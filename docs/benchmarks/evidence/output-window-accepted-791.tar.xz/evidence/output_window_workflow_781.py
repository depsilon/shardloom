"""Complete native Python workflows for the frozen attribution-only experiment."""
import argparse
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

from output_window_driver_781 import E, W, PROTOCOL, PROTOCOL_SHA, sha, verify_artifact
from output_window_oracle_780 import source_fields, source_row


def schema_fields(schema):
    return [dict(name=f.name, type=str(f.type), nullable=f.nullable) for f in schema]


def load_native(path):
    sys.path.insert(0, str(W / 'python/src'))
    import shardloom
    spec = importlib.util.spec_from_file_location('shardloom._native', path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def fixture(pa, rows):
    fields = source_fields()
    schema = pa.schema([pa.field(f['name'], pa.int64(), nullable=f['nullable']) for f in fields])
    scalars = [source_row(r) for r in range(rows)]
    arrays = [pa.array([row[i] for row in scalars], type=pa.int64()) for i in range(4)]
    return pa.RecordBatch.from_arrays(arrays, schema=schema)


def ipc_bytes(pa, batch, compressed=False):
    compression = pa.Codec('zstd', compression_level=3) if compressed else None
    options = pa.ipc.IpcWriteOptions(compression=compression, use_threads=False)
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, batch.schema, options=options) as writer:
        writer.write_batch(batch)
    return sink.getvalue()


def witness(root, payload):
    payload = bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    destination = root / 'witnesses' / f'{digest}.arrow'
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        assert destination.read_bytes() == payload
    else:
        with destination.open('xb') as stream:
            stream.write(payload)
    return dict(path=destination.relative_to(root).as_posix(), bytes=len(payload), sha256=digest)


def matrix(protocol, phase, cohort):
    cells = protocol['workload']['cells']
    if phase == 'smoke':
        return [(cell, rows, override, 0, False) for cell in cells
                for rows, override in ((0, 'zero'), (17, 'small'))] + [(cells[0], cells[0]['rows'], 'declared', 0, False)]
    if phase == 'preflight':
        return [(cell, rows, override, 0, False) for cell in cells
                for rows, override in ((0, 'zero'), (17, 'small'), (cell['rows'], 'declared'))]
    assert phase == 'measure' and cohort in ('A', 'B')
    ordered = cells if cohort == 'A' else list(reversed(cells))
    return [(cells[0], cells[0]['rows'], 'declared', -1, True)] + [
        (cell, cell['rows'], 'declared', sample, False) for cell in ordered for sample in range(3)]


def one_workflow(native, pa, cell, rows, source_fixture, mode):
    buffers, intervals, batch_rows, batch_schemas = [], [], [], []
    record = dict(cell=cell['id'], actual_rows=rows, derived=cell['derived'], plan=cell['plan'],
                  consumer=cell['consumer'], observation_mode=mode, status='running', snapshots={})
    session = source = plan = stream = batch = reader = arrow_batch = None
    start = time.perf_counter_ns()
    try:
        session = native.Session(native.ExecutionResources(64 << 20, 1))
        record['snapshots']['session'] = session.snapshot()
        source = session.from_arrow(source_fixture)
        record['source_row_count'] = source.row_count
        record['source_schema_json'] = source.schema_json
        record['intake_report'] = source.intake_transfer_report
        record['input_columnar_buffer_bytes_copied'] = source.input_columnar_buffer_bytes_copied
        record['snapshots']['source'] = session.snapshot()
        projections = ['k', 'id'] + [f'x * {j + 1} + y AS d{j:03d}' for j in range(cell['derived'])]
        query = 'SELECT ' + ', '.join(projections) + " FROM 'memory://output-window'"
        if cell['plan'] == 'sort':
            query += ' ORDER BY k ASC NULLS LAST'
        record['sql'] = query
        plan = session.sql(query, sources=[('memory://output-window', source)])
        plan.prepare()
        record['snapshots']['prepared'] = session.snapshot()
        stream = plan.iter_batches()
        record['snapshots']['declared'] = session.snapshot()
        record['report_before_demand'] = stream.report
        record['first_provisional_ns'] = None
        while True:
            demand = time.perf_counter_ns()
            batch = next(stream, None)
            received = time.perf_counter_ns()
            if batch is None:
                record['final_response_ns'] = received - start
                break
            if record['first_provisional_ns'] is None:
                record['first_provisional_ns'] = received - start
            assert stream.report is None
            reader = pa.RecordBatchReader.from_stream(batch)
            arrow_batch = reader.read_next_batch()
            assert next(reader, None) is None
            assert arrow_batch.num_rows == batch.row_count
            batch_schemas.append(schema_fields(arrow_batch.schema))
            batch_rows.append(arrow_batch.num_rows)
            buffers.append(ipc_bytes(pa, arrow_batch, cell['consumer'] == 'zstd'))
            serialized = time.perf_counter_ns()
            if cell['consumer'] == 'slow':
                time.sleep(0.001)
            elif cell['consumer'] == 'bursty' and len(buffers) % 4 == 0:
                time.sleep(0.008)
            del arrow_batch, reader, batch
            arrow_batch = reader = batch = None
            intervals.append(dict(demand_ns=demand-start, received_ns=received-start,
                                  serialized_ns=serialized-start, retired_ns=time.perf_counter_ns()-start))
        record['report'] = stream.report
        record['observation'] = json.loads(stream.output_window_observation)
        record['snapshots']['completed'] = session.snapshot()
        assert record['report'] is not None
        stream.close()
        del stream
        stream = None
        plan.release_prepared()
        del plan, source
        plan = source = None
        session.close()
        record['snapshots']['retired'] = session.snapshot()
        assert record['snapshots']['retired']['reserved_bytes'] == 0
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed'
        record['error'] = dict(type=type(error).__name__, message=str(error))
        if stream is not None:
            try:
                stream.close()
                raw = stream.output_window_observation
                record['observation'] = json.loads(raw) if raw else None
                record['report'] = stream.report
            except BaseException as cleanup_error:
                record['cleanup_error'] = repr(cleanup_error)
        stream = batch = reader = arrow_batch = plan = source = None
        gc.collect()
        if session is not None:
            session.close()
            record['snapshots']['retired'] = session.snapshot()
    record['complete_workflow_ns'] = time.perf_counter_ns() - start
    record.update(consumer_intervals=intervals, batch_rows=batch_rows, batch_schemas=batch_schemas)
    del session
    return record, buffers


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--phase', choices=('smoke', 'preflight', 'measure'), required=True)
    parser.add_argument('--mode', choices=('clock', 'trace'), required=True)
    parser.add_argument('--cohort', choices=('smoke', 'preflight', 'A', 'B'), required=True)
    parser.add_argument('--data', required=True)
    args = parser.parse_args()
    assert (args.phase == 'smoke') == (args.cohort == 'smoke')
    assert (args.phase == 'preflight') == (args.cohort == 'preflight')
    assert os.environ['SHARDLOOM_OUTPUT_WINDOW_OBSERVATION'] == args.mode
    bound = verify_artifact(args.label, 'lib')
    root = Path(args.data)
    assert root.parent == E and root.name.startswith('output-window-')
    root.mkdir(exist_ok=True)
    native = load_native(bound['artifact']['path'])
    import pyarrow as pa
    protocol = json.loads(PROTOCOL.read_text())
    declared = matrix(protocol, args.phase, args.cohort)
    fixtures = {rows: fixture(pa, rows) for _, rows, *_ in declared}
    source_witnesses = {rows: witness(root, ipc_bytes(pa, value)) for rows, value in fixtures.items()}
    path = root / f'{args.phase}-{args.mode}-{args.cohort}.jsonl'
    with path.open('x') as stream:
        for ordinal, (cell, rows, override, sample, warmup) in enumerate(declared):
            record, buffers = one_workflow(native, pa, cell, rows, fixtures[rows], args.mode)
            record.update(schema_version='shardloom.output_window_workflow.v1', ordinal=ordinal,
                          phase=args.phase, cohort=args.cohort, override=override, sample=sample, warmup=warmup,
                          protocol_sha256=PROTOCOL_SHA, source_freeze_sha256=bound['source_freeze']['sha256'],
                          native_artifact_sha256=bound['artifact']['sha256'], python_version=sys.version,
                          pyarrow_version=pa.__version__, source_witness=source_witnesses[rows],
                          output_witnesses=[witness(root, buffer) for buffer in buffers])
            stream.write(json.dumps(record, sort_keys=True) + '\n')
            stream.flush()
            del buffers
            print(json.dumps(dict(status=record['status'], phase=args.phase, mode=args.mode, cohort=args.cohort,
                                  ordinal=ordinal, cell=cell['id'], rows=rows)), flush=True)
            assert record['status'] == 'passed', record.get('error')
    verify_artifact(args.label, 'lib')
    assert sha(PROTOCOL) == PROTOCOL_SHA


if __name__ == '__main__':
    main()
