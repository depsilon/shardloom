"""Carry fresh compiled artifacts across an explicit documentation/CI-only delta."""
import json
import subprocess
from pathlib import Path

import output_window_integration_789 as d

OLD = 'output-credit-window-integrated-789-a3'
NEW = 'output-credit-window-integrated-790-a4'
ALLOWED = {
    '.github/workflows/ci.yml',
    'docs/reference/resident-native-results.md',
    'docs/reference/shardloom-user-surface-index.json',
    'docs/reference/shardloom-user-surface-index.md',
    'docs/status/cli-command-registry.md',
    'docs/release/ci-gate-matrix.md',
    'docs/architecture/workspace-feature-build-matrix.md',
}


def verify_identity(row):
    assert d.identity(row['path']) == row, row['path']


def main():
    current = d.verify(NEW)
    prior_path = d.E / f'{OLD}-source-freeze.json'
    prior = json.loads(prior_path.read_text())
    before = {row['path']: row for row in prior['sources']}
    after = {row['path']: row for row in current['sources']}
    assert before.keys() == after.keys()
    changed = sorted(name for name in before if before[name] != after[name])
    assert changed and set(changed) <= ALLOWED, changed
    for helper in prior['helpers']:
        verify_identity(helper)
    patch = d.E / f'{OLD}-tracked.patch'
    assert d.sha(patch) == prior['patch_sha256']
    # Compare the entire old tracked patch with the final one as reconstructed
    # contents, covering JSON and other files absent from the source suffix list.
    import tempfile
    with tempfile.TemporaryDirectory(prefix='output-window-source-delta-', dir=d.E) as temp:
        baseline = Path(temp)
        tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=d.W).decode().split('\0')
        for name in tracked:
            if not name or name in ALLOWED:
                continue
            if name in before:
                assert d.sha(d.W / name) == before[name]['sha256'], name
        old_diff = subprocess.check_output(['git', 'apply', '--numstat', str(patch)], cwd=d.W, text=True)
        new_diff = subprocess.check_output(['git', 'diff', '--numstat', 'HEAD'], cwd=d.W, text=True)
        def relevant(value):
            return [row for row in value.splitlines() if row.split('\t', 2)[-1] not in ALLOWED]
        assert relevant(old_diff) == relevant(new_diff)
        # Git's index represents HEAD; a temporary alternate index reconstructs
        # the old working tree, without touching the real index or checkout.
        import os
        env = dict(os.environ, GIT_INDEX_FILE=str(baseline / 'index'))
        subprocess.run(['git', 'read-tree', 'HEAD'], cwd=d.W, env=env, check=True)
        subprocess.run(['git', 'apply', '--cached', str(patch)], cwd=d.W, env=env, check=True)
        delta = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=d.W, env=env).decode().split('\0')
        assert {name for name in delta if name} <= ALLOWED, delta
    proofs = []
    for kind in ('lib', 'observed'):
        old_path = d.E / f'{OLD}-{kind}-artifact.json'
        record = json.loads(old_path.read_text())
        for key in ('artifact', 'build_receipt', 'build_log', 'source_freeze'):
            verify_identity(record[key])
        assert record['source_freeze'] == d.identity(prior_path)
        assert record['compiler_artifact']['fresh'] is False
        original = d.identity(old_path)
        record.update(source_freeze=d.identity(d.E / f'{NEW}-source-freeze.json'),
                      compiled_source_freeze=d.identity(prior_path),
                      original_artifact_record=original,
                      runtime_sources_byte_identical=True,
                      administrative_delta=changed,
                      rebuilt_after_administrative_delta=False)
        d.save(d.E / f'{NEW}-{kind}-artifact.json', record)
        d.verify_artifact(NEW, kind)
        proofs.append(original)
    d.save(d.E / 'output-window-source-continuity-790.json', dict(status='passed',
        before=d.identity(prior_path), after=d.identity(d.E / f'{NEW}-source-freeze.json'),
        allowed_nonruntime_paths=sorted(ALLOWED), changed_sources=changed,
        runtime_sources_byte_identical=True, original_artifact_records=proofs,
        helper=d.identity(__file__), remeasured=False))
    print(json.dumps(dict(status='passed', changed_nonruntime_sources=changed)))


if __name__ == '__main__':
    main()
