"""Audit the completed saved observation without executing new queries."""
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
python = '/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python'
for name, script in [
    ('pipeline-audit-r1', 'audit_pipeline_certificates.py'),
    ('certificate-export-r1', 'export_certificates.py'),
    ('optimization-activation-r1', 'audit_optimization_coverage.py'),
]:
    print(name, flush=True)
    subprocess.run([sys.executable, str(out / 'guard_checks.py'), '--name', name,
                    '--timeout', '2400', '--', '/usr/bin/env', '-u', 'PYTHONPATH',
                    python, '-B', str(out / script)], check=True)
