"""Retain source-bound release artifacts without replacing an older runtime."""
import os
from pathlib import Path
import shutil
import sys

from pipeline_runtime import ROOT, OUT, fingerprint, git, identity, read, sources

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

import json

CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
receipt = OUT / 'release-build-r1.json'
build = read(receipt)
assert __debug__ and build['status'] == 'passed' and build['returncode'] == 0
assert build['sources_unchanged'] and build['process_group_drained'] and build['direct_child_reaped']
assert build['target_directory'] == str(CACHE)
assert build['source_files'] == sources()
assert git('rev-parse', 'HEAD') == build['head']
assert git('rev-parse', 'HEAD^{tree}') == build['source_tree']
assert not git('status', '--porcelain')
destination = OUT / 'runtime-r1'
require_local_path(destination, Path.home(), sys.platform)
assert not destination.exists()
artifacts = [CACHE / 'release' / name for name in ('shardloom', 'lib_native.dylib')]
before = {str(path): identity(path) for path in artifacts}
check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
    reserve_bytes=2*sum(item['bytes'] for item in before.values()),
    max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
destination.mkdir()
files = {}
for source in artifacts:
    target = destination / source.name
    with source.open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    shutil.copymode(source, target)
    assert identity(source) == identity(target) == before[str(source)]
    files[str(target)] = identity(target)
library = destination / '_native.abi3.so'
with (destination / 'lib_native.dylib').open('rb') as src, library.open('xb') as dst:
    shutil.copyfileobj(src, dst)
assert identity(library) == identity(destination / 'lib_native.dylib')
files[str(library)] = identity(library)
assert os.access(destination / 'shardloom', os.X_OK)
assert build['source_files'] == sources()
record = dict(status='passed', source_commit=build['head'], source_tree=build['source_tree'],
    source_fingerprint_sha256=fingerprint(build['source_files']),
    build_receipt=receipt.name, build_receipt_identity=identity(receipt), profile='release',
    files=files, publication_attempted=False, benchmark_executions=0)
with (OUT / 'runtime-r1-identity.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({'status':record['status'],'source_commit':record['source_commit']}))
