"""Verify every saved successful result used the single native operator pipeline."""
from collections import Counter
import gzip
import json
import math
from pathlib import Path
import re

import replay_10k as replay
from pipeline_runtime import OUT, identity, read

assert __debug__
target = OUT / 'full10k-r1'
destination = target / 'pipeline-certificate-audit-r1.json'
assert not destination.exists()
summary_path = target / 'verified-summary-r1.json'
summary = read(summary_path)
assert summary['status'] == 'passed_offline_replay'
assert summary['successful_cases'] == summary['attempted_cases'] == 10000
ledger, cases = target / 'attempts.sqlite', target / 'verified-cases-r1.jsonl.gz'
assert replay.identity(ledger) == summary['ledger']
assert replay.identity(cases) == summary['case_rows']
before = {str(path): identity(path) for path in (ledger, cases, summary_path)}
counts = Counter()
kernel_families = Counter()
engine, previous = [], []
maximum_operators = maximum_file_kernels = 0
with replay.closing_db(ledger, readonly=True) as database, gzip.open(cases, 'rt') as stream:
    records = iter(stream)
    for seq, case_id, status, packet in database.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'):
        case = json.loads(next(records))
        assert (case['seq'], case['id'], case['current']['status']) == (seq, case_id, status)
        assert seq == counts['cases'] and status == 'passed'
        response = json.loads(replay.raw_files(replay.unpack(packet))['one.stdout.json'])
        fields = response['observation']['fields']
        assert fields['relational_provider_selection_reason'] == 'native_operator_pipeline', case_id
        proof = fields['local_primitive_native_io_pushdown_proof_basis']
        assert 'native_execution_pipeline=native_operator_pipeline' in proof, case_id
        assert 'native_pipeline_catch_all_execution=false' in proof, case_id
        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false', case_id
        def number(name):
            values = re.findall(r'\b' + re.escape(name) + r'=(\d+)\b', proof)
            assert len(values) == 1, (case_id, name, values)
            return int(values[0])
        operators = number('native_pipeline_operator_invocations')
        kernels = number('native_pipeline_file_kernel_invocations')
        assert operators > 0 and 0 <= kernels <= operators, case_id
        counts['cases'] += 1
        counts['operator_invocations'] += operators
        counts['file_kernel_invocations'] += kernels
        maximum_operators = max(maximum_operators, operators)
        maximum_file_kernels = max(maximum_file_kernels, kernels)
        if kernels:
            counts['cases_with_file_kernels'] += 1
            kernel_families[case['family']] += 1
        if 'native_source_demand_prepared_input_bytes_written' in fields:
            assert fields['native_source_demand_prepared_input_bytes_written'] == '0', case_id
            counts['direct_source_cases_reporting_zero_prepared_bytes'] += 1
        if fields.get('write_io_performed') == 'true':
            counts['cases_reporting_write_io'] += 1
        engine.append(case['current']['engine_seconds'])
        previous.append(case['previous_engine_seconds'])
    assert next(records, None) is None
assert counts['cases'] == 10000
assert math.fsum(engine) == summary['successful_engine_seconds']
assert math.fsum(previous) == summary['previous_same_successful_cases_engine_seconds']
assert before == {str(path): identity(path) for path in (ledger, cases, summary_path)}
record = dict(status='passed', query_executions=0,
    source_commit=summary['source_commit'], source_tree=summary['source_tree'],
    all_successful_cases_single_native_pipeline=True, all_catch_all_execution_false=True,
    all_fallback_attempted_false=True, all_external_engine_invoked_false=True,
    counts=dict(counts), maximum_operator_invocations_per_case=maximum_operators,
    maximum_file_kernel_invocations_per_case=maximum_file_kernels,
    file_kernel_case_families=dict(sorted(kernel_families.items())),
    file_kernel_scope='Optional physical specialization inside the native operator tree; this count is not native execution coverage.',
    sources=before, verifier=identity(Path(__file__)))
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record, indent=2))
