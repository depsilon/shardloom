"""Retain all task-owned check outcomes without promoting interrupted runs."""
from collections import Counter
import json
from pathlib import Path

from pipeline_runtime import OUT, identity, read

assert __debug__
destination = OUT / 'validation-inventory-r1.json'
assert not destination.exists()
admitted = read(OUT / 'validation-before-10k.json')
records = []
statuses = Counter()
for path in sorted(OUT.glob('*.json')):
    record = read(path)
    if not isinstance(record, dict) or 'command' not in record or 'source_files' not in record:
        continue
    assert record['status'] in {'passed', 'failed'}
    statuses[record['status']] += 1
    records.append(dict(name=path.name, identity=identity(path), status=record['status'],
                        returncode=record.get('returncode')))
accepted = sorted(admitted['checks'])
assert set(accepted) <= {record['name'] for record in records}
result = dict(status='passed', receipt_count=len(records), receipts=records,
              statuses=dict(statuses), discrepancies=[],
              final_accepted_check_set=accepted, query_executions=0,
              failed_evidence_policy='All failed and interrupted check receipts remain immutable; '
                                     'only explicit passing checks are accepted.')
with destination.open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps({'status':'passed','receipts':len(records),'statuses':dict(statuses)}))
