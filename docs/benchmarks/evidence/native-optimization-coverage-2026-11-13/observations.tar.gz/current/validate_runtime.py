"""Bind completed checks and isolated install proof to the fresh release build."""
import json
import re
from pathlib import Path

from pipeline_runtime import OUT, fingerprint, identity, read, sources, verify

manifest_path = OUT / 'runtime-r1-identity.json'
manifest = read(manifest_path)
build = read(OUT / manifest['build_receipt'])
assert __debug__ and manifest['status'] == build['status'] == 'passed'
assert build['source_files'] == sources()
assert fingerprint(build['source_files']) == manifest['source_fingerprint_sha256']
names = ['fmt-r1', 'native-focused-final-r1', 'default-clippy-r1', 'default-tests-r1',
         'native-clippy-r3', 'native-cli-python-tests-r1', 'installed-wheel-r1']
checks = {}
for name in names:
    path = OUT / (name + '.json')
    check = read(path)
    assert check['status'] == 'passed' and check['returncode'] == 0, name
    assert check['sources_unchanged'] and check['process_group_drained'], name
    assert check['direct_child_reaped'] and check['source_files'] == build['source_files'], name
    checks[path.name] = identity(path)
counts = {}
for name, expected in [('native-focused-final-r1', (172, 0, 0)),
                       ('default-tests-r1', (3325, 0, 0)),
                       ('native-cli-python-tests-r1', (1567, 0, 3))]:
    text = (OUT / 'logs' / (name + '.log')).read_text()
    rows = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
    total = tuple(sum(row[i] for row in rows) for i in range(3))
    assert total == expected, (name, total)
    counts[name] = dict(passed=total[0], failed=total[1], ignored=total[2])
installed = read(OUT / 'installed-wheel-r1/report.json')
integration = read(OUT / 'installed-wheel-r1/integration.json')
assert installed['status'] == integration['status'] == 'passed'
assert integration == dict(tests=442, failures=0, errors=0, skipped=0, status='passed')
assert installed['integrity']['native_library_sha256'] == identity(OUT / 'runtime-r1/_native.abi3.so')['sha256']
assert installed['integrity']['cli_sha256'] == identity(OUT / 'runtime-r1/shardloom')['sha256']
assert not installed['publication_attempted']
record = dict(status='passed', source_commit=manifest['source_commit'],
    source_tree=manifest['source_tree'], runtime=identity(manifest_path), checks=checks,
    installed_checks={name:identity(OUT / name) for name in (
        'installed-wheel-r1/report.json', 'installed-wheel-r1/integration.json')},
    native_validation_scope='focused_changed_owners_plus_all_cli_python_targets',
    full_native_library_suite_completed=False, focused_native_tests_passed=172,
    test_counts=counts, installed_python_tests=integration,
    scope_note='The earlier broad native-library check was interrupted before completion; '
               'it is preserved and receives no full-suite acceptance credit.',
    benchmark_executions=0)
destination = OUT / 'validation-before-10k.json'
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
proof = verify()
print(json.dumps({'status':'passed','source_commit':proof['head'],
                  'test_counts':counts,'installed_python_tests':integration}))
