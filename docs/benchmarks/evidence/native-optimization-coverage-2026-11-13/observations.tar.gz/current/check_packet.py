"""Verify relocation and meaningful corrupted-evidence rejection without queries."""
import gzip
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = OUT / 'compact-evidence-r1'
spec = importlib.util.spec_from_file_location('pipeline_packet_verify', PACKET / 'verify.py')
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def reseal(path, manifest, name):
    manifest['files'][name] = verifier.identity((path / name).read_bytes())


def changed_rows(path, name, change):
    with gzip.open(path / name, 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    change(rows)
    data = ''.join(json.dumps(row, separators=(',', ':')) + '\n' for row in rows).encode()
    (path / name).write_bytes(gzip.compress(data, mtime=0))


def replace_archived(path, manifest, name, transform):
    with tarfile.open(path / 'observations.tar.gz', 'r:gz') as archive:
        rows = {member.name: archive.extractfile(member).read() for member in archive.getmembers()}
    value = json.loads(rows[name])
    transform(value)
    rows[name] = (json.dumps(value, indent=2) + '\n').encode()
    manifest['archive_members'][name].update(verifier.identity(rows[name]))
    with (path / 'observations.tar.gz').open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for member, data in sorted(rows.items()):
                    info = tarfile.TarInfo(member)
                    info.size, info.mode = len(data), 0o644
                    archive.addfile(info, io.BytesIO(data))
    reseal(path, manifest, 'observations.tar.gz')


def main():
    assert __debug__ and not (OUT / 'packet-controls-r1.json').exists()
    assert shutil.disk_usage(OUT).free >= (12 << 30) + (128 << 20)
    original = verifier.verify(PACKET)
    controls = []
    with tempfile.TemporaryDirectory(prefix='compact-proof-check-', dir=OUT) as temporary:
        path = Path(temporary) / 'relocated'
        shutil.copytree(PACKET, path)
        relocated = verifier.verify(path)
        assert relocated == original
        for name in ('unsealed_summary_change', 'duplicate_case_id', 'nonfinite_engine_clock', 'external_fallback_claim', 'wrong_activation_count'):
            shutil.rmtree(path)
            shutil.copytree(PACKET, path)
            manifest = read(path / 'manifest.json')
            if name == 'unsealed_summary_change':
                with (path / 'summary.json').open('ab') as stream:
                    stream.write(b'\n')
            elif name in {'duplicate_case_id', 'nonfinite_engine_clock'}:
                if name == 'duplicate_case_id':
                    changed_rows(path, 'cases.jsonl.gz', lambda rows: rows[1].update(id=rows[0]['id']))
                else:
                    changed_rows(path, 'cases.jsonl.gz', lambda rows: rows[0]['current'].update(engine_seconds=float('nan')))
                reseal(path, manifest, 'cases.jsonl.gz')
                summary = read(path / 'summary.json')
                summary['case_rows']['sha256'] = manifest['files']['cases.jsonl.gz']['sha256']
                write(path / 'summary.json', summary)
                reseal(path, manifest, 'summary.json')
            elif name == 'external_fallback_claim':
                changed_rows(path, 'certificates.jsonl.gz', lambda rows: rows[0]['fields'].update(fallback_attempted='true'))
                reseal(path, manifest, 'certificates.jsonl.gz')
                replace_archived(path, manifest, 'current/full10k-r1/certificate-export-r1.json',
                                 lambda value: value.update(output=manifest['files']['certificates.jsonl.gz']))
            else:
                activation = read(path / 'optimization-activation.json')
                activation['counts']['source_buffer_transfer']['positive'] += 1
                write(path / 'optimization-activation.json', activation)
                reseal(path, manifest, 'optimization-activation.json')
            write(path / 'manifest.json', manifest)
            try:
                verifier.verify(path)
            except AssertionError as error:
                trace = error.__traceback__
                while trace.tb_next is not None:
                    trace = trace.tb_next
                controls.append(dict(name=name, status='rejected', verification_line=trace.tb_lineno))
            else:
                raise AssertionError('corrupted packet admitted: ' + name)
    result = dict(status='passed', original=original, relocated=relocated, controls=controls,
                  query_executions=0, temporary_copies_removed=True,
                  verifier=verifier.identity((PACKET / 'verify.py').read_bytes()),
                  helper=verifier.identity(Path(__file__).read_bytes()))
    write(OUT / 'packet-controls-r1.json', result)
    write(PACKET / 'verification.json', result)
    print(json.dumps(dict(status='passed', relocated=True, rejected_controls=len(controls), query_executions=0)))


if __name__ == '__main__':
    main()
