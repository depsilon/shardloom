"""Export exact saved certificate fields for compact verification; execute no query."""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import zlib

OUT = Path(__file__).resolve().parent
TARGET = OUT / 'full10k-r1'
DEST = TARGET / 'certificate-cases-r1.jsonl.gz'
RECEIPT = TARGET / 'certificate-export-r1.json'


def identity(path):
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def main():
    assert __debug__ and not DEST.exists() and not RECEIPT.exists()
    ledger = TARGET / 'attempts.sqlite'
    summary = json.loads((TARGET / 'verified-summary-r1.json').read_bytes())
    before = identity(ledger)
    assert before['sha256'] == summary['ledger']['sha256']
    names = ('relational_provider_selection_reason', 'local_primitive_native_io_pushdown_proof_basis',
             'fallback_attempted', 'external_engine_invoked', 'native_source_demand_prepared_input_bytes_written')
    count = 0
    with sqlite3.connect(ledger.as_uri() + '?mode=ro', uri=True) as database, DEST.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for seq, case_id, status, blob in database.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'):
                assert seq == count and status == 'passed'
                packet = json.loads(zlib.decompress(blob))
                file = packet['files']['one.stdout.json']
                data = file['utf8'].encode() if 'utf8' in file else base64.b64decode(file['base64'], validate=True)
                assert len(data) == file['bytes'] and hashlib.sha256(data).hexdigest() == file['sha256']
                report = json.loads(data)['observation']
                row = dict(seq=seq, id=case_id, status=status, raw_stdout_sha256=file['sha256'],
                           engine_seconds=report['clocks']['engine_execution_seconds'],
                           engine_timing_reported=report['clocks']['engine_timing_reported'],
                           fields={name: report['fields'][name] for name in names if name in report['fields']})
                stream.write((json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n').encode())
                count += 1
    assert count == 10000 and identity(ledger) == before
    result = dict(status='passed', query_executions=0, cases=count, ledger=before,
                  output=identity(DEST), helper=identity(Path(__file__)),
                  scope='Exact selected certificate fields and engine clocks from each saved raw response; full result payloads and reference expectations remain in the local ledgers.')
    RECEIPT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
