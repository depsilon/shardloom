"""Run source-bound acceptance checks sequentially before the requested 10k pass."""
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
checks = [
    ('fmt-r1', 600, ['cargo', 'fmt', '--all', '--', '--check']),
    ('native-focused-final-r1', 2400, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', '--', 'native_pipeline_', 'provider_tests::', 'provider_normalization_tests::', 'credit_window_', 'source_demand_tests::', 'native_decimal_rolling_relational_limits_cap_only_safe_output_prefixes', 'empty_source']),
    ('default-clippy-r1', 5400, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-r1', 5400, ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('native-cli-python-tests-r1', 5400, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--all-targets', '--features', 'release-user-surfaces']),
]
for name, timeout, command in checks:
    print(name, flush=True)
    subprocess.run([sys.executable, str(out / 'guard_checks.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], check=True)
