"""Count recorded activation from saved results, without claiming total coverage."""
from collections import Counter, defaultdict
import gzip
import json
import re

from pipeline_runtime import OUT, identity, read

TARGET = OUT / 'full10k-r1'
DEST = TARGET / 'optimization-activation-r1.json'
COUNTERS = {
    'source_buffer_transfer': 'intake_columnar_buffer_bytes_transferred',
    'materialized_relation_reuse': 'relational_materialized_reuses',
    'metadata_pruned_scan': 'scans_metadata_pruned',
    'rank_then_selected_payload_source': 'ranked_sources',
    'adaptive_native_scan_policy_exercised': 'adaptive_native_scan_completed_windows',
    'adaptive_native_scan_window_shrunk': 'adaptive_native_scan_shrunk_windows',
    'adaptive_native_scan_window_grown': 'adaptive_native_scan_grown_windows',
}

assert __debug__ and not DEST.exists()
summary = read(TARGET / 'verified-summary-r1.json')
assert summary['successful_cases'] == summary['attempted_cases'] == 10000
paths = [TARGET / 'verified-cases-r1.jsonl.gz', TARGET / 'certificate-cases-r1.jsonl.gz']
before = {p.name:identity(p) for p in paths}
assert before[paths[0].name]['sha256'] == summary['case_rows']['sha256']
assert before[paths[1].name] == read(TARGET / 'certificate-export-r1.json')['output']
counts = defaultdict(Counter)
seen = set()
with gzip.open(paths[0], 'rt') as cases, gzip.open(paths[1], 'rt') as certificates:
    for ordinal, (case_line, certificate_line) in enumerate(zip(cases, certificates, strict=True)):
        case, cert = json.loads(case_line), json.loads(certificate_line)
        assert case['id'] == cert['id'] and case['seq'] == cert['seq'] == ordinal
        assert case['current']['status'] == cert['status'] == 'passed'
        assert case['id'] not in seen
        seen.add(case['id'])
        pairs = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
                           cert['fields']['local_primitive_native_io_pushdown_proof_basis'])
        assert len(pairs) == len(dict(pairs)), 'ambiguous duplicate counters'
        metrics = {key:int(value) for key, value in pairs}
        group = 'with_file_kernel' if metrics['native_pipeline_file_kernel_invocations'] else 'without_file_kernel'
        counts['cases'][group] += 1
        for label, key in COUNTERS.items():
            if key in metrics:
                counts[label]['reported'] += 1
                if metrics[key] > 0:
                    counts[label]['positive'] += 1
                    counts[label][group] += 1
        work = case['current']['work']
        projected = work.get('native_source_demand_projected_columns')
        available = work.get('native_source_demand_available_columns')
        if projected is not None and available is not None:
            counts['direct_source_narrow_column_demand']['reported'] += 1
            if 0 < int(projected) < int(available):
                counts['direct_source_narrow_column_demand']['positive'] += 1
                counts['direct_source_narrow_column_demand'][group] += 1
assert len(seen) == sum(counts['cases'].values()) == 10000
assert {p.name:identity(p) for p in paths} == before
result = dict(status='passed', query_executions=0, source_commit=summary['source_commit'],
    inputs=before, counts=dict(counts), counter_keys=COUNTERS,
    overall_optimization_coverage_percent=None,
    overall_coverage_status='not_complete_existing_and_planned_mechanisms_remain_open',
    limits=['Counts overlap and are not comprehensive optimization coverage.',
            'Zero or absent counters do not establish ineligibility or a missing implementation.',
            'Positive counters establish recorded activation/work, not individual speed benefit.',
            'Adaptive policy execution does not by itself mean a window changed size.',
            'Column demand does not establish proportional byte savings for every source format.'],
    verifier=identity(OUT / 'audit_optimization_coverage.py'))
with DEST.open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps(dict(status=result['status'], counts=result['counts'])))
