"""Package version for the ShardLoom Python client.

This file is derived from root Cargo.toml by scripts/sync_workspace_package_versions.py.
"""

__version__ = "1.1.0"
