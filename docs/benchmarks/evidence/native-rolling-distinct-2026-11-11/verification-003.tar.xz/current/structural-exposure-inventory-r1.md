# Structural exposure inventory (r1)

Status: **NEEDS_REASONING** — source boundaries are located, but exact matching corpus case IDs/counts for all three proposed shapes were not established. This is an exposure inventory, not a semantic/design/acceptance decision. No code, query, timing, or implementation authorization is inferred.

## Snapshot and evidence identity

Active checkout: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`, branch `codex/native-rolling-distinct`, HEAD `591fdb42f6ffcd5e9003b4a5c130324d7a34a62c` (as requested). Worktree has task-owned modifications in `shardloom-vortex/src/local_primitives/native_relational_window_frame_state.rs` and untracked `shardloom-vortex/src/local_primitives/native_relational_window_distinct_baseline_tests.rs`; neither was read as evidence for these hypotheses.

Frozen design: `/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/design.json`, SHA-256 `fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216`, declares `analytical-10000-v2`, 10,000 cases. Supplied hypothesis attachment SHA-256 `eb87af60f9ae2f216542c0d5d6b0315b74b6989b402b0e08c3935594783bb518`.

Source SHA-256 at inspection:

- `shardloom-vortex/src/local_primitive_relational_correlated.rs`: `126a6e1e9beab7b654a49e960e2ce96bc2853939ba2189aff8accd291c2fb037`
- `shardloom-vortex/src/local_primitive_relational_decorrelate.rs`: `2635d2022ac8d0d80b9710d0c4ceb35ccc6ded063d3cdb1bb6893fcf340ee044`
- `shardloom-vortex/src/local_primitive_relational_transform.rs`: `afcc717a218dc5ae20b417c71c499bbedd7c9c369c84d6bf86062399338f2388`
- `shardloom-vortex/src/local_primitives/native_relational_join.rs`: `293d9dafe2c2638e585564da0a68714011c6bc679a09247ace9ea6a393880cc0`
- `shardloom-vortex/src/local_primitives/native_relational_sort.rs`: `78d1867f62f89d13c29975c04e20e45c237ea915d6311de3f4f3f296990bdb06`
- `shardloom-vortex/src/local_primitives/native_relational_order.rs`: `ba4deced97c28dc97fc65a9f33bc9f8f0dd2eca9dee3548532772c7254d9e4e2`

## 1. Correlated scalar COUNT vs restricted EXISTS/IN rewrite

**Source boundary:** `local_primitive_relational_correlated.rs:32-42` routes parameterized nodes into the correlated path; `:46-107` runs outer input and iterates selected rows; `:56-68` extracts a one-row parameter and dispatches per row; `:100-103` records/finishes each subquery state. Dynamic relation binding is also per selected row at `:69-98`. This establishes a structural repeated-execution boundary; it does not measure its runtime cost on any cohort case.

The rewrite owner is `local_primitive_relational_decorrelate.rs:1-3` and `:83-119` (`pure_source`), with eligibility machinery in the rest of the file. Its module comment explicitly describes removal of pure equality parameters and retaining singleton execution for callbacks, filters, finite limits, or effects. The located tests include `local_primitive_relational_correlated_tests.rs:416` and following, but that name alone does not establish a frozen 10k case match.

Existing observation surface found: `Metrics` in `local_primitive_prepared_relational.rs` contains subquery-related counters (`subquery_build_rows_detached`, `subquery_outer_rows_detached`, `subquery_validation_rows`; around lines 1037 and assignments around 1546). No named scalar-correlated inner-execution count was located in this pass. These counters do not, by themselves, establish number of per-row subquery executions or visited inner rows.

Frozen cohort exact matching: **unmatched / not established**. The design JSON records IDs/archetypes/families and reference paths, but those labels are not sufficient to assert the precise scalar COUNT same-source eligible shape. Need inspect the frozen original input/harness records and match their actual SQL/typed plan. Do not use family names as proxies.

## 2. Sparse intermediate consumer batching

**Source boundary:** `local_primitive_relational_transform.rs:54-72` streams each filter result through `rows.for_each_batch(..., consume)`; pipeline execution starts at `:112-120`, and stage application occurs within each delivered input array at `:158-176`. Join implementation is the named source `native_relational_join.rs` (hash above); hypothesis specifically points to per-input-batch accumulation and flush. The exact join consume/flush line region still needs a focused read before any stronger assertion. Replay retention is a separate boundary in `local_primitive_relational_replay_capture.rs`; it is not general consumer batching.

Existing observation surface: no direct counter name for downstream preparation/initialization count or sparse-fragment count was established in the inspected snippets. Thus the source callback boundary is visible, while actual invocation frequency and cost are unmeasured. Hypothesis-listed counters are not runtime evidence unless tied to a matching recorded observation.

Frozen cohort exact matching: **unmatched / not established**. Sparse selectivity and downstream operator composition must be derived from original case SQL/plan records, not inferred from selectivity-family names. No case IDs/count are asserted.

## 3. Full disordered sort key interpretation / heap

**Source boundary:** `native_relational_sort.rs:86-107` validates and retains input batches; `:109-154` creates ordinals, selects prefix or full-sort route; full ordering is called at `:143-153`; comparator `:157-172` repeatedly locates rows and compares each specified key, returning ordinal comparison for stable ties. `native_relational_order.rs` owns ordering algorithms (SHA above). This is a clear comparator invocation boundary, not evidence that comparator/key interpretation dominates runtime.

Existing debug observation names found in tests/code include `order_check_comparisons` (test assertion in `local_primitives/native_relational_sort_tests.rs:86`) and numeric prefix counters `sort_numeric_prefix_comparisons`, `sort_numeric_prefixes`, `sort_numeric_prefix_rows`, `sort_numeric_prefix_key_views` in `native_relational_sort_numeric.rs` around lines 69-71 and 191-195. Prefix counters apply to the bounded numeric-prefix path and are not measurements of general full disordered sort comparison/key interpretation. No confirmed full-sort comparator-count counter was located in this inventory. `order_check_comparisons` concerns the ordered-input check, not necessarily heap comparisons.

Frozen cohort exact matching: **unmatched / not established**. Need original SQL/plan per case to distinguish full disordered ORDER BY from Top-K, already-ordered inputs, window ordering, or other family members. No family-label-based count is claimed.

## Unresolved evidence required

1. Identify the frozen original harness/input file referenced by the design metadata and resolve every potentially matching case to its actual SQL/plan; report exact matching and unmatched counts per hypothesis.
2. For batching, finish locating the join's per-input-batch flush owner and enumerate existing counters, carefully labeling proxy counters versus direct invocation counters.
3. Confirm whether a full-sort comparison counter exists beyond the test-only order-check and numeric-prefix counters listed above.

No benchmark, build, test, query execution, source edit, or external fetch was performed. Source-boundary evidence must not be presented as measured runtime exposure.
