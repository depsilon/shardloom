"""Independent set answers from frozen IPC, plus byte-exact accepted controls."""
from contextlib import ExitStack, closing
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

from rolling_common import (CLIENT, E, FROZEN, OUT, REFERENCE, S, SELECTION, T,
    Cases, accepted_runtime, content, database, digest, load_module, read, worker)
from query_surface.datasets import SCHEMAS
from query_surface.evidence import identity
from query_surface.expanded_freeze import pack, unpack
from query_surface.semantics import arrow_schema, compare, result_from_record, result_record
from resources import BenchmarkGuard


def main():
    import pyarrow as pa
    import pyarrow.compute as pc
    assert __debug__ and not REFERENCE.parent.exists()
    helper_path = S / 'tools/prepare_window_references.py'
    assert content(helper_path) == dict(bytes=13194,
        sha256='ee26a8bff27fb9d84e0d02a15f73950fa2d412c4f20f680372cec6a533a1d978')
    previous = load_module('accepted_reference_transport', helper_path)
    current = previous.historical_subset()
    accepted_runtime()
    protocol = read(T / 'candidate-protocol-r1.json')
    old_reference = protocol['runtime_binding']['composition_reference']
    assert identity(Path(old_reference['path'])) == old_reference
    checked = read(OUT / 'client-check-r2.json')
    assert checked['status'] == 'passed_declaration_and_reference_controls'
    for path, expected in checked['sources'].items():
        assert content(Path(path)) == expected
    assert content(E / 'design.json')['sha256'] == 'fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216'
    inputs, frozen = read(E / 'inputs.json'), read(E / 'frozen.json')
    current(frozen['inputs']); current(frozen['design'])
    assert frozen['design'] == inputs['design'] and pa.__version__ == frozen['pyarrow'] == '25.0.1'
    rows = read(SELECTION)['cases']
    new = [r for r in rows if 'rolling_distinct_version' in r['case']]
    controls = [r for r in rows if r['kind'] == 'composition' and 'rolling_distinct_version' not in r['case']]
    assert len(new) == len(controls) == 436 and len(rows) == 1090
    cases = Cases()
    for row in new:
        worker.validate(row['case'])
    proof = {str(p): identity(p) for p in (Path(__file__), helper_path, SELECTION,
        CLIENT / 'rolling_distinct_cases.py', CLIENT / 'rolling_distinct_worker.py',
        OUT / 'client-check-r2.json', T / 'candidate-protocol-r1.json',
        E / 'design.json', E / 'inputs.json', E / 'frozen.json', Path(old_reference['path']))}
    harness = {}
    old_root = '/Users/dylan/.codex/worktrees/native-post-110-optimization/shardloom-local-repo/'
    for item in frozen['harness']:
        assert item['path'].startswith(old_root)
        path = FROZEN / item['path'].removeprefix(old_root)
        assert content(path) == dict(bytes=item['generation']['bytes'], sha256=item['sha256'])
        harness[str(path)] = content(path)
    assert len(harness) == 65
    known = {row['path']: row for row in inputs['files']}
    result = dict(schema='shardloom.rolling_distinct_reference.v1', status='failed',
        native_query_executions=0, native_runtime_loaded=False, comparison_engine_benchmark_runs=0,
        independent_boundary='PyArrow input transport and Python sets over each complete frame',
        selection=identity(SELECTION), generator=identity(Path(__file__)),
        accepted_control_reference=old_reference, frozen_harness_files=harness,
        profiles={}, rows=[], pyarrow=pa.__version__)
    REFERENCE.parent.mkdir()
    try:
        with BenchmarkGuard(REFERENCE.parent, binary=Path('shardloom'), memory_gb=2) as guard, closing(sqlite3.connect(REFERENCE)) as db:
            db.execute('PRAGMA journal_mode=DELETE')
            db.execute('CREATE TABLE expected (id TEXT PRIMARY KEY, identity TEXT NOT NULL, value BLOB NOT NULL)')
            with database(Path(old_reference['path'])) as old:
                assert old.execute('SELECT COUNT(*) FROM expected').fetchone() == (436,)
                for row in controls:
                    c = row['case']; item = cases.item(c)
                    entry = old.execute('SELECT identity,value FROM expected WHERE id=?', (c['id'],)).fetchone()
                    assert entry and entry[0] == item.identity == c['case_identity']
                    expected = result_from_record(unpack(entry[1]))
                    compare(expected, expected, item.contract)
                    db.execute('INSERT INTO expected VALUES (?,?,?)', (c['id'], *entry))
                    result['rows'].append(dict(ordinal=row['cohort_ordinal'], id=c['id'], identity=entry[0],
                        origin='byte_exact_accepted_control', blob_sha256=hashlib.sha256(entry[1]).hexdigest(),
                        blob_bytes=len(entry[1]), result_rows=len(expected.rows)))
            db.commit()
            for profile in ('smoke', 'holdout', 'primary', 'scale'):
                group = [r for r in new if r['case']['profile'] == profile]
                declared = inputs['profiles'][profile]
                dataset = Path(declared['dataset']); manifest_path = dataset / 'dataset.json'
                proof[str(manifest_path)] = current(known[str(manifest_path)])
                manifest = read(manifest_path)
                assert manifest['spec'] == declared['spec'] and manifest['layout'] == declared['layout']
                assert manifest['logical_identity'] == declared['logical_identity']
                names = sorted({'row_id', 'selection_key'} | {r['case']['declaration'][key]
                    for r in group for key in ('partition', 'argument')})
                fact = manifest['tables']['fact']; paths = [dataset / p['path'] for p in fact['files']]
                assert list(map(str, paths)) == declared['sources']['arrow-ipc']['fact']
                with ExitStack() as stack:
                    tables = []
                    for path, part in zip(paths, fact['files'], strict=True):
                        assert path.resolve().is_relative_to(dataset.resolve()) and not path.is_symlink()
                        proof[str(path)] = current(known[str(path)])
                        assert content(path) == dict(bytes=part['bytes'], sha256=part['sha256'])
                        memory = stack.enter_context(pa.memory_map(str(path), 'r'))
                        reader = pa.ipc.open_file(memory)
                        assert arrow_schema(reader.schema) == SCHEMAS['fact']
                        options = pa.ipc.IpcReadOptions(use_threads=False,
                            included_fields=[reader.schema.get_field_index(name) for name in names])
                        table = pa.ipc.open_file(memory, options=options).read_all().select(names)
                        assert dict(arrow_schema(table.schema)) == {n: dict(SCHEMAS['fact'])[n] for n in names}
                        assert table.num_rows == part['rows']; tables.append(table)
                    table = pa.concat_tables(tables)
                    assert table.num_rows == fact['rows'] == declared['spec']['fact_rows']
                    assert table['row_id'].null_count == 0 and pc.count_distinct(table['row_id']).as_py() == table.num_rows
                    assert pc.min(table['row_id']).as_py() == 0 and pc.max(table['row_id']).as_py() == table.num_rows - 1
                    if profile == 'smoke':
                        source_rows = table.to_pylist()
                        for scope in {r['case']['declaration']['population'] for r in new}:
                            assert previous.filtered(table, scope)['row_id'].to_pylist() == [r['row_id']
                                for r in source_rows if worker.declarations.admitted_population(r, scope)]
                    for row in group:
                        guard.check(); c = row['case']
                        expected = worker.declarations.reference(c, previous.rows(table, c, guard))
                        document = result_record(expected); blob = pack(document)
                        compare(expected, result_from_record(unpack(blob)), worker.declarations.contract(c))
                        db.execute('INSERT INTO expected VALUES (?,?,?)', (c['id'], c['case_identity'], blob)); db.commit()
                        result['rows'].append(dict(ordinal=row['cohort_ordinal'], id=c['id'], identity=c['case_identity'],
                            origin='independent_python_set', result_rows=len(expected.rows), blob_bytes=len(blob),
                            blob_sha256=hashlib.sha256(blob).hexdigest(), document_sha256=digest(document)))
                    result['profiles'][profile] = dict(input_rows=table.num_rows, cases=len(group),
                        input_columns=names, logical_identity=manifest['logical_identity'])
                    del table, tables
                print(json.dumps(dict(reference_profile=profile, complete_new_cases=sum(
                    r['origin'] == 'independent_python_set' for r in result['rows']), native_query_executions=0)), flush=True)
            assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
            assert db.execute('SELECT COUNT(*) FROM expected').fetchone() == (872,)
            assert len(result['rows']) == len({r['id'] for r in result['rows']}) == 872
            for row in result['rows']:
                entry = db.execute('SELECT identity,value FROM expected WHERE id=?', (row['id'],)).fetchone()
                assert entry[0] == row['identity'] and hashlib.sha256(entry[1]).hexdigest() == row['blob_sha256']
            guard.check(); result['resource_observations'] = guard.samples
        for path, expected in proof.items():
            assert identity(Path(path)) == expected, path
        for path, expected in harness.items():
            assert content(Path(path)) == expected, path
        assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
        result['rows'].sort(key=lambda r: r['ordinal'])
        assert {r['ordinal'] for r in result['rows']} == {r['cohort_ordinal'] for r in rows if r['kind'] == 'composition'}
        result.update(status='passed_independent_references', new_cases=436, reused_control_cases=436,
            cases=872, expected=identity(REFERENCE), proof=proof, input_and_client_hashes_unchanged=True,
            original_controls=218, original_control_references='unchanged frozen per-profile or legacy references',
            complete_scoring_protocol_frozen=False)
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        if 'guard' in locals():
            result['resource_observations'] = guard.samples
        raise
    finally:
        with (REFERENCE.parent / 'complete.json').open('x') as stream:
            json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'new_cases', 'reused_control_cases', 'native_query_executions')}))


if __name__ == '__main__':
    main()
