"""Construct public requests and check independent reference semantics; no execution."""
import ast
import copy
import json
from pathlib import Path
from unittest.mock import patch

from rolling_common import CLIENT, OUT, SELECTION, accepted_runtime, content, digest, read, worker
from query_surface.worker import load_native

DEST = OUT / 'client-check-r2.json'
assert __debug__ and not DEST.exists()
cases = [row['case'] for row in read(SELECTION)['cases'] if 'rolling_distinct_version' in row['case']]
assert len(cases) == 436
runtime, _ = accepted_runtime()
sources = {str(path): content(path) for path in (Path(__file__), SELECTION,
    CLIENT / 'rolling_distinct_cases.py', CLIENT / 'rolling_distinct_worker.py')}
result = dict(status='failed', query_executions=0, preparation_calls=0, collect_calls=0,
    sources=sources, runtime=runtime, native_library_loaded=True)
try:
    for path in CLIENT.glob('*.py'):
        ast.parse(path.read_text())
    native = load_native(Path(runtime['library']['path']))
    import shardloom as sl
    client = sl.ShardLoomClient(binary=runtime['binary']['path'], transport='native',
        use_persistent_worker=False, memory_bytes=1 << 30, max_parallelism=1, timeout=60)
    try:
        for case in cases:
            worker.validate(case)
            suffix = {'parquet': 'parquet', 'vortex': 'vortex', 'arrow-ipc': 'arrow'}[case['native_format']]
            declared = {'fact': ['/declared-only/fact.' + suffix]}
            sql = worker.declarations.sql(case, declared)
            assert sql.count('COUNT(DISTINCT ') == sql.count(' OVER (') == 1
            assert type(worker.declarations.native_plan(case, declared, native)) is native.Relation
            class OutputColumns:
                def window(self, columns, outputs):
                    assert len(columns) == len(set(columns)), 'duplicate window output aliases'
                    assert columns[0] == 'row_id' and outputs
                    return self
                def project(self, _):
                    return self
                def sort(self, _):
                    return self
                def limit(self, *_args, **_kwargs):
                    return self
            with patch.object(worker.declarations.adapters, 'relation_native', return_value=OutputColumns()):
                worker.declarations.native_plan(case, declared, native)
            frame = worker.declarations.dataframe(case, declared, sl, client)
            assert frame.client is client and frame.operations[-1].kind == 'limit'
            assert client._native_backend is None and client._worker_process is None and not client._active_processes
        rejected = []
        for name, mutate in (
            ('identity', lambda c: c.update(case_identity='0' * 64)),
            ('request_id', lambda c: c.update(id='unknown')),
            ('surface', lambda c: c.update(surface='unknown')),
            ('frame', lambda c: c['declaration']['frame'].update(preceding=99)),
            ('source_identity', lambda c: c['original_case'].update(case_identity='0' * 64)),
            ('source_argument', lambda c: c['declaration'].update(source_argument='row_id')),
            ('new_argument', lambda c: c['declaration'].update(argument='row_id')),
        ):
            changed = copy.deepcopy(cases[0]); mutate(changed)
            try:
                worker.validate(changed)
            except ValueError:
                rejected.append(name)
            else:
                raise AssertionError('corrupted request accepted: ' + name)
        # Rebind the identity so source and target validation must do real work.
        for name in ('source_argument', 'new_argument'):
            changed = copy.deepcopy(cases[0]); changed['declaration'][name.replace('new_', '')] = 'row_id'
            changed['case_identity'] = digest(changed['declaration'])
            changed['id'] = f"window_distinct_v1_{changed['declaration']['family']}_{changed['case_identity'][:16]}"
            try:
                worker.validate(changed)
            except ValueError:
                rejected.append('rebound_' + name)
            else:
                raise AssertionError('rebound corrupted source accepted')
    finally:
        client.close()
    rows = [dict(row_id=i, group_key=g, signed_value=v) for i, (g, v) in enumerate(
        [(None, 5), ('A', 3), (None, 5), ('A', 3), (None, None), ('A', 4), (None, 7)])]
    toy = copy.deepcopy(cases[0]); d = toy['declaration']
    d.update(population='population', partition='group_key', argument='signed_value', source_argument='signed_value', output_limit=7)
    d['frame']['preceding'] = 1
    for reverse, counts in ((False, [1, 1, 1, 1, 1, 2, 1]), (True, [1, 1, 1, 2, 1, 1, 1])):
        d['order']['descending'] = reverse
        expected = [dict(row_id=i, count_distinct=counts[i]) for i in reversed(range(7))]
        assert worker.declarations.reference(toy, rows).rows == expected
    assert worker.declarations.reference(toy, []).rows == []
    assert all(row['count_distinct'] == 0 for row in worker.declarations.reference(
        toy, [dict(row, signed_value=None) for row in rows]).rows)
    try:
        worker.declarations.reference(toy, rows + [rows[0]])
    except ValueError as error:
        assert 'unique integers' in str(error)
    else:
        raise AssertionError('duplicate reference row IDs accepted')
    assert all(content(Path(path)) == item for path, item in sources.items())
    result.update(status='passed_declaration_and_reference_controls', declarations=436,
        rejected_corruptions=rejected, independent_controls=['duplicate membership', 'null membership',
            'nullable partitions', 'ascending/descending frame membership', 'empty/all-null', 'duplicate row ID refusal'])
except BaseException as error:
    result['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with DEST.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'declarations', 'query_executions')}))
