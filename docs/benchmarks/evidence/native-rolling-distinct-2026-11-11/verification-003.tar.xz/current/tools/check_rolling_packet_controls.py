"""Challenge portable rolling DISTINCT evidence without executing a query."""
from __future__ import annotations

import argparse
import copy
import gzip
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile

import verify_rolling_packet as verifier

T = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
RAW_CONTROLS = {'candidate_engine_total_corrupted', 'candidate_case_omitted',
    'baseline_reuse_corrupted', 'candidate_no_fallback_denied', 'gain_disposition_corrupted',
    'composition_identity_changed', 'composition_reference_changed'}
DIAGNOSTIC_CONTROLS = {'allocation_capacity_corrupted', 'allocation_peak_corrupted', 'allocation_membership_corrupted',
    'required_test_missing_with_rebound_log'}


def put(data, name, value):
    data[name] = (json.dumps(value, indent=2) + '\n').encode()


def change(data, name, update):
    value = json.loads(data[name])
    update(value)
    put(data, name, value)


def rebind_diagnostic_files(report, data):
    def update(row):
        for path in row['files']:
            row['files'][path] = verifier.identity(data[report['locations'][path]])
    change(data, 'current/candidate-diagnostics-r1.json', update)


def mutate(name, report, data):
    receipt = 'current/candidate-native-tests-r1.json'
    if name == 'native_test_failure':
        change(data, receipt, lambda row: row.update(status='failed', returncode=101))
    elif name == 'undrained_native_process':
        change(data, receipt, lambda row: row.update(process_group_drained=False))
    elif name == 'mutable_source_validation':
        change(data, receipt, lambda row: row.update(fixed_source_validation=False, allow_lockfile_update=True))
    elif name in ('window_source_changed', 'root_lock_changed'):
        source = 'Cargo.lock' if name == 'root_lock_changed' else 'shardloom-vortex/src/local_primitives/native_relational_window_rolling_distinct.rs'
        data['source-blobs/' + report['candidate_source_snapshot'][source]['sha256']] += b'\ncorruption-control\n'
    elif name == 'required_test_missing_with_rebound_log':
        required = json.loads(data['current/candidate-diagnostics-r1.json'])['required_tests'][0]
        log = 'current/candidate-native-tests-r1.log'
        lines = data[log].splitlines(keepends=True)
        selected = [i for i, line in enumerate(lines) if line.startswith(b'test ') and
            line.endswith(('::' + required + ' ... ok\n').encode())]
        assert len(selected) == 1
        del lines[selected[0]]
        change(data, 'current/candidate-diagnostics-r1.json', lambda row: row.update(
            actual_passed_tests=[item for item in row['actual_passed_tests'] if not item.endswith('::' + required)]))
        data[log] = b''.join(lines)
        change(data, receipt, lambda row: row.update(log_sha256=verifier.digest(data[log])))
        rebind_diagnostic_files(report, data)
    elif name == 'ignored_ci_policy_changed':
        key = 'source-blobs/' + report['candidate_source_snapshot'][verifier.CI_POLICY_PATH]['sha256']
        def alter(row):
            row['ignored_tests'].append('ordinary::correctness_test')
            row['ignored_tests'].sort()
        change(data, key, alter)
    elif name == 'actual_ci_inventory_changed':
        change(data, 'current/candidate-ci-inventory-r1.json', lambda row: row['partitions'][0]['tests'].pop())
    elif name == 'runtime_library_mismatch':
        def alter(row):
            item = next(item for item in row['files'] if Path(item['path']).name == 'lib_native.dylib')
            item['sha256'] = '0' * 64
        change(data, 'current/runtime-r1-identity.json', alter)
    elif name in ('allocation_capacity_corrupted', 'allocation_peak_corrupted', 'allocation_membership_corrupted'):
        target = 'current/candidate-allocation-observations-r2.json'
        observations = json.loads(data[target])
        field, value = {
            'allocation_capacity_corrupted': ('allocated_buckets', 131072),
            'allocation_peak_corrupted': ('peak_reserved_bytes', 1 << 30),
            'allocation_membership_corrupted': ('active_entries', 0),
        }[name]
        observations['records'][0][field] = value
        put(data, target, observations)
        rebind_diagnostic_files(report, data)
    elif name == 'candidate_engine_total_corrupted':
        key = 'current/candidate-verified-r1.json'
        row = json.loads(data[key])
        row['engine_execution_seconds'] = (row['engine_execution_seconds'] or 0) + 1
        row['engine_seconds_saved'] = row['baseline_engine_execution_seconds'] - row['engine_execution_seconds']
        row['observed_engine_reduction_percent'] = 100 * row['engine_seconds_saved'] / row['baseline_engine_execution_seconds']
        put(data, key, row)
        report['candidate'].update({key: row[key] for key in report['candidate']})
    elif name == 'candidate_case_omitted':
        key = 'current/candidate-cases-r1.jsonl.gz'
        rows = gzip.decompress(data[key]).splitlines(keepends=True)
        assert len(rows) == 1090
        data[key] = gzip.compress(b''.join(rows[:-1]), mtime=0)
        def alter(row):
            row['case_rows']['generation']['bytes'] = len(data[key])
            row['case_rows']['sha256'] = verifier.digest(data[key])
        change(data, 'current/candidate-verified-r1.json', alter)
    elif name == 'baseline_reuse_corrupted':
        change(data, 'current/baseline-reuse-r1.json',
            lambda row: row['rows'][0].update(source_seq=-1))
    elif name == 'candidate_no_fallback_denied':
        change(data, 'current/candidate-verified-r1.json', lambda row: row.update(native_no_fallback=False))
    elif name == 'gain_disposition_corrupted':
        wrong = 'drop_candidate_no_gain' if report['disposition'] == 'retain_candidate' else 'retain_candidate'
        report['disposition'] = wrong
        change(data, 'current/candidate-verified-r1.json', lambda row: row.update(frozen_rule_disposition=wrong))
    elif name == 'original_failure_omitted':
        key = 'candidate-native-clippy-r1.json'
        del data['current/' + key]
        report['original_failed_checks'] = [row for row in report['original_failed_checks'] if row['receipt'] != 'current/' + key]
        change(data, 'current/candidate-failure-dispositions-r1.json', lambda row: row.pop(key))
    elif name in ('full10k_claim', 'full43_claim'):
        report['complete_10k_performance_claim' if name == 'full10k_claim' else 'full43_claim'] = True
    elif name == 'composition_identity_changed':
        def alter(row):
            item = next(item for item in row['cases'] if 'rolling_distinct_version' in item['case'])
            item['case']['case_identity'] = '0' * 64
        change(data, 'current/candidate-protocol-r1.json', alter)
    elif name == 'composition_reference_changed':
        key = 'current/references-r1/expectations.sqlite'
        with tempfile.TemporaryDirectory(prefix='rolling-control-reference-', dir=T) as temporary:
            path = Path(temporary) / 'reference.sqlite'
            path.write_bytes(data[key])
            with sqlite3.connect(path) as connection:
                changed = connection.execute("UPDATE expected SET identity=? WHERE id=(SELECT id FROM expected WHERE id LIKE 'window_distinct_v1_%' ORDER BY id LIMIT 1)", ('0' * 64,)).rowcount
                assert changed == 1
            data[key] = path.read_bytes()
    else:
        raise ValueError('unrecognized control: ' + name)


def child(packet_path, name):
    report, data = verifier.read_archive(packet_path)
    if name == 'archive_byte_changed':
        with tempfile.TemporaryDirectory(prefix='rolling-control-archive-', dir=T) as temporary:
            clone = Path(temporary) / 'packet'
            shutil.copytree(packet_path, clone)
            path = clone / report['archives'][0]['path']
            raw = bytearray(path.read_bytes())
            raw[-1] ^= 1
            path.write_bytes(raw)
            try:
                verifier.read_archive(clone)
            except AssertionError:
                return dict(name=name, outcome='rejected', boundary='archive_identity')
        raise AssertionError('corrupted archive was accepted')
    report, data = copy.deepcopy(report), dict(data)
    mutate(name, report, data)
    boundary = 'source_runtime_claim_binding'
    try:
        if name in RAW_CONTROLS:
            boundary = 'complete_saved_result_replay'
            with tempfile.TemporaryDirectory(prefix='rolling-control-replay-', dir=T) as temporary:
                verifier.replay_saved(report, data, Path(temporary))
        elif name in DIAGNOSTIC_CONTROLS:
            boundary = 'diagnostic_work_invariants'
            verifier.verify_diagnostics(verifier.Packet(report, data))
        elif name in ('ignored_ci_policy_changed', 'actual_ci_inventory_changed'):
            boundary = 'exact_ci_inventory'
            verifier.verify_ci(verifier.Packet(report, data), report['candidate_source_snapshot'])
        else:
            verifier.verify_sources(report, data)
    except (AssertionError, KeyError, ValueError) as error:
        return dict(name=name, outcome='rejected', boundary=boundary, failure_type=type(error).__name__)
    raise AssertionError('corruption was accepted at ' + boundary + ': ' + name)


def invoke(command, name, log_root):
    result = subprocess.run(command, cwd=T, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
        capture_output=True, text=True, timeout=300, check=False)
    (log_root / (name + '.stdout.log')).write_text(result.stdout)
    (log_root / (name + '.stderr.log')).write_text(result.stderr)
    assert result.returncode == 0, (name, result.stderr[-2000:])
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--child', choices=sorted(verifier.CONTROL_NAMES))
    parser.add_argument('--execution-name')
    args = parser.parse_args()
    assert __debug__ and args.packet.resolve().is_relative_to(T)
    if args.child:
        print(json.dumps(child(args.packet, args.child), sort_keys=True))
        return
    assert args.execution_name and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    log_root = T / args.execution_name
    assert not log_root.exists()
    log_root.mkdir()
    report, data = verifier.read_archive(args.packet)
    assert data['current/tools/check_rolling_packet_controls.py'] == Path(__file__).read_bytes()
    destination = args.packet / 'corruption-controls.json'
    assert not destination.exists()
    accepted = verifier.identity((args.packet / 'acceptance.json').read_bytes())
    first = invoke([sys.executable, '-B', str(args.packet / 'verify.py'), '--repo-root', str(W)], 'source-bound', log_root)
    assert first['status'] == 'passed_source_bound_replay' and first['query_executions'] == 0
    controls = [dict(name='source_bound', outcome='passed')]
    for name in sorted(verifier.CONTROL_NAMES):
        result = invoke([sys.executable, '-B', str(Path(__file__).resolve()), '--packet', str(args.packet), '--child', name], name, log_root)
        assert result['name'] == name and result['outcome'] == 'rejected'
        controls.append(result)
    with tempfile.TemporaryDirectory(prefix='rolling-control-relocated-', dir=T) as temporary:
        clone = Path(temporary) / 'packet'
        shutil.copytree(args.packet, clone)
        last = invoke([sys.executable, '-B', str(clone / 'verify.py')], 'relocated', log_root)
        assert last == first
    controls.append(dict(name='relocated_source_only', outcome='passed'))
    assert verifier.identity((args.packet / 'acceptance.json').read_bytes()) == accepted
    observations = args.packet / 'control-observations'
    assert not observations.exists()
    shutil.copytree(log_root, observations)
    result = dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES), controls=controls,
        acceptance_manifest=accepted, archives=report['archives'],
        sources={name: verifier.identity(data['current/tools/' + name])
            for name in ('verify_rolling_packet.py', 'check_rolling_packet_controls.py')},
        observations=[dict(path='control-observations/' + path.name, **verifier.identity(path.read_bytes()))
            for path in sorted(log_root.iterdir())])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES)), sort_keys=True))


if __name__ == '__main__':
    main()
