"""Check actual native executable discovery and exact ignored-test ownership."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib

import verify_rolling_diagnostics as diagnostics
sys.path.insert(0, str(diagnostics.ROOT / 'scripts'))
import ci_native_tests as ci
import ci_build_artifact as ci_build
from window_replay import content, digest, read
from query_surface.evidence import identity

BUILD_COMMAND = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
    '--lib', '--features', 'release-user-surfaces', '--no-run']


def main():
    assert __debug__
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert Path(__file__).resolve() == diagnostics.OUT / 'tools/verify_rolling_ci_inventory.py'
    assert args.build.parent == args.output.parent == diagnostics.OUT
    assert not args.output.exists()
    sources = diagnostics.source_inventory()
    _, log = diagnostics.guarded(args.build, BUILD_COMMAND, sources)
    paths = re.findall(r'^\s+Executable unittests src/lib.rs \(([^\n]*shardloom_vortex-[0-9a-f]+)\)$', log, re.MULTILINE)
    assert len(paths) == 1
    binary = Path(paths[0])
    assert binary.parent == Path('/Users/dylan/.cache/shardloom/cargo-target/debug/deps')
    before = identity(binary)
    assert ci_build.PRODUCTS['native-tests'] == ('ci-native', 'shardloom-vortex', ['--lib'], ['release-user-surfaces'])
    cargo = tomllib.loads((diagnostics.ROOT / 'Cargo.toml').read_text())
    assert cargo['profile']['ci-native']['debug-assertions'] is True
    for profile in ('dev', 'test'):
        assert cargo.get('profile', {}).get(profile, {}).get('debug-assertions', True) is True
    subprocess.run([sys.executable, '-B', str(diagnostics.ROOT / 'scripts/test_ci_native_tests.py')],
        cwd=diagnostics.ROOT, check=True, timeout=120)
    tests, ignored = ci.discover(binary), ci.discover(binary, ignored=True)
    baseline_path = diagnostics.ROOT / '.github/ci-native-baseline.json'
    baseline = read(baseline_path)
    partitions = ci.partition_tests(tests, ignored, baseline)
    ci.verify_coverage(tests, partitions)
    name = 'local_primitives::native_relational_window_frame::rolling_distinct::tests::rolling_distinct_candidate_allocated_storage_observation'
    assert len(ignored) == 36 and ignored == baseline['ignored_tests']
    assert tests.count(name) == ignored.count(name) == 1
    assert sum(row['tests'].count(name) for row in partitions) == 1
    for required in diagnostics.REQUIRED_TESTS:
        assert sum(value.endswith('::' + required) for value in tests) == 1
    assert identity(binary) == before
    assert diagnostics.source_inventory() == sources
    files = [Path(__file__), Path(diagnostics.__file__), Path(ci.__file__),
        diagnostics.ROOT / 'scripts/ci_build_artifact.py', diagnostics.ROOT / 'scripts/test_ci_native_tests.py',
        baseline_path, diagnostics.ROOT / 'Cargo.toml', args.build, args.build.with_suffix('.log')]
    result = dict(schema='shardloom.rolling_distinct_ci_inventory.v1',
        status='passed_actual_native_inventory', source_fingerprint_sha256=digest(sources),
        binary=before, test_count=len(tests), ignored=ignored, partitions=partitions,
        discovery_features=['release-user-surfaces'], discovery_profile='debug',
        hosted_ci_profile='ci-native', both_profiles_have_debug_assertions=True,
        attribution_test=name, exact_ignored_ownership=True, query_executions=0,
        files={str(path):content(path) for path in files})
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status', 'test_count', 'exact_ignored_ownership', 'query_executions')}))


if __name__ == '__main__':
    main()
