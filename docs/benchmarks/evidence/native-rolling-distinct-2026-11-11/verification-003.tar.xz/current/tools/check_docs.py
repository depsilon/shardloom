"""Check public references and rolling DISTINCT status against the selected runtime."""
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parents[1]
decision = json.loads((OUT / 'candidate-verified-r1.json').read_bytes())['frozen_rule_disposition']
assert decision in {'retain_candidate', 'drop_candidate_no_gain', 'drop_candidate_invalid_cohort'}
runtime = (OUT if decision == 'retain_candidate' else OUT.parent / 'shared-window-state-2026-11-11') / 'runtime-r1'
commands = [
    ['scripts/write_native_function_reference.py', '--check', '--native-library', str(runtime / 'lib_native.dylib')],
    ['scripts/write_public_api_reference.py', '--check', '--binary', str(runtime / 'shardloom')],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_python_license_bundle.py'],
    ['scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status-docs-r1.json')],
    ['scripts/check_contribution_governance.py', '--output', str(OUT / 'contribution-governance-r1.json')],
]
for command in commands:
    print('Checking ' + command[0], flush=True)
    subprocess.run([sys.executable, '-B', *command], check=True, timeout=120)
