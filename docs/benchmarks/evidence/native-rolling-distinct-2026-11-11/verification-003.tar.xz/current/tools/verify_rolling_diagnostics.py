"""Verify exact allocation, source, regression and failure-preservation evidence.

This reads diagnostic observations and guarded test receipts. It executes no
native queries and makes no throughput or whole-query memory acceptance claim.
"""
import argparse
import copy
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import subprocess

from rolling_common import BASE, OUT, W as ROOT, content, digest, read

FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
FORMAT = ['cargo', 'fmt', '--all', '--', '--check']
CLIPPY = ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
    '--features', FEATURES, '--', '-D', 'warnings']
NATIVE_TESTS = ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked',
    '--workspace', '--all-targets', '--features', FEATURES]
ATTRIBUTION_NAME = 'rolling_distinct_candidate_allocated_storage_observation'
ALLOCATION = ['env', 'SHARDLOOM_DISTINCT_CANDIDATE_OUTPUT=' + str(OUT / 'candidate-allocation-observations-r2.json'),
    'cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features', FEATURES,
    ATTRIBUTION_NAME, '--', '--ignored', '--show-output', '--test-threads=1']
REQUIRED_TESTS = [
    'rolling_distinct_complete_frames_bound_storage_across_exclusions_filters_and_collisions',
    'rolling_distinct_rehash_and_backward_shift_preserve_wrapped_probe_chains',
    'rolling_distinct_collision_control_detects_a_broken_deletion_chain',
    'rolling_distinct_representatives_can_leave_before_the_last_equal_occurrence',
    'rolling_distinct_denied_overlap_and_cancellation_refund_before_fresh_retry',
    'rolling_distinct_eligibility_excludes_other_units_unbounded_and_additive_distinct',
    'rolling_distinct_empty_filtered_and_excluded_frames_do_not_observe_invalid_values',
    'rolling_distinct_native_keys_filters_and_exclusions_match_resident_and_stored_frames',
    'rolling_distinct_finite_following_frames_keep_invalid_unobserved_keys_lazy',
]
CHECKS = {
    'format': ('candidate-format-r2', FORMAT),
    'default_clippy': ('candidate-default-clippy-r1', ['cargo', 'clippy', '--offline', '--locked',
        '--workspace', '--all-targets', '--', '-D', 'warnings']),
    'default_tests': ('candidate-default-tests-r1', ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test',
        '--offline', '--locked', '--workspace', '--all-targets']),
    'native_clippy': ('candidate-native-clippy-r2', CLIPPY),
    'native_tests': ('candidate-native-tests-r1', NATIVE_TESTS),
    'allocation': ('candidate-allocation-r2', ALLOCATION),
}


def source_inventory():
    paths = set()
    for command in (['git', 'ls-files', '--cached', '-z'],
            ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(value for value in subprocess.check_output(command, cwd=ROOT).decode().split('\0')
            if value and not value.startswith(('.git/', 'docs/benchmarks/evidence/',
                'docs/release/evidence/', 'docs/dependencies/evidence/')) and '.git' not in Path(value).parts)
    result = {}
    for relative in sorted(paths):
        path = ROOT / relative
        if path.is_symlink():
            target = os.readlink(path)
            result[relative] = dict(symlink=target, sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        elif path.is_file():
            result[relative] = content(path)
        else:
            assert not path.exists(), relative
            result[relative] = dict(absent=True)
    return result


def validate_guard(record, command, sources):
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['command'] == command and record['cwd'] == str(ROOT)
    assert record['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert record['base'] == record['accepted_baseline_merge'] == BASE
    assert record['fixed_source_validation'] and not record['allow_lockfile_update']
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['query_workload']
    assert record['build_sources'] == sources
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    for stage in ('pre_execution', 'post_execution'):
        item = record['build_source_verification'][stage]
        assert item['head_matches'] and item['path_set_matches'] and not item['changed_paths']
        assert item['fingerprint_sha256'] == digest(sources)
    driver = OUT / 'tools/guard_rolling_distinct.py'
    assert record['driver_sha256'] == content(driver)['sha256']
    assert record['tool_source_inventory'][str(driver)] == content(driver)


def guarded(path, command, sources):
    assert path.parent == OUT and path.name.startswith('candidate-')
    record = read(path)
    validate_guard(record, command, sources)
    assert record['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return record, path.with_suffix('.log').read_text()


def passed_tests(log):
    names = re.findall(r'^test (\S+) \.\.\. ok$', log, re.MULTILINE)
    assert names and not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED\.', log, re.MULTILINE)
    return names


def key(row):
    return tuple(row[name] for name in ('rows', 'width', 'pattern', 'filtered', 'exclusion'))


def final_count(row):
    at = row['rows'] - 1
    positions = range(max(0, row['rows'] - row['width']), row['rows'])
    kept = []
    for position in positions:
        if row['exclusion'] == 'CurrentRow' and position == at:
            continue
        if row['exclusion'] == 'Group' and position // 3 == at // 3:
            continue
        if row['exclusion'] == 'Ties' and position != at and position // 3 == at // 3:
            continue
        if row['filtered'] and (position % 5 == 0 or position % 7 == 0):
            continue
        kept.append(position if row['pattern'] == 'unique'
            else position % (3 if row['pattern'] == 'repeat' else 127))
    return len(set(kept))


def compare_allocation(old, new):
    for role, report in (('baseline', old), ('candidate', new)):
        assert report['schema'] == 'shardloom.rolling_distinct_auxiliary_' + role + '.v1'
        assert report['role'] == 'synthetic_native_frame_owner_diagnostic'
        assert report['query_executions'] == 0 and report['whole_query_memory_claim'] is False
    expected = set(itertools.product((257, 4097, 65537), (1, 8, 65),
        ('unique', 'repeat', 'reappear'), (False, True), ('NoOthers', 'CurrentRow', 'Group', 'Ties')))
    previous = {key(row): row for row in old['records']}
    current = {key(row): row for row in new['records']}
    assert len(old['records']) == len(new['records']) == len(expected) == 216
    assert set(previous) == set(current) == expected
    for identity, row in current.items():
        before = previous[identity]
        for record in (row, before):
            for name in ('rows', 'width', 'max_active', 'complete_outputs_verified',
                    'initial_reserved_bytes', 'retained_reserved_bytes', 'peak_reserved_bytes',
                    'allocation_peak_reserved_bytes', 'state_bytes', 'denied_reservations'):
                assert type(record[name]) is int and record[name] >= 0, name
            assert type(record['filtered']) is bool
            assert record['complete_outputs_verified'] == record['rows']
            assert record['initial_reserved_bytes'] == record['denied_reservations'] == 0
        assert row['hashes'] == 'Mixed'
        assert before['state_bytes'] == 1728 and row['state_bytes'] == 112 and row['bucket_bytes'] == 24
        assert row['max_active'] == before['max_active'] <= row['width']
        maximum = row['max_active']
        capacity, active = row['allocated_buckets'], row['active_entries']
        assert type(capacity) is int and type(active) is int
        assert active == final_count(row) <= maximum
        assert capacity == 0 if maximum == 0 else (
            capacity >= max(8, 2 * maximum) and capacity & (capacity - 1) == 0
            and capacity <= max(8, 4 * maximum))
        assert row['retained_reserved_bytes'] == row['state_bytes'] + row['bucket_bytes'] * capacity
        ceiling = row['state_bytes'] + row['bucket_bytes'] * (max(8, 6 * maximum) if maximum else 0)
        assert row['retained_reserved_bytes'] <= row['allocation_peak_reserved_bytes'] <= row['peak_reserved_bytes'] <= ceiling
    example = (65537, 8, 'unique', False, 'NoOthers')
    assert previous[example]['historical_entries'] == 65537
    assert current[example]['allocated_buckets'] == 16 and current[example]['active_entries'] == 8
    return dict(cases=216, outputs_verified=sum(row['rows'] for row in new['records']),
        fixed_state_bytes=112, bucket_bytes=24, complete_case_coverage=True,
        retained_bucket_bound='M=0: 0; otherwise max(8,4*M)',
        overlapping_bucket_bound='M=0: 0; otherwise max(8,6*M)',
        M='maximum non-null distinct membership of completed frames',
        final_membership_independently_recomputed=True,
        example=dict(identity=list(example), baseline=previous[example], candidate=current[example]),
        whole_query_memory_claim=False, performance_acceptance_claimed=False)


def corruptions(old, new, guard, sources):
    rejected = []
    mutations = [('missing case', lambda x: x['records'].pop()),
        ('duplicate case', lambda x: x['records'].__setitem__(1, copy.deepcopy(x['records'][0]))),
        ('whole query memory claim', lambda x: x.__setitem__('whole_query_memory_claim', True))]
    for field, value in [('allocated_buckets', 131072), ('active_entries', 0), ('max_active', 2),
            ('retained_reserved_bytes', 1), ('peak_reserved_bytes', 1 << 30),
            ('allocation_peak_reserved_bytes', 0), ('complete_outputs_verified', 1),
            ('denied_reservations', 1), ('initial_reserved_bytes', 1)]:
        mutations.append(('wrong ' + field, lambda x, f=field, v=value: x['records'][0].__setitem__(f, v)))
    for label, mutate in mutations:
        value = copy.deepcopy(new); mutate(value)
        try:
            compare_allocation(old, value)
        except (AssertionError, KeyError, ValueError):
            rejected.append(label)
        else:
            raise AssertionError('corruption was accepted: ' + label)
    for field, value in [('status', 'failed'), ('process_group_drained', False),
            ('direct_child_reaped', False), ('fixed_source_validation', False),
            ('build_source_fingerprint_sha256', '0' * 64), ('build_sources', {}),
            ('command', ['cargo', 'test'])]:
        changed = copy.deepcopy(guard); changed[field] = value
        try:
            validate_guard(changed, NATIVE_TESTS, sources)
        except (AssertionError, KeyError, ValueError):
            rejected.append('invalid guard ' + field)
        else:
            raise AssertionError('invalid guard accepted: ' + field)
    assert len(rejected) == 19
    return rejected


def main():
    assert __debug__ and Path(__file__).resolve() == OUT / 'tools/verify_rolling_diagnostics.py'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert args.output.parent == OUT and not args.output.exists()
    sources = source_inventory()
    protocol = OUT / 'baseline-protocol-r1.json'
    assert content(protocol)['sha256'] == '92ff53c6e7f7b93a84420288c38eab070a61e0d3b2994515988b5d2e518fb4dc'
    original = read(protocol)
    bound = {item['path']: dict(bytes=item['generation']['bytes'], sha256=item['sha256'])
        for item in original['runtime_binding']['proof_files']}
    old_path = OUT / 'baseline-allocation-observations-r1.json'
    assert content(old_path) == bound[str(old_path)]
    old = read(old_path)
    guards, logs, files = {}, {}, [Path(__file__), protocol, old_path]
    for name, (stem, command) in CHECKS.items():
        path = OUT / (stem + '.json')
        guards[name], logs[name] = guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    actual = passed_tests(logs['native_tests'])
    for name in REQUIRED_TESTS:
        assert sum(value.endswith('::' + name) for value in actual) == 1, name
    allocation_tests = passed_tests(logs['allocation'])
    assert len(allocation_tests) == 1 and allocation_tests[0].endswith('::' + ATTRIBUTION_NAME)
    assert read(ROOT / '.github/ci-native-baseline.json')['ignored_tests'].count(allocation_tests[0]) == 1
    new_path = OUT / 'candidate-allocation-observations-r2.json'
    new = read(new_path); files.append(new_path)
    allocation = compare_allocation(old, new)
    controls = corruptions(old, new, guards['native_tests'], sources)
    preserved = []
    for stem, status in [('candidate-focused-r1', 'failed'), ('candidate-focused-r2', 'passed'),
            ('candidate-native-clippy-r1', 'failed'), ('candidate-allocation-r1', 'passed')]:
        path = OUT / (stem + '.json'); record = read(path)
        assert record['status'] == status and record['process_group_drained'] and record['direct_child_reaped']
        assert record['log_sha256'] == content(path.with_suffix('.log'))['sha256']
        for expected in record['changed_source_inventory'].values():
            if 'bytes' in expected:
                blob = OUT / 'source-blobs' / expected['sha256']
                assert content(blob) == expected
                files.append(blob)
        files.extend((path, path.with_suffix('.log')))
        preserved.append(dict(name=stem, status=status, source_fingerprint_sha256=record['build_source_fingerprint_sha256']))
    for path in (OUT / 'candidate-allocation-observations-r1.json',
            OUT / 'candidate-native-tests-preflight-refusal-r1.json'):
        assert path.exists(); files.append(path)
    proof = {str(path): content(path) for path in sorted(set(files))}
    assert source_inventory() == sources
    result = dict(schema='shardloom.rolling_distinct_candidate_diagnostics.v1',
        status='passed_candidate_diagnostics', accepted_merge=BASE,
        diagnostic_source_fingerprint_sha256=digest(sources), allocation=allocation,
        rejected_corruptions=controls, required_tests=REQUIRED_TESTS,
        actual_passed_tests=actual, attribution_test=allocation_tests[0], ignored_ci_registered=True,
        preserved_prior_observations=preserved, files=proof,
        checks={name: str(OUT / (stem + '.json')) for name, (stem, _) in CHECKS.items()},
        native_query_executions_during_verification=0, engine_timing_claimed=False,
        candidate_acceptance_claimed=False)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(dict(status=result['status'], allocation_cases=216,
        required_tests=len(REQUIRED_TESTS), rejected_corruptions=len(controls), query_executions=0)))


if __name__ == '__main__':
    main()
