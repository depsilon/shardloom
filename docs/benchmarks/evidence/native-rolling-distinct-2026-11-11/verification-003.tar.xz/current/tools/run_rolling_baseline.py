"""Freeze exact 654-result reuse, then execute only the 436 missing requests once."""
from contextlib import ExitStack, closing
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess

import rolling_common as common
from rolling_common import (BASE, CLIENT, CLOSEOUT, E, FROZEN, OUT, REFERENCE, S, SELECTION,
    T, TREE, W, Cases, accepted_runtime, content, database, digest, load_module, read, replay_case)
import capture_window_cohort as capture
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import request, verify

TARGET = OUT / 'baseline-missing-r1'
PROTOCOL = OUT / 'baseline-protocol-r1.json'
REUSE = OUT / 'baseline-reuse-r1.json'
SAVED = OUT / 'saved-window-controls-r1.sqlite'
WORKER = CLIENT / 'rolling_distinct_worker.py'
PACKET = W / 'docs/benchmarks/evidence/native-shared-window-state-2026-11-11'


def references(stack, selection):
    result = {p: stack.enter_context(database(E / ('reference-' + p) / 'expectations.sqlite'))
        for p in {r['case']['profile'] for r in selection['cases']}}
    result['composition'] = stack.enter_context(database(REFERENCE))
    return result


def case_reference(refs, row, cases):
    c = row['case']; item = cases.item(c)
    ref = refs['composition' if row['kind'] == 'composition' else c['profile']].execute(
        'SELECT identity,value FROM expected WHERE id=?', (c['id'],)).fetchone()
    assert ref and ref[0] == c['case_identity'] == item.identity
    return item, ref, unpack(ref[1])


def context():
    runtime, closeout = accepted_runtime()
    design, inputs, prepared, frozen, historical = common.inputs_and_client()
    inputs = dict(inputs, runtime=runtime)
    selection = read(SELECTION)
    assert selection['selected_requests'] == len(selection['cases']) == 1090
    assert not selection['selection_uses_timing'] and selection['query_executions'] == 0
    assert len({r['case']['id'] for r in selection['cases']}) == 1090
    for i, row in enumerate(selection['cases']):
        assert row['cohort_ordinal'] == i
        if row['kind'] == 'original':
            assert row['case'] == design['cases'][row['original_seq']]
        elif 'rolling_distinct_version' in row['case']:
            common.worker.validate(row['case'])
        else:
            common.old_proof.worker.validate(row['case'])
    reference = read(REFERENCE.parent / 'complete.json')
    assert reference['status'] == 'passed_independent_references'
    assert reference['cases'] == 872 and reference['new_cases'] == reference['reused_control_cases'] == 436
    assert reference['native_query_executions'] == 0 and not reference['native_runtime_loaded']
    assert reference['expected'] == identity(REFERENCE) and reference['input_and_client_hashes_unchanged']
    verify(list(reference['proof'].values()))
    for n, expected in reference['frozen_harness_files'].items():
        assert content(Path(n)) == expected
    declarations = read(OUT / 'client-check-r2.json')
    assert declarations['status'] == 'passed_declaration_and_reference_controls'
    assert declarations['declarations'] == 436 and declarations['query_executions'] == 0
    for n, expected in declarations['sources'].items():
        assert content(Path(n)) == expected
    diagnostic = read(OUT / 'baseline-allocation-observations-r1.json')
    assert diagnostic['query_executions'] == 0 and not diagnostic['whole_query_memory_claim']
    assert len(diagnostic['records']) == 216
    assert all(r['complete_outputs_verified'] == r['rows'] and r['denied_reservations'] == 0
        and r['initial_reserved_bytes'] == 0 and r['state_bytes'] == 1728 for r in diagnostic['records'])
    diagnostic_guard = read(OUT / 'baseline-allocation-r1.json')
    for name in ('baseline-allocation-r1', 'client-preflight-r3', 'references-r1'):
        receipt = read(OUT / (name + '.json'))
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['fixed_source_validation'] and receipt['log_sha256'] == content(OUT / (name + '.log'))['sha256']
    for n in ('native_relational_window_frame_state.rs', 'native_relational_window_distinct_baseline_tests.rs'):
        source = diagnostic_guard['build_sources']['shardloom-vortex/src/local_primitives/' + n]
        assert content(OUT / 'source-blobs' / source['sha256']) == source
    common.old_proof.verify_capture()
    sources = [SELECTION, REFERENCE, REFERENCE.parent / 'complete.json', CLOSEOUT,
        OUT / 'design-r1.md', OUT / 'cohort-design-r1.md', OUT / 'client-check-r2.json',
        OUT / 'baseline-allocation-observations-r1.json', OUT / 'baseline-allocation-r1.json',
        OUT / 'baseline-allocation-r1.log', OUT / 'client-preflight-r3.json', OUT / 'client-preflight-r3.log',
        OUT / 'references-r1.json', OUT / 'references-r1.log',
        S / 'window-tools-draft/capture_window_cohort.py', S / 'window-tools-draft/window_replay.py',
        S / 'window-tools-draft/window_admission.py', T / 'candidate-protocol-r1.json',
        PACKET / 'acceptance.json', PACKET / 'verify.py']
    sources += [OUT / 'tools' / n for n in ('rolling_common.py', 'run_rolling_baseline.py',
        'replay_rolling_baseline.py', 'prepare_rolling_references.py', 'check_rolling_clients.py',
        'plan_rolling_cohort.py', 'guard_rolling_distinct.py')]
    sources += [CLIENT / n for n in ('rolling_distinct_cases.py', 'rolling_distinct_worker.py')]
    proof = [identity(p) for p in sorted(set(sources))]
    unique = {}
    for item in [*frozen, *proof, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values()); verify(frozen)
    return dict(design=design, inputs=inputs, prepared=prepared, runtime=runtime, closeout=closeout,
        selection=selection, frozen=frozen, proof_files=proof, historical=historical)


def verify_saved_reuse(ctx):
    assert not SAVED.exists()
    verifier = load_module('accepted_window_packet', PACKET / 'verify.py')
    accepted, data = verifier.read_archive(PACKET)
    assert accepted['disposition'] == 'retain_candidate'
    member = 'current/candidate-r1/attempts.sqlite'; raw = data[member]
    assert verifier.identity(raw) == dict(bytes=17747968,
        sha256='6db8e8b3713d8b13f07dd76b1dd0ede5c3f1f72fc9a183d71c9b22d76dabc623')
    old_protocol = json.loads(data['current/candidate-protocol-r1.json'])
    assert old_protocol == read(T / 'candidate-protocol-r1.json')
    observed = [json.loads(line) for line in gzip.decompress(data['current/candidate-cases-r1.jsonl.gz']).splitlines()]
    assert len(observed) == 1212
    rows, requests = [], []
    with ExitStack() as stack:
        old = stack.enter_context(closing(sqlite3.connect(':memory:'))); old.deserialize(raw)
        old.execute('PRAGMA query_only=ON')
        saved = stack.enter_context(closing(sqlite3.connect(SAVED)))
        saved.execute('PRAGMA journal_mode=DELETE')
        saved.execute('CREATE TABLE attempt (seq INTEGER PRIMARY KEY,id TEXT NOT NULL UNIQUE,status TEXT NOT NULL,packet BLOB NOT NULL)')
        assert dict(old.execute('SELECT status,count(*) FROM attempt GROUP BY status')) == {'passed': 1212}
        refs, cases = references(stack, ctx['selection']), Cases()
        for selected in ctx['selection']['cases']:
            c = selected['case']; item, reference, expected = case_reference(refs, selected, cases)
            job = request(c, 'native', ctx['inputs'], ctx['prepared'], expected, ctx['design']['execution'])
            declaration = dict(cohort_ordinal=selected['cohort_ordinal'], id=c['id'], case_identity=c['case_identity'],
                request_sha256=digest(job), reference_blob_sha256=hashlib.sha256(reference[1]).hexdigest())
            requests.append(declaration)
            source_seq = selected['saved_window_ordinal']
            if source_seq is None:
                continue
            old_case = old_protocol['cases'][source_seq]
            assert old_case['case'] == c and old_case['cohort_ordinal'] == source_seq
            entry = old.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (source_seq,)).fetchone()
            assert entry and entry[:3] == (source_seq, c['id'], 'passed')
            row = observed[source_seq]; prior = row['provenance']
            assert row['id'] == c['id'] and row['case_identity'] == c['case_identity']
            assert prior['packet'] == verifier.identity(entry[3])
            files = raw_files(unpack(entry[3]))
            assert json.loads(files['one.job.json']) == job
            assert hashlib.sha256(files['one.job.json']).hexdigest() == prior['job_sha256']
            assert prior['independent_expected_blob_sha256'] == declaration['reference_blob_sha256']
            result = replay_case(entry, c, expected, item, ctx['inputs'], ctx['prepared'], ctx['design']['execution'])
            assert result == row['result'] and result['status'] == 'passed'
            saved.execute('INSERT INTO attempt VALUES (?,?,?,?)', entry)
            rows.append(dict(declaration, source_seq=source_seq, packet=prior['packet'], raw_job_sha256=prior['job_sha256'], result=result))
        saved.commit()
        assert saved.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert saved.execute('SELECT COUNT(*) FROM attempt').fetchone() == (654,)
    assert len(rows) == 654 and len(requests) == 1090
    verify(ctx['frozen'])
    return dict(schema='shardloom.rolling_distinct_reuse.v1', status='verified_saved_observations',
        query_executions=0, selected_reused_cases=654, complete_requests_verified=1090,
        accepted_merge=BASE, accepted_tree=TREE, runtime=ctx['runtime'], selection=identity(SELECTION),
        saved=identity(SAVED), original_ledger_member=dict(path=member, **verifier.identity(raw)),
        packet_acceptance=identity(PACKET / 'acceptance.json'), rows=rows, requests=requests,
        all_complete_results_correct=True, all_engine_clocks_valid=True, no_external_fallback=True,
        exact_requests_and_expected_results=True, retired_original_ledger_recreated=False)


def admission(root, require_protocol=True):
    assert __debug__ and root == E
    ctx = context()
    if require_protocol:
        reused = read(REUSE)
    else:
        assert not any(p.exists() for p in (PROTOCOL, REUSE, TARGET))
        reused = verify_saved_reuse(ctx)
        with REUSE.open('x') as f:
            json.dump(reused, f, indent=2, allow_nan=False); f.write('\n')
    assert reused['status'] == 'verified_saved_observations' and reused['runtime'] == ctx['runtime']
    assert reused['selection'] == identity(SELECTION) and reused['saved'] == identity(SAVED)
    missing = [r for r in ctx['selection']['cases'] if r['saved_window_ordinal'] is None]
    assert len(missing) == 436
    binding = dict(schema='shardloom.rolling_distinct_baseline_runtime.v1', role='accepted_baseline_missing_cases',
        accepted_merge=BASE, accepted_tree=TREE, source_root=str(W),
        source_fingerprint_sha256=ctx['closeout']['source_fingerprint_sha256'], accepted_closeout=identity(CLOSEOUT),
        runtime=ctx['runtime'], proof_files=ctx['proof_files'], selection=identity(SELECTION),
        saved_reuse=identity(REUSE), target=str(TARGET), versioned_worker=identity(WORKER),
        original_worker=identity(FROZEN / 'benchmarks/traditional_analytics/query_surface/expanded_worker.py'),
        composition_reference=identity(REFERENCE), frozen_harness_files=65,
        attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.rolling_distinct_baseline_protocol.v1', status='frozen_before_new_queries',
        selected_count=1090, original_controls=218, composed_controls=436, new_distinct=436,
        reused_count=654, missing_count=436, selection=identity(SELECTION),
        candidate_contract=dict(stage='fixed_before_candidate_implementation_and_scoring',
            design=identity(OUT / 'design-r1.md'), cohort=identity(OUT / 'cohort-design-r1.md'),
            eligibility='resident COUNT DISTINCT; ROWS; both bounds finite Count/CurrentRow; all exclusions/filters/native keys',
            retained_bucket_bound='M=0:0; M>0:max(8,4M)', growth_overlap_bucket_bound='M=0:0; M>0:max(8,6M)',
            additional_bytes='separately reserved fixed owner; no whole-query memory bound',
            general_state_and_row_index='unchanged layouts/identity contracts',
            candidate_count=1, tuning='no changed cases, eligibility or constants after scored observations'),
        design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'), frozen=identity(E / 'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=binding, missing_cases=missing, reuse=identity(REUSE),
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        capture_changes=common.old_proof.verify_capture(),
        supervision_change='Accepted window closeout and exact selected archived packets; same workload guard, resources, deadlines, cleanup and query-only inventories.',
        isolation='All other task work and agents idle; no profiling, repeats, warmup, cache manipulation or pacing.',
        performance_decision='All 1090 correct with allocation/ownership/no-fallback gates; strictly lower complete engine sum retains, equal/higher drops.')
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        with PROTOCOL.open('x') as f:
            json.dump(protocol, f, indent=2, allow_nan=False); f.write('\n')
    frozen = [*ctx['frozen'], identity(REUSE), identity(PROTOCOL), identity(SAVED)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, binding


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    # Baseline preparation must finish before candidate source changes.
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=W, text=True).splitlines()
    changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W, text=True).splitlines()
    assert all(n.startswith('docs/') for n in changed), changed
    os.environ['POLARS_MAX_THREADS'] = '2'
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_new_queries', selected=1090, reused=654, missing=436, query_executions=0)))
    else:
        protocol = read(PROTOCOL); capture.TARGET_NAME = str(TARGET)
        capture.observe(E, False, admission, common.previous.HistoricalSubset(),
            [r['case'] for r in protocol['missing_cases']], worker=WORKER, composition_reference=REFERENCE)


if __name__ == '__main__':
    main()
