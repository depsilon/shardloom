"""Admit the single fixed 1090-request release candidate after exact local proof.

No request, worker, reference, capture loop, resource limit or timing rule changes.
Planning binds the release runtime and sources before any candidate request runs.
"""
import argparse
import gzip
import json
import math
import os
from pathlib import Path
import sys

import run_rolling_baseline as baseline
import verify_rolling_diagnostics as diagnostics
from rolling_common import BASE, E, OUT, W, content, digest, read
from query_surface.evidence import identity
from query_surface.expanded_run import verify

TARGET = OUT / 'candidate-r1'
PROTOCOL = OUT / 'candidate-protocol-r1.json'
BASELINE_RESULT = OUT / 'baseline-verified-r1.json'
RUNTIME = OUT / 'runtime-r1'
BUILD = OUT / 'candidate-release-build-r1.json'
DIAGNOSTICS = OUT / 'candidate-diagnostics-r1.json'
CI = OUT / 'candidate-ci-inventory-r1.json'
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
BUILD_COMMAND = ['env', 'PYO3_PYTHON=' + PYTHON, 'cargo', 'build', '--offline', '--locked',
    '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']


def baseline_proof():
    assert content(baseline.PROTOCOL)['sha256'] == '92ff53c6e7f7b93a84420288c38eab070a61e0d3b2994515988b5d2e518fb4dc'
    assert content(BASELINE_RESULT)['sha256'] == '5a4c89c20613ff5ef9ed3aceba275117016a83c8fa7788e6e2ce90e42daade7c'
    design, inputs, frozen, binding = baseline.admission(E)
    protocol, result = read(baseline.PROTOCOL), read(BASELINE_RESULT)
    assert result['status'] == 'passed_complete_baseline_cohort'
    assert result['accepted_merge'] == BASE
    assert result['selected_cases'] == 1090 and result['reused_saved_cases'] == 654 and result['new_attempts'] == 436
    assert result['outcomes'] == {'passed': 1090} and result['new_outcomes'] == {'passed': 436}
    assert result['complete_performance_result_valid'] and result['all_selected_results_correct']
    assert result['all_engine_clocks_valid'] and result['native_no_fallback']
    assert result['primary_clock'] == 'engine_execution_seconds'
    assert not result['complete_10k_performance_claim'] and not result['full43_claim']
    assert result['protocol'] == identity(baseline.PROTOCOL)
    assert result['runtime_binding'] == binding == protocol['runtime_binding']
    assert result['selection'] == protocol['selection'] == identity(baseline.SELECTION)
    verify([result[key] for key in ('case_rows', 'guard', 'complete', 'ledger', 'reuse')])
    selected = read(baseline.SELECTION)['cases']
    with gzip.open(result['case_rows']['path'], 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == len(selected) == 1090
    for ordinal, (row, case) in enumerate(zip(rows, selected, strict=True)):
        assert row['cohort_ordinal'] == ordinal and row['original_seq'] == case['original_seq']
        assert row['id'] == case['case']['id'] and row['case_identity'] == case['case']['case_identity']
        assert row['result']['status'] == 'passed'
        seconds = row['result']['engine_seconds']
        assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
    assert math.fsum(row['result']['engine_seconds'] for row in rows) == result['engine_execution_seconds'] == 310.690303040
    files = [baseline.PROTOCOL, BASELINE_RESULT, baseline.REUSE, baseline.SAVED,
        OUT / 'baseline-cases-r1.jsonl.gz', OUT / 'baseline-replay-r1.json', OUT / 'baseline-replay-r1.log',
        OUT / 'baseline-missing-r1.json', OUT / 'baseline-missing-r1.log',
        OUT / 'baseline-missing-r1/complete.json', OUT / 'baseline-missing-r1/binding.json',
        OUT / 'baseline-missing-r1/attempts.sqlite']
    files.extend(Path(item['path']) for item in binding['proof_files'])
    return protocol, result, design, inputs, frozen, files


def runtime_proof():
    sources = diagnostics.source_inventory()
    build, _ = diagnostics.guarded(BUILD, BUILD_COMMAND, sources)
    report = read(DIAGNOSTICS)
    assert report['schema'] == 'shardloom.rolling_distinct_candidate_diagnostics.v1'
    assert report['status'] == 'passed_candidate_diagnostics'
    assert report['diagnostic_source_fingerprint_sha256'] == digest(sources)
    assert report['native_query_executions_during_verification'] == 0
    assert report['ignored_ci_registered'] and not report['candidate_acceptance_claimed']
    assert report['required_tests'] == diagnostics.REQUIRED_TESTS
    files = [BUILD, BUILD.with_suffix('.log'), DIAGNOSTICS, CI]
    for name, (stem, command) in diagnostics.CHECKS.items():
        path = OUT / (stem + '.json')
        assert report['checks'][name] == str(path)
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    for name, expected in report['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    old = read(OUT / 'baseline-allocation-observations-r1.json')
    new = read(OUT / 'candidate-allocation-observations-r2.json')
    native_guard = read(OUT / 'candidate-native-tests-r1.json')
    assert diagnostics.compare_allocation(old, new) == report['allocation']
    assert diagnostics.corruptions(old, new, native_guard, sources) == report['rejected_corruptions']
    ci = read(CI)
    assert ci['schema'] == 'shardloom.rolling_distinct_ci_inventory.v1'
    assert ci['status'] == 'passed_actual_native_inventory' and ci['exact_ignored_ownership']
    assert ci['query_executions'] == 0 and ci['source_fingerprint_sha256'] == digest(sources)
    assert len(ci['ignored']) == 36 and ci['ignored'] == read(W / '.github/ci-native-baseline.json')['ignored_tests']
    for name, expected in ci['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    checks = {
        'candidate-ci-verification-r1': [PYTHON, '-B', str(OUT / 'tools/verify_rolling_ci_inventory.py'),
            '--build', str(OUT / 'candidate-ci-build-r1.json'), '--output', str(CI)],
        'candidate-diagnostics-verification-r1': [PYTHON, '-B', str(OUT / 'tools/verify_rolling_diagnostics.py'),
            '--output', str(DIAGNOSTICS)],
        'candidate-freeze-runtime-r1': [PYTHON, '-B', str(OUT / 'tools/freeze_runtime.py'),
            '--build', BUILD.name, '--name', 'runtime-r1', '--profile', 'release'],
    }
    for stem, command in checks.items():
        path = OUT / (stem + '.json')
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    freeze = OUT / 'runtime-r1-identity.json'
    record = read(freeze)
    assert record['status'] == 'passed' and record['profile'] == 'release'
    assert record['build_receipt'] == BUILD.name and record['build_receipt_identity'] == content(BUILD)
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    assert record['native_query_executions'] == 0
    members = {Path(item['path']).name: item for item in record['files']}
    assert set(members) == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
    for name, item in members.items():
        assert Path(item['path']) == RUNTIME / name
        assert content(Path(item['path'])) == {key: item[key] for key in ('bytes', 'sha256')}
    assert content(RUNTIME / 'lib_native.dylib') == content(RUNTIME / '_native.abi3.so')
    files.extend((freeze, OUT / 'tools/freeze_runtime.py'))
    return build, files


def context():
    original, result, design, inputs, frozen, files = baseline_proof()
    build, current_files = runtime_proof()
    files.extend(current_files)
    files.extend(OUT / 'tools' / name for name in ('run_rolling_candidate.py',
        'replay_rolling_candidate.py', 'verify_rolling_diagnostics.py', 'verify_rolling_ci_inventory.py'))
    proof_files = [identity(path) for path in sorted(set(files))]
    runtime = dict(binary=identity(RUNTIME / 'shardloom'), library=identity(RUNTIME / '_native.abi3.so'))
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values()); verify(frozen)
    return dict(original=original, result=result, design=design, inputs=dict(inputs, runtime=runtime),
        selected=read(baseline.SELECTION), runtime=runtime, build=build, frozen=frozen, proof_files=proof_files)


def admission(root, require_protocol=True):
    assert root == E and __debug__
    ctx = context()
    binding = dict(schema='shardloom.rolling_distinct_candidate_runtime.v1', role='single_fixed_cohort_candidate',
        accepted_base=BASE, source_root=str(W), source_head=ctx['build']['head'],
        source_fingerprint_sha256=ctx['build']['build_source_fingerprint_sha256'],
        runtime=ctx['runtime'], proof_files=ctx['proof_files'], selection=identity(baseline.SELECTION),
        baseline_protocol=identity(baseline.PROTOCOL), target=str(TARGET),
        original_worker=ctx['original']['runtime_binding']['original_worker'],
        versioned_worker=identity(baseline.WORKER), composition_reference=identity(baseline.REFERENCE),
        frozen_harness_files=65, attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.rolling_distinct_candidate_protocol.v1', status='frozen_before_candidate_queries',
        selected_count=1090, original_controls=218, composed_controls=436, new_distinct=436,
        candidate_contract=ctx['original']['candidate_contract'],
        baseline_protocol=identity(baseline.PROTOCOL), baseline_result=identity(BASELINE_RESULT),
        selection=identity(baseline.SELECTION), design=identity(E / 'design.json'),
        inputs=identity(E / 'inputs.json'), frozen=identity(E / 'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=binding, cases=ctx['selected']['cases'],
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        baseline_observations=dict(reused=654, newly_measured=436, result=identity(BASELINE_RESULT)),
        capture_changes='Unchanged capture loop, workers, requests, references, clocks, guards and cleanup; 1090 fixed requests execute once.',
        supervision_change='Same rolling guard, resource limits and before/after-only full inventories; candidate source/build admission follows complete local validation.',
        isolation=ctx['original']['isolation'], performance_decision=ctx['original']['performance_decision'])
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        assert not PROTOCOL.exists() and not TARGET.exists()
        with PROTOCOL.open('x') as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False); stream.write('\n')
    frozen = [*ctx['frozen'], identity(PROTOCOL)]; verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, binding


def main():
    assert Path(__file__).resolve() == OUT / 'tools/run_rolling_candidate.py'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (OUT, E):
        baseline.capture.require_local_path(path, Path.home(), sys.platform)
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_candidate_queries', selected=1090, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        baseline.capture.TARGET_NAME = str(TARGET)
        baseline.capture.observe(E, False, admission, baseline.common.previous.HistoricalSubset(),
            [row['case'] for row in protocol['cases']], worker=baseline.WORKER,
            composition_reference=baseline.REFERENCE)


if __name__ == '__main__':
    main()
