"""Freeze structural selection and new request identities without loading native code."""
from collections import Counter
import copy
import json
from pathlib import Path

from rolling_common import S, OUT, SELECTION, content, digest, read, worker

assert __debug__ and not SELECTION.exists()
source = S / 'window-cohort-selection-r1.json'
assert content(source)['sha256'] == '78491c156869c70743753d129583ff15ae3378cac13ae0125fcd304bf276921a'
old = read(source)['cases']
controls = [row for row in old if row['kind'] == 'composition' or row['case']['archetype'] == 'window_rolling_sum']
templates = [row for row in old if row['kind'] == 'composition' and row['case']['declaration']['family'] == 'arithmetic']
assert len(controls) == 654 and len(templates) == 218
cases = [dict(cohort_ordinal=index, kind=row['kind'], original_seq=row['original_seq'],
    case=row['case'], saved_window_ordinal=row['cohort_ordinal']) for index, row in enumerate(controls)]
for template in templates:
    for family in ('distinct_original', 'distinct_unique'):
        case = copy.deepcopy(template['case'])
        declaration = case['declaration']
        declaration.update(family=family, source_argument=declaration['argument'],
            functions=['count_distinct'], comparison=dict(ordered=True, integer_and_nulls='exact'))
        if family == 'distinct_unique':
            declaration['argument'] = 'row_id'
        declaration['output_schema'] = [dict(name='row_id', dtype='int64', nullable=False),
            dict(name='count_distinct', dtype='uint64', nullable=False)]
        identifier = digest(declaration)
        case.update(id=f'window_distinct_v1_{family}_{identifier[:16]}', case_identity=identifier,
            family='rolling_' + family, archetype='rolling_' + family, rolling_distinct_version=1)
        worker.validate(case)
        cases.append(dict(cohort_ordinal=len(cases), kind='composition',
            original_seq=template['original_seq'], case=case, saved_window_ordinal=None))
assert len(cases) == len({row['case']['id'] for row in cases}) == 1090
result = dict(schema='shardloom.rolling_distinct_selection.v1',
    status='frozen_structural_selection_before_candidate_or_scoring', selected_requests=1090,
    reused_controls=654, new_requests=436, query_executions=0, selection_uses_timing=False,
    original_selection=dict(path=str(source), **content(source)), generator=content(Path(__file__)),
    fixed_design=content(OUT / 'design-r1.md'), cohort_design=content(OUT / 'cohort-design-r1.md'),
    families=dict(Counter(row['case']['family'] for row in cases)), cases=cases,
    complete_10k_performance_claim=False, full43_claim=False)
with SELECTION.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'selected_requests', 'reused_controls', 'new_requests', 'families')}))
