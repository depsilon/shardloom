"""Collect portable source, allocation and complete-cohort evidence without runtime backups."""
from __future__ import annotations
import argparse
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import tempfile
from verify_rolling_packet import (BASE, CHECKS, DOC_CHECKS, REPLAY_SUPPORT, digest,
    fingerprint, identity, replay_saved, rust_counts, verify, verify_diagnostics, verify_sources)

T = Path(__file__).resolve().parents[1]
WINDOW = T.parent / 'shared-window-state-2026-11-11'
N = T.parent / 'shared-index-metadata-2026-11-10'
S = T.parent / 'shared-operator-state-2026-11-10'
D = T.parent / 'dictionary-execution-repair-2026-11-10'
K = T.parent / 'variant-expressions-2026-11-10'
E = T.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def read(path):
    return json.loads(path.read_bytes())


def collect(execution_name):
    result = read(T / 'candidate-verified-r1.json')
    assert result['selected_cases'] == result['new_attempts'] == 1090
    protocol = read(T / 'candidate-protocol-r1.json')
    candidate_sources = read(T / 'candidate-release-build-r1.json')['build_sources']
    accepted_sources = read(T / 'baseline-missing-r1.json')['build_sources']
    data, locations, external = {}, {}, {}
    predecessor = None

    def prior_packet():
        nonlocal predecessor
        if predecessor is None:
            root = W / 'docs/benchmarks/evidence/native-shared-window-state-2026-11-11'
            spec = importlib.util.spec_from_file_location('accepted_window_packet', root / 'verify.py')
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            predecessor = module.read_archive(root)
        return predecessor

    def mapped(path):
        if path.parent.name == 'source-blobs' and re.fullmatch(r'[0-9a-f]{64}', path.name):
            return 'source-blobs/' + path.name
        if path.is_relative_to(E / 'investigation-original-harness-r1'):
            relative = path.relative_to(E / 'investigation-original-harness-r1').as_posix()
            if relative in REPLAY_SUPPORT:
                return 'protocol-support/' + relative
        for root, prefix in ((T, 'current'), (WINDOW, 'window'), (N, 'index'), (S, 'preparation'),
                (D, 'repair'), (K, 'prior'), (E / 'investigation-original-harness-r1', 'harness'),
                (E, 'frozen'), (W / 'docs/benchmarks/evidence', 'prior-benchmark-packets'),
                (W / 'docs/release/evidence', 'prior-release-packets'), (W, 'source-imports')):
            if path.is_relative_to(root):
                return prefix + '/' + path.relative_to(root).as_posix()
        raise AssertionError('unclassified proof path: ' + str(path))

    def add(path, name=None):
        name = name or mapped(path)
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert name not in data or data[name] == raw
        assert str(path) not in locations or locations[str(path)] == name
        data[name], locations[str(path)] = raw, name
        return raw

    for path in sorted([*T.glob('*.json'), *T.glob('*.log'), *T.glob('tools/*.py'), *T.glob('client/*.py')]):
        if path.name not in (execution_name + '.json', execution_name + '.log'):
            add(path)
    for pattern in ('adversarial-review-*.md', '*correction*.md', '*inventory*.md'):
        for path in sorted(T.glob(pattern)):
            add(path)
    for folder in ('debug-retirement-r1', 'audit-failure-r1'):
        for path in sorted((T / folder).rglob('*')):
            if path.is_file():
                add(path)
    for previous in sorted(T.glob('packet-r[0-9]*')):
        if previous.is_dir():
            for name in ('acceptance.json', 'verify.py'):
                path = previous / name
                if path.is_file():
                    add(path)
    for prefix in ('baseline-missing-r1', 'candidate-r1'):
        for name in ('complete.json', 'binding.json', 'attempts.sqlite'):
            add(T / prefix / name)
    for path in sorted(T.glob('*-cases-r1.jsonl.gz')):
        add(path)
    for row in protocol['runtime_binding']['proof_files']:
        path = Path(row['path']); wanted = dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        if path.parent == WINDOW / 'runtime-r1':
            assert path.name in ('shardloom', 'lib_native.dylib', '_native.abi3.so')
            role = 'accepted_runtime_identity'
        elif (path.is_relative_to(W / 'docs/release/evidence') or path.is_relative_to(W / 'docs/benchmarks/evidence')) and path.name.endswith('.tar.xz'):
            role = 'historical_committed_archive_identity'
        else:
            actual = identity(path.read_bytes())
            if actual == wanted:
                assert identity(add(path)) == wanted
            else:
                # A dropped candidate has restored source/CI files. Archive the
                # exact scored snapshot, while separately proving restoration;
                # never substitute current bytes for a frozen proof identity.
                assert result['frozen_rule_disposition'] == 'drop_candidate_no_gain'
                assert path.is_relative_to(W)
                relative = path.relative_to(W).as_posix()
                assert candidate_sources[relative] == wanted
                assert accepted_sources[relative] == actual
                raw = (T / 'source-blobs' / wanted['sha256']).read_bytes()
                assert identity(raw) == wanted
                name = mapped(path)
                assert name not in data and str(path) not in locations
                data[name], locations[str(path)] = raw, name
            continue
        import hashlib
        with path.open('rb') as stream:
            assert dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest()) == wanted
        external[str(path)] = dict(role=role, identity=wanted)
    add(WINDOW / 'candidate-release-build-r1.json')
    accepted, prior_data = prior_packet()
    prior_protocol = json.loads(prior_data['current/candidate-protocol-r1.json'])
    assert prior_protocol == read(WINDOW / 'candidate-protocol-r1.json')
    inherited_clients = []
    for name in ('shared_window_worker.py', 'shared_window_cases.py'):
        path = S / 'window-client-draft' / name
        rows = [row for row in prior_protocol['runtime_binding']['proof_files']
            if row['path'] == str(path)]
        assert len(rows) == 1
        row = rows[0]
        raw = add(path)
        assert raw == prior_data[accepted['locations'][str(path)]]
        assert identity(raw) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        stat = path.stat()
        assert row['generation'] == dict(device=stat.st_dev, inode=stat.st_ino,
            bytes=stat.st_size, mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)
        inherited_clients.append(row)
    raw = prior_data['current/candidate-cases-r1.jsonl.gz']
    member = next(row for row in accepted['members'] if row['path'] == 'current/candidate-cases-r1.jsonl.gz')
    assert identity(raw) == {key: member[key] for key in ('bytes', 'sha256')}
    data['window/candidate-cases-r1.jsonl.gz'] = raw
    # Bind the retained accepted case rows without recreating its retired ledger.
    locations[str(WINDOW / 'candidate-cases-r1.jsonl.gz')] = 'window/candidate-cases-r1.jsonl.gz'
    for name in ('design.json', 'inputs.json', 'frozen.json', 'native-preparation/complete.json',
            'investigation-original-harness-source-r1.json'):
        add(E / name)
    frozen = read(E / 'frozen.json')
    for row in frozen['references']:
        assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    manifest = read(E / 'investigation-original-harness-source-r1.json')
    for relative, sha256 in manifest['harness_sha256'].items():
        path = E / 'investigation-original-harness-r1' / relative
        assert digest(add(path)) == sha256
        original = [row for row in frozen['harness'] if row['path'].endswith('/' + relative)]
        assert len(original) == 1 and original[0]['sha256'] == sha256
        locations[original[0]['path']] = 'harness/' + relative
    add(S / 'current-baseline-10k-r1/failed-observation-replay-r1.json')
    wanted = {}
    for name, raw in list(data.items()):
        if not name.endswith('.json'):
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        for key in ('build_sources', 'tool_source_inventory'):
            for item in record.get(key, {}).values():
                if 'sha256' in item and 'symlink' not in item:
                    assert item['sha256'] not in wanted or wanted[item['sha256']] == item
                    wanted[item['sha256']] = item
    existing_bytes = {digest(raw): raw for raw in data.values()}
    prior_bytes = {digest(raw): raw for raw in prior_data.values()}
    for sha256, item in sorted(wanted.items()):
        roots = (T, WINDOW, N, S, D, K)
        found = [root / 'source-blobs' / sha256 for root in roots if (root / 'source-blobs' / sha256).is_file()]
        if found:
            raw = add(found[0], 'source-blobs/' + sha256)
        elif sha256 in existing_bytes:
            raw = existing_bytes[sha256]; data['source-blobs/' + sha256] = raw
        else:
            raw = prior_bytes[sha256]; data['source-blobs/' + sha256] = raw
        assert identity(raw) == item
    dispositions = read(T / 'candidate-failure-dispositions-r1.json'); failures = []
    for name, raw in sorted(data.items()):
        if name.startswith('current/') and name.count('/') == 1 and name.endswith('.json'):
            record = json.loads(raw)
            if isinstance(record, dict) and (str(record.get('status')).startswith('failed') or record.get('status') == 'interrupted'):
                key = name.removeprefix('current/'); assert dispositions[key]
                failures.append(dict(receipt=name, identity=identity(raw), disposition=dispositions[key]))
    assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
    build = read(T / 'candidate-release-build-r1.json')
    diagnostics = read(T / 'candidate-diagnostics-r1.json')
    ci = read(T / 'candidate-ci-inventory-r1.json')
    report = dict(schema='shardloom.rolling_distinct_acceptance.v1', status='local_candidate_decision_recorded',
        source_base=BASE, candidate_source_snapshot=build['build_sources'],
        candidate_source_fingerprint_sha256=fingerprint(build['build_sources']),
        checks={name: dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log']))
            for name, command in CHECKS.items()},
        documentation_checks={name: dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log']))
            for name, command in DOC_CHECKS.items()},
        ci_inventory=dict(tests=ci['test_count'], ignored=len(ci['ignored']), partitions=len(ci['partitions'])),
        inherited_window_clients=inherited_clients,
        allocation=diagnostics['allocation'], disposition=result['frozen_rule_disposition'],
        original_failed_checks=failures,
        baseline=dict(cases=1090, reused_saved_cases=654, new_attempts=436, engine_execution_seconds=310.690303040),
        candidate={key: result[key] for key in ('selected_cases', 'outcomes', 'engine_execution_seconds',
            'engine_seconds_saved', 'observed_engine_reduction_percent', 'complete_performance_result_valid')},
        complete_10k_performance_claim=False, full43_claim=False, whole_query_memory_claim=False,
        whole_item_19_complete=False, whole_item_20_complete=False, publication_attempted=False,
        hosted_integration='pending',
        source_policy='Exact validated candidate sources; only named architecture/status prose may advance. A dropped candidate restores accepted source.',
        limitations=[
            'One fixed 1090-case cohort, not a new full10k, Full43, statistical-confidence or superiority result.',
            'Baseline combines 654 exact saved accepted controls and 436 newly measured requests from separate sessions.',
            'The 436 new DISTINCT declarations have independent set references; the 654 unchanged controls retain their exact references.',
            'One candidate execution per case; no repeats, warmup, profiling, cache manipulation or post-score tuning.',
            'Allocation observations cover only the auxiliary resident frame owner, not resident input, peers, output or whole-query memory.',
            'Runtime/input payloads and prior archives have retained identities; no duplicate rollback payload is included.',
            'The original failed 10000-case observation remains invalid and preserved.',
            'Hosted integration, retention, remaining investigations, item19/item20/RFC0044 and CG1through23 remain separate.',
        ], identity_only_proof=dict(sorted(external.items())), locations=dict(sorted(locations.items())),
        members=[dict(path=name, **identity(raw)) for name, raw in sorted(data.items())])
    assert sum(len(raw) for raw in data.values()) < 512 << 20
    return report, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--execution-name', required=True)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--replay-preflight', action='store_true')
    args = parser.parse_args()
    assert args.destination.resolve().is_relative_to(T) and not args.destination.exists()
    assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    assert not args.replay_preflight or args.preflight_only
    report, data = collect(args.execution_name)
    packet = verify_sources(report, data, W)
    if args.preflight_only:
        replay = None
        if args.replay_preflight:
            verify_diagnostics(packet)
            with tempfile.TemporaryDirectory(prefix='rolling-replay-preflight-', dir=T) as temporary:
                replay = replay_saved(report, data, Path(temporary))
        print(json.dumps(dict(status='passed_collection_preflight', query_executions=0,
            logical_files=len(data), logical_bytes=sum(len(raw) for raw in data.values()),
            archives_written=0, replay=replay)))
        return
    stored, assemblies = {}, []
    for name, raw in sorted(data.items()):
        if len(raw) <= 24 << 20:
            stored[name] = raw
        else:
            parts = []
            for ordinal, offset in enumerate(range(0, len(raw), 24 << 20)):
                part = 'parts/' + digest(name.encode()) + '/' + str(ordinal).zfill(4)
                assert part not in stored
                stored[part] = raw[offset:offset + (24 << 20)]
                parts.append(part)
            assemblies.append(dict(path=name, parts=parts, **identity(raw)))
    report['assemblies'] = assemblies
    report['stored_members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(stored.items())]
    groups, group, total = [], [], 0
    for row in report['stored_members']:
        if group and total + row['bytes'] > 48 << 20:
            groups.append(group)
            group, total = [], 0
        group.append(row)
        total += row['bytes']
    if group:
        groups.append(group)
    args.destination.mkdir()
    report['archives'] = []
    for ordinal, group in enumerate(groups):
        path = args.destination / f'verification-{ordinal + 1:03d}.tar.xz'
        with tarfile.open(path, 'w:xz', preset=6) as archive:
            for row in group:
                entry = tarfile.TarInfo(row['path'])
                entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
                archive.addfile(entry, io.BytesIO(stored[row['path']]))
        raw = path.read_bytes()
        assert len(raw) < 64 << 20
        report['archives'].append(dict(path=path.name, members=[row['path'] for row in group], **identity(raw)))
    (args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    shutil.copyfile(T / 'tools/verify_rolling_packet.py', args.destination / 'verify.py')
    del data, stored
    print(json.dumps(verify(args.destination, W), sort_keys=True))


if __name__ == '__main__':
    main()
