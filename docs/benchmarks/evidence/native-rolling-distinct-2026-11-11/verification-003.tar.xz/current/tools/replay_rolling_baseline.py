"""Independently recheck all 1090 exact baseline requests, results and clocks."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_rolling_baseline as current
from rolling_common import Cases, content, database, digest, read, replay_case
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import verify


def capture_receipts(binding):
    done = read(current.TARGET / 'complete.json'); observed = read(current.TARGET / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 436 and done['posthash_verified']
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['updated'] == binding
    assert observed['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(current.TARGET / 'attempts.sqlite')
    assert done['binding']['path'] == str(current.TARGET / 'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    path = current.OUT / 'baseline-missing-r1.json'; guard = read(path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['head'] == guard['base'] == binding['accepted_merge']
    assert guard['active_output'] == str(current.TARGET) and guard['fixed_source_validation']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['accepted_window_closeout']['sha256'] == identity(current.CLOSEOUT)['sha256']
    assert guard['accepted_baseline_source_fingerprint_sha256'] == binding['source_fingerprint_sha256']
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(current.OUT / 'tools/run_rolling_baseline.py')]
    assert guard['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return done, path


def main():
    destination = current.OUT / 'baseline-verified-r1.json'
    records = current.OUT / 'baseline-cases-r1.jsonl.gz'
    partial = current.OUT / 'baseline-cases-r1.partial.jsonl.gz'
    assert __debug__ and not any(p.exists() for p in (destination, records, partial))
    design, inputs, frozen, binding = current.admission(current.E)
    protocol, selection, reuse = (read(p) for p in (current.PROTOCOL, current.SELECTION, current.REUSE))
    done, guard_path = capture_receipts(binding)
    reused = {r['cohort_ordinal']: r for r in reuse['rows']}
    missing = {r['cohort_ordinal']: (i, r) for i, r in enumerate(protocol['missing_cases'])}
    assert len(reused) == 654 and len(missing) == 436 and not set(reused) & set(missing)
    assert set(reused) | set(missing) == set(range(1090))
    prepared = read(current.E / 'native-preparation/complete.json')
    outcomes, new_outcomes, families, values, failures = Counter(), Counter(), defaultdict(list), [], []
    with ExitStack() as stack:
        db = stack.enter_context(database(current.TARGET / 'attempts.sqlite'))
        saved = stack.enter_context(database(current.SAVED))
        assert dict(saved.execute('SELECT status,count(*) FROM attempt GROUP BY status')) == {'passed': 654}
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs, cases = current.references(stack, selection), Cases()
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, (selected, declaration) in enumerate(zip(selection['cases'], reuse['requests'], strict=True)):
            c = selected['case']; item, reference, expected = current.case_reference(refs, selected, cases)
            assert selected['cohort_ordinal'] == declaration['cohort_ordinal'] == ordinal
            assert declaration['reference_blob_sha256'] == hashlib.sha256(reference[1]).hexdigest()
            assert declaration['id'] == c['id'] and declaration['case_identity'] == c['case_identity']
            if ordinal in reused:
                previous = reused[ordinal]; source_seq = previous['source_seq']
                assert source_seq == selected['saved_window_ordinal']
                entry = saved.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (source_seq,)).fetchone()
                ledger_path, origin = str(current.SAVED), 'exact_accepted_window_candidate'
            else:
                source_seq, wanted = missing[ordinal]; assert wanted == selected
                entry = next(entries, None)
                ledger_path, origin = done['ledger']['path'], 'new_missing_baseline'
            assert entry and entry[:2] == (source_seq, c['id'])
            result = replay_case(entry, c, expected, item, inputs, prepared, design['execution'])
            assert result['status'] == entry[2]
            files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
            packet = dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) if entry[3] is not None else None
            job_sha = hashlib.sha256(files['one.job.json']).hexdigest() if files else None
            if files:
                assert digest(json.loads(files['one.job.json'])) == declaration['request_sha256']
            if ordinal in reused:
                assert result == previous['result'] and result['status'] == 'passed'
                assert packet == previous['packet'] and job_sha == previous['raw_job_sha256']
            else:
                new_outcomes[result['status']] += 1
            outcomes[result['status']] += 1
            if result['status'] == 'passed':
                elapsed = result['engine_seconds']
                assert type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0
                values.append(elapsed); families[c['family']].append(elapsed)
            else:
                failures.append(dict(cohort_ordinal=ordinal, id=c['id'], status=result['status'], detail=result.get('failure_detail')))
            output.write(json.dumps(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                kind=selected['kind'], id=c['id'], case_identity=c['case_identity'], family=c['family'],
                profile=c['profile'], surface=c['surface'], native_format=c['native_format'],
                provenance=dict(source=origin, ledger=ledger_path, source_seq=source_seq, packet=packet,
                    job_sha256=job_sha, independent_expected_blob_sha256=declaration['reference_blob_sha256']),
                result=result), separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None
    assert dict(new_outcomes) == done['outcomes'] and sum(new_outcomes.values()) == 436
    assert sum(outcomes.values()) == 1090
    verify([*frozen, done['ledger'], done['binding'], done['frozen'], reuse['saved']])
    partial.rename(records); passed = outcomes == {'passed': 1090}
    result = dict(schema='shardloom.rolling_distinct_baseline.v1',
        status='passed_complete_baseline_cohort' if passed else 'failed_baseline_cohort',
        query_executions_during_replay=0, accepted_merge=current.BASE, accepted_tree=current.TREE,
        selected_cases=1090, reused_saved_cases=654, new_attempts=436,
        outcomes=dict(outcomes), new_outcomes=dict(new_outcomes), attempts_per_case=1, warmups=0, requested_repeats=0,
        primary_clock='engine_execution_seconds', engine_execution_seconds=math.fsum(values) if passed else None,
        complete_performance_result_valid=passed, all_selected_results_correct=passed,
        all_engine_clocks_valid=passed, native_no_fallback=passed, failures=failures,
        families={n: dict(cases=len(v), engine_execution_seconds=math.fsum(v)) for n, v in sorted(families.items())},
        protocol=identity(current.PROTOCOL), selection=identity(current.SELECTION), reuse=identity(current.REUSE),
        complete=identity(current.TARGET / 'complete.json'), ledger=done['ledger'], guard=identity(guard_path),
        case_rows=identity(records), verifier=identity(Path(__file__)), runtime_binding=binding,
        performance_claim=False, complete_10k_performance_claim=False, full43_claim=False,
        limitations=['One observation per exact request; saved controls and new requests occurred in separate sessions.',
            'Fixed 1090-case cohort, not a complete 10k or Full43; original failed 10k remains invalid.',
            'Auxiliary allocation evidence is separate; no whole-query memory bound or statistical confidence claim.'])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'selected_cases', 'outcomes', 'engine_execution_seconds')}))
    assert passed, 'baseline has failed observations; preserve all observations'


if __name__ == '__main__':
    main()
