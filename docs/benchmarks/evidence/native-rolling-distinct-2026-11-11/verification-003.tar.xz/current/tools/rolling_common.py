"""Source-bound preparation helpers; importing this module executes no queries."""
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

OUT = Path(__file__).resolve().parents[1]
S = OUT.parent / 'shared-operator-state-2026-11-10'
T = OUT.parent / 'shared-window-state-2026-11-11'
E = OUT.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
FROZEN = E / 'investigation-original-harness-r1'
CLIENT = OUT / 'client'
SELECTION = OUT / 'cohort-selection-r1.json'
REFERENCE = OUT / 'references-r1/expectations.sqlite'
CLOSEOUT = T / 'shared-window-closeout-r1.json'
BASE = '591fdb42f6ffcd5e9003b4a5c130324d7a34a62c'
TREE = '4674fd245f1a09c84d8aed3226f2dcc01b366dda'
sys.path[:0] = [str(CLIENT), str(S / 'window-tools-draft')]
import window_admission as previous
import window_replay as old_proof
from window_replay import content, database, digest, read
import rolling_distinct_worker as worker
from query_surface.evidence import identity
from query_surface.expanded_run import verify


def accepted_runtime():
    assert content(CLOSEOUT)['sha256'] == '97b80163c9c91d1186acc86522e808fa8563c8d9dd88be9a4ff1b71e316768a0'
    closeout = read(CLOSEOUT)
    assert closeout['status'] == 'complete' and closeout['merge_commit'] == BASE
    assert closeout['source_tree'] == TREE
    assert closeout['pr_checks_passed'] == 58 and closeout['main_checks_passed'] == 55
    assert not closeout['review_findings'] and closeout['portable_replay_after_retirement'] == 'passed'
    assert closeout['current_inputs_unchanged'] and closeout['runtime_sources_match_build']
    for name, expected in closeout['retained_runtime'].items():
        assert content(Path(name)) == expected
    protocol_path = T / 'candidate-protocol-r1.json'
    packet = W / 'docs/benchmarks/evidence/native-shared-window-state-2026-11-11/acceptance.json'
    assert content(packet) == closeout['committed_evidence'][packet.relative_to(W).as_posix()]
    expected = next(row for row in read(packet)['members'] if row['path'] == 'current/candidate-protocol-r1.json')
    assert content(protocol_path) == {key: expected[key] for key in ('bytes', 'sha256')}
    runtime = read(protocol_path)['runtime_binding']['runtime']
    assert runtime['binary']['path'] == str(T / 'runtime-r1/shardloom')
    assert runtime['library']['path'] == str(T / 'runtime-r1/_native.abi3.so')
    assert all(content(Path(row['path'])) == closeout['retained_runtime'][row['path']] for row in runtime.values())
    verify(list(runtime.values()))
    return runtime, closeout


def inputs_and_client():
    return previous.inputs_and_client()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Cases(old_proof.Cases):
    def item(self, case):
        if 'rolling_distinct_version' in case:
            worker.validate(case)
            return SimpleNamespace(identity=case['case_identity'], contract=worker.declarations.contract(case))
        return super().item(case)


def replay_case(entry, case, expected, item, inputs, prepared, policy):
    if 'rolling_distinct_version' not in case:
        return old_proof.replay_case(entry, case, expected, item, inputs, prepared, policy)
    result = old_proof.replay(entry, case, 'native', expected, item, inputs, prepared, policy)
    if result['status'] == 'passed' or result['engine_seconds'] is not None:
        old_proof.verify_clock(entry, result)
    if result['status'] in {'passed', 'incorrect', 'comparison_inconclusive'} and not result.get('delivered_invalid_result'):
        raw = old_proof.raw_files(old_proof.unpack(entry[3]))
        job = json.loads(raw['one.job.json'])
        report = json.loads(raw['one.stdout.json'])['observation']
        assert report['sql_declaration'] == worker.declarations.sql(case, job['sources'])
        assert report['sql_declaration_submitted'] == (case['surface'] in {'cli_sql', 'embedded_workflow', 'python_sql'})
        assert report['execution_mode'] == 'first_query_fresh_session'
    return result
