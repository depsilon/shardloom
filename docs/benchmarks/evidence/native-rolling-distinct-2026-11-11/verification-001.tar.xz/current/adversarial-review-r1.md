# Rolling DISTINCT: primary source and admission review

November 11, 2026, before any scored candidate query. Accepted base:
`591fdb42f6ffcd5e9003b4a5c130324d7a34a62c`. Candidate build-input fingerprint:
`85ff2f22e81409581abb4d6765300428f888cd507a9c7b45010231274e83009d`.
The expert comparator is an exact native moving-window implementation with
credited storage, collision-safe deletion and independently checked results.
This is not a throughput acceptance or hosted integration record.

## Semantics and dispatch

Only resident COUNT DISTINCT with a bound argument and finite ROWS bounds
enters the new owner. Both bounds must be CurrentRow or a preceding/following
Count offset. GROUPS, RANGE, calendar offsets, unbounded frames, additive
DISTINCT and stored/spilled evaluation retain the existing evaluator. The
ordinary resident loop was extracted mechanically: it still computes bounds,
peer/exclusion intervals, output row mapping and writes in the same order.
Shared arithmetic and moment dispatch remain separate and unchanged.

The new owner uses the existing Input filter, null, hash and exact comparator.
It checks the full hash before equality; a hash or a bucket position is never
the value identity. The representative can leave the current frame because the
same immutable resident table remains owned for the entire evaluator. A final
departure closes the probe-chain hole using modular distances, including chains
that wrap around the allocation. There are no escaping bucket identities or
append-only representatives. Existing masked bucket selection is reused so its
conversion remains safe on narrower pointer targets.

All departures across the three disjoint interval slots precede arrivals. Rows
moving between interval slots may be removed and added again, but intermediate
membership remains within the old or new complete frame. Filtered, null or
excluded values do not become members. Rich-key integration covers binary,
decimal, date, timestamp, nested and dictionary text domains, with both order
directions, filters, all exclusions, resident and stored outputs. Following-frame
controls keep invalid unobserved decimal and floating values lazy.

## Allocation, failure and cancellation

The fixed owner and bucket allocation have separate memory credits. Rehash
reserves the replacement while the old allocation is still charged and only
then swaps owners. A successful traversal retains at most max(8,4M) buckets,
with at most max(8,6M) backing buckets during growth, where M is its maximum
completed-frame non-null distinct membership. M=0 allocates no buckets. The
fixed owner is additional. No bound is claimed for the resident input, peer
arrays, output or whole query. A partially failed advance is discarded, not
resumed; its allocations remain subject to the ordinary memory grant.

Lookup, insertion, rehash and backward-shift deletion poll cancellation and
return explicit errors. Occurrence and distinct counts use checked arithmetic.
Denied replacement allocation leaves the old allocation credited; errors and
cancellation drop both partial state and credits. The tests include overlap
denial, cancellation during hashing/comparison, refund and a fresh retry.
Forced full-hash collisions, low-bit collisions, wrapped chains, reappearance
and departed representatives cover the likely deletion mistakes. A deliberate
broken-chain control loses a still-live key and the capacity control rejects
historical-slot retention.

## Proof and frozen throughput admission

The original focused failure was an incorrectly ordered empty interval in a
new test; its receipt and source are retained. Native lint then rejected three
potentially truncating hash casts and test-style issues. Those were corrected
using the existing bucket helper and an extracted independent reference helper;
the failure and final strict-lint pass remain separate observations. The
original 216-case allocation observation also remains alongside its required
post-correction observation.

The baseline contains exactly 654 accepted saved controls and 436 newly
measured DISTINCT requests. The 1,090-case selection, independent references,
workers, source identities and one-call protocol were frozen before candidate
implementation/scoring. Candidate admission separately checks the final test,
allocation, actual CI discovery and release-build source identities. No
post-score case selection, threshold tuning or resource-only override is allowed.
All results and clocks must replay before the complete engine sum determines
retain/drop. Family losses remain visible; prior improvements are not additive.

## Remaining verification

Full native/default tests, final allocation replay and actual CI inventory are
still being completed. Release construction, one isolated candidate pass,
source-bound portable replay, corruption controls, hosted review/checks,
merge/main verification and exact generated-artifact retirement remain. No
fixable semantic or ownership objection was found in this source review. No
whole-query memory, complete 10k, Full43, phase or competitive-gate completion
claim follows.
