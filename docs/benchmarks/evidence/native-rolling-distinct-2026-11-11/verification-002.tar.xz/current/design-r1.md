# Bounded rolling COUNT DISTINCT — fixed first candidate

Prepared November 11, 2026 before candidate implementation or scored execution.
Base: 591fdb42f6ffcd5e9003b4a5c130324d7a34a62c, accepted PR #1679.
This implements recommendation 10 in item 20/RFC 0044. No new phase, API,
provider dependency, source family, spill format or release is authorized here.

## Contract and expert comparator

The review standard is an exact native window implementation with an explicit
allocated-storage proof, adversarial hash deletion checks, complete credited
lifetimes and ordinary end-to-end requests. Live membership alone is inadequate.
Retain general RowIndex stable identities and ordered duplicate chains.

Admit only resident COUNT DISTINCT with ROWS and both bounds selected from
CurrentRow, Preceding(Count), Following(Count). All exclusions, fixed filters,
native key domains, ordering directions and null orders remain supported.
Unbounded bounds, GROUPS/RANGE/calendar, SUM/AVG DISTINCT and stored/spilled
evaluation keep their current implementation. Selection is structural, fixed
before measurement, with no timing-dependent size threshold.

Dispatch once before the ordinary resident frame traversal. Extract that loop
mechanically into a helper taking an advance closure, so bounds, peer discovery,
output mapping, writes and cancellation retain one source of truth. The general
State layout and shared-window family admission remain unchanged.

## Native provider check

Decision: implement_shardloom_kernel inside the existing native frame owner.
Cargo.lock pins Vortex 0.93.0, with the existing vendor/vortex-array patch.
The checked aggregate_fn/fns/mod.rs exposes count and all_non_distinct but no
moving distinct-membership owner with row removal. all_non_distinct is elementwise
array equality with null equality, not a rolling SQL COUNT DISTINCT state.
aggregate_fn/accumulator.rs accumulates arrays and merges partials; that surface
does not provide the required removal, exclusions or ShardLoom memory credits.
Reuse the existing native Input hash_key/compare_key/key_is_null and resident
table ownership. No Arrow executor, external engine or query-engine integration.
Both no-fallback certificate fields remain false. Input/result fidelity and
materialization boundaries do not change.

## Private storage and bound

Use one power-of-two open-addressed bucket vector. A bucket stores the complete
hash, a representative partition position, and a u64 occurrence count; zero count
means empty. No stable entry IDs escape and there is no append-only side vector.
Lookup compares full hash followed by existing native equality. A repeated key
increments its checked count. Final departure deletes the bucket and closes the
probe-chain hole by backward shifting; there are no retained tombstones.
The representative may have left the frame but its immutable native table row
remains owned until this evaluator finishes. Deleting it never releases input.

Start with eight buckets on the first insertion. Grow by doubling only when a
new distinct key would exceed half occupancy. Build and rehash a separately
credited replacement before swapping; charge old plus new backing allocation.
Use ReservedVec, verify its actual capacity guarantee and poll cancellation on
lookup, rehash and deletion. No uncredited allocation or silent admission retry.
On error/cancellation the query drops the whole partial owner; it is not resumable.

Let M be the maximum admitted non-null distinct population of a completed frame.
All departures precede arrivals, retaining the existing validated disjoint
three-interval schedule. During departure membership is a subset of the old
frame; after all departures it is a subset of the new frame, and stays so during
arrivals. Cross-slot moves can remove/reinsert rows without violating that bound.
Thus active membership never exceeds M. For M>0, retained bucket capacity is at
most max(8,4M), and backing overlap during growth at most max(8,6M) buckets.
For M=0 no backing buckets allocate. Add the separately reserved fixed state size.
The exact Bucket size and observed peak must be recorded, not assumed. This is
only an auxiliary state bound; resident input, peers and outputs remain owners.

## Frozen validation and acceptance

Before candidate code, capture baseline auxiliary allocation/slots using current
State and exact source identities. Check long unique partitions with narrow
frames, repeated/reappearing keys, all exclusions, filters/nulls, forced collisions
including wraparound, capacity boundaries, denied growth, cancellation, refund
and retry. Independent set references must check every output. Include empty
frames, exclusion-hidden invalid values and native rich key integration controls.
Candidate capacity/credit assertions must fail for historical-slot retention.
Force collision deletion and mutations/negative controls to demonstrate that
the tests detect a broken probe chain, historical storage or missed removal.

Use a separate predeclared throughput cohort derived from source exposure and
controls, with exact baseline-runtime saved-result reuse and newly measured
missing cases. Freeze request/reference/input/runtime identities before timing.
Run each missing baseline request once and each candidate request once under
the standard isolated supervision and existing limits. No full10k/Full43 rerun,
warmup, repeated trial, cache manipulation or post-score tuning is implied.
Correctness, allocation bound, ownership and no-fallback proof are independent
gates. Apply the standing binary complete-cohort timing rule: strictly lower
engine sum retains, unchanged/higher drops. Preserve family losses and failures.
Any resource improvement remains separately described; do not add #8/#9 savings.

Focused tests precede required default/native format, strict lint, tests, public
route/certificate proof, portable replay and corruption controls. Hosted PR/main
checks, review and verified retirement follow the established user authorization.
No publication or whole-query memory/10k/CG completion claim follows.
