# Rolling DISTINCT throughput cohort, fixed before scoring

Select all 218 original rolling-SUM requests and all 436 arithmetic/moments
compositions from the accepted recommendation-9 selection. These 654 unchanged
requests cover the resident frame traversal extracted by this candidate and the
accepted shared-state paths, across the existing five surfaces and three formats.
Reuse their exact accepted #9 candidate packets after verifying complete request,
reference, source, runtime, result, schema, certificates and engine-clock identity.
No time value participates in selection.

For every one of the 218 arithmetic composition declarations, version two new
requests with one COUNT DISTINCT output: the original observed argument, then
unique row_id. Keep the exact original population, partition/order/frame, format,
surface and output limit. The first lane covers duplicate/null-heavy values; the
second exposes retention over unique history. Preserve source_argument separately
to verify the original source subtree. Use an independent Python set of each
selected frame's non-null values, reading the frozen reference-input rows.

Fixed total: 1,090 requests, comprising 654 exact reused baseline controls and
436 newly measured baseline requests. Each candidate request runs once. Existing
public declarations, complete-result/certificate checks, engine clock, resources,
deadline/process cleanup, exclusive workload and storage supervision stay in use.
No Full43/10k run, repetition, warmup, artificial pacing or cache manipulation.
Unit and native integration tests separately cover every output, exclusions,
FILTER/nulls, rich key types, forced hash collisions, denial and cancellation.

After correctness/resource/ownership gates, the binary decision uses the engine
sum across all 1,090 cases, including controls. Strictly lower retains; otherwise
drop. Preserve all family regressions and original failures. Auxiliary allocation
proof remains separately reported and does not imply a whole-query memory bound.
