"""Fresh public native request for versioned window compositions or unchanged controls.

The original 65-file client is imported without edits. The new execution adapter
uses its public-call, collection, envelope and clock boundaries with composed
declarations. This worker does not implement window computation.
"""
from contextlib import ExitStack
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

S = Path(__file__).resolve().parents[1]
FROZEN = S.parent / 'expanded-query-2026-11-03/investigation-original-harness-r1'
sys.path[:0] = [str(FROZEN / 'scripts'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
sys.path.insert(0, str(S.parent / 'shared-operator-state-2026-11-10/window-client-draft'))
import shared_window_worker as prior_window
import rolling_distinct_cases as declarations
from query_surface import adapters
from query_surface.diagnostics import extract
from query_surface.evidence import no_fallback
from query_surface.semantics import (
    ComparisonLimit, ResultMismatch, TypedResult, compare, result_from_record, result_record,
)
from query_surface.worker import failure, load_native
from query_timing_report import query_phase_timings
from shardloom._result_schema import schema_fields


def validate(case):
    d = case['declaration']
    identity = hashlib.sha256(json.dumps(d, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    if case['rolling_distinct_version'] != 1 or case['window_composition_version'] != 1 or identity != case['case_identity']:
        raise ValueError('composed request identity differs from its declaration')
    if case['id'] != f"window_distinct_v1_{d['family']}_{identity[:16]}":
        raise ValueError('composed request id differs')
    if any(case[key] != d[key] for key in ('profile', 'surface', 'native_format')):
        raise ValueError('composed request source or public surface differs')
    declarations.original_source(case)


def execute(case, sources, surface, *, native, binary, memory_bytes, parallelism, timeout):
    """Collect one complete result through the declared existing public surface."""
    import shardloom as sl
    if surface not in adapters.SURFACES or surface != case['surface']:
        raise ValueError('unknown or mismatched public surface')
    started = time.perf_counter()
    submits_sql = surface in {'cli_sql', 'embedded_workflow', 'python_sql'}
    sql = declarations.sql(case, sources) if submits_sql else None
    files = []
    if surface in {'python_sql', 'typed_relation'}:
        files = [(str(path), adapters.source_format(path), None)
            for name in sorted(declarations.original_source(case).sources())
            for path in adapters._paths(sources, name)]
    with ExitStack() as stack:
        if surface in {'dataframe', 'cli_sql'}:
            client = sl.ShardLoomClient(binary=str(binary),
                transport='subprocess' if surface == 'cli_sql' else 'native',
                use_persistent_worker=False, memory_bytes=memory_bytes,
                max_parallelism=parallelism, timeout=timeout)
            stack.callback(client.close)
            plan = sl.sql(sql, client=client) if surface == 'cli_sql' else declarations.dataframe(case, sources, sl, client)
            constructed = time.perf_counter()
            result = plan.collect(check=True)
            collected = time.perf_counter()
            legacy = {entry.key: entry.value for entry in result.envelope.fields}
            fields = dict(result.envelope.field_map)
            if (len(legacy) != len(result.envelope.fields) or result.envelope.fallback.attempted
                    or any(fields[key] != value for key, value in legacy.items())):
                raise ValueError('ambiguous or unsafe public result envelope')
            schema, rows = result.schema, result.to_rows()
            report = result.envelope.raw
        else:
            session = native.Session(native.ExecutionResources(memory_bytes, parallelism))
            stack.callback(session.close)
            if surface == 'typed_relation':
                plan = session.plan(declarations.native_plan(case, sources, native), files=files)
            elif surface == 'python_sql':
                plan = session.sql(sql, files=files)
            else:
                plan = session.workflow(['sql', '--sql', sql, '--request', 'collect', '--bounded', 'true',
                    '--memory-bytes', str(memory_bytes), '--max-parallelism', str(parallelism)])
            constructed = time.perf_counter()
            result = plan.collect(timeout=timeout)
            collected = time.perf_counter()
            fields = dict(result.report)
            schema = schema_fields(result.schema_json, 'vortex.dtype.serde.v1')
            rows, export = result.row_export(temporal_objects=False)
            report = {'fields': fields, 'row_export': export}
        consumed = time.perf_counter()
        no_fallback(fields)
        clocks = dict(setup_and_declaration_seconds=constructed-started,
            collect_call_seconds=collected-constructed, delivery_seconds=consumed-collected,
            complete_workflow_seconds=consumed-started)
        clocks.update(query_phase_timings(fields, consumed-started, allow_missing=True))
        if sql is None:
            sql = declarations.sql(case, sources)
        return TypedResult(schema, rows), dict(surface=surface, sql_declaration=sql,
            sql_declaration_submitted=submits_sql, fields=fields, raw_report=report, clocks=clocks,
            execution_mode='first_query_fresh_session', diagnostics=extract(fields), complete_consumption=True)


def request(job):
    if job['engine'] != 'native':
        raise ValueError('this investigation permits only native query execution')
    case = job['case']
    if 'rolling_distinct_version' not in case:
        return prior_window.request(job)
    validate(case)
    wanted = result_from_record(job['expected'])
    contract = declarations.contract(case)
    compare(wanted, wanted, contract)
    native = load_native(job['runtime']['library']['path'])
    actual, report = execute(case, job['sources'], job['surface'], native=native,
        binary=job['runtime']['binary']['path'], memory_bytes=job['memory_bytes'],
        parallelism=job['parallelism'], timeout=job['timeout'])
    no_fallback(report['fields'])
    outcome = dict(status='passed', id=case['id'], case_identity=case['case_identity'],
        execution_engine='native', observation=report)
    try:
        outcome['actual'] = result_record(actual)
    except ResultMismatch as error:
        outcome.update(status='incorrect', detail=str(error), invalid_public_result=True,
            observed_rows=repr(actual.rows), observed_schema=repr(actual.schema))
        return outcome
    try:
        compare(wanted, actual, contract)
    except ResultMismatch as error:
        outcome.update(status='incorrect', detail=str(error))
    except ComparisonLimit as error:
        outcome.update(status='comparison_inconclusive', detail=str(error))
    return outcome


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    job = json.loads(args.job.read_bytes())
    try:
        outcome = request(job)
    except Exception as error:
        outcome = failure(error)
        outcome.update(id=job['case']['id'], case_identity=job['case']['case_identity'],
            execution_engine=job['engine'], comparison_engine_invoked=False)
    print(json.dumps(outcome, allow_nan=False, separators=(',', ':')))


if __name__ == '__main__':
    main()

