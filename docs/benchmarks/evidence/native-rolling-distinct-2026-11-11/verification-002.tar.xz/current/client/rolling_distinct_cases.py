"""Versioned bounded COUNT DISTINCT declarations and an independent set oracle.

Draft client code, not a runtime provider. The caller must admit the frozen
original client, inputs and runtime before using these public declarations.
"""
from collections import defaultdict
import heapq

from query_surface import adapters
from query_surface.expanded_catalog import build
from query_surface.semantics import ResultContract, TypedResult
from shardloom._result_schema import ResultType


FAMILIES = {
    'distinct_original': ('count_distinct',),
    'distinct_unique': ('count_distinct',),
}


def original_source(case):
    original, declaration = case['original_case'], case['declaration']
    item = build(original)
    if item.identity != original['case_identity']:
        raise ValueError('original case identity changed')
    if declaration['original_case_identity'] != item.identity:
        raise ValueError('composition is not bound to its original case')
    node = item.relation
    if node.op != 'limit' or node.args != (declaration['output_limit'], 0) or len(node.inputs) != 1:
        raise ValueError('original window limit shape changed')
    node = node.inputs[0]
    if node.op != 'sort' or len(node.inputs) != 1:
        raise ValueError('original window result ordering shape changed')
    node = node.inputs[0]
    expected = ('rolling_sum', declaration['partition'], declaration['source_argument'],
        declaration['order']['descending'], declaration['frame']['preceding'])
    if node.op != 'window_case' or node.args != expected or len(node.inputs) != 1:
        raise ValueError('original rolling window declaration changed')
    if tuple(declaration['functions']) != FAMILIES[declaration['family']]:
        raise ValueError('composition family changed')
    required_argument = (declaration['source_argument'] if declaration['family'] == 'distinct_original' else 'row_id')
    if declaration['argument'] != required_argument:
        raise ValueError('distinct target argument changed')
    source = node.inputs[0]
    if source.sources() != {'fact'}:
        raise ValueError('composition requires the original fact population')
    return source


def names(case):
    return ['row_id', *case['declaration']['functions']]


def contract(case):
    declaration = case['declaration']
    schema = tuple((row['name'], ResultType(row['dtype'], row['nullable']))
        for row in declaration['output_schema'])
    return ResultContract(schema, ordered=True)


def sql(case, sources):
    source = adapters.relation_sql(original_source(case), sources)
    d = case['declaration']
    direction = 'DESC' if d['order']['descending'] else 'ASC'
    frame = (f"PARTITION BY q.{d['partition']} ORDER BY q.row_id {direction} NULLS LAST "
        f"ROWS BETWEEN {d['frame']['preceding']} PRECEDING AND CURRENT ROW")
    outputs = [f"COUNT(DISTINCT q.{d['argument']}) OVER ({frame}) AS {function}"
        for function in d['functions']]
    return (f"SELECT q.row_id AS row_id,{','.join(outputs)} FROM ({source}) AS q "
        f"ORDER BY row_id DESC NULLS LAST LIMIT {d['output_limit']}")


def native_plan(case, sources, native):
    source = adapters.relation_native(original_source(case), sources, native)
    d = case['declaration']
    frame = native.WindowFrame('rows',
        ('preceding', native.FrameOffset.number(native.Expression.literal(d['frame']['preceding']))),
        ('current_row', None))
    outputs = [native.WindowExpression(function, function, source_column=d['argument'],
        partition_by=[d['partition']], order_by=[('row_id', d['order']['descending'], 'last')],
        frame=frame) for function in d['functions']]
    plan = source.window(list(dict.fromkeys(['row_id', d['partition'], d['argument']])), outputs)
    plan = plan.project([(name, native.Expression.column(name)) for name in names(case)])
    return plan.sort([('row_id', True, 'last')]).limit(d['output_limit'], offset=0)


def dataframe(case, sources, sl, client):
    from shardloom import functions as F
    source = adapters.relation_dataframe(original_source(case), sources, sl, client)
    d = case['declaration']
    window = sl.Window.partition_by(d['partition']).order_by('row_id',
        descending=d['order']['descending'], nulls='last').rows_between(-d['frame']['preceding'], 0)
    outputs = [getattr(F, function)(d['argument']).over(window).alias(function)
        for function in d['functions']]
    return source.select('row_id', *outputs).sort('row_id', descending=True, nulls='last').limit(d['output_limit'], offset=0)


def admitted_population(row, scope):
    if scope == 'population':
        return True
    if scope == 'middle_band':
        return 117 <= row['row_id'] < 3217
    if scope == 'flagged':
        return row['nullable_flag'] is True
    if scope == 'rare':
        return row['selection_key'] < 1000
    if scope == 'broad':
        return row['selection_key'] < 350000
    if scope == 'first_4096':
        return row['row_id'] < 4096
    if scope == 'prefix_17':
        return row['row_id'] < 17
    raise ValueError('unknown original population scope')


def reference(case, original_rows):
    """Consume frozen reference-input rows, never ShardLoom result rows.

    Python sets over complete independently selected frame rows do not use the
    native index, rolling-state transitions, range cursor or output finalizers.
    """
    d = case['declaration']
    groups = defaultdict(list)
    ids = set()
    for row in original_rows:
        if not admitted_population(row, d['population']):
            continue
        row_id, value = row['row_id'], row[d['argument']]
        if type(row_id) is not int or row_id in ids:
            raise ValueError('reference row ids must be unique integers')
        ids.add(row_id)
        if value is not None and (type(value) is not int or abs(value) > 2**53):
            raise ValueError('reference input exceeds its declared exact integer domain')
        groups[row[d['partition']]].append((row_id, value))
    selected = set(heapq.nlargest(d['output_limit'], ids))
    results = []
    for group in groups.values():
        group.sort(key=lambda item: item[0], reverse=d['order']['descending'])
        for index, (row_id, _) in enumerate(group):
            if row_id not in selected:
                continue
            observations = [value for _, value in group[max(0, index-d['frame']['preceding']):index+1]
                if value is not None]
            row = dict(row_id=row_id)
            if d['family'] not in FAMILIES:
                raise ValueError('unknown distinct family')
            row['count_distinct'] = len(set(observations))
            results.append(row)
    results.sort(key=lambda row: row['row_id'], reverse=True)
    if len(results) != min(d['output_limit'], len(ids)):
        raise AssertionError('reference did not produce the complete selected result')
    return TypedResult(contract(case).schema, results)

