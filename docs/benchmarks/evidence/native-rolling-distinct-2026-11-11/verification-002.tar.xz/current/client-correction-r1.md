# Pre-execution declaration correction

Source review of local_primitive_relational_window_bind.rs confirmed that
duplicate window pass-through aliases are rejected by validate_unique. The new
unique-row-id lane had listed row_id both as a pass-through identity and as its
argument. The declaration constructor does not bind those aliases, so the first
construction-only check did not catch it. No query has executed.

Deduplicate pass-through aliases while preserving first occurrence. This changes
no frozen case identity, requested output, source population or reference answer.
The SQL and DataFrame declarations, and all 654 reused controls, are unchanged.
The second declaration check captures typed window output columns for every case
and rejects repeated aliases, in addition to the existing constructors and
negative/reference controls. Original client bytes and the original passing
construction receipt remain in the earlier guard's source inventory.
