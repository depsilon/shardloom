//! Allocator ownership of copied native file metadata, separate from input bytes.

use std::sync::Arc;

use shardloom_exec::live_memory::LiveMemoryPool;
use vortex::{
    VortexSessionDefault as _,
    array::{
        IntoArray as _,
        arrays::{PrimitiveArray, StructArray},
        dtype::FieldNames,
        memory::MemorySessionExt as _,
        validity::Validity,
    },
    buffer::ByteBuffer,
    file::{Footer, OpenOptionsSessionExt as _, WriteOptionsSessionExt as _},
    io::{
        runtime::{BlockingRuntime as _, current::CurrentThreadRuntime},
        session::RuntimeSessionExt as _,
    },
    session::VortexSession,
};

fn fixture() -> (Vec<u8>, Footer) {
    let column = PrimitiveArray::from_option_iter([Some(-9_i64), None, Some(17)]).into_array();
    let array = StructArray::try_new(
        FieldNames::from(["metric"]),
        vec![column],
        3,
        Validity::NonNullable,
    )
    .unwrap()
    .into_array();
    let runtime = CurrentThreadRuntime::new();
    let session = VortexSession::default().with_handle(runtime.handle());
    let mut bytes = Vec::new();
    let summary = runtime
        .block_on(
            session
                .write_options()
                .with_metadata_segment("owner-test", ByteBuffer::from(vec![0x5a_u8; 257]))
                .write(&mut bytes, array.to_array_stream()),
        )
        .unwrap();
    (bytes, summary.footer().clone())
}

fn session(memory: &LiveMemoryPool) -> VortexSession {
    VortexSession::default().with_allocator(Arc::new(
        crate::owned_buffers::ReservedHostAllocator::new(memory.clone()),
    ))
}

#[test]
fn native_file_metadata_footer_copies_require_allocator_admission() {
    let (bytes, _) = fixture();
    // The test supplies already-owned bytes, isolating new parser allocations.
    let memory = LiveMemoryPool::new(1).unwrap();
    let error = session(&memory)
        .open_options()
        .open_buffer(bytes)
        .expect_err("a one-byte grant cannot admit copied native footer buffers");
    assert!(crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert_eq!(memory.snapshot().peak_reserved_bytes, 0);
    assert_eq!(memory.snapshot().denied_reservations, 1);
}

#[test]
fn native_file_metadata_explicit_payload_copy_requires_its_receiving_allocator() {
    let (bytes, footer) = fixture();
    // A supplied footer skips parsing and isolates the optional payload copy.
    let memory = LiveMemoryPool::new(1).unwrap();
    let error = session(&memory)
        .open_options()
        .with_footer(footer)
        .include_metadata()
        .open_buffer(bytes)
        .expect_err("a one-byte grant cannot admit a 257-byte metadata copy");
    assert!(crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert_eq!(memory.snapshot().peak_reserved_bytes, 0);
    assert_eq!(memory.snapshot().denied_reservations, 1);
}

#[test]
fn native_file_metadata_schema_and_layout_clones_keep_their_buffer_credits() {
    let (bytes, original) = fixture();
    let memory = LiveMemoryPool::new(4 << 20).unwrap();
    let consumer = session(&memory);
    let file = consumer.open_options().open_buffer(bytes).unwrap();
    assert_eq!(file.footer().dtype(), original.dtype());
    assert_eq!(file.footer().row_count(), 3);
    let dtype = file.footer().dtype().clone();
    let layout = Arc::clone(file.footer().layout());
    drop((file, consumer));
    assert!(
        memory.snapshot().reserved_bytes > 0,
        "schema and layout copies must retain the admitted buffer owners"
    );
    drop(dtype);
    assert!(memory.snapshot().reserved_bytes > 0);
    assert_eq!(layout.row_count(), 3);
    assert_eq!(layout.dtype(), original.dtype());
    drop(layout);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}
