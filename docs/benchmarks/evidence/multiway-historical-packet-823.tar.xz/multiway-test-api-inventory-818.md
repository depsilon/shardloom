# Multiway strategy test API inventory

Bounded read-only source inventory at W HEAD 563c91260a526f6b02ab9bbb171dd9bfb8c4c2f0. No Cargo commands or repository edits.

## 1. Native consumption, cancellation, and output batch size

PreparedVortexRelational::for_each_batch(&self, cancellation: &CancellationToken, consume: impl FnMut(ArrayRef, &NativeExecutionContext<'_>) -> Result<()>) is the native-output consumer API; it forwards the caller token and uses the internal native batch size (local_primitive_prepared_relational.rs:987-1003). The JSON alternative accepts caller batch_rows and max_batch_bytes; it rejects values outside 1..=2,048 rows and 1..=8 MiB (:1066-1102).

streaming_join_nested_aggregate_order_limit_and_native_write_reopen_preserve_complete_values collects exact values with .for_each_json_batch(&CancellationToken::default(), 2, 1 << 20, ...), and varies stream side, spill, and write (local_primitive_relational_batch_join_composition_tests.rs:61-68,82-145).

## 2. Consumer failure, cancellation, memory denial, recovery

- streaming_join_mixed_file_mutation_and_final_consumer_failure_never_complete runs ordinary join composition with spill on/off and forces a final consumer error ("join final consumer failure") or cancels the supplied token from inside the output callback. It asserts error, zero completed executions, and memory returned to baseline (local_primitive_relational_batch_join_composition_tests.rs:181-239).
- streaming_join_spilled_faults_refund_state_and_never_report_completion has an "allocation-probe" case that reserves all but 1 KiB from the active memory grant inside the consumer, then asserts reservation denied, provisional output behavior, zero completed executions, and baseline memory after release (local_primitive_relational_batch_join_fault_tests.rs:110-139,192-240,241-305). The same matrix includes consumer cancellation/error and input/merge cancellation.
- streaming_join_recovery_refuses_live_and_unknown_owners_then_restarts_exactly creates a child execution with live join spill, refuses cleanup while live and when an unknown file is present, then cleans owned state and constructs a fresh prepared join whose complete execution succeeds (local_primitive_relational_batch_join_recovery_tests.rs:68-137). This is fresh preparation/process recovery; no source claim is made that the interrupted execution resumes.
- Resident allocation denial in input construction is explicit: ResidentMemorySource::from_columns documents shared-memory admission failures and validates bounded input (resident_memory_source.rs:240-252); there are input ownership/denial cases in completion_input_foreign_shared_and_untracked_owners_are_denied (local_primitive_relational_batch_input_tests.rs:300-355).

## 3. Numeric, float, and encoded/noncanonical payload construction

The public in-memory scalar column types are Int64, Int64NonNullable, Float64, Bool, Utf8, and TypedJson { dtype_json, values } (resident_memory_source.rs:63-80). ResidentMemorySource::from_columns(session, columns, bounds) copies values into session-owned native arrays; it does not accept an arbitrary prebuilt ArrayRef (:240-278). Batch constructor from_batch_columns is limited to 2,048 input rows (:281-296). Thus ordinary bounded memory fixtures can directly construct signed Int64 and Float64 columns; other numeric DTypes require the documented TypedJson boundary or another source path.

Existing join key-domain examples are built from native Vortex arrays in file fixtures:

- ordered_join_compound_integer_domains_nulls_and_exact_float_boundaries constructs left Int64 keys and right UInt64 keys, adds a nullable UTF8 compound key, and separately tests Int64-vs-Float64 exact-boundary behavior (local_primitive_relational_join_spill_semantics_tests.rs:165-240).
- native_relational_join_null_root_hides_keys_and_payload_before_matching and every_native_join_kind_preserves_duplicates_nulls_order_and_integer_payload_width use PrimitiveArray inputs, including nullable key values (local_primitives/native_relational_join_tests.rs:92-161,245-).

No exact existing multiway join test was found that supplies a deliberately noncanonical/encoded key array through ResidentMemorySource. Its constructors expose scalar column conversion, while a prebuilt-array source constructor was not found (resident_memory_source.rs:63-80,240-296). This is an API/test-evidence boundary, not a claim that the engine cannot scan encoded Vortex files.

## 4. Scan filters, residual filters, Join conditions, spill, one-shot producers

- VortexRelationalScan has URI, projection, and optional PredicateExpr (relational_query.rs:202-208). streaming_replay_preserves_different_scan_projections_filters_and_unused_columns demonstrates two scans with separate projected columns and predicates (local_primitive_relational_batch_replay_tests.rs:121-146).
- A separate public residual plan node is VortexRelationalPlan::Filter(VortexRelationalFilter { input, predicate }); the type documents SQL truth behavior (relational_query.rs:180-185). Example test selector native_relational_on_precedes_null_extension_for_every_join_kind constructs a Join with a keyed ON comparison; native_relational_non_equi_predicate_keeps_unknown_distinct_from_true clears equality keys and uses a residual predicate (local_primitive_relational_join_condition_tests.rs:21-39,41-108,110-129).
- VortexRelationalJoin exposes keys, condition: Option<Expression>, and explicit output columns; condition names use left.<column>/right.<column>, is evaluated before outer null extension, and with no keys defines a non-equi join (relational_query.rs:242-253).
- Join spill is selected with .with_spill(VortexRelationalSpillPolicy::new(path, quota_bytes, run_bytes)?); the composition test compares spill false/true (local_primitive_relational_batch_join_composition_tests.rs:65-68), and prepare_join does the same in the join-fault tests (local_primitive_relational_batch_join_fault_tests.rs:94-103).
- One-shot producer behavior is exercised in streaming_join_either_side_all_kinds_and_mixed_sources_release_each_producer_batch: its callback returns three batches then None, panics on replay, and asserts the callback count for every execution (local_primitive_relational_batch_join_tests.rs:237-239,267-320). The nested-composition selector similarly asserts three calls for two batches plus completion (local_primitive_relational_batch_join_composition_tests.rs:82-109,151-176).
