# Multiway portability inventory (819)

Read-only inventory of the named orchestration, verification, and reference-generation scripts and their local dependencies. Hashes and binding comparisons below retain the time-of-inventory state from Oct 20, 2026; primary integration edits may now have changed those files. No tests, builds, or benchmarks were run for this clerical repair.

## Scripts and dependencies

| Script | SHA-256 | Role |
|---|---|---|
| freeze_multiway_817.py | 4cb546012f4f42f9a4cdd990a1ebc9ffc386a8788ecb9ee06b069a8afddaf6ce | Freezes the 817 source/input manifest and bounded inputs. |
| bind_multiway_818.py | e35a2956798b3eeb403c3b139c4fdd648918dc936084faf304de0f9333a1696e | Binds the 818 source set and executable identity. |
| run_multiway_stage_818.py | c1eddeafad4ac293527a0604b5eb21aa22487d39e1e56cf38bfdf6e72cfd8dcb | Rechecks binding and runs named guarded stages. |
| verify_multiway_intake_817.py | ee1abff2f9ce3c6121b243ccd8948cbfd19976cb74cef4e7eae0af4bd27bf80b | Verifies intake results against the oracle. |
| verify_multiway_screen_818.py | aa108cf6f9c3c71e035e267208355f14c9d800c1cfc357e624cc8649b686ef1a | Verifies screen outputs, values, schemas, counters, and witnesses. |
| generate_multiway_references_818.py | cb7b36e021f4f17bd0c35b07b1188834baf953fa94d1063bea95262813f2106b | Generates eight reference-cell JSON files from the oracle; does not run ShardLoom. |
| run_guarded.py | 68ec416e4fa11cb2d40d48a5f108eb2808f886148e478e8543027837df186be4 | Supervises commands and enforces workload/storage/process guards. |

Supporting inputs: oracle multiway_reference_817.py, SHA-256 7858a4f8b6ed53715ad46a123d1d5f7e2d97c4739ab282f0f297ada6418a35fa; native_workload_guard_816.py, ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76; W/scripts/local_uat_storage.py, 558920fa007e001682f11c2bc3bc2bf34c8ec1af664fec396cf45c8987186a9d; supervisor helper bounded_build_process_resume_20260912.py, 1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97. run_guarded.py inserts a release-script path into sys.path, but local_uat_storage.py was absent there and present under W/scripts. Cargo.lock pins rustc-hash 2.1.3; its registry source lib.rs hash is bed094e995c07565d37f994a0021d6144d236359cf4cdac73e971195a680ebec.

Relevant source hashes recorded at inventory time:

| Source | SHA-256 |
|---|---|
| local_primitive_prepared_relational.rs | 35194dd1d68183ea6c1be81352d0f0526786c54e72a1e647d5a3d12221810f21 |
| local_primitive_relational_multiway.rs | d179cd7ba3443d317f2a0ededf02d905d786383d19d0fca2a47ace806f433d89 |
| local_primitive_relational_multiway_tests.rs | 302b5719566cafe04762c35f23d8de84b056d2925271070016003e576d187fef |
| local_primitive_relational_multiway_screen.rs | a0a613c41d8fdbeeaf5aa9b4f636398f61f32db8dce38af0d5fdbc01e86e51c5 |
| local_primitive_relational_multiway_boundary_tests.rs | 35a7f85a42588abe2637dd9db6bdbab504c50ea8f5fde5e27a9f2bdaa21c8370 |
| native_relational_keys.rs | b3136a468ce703d7df0836ad9bcad641ed5fe038451980919bee193f0bd0a292 |
| native_relational_index.rs | 35fe630ad5b386f5507969fdbd2ae4d5fab1950699be3e1a8dc660fbb003dcab |
| compound_count_partial.rs | 71b98565042e82747675fffdddabed6cfd6f800e9b622faeb55513203090b242 |

## Artifact presence

The 817 intake result JSONL was present (10,150,169 bytes; SHA-256 4d9d2e9eeda010b5139c689c7cab71da6f8fbf52710a6902772ca173f4194f26), with verification output, input manifest, compressed source, receipt, and log. The 818b and 818c manifests, compressed sources, receipts, logs, and bindings were present; each manifest froze 1,906 Rust/Cargo inputs. The 818a references directory contained its manifest and eight cell JSON files. The 819 preflight and cohorts A/B each had invocation records, guarded receipts/logs, result JSONL, verification JSON/receipt/log, and witness directories.

## Binding comparisons at inventory time

The 818c binding had zero mismatches across its direct file map, all 1,906 manifest inputs, and executable identity. The expected/current executable SHA-256 was 1644c272c9102c909bdf0083f9e0818ccb4601c7ff0551688d75f03ecdb63d01.

The 818b binding had two direct-file mismatches, six source-manifest mismatches, and one executable mismatch; no referenced paths were missing. The six source mismatches (binding-declared SHA-256 vs then-current SHA-256) were:

| Source | Binding-declared | Then-current |
|---|---|---|
| local_primitive_relational_multiway_boundary_tests.rs | 382ef92e157497f564cdd80e642eb412e016286b4be8458db020d1ac85ba7721 | 35a7f85a42588abe2637dd9db6bdbab504c50ea8f5fde5e27a9f2bdaa21c8370 |
| local_primitive_relational_multiway_screen.rs | 75ba7db4e6b42156811b0e0265e29d05316a67478824ca601d8e73fc803b94a4 | a0a613c41d8fdbeeaf5aa9b4f636398f61f32db8dce38af0d5fdbc01e86e51c5 |
| local_primitive_relational_multiway_tests.rs | 0c60357fb22b6be19844148f999887c2bd6fe823b27d735bf6b4fa1abb5c46ed | 302b5719566cafe04762c35f23d8de84b056d2925271070016003e576d187fef |
| native_multiway_join.rs | ef910a6eea416b382561380da2ad64243b73277a47d39895e042fe0dce344545 | 725ab2e5a45494b8d2a3fa364e6fd0ed2edff7d341f2969601ee0f4b8edaddfb |
| native_relational_join.rs | 87cd699285ea7f474c7dd343572c7140c5e46da8767592fdda628fb755094d0a | 5b9cdb311c9ef7cd8e000dab83780f6eda34ee8b8b9a846f95d4c71b519dc3e4 |
| native_relational_join_observation.rs | 2377a68c6d31a302b2d55ba8390099081d703f2d5c89a630cfa9eacbd4541531 | c3e14b25109ca042a1465c231684e38c6ba7a882b9b4d6c3e9f759041748d5fe |

The direct-file mismatches were bind_multiway_818.py (declared eb41726503de16699eb30f0b02fe8a6036b8c623a96a2dca07f5dbeca287b980; then-current e35a2956798b3eeb403c3b139c4fdd648918dc936084faf304de0f9333a1696e) and verify_multiway_screen_818.py (declared ec4bb3edd653df7c1bfd37d1749fe550f1bec2e44812b428800558088fc2113e; then-current aa108cf6f9c3c71e035e267208355f14c9d800c1cfc357e624cc8649b686ef1a). The 818b executable declared 248dc299b1ecc51c95810b8d3d2091eb6359a8fd7a90a594728553836727e67a; then-current was 1644c272c9102c909bdf0083f9e0818ccb4601c7ff0551688d75f03ecdb63d01. No historical versions were reconstructed.

## Recorded guard and test outcomes

All inspected receipts reported process_group_drained=true. Passed receipts: fmt-817a, semantic-817a, intake-build-817a, intake-817a, intake-verification-817b, fmt-818a/b/c/d/e/f, check-818b, clippy-818b, probe-build-818b/c, references-818a, preflight-819a and verifier, cohort A/B and verifiers, semantics-819a. Failed receipts: intake-verification-817a, check-818a, clippy-818a, probe-build-818a, semantics-818a.

Recorded selected test summaries: intake-817a, semantic-817a, preflight-819a, and each cohort A/B had 1 passed; semantics-818a had 4 passed, 2 failed, 2 ignored; semantics-819a had 6 passed, 0 failed, 2 ignored. Other inspected logs had no selected test summary. These are recorded artifacts, not fresh executions; this inventory records current-file relationships at the inventory time only.

## 820 acceptance-evidence portability addendum

The machine-readable companion [multiway-portability-inventory-820.json](/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/multiway-portability-inventory-820.json) records full paths, byte lengths, SHA-256 digests, roles, and binding checks for 131 stable source/evidence files. It includes the 819a integration binding and its 25 direct files; all 25 current hashes/lengths match the binding. The 819a input manifest names 1,906 source paths; all 1,906 existed at inspection. That large manifest was checked for path presence, not rehashed in full. No binary or dataset payload was hashed.

The 820a comparison inventory binds all per-stage invocation, result JSONL, guarded run receipt/log, verification receipt/log, and all 18 witness files for preflight, cohort A, and cohort B. The recorded verifiers passed with return code 0, drained process groups, and reaped direct children. Preflight covered 80 queries, 32 workflows, 621,540 output rows, and rejected 20 negative controls. Each comparison cohort covered 304 queries, 112 workflows, 2,361,852 output rows, 18 unique witnesses, and rejected 19 negative controls; both reported quantitative gates passed. These are prior recorded outcomes, not runs performed for this addendum.

The addendum includes multiway_acceptance_common_820.py, multiway_acceptance_820.py, verify_multiway_acceptance_820.py, and the verifier adaptation record, plus the stable helper/provenance files inspected. The separate 820 source-freeze map records 2,227 source paths, all present at inspection; only the two direct runner/storage helper hashes shown in the JSON were rechecked against that map. Thus path completeness is established, while full live-tree hash identity for all 2,227 entries is not claimed. No missing dependency paths were found in the inspected 819 manifest closure.

Historical failure provenance remains visible: intake verification 817a failed and its 817b correction passed; 818a check, clippy, probe build, and semantics attempts failed. The 818b restoration manifest and restoration helper are included to recover the older binder/verifier byte identities. This inventory does not reconstruct or execute those historical scripts.

The 820 acceptance source freeze, native all-tests and integrated-semantics records/logs, and current workspace check artifacts are explicitly excluded from the stable file set because they belong to current-source/final acceptance work. Planned public CLI, Full43, modular, and final integration-gate outputs are listed as pending where absent. Binary artifacts, generated build targets, and benchmark datasets remain unhashed. No repository source was changed, and no build, test, or benchmark was run while preparing this addendum.
