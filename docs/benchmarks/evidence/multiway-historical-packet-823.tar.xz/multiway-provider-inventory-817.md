# PERF-10.multiway_joins: pinned Vortex provider API inventory

Bounded read-only source inventory from registry crates `vortex-array`, `vortex-compute`, `vortex-scan`, and `vortex-mask` version `0.85.0`, all Apache-2.0 (each crate `Cargo.toml:15-16,41`). No builds, tests, benchmarks, or network access.

## Available APIs

**Ordered search.** `vortex_array::search_sorted` is a public module (`vortex-array/src/lib.rs:138`). `SearchSorted<T>::search_sorted(&self, value, side) -> VortexResult<SearchResult>` assumes sorted input and supports left/right insertion positions among duplicates (`search_sorted/mod.rs:131-169,184-216`). The concrete `SearchSortedPrimitiveArray<'a,T>` adapter wraps an `ArrayRef` and mutable `ExecutionCtx`, asserts the array primitive type matches `T`, and implements comparisons for `T`, `Option<T>`, and `usize` (`search_sorted/primitive.rs:15-88`). Its docs specify nullable comparison behavior: use `Option<T>` when nulls exist; nulls sort before non-null values. This source does not establish a general-purpose join index/provider.

**Array filter and take.** Public erased `ArrayRef::filter(mask: Mask) -> VortexResult<ArrayRef>` wraps the input in `FilterArray` and optimizes it; `ArrayRef::take(indices: ArrayRef) -> VortexResult<ArrayRef>` wraps input/indices in `DictArray` and optimizes (`vortex-array/src/array/erased.rs:249-257`). These are array operations, not relational joins. The cited surface alone does not promise a no-materialization execution mode or a particular physical output representation.

**Patch-array filter/take.** `Patches::filter(mask, ctx)` filters patch indices/values, with mask-length validation and `All`/`None` fast cases (`vortex-array/src/patches.rs:631-660`). `take_with_nulls` and `take` dispatch between map and search according to patch-count / take-index-count ratio (`:766-820`); `take_search` is exposed on `Patches` (`:823+`). This is patch maintenance, not row-key join support.

**Mask intersection.** Public `Mask::intersect_by_rank(&self, mask) -> Mask` requires `self.true_count() == mask.len()` and intersects a rank-space mask into the original set-bit positions (`vortex-mask/src/intersect_by_rank.rs:462-480`). It is not ordinary same-row-position boolean AND: the second mask indexes the true values of the first. `Mask::from_indices` requires sorted, unique indices (mask `lib.rs:195-214`). The mask crate module containing the method is private, but the public inherent method on exported `Mask` is visible from the crate.

**Scan selection.** `vortex-scan::Selection` supports all rows, sorted unique include/exclude indices via `StrictSortedBuffer<u64>`, and roaring include/exclude sets; `row_count` and `row_mask(range)` produce range-local masks (`vortex-scan/src/selection.rs:16-105`). `StrictSortedBuffer::try_new` checks strict increasing order and `new_unchecked` leaves that invariant to the caller (`strict_sorted_buffer.rs:12-43`). Scan crate docs describe projection/filter/limit pushdown and partitions, and note the API is under development (`vortex-scan/src/lib.rs:6-21`). These are scan-selection primitives, not a multi-relation join provider.

**Compute crate.** `vortex-compute` 0.85.0 publicly exposes `lane_kernels`; its crate documentation describes lane-level mask-aware map kernels and says additional kernels will land here (`vortex-compute/src/lib.rs:4-14`). No join/intersection/take/filter relational operator export is present in that crate root.

## Multiway/join export search scope and limitation

Searched all Rust source files under the four exact registry directories `vortex-array-0.85.0/src`, `vortex-compute-0.85.0/src`, `vortex-scan-0.85.0/src`, and `vortex-mask-0.85.0/src` for case-insensitive `hash.?join`, `sort.?merge.?join`, `multiway.?join`, `pub.*join`, and `fn join`, and separately inspected public crate roots and the ordered-search/filter/take/intersection APIs above. No join or multiway-join provider export or implementation was found in this bounded scope. Matches such as `StructFields::disjoint_merge` and comments mentioning disjoint sets are not join operators. This is only a statement about the named crate sources, not all Vortex workspace crates.

## SHA256 manifest

| Source file | SHA256 |
|---|---|
| `vortex-array-0.85.0/Cargo.toml` | `e1d57e78490aca0d9535bbc73a3ae4e0a10572a9728bf69424f29cade49c54e4` |
| `vortex-compute-0.85.0/Cargo.toml` | `f7631233188950ba12a10a63e3d25c9a05e19a9e30d7f99a10ca951dbeeea3dd` |
| `vortex-scan-0.85.0/Cargo.toml` | `f1cae4cf05e0435cfd39ec6ed2c6c3dd99cca277c7036c3da2de92db8932b7c3` |
| `vortex-mask-0.85.0/Cargo.toml` | `69ff472b2343741ede0a0e8e7b0867065b679057e7a38b38f57f23256ba43181` |
| `vortex-array-0.85.0/src/lib.rs` | `b2eea0909e633430f878b7c6e0424d2d193bc33cd92961cee2727306a138281a` |
| `vortex-array-0.85.0/src/search_sorted/mod.rs` | `f3ddd04062554c833c32ef44413bd973eb97de9982c68d9bafa9764308260eb2` |
| `vortex-array-0.85.0/src/search_sorted/primitive.rs` | `c4d0713fc216e973b3d55b7334cbb1db34aa3199bdeb144c70cb4408a47479ab` |
| `vortex-array-0.85.0/src/array/erased.rs` | `8b56dfe595612f8981b2a3ba4a1bebc9c4dce51a406d235f48aeb37478efec98` |
| `vortex-array-0.85.0/src/patches.rs` | `b1c823f6563eb138f53e9fbe4d183d82f2d6750b54fc470898fd69bb1a85d4e9` |
| `vortex-mask-0.85.0/src/lib.rs` | `ded4355a9eeef30d18ece5b8876676238d6d61478fe9885b5859b94f2fd0c74e` |
| `vortex-mask-0.85.0/src/intersect_by_rank.rs` | `6607e95d26e251f703e196cd6ecf881715d778c5a717cd9fddb634c9c2efa34d` |
| `vortex-scan-0.85.0/src/lib.rs` | `fe5e6853416488e80627aa8365e04d3c9569ee83879dd3024f8158a83c9ac825` |
| `vortex-scan-0.85.0/src/selection.rs` | `4f37aef4edc8e51afa4ac76ce36a3832f3b6a6ae13508ba46f59e8a57c58e759` |
| `vortex-scan-0.85.0/src/strict_sorted_buffer.rs` | `261be9563e1a9c62258ed38df9b7de452ab6978d58c91f131f4e6b87536bd9a4` |
| `vortex-compute-0.85.0/src/lib.rs` | `e2623438de9fa4dde1bb45ee9bf513c55c91692ec097a7efc1084d7e5f05e579` |
