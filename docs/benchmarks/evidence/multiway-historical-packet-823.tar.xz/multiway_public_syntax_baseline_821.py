"""Check supported nested SQL on the preserved pre-projection normal binary.

This is a functional diagnostic and ordinary-path control, not acceptance of
the later runtime or a new performance observation.
"""
import hashlib
import json
from pathlib import Path
import subprocess

E = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
OUT = E / 'multiway-public-syntax-baseline-821'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    build_path = E / 'multiway-acceptance-build-820.json'
    build = json.loads(build_path.read_text())
    assert sha(build['binary']) == build['binary_sha256']
    assert sha(build['source_manifest']['path']) == build['source_manifest']['sha256']
    for value in build['build_receipts'].values():
        receipt = json.loads(Path(value['receipt']['path']).read_text())
        assert sha(value['receipt']['path']) == value['receipt']['sha256']
        assert receipt['status'] == 'passed' and receipt['process_group_drained']
    sources = {
        'r': [[1, 5, 0], [2, 5, 1], [1, 5, 2], [None, 5, 3], [1, None, 4]],
        's': [[5, 9, 0], [5, 9, 1], [5, 10, 2], [None, 9, 3]],
        't': [[1, 9, 0], [2, 10, 1], [1, 9, 2], [None, 9, 3]],
    }
    bindings = {'memory://' + name: {'input_format': 'memory', 'memory_input': {
        'kind': 'rows', 'schema': [[key, 'int64'] for key in ('x', 'y', 'id')],
        'rows': [[None if value is None else str(value) for value in row] for row in rows],
    }} for name, rows in sources.items()}
    expected = [dict(rid=r, sid=s, tid=t) for r, s, t in (
        (0, 0, 0), (0, 0, 2), (0, 1, 0), (0, 1, 2), (1, 2, 1),
        (2, 0, 0), (2, 0, 2), (2, 1, 0), (2, 1, 2))]
    OUT.mkdir(exist_ok=False)
    records = []
    for surface in ('sql', 'python', 'dataframe', 'cli'):
        for lower in ('INNER', 'LEFT'):
            for condition in ('q.a = t.x AND q.c = t.y', 't.y = q.c AND t.x = q.a'):
                statement = ("SELECT q.rid AS rid,q.sid AS sid,t.id AS tid FROM "
                    "(SELECT r.x AS a,s.y AS c,r.id AS rid,s.id AS sid FROM 'memory://r' AS r "
                    f"{lower} JOIN 'memory://s' AS s ON r.y = s.x) AS q "
                    f"INNER JOIN 'memory://t' AS t ON {condition}")
                command = [build['binary'], 'run', surface, '--sql', statement,
                    '--source-bindings', json.dumps(bindings), '--request', 'collect', '--bounded', 'true',
                    '--memory-bytes', str(64 << 20), '--max-parallelism', '1', '--format', 'json']
                result = subprocess.run(command, capture_output=True, timeout=30)
                name = str(len(records)).zfill(2)
                (OUT / (name + '.stdout.json')).write_bytes(result.stdout)
                (OUT / (name + '.stderr.txt')).write_bytes(result.stderr)
                assert result.returncode == 0, (command, result.stdout.decode(), result.stderr.decode())
                envelope = json.loads(result.stdout)
                assert envelope['status'] == 'success'
                assert envelope['fallback']['attempted'] is envelope['fallback']['allowed'] is False
                fields = {row['key']: row['value'] for row in envelope['fields']}
                assert len(fields) == len(envelope['fields'])
                assert fields['relational_multiway_join_stages'] == '0'
                assert fields['external_engine_invoked'] == 'false'
                assert [json.loads(row) for row in fields['result_jsonl'].splitlines()] == expected
                records.append(dict(command=command, stdout_sha256=sha(OUT / (name + '.stdout.json')),
                    stderr_sha256=sha(OUT / (name + '.stderr.txt')), complete_rows=9, selected_stages=0))
    assert sha(build['binary']) == build['binary_sha256']
    report = dict(status='passed', role='ordinary_pre_projection_normal_binary',
        build=build_path.name, build_sha256=sha(build_path), binary_sha256=build['binary_sha256'],
        complete_queries=16, records=records, performance_observation=False,
        later_projection_runtime_accepted=False, driver_sha256=sha(__file__))
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'role', 'complete_queries')}))


if __name__ == '__main__':
    main()
