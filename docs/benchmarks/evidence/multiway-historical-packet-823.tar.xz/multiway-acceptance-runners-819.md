# Acceptance runner inventory for the multiway integration

Read-only inventory made while the multiway implementation was building. It describes the latest accepted native Python/Public39/Full43/modular machinery available for reuse. That acceptance applies to the historical output-window source snapshot only. It does not accept the current multiway source or current build.

## Contract and latest usable packet

The controlling documents are W/docs/architecture/native-output-window-integration-2026-10-19.md and W/docs/architecture/native-roadmap-verification-contracts-2026-10-18.md, sections PERF-10 and PERF-12. The integration doc records an isolated wheel proof (111 native binding tests, no skips), Public39 (5,930 cases in 39 families), Full43 (43 queries once, 381 rows/schemas, 50.102590495 seconds engine time), and all 18 modular cohorts. It cautions that this was one accepted finite workflow, not a comparative engine speedup or all-platform certification.

The closest source of truth is the retained output-window packet:

| Evidence | Path | SHA-256 |
|---|---|---|
| Portable packet | W/docs/benchmarks/evidence/output-window-accepted-791.tar.xz | d831568d8e6ed50035857637c42634ce68df65db9a4e5b8e639c5da92f80db10 |
| Packet manifest | W/docs/benchmarks/evidence/output-window-accepted-791-manifest.json.xz | 6dbc1c8a66e985b6b3f91e3c6eb828e0cd21f2cf777947cd8da1cb9bf3b22541 |
| Packet verification | W/docs/benchmarks/evidence/output-window-accepted-packet-verification-791.json | c9b162bb640ee8b98e865d48520f1547538406b1e8c1344758bb73bd1fb4a486 |

The archive includes members under evidence/ such as output_window_acceptance_789.py, verify_output_window_acceptance_789.py, output_window_modular_runner_789.py, finalization and verification records, and historical repo/scripts runners. The members can be listed or read directly from the tar.xz; the archive need not be unpacked into the source checkout. A prior accepted native roadmap UAT packet is split across docs/benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.part01.tar.xz through part03.tar.xz, with a compressed manifest. It contains helpers/local/prepare_roadmap_fresh_launch_663.py and helpers/local/verify_roadmap_fresh_uat_663.py, plus runtime-source/scripts/run_clickbench_query_uat.py and scripts/prove_native_python_wheel.py. These are provenance/recovery sources for the older UAT, not new current-source acceptance.

## Exact historical source, build and runner identities

The output-window acceptance source manifest is E/output-window-acceptance-source-789.json (369,188 bytes; SHA-256 72b0eb07b2eccdbd40057fb8a53bdfaa696d98daf53521d6125fea1f07160349); build manifest is E/output-window-acceptance-build-789.json (375,848 bytes; SHA-256 ad8485523142f685b438ecf6fa69abe8936c74ce8996c8f006a24ce61374927b); plan is E/output-window-acceptance-plan-789.json (SHA-256 f760e8cd4c868207961d54450992def27fbf91271dbb44b97870516546a887fd). The final acceptance record is E/output-window-final-acceptance-791.json. It binds source commit f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6 plus its recorded tracked patch and ten added files; the commit alone does not recreate the accepted files. The packet has the exact source bridge and patches.

| Runner/source path | SHA-256 at inspection | Use |
|---|---|---|
| E/output_window_acceptance_789.py | 11789d1762f207fa096a665fded14898a530a3ddd91d057cbb7baa9752c838ce | Historical orchestrator phases source/build/wheel/plan/public/full43/modular/verify. |
| E/verify_output_window_acceptance_789.py | 7562428f45e47fe88bc883cb5fe6bcb4b945dcc4bb5f509aaa4fe587b6e1adef | Reopens Public39, Full43, and modular results against frozen evidence. |
| E/output_window_modular_runner_789.py | 695a93becd163917db332fce6c0288bee7686b6bf66449c39284ed83c39b34f0 | Historical 18-cohort format/workflow driver. |
| W/scripts/run_native_streaming_input_uat.py | 0be6e0fb653e7aa04ca8b3d4b4f5e3e34bf4fd500b93802f7db5b7e356df3c2b | Public matrix runner. |
| W/scripts/run_clickbench_query_uat.py | 7d22f4ae6022c6b3f931eeae9f2acb47271fc1b6755f66838b76669e01d64da3 | Full43 query UAT runner. |
| W/scripts/run_native_relational_suite.py | ed19ad854497f489b75a04949544cc0301a4ed5dbcf5d87589e5dfa0ab82a824 | 18-cohort modular suite machinery used by the surrounding runner. |
| W/scripts/prove_native_python_wheel.py | 8e308394dbdca2185bc5a8bb4cc1cddba3a33de91050744d33be0eb44161952d | Stages/builds a wheel, installs in a new isolated environment, runs binding tests, then uninstalls and verifies cleanup. |
| W/scripts/run_clickbench_ingest_uat.sh | 989536c4e07c9208819feadbe479a05f170ed8c23d2e27d3f79f71f993cb3c47 | Guarded replacement ingestion runner. The accepted output-window Full43 reused an existing Vortex input and did not rerun ingestion. |

The output-window CLI build receipt records this exact Cargo invocation:

```sh
/Users/dylan/.cargo/bin/rustup run 1.99.0 cargo build --release --offline --locked -p shardloom-cli --features release-user-surfaces --message-format=json-render-diagnostics
```

The guarded build environment recorded CARGO_TARGET_DIR=/Users/dylan/.cache/shardloom/cargo-target, CARGO_BUILD_JOBS=2, CARGO_INCREMENTAL=0, CARGO_PROFILE_DEV_DEBUG=0, and CARGO_PROFILE_TEST_DEBUG=0. The acceptance wrapper also verifies a fresh release CLI artifact under Cargo's resolved target directory and independently builds/copies the release Python extension. Historical CLI at E/artifacts/output-window-public-789/shardloom was 7e4b1439f85ddbb100c1906e228e8782b47dd4c2e8aa102f77a88abdf3a891b0; extension at the same directory/_native.abi3.so was cb9d705b1ed1417e8a3df8a79840d7a3886c21db37d5e65c9d01d9df2bf192b1. These are old-source outputs, not suitable as binaries for the in-progress source.

## Python wheel isolation recipe and proof outputs

The retained phase command is:

```sh
/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python -B /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/output_window_acceptance_789.py wheel
```

That wrapper calls W/scripts/prove_native_python_wheel.py with the repo root, a new output directory E/output-window-installed-python-789, the freshly built native library and CLI, and the local wheelhouse /Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-wheelhouse-267. The proof requires non-symlink inputs and a new output directory; builds the wheel with pip wheel --no-build-isolation --no-deps --no-index; creates a fresh venv; installs only hashed, binary optional-consumer requirements from the wheelhouse with pip --no-index --find-links --only-binary=:all: --require-hashes; installs the new wheel with --no-index --no-deps; loads it with isolated Python (-I) while checking native-library/CLI identities; runs python/tests/test_native*binding.py via unittest discovery; uninstalls shardloom; and asserts the package and installed native paths are gone. Ambient PYTHONPATH/PYTHONHOME and ShardLoom selection variables are stripped. Do not reuse the old venv or wheel as proof for new sources.

The historical phase passed: 111 tests, zero skips, successful uninstall. Its proof report is E/output-window-installed-python-789/report.json (SHA-256 db4010b988c6062babb8ff06f5a244b92f8551988bdebea114c8e3264e847a80); integration summary is E/output-window-installed-python-789/integration.json (d96476f768e4bf10075c6c86358c2ad3127c5a09a5b85deb413634f0a12c7e89); wrapper receipt E/output-window-installed-python-789.json is SHA-256 8a66cb77036acc6ba661c7cea5c1adb0107419381f1887e50af493902e55c3ba. Wheel and venv files are currently present under that output directory, but are from the old source. For another proof, use a fresh output path and regenerated inputs.

## Public39, Full43 and modular commands

The exact argv arrays, execution directories, source/binary binding, and outputs are preserved in E/output-window-acceptance-plan-789.json and each runner record. These command records are historical, not launch instructions for the current build.

Public39 command record: E/output-window-public-789.json (SHA-256 81f4a8766b21a750e8ece4c411be2e463cb98f735b876ddd361cb5056101adeb), status passed. Its exact command runs the configured Python 3 interpreter with -B scripts/run_native_streaming_input_uat.py --binary E/artifacts/output-window-public-789/shardloom --uat-root E/output-window-public-789 --operation-timeout 600 --compress-logs --families followed by the 39 frozen family selectors in the plan. Public verifier command is the same configured Python with -B E/verify_output_window_acceptance_789.py public. Final verification reports 5,930 cases, 39 families, 8,151 no-fallback envelopes, and 16,389 logs reopened. Verified output E/output-window-acceptance-public-verified-789.json is 4,909,659 bytes, SHA-256 623ab20f5a605f3adadfd7ca3021cd463ec479622f5a14832136d99306937a62.

Full43 exact command:

```sh
/opt/homebrew/opt/python@3.13/bin/python3.13 -B scripts/run_clickbench_query_uat.py --binary /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/artifacts/output-window-public-789/shardloom --input /Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex --uat-root /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/output-window-full43-789 --reference-packet /Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json --build-commit f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6 --memory-gb 24 --max-parallelism 12 --repeats 1 --compress-logs --max-log-mib 1024 --max-run-log-mib 256
```

The query verifier is /Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/verify_output_window_acceptance_789.py full43. Runner record E/output-window-full43-789.json is SHA-256 34bf51619f5385c4c60582efa599caddda4335faa0778cf92ece0b0b2cfa5e96; verified results E/output-window-acceptance-full43-verified-789.json SHA-256 f3ae589e75610d52fb0abb758248e6ffcbfea50e1c4e1e9330430202ad629baa. Full43 executed 43 queries once, verifying 381 result rows, schemas and native certificates. Routine timing is engine time only.

Modular command record E/output-window-modular-789.json (SHA-256 757bad995f050109b9ed80cdaeffd23d6f505daef2981848a92c3bd6446e2425), status passed:

```sh
/usr/bin/env PYTHONPATH=/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/python-deps /Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/output_window_modular_runner_789.py --repo /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo --build-manifest /Users/dylan/LocalData/shardloom/conditional-investigations-20261019/output-window-acceptance-build-789.json --prefix output-window --attempt 789
```

The modular verifier is the same configured Python with -B E/verify_output_window_acceptance_789.py modular. Verified results E/output-window-acceptance-modular-verified-789.json SHA-256 7833d6b038345b652ec8a12e9ae749ed5d32ab7319c56e64cb422a92720759b9. The run covered 18 cohorts and 704 native workflows against 704 freshly computed independent oracle records.

## Data and what remains reusable

At this inventory, these inputs and host paths existed:

| Input | Path and frozen identity | Use/qualification |
|---|---|---|
| Native Full43 input | /Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex; 15,713,610,513 bytes; SHA-256 06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22 | Existing Vortex artifact used by the accepted Full43; present locally and directly reusable only after identity/preflight checks. |
| Original ClickBench Parquet | /Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet; 14,779,976,446 bytes; SHA-256 a390f6cb782f6aaef278c72fc1dd86c4f30bc843ebab3c159e9bd4d45ddb079f | Source identity for the generated native file; present, but no replacement ingest was part of output-window acceptance. |
| Independent Full43 value packet | /Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json; 135,485 bytes; SHA-256 cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39 | Independent result oracle; present. |
| Optional-consumer wheelhouse | /Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-wheelhouse-267 | Offline, hash-locked dependency source; present. |
| Wheel build Python | /Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python | Host-specific build tooling; present. |

Do not treat old output-window binaries, wheel, or installed venv as rebuilt artifacts for the current multiway source. The portable packet intentionally excludes large binaries, wheel/environment payloads, resident datasets and generated outputs, while recording their exact identities and rebuild instructions. The local 789 binaries/wheel/venv and both Full43 inputs were present at inspection time; the archive is the recovery location if any of those host-local artifacts are retired. Fresh UAT's earlier native CLI and binding identities (96e78f3575e17e2b88b3b9b520dcfded3695ab05c586192b174b16297123f0ef and 59b6abffd123922f082c8558e417b911cb0eb78ec58ee006ead351259b091dff) were also expressly excluded from its packet; the 663 prep/verification helpers and archived command records are in the three-part native-roadmap-fresh-uat archive listed above.

Current integrated sources must be frozen and built with their own new source/build manifests, binaries, isolated Python proof output, and new Public39/Full43/modular result roots. Reuse the harness logic and identified input/reference only; the recorded commands contain historical source hashes, commit and output destinations. No current-source acceptance result is asserted here.
