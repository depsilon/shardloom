#!/usr/bin/env python3
"""Preserve prospective projection-build source inputs as content-addressed blobs."""

from __future__ import annotations

import hashlib
import importlib
import json
import lzma
from pathlib import Path, PurePosixPath
import shlex
import shutil
import subprocess
import sys
import tempfile

EVIDENCE = Path("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
ROOT = Path("/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo")
OUT = EVIDENCE / "multiway-source-portability-821"
BLOBS = OUT / "blobs"
VERSION = "multiway-projection-build-821a"
BASE = "563c91260a526f6b02ab9bbb171dd9bfb8c4c2f0"
MAPPING = OUT / "projection-version.json"
TEXT_SUFFIXES = {
    ".rs", ".md", ".py", ".pyi", ".toml", ".json", ".yml", ".yaml",
    ".sh", ".txt", ".lock", ".sql", ".ini", ".conf", ".gitignore",
}
MAX_SOURCE_BYTES = 16 * 1024 * 1024


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_rel(name: str) -> Path:
    p = PurePosixPath(name)
    if p.is_absolute() or not name or any(x in ("", ".", "..") for x in p.parts):
        raise RuntimeError(f"unsafe archived source path: {name!r}")
    return Path(*p.parts)


def ensure_text(name: str, data: bytes) -> None:
    if len(data) > MAX_SOURCE_BYTES:
        raise RuntimeError(f"source exceeds bounded text size: {name} ({len(data)} bytes)")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise RuntimeError(f"refusing non-UTF-8/binary payload: {name}") from error


def git(args: list[str], *, data: bytes | None = None, cwd: Path = ROOT) -> bytes:
    result = subprocess.run(["git", *args], cwd=cwd, input=data,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed: "
                           + result.stderr.decode("utf-8", "replace")[:2000])
    return result.stdout


def base_tree() -> dict[str, tuple[str, str]]:
    output = git(["ls-tree", "-r", "-z", "--full-tree", BASE])
    result = {}
    for item in output.split(b"\0"):
        if not item:
            continue
        metadata, raw_path = item.split(b"\t", 1)
        mode, kind, oid = metadata.decode("ascii").split()
        result[raw_path.decode("utf-8")] = (mode, oid)
    return result


def load_git_blobs(oids: list[str]) -> dict[str, bytes]:
    unique = list(dict.fromkeys(oids))
    raw = git(["cat-file", "--batch"], data=("\n".join(unique) + "\n").encode("ascii"))
    result, offset = {}, 0
    for oid in unique:
        stop = raw.find(b"\n", offset)
        header = raw[offset:stop].decode("ascii").split()
        offset = stop + 1
        if len(header) != 3 or header[0] != oid or header[1] != "blob":
            raise RuntimeError(f"expected source blob {oid}, got {header!r}")
        size = int(header[2])
        data = raw[offset:offset + size]
        if len(data) != size or raw[offset + size:offset + size + 1] != b"\n":
            raise RuntimeError(f"truncated Git source blob: {oid}")
        offset += size + 1
        result[oid] = data
    if offset != len(raw):
        raise RuntimeError("unexpected trailing cat-file data")
    return result


def changed_paths(patch: str) -> list[str]:
    paths = []
    for line in patch.splitlines():
        if line.startswith("diff --git "):
            fields = shlex.split(line)
            if len(fields) != 4:
                raise RuntimeError(f"invalid tracked diff header: {line!r}")
            for side in fields[2:]:
                if side != "/dev/null" and side.startswith(("a/", "b/")):
                    name = side[2:]
                    if name not in paths:
                        paths.append(name)
    return paths


def apply_diff(scratch: Path, patch_text: str) -> list[str]:
    patch = patch_text.encode("utf-8")
    if b"GIT binary patch" in patch or b"Binary files " in patch:
        raise RuntimeError("binary content detected in tracked source archive")
    for args in (["git", "apply", "--check"], ["git", "apply"]):
        result = subprocess.run(args, cwd=scratch, input=patch, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, check=False)
        if result.returncode:
            raise RuntimeError("archived diff failed to apply: "
                               + result.stderr.decode("utf-8", "replace")[:2000])
    return changed_paths(patch_text)


def store(data: bytes) -> dict[str, int | str]:
    digest = sha(data)
    target = BLOBS / digest
    if target.exists():
        if target.is_symlink() or not target.is_file() or hash_file(target) != digest:
            raise RuntimeError(f"existing content-addressed blob is invalid: {target}")
    else:
        with target.open("xb") as stream:
            stream.write(data)
    return {"blob": f"blobs/{digest}", "bytes": len(data), "sha256": digest}


def main() -> None:
    if not OUT.is_dir() or not BLOBS.is_dir():
        raise RuntimeError(f"source-portability output is missing: {OUT}")
    if MAPPING.exists() or MAPPING.is_symlink():
        raise RuntimeError(f"refusing to replace projection mapping: {MAPPING}")
    sys.path.insert(0, str(ROOT / "scripts"))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    require_local_path(EVIDENCE, Path.home(), sys.platform)
    require_local_path(OUT, Path.home(), sys.platform)
    storage_before = check_budgets(
        EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
        reserve_bytes=64 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
    )

    prior_files = {
        "versions.json": hash_file(OUT / "versions.json"),
        "public-sources.json": hash_file(OUT / "public-sources.json"),
        "reconstruct_multiway_sources_821.py": hash_file(
            EVIDENCE / "reconstruct_multiway_sources_821.py"),
        "complete_multiway_public_sources_821.py": hash_file(
            EVIDENCE / "complete_multiway_public_sources_821.py"),
    }
    manifest_path = EVIDENCE / f"{VERSION}-input.json"
    archive_path = EVIDENCE / f"{VERSION}-source.json.xz"
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    archive_bytes = archive_path.read_bytes()
    if manifest.get("base_commit") != BASE or manifest.get("root") != str(ROOT):
        raise RuntimeError("projection input manifest has an unexpected source base/root")
    if hash_file(archive_path) != manifest.get("source_archive_sha256"):
        raise RuntimeError("projection source archive digest does not match its input manifest")
    if Path(manifest.get("source_archive", "")).resolve() != archive_path.resolve():
        raise RuntimeError("projection input manifest names a different source archive")
    archive = json.loads(lzma.decompress(archive_bytes))
    if archive.get("base_commit") != BASE or not isinstance(archive.get("untracked"), dict):
        raise RuntimeError("projection archive has an unexpected base or untracked section")
    patch_text = archive.get("tracked_diff")
    if not isinstance(patch_text, str):
        raise RuntimeError("projection archive tracked diff is not UTF-8 text")

    files = manifest.get("files")
    if not isinstance(files, dict) or len(files) != 1906:
        raise RuntimeError(f"expected exactly 1,906 compile inputs, got {len(files or {})}")
    paths = set(files)
    delta_paths = set(changed_paths(patch_text))
    untracked_paths = set(archive["untracked"])
    for name in paths | delta_paths | untracked_paths:
        safe_rel(name)
    base = base_tree()
    collisions = sorted(untracked_paths & set(base))
    if collisions:
        raise RuntimeError(f"untracked archive paths exist in frozen base: {collisions[:10]}")
    required = paths | delta_paths
    missing = sorted(name for name in required
                     if name not in base and name not in untracked_paths)
    if missing:
        raise RuntimeError(f"source paths missing from base and archive: {missing[:20]}")
    contents = load_git_blobs([base[name][1] for name in required if name in base])

    before_blob_names = set()
    for blob in BLOBS.iterdir():
        if blob.is_symlink() or not blob.is_file():
            raise RuntimeError(f"non-file entry in content blob directory: {blob}")
        before_blob_names.add(blob.name)

    scratch_parent = Path(tempfile.mkdtemp(prefix=".multiway-projection-821-", dir=EVIDENCE))
    version_map = {}
    added_digests = set()
    try:
        scratch = scratch_parent / VERSION
        scratch.mkdir()
        for name in required:
            if name not in base:
                continue
            mode, oid = base[name]
            if mode not in ("100644", "100755"):
                continue
            data = contents[oid]
            ensure_text(name, data)
            target = scratch / safe_rel(name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        applied = apply_diff(scratch, patch_text)
        for name, text in archive["untracked"].items():
            if not isinstance(text, str):
                raise RuntimeError(f"untracked source member is not text: {name}")
            data = text.encode("utf-8")
            ensure_text(name, data)
            target = scratch / safe_rel(name)
            if target.exists():
                raise RuntimeError(f"untracked source collides with reconstructed path: {name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)

        mapping = {}
        mismatch = []
        for name, expected in sorted(files.items()):
            target = scratch / safe_rel(name)
            if target.is_symlink() or not target.is_file():
                mismatch.append({"path": name, "reason": "missing_or_not_regular"})
                continue
            data = target.read_bytes()
            ensure_text(name, data)
            observed = {"bytes": len(data), "sha256": sha(data)}
            if observed != expected:
                mismatch.append({"path": name, "expected": expected, "observed": observed})
                continue
            digest = observed["sha256"]
            existed = (BLOBS / digest).exists()
            mapping[name] = {**store(data), "source": "existing_blob" if existed else "reconstructed_git_delta"}
            if not existed:
                added_digests.add(digest)
        if mismatch:
            raise RuntimeError(f"projection manifest mismatches ({len(mismatch)}): "
                               + json.dumps(mismatch[:20], sort_keys=True))

        additional = {}
        for name in sorted((set(applied) | untracked_paths) - set(mapping)):
            relative = safe_rel(name)
            target = scratch / relative
            if not target.exists() or relative.suffix.lower() not in TEXT_SUFFIXES:
                continue
            if target.is_symlink() or not target.is_file():
                raise RuntimeError(f"additional delta path is not a regular text file: {name}")
            data = target.read_bytes()
            ensure_text(name, data)
            digest = sha(data)
            existed = (BLOBS / digest).exists()
            additional[name] = {
                **store(data),
                "source": "existing_blob" if existed else "reconstructed_git_delta",
            }
            if not existed:
                added_digests.add(digest)

        final_blobs = list(BLOBS.iterdir())
        result = {
            "schema": "multiway-projection-source-version-821-v1",
            "status": "prospective_unaccepted",
            "scope_note": "Frozen compile-input source reconstruction only; this does not establish build, test, or acceptance status.",
            "version": VERSION,
            "base_commit": BASE,
            "helper_sha256": hash_file(Path(__file__)),
            "manifest": {
                "path": str(manifest_path),
                "bytes": len(manifest_bytes),
                "sha256": sha(manifest_bytes),
                "declared_file_count": len(files),
                "verified_file_count": len(mapping),
            },
            "archive": {
                "path": str(archive_path),
                "bytes": len(archive_bytes),
                "sha256": sha(archive_bytes),
                "declared_sha256": manifest["source_archive_sha256"],
                "untracked_entry_count": len(untracked_paths),
                "tracked_diff_path_count": len(delta_paths),
            },
            "files": mapping,
            "changed_or_untracked_text_outside_manifest": additional,
            "blob_union": {
                "existing_blob_count_before": len(before_blob_names),
                "new_unique_blob_count": len(added_digests),
                "final_blob_count": len(final_blobs),
                "final_blob_bytes": sum(p.stat().st_size for p in final_blobs),
            },
            "related_821_snapshot_identities": prior_files,
            "verification": {
                "all_1906_manifest_identities_match": len(mapping) == len(files),
                "all_mapping_blob_refs_resolve": True,
                "unresolved_paths": [],
            },
            "storage_check_before": storage_before,
        }
        storage_after = check_budgets(
            EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
            reserve_bytes=0, max_workspace_bytes=100 * GIB,
            max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
        )
        for name, expected_sha in prior_files.items():
            path = EVIDENCE / name if name.endswith(".py") else OUT / name
            if hash_file(path) != expected_sha:
                raise RuntimeError(f"pre-existing portability artifact changed: {name}")
        result["storage_check_after"] = storage_after
        with MAPPING.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, sort_keys=True, indent=2)
            stream.write("\n")
    finally:
        shutil.rmtree(scratch_parent)

    print(json.dumps({
        "status": "complete",
        "mapping": str(MAPPING),
        "mapping_sha256": hash_file(MAPPING),
        "manifest_files": len(mapping),
        "additional_text": len(additional),
        "new_unique_blobs": len(added_digests),
        "final_blob_count": len(list(BLOBS.iterdir())),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
