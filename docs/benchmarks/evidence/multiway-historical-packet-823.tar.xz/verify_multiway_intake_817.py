"""Validate complete ordinary-path values, schemas, stage traffic and cleanup."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import multiway_reference_817 as oracle

ORACLE_SHA = '7858a4f8b6ed53715ad46a123d1d5f7e2d97c4739ab282f0f297ada6418a35fa'
assert hashlib.sha256(Path(oracle.__file__).read_bytes()).hexdigest() == ORACLE_SHA

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

def dtype(cell):
    names = list(oracle.RS_FIELDS) + ([] if cell == 'binary_control' else list(oracle.T_FIELDS))
    return {'Struct': [{'names': names, 'dtypes': [{'Primitive': ['i64', not name.endswith('id')]} for name in names]}, False]}

def index_bytes(keys):
    keys = [tuple(key) for key in keys if all(value is not None for value in key)]
    if not keys:
        return 0
    unique = len(set(keys))
    capacity = lambda n: max(8, 1 << (n - 1).bit_length())
    buckets = max(16, 1 << (2 * unique - 1).bit_length())
    return 8 * buckets + 24 * capacity(unique) + 16 * capacity(len(keys))

def validate(record, expected=None, inner_count=None):
    cell = record['cell']
    assert record['protocol'] == 'multiway-intake-817-v1'
    assert record['sources'] == oracle.source(cell), cell
    expected = oracle.expected(cell) if expected is None else expected
    inner_count = len(oracle.expected_inner(cell)) if inner_count is None else inner_count
    assert record['expected_dtype'] == dtype(cell), cell
    assert record['completed_executions'] == 2
    assert record['reserved_after_cleanup'] == record['denied_reservations'] == 0
    assert 0 < record['peak_reserved_bytes'] <= 64 << 20
    assert len(record['operations']) == 2
    source = record['sources']
    expected_sources = 2 if cell == 'binary_control' else 3
    for call, operation in enumerate(record['operations']):
        assert operation['call'] == call
        assert operation['rows'] == expected, (cell, call, 'complete ordered values')
        assert operation['output_rows'] == len(expected)
        assert operation['schema'] == dtype(cell)
        assert operation['certified'] is True and operation['fallback_attempted'] is False
        assert operation['prepared_sources'] == expected_sources
        for key in ['engine_execution_ns', 'result_serialization_ns']:
            assert isinstance(operation[key], int) and 0 <= operation[key] < 600_000_000_000
        stages = operation['binary_stages']
        assert len(stages) == expected_sources - 1
        first = next(stage for stage in stages if stage['fields'] == list(oracle.RS_FIELDS))
        assert first['left_keys'] == ['x' if cell == 'star_control' else 'y']
        assert first['right_keys'] == ['x']
        stats = first['stats']
        assert stats['build_rows'] == len(source['s']) and stats['probe_rows'] == len(source['r'])
        assert stats['output_rows'] == stats['candidate_assignments'] == inner_count
        assert stats['index_capacity_bytes'] == index_bytes([[row[0]] for row in source['s']])
        assert stats['exact_comparisons'] > 0
        assert stats['output_batches'] > 0 and stats['delivered_array_bytes'] > 0
        if cell != 'binary_control':
            last = next(stage for stage in stages if stage['fields'] == list(oracle.RS_FIELDS + oracle.T_FIELDS))
            assert last['left_keys'] == (['rb'] if cell == 'star_control' else ['ra', 'sc'])
            assert last['right_keys'] == (['x'] if cell == 'star_control' else ['x', 'y'])
            stats = last['stats']
            assert stats['build_rows'] == len(source['t']) and stats['probe_rows'] == inner_count
            assert stats['output_rows'] == stats['candidate_assignments'] == len(expected)
            keys = [[row[0]] if cell == 'star_control' else row[:2] for row in source['t']]
            assert stats['index_capacity_bytes'] == index_bytes(keys)
            assert (stats['output_batches'] == stats['delivered_array_bytes'] == 0) if not expected else (stats['output_batches'] > 0 and stats['delivered_array_bytes'] > 0)
    return {'cell': cell, 'source_sha256': digest(source), 'output_sha256': digest(expected),
            'output_rows': len(expected), 'inner_rows': inner_count,
            'materialized_work_signal': inner_count >= 100_000 and (not expected or inner_count >= 16 * len(expected)),
            'peak_reserved_bytes': record['peak_reserved_bytes'],
            'operations': [{k: v for k, v in op.items() if k != 'rows'} for op in record['operations']]}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    records = [json.loads(line) for line in args.input.read_text().splitlines()]
    assert [record['cell'] for record in records] == list(oracle.CELLS)
    results = [validate(record) for record in records]
    assert sum(result['materialized_work_signal'] for result in results[:4]) >= 2
    small = next(record for record in records if record['cell'] == 'cyclic_small')
    expected = oracle.expected('cyclic_small')
    inner = len(oracle.expected_inner('cyclic_small'))
    mutations = [
        lambda value: value['operations'][0]['rows'].reverse(),
        lambda value: value['operations'][0].update(schema={'Struct': []}),
        lambda value: value['operations'].pop(),
        lambda value: value.update(reserved_after_cleanup=1),
        lambda value: value['sources']['s'][0].__setitem__(1, 9999),
        lambda value: value['operations'][0]['binary_stages'][0]['stats'].update(output_rows=0),
    ]
    for mutate in mutations:
        altered = copy.deepcopy(small)
        mutate(altered)
        try:
            validate(altered, expected, inner)
        except (AssertionError, KeyError, StopIteration):
            continue
        raise AssertionError('validator accepted a malformed control')
    result = {'status': 'passed', 'input_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
              'oracle_sha256': ORACLE_SHA, 'workflows': 8, 'queries': 16,
              'complete_output_rows_checked': sum(result['output_rows'] * 2 for result in results),
              'negative_validator_controls_rejected': len(mutations), 'cells': results}
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'cells'}))

if __name__ == '__main__':
    main()
