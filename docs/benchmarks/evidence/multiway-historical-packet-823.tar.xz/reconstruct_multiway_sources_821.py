#!/usr/bin/env python3
"""Reconstruct frozen multiway source trees and retain portable content blobs."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile

EVIDENCE = Path("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
ROOT = Path("/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo")
BASE = "563c91260a526f6b02ab9bbb171dd9bfb8c4c2f0"
OUT = EVIDENCE / "multiway-source-portability-821"
VERSIONS = (
    "multiway-intake-build-817a",
    "multiway-probe-build-818a",
    "multiway-probe-build-818b",
    "multiway-probe-build-818c",
    "multiway-integration-build-819a",
)
TEXT_SUFFIXES = {
    ".rs", ".md", ".py", ".pyi", ".toml", ".json", ".yml", ".yaml",
    ".sh", ".txt", ".lock", ".sql", ".ini", ".conf", ".gitignore",
}
MAX_SOURCE_BYTES = 16 * 1024 * 1024


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_identity(path: Path) -> dict[str, int | str]:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": sha256(data)}


def run_git(args: list[str], *, cwd: Path, data: bytes | None = None) -> bytes:
    result = subprocess.run(
        ["git", *args], cwd=cwd, input=data, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"git {' '.join(args)} failed ({result.returncode}): "
            + result.stderr.decode("utf-8", "replace")[:2000]
        )
    return result.stdout


def ensure_text(path: str, data: bytes) -> None:
    if len(data) > MAX_SOURCE_BYTES:
        raise RuntimeError(f"source file exceeds bounded text size: {path} ({len(data)} bytes)")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise RuntimeError(f"refusing non-UTF-8/binary source payload: {path}") from error


def safe_relative(name: str) -> Path:
    posix = PurePosixPath(name)
    if posix.is_absolute() or not name or any(part in ("", ".", "..") for part in posix.parts):
        raise RuntimeError(f"unsafe archived path: {name!r}")
    return Path(*posix.parts)


def git_tree_blobs() -> dict[str, tuple[str, str]]:
    listing = run_git(["ls-tree", "-r", "-z", "--full-tree", BASE], cwd=ROOT)
    result: dict[str, tuple[str, str]] = {}
    for entry in listing.split(b"\0"):
        if not entry:
            continue
        meta, raw_name = entry.split(b"\t", 1)
        mode, kind, oid = meta.decode("ascii").split()
        name = raw_name.decode("utf-8")
        result[name] = (mode, oid)
    return result


def cat_blobs(oids: list[str]) -> dict[str, bytes]:
    unique = list(dict.fromkeys(oids))
    stream = run_git(["cat-file", "--batch"], cwd=ROOT,
                     data=("\n".join(unique) + "\n").encode("ascii"))
    cursor = 0
    result = {}
    for expected_oid in unique:
        end = stream.find(b"\n", cursor)
        if end < 0:
            raise RuntimeError("truncated git cat-file --batch header")
        header = stream[cursor:end].decode("ascii").split()
        cursor = end + 1
        if len(header) != 3 or header[0] != expected_oid or header[1] != "blob":
            raise RuntimeError(f"expected base text blob {expected_oid}; got {header!r}")
        size = int(header[2])
        content = stream[cursor:cursor + size]
        if len(content) != size or stream[cursor + size:cursor + size + 1] != b"\n":
            raise RuntimeError(f"truncated git blob {expected_oid}")
        cursor += size + 1
        result[expected_oid] = content
    if cursor != len(stream):
        raise RuntimeError("unexpected trailing data in git cat-file --batch response")
    return result


def store_blob(data: bytes, blobs_dir: Path) -> dict[str, int | str]:
    digest = sha256(data)
    target = blobs_dir / digest
    if target.exists():
        if target.is_symlink() or not target.is_file() or file_identity(target) != {
            "bytes": len(data), "sha256": digest
        }:
            raise RuntimeError(f"pre-existing blob path does not match its identity: {target}")
    else:
        with target.open("xb") as stream:
            stream.write(data)
    return {"blob": f"blobs/{digest}", "bytes": len(data), "sha256": digest}


def apply_archive_patch(scratch: Path, patch_text: str) -> list[str]:
    patch = patch_text.encode("utf-8")
    if b"GIT binary patch" in patch or b"Binary files " in patch:
        raise RuntimeError("binary patch found; refusing to read or copy binary content")
    checked = subprocess.run(
        ["git", "apply", "--check"], cwd=scratch, input=patch,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    if checked.returncode:
        raise RuntimeError("archived tracked diff does not apply to base: "
                           + checked.stderr.decode("utf-8", "replace")[:2000])
    applied = subprocess.run(
        ["git", "apply"], cwd=scratch, input=patch,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    if applied.returncode:
        raise RuntimeError("could not apply archived tracked diff: "
                           + applied.stderr.decode("utf-8", "replace")[:2000])
    paths = []
    for line in patch_text.splitlines():
        if not line.startswith("diff --git "):
            continue
        import shlex
        fields = shlex.split(line)
        if len(fields) != 4:
            raise RuntimeError(f"unparseable diff path header: {line!r}")
        for side in fields[2:4]:
            if side == "/dev/null":
                continue
            if side.startswith(("a/", "b/")):
                name = side[2:]
                if name not in paths:
                    paths.append(name)
    return paths


def main() -> None:
    if OUT.exists() or OUT.is_symlink():
        raise RuntimeError(f"output must be a new directory: {OUT}")
    if not ROOT.is_dir() or not EVIDENCE.is_dir():
        raise RuntimeError("expected worktree and evidence directory are unavailable")
    sys.path.insert(0, str(ROOT / "scripts"))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    require_local_path(EVIDENCE, Path.home(), sys.platform)
    require_local_path(OUT, Path.home(), sys.platform)
    budget_before = check_budgets(
        EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
        reserve_bytes=512 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
    )

    head = run_git(["rev-parse", "HEAD"], cwd=ROOT).decode().strip()
    if head != BASE:
        raise RuntimeError(f"worktree base mismatch: expected {BASE}, got {head}")
    base_tree = git_tree_blobs()
    records = {}
    archives = {}
    required_base_paths = set()
    per_version = {}
    for version in VERSIONS:
        manifest_path = EVIDENCE / f"{version}-input.json"
        archive_path = EVIDENCE / f"{version}-source.json.xz"
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes)
        archive_bytes = archive_path.read_bytes()
        if manifest.get("base_commit") != BASE:
            raise RuntimeError(f"{version}: manifest pins another base")
        if sha256(archive_bytes) != manifest.get("source_archive_sha256"):
            raise RuntimeError(f"{version}: source archive digest mismatch")
        archive = json.loads(lzma.decompress(archive_bytes))
        if archive.get("base_commit") != BASE:
            raise RuntimeError(f"{version}: archive pins another base")
        if not isinstance(archive.get("untracked"), dict):
            raise RuntimeError(f"{version}: archive untracked member is not a path map")
        patch_text = archive.get("tracked_diff")
        if not isinstance(patch_text, str):
            raise RuntimeError(f"{version}: tracked diff is not text")
        diff_paths = []
        for line in patch_text.splitlines():
            if line.startswith("diff --git "):
                import shlex
                fields = shlex.split(line)
                if len(fields) != 4:
                    raise RuntimeError(f"{version}: unparseable diff header {line!r}")
                diff_paths.extend(side[2:] for side in fields[2:4]
                                  if side != "/dev/null" and side.startswith(("a/", "b/")))
        manifest_paths = set(manifest.get("files", {}))
        untracked_paths = set(archive["untracked"])
        for name in manifest_paths | set(diff_paths):
            safe_relative(name)
            required_base_paths.add(name)
        if archive_path.resolve() != Path(manifest["source_archive"]).resolve():
            raise RuntimeError(f"{version}: archive path mismatch in input manifest")
        if untracked_paths & set(base_tree):
            raise RuntimeError(f"{version}: archived untracked path already exists in frozen base")
        records[version] = {
            "manifest_path": str(manifest_path),
            "manifest_identity": {"bytes": len(manifest_bytes), "sha256": sha256(manifest_bytes)},
            "archive_path": str(archive_path),
            "archive_identity": {"bytes": len(archive_bytes), "sha256": sha256(archive_bytes)},
            "archive_untracked_count": len(untracked_paths),
        }
        archives[version] = (manifest, archive, diff_paths)

    missing_base = sorted(name for name in required_base_paths
                          if name not in base_tree and all(
                              name not in archives[v][1]["untracked"] for v in VERSIONS))
    if missing_base:
        raise RuntimeError(f"required path absent from base and untracked archives: {missing_base[:10]}")
    blob_ids = [base_tree[name][1] for name in required_base_paths if name in base_tree]
    base_content = cat_blobs(blob_ids)

    OUT.mkdir()
    blobs_dir = OUT / "blobs"
    blobs_dir.mkdir()
    scratch_parent = Path(tempfile.mkdtemp(prefix=".multiway-821-reconstruct-", dir=EVIDENCE))
    version_mappings = {}
    try:
        for version in VERSIONS:
            manifest, archive, diff_paths = archives[version]
            scratch = scratch_parent / version
            scratch.mkdir()
            for name in required_base_paths:
                if name not in base_tree:
                    continue
                mode, oid = base_tree[name]
                if mode not in ("100644", "100755"):
                    continue
                destination = scratch / safe_relative(name)
                destination.parent.mkdir(parents=True, exist_ok=True)
                data = base_content[oid]
                ensure_text(name, data)
                destination.write_bytes(data)
            patched = apply_archive_patch(scratch, archive["tracked_diff"])
            additional = {}
            for name, text in archive["untracked"].items():
                safe_relative(name)
                if not isinstance(text, str):
                    raise RuntimeError(f"{version}: non-text untracked member: {name}")
                data = text.encode("utf-8")
                ensure_text(name, data)
                destination = scratch / safe_relative(name)
                if destination.exists():
                    raise RuntimeError(f"{version}: untracked path collides after patch: {name}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)

            mapping = {}
            mismatches = []
            for name, expected in sorted(manifest["files"].items()):
                source = scratch / safe_relative(name)
                if source.is_symlink() or not source.is_file():
                    mismatches.append({"path": name, "reason": "missing_or_not_regular"})
                    continue
                data = source.read_bytes()
                ensure_text(name, data)
                observed = {"bytes": len(data), "sha256": sha256(data)}
                if observed != expected:
                    mismatches.append({"path": name, "expected": expected, "observed": observed})
                    continue
                mapping[name] = store_blob(data, blobs_dir)
            if mismatches:
                raise RuntimeError(f"{version}: {len(mismatches)} frozen source identity mismatches; "
                                   f"first={mismatches[:3]}")

            for name in sorted((set(patched) | set(archive["untracked"])) - set(mapping)):
                relative = safe_relative(name)
                source = scratch / relative
                if not source.exists():
                    continue
                if relative.suffix.lower() not in TEXT_SUFFIXES:
                    continue
                if source.is_symlink() or not source.is_file():
                    raise RuntimeError(f"{version}: additional source is not a regular file: {name}")
                data = source.read_bytes()
                ensure_text(name, data)
                additional[name] = store_blob(data, blobs_dir)

            version_mappings[version] = {
                **records[version],
                "manifest_file_count": len(manifest["files"]),
                "manifest_verified_count": len(mapping),
                "files": mapping,
                "changed_or_untracked_text_outside_manifest": additional,
                "tracked_diff_paths": sorted(set(patched)),
                "deleted_diff_paths": sorted(
                    name for name in set(patched)
                    if not (scratch / safe_relative(name)).exists()
                ),
            }

        accepted_path = EVIDENCE / "multiway-acceptance-source-820.json"
        accepted_bytes = accepted_path.read_bytes()
        accepted = json.loads(accepted_bytes)
        accepted_map = accepted["source_hashes"]
        accepted_entries = {}
        accepted_mismatches = []
        for name, expected_sha in sorted(accepted_map.items()):
            relative = safe_relative(name)
            source = ROOT / relative
            if source.is_symlink() or not source.is_file():
                accepted_mismatches.append({"path": name, "reason": "missing_or_not_regular"})
                continue
            if not source.resolve().is_relative_to(ROOT.resolve()):
                accepted_mismatches.append({"path": name, "reason": "resolves_outside_worktree"})
                continue
            data = source.read_bytes()
            ensure_text(name, data)
            observed_sha = sha256(data)
            if observed_sha != expected_sha:
                accepted_mismatches.append({
                    "path": name, "expected_sha256": expected_sha,
                    "observed_sha256": observed_sha,
                })
                continue
            accepted_entries[name] = {"bytes": len(data), "sha256": expected_sha}
        if accepted_mismatches:
            raise RuntimeError(
                f"accepted public source map has {len(accepted_mismatches)} mismatches; "
                f"first={accepted_mismatches[:3]}"
            )

        manifest_hashes = {
            version: {
                "manifest": records[version]["manifest_identity"]["sha256"],
                "archive": records[version]["archive_identity"]["sha256"],
                "files": len(version_mappings[version]["files"]),
                "additional_text": len(version_mappings[version]["changed_or_untracked_text_outside_manifest"]),
            }
            for version in VERSIONS
        }
        result = {
            "schema": "multiway-source-portability-821-v1",
            "base_commit": BASE,
            "helper_sha256": sha256(Path(__file__).read_bytes()),
            "storage_check_before": budget_before,
            "frozen_versions": version_mappings,
            "accepted_public_sources": {
                "record_path": str(accepted_path),
                "record_bytes": len(accepted_bytes),
                "record_sha256": sha256(accepted_bytes),
                "source_commit": accepted.get("source_commit"),
                "source_hash_count": len(accepted_map),
                "verified_count": len(accepted_entries),
                "files": accepted_entries,
            },
            "blob_count": len(list(blobs_dir.iterdir())),
            "blob_bytes": sum(p.stat().st_size for p in blobs_dir.iterdir()),
            "verification_summary": {
                "all_five_manifest_sets_verified": all(
                    version_mappings[v]["manifest_verified_count"] == version_mappings[v]["manifest_file_count"]
                    for v in VERSIONS
                ),
                "accepted_public_sources_all_verified": len(accepted_entries) == len(accepted_map),
                "frozen_version_manifest_identities": manifest_hashes,
                "mismatch_count": 0,
            },
        }
        after = check_budgets(
            EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
            reserve_bytes=0, max_workspace_bytes=100 * GIB,
            max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
        )
        result["storage_check_after"] = after
        versions_path = OUT / "versions.json"
        with versions_path.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, sort_keys=True, indent=2)
            stream.write("\n")
    finally:
        shutil.rmtree(scratch_parent)

    print(json.dumps({
        "status": "complete",
        "output": str(OUT),
        "versions": {k: {"files": v["manifest_verified_count"],
                         "additional_text": len(v["changed_or_untracked_text_outside_manifest"])}
                     for k, v in version_mappings.items()},
        "accepted_public_sources": len(accepted_entries),
        "blob_count": result["blob_count"],
        "blob_bytes": result["blob_bytes"],
        "versions_sha256": sha256((OUT / "versions.json").read_bytes()),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
