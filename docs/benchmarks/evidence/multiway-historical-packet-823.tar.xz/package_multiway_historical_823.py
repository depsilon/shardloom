#!/usr/bin/env python3
"""Package the frozen multiway historical evidence inventory with checked readback."""

from __future__ import annotations

import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

E = Path("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
WORKTREE = Path("/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo")
STORAGE_HELPER = WORKTREE / "scripts/local_uat_storage.py"
INVENTORY = E / "multiway-artifact-inventory-822.json"
INVENTORY_MD = E / "multiway-artifact-inventory-822.md"
SCRIPT = E / "package_multiway_historical_823.py"
EXTERNAL_HELPER = Path(
    "/Users/dylan/LocalData/shardloom/perf-all-20260906/"
    "bounded_build_process_resume_20260912.py"
)
ARCHIVE = E / "multiway-historical-packet-823.tar.xz"
MANIFEST = E / "multiway-historical-packet-823-manifest.json"
READBACK = E / "multiway-historical-packet-823-readback.json"

PINNED_INVENTORY_SHA256 = "9471840b914eb2f6f9fe67c814b92a2c66f5a3bf87a6ae1a38a65b9acad5d139"
PINNED_INVENTORY_MD_SHA256 = "05a665d6cbf47dc18d57906b682b03c333e554d6f3e3ea6fa70ed00863fa1895"
PINNED_EXTERNAL_HELPER_SHA256 = "1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97"
MIB = 1024**2
GIB = 1024**3
RESERVE_BYTES = 128 * MIB
MIN_FREE_BYTES = 12 * GIB
MAX_WORKSPACE_BYTES = 100 * GIB
MAX_LOG_BYTES = 192 * MIB


class PacketError(RuntimeError):
    pass


def sha_stream(stream) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            break
        size += len(chunk)
        digest.update(chunk)
    return size, digest.hexdigest()


def identity(path: Path) -> dict[str, object]:
    if path.is_symlink():
        raise PacketError(f"refusing symlink input: {path}")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise PacketError(f"input is not a regular file: {path}")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            size, digest = sha_stream(stream)
        if size != info.st_size:
            raise PacketError(f"input changed while hashing: {path}")
        return {"path": str(path), "bytes": size, "sha256": digest}
    finally:
        os.close(fd)


def safe_member(name: str) -> str:
    pure = PurePosixPath(name)
    if pure.is_absolute() or not name or any(part in ("", ".", "..") for part in name.split("/")):
        raise PacketError(f"unsafe archive member path: {name!r}")
    if "\\" in name:
        raise PacketError(f"non-portable archive member path: {name!r}")
    return pure.as_posix()


def load_storage_helper():
    if STORAGE_HELPER.is_symlink() or not STORAGE_HELPER.is_file():
        raise PacketError(f"storage guard is missing or not a regular file: {STORAGE_HELPER}")
    spec = importlib.util.spec_from_file_location("local_uat_storage_823", STORAGE_HELPER)
    if spec is None or spec.loader is None:
        raise PacketError("could not load local storage guard")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reserve_storage() -> dict[str, object]:
    guard = load_storage_helper()
    root = guard.require_local_path(E, Path.home(), sys.platform)
    source = guard.require_local_path(INVENTORY, Path.home(), sys.platform)
    target = guard.require_local_path(ARCHIVE, Path.home(), sys.platform)
    logs = guard.require_local_path(E / "packet-823-log-reservation", Path.home(), sys.platform)
    if not source.is_relative_to(root) or not target.is_relative_to(root):
        raise PacketError("source and archive must be beneath the guarded evidence root")
    budgets = guard.check_budgets(
        root,
        target,
        logs,
        min_free_bytes=MIN_FREE_BYTES,
        reserve_bytes=RESERVE_BYTES,
        max_workspace_bytes=MAX_WORKSPACE_BYTES,
        max_log_bytes=MAX_LOG_BYTES,
    )
    return {
        "helper": identity(STORAGE_HELPER),
        "thresholds": {
            "minimum_free_bytes": MIN_FREE_BYTES,
            "candidate_reserve_bytes": RESERVE_BYTES,
            "maximum_workspace_bytes": MAX_WORKSPACE_BYTES,
            "maximum_retained_log_bytes": MAX_LOG_BYTES,
        },
        "snapshot": budgets,
    }


def check_no_existing_outputs() -> None:
    for path in (ARCHIVE, MANIFEST, READBACK):
        if path.exists() or path.is_symlink():
            raise PacketError(f"refusing to overwrite existing output: {path}")


def selected_inputs() -> tuple[list[dict[str, object]], dict[str, object]]:
    inv_id = identity(INVENTORY)
    md_id = identity(INVENTORY_MD)
    ext_id = identity(EXTERNAL_HELPER)
    if inv_id["sha256"] != PINNED_INVENTORY_SHA256:
        raise PacketError("inventory JSON identity differs from the accepted pinned SHA-256")
    if md_id["sha256"] != PINNED_INVENTORY_MD_SHA256:
        raise PacketError("inventory Markdown identity differs from the accepted SHA-256")
    if ext_id["sha256"] != PINNED_EXTERNAL_HELPER_SHA256:
        raise PacketError("external supervisor identity differs from the pinned SHA-256")

    inventory = json.loads(INVENTORY.read_text(encoding="utf-8"))
    entries = inventory.get("scope", {}).get("files")
    if not isinstance(entries, list) or len(entries) != 2685:
        raise PacketError("accepted inventory does not contain exactly 2,685 selected files")
    if inventory.get("scope", {}).get("file_count") != 2685:
        raise PacketError("inventory file_count does not match the selected file list")

    members: list[dict[str, object]] = []
    seen: set[str] = set()

    def add(path: Path, member: str, expected_size: int | None = None,
            expected_sha256: str | None = None) -> None:
        member = safe_member(member)
        if member in seen:
            raise PacketError(f"duplicate archive member: {member}")
        seen.add(member)
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or path.is_symlink():
            raise PacketError(f"input must be a non-symlink regular file: {path}")
        if info.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
            raise PacketError(f"refusing executable input: {path}")
        if expected_size is not None and info.st_size != expected_size:
            raise PacketError(f"inventory byte count mismatch: {path}")
        ident = identity(path)
        if expected_sha256 is not None and ident["sha256"] != expected_sha256:
            raise PacketError(f"inventory SHA-256 mismatch: {path}")
        members.append({
            "member": member,
            "original_path": str(path),
            "bytes": ident["bytes"],
            "sha256": ident["sha256"],
        })

    for entry in entries:
        rel = entry.get("relative_path")
        if not isinstance(rel, str):
            raise PacketError("inventory entry has no relative_path string")
        member = safe_member(rel)
        path = E / member
        if Path(entry.get("path", "")).resolve() != path.resolve():
            raise PacketError(f"inventory absolute/relative path disagreement: {rel}")
        add(path, member, entry.get("bytes"), entry.get("sha256"))

    extras = [
        (INVENTORY, INVENTORY.name),
        (INVENTORY_MD, INVENTORY_MD.name),
        (SCRIPT, SCRIPT.name),
        (EXTERNAL_HELPER, "external/bounded_build_process_resume_20260912.py"),
    ]
    for path, member in extras:
        add(path, member)
    if len(members) != 2689:
        raise PacketError(f"expected 2,689 payload members, found {len(members)}")
    return sorted(members, key=lambda row: str(row["member"])), {
        "inventory_json": inv_id,
        "inventory_markdown": md_id,
        "external_supervisor": ext_id,
    }


def write_exclusive(path: Path, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)


def open_source_no_follow(path: Path, expected: dict[str, object]):
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_size != expected["bytes"]:
        os.close(fd)
        raise PacketError(f"source type/size changed before archive read: {path}")
    return fd, info


def archive_members(members: list[dict[str, object]], manifest_bytes: bytes) -> None:
    fd = os.open(ARCHIVE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as raw:
            with tarfile.open(fileobj=raw, mode="w|xz", format=tarfile.PAX_FORMAT) as tar:
                for row in members:
                    source = Path(str(row["original_path"]))
                    source_fd, info = open_source_no_follow(source, row)
                    try:
                        with os.fdopen(source_fd, "rb", closefd=False) as source_stream:
                            ti = tarfile.TarInfo(str(row["member"]))
                            ti.size = info.st_size
                            ti.mode = stat.S_IMODE(info.st_mode) & 0o666
                            ti.mtime = 0
                            tar.addfile(ti, source_stream)
                    finally:
                        os.close(source_fd)
                ti = tarfile.TarInfo("MANIFEST.json")
                ti.size = len(manifest_bytes)
                ti.mode = 0o600
                ti.mtime = 0
                import io
                tar.addfile(ti, io.BytesIO(manifest_bytes))
            raw.flush()
            os.fsync(fd)
    finally:
        os.close(fd)


def verify_archive(members: list[dict[str, object]], manifest_bytes: bytes) -> dict[str, object]:
    expected = {str(row["member"]): row for row in members}
    if "MANIFEST.json" in expected:
        raise PacketError("payload collides with MANIFEST.json")
    verified = 0
    total_bytes = 0
    with tarfile.open(ARCHIVE, mode="r:xz") as tar:
        actual_names: list[str] = []
        for ti in tar:
            name = safe_member(ti.name)
            if name in actual_names:
                raise PacketError(f"duplicate member during readback: {name}")
            actual_names.append(name)
            if not ti.isfile() or ti.issym() or ti.islnk():
                raise PacketError(f"non-regular archive member: {name}")
            stream = tar.extractfile(ti)
            if stream is None:
                raise PacketError(f"archive member cannot be read: {name}")
            size, digest = sha_stream(stream)
            if name == "MANIFEST.json":
                if size != len(manifest_bytes) or digest != hashlib.sha256(manifest_bytes).hexdigest():
                    raise PacketError("embedded MANIFEST.json differs from the exact sidecar bytes")
            else:
                row = expected.get(name)
                if row is None:
                    raise PacketError(f"unexpected archive member: {name}")
                if size != row["bytes"] or digest != row["sha256"]:
                    raise PacketError(f"archived member identity mismatch: {name}")
                verified += 1
                total_bytes += size
    expected_names = set(expected) | {"MANIFEST.json"}
    if set(actual_names) != expected_names or len(actual_names) != len(expected_names):
        raise PacketError("archive member set differs from manifest payload plus MANIFEST.json")
    if verified != len(members):
        raise PacketError("not every payload member was verified")
    return {"archive_member_count": len(actual_names), "payload_member_count": verified,
            "payload_bytes": total_bytes}


def main() -> int:
    try:
        check_no_existing_outputs()
        storage = reserve_storage()
        members, pinned = selected_inputs()
        before = [identity(Path(str(row["original_path"]))) for row in members]
        manifest = {
            "schema": "multiway-historical-packet-823-v1",
            "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "historical_only": True,
            "production_accepted": False,
            "historical_context": {
                "projected_cohort_A": "failed required control",
                "projected_cohort_B": "passed",
                "preliminary_accepted_public_sources":
                    "labels retained as historical labels; they do not constitute acceptance",
            },
            "input_inventory": pinned,
            "storage_guard": storage,
            "payload_member_count": len(members),
            "payload_bytes": sum(int(row["bytes"]) for row in members),
            "members": members,
        }
        manifest_bytes = (json.dumps(manifest, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=False) + "\n").encode("utf-8")
        write_exclusive(MANIFEST, manifest_bytes)
        archive_members(members, manifest_bytes)
        readback = verify_archive(members, manifest_bytes)
        after = [identity(Path(str(row["original_path"]))) for row in members]
        if before != after:
            raise PacketError("one or more source inputs changed during packaging")
        archive_id = identity(ARCHIVE)
        manifest_id = identity(MANIFEST)
        script_id = identity(SCRIPT)
        result = {
            "schema": "multiway-historical-packet-823-readback-v1",
            "status": "passed",
            "historical_only": True,
            "production_accepted": False,
            "archive": archive_id,
            "manifest": manifest_id,
            "packaging_script": script_id,
            "input_identity_recheck": "all payload inputs match before and after packaging",
            "payload_member_count": len(members),
            "archive_member_count": readback["archive_member_count"],
            "payload_bytes": readback["payload_bytes"],
            "readback": readback,
            "storage_guard": storage,
            "projected_cohort_A": "failed required control",
            "projected_cohort_B": "passed",
            "preliminary_accepted_public_sources":
                "historical labels only; no production acceptance asserted",
        }
        write_exclusive(READBACK, (json.dumps(result, sort_keys=True, indent=2) + "\n").encode())
        print(json.dumps(result, sort_keys=True))
        return 0
    except Exception as exc:
        print(f"historical packet packaging failed closed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
