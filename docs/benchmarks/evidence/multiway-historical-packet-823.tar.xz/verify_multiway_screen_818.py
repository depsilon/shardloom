"""Verify the frozen multiway lifecycle grid, complete witnesses and cost gates.

Only this independent Python oracle computes expected rows. No engine is used.
The counter check derives equality-call counts after proving the finite integer
key sets have no FxHash collisions under the pinned 64-bit rustc-hash 2.1.3.
"""
import argparse
from collections import Counter, defaultdict
import copy
import hashlib
import json
from pathlib import Path
import re
import statistics

import multiway_reference_817 as oracle

ORACLE_SHA = '7858a4f8b6ed53715ad46a123d1d5f7e2d97c4739ab282f0f297ada6418a35fa'
PROTOCOL = 'multiway-probe-817-v1'
assert hashlib.sha256(Path(oracle.__file__).read_bytes()).hexdigest() == ORACLE_SHA

def sha(data):
    return hashlib.sha256(data).hexdigest()

def same_json(left, right):
    # Python's ordinary equality equates True, 1 and 1.0. The native transport
    # must retain its exact scalar and schema representation as well as values.
    encode=lambda value: json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
    return encode(left)==encode(right)

def schema(cell):
    names = list(oracle.RS_FIELDS) + ([] if cell == 'binary_control' else list(oracle.T_FIELDS))
    return {'Struct': [{'names': names, 'dtypes': [{'Primitive': ['i64', not n.endswith('id')]} for n in names]}, False]}

def index_bytes(keys):
    keys = [tuple(key) for key in keys if None not in key]
    if not keys:
        return 0
    capacity = lambda size: max(8, 1 << (size - 1).bit_length())
    unique = len(set(keys))
    return 8 * max(16, 1 << (2 * unique - 1).bit_length()) + 24 * capacity(unique) + 16 * capacity(len(keys))

def integer_hash(key):
    # native_relational_keys.rs:293-320; rustc-hash 2.1.3 src/lib.rs:76-196.
    mask = (1 << 64) - 1
    state = 0
    for value in key:
        assert type(value) is int
        for word in (1 if value < 0 else 2, value & mask):
            state = ((state + word) * 0xf1357aea2e62a9c5) & mask
    return ((state << 26) | (state >> 38)) & mask

def collision_free(keys):
    unique = set(keys)
    return len({integer_hash(key) for key in unique}) == len(unique)

def counters(cell, candidate):
    source = oracle.source(cell)
    r, s, t = (source[name] for name in ('r', 's', 't'))
    active = candidate and cell.startswith('cyclic_')
    r_b = 0 if cell == 'star_control' else 1
    groups = defaultdict(list)
    for row in s:
        if row[0] is not None:
            groups[row[0]].append(row)
    lower_keys = [(row[0],) for row in s if row[0] is not None]
    lower_queries = set()
    partials = lower_hits = upper_hits = final_rows = 0
    upper_keys = [(row[0],) if cell == 'star_control' else tuple(row[:2]) for row in t]
    upper_keys = [key for key in upper_keys if None not in key]
    upper_counts = Counter(upper_keys)
    upper_queries = set()
    for rr in r:
        if rr[r_b] is None or (active and rr[0] is None):
            continue
        lower_queries.add((rr[r_b],))
        matches = groups[rr[r_b]]
        lower_hits += bool(matches)
        partials += len(matches)
        for ss in matches:
            key = (rr[1],) if cell == 'star_control' else (rr[0], ss[1])
            if None not in key:
                upper_queries.add(key)
                upper_hits += key in upper_counts
                final_rows += upper_counts[key]
    assert collision_free(set(lower_keys) | lower_queries)
    assert collision_free(set(upper_keys) | upper_queries)
    lower = dict(build_rows=len(s), probe_rows=len(r),
                 exact_comparisons=len(lower_keys)-len(set(lower_keys))+lower_hits,
                 candidate_assignments=partials, index_capacity_bytes=index_bytes(lower_keys),
                 output_rows=0 if active else partials)
    upper = dict(build_rows=len(t), probe_rows=partials,
                 exact_comparisons=len(upper_keys)-len(set(upper_keys))+upper_hits,
                 candidate_assignments=final_rows, index_capacity_bytes=index_bytes(upper_keys), output_rows=final_rows)
    return lower, upper

def grid(stage):
    cells = list(oracle.CELLS)
    records = []
    if stage == 'preflight':
        for cell in cells:
            for calls in (1, 4):
                for candidate in (False, True):
                    records.append((cell, calls, candidate, None, False))
    else:
        assert stage in ('A', 'B')
        reverse = stage == 'B'
        if reverse:
            cells.reverse()
        for cell in cells:
            for candidate in ((True, False) if reverse else (False, True)):
                records.append((cell, 4, candidate, None, True))
        for cell in cells:
            for calls in ((4, 1) if reverse else (1, 4)):
                for sample in range(3):
                    first = bool(sample % 2) != reverse
                    for candidate in (first, not first):
                        records.append((cell, calls, candidate, sample, False))
    return records

class Verifier:
    def __init__(self, references, witnesses):
        self.references, self.witnesses = references, witnesses
        self.cache = {}
        self.reference = {}
        self.reference_sha = {}
        self.counts = {}
        oracle._self_check()
        manifest = json.loads((references / 'manifest.json').read_bytes())
        assert manifest['protocol'] == PROTOCOL and manifest['oracle_sha256'] == ORACLE_SHA
        assert set(manifest['files']) == set(oracle.CELLS)
        for cell in oracle.CELLS:
            entry = manifest['files'][cell]
            assert entry['file'] == f'{cell}.json'
            data = (references / entry['file']).read_bytes()
            assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
            ref = json.loads(data)
            assert same_json(ref, dict(cell=cell, sources=oracle.source(cell), rows=oracle.expected(cell), schema=schema(cell)))
            assert len(ref['rows']) == entry['row_count']
            self.reference[cell], self.reference_sha[cell] = ref, sha(data)
            for candidate in (False, True):
                self.counts[cell, candidate] = counters(cell, candidate)
        assert manifest['source_row_count'] == sum(len(rows) for ref in self.reference.values() for rows in ref['sources'].values())

    def witness(self, metadata, suffix):
        name = metadata['file']
        assert type(metadata['bytes']) is int and metadata['bytes'] >= 0
        assert re.fullmatch(r'[a-f0-9]{64}\.' + re.escape(suffix), name)
        assert name == metadata['sha256'] + '.' + suffix
        if name not in self.cache:
            path = self.witnesses / name
            assert not path.is_symlink()
            data = path.read_bytes()
            assert sha(data) == metadata['sha256'] and len(data) == metadata['bytes']
            parsed = [json.loads(line) for line in data.splitlines()] if suffix == 'jsonl' else json.loads(data)
            self.cache[name] = (sha(data), len(data), parsed)
        digest, size, value = self.cache[name]
        assert digest == metadata['sha256'] and size == metadata['bytes']
        return value

    def record(self, row, stage, sequence, expected):
        assert 'error' not in row
        cell, calls, candidate, sample, warmup = expected
        assert (row['cell'],row['calls'],row['candidate'],row['sample'],row['warmup']) == expected
        assert type(row['candidate']) is bool and type(row['warmup']) is bool
        assert type(row['calls']) is int and type(row['sequence']) is int
        assert row['sample'] is None or type(row['sample']) is int
        assert row['protocol'] == PROTOCOL and row['stage'] == stage and row['sequence'] == sequence
        ref = self.reference[cell]
        assert row['reference_sha256'] == self.reference_sha[cell]
        assert same_json(self.witness(row['source_witness'], 'sources.json'), ref['sources'])
        assert row['completed_executions'] == calls
        active = candidate and cell.startswith('cyclic_')
        assert row['activation_count'] == (calls if active else 0)
        assert row['reserved_after_cleanup'] == row['denied_reservations'] == 0
        for key in ('reserved_after_cleanup','denied_reservations','prepared_reserved_bytes','peak_reserved_bytes','completed_executions','activation_count'):
            assert type(row[key]) is int
        assert 0 < row['prepared_reserved_bytes'] <= row['peak_reserved_bytes'] <= 64 << 20
        operations = row['operations']
        assert len(operations) == calls
        for call, operation in enumerate(operations):
            assert operation['call'] == call and operation['activation_count'] == (call + 1 if active else 0)
            assert operation['rows_valid'] is True and operation['schema_valid'] is True
            assert same_json(self.witness(operation['output_witness'], 'jsonl'), ref['rows'])
            assert same_json(self.witness(operation['schema_witness'], 'schema.json'), ref['schema'])
            assert operation['output_rows'] == len(ref['rows'])
            assert operation['certified'] is True and operation['fallback_attempted'] is False
            assert operation['prepared_sources'] == (2 if cell == 'binary_control' else 3)
            for key in ('engine_execution_ns','serialization_ns','collect_ns','result_release_ns'):
                assert type(operation[key]) is int and 0 < operation[key] < 600_000_000_000
            assert operation['engine_execution_ns'] + operation['serialization_ns'] <= operation['collect_ns']
            if stage == 'preflight':
                self.stages(cell, candidate, operation['stages'])
            else:
                assert operation['stages'] is None, 'scored and warmup observers must be disabled'
        for field in ('engine_execution_ns','collect_ns','result_release_ns'):
            assert row[field] == sum(op[field] for op in operations)
        for key in ('preparation_ns','destruction_ns','complete_ns'):
            assert type(row[key]) is int and 0 < row[key] < 600_000_000_000
        assert row['complete_ns'] == sum(row[k] for k in ('preparation_ns','collect_ns','result_release_ns','destruction_ns'))

    def stages(self, cell, candidate, stages):
        assert len(stages) == (1 if cell == 'binary_control' else 2)
        expected = self.counts[cell, candidate]
        for index, fields in enumerate((oracle.RS_FIELDS, oracle.RS_FIELDS + oracle.T_FIELDS)):
            if index and cell == 'binary_control':
                break
            stage = next(item for item in stages if item['fields'] == list(fields))
            left_keys = (['x'] if cell == 'star_control' else ['y']) if index == 0 else (['rb'] if cell == 'star_control' else ['ra','sc'])
            right_keys = ['x'] if index == 0 or cell == 'star_control' else ['x','y']
            assert stage['left_keys'] == left_keys and stage['right_keys'] == right_keys
            stats = stage['stats']
            assert all(type(value) is int and value >= 0 for value in stats.values())
            for key, value in expected[index].items():
                assert stats[key] == value, (cell,candidate,index,key,stats[key],value)
            if stats['output_rows'] == 0:
                assert stats['output_batches'] == stats['delivered_array_bytes'] == 0
            else:
                assert 0 < stats['output_batches'] <= stats['output_rows'] and stats['delivered_array_bytes'] > 0

    def records(self, rows, stage):
        expected = grid(stage)
        assert len(rows) == len(expected)
        for i, (row, entry) in enumerate(zip(rows, expected)):
            self.record(row, stage, i, entry)

def costs(rows):
    comparisons = []
    for cell in oracle.CELLS:
        for calls in (1, 4):
            roles = {candidate: [row for row in rows if row['cell']==cell and row['calls']==calls and row['candidate']==candidate and not row['warmup']] for candidate in (False,True)}
            assert all(len(role) == 3 for role in roles.values())
            medians = {str(candidate): {key: statistics.median(row[key] for row in role) for key in ('engine_execution_ns','complete_ns','peak_reserved_bytes')} for candidate,role in roles.items()}
            ordinary, candidate = medians['False'], medians['True']
            target = cell in ('cyclic_sparse','cyclic_empty','cyclic_skew')
            numerator, denominator = (9,10) if target else (21,20)
            threshold = numerator/denominator
            ratios = {key: candidate[key]/ordinary[key] for key in ('engine_execution_ns','complete_ns')}
            gates = {key: candidate[key]*denominator <= ordinary[key]*numerator for key in ratios}
            gates['native_peak'] = candidate['peak_reserved_bytes']*10 <= ordinary['peak_reserved_bytes']*11 + (256<<10)*10
            comparisons.append(dict(cell=cell,calls=calls,medians=medians,ratios=ratios,threshold=threshold,gates=gates,passed=all(gates.values())))
    return comparisons

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=('preflight','A','B'))
    parser.add_argument('references',type=Path)
    parser.add_argument('witnesses',type=Path)
    parser.add_argument('records',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    raw=args.records.read_bytes()
    rows=[json.loads(line) for line in raw.splitlines()]
    verifier=Verifier(args.references,args.witnesses)
    verifier.records(rows,args.stage)
    base=next((i,row) for i,row in enumerate(rows) if row['cell']=='cyclic_small' and row['candidate'])
    sequence, original=base
    mutations=[lambda row: row.update(reserved_after_cleanup=1),lambda row: row.update(activation_count=0),
        lambda row: row['operations'].pop(),lambda row: row.update(complete_ns=row['complete_ns']+1),
        lambda row: row['operations'][0].update(fallback_attempted=True),
        lambda row: row['operations'][0]['output_witness'].update(sha256='0'*64),
        lambda row: row['operations'][0].update(schema_valid=False),
        lambda row: row['source_witness'].update(bytes=row['source_witness']['bytes']+1),
        lambda row: row.update(reference_sha256='0'*64),lambda row: row.update(calls=2)]
    if args.stage=='preflight':
        mutations += [lambda row: row['operations'][0]['stages'][0]['stats'].update(exact_comparisons=0),
                      lambda row: row['operations'][0]['stages'][0]['stats'].update(delivered_array_bytes=1)]
    else:
        mutations += [lambda row: row['operations'][0].update(stages=[])]
    for mutate in mutations:
        altered=copy.deepcopy(original)
        mutate(altered)
        try:
            verifier.record(altered,args.stage,sequence,grid(args.stage)[sequence])
        except (AssertionError,KeyError,StopIteration):
            continue
        raise AssertionError('validator accepted a malformed control')
    semantic_mutations = 0
    for metadata, mutate in (
        (original['operations'][0]['output_witness'], lambda value: value.reverse()),
        (original['operations'][0]['output_witness'], lambda value: value[0].update(tid=999)),
        (original['operations'][0]['output_witness'], lambda value: value[0].update(tid=float(value[0]['tid']))),
        (original['operations'][0]['output_witness'], lambda value: value.pop()),
        (original['operations'][0]['schema_witness'], lambda value: value['Struct'][0]['dtypes'][0]['Primitive'].__setitem__(0,'u64')),
        (original['source_witness'], lambda value: value['r'][0].__setitem__(0,999)),
    ):
        # Exercise semantic rejection separately from the file-integrity gate,
        # which the mismatched digest/byte controls above test independently.
        key = metadata['file']
        saved = verifier.cache[key]
        changed = copy.deepcopy(saved[2])
        mutate(changed)
        verifier.cache[key] = (saved[0], saved[1], changed)
        rejected = False
        try:
            verifier.record(original,args.stage,sequence,grid(args.stage)[sequence])
        except (AssertionError,KeyError,StopIteration):
            rejected = True
        finally:
            verifier.cache[key] = saved
        assert rejected, 'validator accepted a malformed complete witness'
        semantic_mutations += 1
    comparisons=[] if args.stage=='preflight' else costs(rows)
    result=dict(status='passed',stage=args.stage,protocol=PROTOCOL,records_sha256=sha(raw),oracle_sha256=ORACLE_SHA,
        verifier_sha256=sha(Path(__file__).read_bytes()),reference_manifest_sha256=sha((args.references/'manifest.json').read_bytes()),
        workflows=len(rows),queries=sum(row['calls'] for row in rows),scored_workflows=sum(not row['warmup'] for row in rows) if args.stage!='preflight' else 0,
        complete_output_rows_checked=sum(operation['output_rows'] for row in rows for operation in row['operations']),
        unique_witnesses_checked=len(verifier.cache),negative_controls_rejected=len(mutations)+semantic_mutations,comparisons=comparisons,
        quantitative_gates_passed=all(row['passed'] for row in comparisons) if comparisons else None,
        failed_gates=[dict(cell=row['cell'],calls=row['calls'],gate=gate,ratio=row['ratios'].get(gate),threshold=row['threshold']) for row in comparisons for gate,passed in row['gates'].items() if not passed])
    with args.output.open('x') as stream:
        json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps({key:value for key,value in result.items() if key!='comparisons'}))

if __name__=='__main__':
    main()
