"""Retain the two historical script versions by reversing their known edits.

The pre-existing build binding authenticates the reconstructed bytes. Neither
version drove scored observations; they are preserved for complete provenance.
"""
import base64
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
binding = json.loads((root / 'multiway-probe-binding-818b.json').read_bytes())

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

binder = (root / 'bind_multiway_818.py').read_text()
binder = replace(binder,
    "       OUT/'run_guarded.py',OUT/'native_workload_guard_816.py',OUT/'run_multiway_stage_818.py',\n"
    "       OUT/'multiway-counter-sources-818.json',Path(__file__)]\n"
    "files.extend(sorted((OUT/'multiway-references-818a').glob('*.json')))\n",
    "       OUT/'run_guarded.py',OUT/'native_workload_guard_816.py',OUT/'multiway-references-818a/manifest.json',Path(__file__)]\n")
verifier = (root / 'verify_multiway_screen_818.py').read_text()
verifier = replace(verifier,
    "\ndef same_json(left, right):\n"
    "    # Python's ordinary equality equates True, 1 and 1.0. The native transport\n"
    "    # must retain its exact scalar and schema representation as well as values.\n"
    "    encode=lambda value: json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)\n"
    "    return encode(left)==encode(right)\n", '')
for old, new in (
    ("assert same_json(ref, dict(cell=cell, sources=oracle.source(cell), rows=oracle.expected(cell), schema=schema(cell)))",
     "assert ref == dict(cell=cell, sources=oracle.source(cell), rows=oracle.expected(cell), schema=schema(cell))"),
    ("assert same_json(self.witness(row['source_witness'], 'sources.json'), ref['sources'])",
     "assert self.witness(row['source_witness'], 'sources.json') == ref['sources']"),
    ("assert same_json(self.witness(operation['output_witness'], 'jsonl'), ref['rows'])",
     "assert self.witness(operation['output_witness'], 'jsonl') == ref['rows']"),
    ("assert same_json(self.witness(operation['schema_witness'], 'schema.json'), ref['schema'])",
     "assert self.witness(operation['schema_witness'], 'schema.json') == ref['schema']"),
    ("        assert type(metadata['bytes']) is int and metadata['bytes'] >= 0\n", ''),
    ("        assert type(row['calls']) is int and type(row['sequence']) is int\n"
     "        assert row['sample'] is None or type(row['sample']) is int\n", ''),
    ("        for key in ('reserved_after_cleanup','denied_reservations','prepared_reserved_bytes','peak_reserved_bytes','completed_executions','activation_count'):\n"
     "            assert type(row[key]) is int\n", ''),
    ("            assert all(type(value) is int and value >= 0 for value in stats.values())\n", ''),
    ("        (original['operations'][0]['output_witness'], lambda value: value[0].update(tid=float(value[0]['tid']))),\n", ''),
    ("            target = cell in ('cyclic_sparse','cyclic_empty','cyclic_skew')\n"
     "            numerator, denominator = (9,10) if target else (21,20)\n"
     "            threshold = numerator/denominator\n",
     "            threshold = 0.9 if cell in ('cyclic_sparse','cyclic_empty','cyclic_skew') else 1.05\n"),
    ("            gates = {key: candidate[key]*denominator <= ordinary[key]*numerator for key in ratios}\n"
     "            gates['native_peak'] = candidate['peak_reserved_bytes']*10 <= ordinary['peak_reserved_bytes']*11 + (256<<10)*10\n",
     "            gates = {key: ratios[key] <= threshold for key in ratios}\n"
     "            gates['native_peak'] = candidate['peak_reserved_bytes'] <= 1.1*ordinary['peak_reserved_bytes'] + (256<<10)\n"),
):
    verifier = replace(verifier, old, new)
members = []
for name, text in (('bind_multiway_818.py', binder), ('verify_multiway_screen_818.py', verifier)):
    raw = text.encode()
    path = str(root / name)
    expected = binding['files'][path]
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == expected['sha256'] and len(raw) == expected['bytes'], (name, digest, expected)
    members.append(dict(path=path, bytes=len(raw), sha256=digest, base64=base64.b64encode(raw).decode()))
target = root / 'multiway-historical-scripts-818b.json'
with target.open('x') as stream:
    json.dump(dict(binding_sha256=hashlib.sha256((root/'multiway-probe-binding-818b.json').read_bytes()).hexdigest(),
                   verification='exact pre-existing binding digests', members=members), stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status='passed', historical_scripts=len(members), output=str(target))))
