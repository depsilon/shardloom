"""Small path and integrity helpers shared by the finite multiway acceptance packet."""
import hashlib
import json
from pathlib import Path

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
E = Path(__file__).resolve().parent
P = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
RUSTUP = '/Users/dylan/.cargo/bin/rustup'
GUARD = E / 'run_guarded.py'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
