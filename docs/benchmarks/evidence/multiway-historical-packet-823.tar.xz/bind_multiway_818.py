"""Bind a completed optimized build to every unchanged input and protocol."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT=Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

parser=argparse.ArgumentParser()
parser.add_argument('build')
parser.add_argument('output')
args=parser.parse_args()
manifest_path=OUT/f'{args.build}-input.json'
manifest=json.loads(manifest_path.read_bytes())
assert sha(Path(manifest['source_archive']))==manifest['source_archive_sha256']
for path,expected in manifest['files'].items():
    actual=ROOT/path
    assert actual.is_file() and actual.stat().st_size==expected['bytes'] and sha(actual)==expected['sha256'],path
receipt_path=OUT/f'{args.build}.json'
receipt=json.loads(receipt_path.read_bytes())
assert receipt['status']=='passed' and receipt['returncode']==0 and receipt['process_group_drained'] is True
assert receipt['head']==manifest['base_commit'] and receipt['cwd']==str(ROOT)
log_path=OUT/f'{args.build}.log'
assert receipt['log_sha256']==sha(log_path)
events=[json.loads(line) for line in log_path.read_text().splitlines() if line.startswith('{')]
assert events[-1]=={'reason':'build-finished','success':True}
artifacts=[event for event in events if event.get('reason')=='compiler-artifact' and event['target']['name']=='shardloom_vortex' and event.get('executable')]
assert len(artifacts)==1
artifact=artifacts[0]
assert artifact['profile']['test'] is True and artifact['profile']['opt_level']=='3' and artifact['fresh'] is False
assert 'release-user-surfaces' in artifact['features']
binary=Path(artifact['executable'])
assert binary.is_file() and binary.is_relative_to(Path(receipt['environment']['CARGO_TARGET_DIR'])/'release')
files=[manifest_path,receipt_path,log_path,Path(manifest['source_archive']),
       ROOT/'docs/architecture/native-multiway-join-intake-2026-10-20.md',
       ROOT/'docs/architecture/native-multiway-join-comparison-design-2026-10-20.md',
       ROOT/'docs/architecture/native-multiway-join-admission-2026-10-20.md',
       OUT/'multiway_reference_817.py',OUT/'generate_multiway_references_818.py',OUT/'verify_multiway_screen_818.py',
       OUT/'run_guarded.py',OUT/'native_workload_guard_816.py',OUT/'run_multiway_stage_818.py',
       OUT/'multiway-counter-sources-818.json',Path(__file__)]
files.extend(sorted((OUT/'multiway-references-818a').glob('*.json')))
binding={'protocol':'multiway-probe-817-v1','head':manifest['base_commit'],
         'manifest':str(manifest_path),'manifest_sha256':sha(manifest_path),'input_files_checked':len(manifest['files']),
         'binary':str(binary),'binary_sha256':sha(binary),'binary_bytes':binary.stat().st_size,
         'artifact':artifact,'files':{str(path):{'sha256':sha(path),'bytes':path.stat().st_size} for path in files}}
with (OUT/args.output).open('x') as stream:
    json.dump(binding,stream,sort_keys=True,indent=2);stream.write('\n')
print(json.dumps({key:value for key,value in binding.items() if key not in ('files','artifact')}))
