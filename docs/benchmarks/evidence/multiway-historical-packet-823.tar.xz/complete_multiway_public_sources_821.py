#!/usr/bin/env python3
"""Add portable content blobs for the immutable accepted public-source mapping."""

from __future__ import annotations

import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import sys

EVIDENCE = Path("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
ROOT = Path("/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo")
OUT = EVIDENCE / "multiway-source-portability-821"
BLOBS = OUT / "blobs"
SOURCE_RECORD = EVIDENCE / "multiway-acceptance-source-820.json"
VERSIONS = OUT / "versions.json"
PUBLIC_MAP = OUT / "public-sources.json"
ARCHIVE = EVIDENCE / "multiway-integration-build-819a-source.json.xz"
MAX_SOURCE_BYTES = 16 * 1024 * 1024
ALLOWED_SUFFIXES = {
    ".rs", ".py", ".pyi", ".toml", ".json", ".yml", ".yaml",
    ".sh", ".txt", ".lock", ".sql", ".md", ".ini", ".conf", ".gitignore",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def text_source(path: str, data: bytes) -> None:
    if len(data) > MAX_SOURCE_BYTES:
        raise RuntimeError(f"source exceeds text-size limit: {path} ({len(data)} bytes)")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise RuntimeError(f"refusing non-UTF-8/binary payload: {path}") from error


def relative_path(name: str) -> Path:
    p = PurePosixPath(name)
    if p.is_absolute() or not name or any(part in ("", ".", "..") for part in p.parts):
        raise RuntimeError(f"unsafe source-map path: {name!r}")
    return Path(*p.parts)


def main() -> None:
    if not OUT.is_dir() or not BLOBS.is_dir():
        raise RuntimeError(f"821 source snapshot is missing: {OUT}")
    if PUBLIC_MAP.exists() or PUBLIC_MAP.is_symlink():
        raise RuntimeError(f"refusing to replace existing mapping: {PUBLIC_MAP}")

    sys.path.insert(0, str(ROOT / "scripts"))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    require_local_path(EVIDENCE, Path.home(), sys.platform)
    require_local_path(OUT, Path.home(), sys.platform)
    storage_before = check_budgets(
        EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
        reserve_bytes=64 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
    )

    source_bytes = SOURCE_RECORD.read_bytes()
    source_identity = {"bytes": len(source_bytes), "sha256": digest(source_bytes)}
    source = json.loads(source_bytes)
    expected_sources = source["source_hashes"]
    if not isinstance(expected_sources, dict) or len(expected_sources) != 2227:
        raise RuntimeError("immutable accepted source record does not contain exactly 2,227 paths")

    versions_bytes = VERSIONS.read_bytes()
    versions_sha = digest(versions_bytes)
    versions = json.loads(versions_bytes)
    recorded = versions["accepted_public_sources"]
    if (recorded["record_sha256"] != source_identity["sha256"]
            or recorded["record_bytes"] != source_identity["bytes"]
            or recorded["source_hash_count"] != len(expected_sources)):
        raise RuntimeError("accepted source record differs from the immutable snapshot identity")
    original_versions_helper_sha = versions["helper_sha256"]

    archive_bytes = ARCHIVE.read_bytes()
    archive = json.loads(lzma.decompress(archive_bytes))
    archived_untracked = archive["untracked"]

    before_names = set()
    for entry in BLOBS.iterdir():
        if entry.is_symlink() or not entry.is_file():
            raise RuntimeError(f"unexpected non-file in blob store: {entry}")
        before_names.add(entry.name)

    resolved = {}
    additions = {}
    mismatches = []
    for name, expected_sha in sorted(expected_sources.items()):
        relative = relative_path(name)
        if relative.suffix.lower() not in ALLOWED_SUFFIXES:
            mismatches.append({"path": name, "reason": "outside_text_source_allowlist"})
            continue
        blob = BLOBS / expected_sha
        if blob.exists():
            if blob.is_symlink() or not blob.is_file():
                mismatches.append({"path": name, "reason": "blob_path_not_regular"})
                continue
            data = blob.read_bytes()
            text_source(name, data)
            actual = digest(data)
            if actual != expected_sha:
                mismatches.append({"path": name, "reason": "existing_blob_digest_mismatch",
                                   "expected_sha256": expected_sha, "observed_sha256": actual})
                continue
            resolved[name] = {
                "bytes": len(data), "sha256": expected_sha,
                "blob": f"blobs/{expected_sha}", "source": "existing_content_blob",
            }
            continue

        candidate = None
        source_kind = None
        worktree_path = ROOT / relative
        if worktree_path.is_file() and not worktree_path.is_symlink():
            data = worktree_path.read_bytes()
            text_source(name, data)
            if digest(data) == expected_sha:
                candidate, source_kind = data, "worktree_exact_sha256"
        if candidate is None and name in archived_untracked:
            archived_text = archived_untracked[name]
            if isinstance(archived_text, str):
                data = archived_text.encode("utf-8")
                text_source(name, data)
                if digest(data) == expected_sha:
                    candidate, source_kind = data, str(ARCHIVE)
        if candidate is None:
            mismatches.append({
                "path": name, "reason": "no_exact_blob_worktree_or_819a_untracked_source",
                "expected_sha256": expected_sha,
                "worktree_sha256": (digest(worktree_path.read_bytes())
                                     if worktree_path.is_file() and not worktree_path.is_symlink()
                                     else None),
                "archive_untracked_present": name in archived_untracked,
            })
            continue
        additions[expected_sha] = candidate
        resolved[name] = {
            "bytes": len(candidate), "sha256": expected_sha,
            "blob": f"blobs/{expected_sha}", "source": source_kind,
        }

    if mismatches:
        raise RuntimeError(
            "accepted source blobs could not be resolved; no blobs or mapping were written: "
            + json.dumps(mismatches[:30], sort_keys=True)
        )

    for expected_sha, data in additions.items():
        target = BLOBS / expected_sha
        if target.exists():
            if target.is_symlink() or not target.is_file() or file_digest(target) != expected_sha:
                raise RuntimeError(f"blob appeared with incorrect identity during write: {target}")
            continue
        with target.open("xb") as stream:
            stream.write(data)

    union_names = set()
    union_bytes = 0
    for path in BLOBS.iterdir():
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"unexpected non-file in final blob store: {path}")
        data = path.read_bytes()
        if digest(data) != path.name:
            raise RuntimeError(f"final blob failed content-addressed verification: {path}")
        text_source(path.name, data)
        union_names.add(path.name)
        union_bytes += len(data)

    for name, entry in resolved.items():
        blob = OUT / entry["blob"]
        if not blob.is_file() or blob.is_symlink():
            raise RuntimeError(f"mapping refers to missing or unsafe blob: {name}")
        data = blob.read_bytes()
        if len(data) != entry["bytes"] or digest(data) != expected_sources[name]:
            raise RuntimeError(f"mapping/blob verification failed: {name}")

    if digest(VERSIONS.read_bytes()) != versions_sha:
        raise RuntimeError("existing versions.json changed during repair")
    if digest(SOURCE_RECORD.read_bytes()) != source_identity["sha256"]:
        raise RuntimeError("immutable accepted source record changed during repair")
    if versions["helper_sha256"] != original_versions_helper_sha:
        raise RuntimeError("existing source-reconstruction helper identity changed")

    after_budget = check_budgets(
        EVIDENCE, OUT, OUT / "logs", min_free_bytes=12 * GIB,
        reserve_bytes=0, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=128 * MIB,
    )
    result = {
        "schema": "multiway-public-sources-821-v1",
        "repair_helper_sha256": digest(Path(__file__).read_bytes()),
        "accepted_source_record": {
            "path": str(SOURCE_RECORD),
            **source_identity,
            "source_commit": source.get("source_commit"),
            "source_hash_count": len(expected_sources),
            "verified_count": len(resolved),
            "files": resolved,
        },
        "source_reconstruction_versions_sha256": versions_sha,
        "source_reconstruction_helper_sha256": original_versions_helper_sha,
        "blob_union": {
            "existing_blob_count_before_repair": len(before_names),
            "existing_accepted_source_digest_count": len(before_names & set(expected_sources.values())),
            "new_blob_count": len(additions),
            "accepted_source_digest_count": len(set(expected_sources.values())),
            "final_blob_count": len(union_names),
            "final_blob_bytes": union_bytes,
        },
        "storage_check_before": storage_before,
        "storage_check_after": after_budget,
        "verification": {
            "all_source_hashes_resolved": len(resolved) == len(expected_sources),
            "all_references_verified_after_write": True,
            "existing_versions_json_unchanged": True,
            "original_source_record_unchanged": True,
            "unresolved_paths": [],
        },
    }
    with PUBLIC_MAP.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({
        "status": "complete",
        "mapping": str(PUBLIC_MAP),
        "mapping_sha256": file_digest(PUBLIC_MAP),
        "source_paths": len(resolved),
        "existing_accepted_source_digests": result["blob_union"]["existing_accepted_source_digest_count"],
        "new_blobs": len(additions),
        "final_blob_count": len(union_names),
        "final_blob_bytes": union_bytes,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
