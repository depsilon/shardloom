"""Close the finite multiway decision only after normal public acceptance."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import multiway_acceptance_common_820 as d

E, W = d.E, d.W
HEAD = '563c91260a526f6b02ab9bbb171dd9bfb8c4c2f0'
checked = {}


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=value)


def check(row):
    assert identity(row['path']) == row, row['path']
    checked[row['path']] = row
    return Path(row['path'])


def references(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'} and Path(value['path']).is_absolute():
            check(value)
        else:
            for child in value.values():
                references(child)
    elif isinstance(value, list):
        for child in value:
            references(child)


def receipt(name, status='passed'):
    path, log = E / f'{name}.json', E / f'{name}.log'
    value = read(path)
    assert value['status'] == status and value['process_group_drained'] and value['direct_child_reaped']
    assert value['head'] == HEAD and value['log_sha256'] == identity(log)['sha256']
    assert (value['returncode'] == 0) == (status == 'passed')
    result = dict(receipt=identity(path), log=identity(log))
    references(result)
    return result


def verify_source():
    subprocess.run([sys.executable, '-B', str(E / 'multiway_projected_acceptance_821.py'), 'verify'],
                   cwd=W, check=True)


def main():
    verify_source()
    source_path = E / 'multiway-projected-acceptance-source-821.json'
    build_path = E / 'multiway-projected-acceptance-build-821.json'
    source, build = read(source_path), read(build_path)
    assert build['source_commit'] == source['source_commit'] == HEAD
    assert build['source_hashes'] == source['source_hashes']
    assert build['working_tree'] == source['working_tree']
    assert build['publication_attempted'] is False
    assert identity(build['binary'])['sha256'] == build['binary_sha256']
    check(build['native_library'])
    for artifact in (build['cli_compiler_artifact'], build['native_compiler_artifact']):
        assert artifact['fresh'] is False
        assert artifact['profile']['opt_level'] == '3' and artifact['profile']['test'] is False
        assert 'release-user-surfaces' in artifact['features']
    references(build['build_receipts'])
    check(build['source_manifest'])
    comparisons = {}
    for family, prefix, suffix in [('prototype', 'multiway', '819a'),
                                  ('integrated', 'multiway-integrated', '820a'),
                                  ('projected', 'multiway-projected', '821a')]:
        group = {}
        for stage, label in [('preflight', 'preflight'), ('A', 'cohortA'), ('B', 'cohortB')]:
            name = f'{prefix}-{label}-{suffix}'
            result_path = E / f'{name}-verified.json'
            result = read(result_path)
            assert result['status'] == 'passed' and result['stage'] == stage
            assert result['protocol'] == 'multiway-probe-817-v1'
            assert result['queries'] == (80 if stage == 'preflight' else 304)
            assert result['workflows'] == (32 if stage == 'preflight' else 112)
            assert result['records_sha256'] == identity(E / f'{name}-results.jsonl')['sha256']
            if stage != 'preflight':
                assert result['quantitative_gates_passed'] is True
                assert len(result['comparisons']) == 16
                assert all(row['passed'] for row in result['comparisons'])
            group[stage] = dict(verification=identity(result_path),
                records=identity(E / f'{name}-results.jsonl'),
                invocation=identity(E / f'{name}-invocation.json'), run=receipt(name))
        comparisons[family] = group
    references(comparisons)

    gates_path = E / 'multiway-projected-integration-gates-821.json'
    gates = read(gates_path)
    assert gates['status'] == 'passed' and gates['sources_unchanged']
    assert (gates['native_tests'], gates['native_ignored'], gates['workspace_tests']) == (3049, 32, 3235)
    assert gates['source'] == identity(source_path)
    references(gates)
    for name in ('multiway-projected-native-all-tests-821a', 'multiway-projected-workspace-fmt-821a',
                 'multiway-projected-workspace-clippy-821a', 'multiway-projected-workspace-tests-821a',
                 'multiway-projected-workspace-native-clippy-821a'):
        receipt(name)
    native_log = (E / 'multiway-projected-native-all-tests-821a.log').read_text()
    assert 'test result: ok. 3049 passed; 0 failed; 32 ignored;' in native_log
    workspace = re.findall(r'test result: ok\. (\d+) passed; 0 failed;',
                           (E / 'multiway-projected-workspace-tests-821a.log').read_text())
    assert sum(map(int, workspace)) == 3235

    cli_path = E / 'multiway-projected-public-cli-tests-821-verified.json'
    cli = read(cli_path)
    assert (cli['status'], cli['tests'], cli['public_commands']) == ('passed', 1, 16)
    assert cli['source'] == identity(source_path) and cli['build'] == identity(build_path)
    references(cli)
    receipt('multiway-projected-public-cli-tests-821')
    assert 'test result: ok. 1 passed; 0 failed;' in (E / 'multiway-projected-public-cli-tests-821.log').read_text()

    installed_path = E / 'multiway-projected-installed-python-821.json'
    installed = read(installed_path)
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['tests'] == 113 and installed['skipped'] == 0
    assert installed['sources_unchanged'] and installed['artifacts_unchanged']
    assert installed['publication_attempted'] is False
    references(installed)
    proof_path = check(installed['report'])
    proof = read(proof_path)
    assert proof['integration'] == dict(tests=113, failures=0, errors=0, skipped=0, status='passed')
    assert proof['installed_load']['isolated_install']
    assert proof['status'] == proof['uninstall_status'] == 'passed'
    assert proof['integrity']['native_library_sha256'] == build['native_library']['sha256']
    assert proof['integrity']['cli_sha256'] == build['binary_sha256']
    for step in proof['steps']:
        assert step['returncode'] == 0 and Path(step['log']).name == step['log']
        assert identity(proof_path.parent / step['log'])['sha256'] == step['log_sha256']

    acceptance = {}
    for phase in ('public', 'full43', 'modular'):
        path = E / f'multiway-projected-acceptance-{phase}-verified-821.json'
        value = read(path)
        assert value['status'] == 'passed' and value['phase'] == phase
        assert value['source_commit'] == HEAD and value['working_tree'] == build['working_tree']
        assert value['performance_claim'] is False
        references(value)
        receipt(f'multiway-projected-{phase}-821')
        acceptance[phase] = value
    assert (acceptance['public']['families'], acceptance['public']['cases']) == (39, 5930)
    assert (acceptance['full43']['queries'], acceptance['full43']['calls'],
            acceptance['full43']['complete_rows']) == (43, 43, 381)
    assert (acceptance['modular']['cohorts'], acceptance['modular']['native_workflows'],
            acceptance['modular']['independent_pandas_oracle_workflows']) == (18, 704, 704)
    verify_source()
    historical_failure = check(identity(E / 'multiway-public-projection-correction-821.json'))
    d.save(E / 'multiway-projected-final-acceptance-822.json', dict(
        schema_version='shardloom.multiway_acceptance.v1', status='passed',
        outcome='retain_finite_materialized_integer_three_input_probe_with_bound_projection', production_accepted=True,
        projection_admission='one bound pure-column selection/alias projection',
        source_commit=HEAD, working_tree=source['working_tree'], commit_alone_reproduces_sources=False,
        source=identity(source_path), build=identity(build_path), comparisons=comparisons,
        integration_gates=identity(gates_path), public_cli=identity(cli_path),
        installed_python=identity(installed_path),
        acceptance={phase: identity(E / f'multiway-projected-acceptance-{phase}-verified-821.json') for phase in acceptance},
        historical_public_failure_record=identity(historical_failure),
        public_cases=5930, public_families=39, installed_binding_tests=113,
        full43_engine_execution_seconds=acceptance['full43']['engine_execution_seconds'],
        verified_file_references=list(checked.values()), finalizer=identity(__file__),
        broad_cpu_speedup_claim=False, final_package_comparative_timing=False,
        whole_process_memory_limit_claim=False, publication_attempted=False,
        broader_owner_remains_open=True,
        claim_scope='The frozen eight-cell comparison passes for the bounded materialized integer three-input probe, and the projected comparison admits one bound pure-column selection/alias projection. The integrated runtime passes current-host public correctness acceptance. No general multiway, encoded-source, spill, broad engine speed, release or cross-platform claim.'))
    print(json.dumps(dict(status='passed', outcome='retain_finite_materialized_integer_three_input_probe_with_bound_projection',
                          production_accepted=True, projection_admission='one bound pure-column selection/alias projection',
                          public_cases=5930, installed_binding_tests=113)))


if __name__ == '__main__':
    main()
