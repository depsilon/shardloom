#!/usr/bin/env python3
"""Independent finite oracle for the frozen PERF-10 multiway intake cells.

Uses only Python's standard library. This is reference code, not an engine path.
"""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from typing import Any


CELLS = (
    "cyclic_sparse",
    "cyclic_empty",
    "cyclic_skew",
    "cyclic_duplicates",
    "cyclic_dense",
    "cyclic_small",
    "star_control",
    "binary_control",
)

RS_FIELDS = ("ra", "rb", "rid", "sb", "sc", "sid")
T_FIELDS = ("ta", "tc", "tid")


def _pair(cell: str, relation: str, ordinal: int) -> tuple[int | None, int | None]:
    r = ordinal
    if cell in ("cyclic_sparse", "cyclic_empty"):
        if relation == "R":
            return r % 128, r // 128
        if relation == "S":
            return r % 32, r // 32
        c = 128 + (13 * r) % 128 if cell == "cyclic_empty" else (13 * r) % 128
        return r, c
    if cell == "cyclic_skew":
        if relation == "R":
            return r % 64, (0 if r % 4 != 0 else 1 + r % 7)
        if relation == "S":
            return (0 if r < 1536 else 1 + r % 7), r % 128
        return r, (13 * r) % 128
    if cell == "cyclic_duplicates":
        if relation == "R":
            x, y = (r // 2) % 32, (r // 64) % 8
            return (None if r % 37 == 0 else x, None if r % 41 == 0 else y)
        if relation == "S":
            x, y = (r // 2) % 8, (r // 16) % 32
            return (None if r % 43 == 0 else x, None if r % 47 == 0 else y)
        x, y = (r // 4) % 32, (7 * ((r // 2) % 2) + r // 4) % 32
        return (None if r % 53 == 0 else x, None if r % 59 == 0 else y)
    if cell == "cyclic_dense":
        return (r % 32, r // 32) if relation != "T" else (r % 32, r // 32)
    if cell == "cyclic_small":
        return r % 4, r // 4
    if cell == "star_control":
        if relation == "R":
            return r % 64, (r // 64) % 64
        if relation == "S":
            return r, 17 * r - 5
        return r, 19 * r - 7
    if cell == "binary_control":
        if relation == "R":
            return 17 * r - 3, r
        return r, 19 * r - 5
    raise ValueError(f"unknown cell: {cell}")


def _lengths(cell: str) -> tuple[int, int, int]:
    return {
        "cyclic_sparse": (4096, 4096, 128),
        "cyclic_empty": (4096, 4096, 128),
        "cyclic_skew": (1024, 2048, 64),
        "cyclic_duplicates": (512, 512, 128),
        "cyclic_dense": (1024, 1024, 1024),
        "cyclic_small": (16, 16, 16),
        "star_control": (4096, 64, 64),
        "binary_control": (8192, 8192, 0),
    }[cell]


def source(cell: str) -> dict[str, list[list[int | None]]]:
    """Return R/S/T rows as [x, y, id], with T empty for binary_control."""
    if cell not in CELLS:
        raise ValueError(f"unknown cell: {cell}")
    lengths = _lengths(cell)
    result: dict[str, list[list[int | None]]] = {}
    for relation, length in zip(("R", "S", "T"), lengths):
        result[relation.lower()] = [
            [*_pair(cell, relation, ordinal), ordinal] for ordinal in range(length)
        ]
    return result


def _rs_row(r: list[int | None], s: list[int | None]) -> dict[str, int | None]:
    return dict(zip(RS_FIELDS, (*r, *s)))


def _cyclic_inner_rows(
    relations: dict[str, list[list[int | None]]],
) -> list[dict[str, int | None]]:
    by_sx: dict[int, list[list[int | None]]] = defaultdict(list)
    for s in relations["s"]:
        if s[0] is not None:
            by_sx[s[0]].append(s)
    rows = []
    for r in relations["r"]:
        if r[1] is not None:
            rows.extend(_rs_row(r, s) for s in by_sx.get(r[1], ()))
    return rows


def expected_inner(cell: str) -> list[dict[str, int | None]]:
    """Expected ordinary first binary join, in R then matching S order."""
    relations = source(cell)
    if cell.startswith("cyclic_"):
        return _cyclic_inner_rows(relations)
    r_key = 0 if cell == "star_control" else 1
    s_key = 0
    by_key: dict[int, list[list[int | None]]] = defaultdict(list)
    for s in relations["s"]:
        if s[s_key] is not None:
            by_key[s[s_key]].append(s)
    rows = []
    for r in relations["r"]:
        if r[r_key] is not None:
            rows.extend(_rs_row(r, s) for s in by_key.get(r[r_key], ()))
    return rows


def expected(cell: str) -> list[dict[str, int | None]]:
    """Expected complete join rows in the intake's specified source order."""
    relations = source(cell)
    inner = expected_inner(cell)
    if cell == "binary_control":
        return inner
    if cell == "star_control":
        by_tx: dict[int, list[list[int | None]]] = defaultdict(list)
        for t in relations["t"]:
            if t[0] is not None:
                by_tx[t[0]].append(t)
        out = []
        for row in inner:
            if row["rb"] is None:
                continue
            for t in by_tx.get(row["rb"], ()):
                out.append({**row, "ta": t[0], "tc": t[1], "tid": t[2]})
        return out

    by_tac: dict[tuple[int, int], list[list[int | None]]] = defaultdict(list)
    for t in relations["t"]:
        if t[0] is not None and t[1] is not None:
            by_tac[(t[0], t[1])].append(t)
    out = []
    # inner is already ordered by R ordinal then S ordinal. T postings retain T order.
    for row in inner:
        ra, sc = row["ra"], row["sc"]
        if ra is None or sc is None:
            continue
        for t in by_tac.get((ra, sc), ()):
            out.append({**row, "ta": t[0], "tc": t[1], "tid": t[2]})
    return out


def _literal_cyclic_small() -> list[dict[str, int | None]]:
    rels = source("cyclic_small")
    rows = []
    for r in rels["r"]:
        for s in rels["s"]:
            if r[1] is None or s[0] is None or r[1] != s[0]:
                continue
            for t in rels["t"]:
                if r[0] is not None and s[1] is not None and r[0] == t[0] and s[1] == t[1]:
                    rows.append({**_rs_row(r, s), "ta": t[0], "tc": t[1], "tid": t[2]})
    return rows


def _stable_digest(value: Any) -> str:
    payload = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _self_check() -> None:
    assert expected("cyclic_small") == _literal_cyclic_small()
    binary = expected("binary_control")
    assert len(binary) == 8192
    assert binary[0] == {"ra": -3, "rb": 0, "rid": 0, "sb": 0, "sc": -5, "sid": 0}
    assert binary[-1] == {
        "ra": 17 * 8191 - 3,
        "rb": 8191,
        "rid": 8191,
        "sb": 8191,
        "sc": 19 * 8191 - 5,
        "sid": 8191,
    }


if __name__ == "__main__":
    _self_check()
    for cell_name in CELLS:
        inputs = source(cell_name)
        output = expected(cell_name)
        inner_rows = expected_inner(cell_name)
        print(
            json.dumps(
                {
                    "cell": cell_name,
                    "source_rows": {name: len(rows) for name, rows in inputs.items()},
                    "output_rows": len(output),
                    "inner_rows": len(inner_rows),
                    "source_sha256": _stable_digest(inputs),
                    "output_sha256": _stable_digest(output),
                    "inner_sha256": _stable_digest(inner_rows),
                },
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            )
        )
