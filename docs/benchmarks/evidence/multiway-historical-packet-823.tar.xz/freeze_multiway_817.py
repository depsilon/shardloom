"""Freeze the current Rust/Cargo inputs and reconstructable worktree delta."""
import argparse
import hashlib
import json
import lzma
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('name')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)

def digest(data):
    return hashlib.sha256(data).hexdigest()

paths = sorted(set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''})
inputs = {}
for relative in paths:
    path = ROOT / relative
    if path.is_file() and (path.suffix in {'.rs', '.toml', '.lock'} or path.name.startswith('rust-toolchain')):
        data = path.read_bytes()
        inputs[relative] = {'bytes': len(data), 'sha256': digest(data)}
untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
delta = {'base_commit': git('rev-parse', 'HEAD').decode().strip(),
         'tracked_diff': git('diff', 'HEAD', '--binary').decode(),
         'untracked': {p: (ROOT / p).read_text() for p in untracked if p}}
archive = lzma.compress(json.dumps(delta, sort_keys=True).encode(), preset=6)
archive_path = OUT / f'{args.name}-source.json.xz'
with archive_path.open('xb') as stream:
    stream.write(archive)
assert json.loads(lzma.decompress(archive_path.read_bytes())) == delta
manifest = {'base_commit': delta['base_commit'], 'root': str(ROOT), 'files': inputs,
            'source_archive': str(archive_path), 'source_archive_sha256': digest(archive),
            'protocol_sha256': digest((ROOT / 'docs/architecture/native-multiway-join-intake-2026-10-20.md').read_bytes()),
            'oracle_sha256': digest((OUT / 'multiway_reference_817.py').read_bytes())}
target = OUT / f'{args.name}-input.json'
with target.open('x') as stream:
    json.dump(manifest, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'manifest': str(target), 'sha256': digest(target.read_bytes()), 'files': len(inputs),
                  'source_archive_sha256': digest(archive)}))
