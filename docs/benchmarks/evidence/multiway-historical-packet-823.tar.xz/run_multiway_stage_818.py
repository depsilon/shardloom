"""Run exactly one frozen serial multiway stage after source/binary binding."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(binding):
    for name,expected in binding['files'].items():
        path=Path(name)
        assert path.stat().st_size==expected['bytes'] and sha(path)==expected['sha256'],name
    manifest_path=Path(binding['manifest'])
    assert sha(manifest_path)==binding['manifest_sha256']
    manifest=json.loads(manifest_path.read_bytes())
    for name,expected in manifest['files'].items():
        path=ROOT/name
        assert path.stat().st_size==expected['bytes'] and sha(path)==expected['sha256'],name
    assert sha(Path(binding['binary']))==binding['binary_sha256']
    return len(manifest['files'])

parser=argparse.ArgumentParser()
parser.add_argument('stage',choices=('preflight','A','B'))
parser.add_argument('name')
parser.add_argument('binding',type=Path)
parser.add_argument('--prior',type=Path)
args=parser.parse_args()
assert args.name.replace('-','').isalnum()
binding=json.loads(args.binding.read_bytes())
count=verify(binding)
prior=None
if args.stage!='preflight':
    assert args.prior is not None
    prior=json.loads(args.prior.read_bytes())
    assert prior['status']=='passed' and prior['stage']==('preflight' if args.stage=='A' else 'A')
    assert prior['protocol']=='multiway-probe-817-v1'
    assert prior['queries']==(80 if args.stage=='A' else 304)
    assert prior['verifier_sha256']==sha(OUT/'verify_multiway_screen_818.py')
else:
    assert args.prior is None
record_path=OUT/f'{args.name}-results.jsonl'
witnesses=OUT/f'{args.name}-witnesses'
assert not record_path.exists() and not witnesses.exists()
env=dict(os.environ,SHARDLOOM_MULTIWAY_STAGE=args.stage,SHARDLOOM_MULTIWAY_OUTPUT=str(record_path),
    SHARDLOOM_MULTIWAY_REFERENCES=str(OUT/'multiway-references-818a'),SHARDLOOM_MULTIWAY_WITNESSES=str(witnesses))
selector='local_primitives::prepared_relational::tests::multiway_tests::screen::multiway_join_probe_screen'
command=[sys.executable,str(OUT/'run_guarded.py'),'--name',args.name,'--timeout','1200','--',
    binding['binary'],selector,'--exact','--ignored','--nocapture','--test-threads=1']
invocation={'stage':args.stage,'protocol':binding['protocol'],'binding':str(args.binding),'binding_sha256':sha(args.binding),
    'driver_sha256':sha(Path(__file__)),'prior_verification_sha256':sha(args.prior) if args.prior else None,
    'prior_verification':str(args.prior) if args.prior else None,'command':command,
    'environment':{name:value for name,value in env.items() if name.startswith('SHARDLOOM_MULTIWAY_')},
    'source_inputs_checked_before':count,'binary_sha256_before':sha(Path(binding['binary']))}
target=OUT/f'{args.name}-invocation.json'
with target.open('x') as stream: json.dump(invocation,stream,indent=2);stream.write('\n')
code=subprocess.run(command,cwd=ROOT,env=env,check=False).returncode
invocation['returncode']=code
invocation['source_inputs_checked_after']=verify(binding)
invocation['binary_sha256_after']=sha(Path(binding['binary']))
if record_path.exists(): invocation['records_sha256']=sha(record_path)
if witnesses.exists(): invocation['witnesses']={path.name:{'bytes':path.stat().st_size,'sha256':sha(path)} for path in sorted(witnesses.iterdir())}
with target.open('w') as stream: json.dump(invocation,stream,indent=2);stream.write('\n')
assert code==0
receipt=json.loads((OUT/f'{args.name}.json').read_bytes())
assert receipt['status']=='passed' and receipt['process_group_drained'] is True
print(json.dumps({'stage':args.stage,'records':str(record_path),'binary_sha256':binding['binary_sha256'],'source_inputs_checked':count}))
