"""Freeze and accept the integrated multiway sources through normal public artifacts."""
import argparse
import json
import re
from pathlib import Path
import shutil
import subprocess
import sys

import multiway_acceptance_common_820 as d
from multiway_acceptance_common_820 import digest, identity

ROOT, OUT, PYTHON = d.W, d.E, d.P
ARTIFACTS = OUT / 'artifacts/multiway-projected-public-821'
SOURCE = OUT / 'multiway-projected-acceptance-source-821.json'
BUILD = OUT / 'multiway-projected-acceptance-build-821.json'
PLAN = OUT / 'multiway-projected-acceptance-plan-821.json'
BINDING = OUT / 'multiway-projection-binding-821a.json'
sys.path.insert(0, str(ROOT / 'scripts'))
from run_clickbench_query_uat import clickbench_harness_paths


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sources():
    names = git('ls-files', '-co', '--exclude-standard', '-z').split('\0')
    selected = {name for name in names if name and (
        Path(name).suffix in ('.rs', '.toml') or Path(name).name == 'Cargo.lock'
        or name.startswith(('python/', 'scripts/', 'benchmarks/'))
        and Path(name).suffix in ('.py', '.pyi', '.sh', '.sql', '.json'))}
    return {name: digest(ROOT / name) for name in sorted(selected) if (ROOT / name).is_file()}


def verify_integrated():
    binding = json.loads(BINDING.read_text())
    for path, expected in binding['files'].items():
        actual = identity(path)
        assert all(actual[key] == expected[key] for key in ('bytes', 'sha256')), path
    manifest = json.loads(Path(binding['manifest']).read_text())
    for path, expected in manifest['files'].items():
        actual = identity(ROOT / path)
        assert all(actual[key] == expected[key] for key in ('bytes', 'sha256')), path
    assert digest(binding['binary']) == binding['binary_sha256']
    assert binding['head'] == git('rev-parse', 'HEAD')
    return binding


def verify():
    verify_integrated()
    source = json.loads(SOURCE.read_text())
    assert source['source_commit'] == git('rev-parse', 'HEAD')
    assert source['working_tree'] == git('status', '--porcelain')
    assert source['source_hashes'] == sources()
    assert source['generator'] == identity(__file__)
    assert source['common_helper'] == identity(d.__file__)
    assert source['integrated_binding'] == identity(BINDING)
    for ref in source['comparison_verifications']:
        assert identity(ref['path']) == ref
    return source


def receipt(name, command=None):
    path = OUT / f'{name}.json'
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert record['head'] == git('rev-parse', 'HEAD')
    assert record['working_tree'].strip() == git('status', '--porcelain')
    assert record['log_sha256'] == digest(OUT / f'{name}.log')
    if command is not None:
        assert record['command'] == command
    return dict(receipt=identity(path), log=identity(OUT / f'{name}.log'))


def guard(name, command, timeout=3600):
    verify()
    subprocess.run([PYTHON, str(d.GUARD), '--name', name, '--timeout', str(timeout), '--', *command],
                   cwd=ROOT, check=True)
    verify()
    return receipt(name, command)


def generation(path):
    stat = Path(path).stat()
    assert stat.st_blocks * 512 >= stat.st_size
    assert not stat.st_flags & 0x40000000
    return dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)


def artifacts(name, target):
    events = [json.loads(line) for line in (OUT / f'{name}.log').read_text().splitlines()
              if line.startswith('{')]
    assert events[-1] == {'reason': 'build-finished', 'success': True}
    found = [event for event in events if event.get('reason') == 'compiler-artifact'
             and event['target']['name'] == target]
    assert len(found) == 1 and found[0]['fresh'] is False
    assert found[0]['profile']['opt_level'] == '3' and found[0]['profile']['test'] is False
    assert 'release-user-surfaces' in found[0]['features']
    return found[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['source', 'gates', 'build', 'cli-test', 'wheel', 'plan',
                                         'public', 'full43', 'modular', 'verify'])
    args = parser.parse_args()
    if args.phase == 'source':
        binding = verify_integrated()
        refs = []
        for stage, name in [('preflight', 'preflight'), ('A', 'cohortA'), ('B', 'cohortB')]:
            path = OUT / f'multiway-projected-{name}-821a-verified.json'
            result = json.loads(path.read_text())
            assert result['status'] == 'passed' and result['stage'] == stage
            assert result['protocol'] == binding['protocol']
            assert result['queries'] == (80 if stage == 'preflight' else 304)
            assert stage == 'preflight' or result['quantitative_gates_passed'] is True
            refs.append(identity(path))
        d.save(SOURCE, dict(schema_version='shardloom.multiway_public_source.v1',
            source_commit=git('rev-parse', 'HEAD'), working_tree=git('status', '--porcelain'),
            commit_alone_reproduces_sources=False, source_hashes=sources(),
            integrated_binding=identity(BINDING), comparison_verifications=refs,
            generator=identity(__file__), common_helper=identity(d.__file__)))
    elif args.phase == 'gates':
        source = verify()
        native_name = 'multiway-projected-native-all-tests-821a'
        results = {'native': receipt(native_name)}
        native_log = (OUT / f'{native_name}.log').read_text()
        count = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', native_log)
        assert len(count) == 1 and int(count[0][0]) >= 3000
        commands = {
            'fmt': ['fmt', '--all', '--', '--check'],
            'clippy': ['clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'],
            'tests': ['test', '--offline', '--locked', '--workspace', '--all-targets', '--', '--test-threads=2'],
            'native-clippy': ['clippy', '--offline', '--locked', '-p', 'shardloom-cli', '-p', 'shardloom-vortex',
                              '--features', 'release-user-surfaces', '--all-targets', '--', '-D', 'warnings'],
        }
        for kind, command in commands.items():
            results[kind] = guard(f'multiway-projected-workspace-{kind}-821a', [d.RUSTUP, 'run', '1.99.0', 'cargo', *command], 1800)
        test_log = (OUT / 'multiway-projected-workspace-tests-821a.log').read_text()
        matches = re.findall(r'test result: ok\. (\d+) passed; 0 failed;', test_log)
        assert sum(map(int, matches)) > 0
        d.save(OUT / 'multiway-projected-integration-gates-821.json', dict(status='passed', source=identity(SOURCE),
            results=results, native_tests=int(count[0][0]), native_ignored=int(count[0][1]),
            workspace_tests=sum(map(int, matches)), sources_unchanged=verify() == source))
    elif args.phase == 'build':
        source = verify()
        gates_path = OUT / 'multiway-projected-integration-gates-821.json'
        assert json.loads(gates_path.read_text())['status'] == 'passed'
        ARTIFACTS.mkdir(parents=True, exist_ok=False)
        cli_name, lib_name = 'multiway-projected-public-cli-build-821', 'multiway-projected-public-binding-build-821'
        cargo = [d.RUSTUP, 'run', '1.99.0', 'cargo', 'build', '--release', '--offline', '--locked']
        cli = guard(cli_name, [*cargo, '-p', 'shardloom-cli', '--features', 'release-user-surfaces',
                               '--message-format=json-render-diagnostics'])
        cli_artifact = artifacts(cli_name, 'shardloom')
        executable = Path(cli_artifact['executable'])
        metadata = json.loads(subprocess.check_output([d.RUSTUP, 'run', '1.99.0', 'cargo', 'metadata',
            '--offline', '--locked', '--no-deps', '--format-version', '1'], cwd=ROOT))
        assert executable.is_relative_to(Path(metadata['target_directory']))
        binary = ARTIFACTS / 'shardloom'
        shutil.copy2(executable, binary)
        assert digest(binary) == digest(executable)
        native = guard(lib_name, ['/usr/bin/env', f'PYO3_PYTHON={PYTHON}', 'PYO3_BUILD_EXTENSION_MODULE=1',
            *cargo, '-p', 'shardloom-python', '--features', 'release-user-surfaces', '--lib', '--message-format=json'])
        native_artifact = artifacts(lib_name, '_native')
        libraries = [Path(path) for path in native_artifact['filenames'] if path.endswith('.dylib')]
        assert len(libraries) == 1 and libraries[0].is_relative_to(Path(metadata['target_directory']))
        library = ARTIFACTS / '_native.abi3.so'
        shutil.copy2(libraries[0], library)
        assert digest(library) == digest(libraries[0])
        assert verify() == source
        d.save(BUILD, dict(source, binary=str(binary), binary_sha256=digest(binary),
            native_library=identity(library), build_receipts=dict(cli=cli, binding=native),
            source_manifest=identity(SOURCE), cli_compiler_artifact=cli_artifact,
            native_compiler_artifact=native_artifact, gates=identity(gates_path), publication_attempted=False))
    elif args.phase == 'cli-test':
        command = [d.RUSTUP, 'run', '1.99.0', 'cargo', 'test', '--release', '--offline', '--locked',
            '-p', 'shardloom-cli', '--features', 'release-user-surfaces', '--test', 'public_memory_inputs',
            'native::public_multiway_memory_join_preserves_multiplicity_order_and_strategy_evidence',
            '--', '--exact', '--nocapture', '--test-threads=1']
        name = 'multiway-projected-public-cli-tests-821'
        run = guard(name, command, 1200)
        assert 'test result: ok. 1 passed; 0 failed;' in (OUT / f'{name}.log').read_text()
        d.save(OUT / 'multiway-projected-public-cli-tests-821-verified.json', dict(status='passed', run=run,
            tests=1, public_commands=16, source=identity(SOURCE), build=identity(BUILD)))
    elif args.phase == 'wheel':
        source = verify()
        build = json.loads(BUILD.read_text())
        assert build['source_hashes'] == source['source_hashes']
        assert digest(build['binary']) == build['binary_sha256']
        assert identity(build['native_library']['path']) == build['native_library']
        output = OUT / 'multiway-projected-installed-python-821'
        command = ['/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python',
            '-B', 'scripts/prove_native_python_wheel.py', '--repo-root', str(ROOT), '--output-dir', str(output),
            '--native-library', build['native_library']['path'], '--cli-binary', build['binary'], '--wheelhouse',
            '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-wheelhouse-267']
        run = guard('multiway-projected-wheel-proof-821', command)
        report = json.loads((output / 'report.json').read_text())
        assert report['status'] == report['uninstall_status'] == 'passed'
        assert report['integration']['status'] == 'passed' and report['integration']['tests'] >= 113
        assert report['integration']['failures'] == report['integration']['errors'] == report['integration']['skipped'] == 0
        assert report['integrity']['native_library_sha256'] == build['native_library']['sha256']
        assert report['integrity']['cli_sha256'] == build['binary_sha256']
        assert report['installed_load']['isolated_install'] is True
        for step in report['steps']:
            assert step['returncode'] == 0 and step['log_sha256'] == digest(output / step['log'])
        assert verify() == source
        d.save(OUT / 'multiway-projected-installed-python-821.json', dict(status='passed', source=identity(SOURCE),
            build=identity(BUILD), receipt=run, report=identity(output / 'report.json'),
            integration=identity(output / 'integration.json'), tests=report['integration']['tests'], skipped=0,
            uninstall_status='passed', publication_attempted=False, sources_unchanged=True, artifacts_unchanged=True))
    elif args.phase == 'plan':
        source = verify()
        build = json.loads(BUILD.read_text())
        assert build['source_hashes'] == source['source_hashes']
        assert digest(build['binary']) == build['binary_sha256']
        assert identity(build['native_library']['path']) == build['native_library']
        previous = json.loads((OUT / 'output-window-acceptance-plan-789.json').read_text())
        families = previous['families']
        assert len(families) == len(set(families)) == 39
        full43 = previous['commands']['full43'].copy()
        for option, value in {'--binary': build['binary'], '--build-commit': source['source_commit'],
                              '--uat-root': str(OUT / 'multiway-projected-full43-821')}.items():
            full43[full43.index(option) + 1] = value
        modular = previous['commands']['modular'].copy()
        original = Path(previous['modular_runner']['path'])
        assert identity(original) == previous['modular_runner']
        local = OUT / 'multiway_projected_modular_runner_821.py'
        assert not local.exists()
        shutil.copy2(original, local)
        assert digest(local) == digest(original)
        modular[modular.index(str(original))] = str(local)
        for option, value in {'--repo': str(ROOT), '--build-manifest': str(BUILD),
                              '--prefix': 'multiway-projected', '--attempt': '821'}.items():
            modular[modular.index(option) + 1] = value
        public = [PYTHON, '-B', 'scripts/run_native_streaming_input_uat.py', '--binary', build['binary'],
            '--uat-root', str(OUT / 'multiway-projected-public-821'), '--operation-timeout', '600', '--compress-logs',
            '--families', *families]
        assert identity(previous['reference']['path']) == previous['reference']
        assert all(identity(row['path']) == row for row in previous['schema_sources'])
        input_generation = generation(previous['input']['path'])
        assert input_generation['size_bytes'] == 15713610513
        d.save(PLAN, dict(status='predeclared', source=identity(SOURCE), build=identity(BUILD),
            commands=dict(public=public, full43=full43, modular=modular), expected=previous['expected'],
            input=dict(path=previous['input']['path'], generation=input_generation,
                       sha256=previous['input']['sha256']), reference=previous['reference'],
            schema_sources=previous['schema_sources'], query_source=identity(ROOT / 'benchmarks/clickbench/queries.sql'),
            query_harness=[identity(path) for path in clickbench_harness_paths()],
            public_runner=identity(ROOT / 'scripts/run_native_streaming_input_uat.py'),
            complete_public_family_source=identity(OUT / 'output-window-acceptance-plan-789.json'), families=families,
            modular_runner=identity(local), original_modular_runner=identity(original), guard=identity(d.GUARD),
            resource_limits_changed=False, reingested=False, reference_kind='retained_native_regression',
            performance_claim=False, engine_clock='sum of engine_execution_seconds for one execution of Q01 through Q43'))
    elif args.phase in ('public', 'full43', 'modular'):
        source = verify()
        plan = json.loads(PLAN.read_text())
        assert plan['source'] == identity(SOURCE) and plan['build'] == identity(BUILD)
        build = json.loads(BUILD.read_text())
        assert digest(build['binary']) == build['binary_sha256']
        assert identity(build['native_library']['path']) == build['native_library']
        if args.phase == 'full43':
            expected = plan['input']
            assert generation(expected['path']) == expected['generation']
            assert digest(expected['path']) == expected['sha256']
            assert generation(expected['path']) == expected['generation']
        run = guard(f'multiway-projected-{args.phase}-821', plan['commands'][args.phase], 7200)
        if args.phase == 'full43':
            assert generation(expected['path']) == expected['generation']
            assert digest(expected['path']) == expected['sha256']
            assert generation(expected['path']) == expected['generation']
        assert verify() == source
        d.save(OUT / f'multiway-projected-{args.phase}-binding-821.json', dict(status='passed', plan=identity(PLAN),
            build=identity(BUILD), receipt=run, sources_unchanged=True, artifacts_unchanged=True,
            full_input_pre_and_post_hash_verified=args.phase == 'full43'))
    else:
        verify()
    print(json.dumps(dict(status='passed', phase=args.phase)), flush=True)


if __name__ == '__main__':
    main()
