#!/usr/bin/env python3
"""Write frozen PERF-10 multiway reference objects into a new directory.

This script only calls the pinned Python oracle. It does not run ShardLoom or
any other query engine.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ORACLE_PATH = Path(__file__).with_name("multiway_reference_817.py")
ORACLE_SHA256 = "7858a4f8b6ed53715ad46a123d1d5f7e2d97c4739ab282f0f297ada6418a35fa"


def load_oracle():
    observed = hashlib.sha256(ORACLE_PATH.read_bytes()).hexdigest()
    if observed != ORACLE_SHA256:
        raise RuntimeError(
            f"oracle SHA-256 mismatch: expected {ORACLE_SHA256}, observed {observed}"
        )
    spec = importlib.util.spec_from_file_location("multiway_reference_817", ORACLE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load oracle at {ORACLE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def expected_dtype(cell: str, oracle) -> dict:
    # Match verify_multiway_intake_817.py:dtype (lines 17-19): the existing
    # validator constructs ordered field names and nullable i64 primitives;
    # fields ending in "id" and the outer Struct are non-nullable.
    names = list(oracle.RS_FIELDS) + (
        [] if cell == "binary_control" else list(oracle.T_FIELDS)
    )
    return {
        "Struct": [
            {
                "names": names,
                "dtypes": [
                    {"Primitive": ["i64", not name.endswith("id")]}
                    for name in names
                ],
            },
            False,
        ]
    }


def compact_json_bytes(value: object) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "output_dir",
        type=Path,
        help="absolute path to a new directory for the reference files",
    )
    args = parser.parse_args()
    output_dir = args.output_dir
    if not output_dir.is_absolute():
        parser.error("output_dir must be an absolute path")
    if output_dir.exists():
        parser.error(f"output_dir already exists: {output_dir}")
    if not output_dir.parent.is_dir():
        parser.error(f"output_dir parent must already exist: {output_dir.parent}")

    oracle = load_oracle()
    output_dir.mkdir()
    manifest_files = {}
    source_row_count = 0

    for cell in oracle.CELLS:
        sources = oracle.source(cell)
        rows = oracle.expected(cell)
        payload = {
            "cell": cell,
            "sources": sources,
            "rows": rows,
            "schema": expected_dtype(cell, oracle),
        }
        encoded = compact_json_bytes(payload)
        basename = f"{cell}.json"
        destination = output_dir / basename
        with destination.open("xb") as stream:
            stream.write(encoded)
        source_rows = sum(len(relation_rows) for relation_rows in sources.values())
        source_row_count += source_rows
        manifest_files[cell] = {
            "file": basename,
            "bytes": len(encoded),
            "sha256": hashlib.sha256(encoded).hexdigest(),
            "row_count": len(rows),
        }

    manifest = {
        "protocol": "multiway-probe-817-v1",
        "oracle_sha256": ORACLE_SHA256,
        "files": manifest_files,
        "source_row_count": source_row_count,
    }
    with (output_dir / "manifest.json").open("xb") as stream:
        stream.write(compact_json_bytes(manifest))
    print(json.dumps({"output_dir": str(output_dir), **manifest}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
