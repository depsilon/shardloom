# PERF-10.multiway_joins: test, counter, and source inventory

Read-only source inventory at worktree HEAD `656e9508974358f9b3f532b249841c1e7b4df0f6`. No tests/builds were run and no repository files were edited. This records source evidence only; it does not select a design or assess performance eligibility.

## Existing test entry points and semantics

The public typed plan is a recursive **binary** `VortexRelationalPlan::Join(Box<VortexRelationalJoin>)`; the join node has left/right plans, kind, equality-key pairs, optional condition, and projected columns (`shardloom-vortex/src/relational_query.rs:95-105,210-253`). `prepare_relational(plan, policy)` is the preparation entry point (`local_primitive_prepared_relational.rs:420-435`); binding recursively creates binary join nodes (`local_primitive_relational_bind.rs:554-629`). Runtime builds the right subtree then probes it with the left subtree for each node (`local_primitive_prepared_relational.rs:1582-1603`).

The direct binary test `every_native_join_kind_preserves_duplicates_nulls_order_and_integer_payload_width` exercises all seven kinds. Its expected inner result contains every duplicate match in left-row order and right-build order; NULL keys do not match; it checks exact output ordering and `u64::MAX` payload. It also asserts bounded output chunks, exact row count, output dtype, and retained-array lifetime (`local_primitives/native_relational_join_tests.rs:92-161`). A second binary test covers empty sides/cancellation (`:164+`). These tests do not establish three-relation cyclic semantics.

The nested-composition test `streaming_join_nested_aggregate_order_limit_and_native_write_reopen_preserve_complete_values` builds two binary nodes (Full nested under Left), then aggregates/orders/limits, checks exact JSON values, optionally writes/reopens, and varies stream side and spill (`local_primitive_relational_batch_join_composition_tests.rs:13-59,61-133`). It is not the cyclic `R(a,b), S(b,c), T(a,c)` workload. Existing inventory/source search found no dedicated three-relation cyclic equijoin or self-join correctness test (`multiway-join-caller-inventory-811.md`, source-search scope `shardloom-vortex/src/**/*tests.rs`).

## Counters and materialization visibility

The explicit ordered/spill path reports `ordered_join_stages`, build/probe rows, candidate rows, match records, and lookup blocks (`local_primitive_prepared_relational.rs:181-189,1554-1579`); report construction exposes them at `:1315-1320`. Their increment sites are inside the ordered/spill branch, so they are not universal counters for the resident non-spill join. The direct resident `Join` keeps a hash table/row index and emits bounded result batches (`local_primitives/native_relational_join.rs:46-60,110-178`), but this source surface does not expose general intermediate row-materialization bytes, multiway candidate assignments, or repeated key-search counters. No counter source was found for those quantities.

## Bounded in-memory source path

Ordinary binary controls can use the same typed relational prepare/runtime path with `ResidentMemorySource` inputs. Public finite-source constructors include `from_columns(session, columns, bounds)` (default bounds: 65,536 rows/32 MiB input and output) and `from_batch_columns(session, columns)` (batch cap 2,048 rows and default remaining bounds): `resident_memory_source.rs:66-104,246-253,287-305`. Columns are named and typed via `MemoryColumn { name, values }`; values include nullable/nonnullable Int64, Float64, Bool, Utf8, and validated TypedJson: `:66-90`. Constructors copy into owned native buffers and reject invalid bounds/values (`:243-253,287-305`).

Prepared source APIs include `prepare_relational_from_source` and controlled variants (`local_primitive_prepared_relational.rs:563-642`); a prepared plan can execute or collect (`:1764-1776`). More directly, `prepare_relational_with_schema(policy, lower)` creates one `ResidentVortexSession`, invokes the lowering callback with a single mutable `VortexRelationalPreparation`, then validates/binds the complete returned plan (`local_primitive_prepared_relational.rs:512-533,596-638`). Its `register_memory_source(uri, build)` accepts a URI and a `FnOnce(&ResidentVortexSession) -> Result<ResidentMemorySource>` (`:477-482`). The callback may register distinct named URIs, and the plan can contain separate `Scan` nodes for those URIs (`relational_query.rs:95-105,210-253`); this is the source-backed shape for ordinary binary join controls. The compact-index cost test demonstrates this API for one immutable memory source (`local_primitive_relational_compact_index_cost_tests.rs:189-210`).

The inspected join tests prove multi-input preparation with two distinct **batch** sources, not two immutable `ResidentMemorySource` registrations: `local_primitive_relational_batch_multiple_tests.rs::prepare_multiple` registers `memory://stream` and `memory://second` using `register_batch_source`, then builds a join (`:8-27`); its test checks all join kinds, both source orders, empty/unequal batches, fresh execution, and source counts (`:58-150`). `local_primitive_relational_batch_join_tests.rs` also mixes one batch URI and one registered resident memory URI (`:60-75,146-167`). I found no test registering two immutable resident memory sources and joining them. Thus the API/binder surface supports expressing that shape, but an exact two-resident-source test and any claim of atomic snapshot semantics are absent; no cross-source snapshot guarantee is inferred.

## Gaps and exactness limits

No source-backed test found for cyclic three-relation multiway output, self-join alias behavior, or its multiplicity/NULL/order contract. Binary controls do have finite expected-output tests as above. The campaign specifies cyclic vs binary controls and exact multiplicity/NULL/order semantics in its workload contract (`docs/architecture/phased-execution-plan.md:387`; `docs/architecture/native-state-structure-campaign-2026-10-07.md:151-155`), but that is not implementation or test evidence. No performance measurements or runtime conclusion are included.

## SHA256 of inspected code files

| File | SHA256 |
|---|---|
| `shardloom-vortex/src/relational_query.rs` | `270aed9347adac9905a580543731460e9eb67fc00392c2eb37ca08f02717e09f` |
| `shardloom-vortex/src/local_primitive_prepared_relational.rs` | `d46157b5f1e288e44bcef2e775fdf4d672eb9de6bc50d37fd386bdd9619fdce3` |
| `shardloom-vortex/src/local_primitive_relational_bind.rs` | `d55ad0f056f215e4f7280977087f19409c10bc8a0ddcd2d112501d8f5d10d31a` |
| `shardloom-vortex/src/local_primitives/native_relational_join.rs` | `2c8325281412b4193929c302e914aa2a53e23d94ba27451f4c43742b6bac193a` |
| `shardloom-vortex/src/local_primitives/native_relational_join_tests.rs` | `26ec3565de20b4bc4c8e54afdd1da7593b274c12e9d43946f5524b883f792a0b` |
| `shardloom-vortex/src/local_primitive_relational_batch_join_composition_tests.rs` | `60a51445d211f1bcf1be89044ab1c938af99822564ed39b3f5740bc298867700` |
| `shardloom-vortex/src/resident_memory_source.rs` | `5354835768574468f426e047e8bc7cd6092283bfece2d8bef0df0b516bac5b50` |
| `shardloom-vortex/src/local_primitive_relational_compact_index_cost_tests.rs` | `4fea9a6992c24486e406d6c37e000a9a6c9ba0fa417a74a45e717551915dc940` |
| `shardloom-vortex/src/local_primitive_relational_batch_multiple_tests.rs` | `6329effa088861cf51367daa9d28817adc89e99329341181463621a654ea050f` |
| `shardloom-vortex/src/local_primitive_relational_batch_join_tests.rs` | `69290be66667a25a681af1cc220638354ebcad2b61087dbc03f9435282eb29c2` |
