# Multiway artifact inventory 822

Generated: 2026-10-20T18:44:36.449Z.
Scope: 2685 regular files from the requested E root files, named evidence directories, witness directories, and helper identities. W source content was not read.

Syntax checks: 314 JSON/JSONL/compressed-JSON files checked; 0 failures.
Duplicate content: 18 hashes recur across 192 files.

Duplicate SHA-256 groups (hash — count):

- `092def0c39ab801236e6f81024c6a75672c00ebac56cad251f167039262402f7` — 9
- `0d08976e42a0cc568f9c7d6368892935f18185c5f5a2239daf82ca351911d883` — 9
- `0e8a7fa600ebba8912d39b7b695a7da4c346c716ca43f4600a08678a01c0e27b` — 9
- `26db9045f34d77d3399df2ac7bf1d83d93ea59d1244121b6caca943ba677394d` — 9
- `4615641982589158a0ee324d9ef5a91e3f65b43b7fa2d8db69627c908c058406` — 9
- `4952dd73f26489f44f10d377c574fd9c6316453d13a7c0aad8ebef2a6116c5ab` — 9
- `582944b0d21f8d55f106be060880beb503321395d7b91b438fe33e23d2432e25` — 9
- `6cedf8d02e13854b28028beb8a620286991b97d5abffd7662ce4d671183a6f20` — 9
- `8664e0c78b557a38789e14e090347192e868d90e7ea74d870b6a3ccd831410e4` — 9
- `87950893acf4a0b256549f97f7b365e80fd0e9edea27897381ee6e777a624357` — 9
- `8f7419ead188f20d98a395f8d51b8f16a6d0a887cd2d854393b77d25a778d676` — 9
- `90f5e24cfe4a56e8c7737f8ebd6a329d1d0f2737bcad91e8d27065cfeea36284` — 9
- `987366132bf2080d5857fbf4411581979e01021918470cdc975f961a61b256cb` — 9
- `c696ae7feb2bc3ad623efcdd7945c05436e657f097fbe9fdf8b0364f52672925` — 9
- `cce1aa8ecebc08357dd7e691e1585d06265e8c0b2817cbd41dde4599c2f22e92` — 9
- `dab4c8a22c9ef3bc34e987659e75a44557970418476e189c16302dfb392ef1ce` — 9
- `dc457265479b6398d39beae3ec5c6318720ffa7dd170abd8c2a93fc2ae3495bb` — 9
- `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` — 39

Reference completeness:
- Multiway binding records checked: 6; unresolved E-local evidence references: 0.
- The binding `files` map contains 89 absolute path keys; all 89 resolve with matching bytes/SHA-256 identities. Direct workspace-source references resolve from their versioned source deltas, and the two older 818b scripts resolve from the embedded historical script record.
- Five historical Cargo executable identities are paired with their binding SHA-256 values (and recorded byte counts when present); current bytes at the reused path were not checked. Six other absolute file-path values resolve through the retained E manifests or frozen workspace source map.
- Source portability blob references resolved: 13680/13680.
- All 2,262 distinct source-portability blob files match their referenced SHA-256 names.
- Distinct E-local text/result paths referenced and retained: 13; unresolved/unselected references: 0.
- Historical source identities are resolved from frozen manifests and archived deltas: 1,902/1,902 intake files and 1,906/1,906 files for each of the four later builds; direct W source paths resolve 3/3, 3/3, 4/4, and 5/5 for 818b, 818c, 819a, and 821a. The two superseded 818b scripts match their embedded historical bytes and hashes. All 21 public-build working-tree paths resolve to the accepted source record or archived deltas.
- The five old Cargo executable identities are retained from their binding records as historical metadata. Their reused current path bytes were not read or required.
- Completeness status: **complete**.
- Excluded by coordination: all `multiway-restored-*` files, whose restoration checks are being inventoried separately.

Assignment-provided projected comparison context (not independently interpreted): preflight has 80 records; cohort A has 304 and its single star-control call fails both engine and complete bounds; cohort B has 304 and all gates pass.

The JSON inventory contains exact per-file identities, syntax results, duplicate groups, binding references, and portability-map resolution checks. Inventory only; no acceptance judgment is made.
