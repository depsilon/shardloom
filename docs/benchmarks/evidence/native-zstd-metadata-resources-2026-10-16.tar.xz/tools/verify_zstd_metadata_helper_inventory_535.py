"""Verify the bounded helper inventory and the two explicit packaging corrections."""
import ast
import hashlib
import json
from pathlib import Path
import re

O = Path(__file__).resolve().parent
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
REPORT = O / 'zstd-metadata-helper-primary-check-535.json'


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert not REPORT.exists()
    inventory_path = O / 'zstd-metadata-helper-inventory-534.json'
    inventory = json.loads(inventory_path.read_text())
    assert len(inventory['source_sha256']) == 78
    packager = O / 'package_zstd_metadata_534.py'
    before = """        'metadata_public_verifier_534.py')]
    helper_paths += [supervisor, external / 'release_validation_guard.py', ROOT / 'scripts/timed_native_command.py']"""
    after = """        'metadata_public_verifier_534.py', 'run_guarded.py')]
    helper_paths += [supervisor, external / 'release_validation_guard.py',
        ROOT / 'scripts/timed_native_command.py', ROOT / 'scripts/build_native_python.py']"""
    assert packager.read_text().count(after) == 1
    for path, digest in inventory['source_sha256'].items():
        raw = Path(path).read_bytes()
        if Path(path) == packager:
            raw = raw.decode().replace(after, before).encode()
        assert hashlib.sha256(raw).hexdigest() == digest, path
    assert set(inventory['source_sha256']) == set(inventory['import_closure_files'])
    roots = [Path(path) for path in inventory['packager_local_roots']]
    pending = [Path(path) for path in inventory['explicit_dynamic_guard_files']]
    pending += [O / 'run_guarded.py', R / 'scripts/build_native_python.py']
    pending += [path for path in O.iterdir() if path.is_file() and path.suffix == '.py' and
                (re.search(r'zstd[-_]metadata', path.name) or 'zstdmetadata' in path.name)]
    resolved = {}
    while pending:
        path = pending.pop().resolve()
        if str(path) in resolved:
            continue
        assert path.is_file() and not path.is_symlink()
        resolved[str(path)] = identity(path)
        for node in ast.walk(ast.parse(path.read_text())):
            modules = ([item.name for item in node.names] if isinstance(node, ast.Import) else
                       [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else [])
            for module in modules:
                for root in roots:
                    module_path = root.joinpath(*module.split('.'))
                    candidate = module_path.with_suffix('.py')
                    if not candidate.is_file():
                        candidate = module_path / '__init__.py'
                    if candidate.is_file():
                        pending.append(candidate)
                        break
    assert set(inventory['import_closure_files']) <= set(resolved)
    for row in inventory['literal_local_helper_targets']:
        assert row['target'] in resolved
        text = Path(row['source']).read_text()
        assert Path(row['target']).name in text
        assert any(isinstance(node, ast.Call) and node.lineno == row['line']
                   for node in ast.walk(ast.parse(text)))
        assert row['captured_by_closure'] == (row['target'] in inventory['import_closure_files'])
    assert {row['target'] for row in inventory['not_captured_by_closure']} == {
        str(O / 'run_guarded.py'), str(R / 'scripts/build_native_python.py')}
    # These are generic launchers. Their concrete command vectors are preserved
    # by the supervisor receipts, the lifecycle records and the Full43 records.
    wrappers = {
        str(R / 'scripts/timed_native_command.py'): ('command', 'args.command'),
        str(R / 'scripts/run_clickbench_query_uat.py'): ('command', 'def run_command('),
        '/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py':
            ('command', 'def run('),
    }
    assert {row['source'] for row in inventory['unresolved_subprocess_command_expressions']} == set(wrappers)
    for row in inventory['unresolved_subprocess_command_expressions']:
        expression, marker = wrappers[row['source']]
        text = Path(row['source']).read_text()
        assert row['expression'] == expression and marker in text
        calls = [node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.Call) and node.lineno == row['line']]
        assert calls and ast.unparse(calls[0].args[0]) == expression
    assert all(identity(path) == item for path, item in resolved.items())
    result = dict(status='passed', inventory=identity(inventory_path), helper=identity(__file__),
        original_source_hashes_verified=78, literal_target_sites=13,
        corrected_missing_helpers=[str(O / 'run_guarded.py'), str(R / 'scripts/build_native_python.py')],
        packager_before_correction_sha256=inventory['source_sha256'][str(packager)],
        packager_after_correction=identity(packager), all_literal_targets_in_final_closure=True,
        generic_wrapper_commands_bound_by='supervisor, lifecycle and Full43 raw command records',
        final_import_closure=sorted(resolved.values(), key=lambda row: row['path']),
        final_source_hashes_stable=True)
    with REPORT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', original_source_files=78,
        final_source_files=len(resolved), literal_target_sites=13, missing_targets=0)))


if __name__ == '__main__':
    main()
