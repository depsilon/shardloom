"""Recompute every metadata lifecycle cost decision from the complete raw samples."""
import hashlib
import json
from pathlib import Path
import re
import statistics

O = Path(__file__).resolve().parent
D = O / 'zstd-metadata-cost-530'
RESULT = O / 'zstd-metadata-cost-review-534.json'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


def read_text(path):
    return Path(path).read_text()


def checked(item):
    assert identity(item['path']) == item
    return Path(item['path'])


def inspect_order(order, protocol):
    summary_path = D / order / 'summary.json'
    summary = read(summary_path)
    assert summary['status'] == 'passed' and summary['order'] == order and summary['lock_released']
    assert summary['protocol'] == identity(D / 'protocol.json')
    assert list(summary['runs']) == (['baseline', 'candidate'] if order == 'forward' else ['candidate', 'baseline'])
    cells, timings = {}, {}
    for role, run in summary['runs'].items():
        assert read(D / order / (role + '.json')) == run
        assert run['status'] == 'passed' and run['returncode'] == 0
        assert run['process_group_drained'] and run['direct_child_reaped']
        assert not run['timed_out'] and not run['group_absence_unproved_at_cleanup']
        assert run['command'][-6:] == [protocol['identities'][role]['binary']['path'],
            protocol['test_name'], '--exact', '--ignored', '--nocapture', '--test-threads=1']
        files = [checked(item) for item in run['files']]
        assert {p.name for p in files} == {role + suffix for suffix in
            ('.stdout.txt', '.stderr.txt', '.timing.json', '.pid')}
        text = read_text(D / order / (role + '.stdout.txt'))
        assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out;', text)
        records = [json.loads(line.split('COMPRESSION_COST ', 1)[1])
                   for line in text.splitlines() if 'COMPRESSION_COST ' in line]
        assert len(records) == 72
        computed, operations = [], 0
        for index, case in enumerate(protocol['cases']):
            rows = records[4 * index:4 * index + 4]
            assert [row['phase'] for row in rows] == ['warmup', 'measured', 'measured', 'measured']
            assert [row['sample'] for row in rows[1:]] == [0, 1, 2]
            assert [len(row['nanoseconds']) for row in rows] == [1, 25, 25, 25]
            assert all(type(value) is int and value > 0 for row in rows for value in row['nanoseconds'])
            assert all(all(row[key] == value for key, value in case.items()) for row in rows)
            assert all(row['observation'] == rows[0]['observation'] for row in rows)
            assert rows[0]['observation']['serialized_bytes'] > 0
            assert re.fullmatch('[0-9a-f]{64}', rows[0]['observation']['serialized_sha256'])
            operations += sum(len(row['nanoseconds']) for row in rows)
            computed.append(dict(**case, records=rows, observation=rows[0]['observation'],
                median_sample_ns=statistics.median(sum(row['nanoseconds']) for row in rows[1:])))
        assert operations == 1368 and computed == run['cells']
        cells[role] = computed
        timing = read(D / order / (role + '.timing.json'))
        assert timing == run['timing'] and timing['returncode'] == 0
        assert all(timing[key] >= 0 for key in ('user_cpu_seconds', 'system_cpu_seconds', 'peak_rss_bytes'))
        timings[role] = timing
    recomputed, breaches = [], []
    for baseline, candidate in zip(cells['baseline'], cells['candidate'], strict=True):
        case = {key: baseline[key] for key in ('kind', 'rows', 'encoding')}
        assert all(baseline['observation'][key] == candidate['observation'][key]
                   for key in ('serialized_bytes', 'serialized_sha256'))
        a, b = baseline['median_sample_ns'], candidate['median_sample_ns']
        breach = b > a + max(.10 * a, 25 * 100_000)
        if breach:
            breaches.append(dict(**case, metric='elapsed'))
        recomputed.append(dict(**case, baseline_ns_per_operation=a / 25,
            candidate_ns_per_operation=b / 25, relative_change=b / a - 1, breach=breach,
            baseline_observation=baseline['observation'], candidate_observation=candidate['observation']))
    a, b = timings['baseline'], timings['candidate']
    acpu = a['user_cpu_seconds'] + a['system_cpu_seconds']
    bcpu = b['user_cpu_seconds'] + b['system_cpu_seconds']
    if bcpu > acpu + max(.10 * acpu, 1):
        breaches.append(dict(metric='process_cpu'))
    if b['peak_rss_bytes'] > a['peak_rss_bytes'] + max(.25 * a['peak_rss_bytes'], 64 * 1024 ** 2):
        breaches.append(dict(metric='process_rss'))
    assert summary['cells'] == recomputed and summary['breaches'] == breaches
    assert summary['decision'] == ('needs_reverse_order' if breaches else 'within_declared_cost_bounds')
    return dict(order=order, summary=identity(summary_path), raw_cells_recomputed=36,
        raw_records=144, complete_operations=2736, all_serialized_bytes_equal=True, breaches=breaches)


def main():
    import zstd_metadata_cost_532 as lifecycle

    assert not RESULT.exists()
    protocol = read(D / 'protocol.json')
    lifecycle.verify(protocol)
    assert len(read(protocol['identities']['baseline']['source']['path'])['source_sha256']) == 2063
    assert len(read(protocol['identities']['candidate']['source']['path'])['source_sha256']) == 2067
    expected = [dict(kind=kind, rows=rows, encoding=encoding,
        frame_rows=128 if rows == 4096 else 1024, grant_bytes=64 * 1024 ** 2)
        for kind in ('nullable_i64', 'nullable_utf8', 'nullable_binary')
        for rows in (4096, 65536)
        for encoding in ('canonical', 'zstd_no_dictionary', 'zstd_dictionary')]
    assert protocol['cases'] == expected
    assert protocol['samples_per_case'] == 3 and protocol['operations_per_sample'] == 25
    assert protocol['recorded_warmups_per_case'] == 1 and not protocol['performance_claim_allowed']
    assert protocol['elapsed_gate'] == dict(relative=.10, absolute_seconds_per_operation=.0001)
    assert protocol['process_cpu_gate'] == dict(relative=.10, absolute_seconds=1)
    assert protocol['process_rss_gate'] == dict(relative=.25, absolute_bytes=64 * 1024 ** 2)
    forward = inspect_order('forward', protocol)
    reverse = inspect_order('reverse', protocol) if forward['breaches'] else None
    assert (D / 'reverse').exists() == bool(reverse)
    repeated = [breach for breach in forward['breaches'] if breach in reverse['breaches']] if reverse else []
    decision = read(D / 'decision.json')
    assert decision['repeated_breaches'] == repeated
    assert decision['status'] == ('needs_diagnosis' if repeated else 'retained_pending_broad_acceptance')
    assert decision['forward'] == forward['summary']
    assert decision['reverse'] == (reverse['summary'] if reverse else None)
    assert decision['protocol'] == identity(D / 'protocol.json') and not decision['performance_claim_allowed']
    lifecycle.verify(protocol)
    result = dict(status='passed', helper=identity(__file__), protocol=identity(D / 'protocol.json'),
        decision=identity(D / 'decision.json'), decision_status=decision['status'],
        forward=forward, reverse=reverse, repeated_breaches=repeated,
        baseline_source_files=2063, candidate_source_files=2067,
        independently_recomputed_from_complete_raw_samples=True,
        serialized_identity_equal_in_every_cell=True, source_and_build_identities_unchanged=True,
        performance_claim_allowed=False)
    with RESULT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', decision=decision['status'], reverse_required=bool(reverse),
                         complete_operations=2736 * (2 if reverse else 1))))


if __name__ == '__main__':
    main()
