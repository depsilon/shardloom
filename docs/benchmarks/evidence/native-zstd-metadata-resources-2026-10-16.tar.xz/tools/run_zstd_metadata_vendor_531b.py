"""Validate frozen vendor source in a standalone copy under the outer guard."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'zstd-metadata-vendor-531b'
SOURCE = ROOT / 'vendor/vortex-zstd'
TARGET = OUT / 'vortex-zstd'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


assert not OUT.exists()
paths = sorted(path for path in SOURCE.rglob('*') if path.is_file()
               and path.relative_to(SOURCE).as_posix() != 'Cargo.lock')
assert all(not path.is_symlink() for path in paths)
assert sum(path.stat().st_size for path in paths) < 32 << 20
copies = {path.relative_to(SOURCE).as_posix(): sha(path) for path in paths}
array_paths = sorted(path for path in (ROOT / 'vendor/vortex-array').rglob('*')
                     if path.is_file() and path.name != 'Cargo.lock')
dependencies = {path.relative_to(ROOT).as_posix(): sha(path) for path in array_paths}
dependencies['Cargo.lock'] = sha(ROOT / 'Cargo.lock')
for path in paths:
    destination = TARGET / path.relative_to(SOURCE)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
shutil.copy2(ROOT / 'Cargo.lock', TARGET / 'Cargo.lock')


def verify():
    assert all(sha(SOURCE / name) == digest and sha(TARGET / name) == digest
               for name, digest in copies.items())
    assert all(sha(ROOT / name) == digest for name, digest in dependencies.items())


manifest_args = ['--offline', '--manifest-path', str(TARGET / 'Cargo.toml'),
                 '--config', 'patch.crates-io.vortex-array.path=' +
                 json.dumps(str(ROOT / 'vendor/vortex-array')),
                 '--features', 'vortex-array/table-display']
commands = [
    ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
     *[str(SOURCE / name) for name in (
         'src/array.rs', 'src/compute/cast.rs', 'src/lib.rs', 'src/test.rs',
         'src/metadata_resources.rs', 'src/metadata_resources_tests.rs')]],
    ['cargo', 'test', *manifest_args, '--lib', '--', '--test-threads=1'],
    ['cargo', 'clippy', *manifest_args, '--lib', '--', '-D', 'warnings'],
]
save(OUT / 'protocol.json', dict(source=str(SOURCE), target=str(TARGET),
    source_files=copies, dependency_files=dependencies, commands=commands,
    helper_sha256=sha(__file__),
    required_test_prefix='metadata_resources::tests::', required_new_tests=6))
completed, failure = [], None
try:
    for command in commands:
        verify()
        subprocess.run(command, cwd=ROOT, check=True)
        completed.append(command)
    verify()
except BaseException as error:
    failure = type(error).__name__ + ': ' + str(error)
    raise
finally:
    unchanged = all(sha(SOURCE / name) == digest and sha(TARGET / name) == digest
                    for name, digest in copies.items())
    unchanged = unchanged and all(sha(ROOT / name) == digest
                                  for name, digest in dependencies.items())
    save(OUT / 'summary.json', dict(status='passed' if failure is None and unchanged else 'failed',
        completed=completed, failure=failure, sources_unchanged=unchanged,
        protocol_sha256=sha(OUT / 'protocol.json'),
        standalone_lock_sha256=sha(TARGET / 'Cargo.lock')))
    assert unchanged
