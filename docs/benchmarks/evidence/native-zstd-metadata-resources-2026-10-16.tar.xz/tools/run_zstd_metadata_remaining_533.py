"""Run the already-declared metadata cost and acceptance stages serially."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import OUT, ROOT
from run_query_timing_runtime_461 import guarded
from run_zstd_metadata_acceptance_533 import unchanged

PYTHON = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
COST = OUT / 'zstd_metadata_cost_532.py'
DEST = OUT / 'zstd-metadata-cost-530'
ACCEPTANCE = OUT / 'run_zstd_metadata_acceptance_533.py'


def stage(name, timeout, command):
    unchanged()
    print(json.dumps(dict(stage=name, status='starting')), flush=True)
    guarded(name, timeout, command)
    unchanged()
    print(json.dumps(dict(stage=name, status='passed')), flush=True)


def main():
    assert Path(sys.executable) == PYTHON
    checks = json.loads((OUT / 'zstd-metadata-checks-532.json').read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    stage('zstd-metadata-candidate-build-532', 1800,
        ['cargo', 'test', '--offline', '--locked', '--release', '-p', 'shardloom-vortex',
         '--features', 'release-user-surfaces', '--lib', '--no-run'])
    stage('zstd-metadata-freeze-build-533', 180,
        [PYTHON, '-B', COST, 'freeze-build', '--receipt', OUT / 'zstd-metadata-candidate-build-532.json'])
    stage('zstd-metadata-freeze-cost-533', 180, [PYTHON, '-B', COST, 'freeze-protocol'])
    stage('zstd-metadata-cost-forward-533', 2100, [PYTHON, '-B', COST, 'run', '--order', 'forward'])
    forward = json.loads((DEST / 'forward/summary.json').read_text())
    assert forward['status'] == 'passed'
    if forward['breaches']:
        stage('zstd-metadata-cost-reverse-533', 2100, [PYTHON, '-B', COST, 'run', '--order', 'reverse'])
    stage('zstd-metadata-cost-decision-533', 180, [PYTHON, '-B', COST, 'decide'])
    decision = json.loads((DEST / 'decision.json').read_text())
    assert decision['status'] == 'retained_pending_broad_acceptance', decision
    stage('native-final-cli-release-build-zstdmetadata532', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    stage('native-final-python-release-build-zstdmetadata532', 2100,
        [PYTHON, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'zstd-metadata-native-binding-532'])
    stage('zstd-metadata-freeze-native-533', 180,
        [PYTHON, '-B', OUT / 'freeze_native_release_298.py', '--run-id', 'zstdmetadata532'])
    stage('zstd-metadata-declarations-533', 180, [PYTHON, '-B', ACCEPTANCE, 'declare'])
    stage('zstd-metadata-direct-533', 1800,
        [OUT / 'selected-view-python-468/bin/python', '-B', ACCEPTANCE, 'direct'])
    print(json.dumps(dict(stage='public', status='starting')), flush=True)
    subprocess.run([str(PYTHON), '-B', str(ACCEPTANCE), 'public'], cwd=ROOT, check=True)
    unchanged()
    stage('zstd-metadata-public-inspection-533', 600,
        [PYTHON, '-B', OUT / 'verify_zstd_metadata_public_533.py'])
    print(json.dumps(dict(status='passed', full43_pending=True)), flush=True)


if __name__ == '__main__':
    main()
