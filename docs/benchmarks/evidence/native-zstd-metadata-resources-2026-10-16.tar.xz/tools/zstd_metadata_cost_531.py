"""Bind new metadata ownership to the unchanged compression lifecycle screen."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

import compression_cost_456c as c

BASE = 'b1f4397065861d0e7def468b39f706a4610ece80'
c.DEST = c.OUT / 'zstd-metadata-cost-530'
c.BASE = BASE
CONTRACT = c.ROOT / 'docs/architecture/native-zstd-metadata-resources-2026-10-16.md'
BASE_PROOF = c.DEST / 'baseline-git-verification-531.json'


def verify_build(value):
    assert value['status'] == 'passed'
    for name in ('source', 'build_receipt', 'build_log', 'binary', 'test_inventory'):
        item = value[name]
        assert c.bound(item['path']) == item, name
    receipt = c.read(value['build_receipt']['path'])
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['head'] == BASE
    assert receipt['log_sha256'] == value['build_log']['sha256']
    assert receipt['command'] == value['command']
    assert receipt['environment'] == value['environment']
    assert all(flag in receipt['command'] for flag in ('--release', '--no-run', 'release-user-surfaces'))


def verify_baseline_git():
    source = c.read(c.DEST / 'baseline-source.json')
    assert source['head'] == BASE
    names = sorted(source['source_sha256'])
    tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE],
                                      cwd=c.ROOT, text=True).splitlines()
    expected = {name for name in tracked if name.endswith(('.rs', '.py', 'Cargo.toml'))
                or name == 'Cargo.lock' or name.startswith('.cargo/')}
    assert set(names) == expected
    objects = subprocess.run(['git', 'cat-file', '--batch'], cwd=c.ROOT,
        input=''.join(BASE + ':' + name + '\n' for name in names).encode(),
        stdout=subprocess.PIPE, check=True).stdout
    stream = io.BytesIO(objects)
    for name in names:
        _, kind, size = stream.readline().decode().strip().split()
        assert kind == 'blob'
        payload = stream.read(int(size))
        assert stream.read(1) == b'\n'
        assert hashlib.sha256(payload).hexdigest() == source['source_sha256'][name], name
    assert stream.read() == b''
    proof = dict(status='passed', commit=BASE, source=c.bound(c.DEST / 'baseline-source.json'),
        files=len(names), all_runtime_blobs_match_frozen_build_source=True,
        baseline_freeze_helper=c.bound(c.OUT / 'freeze_zstd_metadata_build_530.py'),
        baseline_source_helper=c.bound(c.OUT / 'freeze_zstd_metadata_sources_530.py'))
    c.save(BASE_PROOF, proof)
    return proof


def prepare():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=c.ROOT, text=True).strip() == BASE
    c.prepare('candidate')


def freeze_build(receipt_path):
    source = c.read(c.DEST / 'candidate-source.json')
    assert c.sources(c.ROOT) == source['source_sha256'] and source['head'] == BASE
    receipt = c.read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    log = Path(receipt_path).with_suffix('.log')
    assert c.sha(log) == receipt['log_sha256']
    original, = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', log.read_text())
    original = Path(original)
    target = c.DEST / 'shardloom-zstd-metadata-candidate'
    c.storage(c.DEST, original.stat().st_size + 128 * c.MIB)
    assert not target.exists()
    before = c.sha(original)
    shutil.copy2(original, target)
    assert c.sha(original) == c.sha(target) == before
    listing = subprocess.check_output([str(target), '--list'], text=True)
    assert c.TEST + ': test' in listing
    assert 'native_zstd_metadata_clones_slices_and_casts_share_credit_at_a_full_grant' in listing
    inventory = c.DEST / 'candidate-test-list.txt'
    with inventory.open('x') as stream:
        stream.write(listing)
    value = dict(status='passed', role='candidate', root=str(c.ROOT),
        source=c.bound(c.DEST / 'candidate-source.json'), binary=c.bound(target),
        build_receipt=c.bound(receipt_path), build_log=c.bound(log),
        test_inventory=c.bound(inventory), test_name=c.TEST,
        command=receipt['command'], environment=receipt['environment'])
    verify_build(value)
    c.save(c.DEST / 'candidate-build.json', value)
    print(json.dumps(dict(status='frozen', role='candidate', binary_sha256=before)))


def freeze_protocol():
    proof = verify_baseline_git()
    identities = {}
    for role in ('baseline', 'candidate'):
        manifest = c.DEST / (role + '-build.json')
        value = c.read(manifest)
        verify_build(value)
        identities[role] = dict(manifest=c.bound(manifest), **value)
    baseline = c.read(identities['baseline']['source']['path'])
    assert baseline['contract_sha256'] == c.sha(CONTRACT)
    assert baseline['harness_sha256'] == c.sha(c.ROOT / c.HARNESS)
    assert identities['baseline']['binary']['sha256'] != identities['candidate']['binary']['sha256']
    names = {role: {line.removesuffix(': test') for line in
        Path(value['test_inventory']['path']).read_text().splitlines() if line.endswith(': test')}
        for role, value in identities.items()}
    assert not names['baseline'] - names['candidate']
    added = names['candidate'] - names['baseline']
    expected = set()
    for name in ('native_provider_zstd_metadata_tests.rs', 'resident_memory_zstd_transfer_tests.rs'):
        expected.update(re.findall(r'^fn ((?:native_zstd_metadata_|encoded_transfer_zstd_)\w+)\(',
            (c.ROOT / 'shardloom-vortex/src' / name).read_text(), re.M))
    assert len(expected) == len(added) == 9
    assert {name.split('::')[-1] for name in added} == expected
    helpers = [Path(__file__), Path(c.__file__), c.SUPERVISOR, c.OUT / 'run_guarded.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
        c.OUT / 'freeze_zstd_metadata_build_530.py', c.OUT / 'freeze_zstd_metadata_sources_530.py']
    helpers += [c.ROOT / 'scripts' / name for name in (
        'timed_native_command.py', 'run_clickbench_query_uat.py',
        'run_clickbench_paired_query_uat.py', 'local_uat_storage.py')]
    protocol = dict(schema='shardloom.zstd_metadata_lifecycle_cost.v1', frozen_at=time.time(),
        identities=identities, helpers=[c.bound(path) for path in helpers],
        baseline_git_proof=c.bound(BASE_PROOF), baseline_source_files=proof['files'],
        contract=c.bound(CONTRACT),
        inherited_contract=c.bound(c.ROOT / 'docs/architecture/native-compression-resources-2026-10-15.md'),
        test_harness=c.bound(c.ROOT / c.HARNESS), test_name=c.TEST,
        binary_inventory_delta=dict(retained_tests=len(names['baseline']), added_candidate_tests=sorted(added)),
        cases=[dict(kind=kind, rows=rows, encoding=encoding,
                    frame_rows=128 if rows == 4096 else 1024, grant_bytes=64 * c.MIB)
               for kind in ('nullable_i64', 'nullable_utf8', 'nullable_binary')
               for rows in (4096, 65536)
               for encoding in ('canonical', 'zstd_no_dictionary', 'zstd_dictionary')],
        samples_per_case=3, operations_per_sample=25, recorded_warmups_per_case=1,
        elapsed_gate=dict(relative=.10, absolute_seconds_per_operation=.0001),
        process_cpu_gate=dict(relative=.10, absolute_seconds=1),
        process_rss_gate=dict(relative=.25, absolute_bytes=64 * c.MIB),
        repeat_rule='Any forward breach triggers the complete reverse order. Repeated same-cell/metric breaches require diagnosis before retention.',
        operation_clock='Session creation, encode/train, native serialization and SHA256, producer close, fresh-session reopen/decode, full reference-value/null checking, all owned cleanup. Fixture/reference construction is outside.',
        process_clock='Native test executable creation through exit, including all fixtures, warmups, samples and output; separate from supervised cohort duration.',
        cache='Input is generated in memory; ordinary allocator and OS caches are uncontrolled. No pacing, cache flush, or battery/thermal admission.',
        performance_claim_allowed=False, platform=platform.platform(), logical_cpus=os.cpu_count(),
        physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES'),
        rust=subprocess.check_output(['/Users/dylan/.cargo/bin/rustup','run','1.99.0','rustc','-Vv'],text=True))
    verify(protocol)
    c.save(c.DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen_protocol', cases=18, operations_per_executable=1368,
                         baseline_files=proof['files'], added_tests=len(added))))


def verify(protocol):
    for item in protocol['helpers'] + [protocol[key] for key in
            ('contract', 'inherited_contract', 'test_harness', 'baseline_git_proof')]:
        assert c.bound(item['path']) == item
    for role, value in protocol['identities'].items():
        assert c.bound(value['manifest']['path']) == value['manifest']
        verify_build(value)
        source = c.read(value['source']['path'])
        assert source['head'] == BASE
        if role == 'candidate':
            assert c.sources(c.ROOT) == source['source_sha256']
        else:
            proof = c.read(protocol['baseline_git_proof']['path'])
            assert proof['status'] == 'passed' and proof['commit'] == BASE
            assert proof['source'] == value['source']
            assert proof['files'] == len(source['source_sha256'])


c.verify = verify
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('prepare','freeze-build','freeze-protocol','run','decide'))
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--order', choices=('forward','reverse'))
    args = parser.parse_args()
    if args.operation == 'prepare': prepare()
    elif args.operation == 'freeze-build': freeze_build(args.receipt)
    elif args.operation == 'freeze-protocol': freeze_protocol()
    elif args.operation == 'run': c.run(args.order)
    else: c.decide()
