"""Bind the accepted baseline build to its exact source and retained executable."""
import json
from pathlib import Path
import re
import shutil
import subprocess

import freeze_zstd_metadata_sources_530 as f

TEST = 'native_provider_memory::zstd_tests::compression_cost_tests::native_zstd_complete_compression_cost_screen'
source = json.loads((f.DEST / 'baseline-source.json').read_text())
assert f.sources() == source['source_sha256']
receipt_path = f.OUT / 'zstd-metadata-baseline-build-530.json'
receipt = json.loads(receipt_path.read_text())
log_path = receipt_path.with_suffix('.log')
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['direct_child_reaped']
assert f.sha(log_path) == receipt['log_sha256']
assert all(flag in receipt['command'] for flag in ('--release', '--no-run', 'release-user-surfaces'))
original, = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', log_path.read_text())
original = Path(original)
target = f.DEST / 'shardloom-zstd-metadata-baseline'
assert not target.exists()
before = f.sha(original)
shutil.copy2(original, target)
assert f.sha(original) == f.sha(target) == before
listing = subprocess.check_output([str(target), '--list'], text=True)
assert TEST + ': test' in listing
inventory = f.DEST / 'baseline-test-list.txt'
with inventory.open('x') as stream:
    stream.write(listing)

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=f.sha(path))

record = dict(status='passed', role='baseline', root=str(f.ROOT),
              source=identity(f.DEST / 'baseline-source.json'),
              binary=identity(target), build_receipt=identity(receipt_path),
              build_log=identity(log_path), test_inventory=identity(inventory),
              test_name=TEST, command=receipt['command'], environment=receipt['environment'])
with (f.DEST / 'baseline-build.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status='frozen', binary_sha256=before,
                     source_files=len(source['source_sha256']))))
