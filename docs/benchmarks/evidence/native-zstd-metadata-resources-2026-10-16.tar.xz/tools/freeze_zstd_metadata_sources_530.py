"""Freeze the unmodified provider and complete lifecycle harness before edits."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
DEST = OUT / 'zstd-metadata-cost-530'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sources():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT
    ).decode().split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(names))
            if name and (name.endswith(('.rs', '.py', 'Cargo.toml'))
                         or name == 'Cargo.lock' or name.startswith('.cargo/'))
            and (ROOT / name).is_file()}


def main():
    DEST.mkdir(exist_ok=False)
    record = dict(
        root=str(ROOT),
        head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        status=subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
        source_sha256=sources(),
        contract_sha256=sha(ROOT / 'docs/architecture/native-zstd-metadata-resources-2026-10-16.md'),
        harness_sha256=sha(ROOT / 'shardloom-vortex/src/native_provider_zstd_compression_cost_tests.rs'),
    )
    assert record['head'] == 'b1f43970' or record['head'].startswith('b1f43970')
    assert not subprocess.check_output(['git', 'diff', '--', '*.rs', '*.py', 'Cargo.toml', 'Cargo.lock'], cwd=ROOT)
    with (DEST / 'baseline-source.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='frozen', source_files=len(record['source_sha256']))))


if __name__ == '__main__':
    main()
