"""Package complete metadata ownership acceptance and its retained counterevidence."""
import ast
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_zstd_metadata_acceptance_533 import (
    SOURCE, MANIFEST, PROTOCOL, PUBLIC, DIRECT, PUBLIC_ACCEPTANCE,
    identity, unchanged, load, prerequisites, protocol, receipt,
)
from package_selection_acceptance_409 import Members, verify, sha_stream, excluded_identity

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

BASE = 'b1f4397065861d0e7def468b39f706a4610ece80'
STEM = 'native-zstd-metadata-resources-2026-10-16'
LOCAL = OUT / 'zstd-metadata-packet-534'
DEST = ROOT / 'docs/benchmarks/evidence'
CHECKS = OUT / 'zstd-metadata-checks-532.json'
FULL = OUT / 'zstd-metadata-full43-review-533.json'
INSPECTION = OUT / 'zstd-metadata-public-inspection-report-533.json'
COST_REVIEW = OUT / 'zstd-metadata-cost-review-534.json'
CONTRACT = ROOT / 'docs/architecture/native-zstd-metadata-resources-2026-10-16.md'
MAX_RAW_BYTES = 256 * MIB


def read(path):
    return json.loads(Path(path).read_text())


def main():
    assert not LOCAL.exists()
    assert all(not (DEST / (STEM + suffix)).exists() for suffix in ('.json', '.tar.xz', '.manifest.json.xz'))
    prerequisites()
    accepted, artifacts, declared = unchanged(), load(), protocol()
    assert accepted['head'] == artifacts['head'] == BASE
    assert len(accepted['source_sha256']) == 2307
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    checks = read(CHECKS)
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert counts['workspace-tests']['passed'] == 3221 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4294 and counts['native-tests']['ignored'] == 29
    prior = read(OUT / 'stream-dynamic-subquery-checks-524.json')
    old_native = next(row['tests'] for row in prior['completed'] if row['stage'] == 'native-tests')
    assert old_native['passed'] + 9 == 4294
    assert sorted(old_native['ignored_declarations']) == sorted(counts['native-tests']['ignored_declarations'])
    test_protocol = read(checks['protocol']['path'])
    native_log = Path(next(row['log']['path'] for row in checks['completed'] if row['stage'] == 'native-tests')).read_text()
    assert len(test_protocol['required_tests']) == 9
    for name in test_protocol['required_tests']:
        assert re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.M), name
    vendor = read(OUT / 'zstd-metadata-vendor-531c/summary.json')
    assert vendor['status'] == 'passed' and vendor['sources_unchanged'] and len(vendor['completed']) == 3
    assert sha(OUT / 'zstd-metadata-vendor-531c/protocol.json') == vendor['protocol_sha256']
    vendor_log = (OUT / 'zstd-metadata-vendor-531c.log').read_text()
    assert re.search(r'test result: ok\. 67 passed; 0 failed; 0 ignored;', vendor_log)
    direct = read(DIRECT)
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['test_names'] == declared['expected_direct_names']
    assert direct['source'] == identity(SOURCE) and direct['artifact_manifest'] == identity(MANIFEST)
    runtime, public, inspected = read(PUBLIC_ACCEPTANCE), read(PUBLIC / 'summary.json'), read(INSPECTION)
    assert runtime['status'] == public['status'] == inspected['status'] == 'passed'
    assert runtime['manifest'] == identity(MANIFEST) and runtime['source'] == identity(SOURCE)
    assert [row['name'] for row in public['cases']] == declared['expected_public_names']
    assert public['families'] == declared['expected_public_families'] and all(row['status'] == 'passed' for row in public['cases'])
    assert inspected['cases'] == 4827 and inspected['families'] == 36
    assert inspected['summary'] == runtime['summary'] == identity(PUBLIC / 'summary.json')
    assert inspected['accepted_source'] == identity(SOURCE)
    cost_review = read(COST_REVIEW)
    assert cost_review['status'] == 'passed' and cost_review['decision_status'] == 'retained_pending_broad_acceptance'
    assert cost_review['decision'] == identity(OUT / 'zstd-metadata-cost-530/decision.json')
    assert not cost_review['repeated_breaches'] and cost_review['independently_recomputed_from_complete_raw_samples']
    full = read(FULL)
    assert full['status'] == 'passed' and full['queries'] == full['calls'] == 43 and full['repeats'] == 1
    assert full['complete_rows'] == 381 and full['accepted_source'] == identity(SOURCE)
    assert full['all_values_schemas_and_clocks_reopened'] and full['native_children_absent']
    assert full['resources_no_fallback_native_certificates'] and full['original_input_and_sources_unchanged']
    admission = read(full['admission']['path'])
    assert admission['source_resident_before_read'] and admission['no_new_ingest']
    final_receipts = [Path(row['receipt']['path']) for row in checks['completed']]
    final_receipts += [OUT / (name + '.json') for name in (
        'zstd-metadata-vendor-531c', 'zstd-metadata-candidate-build-532',
        'zstd-metadata-freeze-build-533', 'zstd-metadata-freeze-cost-533',
        'zstd-metadata-cost-forward-533', 'zstd-metadata-cost-decision-533',
        'native-final-cli-release-build-zstdmetadata532', 'native-final-python-release-build-zstdmetadata532',
        'zstd-metadata-freeze-native-533', 'zstd-metadata-declarations-533', 'zstd-metadata-direct-533',
        'zstd-metadata-public-533', 'zstd-metadata-public-inspection-533',
        'zstd-metadata-cost-inspection-534', 'zstd-metadata-full43-533')]
    if read(OUT / 'zstd-metadata-cost-530/decision.json')['reverse']:
        final_receipts.append(OUT / 'zstd-metadata-cost-reverse-533.json')
    for path in final_receipts:
        receipt(path)

    members, exclusions = Members(), []
    def add(path, name, role, digest=None):
        path = Path(path)
        root = ROOT if path.is_relative_to(ROOT) else OUT if path.is_relative_to(OUT) else path.parent
        members.add(path, name, root.name, root, role, digest)

    changed = set(subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=ROOT, text=True).splitlines())
    changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines())
    overlay = sorted(changed & accepted['source_sha256'].keys())
    assert len(overlay) == 17
    for name in overlay:
        add(ROOT / name, 'source-overlay/' + name, 'complete changed runtime source', accepted['source_sha256'][name])
    baseline_provenance = OUT / 'zstd-metadata-baseline-provenance-534.json'
    baseline_provenance_bytes = subprocess.check_output(['git', 'cat-file', 'blob',
        BASE + ':vendor/vortex-zstd/upstream-provenance.json'], cwd=ROOT)
    with baseline_provenance.open('xb') as stream:
        stream.write(baseline_provenance_bytes)
    add(baseline_provenance, 'baseline-provider/upstream-provenance.json', 'exact immutable baseline provider provenance')
    add(CONTRACT, 'contracts/metadata-contract.md', 'exact predeclared ownership contract', declared['contract']['sha256'])
    inherited = ROOT / 'docs/architecture/native-compression-resources-2026-10-15.md'
    add(inherited, 'contracts/compression-contract.md', 'inherited unchanged lifecycle cost gates')
    for path in (SOURCE, MANIFEST):
        add(path, 'manifests/' + path.name, 'complete frozen accepted source or artifact manifest')
    # Known prefixes preserve the portable public and Full43 verifier contracts.
    members.tree(PUBLIC, 'public', 'public', 'complete public regression logs and source snapshots', exclusions, omit_outputs=True)
    for path, name in (
        (OUT / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json', 'predeclared-reference/unary-predeclared-values.json'),
        (OUT / 'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json', 'predeclared-reference/subquery-predeclared-results.json'),
        (OUT / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json', 'declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'),
        (OUT / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json', 'declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'),
        (OUT / 'stream-dynamic-inner-baseline-513/summary.json', 'baseline/summary.json')):
        add(path, name, 'unchanged independent pre-execution complete reference values')
    for item in [admission['reference'], admission['queries'], *admission['harness'], *admission['schema_sources']]:
        prefix = 'full43-baseline-schemas' if item in admission['schema_sources'] else 'full43-inputs'
        add(item['path'], prefix + '/' + Path(item['path']).name, 'predeclared Full43 input/reference/schema/helper', item['sha256'])
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43', 'complete one-pass Full43 evidence', exclusions)
    for folder in ('zstd-metadata-cost-530', 'zstd-metadata-vendor-531', 'zstd-metadata-vendor-531b', 'zstd-metadata-vendor-531c'):
        members.tree(OUT / folder, folder, folder, 'complete frozen lifecycle or vendor evidence including failures', exclusions)
    skip = {'zstd-metadata-package-534.log', 'zstd-metadata-package-534.json'}
    helper_paths = []
    for path in sorted(OUT.iterdir()):
        if (path.is_file() and path.name not in skip and
                (re.search(r'zstd[-_]metadata', path.name) or 'zstdmetadata' in path.name) and
                path.suffix in ('.json', '.log', '.py', '.diff', '.md')):
            add(path, ('tools/' if path.suffix == '.py' else 'receipts/') + path.name,
                'metadata candidate observation/helper; failures and filtered commands remain counterevidence')
            if path.suffix == '.py':
                helper_paths.append(path)
    for item in [declared['prior_protocol'], declared['prior_direct'],
                 identity(OUT / 'stream-dynamic-subquery-checks-524.json'),
                 *inspected['predeclared_value_files']]:
        if 'original' in item:
            item = item['original']
        add(item['path'], 'prior-identities/' + Path(item['path']).name, 'unchanged prior oracle or exclusion inventory', item['sha256'])
    for field in ('retained_initial_failures', 'corrected_source', 'dynamic_initial_failures', 'dynamic_initial_diagnosis'):
        item = inspected[field]
        add(item['path'], 'inherited-context/' + Path(item['path']).name, 'historical oracle provenance already retained in the prior accepted unit', item['sha256'])
    for artifact in (artifacts['cli'], artifacts['binding']):
        assert identity(artifact['path']) == {k: artifact[k] for k in ('path', 'bytes', 'sha256')}
        exclusions.append(excluded_identity(Path(artifact['path']),
            'executables/' + Path(artifact['path']).parent.name + '/' + Path(artifact['path']).name,
            'frozen executable excluded; complete source/build identity retained'))
    item = admission['input']
    exclusions.append(dict(archive_path='resident-input/' + Path(item['path']).name,
        original_absolute_path=item['path'], byte_count=item['bytes'], sha256=item['sha256'],
        reason='large resident input excluded; complete before/after identity proof retained'))
    for name, digest in accepted['source_sha256'].items():
        if name.startswith('python/src/'):
            add(ROOT / name, 'python-package/' + name.removeprefix('python/src/'), 'complete source Python package', digest)
    # Preserve the import closure of local helpers plus their explicit dynamic guard.
    external = Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
    supervisor = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    roots = (OUT, ROOT / 'scripts', ROOT / 'python/src', external)
    helper_paths += [OUT / name for name in ('package_selection_acceptance_409.py',
        'verify_stream_unary_packet_497.py', 'verify_stream_dynamic_subquery_packet_522.py',
        'metadata_public_verifier_534.py', 'run_guarded.py')]
    helper_paths += [supervisor, external / 'release_validation_guard.py',
        ROOT / 'scripts/timed_native_command.py', ROOT / 'scripts/build_native_python.py']
    visited = set()
    while helper_paths:
        path = helper_paths.pop().resolve()
        if path in visited:
            continue
        visited.add(path)
        prefix = ('repository/' + path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else
                  'local/' + path.relative_to(OUT).as_posix() if path.is_relative_to(OUT) else
                  'external/' + path.parent.name + '/' + path.name)
        add(path, 'dependencies/' + prefix, 'transitive local helper source')
        for node in ast.walk(ast.parse(path.read_text())):
            modules = ([name.name for name in node.names] if isinstance(node, ast.Import) else
                       [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else [])
            for module in modules:
                for root in roots:
                    module_path = root.joinpath(*module.split('.'))
                    candidate = module_path.with_suffix('.py')
                    if not candidate.is_file():
                        candidate = module_path / '__init__.py'
                    if candidate.is_file():
                        helper_paths.append(candidate)
                        break

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= MAX_RAW_BYTES, raw_size
    require_local_path(LOCAL, Path.home(), sys.platform)
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (STEM + '.tar.xz')
    with archive_path.open('xb') as target:
        with tarfile.open(fileobj=target, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as stream:
                    archive.addfile(info, stream)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names)
    for item in ordered:
        verify(item.path, item.digest, item.size)
    assert unchanged() == accepted and load() == artifacts
    prerequisites()
    acceptance = dict(workspace_tests=3221, workspace_ignored=0, native_tests=4294, native_ignored=29,
        vendor_tests=67, new_vendor_tests=6, new_native_tests=9, direct_methods=100, direct_skips=0,
        public_cases=4827, public_families=36, lifecycle_cases=18,
        lifecycle_operations=2736 * (2 if cost_review['reverse'] else 1),
        full43_queries=43, full43_calls=43, full43_repeats=1, full43_complete_rows=381)
    limitations = ['The reservation covers requested frame-vector capacities, not fixed Arc headers, allocator bookkeeping, all process RSS or OS allocation success.',
        'Raw construction/export remains caller-owned; independently supplied Zstd IPC, other codecs, general state spill and transport retain separate contracts.',
        'One finite regression pass and a cost-retention screen do not establish a speedup, package release or all-platform readiness.',
        'Direct binding tests use the source Python package with frozen native artifacts; installed-wheel and hosted proof remain separate gates.']
    manifest = dict(status='passed_local_evidence_packaged', base_commit=BASE, source_files=2307,
        source_manifest=identity(SOURCE), artifact_manifest=identity(MANIFEST), source_overlay=overlay,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True, exclusions=exclusions,
        storage=storage, acceptance=acceptance, final_receipts=[identity(p) for p in final_receipts],
        public_inspection=identity(INSPECTION), full43_review=identity(FULL), lifecycle_review=identity(COST_REVIEW),
        original_contract=identity(CONTRACT), source_identity_preserved=True, publication_attempted=False,
        baseline_provider_provenance=identity(baseline_provenance),
        limitations=limitations)
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw, preset=6)
    assert lzma.decompress(packed) == raw
    manifest_path = LOCAL / (STEM + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.native_zstd_metadata_resources_evidence.v1',
        status='packaged_local_pending_acceptance_decision', base_commit=BASE, source_files=2307,
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True, acceptance=acceptance,
        source_manifest=manifest['source_manifest'], artifact_manifest=manifest['artifact_manifest'], source_overlay=overlay,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=len(packed), sha256=sha(manifest_path), raw_sha256=hashlib.sha256(raw).hexdigest()),
        limitations=limitations, publication_attempted=False, hosted_integration_complete=False)
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (STEM + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='all_members_reopened', member_count=len(seen),
        archive=identity(archive_path), manifest=identity(manifest_path), index=identity(DEST / (STEM + '.json')),
        helper=identity(__file__)))
    print(json.dumps(dict(status=index['status'], members=len(seen), raw_bytes=raw_size)))


if __name__ == '__main__':
    main()
