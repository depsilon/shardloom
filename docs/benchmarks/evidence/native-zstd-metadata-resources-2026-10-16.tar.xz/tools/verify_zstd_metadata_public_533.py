"""Reuse the complete compressed-evidence verifier against the metadata candidate."""
import verify_stream_dynamic_subquery_public_522 as review
import run_zstd_metadata_acceptance_533 as acceptance

review.PUBLIC = acceptance.PUBLIC
review.RUNTIME_PATH = acceptance.PUBLIC_ACCEPTANCE
review.RECEIPT_PATH = acceptance.OUT / 'zstd-metadata-public-533.json'
review.BASELINE_PATH = acceptance.PROTOCOL
review.OUTPUT = acceptance.OUT / 'zstd-metadata-public-inspection-report-533.json'
review.ACCEPTED_SOURCE = acceptance.SOURCE
review.load = acceptance.load
review.unchanged = acceptance.unchanged

if __name__ == '__main__':
    acceptance.protocol()
    review.main()
    acceptance.protocol()
