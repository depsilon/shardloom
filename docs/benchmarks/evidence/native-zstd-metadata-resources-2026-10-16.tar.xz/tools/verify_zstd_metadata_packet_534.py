"""Independently verify every portable metadata-ownership evidence member and result."""
import json
import lzma
from pathlib import Path
import re
import tarfile

from metadata_public_verifier_534 import verify_public
import verify_zstd_metadata_cost_534 as cost
from verify_stream_unary_packet_497 import need, digest, strict_json, safe_member, verify_full43

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/evidence'
STEM = 'native-zstd-metadata-resources-2026-10-16'
BASE = 'b1f4397065861d0e7def468b39f706a4610ece80'
OUTPUT = OUT / 'zstd-metadata-packet-audit-534.json'


def main():
    need(not OUTPUT.exists(), 'preserve earlier evidence inspection')
    index_path = DEST / (STEM + '.json')
    index = strict_json(index_path.read_bytes())
    need(index['schema_version'] == 'shardloom.native_zstd_metadata_resources_evidence.v1' and
         index['status'] == 'packaged_local_pending_acceptance_decision' and index['base_commit'] == BASE,
         'unexpected packet identity or status')
    for kind, suffix in (('archive', '.tar.xz'), ('manifest', '.manifest.json.xz')):
        path = DEST / index[kind]['file']
        need(path.name == STEM + suffix and path.is_file() and not path.is_symlink(), 'unsafe packet path')
        data = path.read_bytes()
        need(len(data) == index[kind]['bytes'] and digest(data) == index[kind]['sha256'], 'packet identity mismatch')
    raw_manifest = lzma.decompress((DEST / index['manifest']['file']).read_bytes())
    need(digest(raw_manifest) == index['manifest']['raw_sha256'], 'decoded manifest identity mismatch')
    manifest = strict_json(raw_manifest)
    need(manifest['status'] == 'passed_local_evidence_packaged' and manifest['base_commit'] == BASE,
         'unexpected manifest scope')
    for key in ('member_count', 'raw_bytes', 'source_files', 'source_overlay', 'acceptance',
                'source_manifest', 'artifact_manifest', 'all_members_reopened'):
        need(index[key] == manifest[key], 'index/manifest differs: ' + key)
    need(index['all_members_reopened'] and index['raw_bytes'] <= 256 * 1024 ** 2 and index['source_files'] == 2307,
         'invalid archive bounds')
    expected, originals = {}, {}
    for row in manifest['members']:
        name = row['archive_path']
        safe_member(name)
        need(name not in expected and row['path'] not in originals, 'duplicate archived identity')
        expected[name], originals[row['path']] = row, name
    members = {}
    with tarfile.open(DEST / index['archive']['file'], mode='r|xz') as archive:
        for entry in archive:
            need(entry.isfile() and entry.name in expected and entry.name not in members,
                 'unexpected, repeated or non-file archive member')
            safe_member(entry.name)
            with archive.extractfile(entry) as stream:
                data = stream.read()
            row = expected[entry.name]
            need(len(data) == entry.size == row['bytes'] and digest(data) == row['sha256'], entry.name)
            members[entry.name] = data
    need(set(members) == set(expected) and len(members) == manifest['member_count'] and
         sum(map(len, members.values())) == manifest['raw_bytes'], 'incomplete archive coverage')

    def by_path(path):
        key = str(path)
        need(key in originals, 'bound evidence absent from archive: ' + key)
        return members[originals[key]]

    def reference(item):
        data = by_path(item['path'])
        need(len(data) == item['bytes'] and digest(data) == item['sha256'], 'bound identity differs: ' + item['path'])
        return data

    def archived_identity(path):
        data = by_path(path)
        return dict(path=str(path), bytes=len(data), sha256=digest(data))

    source = strict_json(reference(manifest['source_manifest']))
    artifacts = strict_json(reference(manifest['artifact_manifest']))
    need(source['head'] == artifacts['head'] == BASE and source['source_sha256'] == artifacts['source_sha256'] and
         artifacts['status'] == 'passed' and artifacts['build_profile'] == 'release', 'source/build binding differs')
    source_map = source['source_sha256']
    need(len(source_map) == 2307 and len(manifest['source_overlay']) == 17, 'source or overlay count differs')
    for name in manifest['source_overlay']:
        need(digest(members['source-overlay/' + name]) == source_map[name], 'source overlay differs: ' + name)
    old_provenance = strict_json(reference(manifest['baseline_provider_provenance']))
    new_provenance = strict_json(members['source-overlay/vendor/vortex-zstd/upstream-provenance.json'])
    need({key for key in set(old_provenance) | set(new_provenance)
          if old_provenance.get(key) != new_provenance.get(key)} == {'local_changes'},
         'provider provenance changed beyond the declared local implementation')
    bundle = strict_json(members['source-overlay/python/THIRD_PARTY_LICENSES/manifest.json'])
    def contains_provenance(value):
        if value == new_provenance:
            return True
        if isinstance(value, dict):
            return any(contains_provenance(child) for child in value.values())
        if isinstance(value, list):
            return any(contains_provenance(child) for child in value)
        return False
    need(contains_provenance(bundle), 'Python bundle lacks the exact provider provenance')
    for name, expected_sha in source_map.items():
        path = ROOT / name
        need(path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected_sha,
             'current source changed: ' + name)
    excluded = {row['original_absolute_path']: row for row in manifest['exclusions']}
    for kind in ('cli', 'binding'):
        item = artifacts[kind]
        need(item['path'] in excluded and excluded[item['path']]['byte_count'] == item['bytes'] and
             excluded[item['path']]['sha256'] == item['sha256'], 'executable exclusion identity differs')
        build_receipt = strict_json(by_path(item['build_receipt']))
        need(digest(by_path(item['build_receipt'])) == item['build_receipt_sha256'] and
             build_receipt['head'] == BASE and '--release' in build_receipt['command'] and
             digest(by_path(item['build_log'])) == build_receipt['log_sha256'], 'release build recipe differs')
    for row in manifest['final_receipts']:
        result = strict_json(reference(row))
        need(result['status'] == 'passed' and result['returncode'] == 0 and result['head'] == BASE and
             result['process_group_drained'] and result['direct_child_reaped'] and
             not result['timed_out'] and not result['group_absence_unproved_at_cleanup'], 'final process gate incomplete')
        need(digest(by_path(Path(row['path']).with_suffix('.log'))) == result['log_sha256'], 'supervisor log differs')
    checks = strict_json(by_path(OUT / 'zstd-metadata-checks-532.json'))
    test_protocol = strict_json(reference(checks['protocol']))
    need(checks['status'] == 'passed' and checks['source_identity_preserved'] and
         checks['source'] == manifest['source_manifest'], 'broad gate source differs')
    need([row['stage'] for row in checks['completed']] ==
         ['fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests'], 'broad gates missing')
    counts = {}
    for row in checks['completed']:
        log = reference(row['log']).decode()
        reference(row['receipt'])
        if row['stage'].endswith('tests'):
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)
            need(groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups), 'failed or filtered broad tests')
            counts[row['stage']] = (sum(int(g[0]) for g in groups), sum(int(g[2]) for g in groups))
        if row['stage'] == 'native-tests':
            ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', log, re.M)
            need(sorted(ignored) == sorted(tuple(x) for x in test_protocol['expected_ignored']), 'manual exclusions changed')
            need(len(test_protocol['required_tests']) == 9, 'new native coverage missing')
            for name in test_protocol['required_tests']:
                need(re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', log, re.M), name)
    need(counts == {'workspace-tests': (3221, 0), 'native-tests': (4294, 29)}, 'broad test totals differ')
    previous = strict_json(reference(test_protocol['previous_ignored_inventory']))
    old_ignored = next(row['tests']['ignored_declarations'] for row in previous['completed'] if row['stage'] == 'native-tests')
    need(sorted(old_ignored) == sorted(test_protocol['expected_ignored']), 'prior exclusion list differs')
    vendor_log = by_path(OUT / 'zstd-metadata-vendor-531c.log').decode()
    need(re.search(r'test result: ok\. 67 passed; 0 failed; 0 ignored;', vendor_log), 'vendor tests incomplete')
    vendor_source = members['source-overlay/vendor/vortex-zstd/src/metadata_resources_tests.rs'].decode()
    vendor_tests = re.findall(r'^#\[test\]\nfn (\w+)\(', vendor_source, re.M)
    need(len(vendor_tests) == 6, 'vendor metadata coverage missing')
    for name in vendor_tests:
        need(re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', vendor_log, re.M), name)

    declared = strict_json(by_path(OUT / 'zstd-metadata-acceptance-protocol-533.json'))
    need(declared['status'] == 'predeclared' and declared['native_engine_executions'] == 0 and
         declared['source'] == manifest['source_manifest'] and declared['artifacts'] == manifest['artifact_manifest'],
         'public/direct predeclaration differs')
    need(reference(manifest['original_contract']) == reference(declared['contract']), 'predeclared contract differs')
    for item in declared['helpers'] + [declared[key] for key in ('prior_protocol', 'prior_direct', 'baseline', 'checks', 'cost')]:
        reference(item)
    direct = strict_json(by_path(OUT / 'zstd-metadata-direct-tests-533.json'))
    need(direct['status'] == 'passed' and direct['tests'] == 100 and
         direct['failures'] == direct['errors'] == direct['skipped'] == 0 and
         direct['test_names'] == declared['expected_direct_names'], 'direct binding matrix incomplete')
    need(direct['source'] == manifest['source_manifest'] and direct['artifact_manifest'] == manifest['artifact_manifest'],
         'direct matrix used different artifacts')
    public = verify_public(members, by_path(OUT / 'zstd-metadata-public-533.log'), declared)
    inspected = strict_json(reference(manifest['public_inspection']))
    need(inspected['status'] == 'passed' and inspected['accepted_source'] == manifest['source_manifest'] and
         inspected['summary'] == archived_identity(OUT / 'zstd-metadata-public-533/summary.json'), 'public inspection binding differs')
    totals = inspected['compressed_json_totals']
    need(public['compressed_json_files'] == totals['files'] and
         public['compressed_stored_bytes'] == totals['stored_bytes'] and
         public['decoded_raw_bytes'] == totals['decoded_raw_bytes'], 'reopened public byte totals differ')
    public_summary = strict_json(members['public/summary.json'])
    for path, expected_sha in public_summary['sources'].items():
        if path in originals:
            data = by_path(path)
        elif path in excluded:
            need(excluded[path]['sha256'] == expected_sha, 'excluded public executable identity differs')
            continue
        else:
            data = members['public/logs/' + Path(path).name]
        need(digest(data) == expected_sha, 'public source snapshot differs: ' + path)

    # The same arithmetic auditor reads exclusively through the archive map here.
    cost.identity = archived_identity
    cost.read = lambda path: strict_json(by_path(path))
    cost.read_text = lambda path: by_path(path).decode()
    lifecycle = cost.read(cost.D / 'protocol.json')
    cost_decision = cost.read(cost.D / 'decision.json')
    expected_cells = [dict(kind=kind, rows=rows, encoding=encoding,
        frame_rows=128 if rows == 4096 else 1024, grant_bytes=64 * 1024 ** 2)
        for kind in ('nullable_i64', 'nullable_utf8', 'nullable_binary')
        for rows in (4096, 65536)
        for encoding in ('canonical', 'zstd_no_dictionary', 'zstd_dictionary')]
    need(lifecycle['samples_per_case'] == 3 and lifecycle['operations_per_sample'] == 25 and
         lifecycle['recorded_warmups_per_case'] == 1 and lifecycle['cases'] == expected_cells,
         'lifecycle workload differs')
    need(lifecycle['elapsed_gate'] == dict(relative=.10, absolute_seconds_per_operation=.0001) and
         lifecycle['process_cpu_gate'] == dict(relative=.10, absolute_seconds=1) and
         lifecycle['process_rss_gate'] == dict(relative=.25, absolute_bytes=64 * 1024 ** 2), 'lifecycle cost gates differ')
    for item in lifecycle['helpers'] + [lifecycle[key] for key in
            ('contract', 'inherited_contract', 'test_harness', 'baseline_git_proof')]:
        reference(item)
    for role, item in lifecycle['identities'].items():
        for key in ('manifest', 'source', 'build_receipt', 'build_log', 'test_inventory'):
            reference(item[key])
        blob = item['binary']
        need(blob['path'] in excluded and excluded[blob['path']]['sha256'] == blob['sha256'] and
             excluded[blob['path']]['byte_count'] == blob['bytes'], 'cost executable identity differs')
        build = strict_json(reference(item['build_receipt']))
        need(build['status'] == 'passed' and build['head'] == BASE and build['process_group_drained'] and
             build['direct_child_reaped'] and build['command'] == item['command'] and
             build['environment'] == item['environment'] and digest(reference(item['build_log'])) == build['log_sha256'],
             'cost build recipe differs')
    cost_sources = {role: strict_json(reference(item['source'])) for role, item in lifecycle['identities'].items()}
    need(len(cost_sources['baseline']['source_sha256']) == 2063 and
         len(cost_sources['candidate']['source_sha256']) == 2067 and
         all(value['head'] == BASE for value in cost_sources.values()), 'cost source identity differs')
    need(all(source_map[name] == value for name, value in cost_sources['candidate']['source_sha256'].items()),
         'lifecycle and public acceptance used different candidate source')
    test_sets = {role: {line.removesuffix(': test') for line in reference(item['test_inventory']).decode().splitlines()
                       if line.endswith(': test')} for role, item in lifecycle['identities'].items()}
    added = test_sets['candidate'] - test_sets['baseline']
    need(not test_sets['baseline'] - test_sets['candidate'] and len(added) == 9 and
         sorted(added) == lifecycle['binary_inventory_delta']['added_candidate_tests'] and
         {name.split('::')[-1] for name in added} == set(test_protocol['required_tests']), 'cost executable roles differ')
    forward = cost.inspect_order('forward', lifecycle)
    reverse = cost.inspect_order('reverse', lifecycle) if forward['breaches'] else None
    need(cost_decision['forward'] == forward['summary'] and cost_decision['reverse'] == (reverse['summary'] if reverse else None),
         'cost decision summary links differ')
    repeated = [x for x in forward['breaches'] if x in reverse['breaches']] if reverse else []
    need(not repeated and not cost_decision['repeated_breaches'] and
         cost_decision['status'] == 'retained_pending_broad_acceptance', 'cost screen was not retained')
    live_cost = strict_json(reference(manifest['lifecycle_review']))
    need(live_cost['forward'] == forward and live_cost['reverse'] == reverse and
         live_cost['decision'] == archived_identity(cost.D / 'decision.json'), 'portable cost recomputation differs')
    full_review = strict_json(reference(manifest['full43_review']))
    admission = strict_json(reference(full_review['admission']))
    full43 = verify_full43(members, full_review, admission)
    for row in admission['prerequisite_gates'].values():
        reference(row)
    # Retain the actual failed attempts and prove their recorded outcome/log identity.
    failures = []
    for path in originals:
        if Path(path).parent != OUT or not Path(path).name.startswith('zstd-metadata-') or not path.endswith('.json'):
            continue
        item = strict_json(by_path(path))
        if isinstance(item, dict) and item.get('status') == 'failed' and 'command' in item:
            need(item['process_group_drained'] and item['direct_child_reaped'] and item['returncode'] != 0,
                 'failed attempt lacks child cleanup')
            need(digest(by_path(Path(path).with_suffix('.log'))) == item['log_sha256'], 'failed log differs')
            failures.append(archived_identity(path))
    need(len(failures) >= 4, 'expected focused/vendor/lint counterevidence is missing')
    result = dict(status='passed', member_count=len(members), raw_bytes=manifest['raw_bytes'], source_files=2307,
        complete_archive_identity_and_membership_verified=True, source_overlay_verified=True,
        current_source_map_unchanged=True, required_test_counts=counts, vendor_tests=67,
        new_vendor_test_names=vendor_tests, new_native_test_names=test_protocol['required_tests'],
        direct_methods=100, direct_skips=0, public=public, lifecycle=dict(forward=forward, reverse=reverse),
        full43=full43, retained_failed_attempts=failures,
        engine_execution_seconds=sum(row['engine_execution_seconds'] for row in strict_json(members['full43/summary.json'])['records']),
        index=dict(path=str(index_path), bytes=index_path.stat().st_size, sha256=digest(index_path.read_bytes())),
        helper=dict(path=__file__, sha256=digest(Path(__file__).read_bytes())),
        no_speedup_claim=True, hosted_integration_complete=False, installed_wheel_proof=False)
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='passed', members=len(members), public_cases=public['cases'],
                         full43_calls=43, engine_execution_seconds=result['engine_execution_seconds'])))


if __name__ == '__main__':
    main()
