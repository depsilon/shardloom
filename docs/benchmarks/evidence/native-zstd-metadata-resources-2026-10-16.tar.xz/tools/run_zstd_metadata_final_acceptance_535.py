"""Finish raw cost review and Full43 sequentially after public acceptance."""
from pathlib import Path
import json
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT
from run_query_timing_runtime_461 import guarded
from run_zstd_metadata_acceptance_533 import unchanged, receipt


def main():
    python = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
    assert Path(sys.executable) == python
    receipt(OUT / 'zstd-metadata-public-inspection-533.json')
    unchanged()
    print(json.dumps(dict(stage='raw-cost-inspection', status='starting')), flush=True)
    guarded('zstd-metadata-cost-inspection-534', 180,
        [python, '-B', OUT / 'verify_zstd_metadata_cost_534.py'])
    unchanged()
    print(json.dumps(dict(stage='full43', status='starting')), flush=True)
    subprocess.run([str(python), '-B', str(OUT / 'run_zstd_metadata_full43_533.py')],
        cwd=ROOT, check=True)
    unchanged()
    print(json.dumps(dict(status='passed', packet_pending=True)), flush=True)


if __name__ == '__main__':
    main()
