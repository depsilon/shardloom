// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors
// Modified by ShardLoom on 2026-10-15: register bounded compression admission.
// Modified by ShardLoom on 2026-10-16: register shared frame metadata admission.

//! Zstd-backed compression encodings for variable-width Vortex arrays.
//!
//! [`ZstdArray`] stores UTF-8 or binary values as one or more zstd frames, optionally sharing a
//! trained dictionary across frames. Frame metadata lets slices decompress only the frames that can
//! contribute values to the requested row range.
//!
//! With the `unstable_encodings` feature, `ZstdBuffers` stores the buffers of another encoding as
//! independently compressed zstd buffers while preserving the inner encoding metadata.
//!
//! This crate exposes array encodings only. Compression scheme selection is wired through
//! `vortex-btrblocks` and file writing. To deserialize arrays manually, register the encoding in the
//! array session:
//!
//! ```rust
//! use vortex_array::session::ArraySessionExt;
//!
//! let session = vortex_array::array_session();
//! session.arrays().register(vortex_zstd::Zstd);
//! ```

pub use array::*;
use vortex_array::dtype::proto::dtype as pb;
use vortex_error::VortexResult;
use vortex_error::vortex_ensure;
use vortex_error::vortex_err;
#[cfg(feature = "unstable_encodings")]
pub use zstd_buffers::*;

mod array;
mod compression_resources;
mod compute;
mod decoder_workspace;
mod metadata_resources;
mod rules;
mod slice;
#[cfg(feature = "unstable_encodings")]
mod zstd_buffers;

#[cfg(test)]
mod test;

/// Ensure Vortex metadata agrees with the content size declared by a zstd frame.
pub(crate) fn validate_frame_content_size(
    frame: &[u8],
    metadata_size: u64,
    index: usize,
) -> VortexResult<()> {
    decoder_workspace::reject_legacy_header(frame)?;
    let frame_content_size = zstd::zstd_safe::get_frame_content_size(frame)
        .map_err(|error| vortex_err!("Invalid zstd frame {index}: {error}"))?
        .ok_or_else(|| vortex_err!("Zstd frame {index} does not declare a content size"))?;
    vortex_ensure!(
        metadata_size == frame_content_size,
        "Zstd frame {index} metadata declares {metadata_size} uncompressed bytes, but its header declares {frame_content_size}"
    );
    Ok(())
}

#[derive(Clone, prost::Message)]
/// Metadata for one zstd frame.
pub struct ZstdFrameMetadata {
    /// Uncompressed byte size of this frame.
    #[prost(uint64, tag = "1")]
    pub uncompressed_size: u64,
    /// Number of valid values stored in this frame.
    #[prost(uint64, tag = "2")]
    pub n_values: u64,
}

#[derive(Clone, prost::Message)]
/// Serialized metadata for a [`ZstdArray`].
pub struct ZstdMetadata {
    // optional, will be 0 if there's no dictionary
    /// Dictionary size in bytes, or `0` when no dictionary is present.
    #[prost(uint32, tag = "1")]
    pub dictionary_size: u32,
    /// Metadata for each compressed frame.
    #[prost(message, repeated, tag = "2")]
    pub frames: Vec<ZstdFrameMetadata>,
}

#[derive(Clone, prost::Message)]
/// Serialized metadata for the unstable `ZstdBuffers` encoding.
pub struct ZstdBuffersMetadata {
    /// Encoding id of the inner array whose buffers were compressed.
    #[prost(string, tag = "1")]
    pub inner_encoding_id: String,
    /// Serialized metadata of the inner array.
    #[prost(bytes = "vec", tag = "2")]
    pub inner_metadata: Vec<u8>,
    /// Uncompressed byte size of each compressed buffer.
    #[prost(uint64, repeated, tag = "3")]
    pub uncompressed_sizes: Vec<u64>,
    /// Alignment of each buffer in bytes (must be a power of two).
    #[prost(uint32, repeated, tag = "4")]
    pub buffer_alignments: Vec<u32>,
    /// DType of child arrays. Children belong to inner encodings, and their
    /// dtypes don't persist after serialization, so we need to retrieve them
    /// from metadata.
    #[prost(message, repeated, tag = "5")]
    pub child_dtypes: Vec<pb::DType>,
    /// Length of each child array, ordered as "child_dtypes"
    #[prost(uint64, repeated, tag = "6")]
    pub child_lens: Vec<u64>,
}
