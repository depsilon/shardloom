from pathlib import Path
import json,subprocess,sys
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo');O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010');N='/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';P=sys.executable
commands=[
('git-whitespace',['git','diff','--check'],R),
('rust-format',['cargo','fmt','--all','--','--check'],R),
('security-posture',[P,'scripts/check_security_posture.py','--json-output',str(O/'native-shared-execution-final-security-posture-625.json')],R),
('search-policy',[N,'--test','scripts/pagefind-policy.test.mjs'],R/'website-src'),
('website-prepare',[N,'scripts/prebuild-static.mjs','--reset-output'],R/'website-src'),
('website-content',[N,'scripts/sync-content.mjs'],R/'website-src'),
('website-types',[N,'node_modules/.bin/astro','check'],R/'website-src'),
('website-build',[N,'node_modules/.bin/astro','build'],R/'website-src'),
('website-static',[N,'scripts/postbuild-static.mjs'],R/'website-src'),
('website-assets',[N,'scripts/validate_static_assets.cjs'],R),
('website-links',[P,'-m','unittest','discover','-s','scripts','-p','test_website_links.py'],R),
('website-readiness',[P,'scripts/check_website_readiness.py','--output',str(O/'native-shared-execution-final-website-readiness-625.json')],R),
('public-status',[P,'scripts/check_public_status_docs.py','--output',str(O/'native-shared-execution-final-public-docs-625.json')],R),
('contribution',[P,'scripts/check_contribution_governance.py','--output',str(O/'native-shared-execution-final-contribution-625.json')],R)]
results=[]
for name,command,cwd in commands:
 print(json.dumps(dict(stage=name,command=command)),flush=True)
 run=subprocess.run(command,cwd=cwd);results.append(dict(name=name,command=command,returncode=run.returncode));assert run.returncode==0,name
sys.path.insert(0,str(R/'scripts'))
import check_production_certification_gate as cert
import check_production_usability_gate as usability
for name,function in [('production_claim_surfaces',cert.validate_claim_surfaces),('production_documentation',usability.validate_docs)]:
 result,blockers=function(R);assert not blockers,blockers
 (O/('native-shared-execution-final-'+name+'-625.json')).open('x').write(json.dumps(result,indent=2)+'\n')
 results.append(dict(name=name,blockers=blockers,returncode=0))
(O/'native-shared-execution-final-doc-results-625.json').open('x').write(json.dumps(dict(status='passed',checks=results),indent=2)+'\n')
print('FINAL_DOCUMENTATION_AND_WEBSITE_CHECKS_PASSED',flush=True)

