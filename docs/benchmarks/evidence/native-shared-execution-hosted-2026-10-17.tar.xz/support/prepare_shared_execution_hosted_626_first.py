"""Bind the retained hosted readers to this PR's immutable source and jobs."""
import argparse, ast, hashlib, json, re, subprocess, sys
from pathlib import Path
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010');R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D=O/'native-shared-execution-hosted-626'
old=O/'native-text-reconstruction-hosted-596'
read=lambda p:json.loads(Path(p).read_text())
identity=lambda p:dict(path=str(p),bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
save=lambda p,x:Path(p).open('x').write(json.dumps(x,indent=2)+'\n')
p=argparse.ArgumentParser()
for name in ('head','base','synthetic','jobs_file'):p.add_argument('--'+name.replace('_','-'),required=True)
p.add_argument('--pr',type=int,required=True);p.add_argument('--run',type=int,required=True)
args=p.parse_args()
assert all(re.fullmatch('[a-f0-9]{40}',getattr(args,k)) for k in ('head','base','synthetic'))
assert args.pr>1567 and args.run>0 and not D.exists()
sys.path.insert(0,str(O));import verify_stream_destination_integrated_sources_482 as v
v.R=R
selected=O/'native-shared-execution-final-selected-source-625.json'
accepted=read(selected);expected=accepted['source_sha256']
assert len(expected)==2412 and read(accepted['comment_only_bridge']['path'])['status']=='passed'
assert identity(Path(accepted['comment_only_bridge']['path']))==accepted['comment_only_bridge']
assert identity(Path(accepted['measured_source']['path']))==accepted['measured_source']
maps={};trees={}
for kind,revision in [('head',args.head),('ci_merge',args.synthetic)]:
 mapping,_=v.immutable_source_map(revision)
 assert {p:x['sha256'] for p,x in mapping.items()}==expected
 maps[kind]=v.identity_summary(mapping)
 trees[kind]=v.git('rev-parse',revision+'^{tree}').decode().strip()
assert len(set(trees.values()))==1
parents=v.git('rev-list','--parents','-n','1',args.synthetic).decode().split()
assert parents==[args.synthetic,args.base,args.head]
coverage=dict(status='passed',head=args.head,base=args.base,ci_merge=args.synthetic,trees=trees,
 source_files=len(expected),source_sha256=expected,source_maps=maps,
 accepted_source=identity(selected),measured_source=accepted['measured_source'],
 comment_only_bridge=accepted['comment_only_bridge'],
 artifacts=identity(O/'native-release-artifacts-sharedexecution624.json'),helper=identity(Path(v.__file__)),
 scope='Immutable reviewed head and CI merge match the final source inventory; the exact two-line comment bridge binds it to measured build 618.')
inventory=read(O/'native-shared-execution-test-inventory-625.json')
inventory['head']=args.head
prior=read(old/'hosted-validation-launch.json')
inventory['documentation_existing_tests']=prior['test_inventory']['documentation_existing_tests']
assert set(inventory['documentation_existing_tests'])<=set(inventory['release_script_methods'])
for test in inventory['native_new_tests']:
 raw=v.git('show',args.head+':'+test['path'])
 assert hashlib.sha256(raw).hexdigest()==test['source_sha256']
 assert 'fn '+test['name']+'(' in raw.decode().splitlines()[test['line']-1]
wanted={'Python test shard (core)','Python test shard (release_scripts)',
 'Rust feature matrix (native_public_surface_tests)','Rust feature matrix (native_vortex_tests)',
 'Native Python wheel (py313_macos)','Native Python wheel (py313_ubuntu)',
 'Native Python wheel (py310_ubuntu)','Website and docs validation'}
jobdoc=read(args.jobs_file)
jobs={j['id']:j['name'] for j in jobdoc['jobs'] if j['name'] in wanted}
assert len(jobs)==8 and set(jobs.values())==wanted
assert all(j['run_id']==args.run and j['head_sha']==args.head for j in jobdoc['jobs'] if j['id'] in jobs)
replacements={
 'native-text-reconstruction-hosted-596':'native-shared-execution-hosted-626',
 '2adcfc95876a432007f4051ef3a316fe9cd1d9ee':args.head,
 '4ea5851eb664ec68c16184766d63b32c6a2059e4':args.base,
 '1cad6f2d1cd74077c1ff70663ade4828f99ed76b':args.synthetic,
 '39047950917':str(args.run),'1567':str(args.pr),'2411':'2412','2946':'2958',
 'native_text_reconstruction':'native_shared_execution'}
programs={}
for key in ('capture_source','acceptance_source','closeout_wrapper','served_source'):
 source=prior[key]
 assert hashlib.sha256(source.encode()).hexdigest()==prior[key+'_sha256']
 for before,after in replacements.items():source=source.replace(before,after)
 if key=='capture_source':
  source,n=re.subn(r'^jobs=.*$',lambda _: 'jobs='+repr(jobs),source,flags=re.M);assert n==1
 ast.parse(source);programs[key]=source
D.mkdir()
save(D/'pr-sources.json',coverage);save(D/'test-inventory.json',inventory)
record=dict(programs,source_verification=coverage,test_inventory=inventory,
 template=identity(old/'hosted-validation-launch.json'),job_inventory=identity(Path(args.jobs_file)),
 substitutions=replacements,program_file_created=False)
for key,value in programs.items():record[key+'_sha256']=hashlib.sha256(value.encode()).hexdigest()
save(D/'hosted-validation-launch.json',record)
print(json.dumps(dict(status='prepared',directory=str(D),pr=args.pr,head=args.head,source_files=len(expected),jobs=len(jobs))))

