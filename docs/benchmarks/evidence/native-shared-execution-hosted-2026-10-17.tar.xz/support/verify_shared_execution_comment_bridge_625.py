from pathlib import Path
import hashlib, json, lzma, sys, tarfile
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path.insert(0,str(O))
from freeze_native_release_298 import sources, save
identity=lambda p: dict(path=str(p),bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
frozen_path=O/'native-release-source-sharedexecution624.json'
frozen=json.loads(frozen_path.read_text())
manifest_path=R/'docs/benchmarks/evidence/native-shared-execution-2026-10-17.manifest.json.xz'
manifest=json.loads(lzma.decompress(manifest_path.read_bytes()))
name='shardloom-vortex/src/local_primitives.rs'
member=next(x for x in manifest['members'] if x['archive_path']=='runtime-source/'+name)
with tarfile.open(manifest_path.parent/member['archive_file'],'r:xz') as archive:
    before=archive.extractfile(member['archive_path']).read()
assert hashlib.sha256(before).hexdigest()==frozen['source_sha256'][name]==member['sha256']
old=b'            // The dictionary family explicitly grants one provider lane in a\n            // total budget of three (caller + dictionary + native progress).'
new=b'            // The dictionary family partitions its admitted grant between the caller,\n            // one or two preparation workers, and one native provider-progress lane.'
assert before.count(old)==1
after=(R/name).read_bytes()
assert before.replace(old,new)==after and before.count(b'\n')==after.count(b'\n')
final=sources()
assert set(final)==set(frozen['source_sha256']) and len(final)==2412
assert [p for p in final if final[p]!=frozen['source_sha256'][p]]==[name]
bridge_path=O/'native-shared-execution-final-comment-bridge-625.json'
bridge=dict(status='passed',measured_source=identity(frozen_path),portable_manifest=identity(manifest_path),
    original_member=dict(archive_file=member['archive_file'],archive_path=member['archive_path']),
    selected_source_count=len(final),unchanged_selected_sources=len(final)-1,
    change=dict(path=name,before_sha256=frozen['source_sha256'][name],after_sha256=final[name],
                original=old.decode(),replacement=new.decode()),
    proof='Exact byte replacement of two adjacent line comments; every other byte and line count is unchanged.',
    runtime_tokens_unchanged=True,source_line_numbers_unchanged=True,behavior_changed=False,
    implementation='Retained measured build 618; provider-ownership comment corrected after local acceptance.')
save(bridge_path,bridge)
save(R/'docs/benchmarks/evidence/native-shared-execution-comment-bridge-2026-10-17.json',bridge)
record=dict(frozen,source_sha256=final,measured_source=identity(frozen_path),
            comment_only_bridge=identity(bridge_path),all_other_selected_sources_unchanged=True)
save(O/'native-shared-execution-final-selected-source-625.json',record)
print(json.dumps(dict(status='passed',selected_sources=len(final),comment_only_files=1,
                      unchanged_selected_sources=len(final)-1)))

