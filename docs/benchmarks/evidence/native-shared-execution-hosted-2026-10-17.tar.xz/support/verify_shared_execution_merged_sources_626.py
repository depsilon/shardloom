"""Bind the actual merge to reviewed, hosted and measured shared-execution source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, sys

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D=O/'native-shared-execution-hosted-626'
sys.path.insert(0,str(O))
import verify_stream_destination_integrated_sources_482 as v
v.R=R
read=lambda p:json.loads(Path(p).read_text())
identity=lambda p:dict(path=str(p),bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
coverage=read(D/'pr-sources.json');merge=sys.argv[1]
assert re.fullmatch('[a-f0-9]{40}',merge)
head=coverage['head'];base=coverage['base'];synthetic=coverage['ci_merge']
trees={k:v.git('rev-parse',rev+'^{tree}').decode().strip() for k,rev in dict(head=head,synthetic=synthetic,merge=merge).items()}
assert len(set(trees.values()))==1
parents=v.git('rev-list','--parents','-n','1',merge).decode().split()
assert parents==[merge,base,head]
mapping,_=v.immutable_source_map(merge)
assert len(mapping)==2412 and {p:x['sha256'] for p,x in mapping.items()}==coverage['source_sha256']
assert identity(Path(coverage['accepted_source']['path']))==coverage['accepted_source']
accepted=read(coverage['accepted_source']['path'])
assert accepted['source_sha256']==coverage['source_sha256']
for field in ('measured_source','comment_only_bridge'):
 assert identity(Path(coverage[field]['path']))==coverage[field]
bridge=read(coverage['comment_only_bridge']['path'])
assert bridge['status']=='passed' and bridge['runtime_tokens_unchanged'] and not bridge['behavior_changed']
record=dict(status='passed',recorded_at=datetime.now(timezone.utc).isoformat(),head=head,base=base,merge=merge,ci_merge=synthetic,trees=trees,parents=parents[1:],source_files=mapping,selected_source_count=2412,all_selected_sources_match=True,accepted_source=coverage['accepted_source'],measured_source=coverage['measured_source'],comment_only_bridge=coverage['comment_only_bridge'],pr_source_verification=identity(D/'pr-sources.json'),helper=identity(Path(v.__file__)),executed_program=identity(Path(__file__)),scope='All 2,412 merged sources match the reviewed head and CI synthetic merge. The measured build is linked by the independently verified exact two-line comment replacement; all remaining bytes are unchanged.')
target=D/'merged-sources-626.json'
target.open('x').write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status='passed',merge=merge,source_files=len(mapping),tree=next(iter(trees.values())))))
