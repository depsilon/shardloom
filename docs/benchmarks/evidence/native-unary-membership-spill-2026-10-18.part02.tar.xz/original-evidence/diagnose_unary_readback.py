"""Separate constrained unary fanout from subsequent persisted-file Arrow admission."""
import gc
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
CASE = OUT / 'unary-binding-readback-diagnostic-731'
CASE.mkdir(exist_ok=False)
OUTPUTS = CASE / 'outputs'
OUTPUTS.mkdir()
sys.path[:0] = [str(ROOT / 'python/tests')]
from test_native_binding import _load_native
from test_native_unary_binding import SCHEMA
_load_native()
import shardloom as sl
import pyarrow as pa

keys = list(range(257)) + list(reversed(range(0, 257, 2))) + list(range(257, 321))
rows = [dict(n=ordinal, s=f'{key:08d}' + 'u' * 8184, items=[ordinal, None])
        for ordinal, key in enumerate(keys)]
wanted_rows = [dict(s=f'{key:08d}' + 'u' * 8184) for key in range(321)]
wanted = pa.Table.from_pylist(wanted_rows, schema=pa.schema([pa.field('s', pa.string())]))
events, observations = [], []

def produce():
    events.append('opened')
    try:
        for start in range(0, len(rows), 41):
            yield rows[start:start + 41]
        events.append('ended')
    finally:
        events.append('closed')


def read_output(client, extension, label, grant):
    row = dict(label=label, extension=extension, grant_bytes=grant, stage='prepare')
    result = None
    try:
        frame = getattr(sl, 'read_' + extension)(OUTPUTS / ('result.' + extension), client=client)
        row['stage'] = 'collect'
        result = frame.collect(check=True)
        row['collection_envelope'] = result.envelope.raw
        row['stage'] = 'arrow_export'
        table = result.to_arrow()
        assert table.schema.equals(wanted.schema, check_metadata=True)
        assert table.equals(wanted, check_metadata=True)
        row.update(status='passed', complete_rows=table.num_rows)
        return table
    except Exception as error:
        row.update(status='denied', error=type(error).__name__ + ': ' + str(error))
        return None
    finally:
        observations.append(row)


with patch('subprocess.Popen', side_effect=AssertionError('child process')), \
     patch('shardloom._batches.BatchInput.encode', side_effect=AssertionError('JSON input')):
    client = sl.ShardLoomClient(transport='native', memory_bytes=32 << 20, max_parallelism=1)
    workspace = OUTPUTS / 'spill'
    workspace.mkdir()
    source = sl.from_batches(produce, schema=SCHEMA, streaming=True, client=client)
    targets = {kind: OUTPUTS / ('result.' + kind) for kind in ('vortex', 'parquet', 'jsonl')}
    report = source.select('s').distinct().fanout(targets, spill={
        'workspace': str(workspace), 'quota_bytes': 128 << 20, 'buffer_bytes': 1 << 20})
    assert events == ['opened', 'ended', 'closed']
    envelope = report.envelope
    assert envelope.status == 'success' and not envelope.fallback.attempted
    assert envelope.field_int('native_vortex_result_export_execution_count') == 1
    assert envelope.field_int('native_vortex_result_export_replay_count') == 3
    assert envelope.field_int('relational_spillable_unary_input_rows') == len(rows)
    assert envelope.field_int('relational_spillable_unary_groups') == 321
    assert envelope.field_int('relational_spillable_unary_output_rows') == 321
    assert envelope.field_int('relational_spill_runs_written') > 0
    assert envelope.field_int('resident_peak_reserved_buffer_bytes') <= 32 << 20
    assert envelope.field_bool('relational_spill_owned_cleanup_completed')
    assert list(workspace.iterdir()) == []
    assert [json.loads(line) for line in targets['jsonl'].read_text().splitlines()] == wanted_rows
    retained = []
    for extension in ('vortex', 'parquet'):
        retained.append(read_output(client, extension, 'original_client', 32 << 20))
    client.close()
    for table in retained:
        if table is not None:
            assert table.equals(wanted, check_metadata=True)
    del retained
    for grant in (32 << 20, 128 << 20):
        for extension in ('vortex', 'parquet'):
            gc.collect()
            reader = sl.ShardLoomClient(transport='native', memory_bytes=grant, max_parallelism=1)
            table = read_output(reader, extension, 'independent_reader', grant)
            reader.close()
            if table is not None:
                assert table.equals(wanted, check_metadata=True)
            del table

record = dict(status='observed', input_rows=len(rows), producer_events=events,
              constrained_writer_grant_bytes=32 << 20, writer=envelope.raw,
              observations=observations, outputs=[])
for path in targets.values():
    record['outputs'].append(dict(path=str(path), bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
with (CASE / 'observations.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
assert len(observations) == 6
assert all(item['status'] == 'passed' for item in observations if item['grant_bytes'] == 128 << 20)
print(json.dumps([{key: value for key, value in item.items() if key != 'collection_envelope'}
                  for item in observations], indent=2))
