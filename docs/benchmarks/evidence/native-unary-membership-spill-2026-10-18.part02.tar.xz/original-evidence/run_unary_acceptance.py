"""Run the frozen native unary acceptance stages serially; preserve every failure."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'
GUARD = OUT / 'run_guarded.py'

def checked_source():
    source = json.loads((OUT / 'acceptance-source.json').read_text())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert source['source_commit'] == head
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
    for name, digest in source['source_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    return source

def run(name, command, timeout=1800):
    source = checked_source()
    path = OUT / (name + '.json')
    if path.exists():
        prior = json.loads(path.read_text())
        assert prior['status'] == 'passed', f'Failed evidence retained; select a new attempt: {path}'
        assert prior['command'] == command and prior['head'] == source['source_commit']
        assert prior['working_tree'] == '' and prior['process_group_drained']
        assert prior['log_sha256'] == hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest()
        print(json.dumps({'stage': name, 'status': 'verified_previous_pass'}), flush=True)
        return
    print(json.dumps({'stage': name, 'status': 'starting'}), flush=True)
    subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command],
                   cwd=ROOT, check=True)
    checked_source()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('gates', 'build', 'bindings', 'matrix', 'final'))
args = parser.parse_args()
source = checked_source()
cargo = ['cargo']
if args.phase == 'gates':
    for name, command in [
        ('unary-workspace-fmt-731', cargo + ['fmt', '--all', '--', '--check']),
        ('unary-public-reference-731', [PYTHON, '-B', 'scripts/check_user_surface_reference.py']),
        ('unary-public-reference-tests-731', [PYTHON, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v']),
        ('unary-native-vortex-tests-731', cargo + ['test', '--release', '--offline', '--locked', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', '--', '--test-threads=1']),
        ('unary-workspace-clippy-731', cargo + ['clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('unary-workspace-tests-731', cargo + ['test', '--offline', '--locked', '--workspace', '--all-targets', '--', '--test-threads=1']),
        ('unary-native-clippy-731', cargo + ['clippy', '--release', '--offline', '--locked', '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('unary-native-cli-tests-731', cargo + ['test', '--offline', '--locked', '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare', '--test', 'public_memory_inputs', '--test', 'public_workflow_route', '--test', 'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1']),
    ]:
        run(name, command)
elif args.phase == 'build':
    run('unary-cli-build-731', cargo + ['build', '--offline', '--locked', '--release', '-p', 'shardloom-cli', '--features', 'release-user-surfaces'])
    run('unary-binding-build-731', [PYTHON, '-B', 'scripts/build_native_python.py', '--output-dir', str(OUT / 'artifacts'), '--release', '--offline'])
    run('unary-freeze-artifacts-731', [PYTHON, '-B', str(OUT / 'freeze_unary_acceptance.py'), 'artifacts', '--cli-build', 'unary-cli-build-731', '--binding-build', 'unary-binding-build-731'], 300)
    run('unary-freeze-plan-731', [PYTHON, '-B', str(OUT / 'freeze_unary_acceptance.py'), 'plan'], 300)
elif args.phase == 'bindings':
    env = ['/usr/bin/env', 'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(OUT / 'artifacts/_native.abi3.so'), 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON]
    run('unary-direct-binding-tests-731', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_native*binding.py', '-v'])
    run('unary-public-context-tests-731', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_context.py', '-v'], 300)
elif args.phase == 'matrix':
    plan = json.loads((OUT / 'acceptance-plan.json').read_text())
    run('unary-input-verify-731', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), 'input'], 600)
    for family, timeout in [('public', 3600), ('full43', 1800), ('modular', 3600)]:
        name = 'unary-' + family + '-731'
        run(name, plan['commands'][family], timeout)
        run('unary-' + family + '-verify-731', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), family, '--receipt', name], 900)
else:
    run('unary-final-verify-731', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), 'final'], 900)
    run('unary-owner-acceptance-731', [PYTHON, '-B', str(OUT / 'finalize_unary_acceptance.py')], 300)
print(json.dumps({'phase': args.phase, 'status': 'passed'}), flush=True)
