# Public unary pressure edit handoff

Updated only `scripts/native_streaming_unary_pressure_cases.py`.

- The module metadata now distinguishes `unary_membership_spill: true`, `sampling_population_spill: false`, and `source_replay_is_separate: true`.
- The seven membership kinds retain no-spill refusal coverage and gain `unary-membership-spill-{kind}` positive cases. Each positive streams the complete unique-key row oracle or all-false duplicate mask and asserts unary stage/input/observed/groups/identity/output counters, real run writes, quota/cleanup, and no source replay spill.
- Sampling fraction/replacement refusal cases remain for both spill settings, retaining explicit resident-only sampling metadata.
- Future-mask selectors now include explicit `spill-{stored}` identity. Only non-first, 8-MiB, no-spill controls expect the existing `requested=8388608` denial. Positive spill cases check stage/input/observed/groups; future last/all masks additionally require full identity rows and actual run writes. First-mask spill-enabled cases may complete without a run.
- Existing bounded-state and replay cases remain, with `unary_state_spill: false` preserved only on those resident/bounded observations.

Validation: Python source parsed with `ast.parse` without writing bytecode. No tests, builds, or native runs were performed. All requested metric keys exist in the dirty CLI mapping (`relational_spillable_unary_*`). No unresolved mapping ambiguity found; primary must validate against its implementation and run evidence.
