"""Capture the complete diagnostic for the new wide-key writer fixture."""
import json
from pathlib import Path
from types import SimpleNamespace
import shardloom as sl
from shardloom.errors import ShardLoomCommandError
from native_streaming_unary_pressure_cases import source

OUT = Path(__file__).resolve().parent / 'unary-public-writer-diagnostic-731'
OUT.mkdir(exist_ok=False)
outputs = OUT / 'outputs'
outputs.mkdir()
client = sl.ShardLoomClient(binary=Path(__file__).resolve().parent / 'artifacts/shardloom', timeout=600)
harness = SimpleNamespace(context=sl.ShardLoomContext(client))
records = []
for grant in (16 << 20, 32 << 20):
    workspace = outputs / f'spill-{grant}'
    workspace.mkdir()
    batch, trace = source(harness, unique=True, count=257, width=8192)
    target = outputs / f'result-{grant}.parquet'
    try:
        report = batch.distinct().write_parquet(target, memory_bytes=grant, max_parallelism=1,
            spill={'workspace':str(workspace), 'quota_bytes':128 << 20, 'buffer_bytes':1 << 20})
        record = dict(status='passed', grant=grant, envelope=report.envelope.raw)
    except ShardLoomCommandError as error:
        record = dict(status='denied', grant=grant, envelope=error.envelope.raw)
    record.update(trace=trace, target_exists=target.exists(), spill_entries=[p.name for p in workspace.iterdir()])
    assert not record['spill_entries']
    records.append(record)
    (OUT / f'{grant}.json').write_text(json.dumps(record,indent=2)+'\n')
client.close()
print(json.dumps([{key:value for key,value in record.items() if key!='envelope'} for record in records]))
