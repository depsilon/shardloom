# Unary membership public runner registration handoff

Updated only `scripts/run_native_streaming_input_uat.py`: imported `unary_membership_cases`, registered family name `unary-membership` beside `unary-pressure`, and added `native_streaming_unary_membership_cases.py` to the source-hash/snapshot manifest at lines 244-245. No defaults or other family registrations changed.

Validation: AST parsing passed for the runner and new module; `git diff --check -- scripts/run_native_streaming_input_uat.py` passed. No native command, test, or build was run.

## Existing claims/validators to revisit after acceptance

- Current broad support field: `docs/reference/shardloom-user-surface-index.json:220` says `"unary_state_spill": false`; `scripts/check_user_surface_reference.py:309` enforces it. The new route supports relational membership spill while sampling population stays resident, so this single field/validator no longer describes the split accurately.
- The historical accepted scope remains recorded at `docs/benchmarks/native-stream-unary-2026-10-15.md:12-17,132-137` and `docs/architecture/native-stream-unary-2026-10-15.md:57,82-85,129-130`. These are time-bound records of the October 15 unit, including its claim that replay spill did not spill unary membership/population; do not retroactively edit their historical results. A current status/reference should supersede them.
- Older broad wording also appears in `docs/architecture/native-unary-composition-2026-10-02.md:36-38` (unsupported unary state spill) and `docs/architecture/native-unary-workflows-2026-10-01.md:63-64,116-117` (unary state spill separate work). These need narrower current scope language for relational membership, while sampling and other resident state remain separate.
- `docs/reference/shardloom-user-surface-index.json:653` and `scripts/check_user_surface_reference.py:590-593` assert `direct_prepared_unary_spill: false` as part of the pivot spill contract. This is explicitly the separate legacy direct-prepared API boundary and is not contradicted by the new relational membership route; preserve unless that scope changes.
- `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md:99` says unary membership/population keep independent PERF-06 boundaries. Independence remains valid, but current membership status/evidence should be updated once accepted; the line does not itself say membership is unsupported.
- The in-progress contract `docs/architecture/native-unary-membership-spill-2026-10-18.md:3` still says implementation is in progress and makes no support-expansion claim. It needs a status update only after primary verification and acceptance are complete.

No documentation/index/validator claim was changed in this registration packet.
