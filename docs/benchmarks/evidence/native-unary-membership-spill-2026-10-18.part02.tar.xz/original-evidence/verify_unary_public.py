"""Independently reopen complete unary values from the public acceptance run."""
import gzip
import hashlib
import json

KINDS = ('distinct', 'dedup-first', 'dedup-last', 'dedup-false',
         'mask-first', 'mask-last', 'mask-false')
FORMATS = ('vortex', 'parquet', 'arrow_ipc', 'avro', 'orc', 'json', 'jsonl', 'csv')


def small_reference(kind, rows):
    keys = [tuple(row.items()) if kind == 'distinct' else row['n'] for row in rows]
    positions = {}
    for index, key in enumerate(keys):
        positions.setdefault(key, []).append(index)
    result = []
    for index, (key, row) in enumerate(zip(keys, rows, strict=True)):
        occurrences = positions[key]
        keep = 'first' if kind == 'distinct' else kind.split('-', 1)[1]
        duplicate = (index != occurrences[0] if keep == 'first' else
                     index != occurrences[-1] if keep == 'last' else len(occurrences) != 1)
        if kind.startswith('mask-'):
            result.append({'duplicated': duplicate})
        elif not duplicate:
            result.append(row)
    return result


def verify(root, summary, identity, strict_json, report_fields):
    cases = {case['name']: case for case in summary['cases']}
    assert len(cases) == len(summary['cases'])
    values, envelopes = [], []

    def json_value(name):
        path = root / 'logs' / (name + '.json.gz')
        value = strict_json(gzip.decompress(path.read_bytes()).decode())
        return path, value

    def complete_values(name, expected):
        path, record = json_value(name + '-values')
        assert record['actual'] == record['expected'] == expected, name
        values.append({'name': name, 'rows': len(expected), 'values': identity(path)})

    def completion(name, *, count=None, actual_runs=False, identities=None):
        path, envelope = json_value(name + '-envelope')
        assert envelope['status'] == 'success' and not envelope['fallback']['attempted']
        fields = report_fields(envelope)
        assert fields['relational_spillable_unary_membership_stages'] == '1', name
        assert fields['relational_spill_owned_cleanup_completed'] == 'true', name
        assert fields['native_input_end_observed'] == 'true', name
        assert fields['resident_completed_executions'] == '1', name
        assert fields['native_input_replay_sources'] == '0', name
        if count is not None:
            for suffix in ('input_rows', 'observed_rows', 'output_rows'):
                assert int(fields['relational_spillable_unary_' + suffix]) == count, (name, suffix)
        if identities is not None:
            assert int(fields['relational_spillable_unary_identity_rows']) == identities, name
        if actual_runs:
            assert int(fields['relational_spill_runs_written']) > 0, name
        envelopes.append(identity(path))
        return fields

    def lines(name, count, expected):
        path = root / 'logs' / (name + '-values.jsonl.gz')
        digest = hashlib.sha256()
        observed = 0
        with gzip.open(path, 'rb') as stream:
            for index, line in enumerate(stream):
                assert index < count and strict_json(line.decode()) == expected(index), (name, index)
                digest.update(line)
                observed += 1
        assert observed == count, name
        case = cases[name]
        assert case['complete_rows'] == count and case['expected_sha256'] == digest.hexdigest()
        assert case['values']['path'] == str(path.relative_to(root))
        assert case['values']['bytes'] == path.stat().st_size
        assert case['values']['sha256'] == identity(path)['sha256']
        values.append({'name': name, 'rows': count, 'values': identity(path),
                       'raw_sha256': digest.hexdigest()})

    _, predeclared = json_value('unary-membership-predeclared')
    assert predeclared['kinds'] == list(KINDS)
    mixed = [dict(n=n, s=s) for n, s in ((3, 'α'), (None, None), (3, 'α'), (1, 'β'),
                                       (2, 'γ'), (None, 'δ'), (1, 'ε'), (4, ''))]
    declared = {row['case']: row for row in predeclared['small_cases']}
    assert len(declared) == 21
    for kind in KINDS:
        for shape, rows in [('mixed', mixed), ('empty', []),
                            ('all-null', [dict(n=None, s=None) for _ in range(3)])]:
            name = f'unary-membership-{kind}-{shape}'
            expected = small_reference(kind, rows)
            assert declared[name]['rows'] == rows and declared[name]['expected'] == expected
            for surface in ('dataframe', 'sql'):
                for terminal in ('collect', 'batches'):
                    case_name = name + '-' + surface + '-' + terminal
                    complete_values(case_name, expected)
                    completion(case_name)

    for kind in KINDS:
        mask = kind.startswith('mask-')
        expected = [{'duplicated': False} if mask else
                    {'n': index, 's': f'{index:08d}' + 'u' * 8184} for index in range(257)]
        for destination in (*FORMATS, 'fanout'):
            name = f'unary-membership-{kind}-write-{destination}'
            fields = completion(name, count=257, actual_runs=True,
                                identities=257 if kind in ('mask-last', 'mask-false') else 0)
            assert int(fields['relational_spillable_unary_groups']) == 257
            formats = FORMATS if destination == 'fanout' else (destination,)
            if destination == 'fanout':
                for suffix, value in [('execution_count', 1), ('target_count', 8), ('replay_count', 8)]:
                    assert int(fields['native_vortex_result_export_' + suffix]) == value
            artifacts = cases[name]['artifacts']
            assert len(artifacts) == len(formats)
            for artifact in artifacts:
                actual = identity(root / artifact['path'])
                assert (actual['bytes'], actual['sha256']) == (artifact['bytes'], artifact['sha256'])
            for extension in formats:
                wanted = ([{'duplicated': 'false'} if mask else
                           {'n': str(row['n']), 's': row['s']} for row in expected]
                          if extension == 'csv' else expected)
                complete_values(name + '-' + extension, wanted)

        name = 'unary-membership-spill-' + kind
        lines(name, 8193, lambda index: {'duplicated': False} if mask else
              {'n': index, 's': f'{index:08d}' + 'u' * 2040})
        fields = completion(name, count=8193, actual_runs=True,
                            identities=8193 if kind in ('mask-last', 'mask-false') else 0)
        assert int(fields['relational_spillable_unary_groups']) == 8193

    for keep in ('first', 'last', 'False'):
        for grant in ((8 << 20,) if keep == 'first' else (8 << 20, 32 << 20)):
            for stored in (False, True):
                name = f'unary-future-mask-{keep}-grant-{grant}-spill-{stored}'
                if keep != 'first' and grant == 8 << 20 and not stored:
                    assert cases[name]['denied_population_identity_bytes'] == 8 << 20
                    continue
                lines(name, 262145, lambda index: {'duplicated':
                      index >= 3 if keep == 'first' else index < 262142 if keep == 'last' else True})
                if stored:
                    fields = completion(name, count=262145, actual_runs=keep != 'first',
                                        identities=0 if keep == 'first' else 262145)
                    assert int(fields['relational_spillable_unary_groups']) == 3

    fault_cases = []
    for kind in KINDS:
        for failure in ('producer', 'corrupt', 'quota'):
            for terminal in ('batches', 'vortex', 'fanout'):
                name = f'unary-membership-{kind}-{failure}-{terminal}'
                case = cases[name]
                assert case['failure'] == failure and case['terminal'] == terminal
                assert case['unary_kind'] == kind and case['recovery_rows'] == 1
                trace = case['failed_trace']
                assert trace['opened'] <= 1 and (not trace['opened'] or trace['closed'])
                if failure != 'quota':
                    assert trace['fault'] and trace['opened'] == 1 and not trace['ended']
                for extension in ('vortex', 'jsonl'):
                    assert not (root / 'outputs' / (name + '.' + extension)).exists()
                complete_values(name + '-recovery', [{'n': 0, 's': '00000000' + 'u' * 2040}])
                fault_cases.append(name)

    assert len(values) == 274  # 84 small + 112 destinations + 7 pressure + 8 future + 63 recoveries.
    assert len(fault_cases) == 63
    return {'unary_complete_value_archives': values, 'unary_completion_envelopes': envelopes,
            'unary_publication_failure_cases': fault_cases,
            'unary_membership_public_cases': 210, 'unary_pressure_public_cases': 51,
            'complete_rows_independently_reopened': sum(item['rows'] for item in values)}
