# Unary membership spill documentation inventory

Read-only evidence inventory from the current worktree. No repository source or documentation was changed. The worktree had concurrent implementation edits; this packet distinguishes checked-in maintained statements from the new explicitly in-progress work note. Acceptance is not complete.

## Current maintained public reference and machine-readable claims

- `docs/reference/native-query-spill.md:157–164` currently says:

  > With an explicit spill policy, bounded native full-row membership spill is available for `UNION` (distinct), `INTERSECT` and `EXCEPT`, preserving their existing first-occurrence order. `UNION ALL` retains its streaming path. Unary membership/population and subquery membership/index state remain resident under their separate contracts.

  It points to the set spill and finite unary contracts. The wording is scoped separately to unary and subquery state, but does not distinguish relational unary membership from legacy direct unary execution.

- `docs/reference/resident-native-results.md:88–95` repeats the public boundary:

  > With an explicit spill policy, bounded native full-row membership spill is available for `UNION` (distinct), `INTERSECT` and `EXCEPT`, preserving their existing first-occurrence order; `UNION ALL` retains its streaming path. Unary membership/population and subquery membership/index state remain resident under their separate contracts.

- The public machine index `docs/reference/shardloom-user-surface-index.json:204–220` keeps unary kinds `distinct`, `dedup`, `duplicate_mask`, `tail`, `sample`, `expression`, `melt`, `explode`, `rolling`, then `"unary_state_spill": false`. The adjacent set fields at `:196–203` say `"set_membership_spill": true` and `"set_membership_spill_acceptance_status": "locally_accepted_hosted_pending"`.
- The same index at `docs/reference/shardloom-user-surface-index.json:221–238` lists subquery kinds `in`, `exists`, `quantified`, `scalar` and `"subquery_state_spill": false`.
- `scripts/check_user_surface_reference.py:306–316` enforces those values in its expected surface tuple, including `("unary_state_spill", False)` and `("subquery_state_spill", False)`, beside the already-true set spill fields. This is an active public-index validator expectation, not just historical prose.
- The streaming API docstring at `python/src/shardloom/query.py:9009–9015` states:

  > Stateful work shares the query grant; ordering, aggregation, joins, windows and pivot can use explicit spill. Set membership and unary state remain resident under credits. Source or result replay spill does not add spill support to that state. Fractional or replacement sampling may retain the input population; future-dependent duplicate masks retain row identities. Oversized state fails explicitly.

  This groups all unary state at a broad level while naming fractional/replacement sampling and future-mask identities as examples.

## Existing unary contract and historical acceptance

- `docs/architecture/native-stream-unary-2026-10-15.md:64–85` describes the previous finite unary breadth contract. The exact membership boundary is:

  > Every operation shares the admitted source, state, output and replay grant. Unary membership/population state remains resident; no new spill algorithm is proposed. Long input can pass only when its retained state fits. Explicit spill permission must not turn an oversized unary state into hidden resident intake or external execution.

  The same section distinguishes bounded fixed-count sampling from fractional/replacement populations that may retain input state (`:72–76`) and warns that future-dependent duplicate masks may retain population identities (`:66–69`).
- Its header identifies this as the completed PR #1559 contract with its own local/hosted acceptance, six Rust gates and 2,601 public cases (`:3–14`). The acceptance report `docs/benchmarks/native-stream-unary-2026-10-15.md:3–17` explicitly limits that historical finite unit: “The implementation contract … keeps unary state spill, other unadmitted families and native transport outside this finite unit.”
- That report’s prior pressure result at `docs/benchmarks/native-stream-unary-2026-10-15.md:123–137` says high-cardinality membership and unknown sampling populations failed with and without replay-spill permission; it concludes “Source/result replay spill does not spill unary membership or population state.” It reports the older observed behavior, rather than the new in-progress relational spill code.
- The historical completed ledger at `docs/architecture/phased-execution-completed-ledger.md:364–368` records “Unary membership/population state remains resident under credits; replay spill does not spill that state,” then says deferred schemas and broader allocation/state/recovery retain owners. This entry accompanies the older unary completion record; do not read it as a fresh acceptance of the current implementation.

## In-progress scope note and route boundary

- The new worktree note `docs/architecture/native-unary-membership-spill-2026-10-18.md:1–8` explicitly says:

  > Status: implementation in progress; no acceptance or support expansion is claimed.

  It scopes seven variants: distinct, dedup first/last/all-duplicates, and duplicate-mask first/last/all-duplicates (`:12–19`). At `:40–43` it says Python DataFrame and SQL table expressions use the shared relational unary route, ordinary SQL `SELECT DISTINCT` remains aggregate lowering, and:

  > Legacy standalone `PreparedVortexUnary` retains its separate resident-only contract; this change does not silently grant it spill permission.

- The runtime source reflects this route distinction in the current dirty worktree: `shardloom-vortex/src/local_primitive_prepared_relational.rs:1244–1273` enters `consume_relation_membership` only when spill metrics exist and `operation.membership_spill_supported()`, otherwise it calls `consume_relation`. The separate `PreparedVortexUnary::consume_relation` at `shardloom-vortex/src/local_primitive_prepared_unary.rs:492–526` constructs `select::State` with `spill=false` and runs the resident selector. This is why the broad historical “unary state” wording cannot itself determine the narrower route support claim.
- Legacy behavior is also stated in maintained docs: `docs/reference/native-query-spill.md:396–399` says “The direct prepared unary API remains resident” and points to separately tracked streaming composition. The new work note preserves that specific exclusion.

## Still-resident populations and subquery membership/index

- The unary contract describes unknown fractional and replacement sampling populations as grant-resident pressure cases (`docs/architecture/native-stream-unary-2026-10-15.md:72–76`). The current pressure runner still tests `sample-fraction` and `sample-replacement` with and without spill permission, expecting deterministic denial (`scripts/native_streaming_unary_pressure_cases.py:189–202`).
- Future-dependent mask identities remain a distinct state family from spilled membership. The current runner’s `future_masks` controls use 262,145 rows and assert identity/run/cleanup metrics when spill is enabled (`scripts/native_streaming_unary_pressure_cases.py:209–246`). The work note likewise keeps sampling populations open at `docs/architecture/native-unary-membership-spill-2026-10-18.md:3–7`.
- The subquery public index remains false for `subquery_state_spill` (`docs/reference/shardloom-user-surface-index.json:221–238`). The native spill reference says “explicit replay or pivot spill does not make membership/index state spillable” (`docs/reference/native-query-spill.md:401–408`).
- The subquery pressure runner explicitly expects a reservation denial after source replay spill, with no Vortex target publication (`scripts/native_streaming_subquery_pressure_cases.py:100–122`). The dynamic-subquery architecture also states that membership/index state is separately owned (`docs/architecture/native-stream-dynamic-subqueries-2026-10-15.md:49–55`), and static subquery contract identifies membership/index among retained state (`docs/architecture/native-stream-subqueries-2026-10-15.md:78–91`).

## Current source/test evidence that makes the broad claims stale or ambiguous

- Current prepared relational dispatch has a separate spill-capable membership branch (`shardloom-vortex/src/local_primitive_prepared_relational.rs:1244–1264`) and falls back to the old resident state path when that branch is not selected (`:1266–1273`). This is implementation-source evidence only; the new architecture note expressly withholds acceptance/support expansion.
- The unary pressure suite now separates resident denial without a spill policy from success with actual unary membership runs for all three membership operation kinds and the applicable keep modes (`scripts/native_streaming_unary_pressure_cases.py:145–187`). It still includes bounded and non-membership cases that report `"unary_state_spill": false`; those individual fields are not a current blanket support declaration (`:135–143`, `:249–283`).
- Native relational tests for membership are added in the dirty worktree under `shardloom-vortex/src/local_primitive_relational_unary_membership_tests.rs`; the Python membership public case module is `scripts/native_streaming_unary_membership_cases.py`. These are present implementation/test source, not completed acceptance records.
- The public prose, JSON index and validator still use blanket `unary_state_spill=false`, while current relational source and in-progress work tests have a membership-spill path. The in-progress note says acceptance/support expansion is not claimed. This is the principal unresolved documentation/status ambiguity for the primary owner; this inventory does not choose a replacement status or wording.

## Coverage and limits

Searched the current README, public reference docs and index, architecture/phase docs, Python source/tests, and scripts source while excluding generated benchmark evidence/log trees. No separate unary-spill claim was found in the root README. This packet quotes the maintained public reference/index and validator, historical unary contract/acceptance/ledger, route-specific legacy contract, current sampling/subquery pressure controls, and current in-progress route/test evidence. It makes no status change and does not assert acceptance completion.
