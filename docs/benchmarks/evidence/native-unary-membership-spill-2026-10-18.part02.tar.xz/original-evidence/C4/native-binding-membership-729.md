# Native binding unary membership spill handoff

Added one test method to `python/tests/test_native_unary_binding.py`: `test_native_unary_membership_spill_preserves_exact_rows_across_terminals`.

- It expresses 56 subcases: 7 membership variants × scalar/columnar input × collect/batches/Vortex/fanout.
- A fresh finite producer emits 450 rows in 11 batches of up to 41. Keys contain 321 unique 8,192-byte strings with repeated even-key occurrences; each row retains ordinal and nested list payload. Distinct projects `s`; dedup/mask key on `s`.
- Independent position-based expected values cover distinct first-seen output, all three keep policies, and all mask flags. Exact Arrow schemas and complete values are checked for collect, concatenated incremental batches, and reopened Vortex/Parquet/JSONL outputs.
- Every case requires one certified unary membership stage, exact input/observed/group/output counts, actual spill runs, quota/owned cleanup, a 32-MiB peak reservation bound, zero replay and existing no-fallback assertions. Fanout checks one execution and three target replays. A foreign workspace witness remains intact; the retained Arrow result is checked again after closing its client.

Validation: AST parsing, trailing-whitespace check, and `git diff --check` passed. The test was not run; no builds or native commands were started.
