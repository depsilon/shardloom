# Public unary membership matrix handoff

Created new script `scripts/native_streaming_unary_membership_cases.py`; no existing runner, test, or documentation files were edited.

- Section A declares and registers 84 cases: seven membership kinds × three fixture shapes × DataFrame/SQL × collect/batches. It reuses unary fixtures/oracles/field contracts and asserts one membership stage and owned spill cleanup; it does not require an actual spill run for these small inputs.
- Section B declares 63 separate cases: seven kinds × eight local formats plus fanout. Each case gets a fresh 257-row, 8,192-byte unique-key producer, uses `s` for dedup and mask key projection, and checks every full output by format reopen. It requires 257 input/observed/group/output rows, actual spill runs, quota and cleanup, no replay, and one execution with all destinations for fanout.
- Predeclared evidence records the exact small semantic rows/fields and full-stress oracle counts/digests before executions.

Validation: the new Python file passed `ast.parse` and a trailing-whitespace check. No tests, native runs, or builds were run. File-output names, eight-format tuple, existing `complete` / `verify_output` callback contracts, and unary key lowering were source-checked. Primary must register and validate the new family.
