# Unary acceptance helper draft

Created fresh-build adaptations of the replay-generation set helpers:

- `freeze_unary_acceptance.py` uses the seven unary membership scope strings, source schema `shardloom.unary_membership.source.v1`, base `ca53145f`, and unary architecture contract path. It adds `unary-membership` after `unary-pressure`, plans 37 public families / 5,126 cases under `public-37`, and binds the identity of the supplied `unary-public-case-declaration-730.json` into the plan while checking its family list and declared public case count.
- `run_unary_acceptance.py` uses `unary-*` stage names with attempt 730, the unary-membership modular prefix, fresh CLI and binding builds, the existing gate commands, and the repository run guard. The old `set-native-family-repair-725` prereq is removed; there is no source/artifact reuse bridge.

The declaration was found at `/Users/dylan/LocalData/shardloom/native-unary-membership-20261018/unary-public-case-declaration-730.json` (sibling of C4, not inside C4 as initially specified). The helper binds this actual file path. No verify/finalize helpers were created. Validation was limited to AST parsing and inspection of explicit replacement diffs; no helper, build, or test was run.

Unresolved template assumption: the plan continues to inherit the supplied prior Full43/modular templates, ClickBench input identity, reference packet, schema source, and resource limits. This assignment requested preserving those gates; no independent change to those inputs was inferred.

The direct-binding gate also retains the replay template's existing v0.6.0 Python virtual-environment path while setting `SHARDLOOM_NATIVE_TEST_LIBRARY` to the fresh `OUT/artifacts/_native.abi3.so`. This was preserved as instructed; the primary can decide whether that interpreter provenance needs separate evidence.

