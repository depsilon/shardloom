# Native unary membership provider inventory (727)

Read-only source inventory at clean `ca53145f`. This records the current pivot replacement-store contract and its concrete call graph for primary review. It makes no algorithm or semantics recommendation for unary membership.

## Existing provider and call graph

The actual provider is nested as `native_relational_spill::pivot`, with `#[path = "native_relational_pivot_store.rs"]` at `shardloom-vortex/src/local_primitives/native_relational_spill.rs:30-38`. That parent owns one execution-scoped `State`: policy, lazily created `QueryRunStore`, merge/open counters, and shared metadata lease (`:50-82`). `with_store` creates the store lazily under the existing shared `LiveMemoryPool`, with 128 KiB scratch, `QueryRunStorePolicy::relational_order`, and the execution cancellation token (`:84-104`). `finish` rejects outstanding readers, snapshots accounting, cleans owned runs, and reports disk/runs/merges/max block rows (`:136-161`). A pivot receives this same `State`; it does not make its own spill directory/quota/memory grant.

The only pivot-store construction/append caller found is `Builder` in `shardloom-vortex/src/local_primitive_unary_pivot_spill.rs`: `Builder::new` constructs `pivot::Store::new(&schema.spec, state, context)` (`:66-99`); `flush` sorts the BTreeMap buffer by `Key`, computes first/last and index bounds, builds arrays in blocks, calls `store.append(...)`, clears/releases buffered state, then compacts (`:101-144`). `cell` checks the current buffer before `store.find` (`:193-201`). Each input row advances its full-source ordinal before predicate filtering (`:203-238`); `update` looks up an index marker and previous cell, applies first/first_unique or aggregate semantics, then inserts/replaces the key (`:240-323`). The completion owner calls the producer once, flushes, then `store.complete` and builds completed schema/margins/report (`:326-477`). There is no separate `local_primitive_unary_pivot_spill_finish.rs`; finish/completion logic resides in that same spill module.

Admission is by `BoundUnary::complete_relation_pivot`: when a relational spill `State` is supplied it routes to `spill::complete` (`shardloom-vortex/src/local_primitive_unary_pivot.rs:448-470`). The dynamic relation caller supplies the shared execution metrics spill state and runs the preceding plan with `BATCH_ROWS` (`local_primitive_relational_dynamic_bind.rs:247-280`). The completed pivot retains the optional `pivot::Owned` run, schema, dimensions and margins. Output uses `Owned::open`, then removes the run only after access/cache owners drop (`local_primitive_unary_pivot_spill_output.rs:15-103`). This stored path is Unix + `vortex-write` feature-gated (`local_primitive_unary_pivot.rs:28-30, 391-395`).

## Store API, data shape and ownership

`native_relational_pivot_store.rs` states its scope literally: “Immutable, chronological replacement runs for sparse native pivot state” and “private operator state, not a general key/value store or checkpoint” (`:1-2`). The private three-field schema is `INDEX="index_key"`, `KIND="record_kind"`, `DOMAIN="domain_key"`; keys compare lexicographically by `(index, kind, domain)` (`:16-43`). Kinds are checked as 0/1 (index marker vs cell); `Spec.names` must equal those three private names (`:115-173, 363-380`).

The public-to-crate `pivot::Store<'p,'s>` methods are:

- `new(spec, state, context)`: checks the exact schema; reserves the run vector, two-entry cache metadata, and 128 KiB reader work lease (`native_relational_pivot_store.rs:354-380`).
- `buffer_bytes()`: returns the existing query spill policy's byte threshold (`:382-384`).
- `find(key, context)`: searches runs newest-first, validates reader generation, prunes via run bounds/index bounds/remembered absent-key range, then uses cached-block binary search (`:386-426`; `Cache::find` at `:229-342`).
- `append(rows, first, last, indices, blocks, context)`: requires nonempty rows and valid ordered bounds; leases bounds and run metadata; writes immutable Vortex arrays; tracks maximum block rows; pushes a run (`:428-459`).
- `compact(context)`: merges adjacent equal-level runs until the last levels differ (`:485-497`).
- `complete(context)`: compacts to one run, clears cache, closes its reader, and returns `(Option<Owned>, lookup_blocks, opens)` (`:580-595`).
- `Owned::open(state, spec, context)` opens a checked reader and fresh bounded cache; `Owned::finish` removes exactly that run through the owning store (`:597-637`). `Access` exposes `validate`, `rows`, `blocks`, positional `row`, binary-search `find`, and sequential `next_index` (`:639-693`).

Replacement contract visible in merge: the store retains a chronology level per run; `merge_last` combines adjacent runs and on equal keys chooses the right/newer complete row (`native_relational_pivot_store.rs:485-578`; `native_relational_pivot_merge.rs:66-88`). It first counts exact merged rows, validates both inputs, writes the merge output, validates again, closes input readers, removes both old owned runs, increments merge count and pushes the replacement. Runs remain immutable; per-run bounds and one credited gap cache prevent extra directory/payload retention (`native_relational_pivot_store.rs:291-339, 499-578`). The two-slot rotating cache keeps at most two `Arc<Held>` Vortex blocks (`:108-113, 206-278`); a held row owns the `QueryRunBlock` and memory metadata (`:108-118`).

The backing `QueryRunSpec` carries exact `dtype`, row count, `block_rows`, and metadata allowance; `NativeQueryRun` stores path, row/byte counts, block rows, identity/digest and metadata lease (`shardloom-vortex/src/local_primitive_query_run_store.rs:217-235`). `write_arrays` accepts only native `ArrayRef` blocks while work is owned by the same pool; a failed write makes the store terminal (`:377-399`). Open checks that ownership and at least 64 KiB reader work credit, verifies run identity, and passes cancellation/generation namespace through (`:546-593`). Removal validates bytes/identity and updates the marker (`:595-609`); cleanup validates owned identities and removes only the owned runs/marker/directory (`:663-694`).

## Block-row and buffer-size facts to preserve in source review

Pivot has its own `pub const BLOCK_ROWS: usize = 1024` (`native_relational_pivot_store.rs:13-19`), independent of parent relational sort's `BLOCK_ROWS=1024` (`native_relational_spill.rs:30`). All pivot-specific fixed uses found:

- `Builder::flush` chunks buffered records by `pivot::BLOCK_ROWS` (`local_primitive_unary_pivot_spill.rs:126-129`).
- `Store::append` sets `run_spec(..., BLOCK_ROWS)` and reports at least that block size (`native_relational_pivot_store.rs:428-458`).
- `Store::merge_last` sets output `run_spec(..., BLOCK_ROWS)` (`:534-543`).
- `merge::Merge::next` reserves and emits up to imported `BLOCK_ROWS` (`native_relational_pivot_merge.rs:90-137`). `merge::count` is a row-at-a-time pass and has no block argument (`:140-155`).
- Cache reads, binary-search alignment and row offsets already use each `NativeQueryRun.block_rows`, not a pivot constant (`native_relational_pivot_store.rs:229-277`; merge cursor alignment in `native_relational_pivot_merge.rs:17-38`). The common `run_spec` accepts `block_rows` and records it (`native_relational_spill.rs:443-459`).

Separate controls that are not run block rows: the builder's retained-entry threshold is weighted key/payload bytes compared against `Store::buffer_bytes()` from the explicit relational spill policy (`local_primitive_unary_pivot_spill.rs:40-63, 146-190`). Its per-record minimum/metadata estimates are 512 bytes plus key capacity; nested payload uses `array.nbytes`, scalar payload uses scalar size (`:40-63`). Builder scratch starts at 65,536 bytes and grows with key payload (`:80-98, 251-259`). The output writer's `batch_rows` argument controls `CompletedRows::streaming_native`, while its temporary output-index vector and per-iteration count use the pivot module's separate `BATCH_ROWS` (`local_primitive_unary_pivot_spill_output.rs:15-56`). It is not the fixed 1,024-row run block size.

For a mechanical parameterization review, the concrete references to inspect together are the `Builder::flush` chunk size, `Store::append` run spec and report, `Store::merge_last` run spec, `Merge::next` output row reservation/loop, and the existing `run_spec`/`NativeQueryRun.block_rows` metadata. No other pivot `BLOCK_ROWS` use appeared in the scoped files. The current source does not state how a future provider extraction should own or pass a block-row parameter; that design choice remains with the primary.

## Related spill and replay code names

There is no `shardloom-vortex/src/local_primitives/native_relational_spill_replay.rs` in this checkout. Existing query replay is module `stored` at `native_relational_spill.rs:33-35`, implemented by `native_relational_stored_order.rs`. Its `Replay` retains either resident array+metadata or a `NativeQueryRun` plus block rows (`:37-51`); `for_each` slices resident arrays by stored block rows or reads run blocks while retaining reader/block credits through consume (`:53-87`). This is a distinct stored-order replay API; pivot uses `pivot::Store/Owned/Access` directly and does not call `Replay`.

The generic order-run path in `native_relational_spill.rs:194-220, 302-439` is distinct from pivot replacement: it sorts `Spec` rows, flushes immutable ordered runs, and merges same-level runs; its block rows are `batch_rows.clamp(1, BLOCK_ROWS)`. It shares `State`, `QueryRunStore`, run specs and reader ownership. Pivot does not use `Ordering` or `Replay` to implement its replacement lookup/update semantics.

## Existing tests that exercise extraction-sensitive behavior

The pivot suite is imported by `local_primitive_relational_tests.rs:44-45` from `local_primitive_relational_pivot_spill_tests.rs`, which in turn includes composition, failure, pressure, recovery, semantics and typed submodules (`:11-22`). The most direct store/API behavior selectors are:

- `native_pivot_spill_sequential_lookups_reuse_covering_blocks` and `native_pivot_spill_repeated_updates_bound_lookup_amplification` (`local_primitive_relational_pivot_spill_tests.rs:142-190`) protect cache reuse and repeated-update lookup bounds; first asserts expected block counts using `div_ceil(1024)`.
- `native_pivot_spill_nonmonotonic_updates_preserve_keys_at_cached_gap_edges` (`:199-239`) exercises multi-run compaction and cached missing-gap boundaries.
- `native_pivot_spill_repeated_evicted_cells_preserve_sequential_float_prefixes` (`:242-276`) compares resident/spilled exact aggregates and checks run/reader counts; output rows are grouped around the 1,024-sized store blocks.
- `native_pivot_spill_validates_open_cache_and_both_merge_pass_generations` (`local_primitive_relational_pivot_spill_failure_tests.rs:47-88`) corrupts/truncates/replaces files at open, cache, gap, count and merge stages.
- `native_pivot_spill_quota_grant_and_partial_merge_denials_release_owned_state`, `native_pivot_spill_late_consumers_cancellation_and_source_changes_never_complete`, and `native_pivot_spill_empty_input_is_inert_and_zero_limit_keeps_existing_rejection` (`...pivot_spill_failure_tests.rs:138-175,199-260`) cover quota/partial merge cleanup, consumer/cancel/source-generation failure, and empty/zero-limit behavior.
- `native_pivot_spill_exact_binary_decimal_temporal_and_list_values_survive_duplicate_reads`, `native_pivot_spill_nested_extrema_and_null_parents_preserve_selected_complete_values`, and `native_pivot_spill_nested_index_and_domain_order_names_are_exact` (`local_primitive_relational_pivot_spill_typed_tests.rs:127,177,257`) cover typed Vortex records and schema/key ordering. The last selector asserts 257 index rows at lines 281-282.
- `native_pivot_spill_recovery_preserves_live_and_unknown_owners_then_restarts` and `streamed_pivot_spill_recovery_preserves_live_and_unknown_owners_then_restarts` (`local_primitive_relational_pivot_spill_recovery_tests.rs:171-177`) protect ownership recovery. The implementation's process-death recovery tests only owned abandoned runs then fresh restart; see `:180+`.
- `native_pivot_spill_composes_filter_order_offset_projection_and_owned_reuse`, `native_pivot_spill_nested_pivots_share_one_owner_and_report_each_discovery_once`, and `native_pivot_spill_composed_output_reopens_all_admitted_writers_and_protects_destinations` (`local_primitive_relational_pivot_spill_composition_tests.rs:79,110,158`) protect shared state, output owner lifetime and sinks.
- Pressure selectors `native_pivot_spill_pressure_denies_resident_and_completes_beyond_the_same_grant` and `streamed_dynamic_pivot_spill_pressure_denies_resident_and_completes_beyond_the_same_grant` (`local_primitive_relational_pivot_pressure_tests.rs:193-198`) cover same-grant resident denial/spill completion.

No test was run. The scoped source does not identify a direct unit-test module dedicated only to `pivot::Store`; current regression coverage is through pivot integration/pressure/failure/typed/composition/recovery selectors listed above.

## Scope gaps / uncertainty

The requested `local_primitive_unary_pivot_spill_finish.rs` and `native_relational_spill_replay.rs` filenames are absent; their nearest actual counterparts are respectively the `complete` function in `local_primitive_unary_pivot_spill.rs` and `native_relational_stored_order.rs`. This inventory identifies existing facts and choke points only. It does not determine what row block-size policy a different family should use, whether existing pivot block rows should change, or which pivot helper contracts are semantically shared versus pivot-only.
