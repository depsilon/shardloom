# Unary membership public failure controls

Appended 63 publication-failure cases to `scripts/native_streaming_unary_membership_cases.py`: seven distinct/dedup/mask kinds × producer failure, corrupted replay spill, and spill quota failure × incremental batches, Vortex write, and fanout to Vortex plus JSONL.

Each case uses the existing 8,193-row, 2,048-byte unique-key pressure producer, the 16-MiB grant and 128-MiB spill quota (2 MiB for quota denial), and checks the expected producer sentinel or structured error diagnostic. It verifies no report or partial destination was published, producer closure and single-open behavior, spill workspace cleanup with the foreign witness preserved, then collects one row through the same public context and runs the existing completion/no-fallback checks.

The established 147 unary-membership success cases were left unchanged. AST parsing, trailing-whitespace checks, and `git diff --check` passed. No tests, builds, or native commands were run.
