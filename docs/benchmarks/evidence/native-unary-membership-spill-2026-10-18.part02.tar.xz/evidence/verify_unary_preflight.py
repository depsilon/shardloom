"""Reopen the focused public unary run before admitting the complete matrix."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'scripts')]
from native_workflow_protocol import report_fields, strict_json
from verify_unary_public import verify
from reuse_unary_acceptance import verify_reuse


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def read(path):
    return strict_json(Path(path).read_text())


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', required=True, type=Path)
parser.add_argument('--receipt', required=True)
args = parser.parse_args()
assert args.root.parent == OUT and args.root.is_dir()
source = read(OUT / 'acceptance-source.json')
build = read(OUT / 'acceptance-build.json')
bridge = verify_reuse()
assert build['source_commit'] == bridge['compiled_source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for name, digest in source['source_hashes'].items():
    assert identity(ROOT / name)['sha256'] == digest, name
assert identity(build['binary'])['sha256'] == build['binary_sha256']
receipt_path = OUT / (args.receipt + '.json')
receipt = read(receipt_path)
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['direct_child_reaped']
assert receipt['head'] == source['source_commit'] and receipt['working_tree'] == ''
assert identity(OUT / (args.receipt + '.log'))['sha256'] == receipt['log_sha256']
command = receipt['command']
assert command[command.index('--binary') + 1] == build['binary']
assert command[command.index('--uat-root') + 1] == str(args.root)
assert command[command.index('--operation-timeout') + 1] == '600'
assert '--compress-logs' in command
families = command[command.index('--families') + 1:]
assert families == ['unary-membership', 'unary-pressure']
summary_path = args.root / 'summary.json'
summary = read(summary_path)
assert summary['status'] == 'passed' and summary['families'] == families
assert not summary['performance_claim'] and not summary['whole_process_memory_ceiling']
declaration = read(OUT / 'unary-public-case-declaration-730.json')
expected = sorted(name for family in families for name in declaration[family])
assert len(expected) == 261
assert sorted(case['name'] for case in summary['cases']) == expected
assert all(case['status'] == 'passed' for case in summary['cases'])
for path, digest in summary['sources'].items():
    assert identity(path)['sha256'] == digest
    if path != build['binary']:
        assert identity(args.root / 'logs' / Path(path).name)['sha256'] == digest
assert summary['sources'][build['binary']] == build['binary_sha256']
seen = set()
for record in summary['compressed_json_files']:
    path = args.root / record['path']
    assert path.resolve().is_relative_to(args.root.resolve())
    assert record['path'] not in seen
    seen.add(record['path'])
    assert identity(path)['sha256'] == record['sha256']
    raw = gzip.decompress(path.read_bytes())
    assert len(raw) == record['raw_bytes']
    assert hashlib.sha256(raw).hexdigest() == record['raw_sha256']
    value = strict_json(raw.decode())
    if isinstance(value, dict) and 'fallback' in value:
        assert value['fallback']['attempted'] is False
assert seen == {str(path.relative_to(args.root)) for path in (args.root / 'logs').glob('*.json.gz')}
record = verify(args.root, summary, identity, strict_json, report_fields)
record.update(status='passed', source_commit=source['source_commit'], public_cases=261,
              summary=identity(summary_path), run_receipt=identity(receipt_path),
              complete_matrix_acceptance=False, verifier=identity(__file__),
              value_verifier=identity(OUT / 'verify_unary_public.py'))
with (OUT / (args.receipt + '-verified.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'public_cases': 261,
                  'unary_complete_value_archives': len(record['unary_complete_value_archives'])}))
