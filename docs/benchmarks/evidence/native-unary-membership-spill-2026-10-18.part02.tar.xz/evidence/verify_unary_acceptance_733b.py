"""Reopen unary membership acceptance against its frozen source and plan."""
import argparse
from collections import Counter
import csv
from decimal import Decimal
import gzip
import hashlib
import json
import os
import re
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-unary-membership-20261018')
DEVELOPMENT = Path('/Users/dylan/LocalData/shardloom/native-unary-membership-readback-20261018')
from reuse_unary_acceptance import verify_reuse
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'benchmarks/traditional_analytics')]
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings, timing_totals, TIMING_METRICS
from run_clickbench_query_uat import equivalent, score
from check_benchmark_artifact_completeness import validate_manifest
from local_uat_storage import require_local_path


def read(path):
    return strict_json(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def check(ref):
    assert identity(ref['path']) == ref, ref['path']
    return Path(ref['path'])


def generation(path):
    path = require_local_path(Path(path), Path.home(), sys.platform)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    assert not info.st_flags & getattr(stat, 'SF_DATALESS', 0x40000000)
    assert info.st_blocks * 512 >= info.st_size
    return dict(device=info.st_dev, inode=info.st_ino, size_bytes=info.st_size,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def receipt(name, command=None):
    directory = PRIOR if name.endswith('-731') else OUT
    expected_head = build['source_commit'] if directory == PRIOR else source['source_commit']
    path = directory / f'{name}.json'
    record = read(path)
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert record['head'] == expected_head and record['working_tree'] == ''
    assert record['log_sha256'] == identity(directory / f'{name}.log')['sha256']
    if command is not None:
        assert record['command'] == command
    return {'receipt': identity(path), 'log': identity(directory / f'{name}.log')}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('input', 'full43', 'public', 'modular', 'final'))
parser.add_argument('--receipt')
args = parser.parse_args()
plan_path = OUT / 'acceptance-plan.json'
plan_identity = identity(plan_path)
plan = read(plan_path)
build = read(check(plan['build']))
source = read(check(plan['source']))
check(plan['source_reuse_bridge'])
verify_reuse()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
assert all(identity(ROOT / name)['sha256'] == digest for name, digest in source['source_hashes'].items())
assert identity(build['binary'])['sha256'] == build['binary_sha256']
check(build['native_library'])
for ref in ([plan[key] for key in ('reference', 'query_source', 'public_runner', 'modular_runner', 'guard', 'public_case_declaration')]
            + plan['query_harness'] + plan['schema_sources'] + plan['verification_helpers']):
    check(ref)
target = Path(plan['input']['path'])
assert generation(target) == plan['input']['generation']
report = {'status': 'passed', 'phase': args.phase, 'plan': plan_identity,
          'source_commit': source['source_commit'], 'compiled_source_commit': build['source_commit'],
          'source_reuse_bridge': plan['source_reuse_bridge'], 'performance_claim': False,
          'verifier': identity(__file__)}
if args.phase == 'input':
    actual = identity(target)
    assert actual['sha256'] == plan['input']['sha256'] and actual['bytes'] == plan['input']['bytes']
    assert generation(target) == plan['input']['generation']
    report.update(input=actual, generation=generation(target), resident=True, reingested=False)
elif args.phase == 'full43':
    assert args.receipt
    report['run'] = receipt(args.receipt, plan['commands']['full43'])
    preflight = read(OUT / 'acceptance-input-verified.json')
    assert preflight['status'] == 'passed' and preflight['plan'] == plan_identity
    summaries = sorted((OUT / 'full43/logs').glob('*/summary.json'))
    assert len(summaries) == 1, summaries
    summary_path = summaries[0]
    summary = read(summary_path)
    assert summary['build_commit'] == build['source_commit']
    assert summary['binary_sha256'] == build['binary_sha256']
    assert summary['source'] == str(target) and summary['source_generation'] == plan['input']['generation']
    for key in ('complete', 'full_result_validation', 'completed_identity_check',
                'reference_packet_identity_verified', 'harness_identity_verified', 'engine_timing_required'):
        assert summary[key] is True, key
    assert summary['reference_kind'] == plan['reference_kind'] == 'retained_native_regression'
    assert summary['reference_packet']['sha256'] == plan['reference']['sha256']
    assert summary['queries_sha256'] == plan['query_source']['sha256']
    assert summary['harness_sha256'] == {ref['path']: ref['sha256'] for ref in plan['query_harness']}
    assert summary['memory_gb'] == 24 and summary['max_parallelism'] == 12
    assert summary['log_budget_bytes'] == {'retained': 1024 << 20, 'active_run': 256 << 20}
    assert summary['selected_query_ids'] == list(range(1, 44)) and len(summary['records']) == 43
    assert summary['repeats'] == 1 and summary['hot_total_seconds'] is None
    assert {(row['query'], row['run']) for row in summary['records']} == {(q, 1) for q in range(1, 44)}
    reference = load_reference_packet(Path(plan['reference']['path']), Path(plan['query_source']['path']))
    schemas = {int(query): tuple(schema) for ref in plan['schema_sources']
               for query, schema in read(check(ref))['expected_schemas'].items()}
    assert set(schemas) == set(range(1, 44))
    rows, nanos, envelopes, companions, engine_times = 0, 0, [], [], []
    for item in summary['records']:
        query = item['query']
        assert item['passed'] and item['validation'] == 'complete_values'
        assert item['returncode'] == 0 and not item['guard_failures']
        assert item['command'][0] == build['binary']
        assert item['command'][item['command'].index('--input') + 1] == str(target)
        prefix = summary_path.parent / f'q{query:02d}_run1'
        timing_path = prefix.with_suffix('.timing.json')
        timing = read(timing_path)
        assert timing['returncode'] == 0
        for key in ('seconds', 'user_cpu_seconds', 'system_cpu_seconds'):
            assert timing[key] == item[key]
        assert timing['peak_rss_bytes'] == item['native_peak_rss_bytes']
        pid_path = prefix.with_suffix('.pid')
        try:
            os.kill(int(pid_path.read_text()), 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError(f'Query process remains: {pid_path}')
        companions.extend([identity(timing_path), identity(pid_path)])
        envelope = None
        for packed in item['completed_log_archives']:
            payload = Path(packed['path']).read_bytes()
            assert len(payload) == packed['gzip_bytes']
            assert hashlib.sha256(payload).hexdigest() == packed['gzip_sha256']
            raw = gzip.decompress(payload)
            assert len(raw) == packed['raw_bytes'] and hashlib.sha256(raw).hexdigest() == packed['raw_sha256']
            envelopes.append(identity(packed['path']))
            if packed['path'].endswith('.stdout.json.gz'):
                assert envelope is None
                envelope = strict_json(raw.decode())
        assert envelope is not None and envelope['status'] == 'success'
        assert envelope['fallback']['attempted'] is False
        fields = report_fields(envelope)
        for key, value in query_phase_timings(fields, timing['seconds']).items():
            assert item[key] == value, (query, key)
        assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
        for key, value in fields.items():
            if key.endswith(('fallback_attempted', 'fallback_execution_allowed', 'external_engine_invoked')):
                assert value == 'false' or value is False, (query, key)
        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
        actual = extract_result(envelope)
        assert equivalent(actual, reference['values'][query])
        assert hashlib.sha256(json.dumps(actual, sort_keys=True, allow_nan=False).encode()).hexdigest() == item['result_sha256']
        assert (fields['result_schema_format'], strict_json(fields['result_schema_json'])) == schemas[query]
        rows += len(actual)
        nanos += int(fields['native_query_execution_nanos'])
        engine_times.append({'query': query, 'engine_execution_seconds': item['engine_execution_seconds']})
    assert rows == 381 and len(companions) == 86
    for key, value in score(summary['records'], 43, repeats=1, timing_key='engine_execution_seconds').items():
        assert summary[key] == value, key
    assert summary['secondary_process_wall'] == score(summary['records'], 43, repeats=1)
    assert summary['timing_totals'] == timing_totals(summary['records'])
    csv_path = summary_path.parent / 'query-timings.csv'
    with csv_path.open() as stream:
        csv_rows = list(csv.DictReader(stream))
    assert len(csv_rows) == 43
    for row, item in zip(csv_rows, summary['records']):
        assert int(row['query']) == item['query'] and int(row['run']) == 1
        assert row['passed'] == row['engine_timing_reported'] == 'True'
        for key in TIMING_METRICS:
            assert float(row[key]) == item[key]
    assert identity(target) == preflight['input']
    assert generation(target) == plan['input']['generation']
    assert not (OUT / 'full43/.ingest-uat.lock').exists()
    report.update(summary=identity(summary_path), timing_csv=identity(csv_path), queries=43,
                  calls=43, complete_rows=rows, engine_execution_nanos=nanos,
                  engine_execution_seconds=str(Decimal(nanos) / Decimal(1_000_000_000)),
                  engine_times=engine_times, values_schemas_clocks_and_certificates_reopened=True,
                  native_children_absent=True, input=preflight['input'], reingested=False,
                  envelopes=envelopes, companions=companions)
elif args.phase == 'public':
    assert args.receipt
    report['run'] = receipt(args.receipt, plan['commands']['public'])
    root = OUT / 'public-37'
    summary_path = root / 'summary.json'
    summary = read(summary_path)
    assert summary['status'] == 'passed' and not summary['performance_claim']
    assert summary['whole_process_memory_ceiling'] is False
    command = plan['commands']['public']
    assert summary['families'] == command[command.index('--families') + 1:]
    assert len(summary['families']) == 37 and len(summary['cases']) == 5126
    declaration = read(check(plan['public_case_declaration']))
    assert sorted(case['name'] for case in summary['cases']) == declaration['expected_public_case_names']
    assert summary['families'] == declaration['families']
    assert Counter(case['status'] for case in summary['cases']) == {'passed': 5126}
    assert summary['compress_logs'] and summary['operation_timeout_seconds'] == 600
    for path, digest in summary['sources'].items():
        assert identity(path)['sha256'] == digest
        if path != build['binary']:
            assert identity(root / 'logs' / Path(path).name)['sha256'] == digest
    assert summary['sources'][build['binary']] == build['binary_sha256']
    seen, envelopes = set(), 0
    members = []
    for item in summary['compressed_json_files']:
        path = root / item['path']
        assert path.resolve().is_relative_to(root.resolve())
        assert item['path'] not in seen
        seen.add(item['path'])
        payload = path.read_bytes()
        assert len(payload) == item['bytes'] and hashlib.sha256(payload).hexdigest() == item['sha256']
        raw = gzip.decompress(payload)
        assert len(raw) == item['raw_bytes'] and hashlib.sha256(raw).hexdigest() == item['raw_sha256']
        value = strict_json(raw.decode())
        if isinstance(value, dict) and 'fallback' in value:
            assert value['fallback']['attempted'] is False
            assert value['fallback']['allowed'] is False and value['fallback']['engine'] is None
            if value['status'] == 'success':
                fields = report_fields(value)
            else:
                assert value['status'] in ('error', 'unsupported')
                entries = value['fields']
                assert isinstance(entries, list)
                fields = {entry['key']: entry['value'] for entry in entries}
                assert len(fields) == len(entries)
            for key, field in fields.items():
                if key.endswith(('fallback_attempted', 'external_engine_invoked')):
                    assert field == 'false' or field is False
            envelopes += 1
        members.append(identity(path))
    assert seen == {str(path.relative_to(root)) for path in (root / 'logs').glob('*.json.gz')}
    assert envelopes > 0
    # Reopen every new complete-value archive using an independent numeric-domain
    # oracle. CSV spellings are the only expected scalar conversion.
    set_records = []
    count = 8193
    formats = ('vortex', 'parquet', 'arrow_ipc', 'avro', 'orc', 'json', 'jsonl', 'csv')
    from native_workflow_outputs import LOCAL_FORMATS
    assert set(formats) == set(LOCAL_FORMATS)
    expected_members = []
    for kind in ('union', 'intersect', 'except_'):
        for offset in (0, count // 2, count):
            for surface in ('dataframe', 'sql'):
                expected_members.append((f'set-membership-spilled-{kind}-{offset}-{surface}', kind, offset, False))
        for destination in formats:
            expected_members.append((f'set-membership-spilled-{kind}-write-{destination}', kind, count // 2, destination == 'csv'))
            expected_members.append((f'set-membership-spilled-{kind}-fanout-all-eight-{destination}', kind, count // 2, destination == 'csv'))
    for destination in formats:
        expected_members.append((f'set-membership-spilled-except-empty-write-{destination}', 'except_', 0, destination == 'csv'))
    assert len(expected_members) == 74

    def keys(kind, offset):
        if kind == 'union':
            yield from range(count - 1, -1, -1)
            yield from range(count, count + offset)
        elif kind == 'intersect':
            yield from range(count - 1, offset - 1, -1)
        else:
            yield from range(min(offset, count) - 1, -1, -1)

    for name, kind, offset, csv_spelling in expected_members:
        path = root / 'logs' / (name + '-values.jsonl.gz')
        oracle = iter(keys(kind, offset))
        rows, digest = 0, hashlib.sha256()
        with gzip.open(path, 'rb') as stream:
            for line in stream:
                key = next(oracle, None)
                assert key is not None, name
                expected = {'n': str(key) if csv_spelling else key, 's': f'{key:08d}' + 'p' * 2040}
                assert strict_json(line.decode()) == expected, (name, rows)
                digest.update(line)
                rows += 1
        assert next(oracle, None) is None, name
        set_records.append({'name': name, 'rows': rows, 'sha256': digest.hexdigest(), 'values': identity(path)})
    assert {str(root / 'logs' / (name + '-values.jsonl.gz')) for name, *_ in expected_members} == {
        str(path) for path in (root / 'logs').glob('set-membership-spilled-*-values.jsonl.gz')}
    report['set_membership_complete_value_archives'] = set_records
    from verify_unary_public import verify as verify_unary_public
    report.update(verify_unary_public(root, summary, identity, strict_json, report_fields))
    report.update(summary=identity(summary_path), cases=5126, families=37,
                  all_recorded_cases_passed=True, no_fallback_envelopes=envelopes,
                  compressed_log_members_verified=len(members), logs=members,
                  source_snapshots_verified=True)
elif args.phase == 'modular':
    assert args.receipt
    report['run'] = receipt(args.receipt, plan['commands']['modular'])
    matrix_path = OUT / 'unary-membership-matrix-733-report.json'
    matrix = read(matrix_path)
    assert matrix['status'] == 'passed' and matrix['records'] == 1408 and matrix['native_records'] == 704
    assert len(matrix['cohorts']) == 18
    assert not matrix['performance_claim'] and not matrix['complete_cartesian_input_output_coverage_claimed']
    assert matrix['binary'] == build['binary'] and matrix['binary_sha256'] == build['binary_sha256']
    assert matrix['runtime_commit'] == build['source_commit']
    assert matrix['harness_commit'] == source['source_commit']
    assert not matrix['changed_metadata_test_only']
    assert matrix['build_manifest_sha256'] == plan['build']['sha256']
    assert matrix['driver_sha256'] == plan['modular_runner']['sha256']
    cohorts, status_counts = [], Counter()
    for cohort in matrix['cohorts']:
        assert cohort['receipt']['returncode'] == 0 and not cohort['receipt']['guard_failures']
        assert cohort['independently_reopened']
        path = Path(cohort['report'])
        assert identity(path)['sha256'] == cohort['report_sha256']
        assert identity(cohort['stdout'])['sha256'] == cohort['stdout_sha256']
        stderr = Path(cohort['stdout']).with_name(Path(cohort['stdout']).name.replace('.stdout.json', '.stderr.txt'))
        assert identity(stderr)['sha256'] == cohort['stderr_sha256']
        blockers, observed = validate_manifest(path)
        assert not blockers, blockers
        records = observed['records']
        assert len(records) == cohort['observed_records']
        assert sum(row['engine'] == 'shardloom' for row in records) == cohort['native_records']
        assert sum(row['engine'] == 'pandas' for row in records) == cohort['native_records']
        assert all(row['status'] == 'passed' and row['matches_reference'] for row in records)
        status_counts.update(row['status'] for row in records)
        cohorts.append({'report': identity(path), 'stdout': identity(cohort['stdout']),
                        'stderr': identity(stderr), 'records': len(records),
                        'native_records': cohort['native_records'],
                        'input_state': cohort['input_state'], 'inputs': cohort['formats'],
                        'output': cohort['output_format']})
    assert sum(cohort['native_records'] for cohort in cohorts) == 704
    assert status_counts == {'passed': 1408}
    report.update(matrix=identity(matrix_path), cohorts=18, records=1408, native_workflows=704,
                  independent_pandas_oracle_workflows=704, all_values_match=True,
                  complete_cartesian_input_output_coverage_claimed=False, cohort_reports=cohorts)
else:
    phases = {name: read(OUT / f'acceptance-{name}-verified.json')
              for name in ('input', 'public', 'full43', 'modular')}
    assert all(value['status'] == 'passed' and value['plan'] == plan_identity for value in phases.values())
    gates = {}
    test_counts = {}
    for name in ('unary-native-vortex-tests-731', 'unary-workspace-fmt-731',
                 'unary-public-reference-731', 'unary-public-reference-tests-731',
                 'unary-workspace-clippy-731', 'unary-workspace-tests-731',
                 'unary-native-clippy-731', 'unary-native-cli-tests-731',
                 'unary-direct-binding-tests-733', 'unary-public-context-tests-733'):
        gates[name] = receipt(name)
        log = Path(gates[name]['log']['path']).read_text()
        rust_counts = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.MULTILINE)
        python_counts = re.findall(r'^Ran (\d+) tests? in ', log, re.MULTILINE)
        python_skips = re.findall(r'^(test_\w+) .*? \.\.\. skipped (.*)$', log, re.MULTILINE)
        if 'tests-' in name or 'family-repair-' in name:
            assert rust_counts or python_counts, name
            assert all(int(failed) == 0 for _, failed, _ in rust_counts)
            if python_counts:
                reported_skips = sum(map(int, re.findall(r'^OK \(skipped=(\d+)\)$', log, re.MULTILINE)))
                assert reported_skips == len(python_skips)
                expected_skips = (['test_process_result_chaining_preserves_empty_nested_nullable_and_exact_types']
                                  if name == 'unary-public-context-tests-733' else [])
                assert [selector for selector, _ in python_skips] == expected_skips
            passed = sum(int(value[0]) for value in rust_counts) + sum(map(int, python_counts)) - len(python_skips)
            assert passed > 0, name
            test_counts[name] = {'passed': passed,
                                'ignored': sum(int(value[2]) for value in rust_counts) + len(python_skips),
                                'python_skips': python_skips}
    assert identity(target) == phases['input']['input']
    assert generation(target) == plan['input']['generation']
    # These are declared per-workflow progress streams, not receipt documents.
    # Their complete bytes were already checked by the modular verifier; retain
    # that exact path/identity boundary instead of skipping arbitrary JSON errors.
    progress = {cohort['stdout']['path']: cohort['stdout']
                for cohort in phases['modular']['cohort_reports']}
    assert len(progress) == 18
    assert set(progress) == {str(path) for path in OUT.glob('unary-*.stdout.json')}
    report['verification_correction'] = {
        'original_verifier': next(ref for ref in plan['verification_helpers']
                                  if Path(ref['path']).name == 'verify_unary_acceptance.py'),
        'reason': 'Declared modular progress streams are not single JSON receipt documents.',
        'modular_progress_streams': list(progress.values()),
        'frozen_plan_and_runtime_inputs_unchanged': True,
    }
    development = {}
    for path in sorted([*PRIOR.glob('unary-*.json'), *DEVELOPMENT.glob('unary-*.json'), *OUT.glob('unary-*.json')]):
        name = path.stem
        if str(path) in progress:
            check(progress[str(path)])
            continue
        item = read(path)
        if name in gates or not isinstance(item, dict) or 'log_sha256' not in item or 'command' not in item:
            continue
        assert item['status'] in ('passed', 'failed') and item['process_group_drained'], name
        log = path.with_suffix('.log')
        assert item['log_sha256'] == identity(log)['sha256'], name
        development[name] = {'receipt': identity(path), 'log': identity(log), 'status': item['status']}
    report.update(source=plan['source'], build=plan['build'], gates=gates, test_counts=test_counts,
                  development_evidence=development,
                  acceptance_scope=source['scope'],
                  finite_family_acceptance_complete=True,
                  broader_membership_population_owner_complete=False,
                  broader_recovery_owner_complete=False, crash_recovery='owned_cleanup_then_fresh_execution',
                  phase_reports={name: identity(OUT / f'acceptance-{name}-verified.json') for name in phases},
                  public_cases=5126, public_families=37, queries=43, query_result_rows=381,
                  modular_cohorts=18, native_workflows=704, independent_pandas_oracle_workflows=704,
                  engine_execution_seconds=phases['full43']['engine_execution_seconds'],
                  reingested=False, publication_attempted=False, release_version_changed=False,
                  source_files_verified=len(build['source_hashes']))

assert identity(plan_path) == plan_identity
save(f'acceptance-{args.phase}-verified.json', report)
print(json.dumps({key: report[key] for key in ('status', 'phase', 'queries', 'calls', 'complete_rows', 'engine_execution_seconds') if key in report}))
