"""Run the frozen native unary acceptance stages serially; preserve every failure."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'
GUARD = OUT / 'run_guarded.py'

def checked_source():
    source = json.loads((OUT / 'acceptance-source.json').read_text())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert source['source_commit'] == head
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
    for name, digest in source['source_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    return source

def run(name, command, timeout=1800):
    source = checked_source()
    path = OUT / (name + '.json')
    if path.exists():
        prior = json.loads(path.read_text())
        assert prior['status'] == 'passed', f'Failed evidence retained; select a new attempt: {path}'
        assert prior['command'] == command and prior['head'] == source['source_commit']
        assert prior['working_tree'] == '' and prior['process_group_drained']
        assert prior['log_sha256'] == hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest()
        print(json.dumps({'stage': name, 'status': 'verified_previous_pass'}), flush=True)
        return
    print(json.dumps({'stage': name, 'status': 'starting'}), flush=True)
    subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command],
                   cwd=ROOT, check=True)
    checked_source()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('bindings', 'matrix', 'final'))
args = parser.parse_args()
source = checked_source()
from reuse_unary_acceptance import verify_reuse
verify_reuse()
build = json.loads((OUT / 'acceptance-build.json').read_text())
if args.phase == 'bindings':
    env = ['/usr/bin/env', 'SHARDLOOM_NATIVE_TEST_LIBRARY=' + build['native_library']['path'], 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON]
    run('unary-direct-binding-tests-732', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_native*binding.py', '-v'])
    run('unary-public-context-tests-732', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_context.py', '-v'], 300)
elif args.phase == 'matrix':
    plan = json.loads((OUT / 'acceptance-plan.json').read_text())
    run('unary-input-verify-732', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), 'input'], 600)
    for family, timeout in [('public', 3600), ('full43', 1800), ('modular', 3600)]:
        name = 'unary-' + family + '-732'
        run(name, plan['commands'][family], timeout)
        run('unary-' + family + '-verify-732', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), family, '--receipt', name], 900)
else:
    run('unary-final-verify-732', [PYTHON, '-B', str(OUT / 'verify_unary_acceptance.py'), 'final'], 900)
    run('unary-owner-acceptance-732', [PYTHON, '-B', str(OUT / 'finalize_unary_acceptance.py')], 300)
print(json.dumps({'phase': args.phase, 'status': 'passed'}), flush=True)
