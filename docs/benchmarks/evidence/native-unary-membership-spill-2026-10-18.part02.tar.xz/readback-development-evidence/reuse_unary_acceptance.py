"""Prove exact runtime equality while retaining the actual compiled commit."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-unary-membership-20261018')
COMPILED = 'a31bd7748dfb37d9b8550deb274eeef8a9d7a2e8'
HARNESSES = ('python/tests/test_native_unary_binding.py',
             'scripts/native_streaming_unary_membership_cases.py')
GATES = ["unary-workspace-fmt-731","unary-public-reference-731","unary-public-reference-tests-731","unary-native-vortex-tests-731","unary-workspace-clippy-731","unary-workspace-tests-731","unary-native-clippy-731","unary-native-cli-tests-731","unary-cli-build-731","unary-binding-build-731","unary-freeze-artifacts-731","unary-freeze-plan-731"]


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def prove():
    source = read(OUT / 'acceptance-source.json')
    prior = read(PRIOR / 'acceptance-source.json')
    build = read(PRIOR / 'acceptance-build.json')
    assert source['source_commit'] == git('rev-parse', 'HEAD')
    assert git('status', '--porcelain') == source['working_tree'] == ''
    assert prior['source_commit'] == build['source_commit'] == COMPILED
    assert prior['working_tree'] == build['working_tree'] == ''
    assert build['source_hashes'] == prior['source_hashes']
    assert build['source_manifest'] == identity(PRIOR / 'acceptance-source.json')
    assert git('rev-parse', 'HEAD^') == COMPILED
    assert git('diff', '--name-only', COMPILED, 'HEAD').splitlines() == list(HARNESSES)
    assert source['source_hashes'].keys() == prior['source_hashes'].keys()
    changed = {name: {'compiled_sha256': prior['source_hashes'][name], 'acceptance_sha256': digest}
               for name, digest in source['source_hashes'].items()
               if digest != prior['source_hashes'][name]}
    assert set(changed) == set(HARNESSES)
    for name in HARNESSES:
        old_bytes = subprocess.check_output(['git', 'show', COMPILED + ':' + name], cwd=ROOT)
        assert hashlib.sha256(old_bytes).hexdigest() == changed[name]['compiled_sha256']
    for name, digest in source['source_hashes'].items():
        assert identity(ROOT / name)['sha256'] == digest, name
    assert identity(build['binary'])['sha256'] == build['binary_sha256']
    assert identity(build['native_library']['path']) == build['native_library']
    assert 'Compiling shardloom-cli v0.6.0' in (PRIOR / 'unary-cli-build-731.log').read_text()
    reused = {}
    for name in GATES:
        path = PRIOR / (name + '.json')
        receipt = read(path)
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['head'] == COMPILED and receipt['working_tree'] == ''
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        log = identity(PRIOR / (name + '.log'))
        assert log['sha256'] == receipt['log_sha256']
        reused[name] = {'receipt': identity(path), 'log': log}
    return {
        'schema_version': 'shardloom.unary_membership.runtime_reuse.v1',
        'status': 'passed', 'compiled_source_commit': COMPILED,
        'acceptance_source_commit': source['source_commit'],
        'compiled_source': identity(PRIOR / 'acceptance-source.json'),
        'acceptance_source': identity(OUT / 'acceptance-source.json'),
        'original_build': identity(PRIOR / 'acceptance-build.json'),
        'compiled_build_record_preserved_verbatim': True,
        'only_changed_source': changed,
        'all_other_frozen_sources_byte_identical': True,
        'unchanged_frozen_source_count': len(source['source_hashes']) - len(HARNESSES),
        'complete_git_diff_is_only_the_named_test_harnesses': True,
        'reused_passed_gates_and_builds': reused,
        'fresh_bindings_public_full43_and_modular_acceptance_required': True,
        'generator': identity(__file__),
    }


def verify_reuse():
    record = prove()
    assert read(OUT / 'acceptance-source-bridge.json') == record
    assert (OUT / 'acceptance-build.json').read_bytes() == (PRIOR / 'acceptance-build.json').read_bytes()
    return record


if __name__ == '__main__':
    assert sys.argv[1:] == ['--create']
    record = prove()
    with (OUT / 'acceptance-build.json').open('xb') as stream:
        stream.write((PRIOR / 'acceptance-build.json').read_bytes())
    with (OUT / 'acceptance-source-bridge.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    verify_reuse()
    print(json.dumps({'status': 'passed', 'compiled_source_commit': COMPILED,
                      'acceptance_source_commit': record['acceptance_source_commit'],
                      'reused_passed_gates_and_builds': len(GATES),
                      'unchanged_frozen_source_count': record['unchanged_frozen_source_count']}))
