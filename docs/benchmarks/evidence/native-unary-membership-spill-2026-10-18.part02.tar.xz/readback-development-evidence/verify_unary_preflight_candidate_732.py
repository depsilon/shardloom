"""Verify the corrected development cohort without relabeling frozen acceptance."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from native_workflow_protocol import report_fields, strict_json
from verify_unary_public import verify


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


name = 'unary-public-preflight-732b'
root = OUT / name
summary = strict_json((root / 'summary.json').read_text())
receipt = strict_json((OUT / (name + '.json')).read_text())
source = strict_json((OUT / 'acceptance-source.json').read_text())
assert receipt['status'] == summary['status'] == 'passed'
assert receipt['returncode'] == 0 and receipt['direct_child_reaped'] and receipt['process_group_drained']
assert receipt['head'] == source['source_commit']
assert receipt['working_tree'].strip() == 'M scripts/native_streaming_unary_membership_cases.py'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == receipt['working_tree']
assert identity(OUT / (name + '.log'))['sha256'] == receipt['log_sha256']
changed = {path for path, sha in source['source_hashes'].items() if identity(ROOT / path)['sha256'] != sha}
assert changed == {'scripts/native_streaming_unary_membership_cases.py'}
families = ['unary-membership', 'unary-pressure']
declaration = strict_json((OUT / 'unary-public-case-declaration-730.json').read_text())
assert summary['families'] == families
assert len(summary['cases']) == 261 and all(case['status'] == 'passed' for case in summary['cases'])
assert sorted(case['name'] for case in summary['cases']) == sorted(name for family in families for name in declaration[family])
for path, sha in summary['sources'].items():
    assert identity(path)['sha256'] == sha
    if Path(path).suffix == '.py':
        assert identity(root / 'logs' / Path(path).name)['sha256'] == sha
for record in summary['compressed_json_files']:
    path = root / record['path']
    assert identity(path)['sha256'] == record['sha256']
    raw = gzip.decompress(path.read_bytes())
    assert len(raw) == record['raw_bytes'] and hashlib.sha256(raw).hexdigest() == record['raw_sha256']
result = verify(root, summary, identity, strict_json, report_fields)
result.update(status='passed', acceptance=False, scope='corrected_development_preflight',
              summary=identity(root / 'summary.json'), receipt=identity(OUT / (name + '.json')),
              source_changes={path: identity(ROOT / path) for path in changed},
              verifier=identity(__file__), value_verifier=identity(OUT / 'verify_unary_public.py'))
with (OUT / (name + '-values-verified.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'public_cases': 261,
                  'value_archives': len(result['unary_complete_value_archives']), 'acceptance': False}))
