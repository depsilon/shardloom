"""Profile the accepted merged engine; all sampled clocks are diagnostic only."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0] = [str(O), str(R / 'scripts')]
from freeze_native_release_298 import sha, sources, save

read = lambda p: json.loads(p.read_text())
ref = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert head == 'd2e6867d466e1871e45aa72a7e5eadc5525ea133'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=R)
final_path = O / 'native-shared-execution-final-selected-source-625.json'
bridge_path = O / 'native-shared-execution-final-comment-bridge-625.json'
merged_path = O / 'native-shared-execution-hosted-626/merged-sources-626.json'
artifacts_path = O / 'native-dictionary-partials618-release.json'
final = read(final_path)
bridge = read(bridge_path)
merged = read(merged_path)
artifacts = read(artifacts_path)
assert sha(final_path) == '8b07d48b3c811aaba7697c6ed788ea06a5e819d40a020fbc7d5059044737f636'
assert sha(bridge_path) == '5d962b6a7a4566f2f11ed7592cf612028f0f4e517bb3ed09ab235e23c752d181'
assert merged['merge'] == head and merged['all_selected_sources_match']
assert sources() == final['source_sha256']
assert final['source_sha256'].keys() == artifacts['source_sha256'].keys()
changed = [p for p in final['source_sha256'] if final['source_sha256'][p] != artifacts['source_sha256'][p]]
change = bridge['change']
assert changed == [change['path']]
assert artifacts['source_sha256'][change['path']] == change['before_sha256']
text = (R / change['path']).read_text()
assert text.count(change['replacement']) == 1 and change['original'] not in text
before = text.replace(change['replacement'], change['original'])
assert hashlib.sha256(before.encode()).hexdigest() == change['before_sha256']
assert sha(Path(artifacts['cli']['path'])) == artifacts['cli']['sha256']
review_path = O / 'native-shared-execution-full43-619/review.json'
review = read(review_path)
baseline_path = Path(review['summary']['path'])
assert sha(baseline_path) == review['summary']['sha256']
queries = [item['query'] for item in sorted(review['per_query'],
    key=lambda item: float(item['mean_engine_seconds']['candidate']), reverse=True)[:12]]
assert queries == [29, 19, 23, 34, 35, 17, 28, 33, 10, 16, 14, 32]
helper = O / 'profile_hotspots_465.py'
assert sha(helper) == '9ab7ed37dd8f54200fd5ec70af4ab16471e1a54ff10dba816587c933c74ca708'
code = helper.read_text()
changes = {
    "baseline['binary_sha256']": "baseline['binaries']['candidate']['sha256']",
    "accepted = artifacts['source_sha256']": "accepted = json.loads(FINAL_SELECTED_SOURCE.read_text())['source_sha256']",
    "assert differences == sorted([\n        'scripts/run_clickbench_query_uat.py', 'scripts/run_clickbench_paired_query_uat.py',\n        'scripts/test_clickbench_query_uat.py', 'scripts/test_clickbench_paired_query_uat.py',\n    ])": "assert differences == [], 'current selected sources differ from accepted merged runtime'",
}
for original, replacement in changes.items():
    assert code.count(original) == 1, original
    code = code.replace(original, replacement)
ast.parse(code)
effective = O / 'profile_merged_shared_speed_637_effective.py'
effective.open('x').write(code)
parameters = dict(DEST=O / 'hotspot-profiles-637', BASELINE=baseline_path,
    ARTIFACTS=artifacts_path, QUERIES=queries, FINAL_SELECTED_SOURCE=final_path)
protocol = dict(status='frozen_before_sampling', purpose='diagnostic_attribution_not_benchmark_timing',
    revision=head, parameters={k: str(v) if isinstance(v, Path) else v for k, v in parameters.items()},
    helper=ref(helper), launcher=ref(Path(__file__)), effective_program=ref(effective),
    source_proof=[ref(p) for p in [final_path, bridge_path, merged_path, artifacts_path]],
    historical_comparison=ref(review_path), historical_summary=ref(baseline_path),
    query_selection='12 largest candidate mean engine times in accepted complete 619 comparison',
    scope='One complete public native query process per selected query, sequential and sampled; no speed claim.',
    source_differences_from_measured_build=changed, exact_comment_reversal_verified=True,
    inherited_controls='Unchanged storage budgets, UAT lock, process supervision, reference values, source generation and native no-fallback evidence.')
save(O / 'hotspot-profiles-637-parameters.json', protocol)
namespace = dict(__name__='merged_shared_speed_profile', __file__=str(effective))
exec(compile(code, str(effective), 'exec'), namespace)
namespace.update(parameters)
namespace['main']()
result = read(parameters['DEST'] / 'summary.json')
assert result['status'] == 'passed' and result['lock_released']
assert len(result['records']) == len(queries) == 12
assert all(item['passed'] and item['native_child_absent'] and item['timing_supervisor_reaped'] and item['sampler_reaped'] for item in result['records'])
assert sources() == final['source_sha256']
for identity in protocol['source_proof'] + [protocol['helper'], protocol['launcher'], protocol['effective_program'], protocol['historical_comparison'], protocol['historical_summary']]:
    assert sha(Path(identity['path'])) == identity['sha256']
save(O / 'hotspot-profiles-637-acceptance.json', dict(status='passed', samples=12,
    complete_results_verified=12, source_files_verified=len(final['source_sha256']),
    protocol=ref(O / 'hotspot-profiles-637-parameters.json'), summary=ref(parameters['DEST'] / 'summary.json'),
    benchmark_credit=False, all_children_reaped=True, accepted_merged_source_verified=True))
