"""Five serial diagnostic stack samples; sampled clocks are not benchmark results."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources

sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from query_timing_report import query_phase_timings
from run_clickbench_paired_query_uat import generation
from run_clickbench_query_uat import equivalent

DEST = OUT / 'hotspot-profiles-465'
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASELINE = UAT / 'logs/full43_20261015T090121385273Z/summary.json'
ARTIFACTS = OUT / 'query-timing-native-artifacts-461.json'
QUERIES = [23, 19, 29, 34, 35]


def interrupted(*_):
    raise KeyboardInterrupt


def stop(child):
    if child is not None and child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()


def absent(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    return False


def main():
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    require_local_path(DEST, Path.home(), sys.platform)
    baseline = json.loads(BASELINE.read_text())
    artifacts = json.loads(ARTIFACTS.read_text())
    binary = Path(artifacts['cli']['path'])
    assert sha(binary) == artifacts['cli']['sha256'] == baseline['binaries']['candidate']['sha256']
    current = sources()
    accepted = json.loads(FINAL_SELECTED_SOURCE.read_text())['source_sha256']
    assert current.keys() == accepted.keys()
    differences = sorted(p for p in accepted if current[p] != accepted[p])
    assert differences == [], 'current selected sources differ from accepted merged runtime'
    source = require_local_path(Path(baseline['source']), Path.home(), sys.platform)
    original_generation = generation(source)
    assert original_generation == baseline['source_generation']
    reference_path = Path(baseline['reference_packet']['path'])
    assert sha(reference_path) == baseline['reference_packet']['sha256']
    query_path = ROOT / 'benchmarks/clickbench/queries.sql'
    packet = load_reference_packet(reference_path, query_path)
    assert sha(query_path) == baseline['queries_sha256']
    assert not DEST.exists()
    DEST.mkdir()

    def guard():
        check_budgets(OUT, source, DEST, min_free_bytes=12 * GIB,
                      reserve_bytes=32 * MIB, max_workspace_bytes=100 * GIB,
                      max_log_bytes=192 * MIB, max_run_log_bytes=64 * MIB)

    guard()
    lock = UAT / '.ingest-uat.lock'
    lock.mkdir()
    report = dict(status='running', purpose='diagnostic_sampling_not_benchmark_timing',
                  sample_scope='one fresh native CLI process per selected query; up to three seconds at one-millisecond sampling; profiler may perturb scheduling and elapsed time',
                  query_order=QUERIES, source=str(source), source_generation=original_generation,
                  baseline_summary=str(BASELINE), baseline_sha256=sha(BASELINE),
                  artifact_manifest=str(ARTIFACTS), artifact_manifest_sha256=sha(ARTIFACTS),
                  binary_sha256=sha(binary), helper_sha256=sha(__file__),
                  current_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                  source_sha256=current, source_differences_from_accepted=differences,
                  records=[])
    try:
        for query in QUERIES:
            guard()
            assert generation(source) == original_generation
            prefix = DEST / f'q{query:02d}'
            command = public_workflow_command(binary, packet['queries'][query-1], input_path=source,
                                              input_format='vortex', memory_gb=24, max_parallelism=12)
            timed = [sys.executable, str(ROOT / 'scripts/timed_native_command.py'),
                     '--timing', str(prefix.with_suffix('.timing.json')),
                     '--pid-file', str(prefix.with_suffix('.pid')), '--shared-process-group', '--', *command]
            record = dict(query=query, command=command, timed_command=timed, passed=False)
            child = sampler = None
            try:
                with prefix.with_suffix('.stdout.json').open('xb') as output, prefix.with_suffix('.stderr.txt').open('xb') as error:
                    child = subprocess.Popen(timed, cwd=ROOT, stdout=output, stderr=error)
                    started = time.monotonic()
                    while not prefix.with_suffix('.pid').exists():
                        if child.poll() is not None or time.monotonic()-started > 10:
                            raise RuntimeError('native PID was not published')
                        time.sleep(0.005)
                    pid = int(prefix.with_suffix('.pid').read_text())
                    record['native_pid'] = pid
                    sample_command = ['/usr/bin/sample', str(pid), '3', '1', '-mayDie', '-file', str(prefix.with_suffix('.sample.txt'))]
                    record['sample_command'] = sample_command
                    with prefix.with_suffix('.sample-command.txt').open('xb') as sample_log:
                        sampler = subprocess.Popen(sample_command, stdout=sample_log, stderr=subprocess.STDOUT)
                        record['returncode'] = child.wait(timeout=120)
                        record['sample_returncode'] = sampler.wait(timeout=30)
                assert record['returncode'] == record['sample_returncode'] == 0
                timing = strict_json(prefix.with_suffix('.timing.json').read_text())
                assert timing['returncode'] == 0
                envelope = strict_json(prefix.with_suffix('.stdout.json').read_text())
                fields = report_fields(envelope)
                values = extract_result(envelope)
                assert equivalent(values, packet['values'][query])
                record.update(timing=timing, phase_timings=query_phase_timings(fields, timing['seconds']),
                              complete_rows=len(values), result_sha256=hashlib.sha256(json.dumps(values, sort_keys=True, allow_nan=False).encode()).hexdigest(),
                              schema_json=fields['result_schema_json'], schema_format=fields['result_schema_format'])
                assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                sample_text = prefix.with_suffix('.sample.txt').read_text()
                assert f'(pid {pid})' in sample_text and 'Call graph:' in sample_text
                assert absent(pid)
                assert generation(source) == original_generation
                record.update(passed=True, native_child_absent=True)
            except BaseException as error:
                record['failure'] = f'{type(error).__name__}: {error}'
                raise
            finally:
                stop(sampler)
                stop(child)
                record['timing_supervisor_reaped'] = child is None or child.poll() is not None
                record['sampler_reaped'] = sampler is None or sampler.poll() is not None
                record['files'] = [dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))
                                   for path in sorted(DEST.glob(prefix.name + '.*'))]
                prefix.with_suffix('.receipt.json').write_text(json.dumps(record, indent=2) + '\n')
                report['records'].append(record)
                (DEST / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
            guard()
            print(json.dumps(dict(query=query, passed=record['passed'], rows=record['complete_rows'],
                                  diagnostic_engine_seconds=record['phase_timings']['engine_execution_seconds'])), flush=True)
        assert sources() == current
        assert sha(binary) == report['binary_sha256']
        assert sha(BASELINE) == report['baseline_sha256']
        assert sha(reference_path) == baseline['reference_packet']['sha256']
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', failure=f'{type(error).__name__}: {error}')
        raise
    finally:
        lock.rmdir()
        report['lock_released'] = True
        (DEST / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], queries=len(report['records']), evidence=str(DEST))), flush=True)


if __name__ == '__main__':
    main()
