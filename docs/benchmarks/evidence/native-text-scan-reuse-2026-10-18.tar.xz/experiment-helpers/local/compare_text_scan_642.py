"""Frozen native text scan comparison using the maintained complete-query runner."""
import argparse
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import sys
import tarfile
import time

O = Path(__file__).resolve().parent
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0] = [str(O), str(R / 'scripts')]
import compare_selected_views_467 as shared
from freeze_native_release_298 import save, sha, sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from query_timing_report import query_phase_timings

D = O / 'native-text-scan-screen-642'
PLAN = O / 'native-text-scan-plan-642.json'
read, bound, verify = shared.read, shared.bound, shared.verify


def archived(summary):
    result = {}
    for archive in summary['archives']:
        assert sha(archive['path']) == archive['sha256']
        with tarfile.open(archive['path'], 'r:xz') as stream:
            assert stream.getnames() == [m['name'] for m in archive['members']]
            for member in archive['members']:
                data = stream.extractfile(member['name']).read()
                assert len(data) == member['bytes']
                assert hashlib.sha256(data).hexdigest() == member['sha256']
                assert member['name'] not in result
                result[member['name']] = data
    return result


def git_sources(revision, names):
    result = {}
    with subprocess.Popen(['git', 'cat-file', '--batch'], cwd=R,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
        for name in sorted(names):
            process.stdin.write((revision + ':' + name + '\n').encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', name
            data = process.stdout.read(int(header[2]))
            assert process.stdout.read(1) == b'\n'
            result[name] = hashlib.sha256(data).hexdigest()
        process.stdin.close()
        assert process.wait(timeout=30) == 0
    return result


def preflight():
    plan = read(PLAN)
    assert sha(plan['invocation_proof']['path']) == plan['invocation_proof']['sha256']
    proof = read(plan['invocation_proof']['path'])
    assert proof['status'] == 'passed' and not proof['performance_credit']
    assert proof['unfiltered_native_view_allocations'] == 1 and proof['filtered_native_view_allocations'] == 2
    for item in proof['files']:
        assert hashlib.sha256(item['content'].encode()).hexdigest() == item['sha256']
    assert not D.exists()
    require_local_path(D, Path.home(), sys.platform)
    storage = check_budgets(O, D, O / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    control, candidate = [read(O / plan[k]) for k in ['control_manifest', 'candidate_manifest']]
    validation_path = O/'native-text-scan-focused-validation-review-642.json'
    validation = read(validation_path)
    assert validation['status'] == 'passed'
    assert len(validation['new_tests']) == 7
    for item in validation['evidence']:
        verify(item)
    verify(validation['source'])
    assert validation['source'] == bound(O/'native-text-scan642-source.json')
    base_path = O / plan['source_base']
    base = read(base_path)
    assert candidate['head'] == base['head']
    assert candidate['source_sha256'] == sources()
    assert git_sources(base['head'], base['source_sha256']) == base['source_sha256']
    changed = {k: dict(base=base['source_sha256'].get(k), candidate=v)
        for k, v in candidate['source_sha256'].items() if base['source_sha256'].get(k) != v}
    assert set(base['source_sha256']) <= set(candidate['source_sha256'])
    assert sorted(changed) == sorted(plan['expected_source_changes'])
    profile_path = O / 'hotspot-profiles-637-acceptance.json'
    profile = read(profile_path)
    assert sha(profile_path) == base['profiling_acceptance_sha256']
    assert profile['status'] == 'passed' and profile['samples'] == 12
    assert profile['accepted_merged_source_verified'] and not profile['benchmark_credit']
    verify(profile['protocol']); verify(profile['summary'])
    profile_protocol = read(profile['protocol']['path'])
    for item in profile_protocol['source_proof']:
        verify(item)
    merged = read(O / 'native-shared-execution-final-selected-source-625.json')['source_sha256']
    assert git_sources(plan['baseline_revision'], merged) == merged
    assert {k for k, v in base['source_sha256'].items() if merged.get(k) != v} == set(plan['inherited_test_only_changes'])
    assert set(merged) <= set(base['source_sha256'])
    bridge_path = O / plan['inherited_comment_bridge']
    bridge = read(bridge_path)
    assert bridge['status'] == 'passed' and not bridge['behavior_changed']
    comment = bridge['change']
    assert {k for k, v in merged.items() if control['source_sha256'].get(k) != v} == {comment['path']}
    original = subprocess.check_output(['git', 'show', plan['baseline_revision'] + ':' + comment['path']], cwd=R)
    assert original.count(comment['replacement'].encode()) == 1
    restored = original.replace(comment['replacement'].encode(), comment['original'].encode())
    assert hashlib.sha256(restored).hexdigest() == control['source_sha256'][comment['path']]
    test_parent = R / 'shardloom-vortex/src/vortex_ingest_dictionary_preservation.rs'
    assert '#[cfg(all(\n    test,\n    feature = "universal-format-io",\n    feature = "vortex-local-primitives"\n))]\n#[path = "vortex_ingest_source_dictionary_bench.rs"]' in test_parent.read_text()
    identities = {}
    for role, manifest, name in [('control', control, plan['control_manifest']),
                                 ('candidate', candidate, plan['candidate_manifest'])]:
        assert manifest['status'] == 'passed'
        cli = manifest['cli']; receipt = read(cli['build_receipt'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert sha(cli['build_receipt']) == cli['build_receipt_sha256']
        assert sha(cli['build_log']) == receipt['log_sha256']
        assert sha(cli['path']) == cli['sha256']
        identities[role] = dict(manifest=bound(O/name), binary=bound(cli['path']),
            build_receipt=bound(cli['build_receipt']), build_log=bound(cli['build_log']))
    assert identities['control']['binary']['sha256'] != identities['candidate']['binary']['sha256']
    records = [json.loads(line) for line in Path(candidate['cli']['build_log']).read_text().splitlines() if line.startswith('{')]
    compiled = [x for x in records if x.get('reason') == 'compiler-artifact' and
        x.get('target', {}).get('name') in ['shardloom_vortex', 'shardloom']]
    assert len(compiled) == 2 and all(not x['fresh'] for x in compiled)
    input_path = Path(plan['input']); generation = shared.paired.generation(input_path)
    assert input_path.stat().st_flags == 0 and input_path.stat().st_blocks*512 >= input_path.stat().st_size
    input_identity = bound(input_path)
    assert input_identity['sha256'] == plan['input_sha256']
    assert shared.paired.generation(input_path) == generation
    queries = R / 'benchmarks/clickbench/queries.sql'
    assert sha(shared.REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = shared.load_reference_packet(shared.REFERENCE, queries)
    verify(profile_protocol['historical_summary'])
    historical = read(profile_protocol['historical_summary']['path'])
    raw = archived(historical)
    schemas = {}
    for query in sorted({q for c in plan['cohorts'] for q in c['query_ids']}):
        envelope = shared.strict_json(raw[f'q{query:02d}_run1_candidate.stdout.json'].decode())
        assert shared.equivalent(shared.extract_result(envelope), reference['values'][query])
        fields = shared.report_fields(envelope)
        schemas[str(query)] = [fields['result_schema_format'], shared.strict_json(fields['result_schema_json'])]
    helpers = [Path(__file__), Path(shared.__file__), O/'freeze_native_release_298.py',
        O/'freeze_query_cli_368.py', O/'run_guarded_worker_drain_565.py', base_path,
        bridge_path, profile_path, validation_path, Path(profile['protocol']['path']),
        Path(profile_protocol['historical_summary']['path']), Path(plan['invocation_proof']['path'])]
    helpers += [R/'scripts'/n for n in ['run_clickbench_paired_query_uat.py',
        'run_clickbench_query_uat.py', 'local_uat_storage.py', 'native_workflow_protocol.py',
        'timed_native_command.py', 'query_timing_report.py', 'clickbench_reference_packet.py']]
    assert sha(plan['design']['path']) == plan['design']['sha256']
    protocol = dict(**{k:v for k,v in plan.items() if k != 'design'},
        identities=identities, decision_plan=bound(PLAN), focused_validation=bound(validation_path),
        candidate_source=bound(O/'native-text-scan642-source.json'),
        source_differences=changed, inherited_source_proof=dict(base=bound(base_path),
            comment_bridge=bound(bridge_path), test_parent=bound(test_parent),
            selected_merged_files_verified=len(merged)), changed_crates_recompiled=compiled,
        input_identity=input_identity, input_generation=generation, queries=bound(queries),
        reference=bound(shared.REFERENCE), expected_schemas=schemas,
        schema_source_summary=profile_protocol['historical_summary'],
        helpers=[bound(x) for x in helpers], design=bound(plan['design']['path']), storage=storage,
        hardware=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
            physical_memory_bytes=os.sysconf('SC_PAGE_SIZE')*os.sysconf('SC_PHYS_PAGES')))
    D.mkdir()
    save(D/'protocol.json', protocol)
    added = sorted(set(candidate['source_sha256']) - set(base['source_sha256']))
    save(D/'candidate.patch.json', dict(patch=subprocess.check_output(
        ['git', 'diff', '--binary'], cwd=R, text=True),
        added_sources={name:(R/name).read_text() for name in added}))
    print(json.dumps(dict(status='preflight_passed', source_files=len(sources()),
        native_calls=plan['expected_native_calls'])), flush=True)


def verify_protocol(p):
    for item in p['helpers'] + [p['candidate_source'], p['decision_plan'], p['design'], p['queries'], p['reference']]:
        verify(item)
    for role in p['identities'].values():
        for item in role.values():
            verify(item)
    assert sources() == read(p['candidate_source']['path'])['source_sha256']


def run():
    p = read(D/'protocol.json'); verify_protocol(p)
    input_path = Path(p['input'])
    assert shared.paired.generation(input_path) == p['input_generation']
    verify(p['input_identity'])
    report = dict(status='running', protocol=bound(D/'protocol.json'), cohorts=[], records=[])
    started = time.perf_counter()
    try:
        for cohort in p['cohorts']:
            before = set((shared.UAT/'logs').glob('paired43_*'))
            command = [str(R/'scripts/run_clickbench_paired_query_uat.py'),
                '--control-binary', p['identities']['control']['binary']['path'],
                '--control-commit', p['baseline_revision'],
                '--candidate-binary', p['identities']['candidate']['binary']['path'],
                '--candidate-commit', p['baseline_revision']+'+text-scan-'+p['candidate_source']['sha256'][:12],
                '--input', str(input_path), '--uat-root', str(shared.UAT),
                '--reference-packet', p['reference']['path'],
                '--query-ids', ','.join(map(str, cohort['query_ids'])), '--repeats', str(cohort['pairs']),
                '--memory-gb', str(p['policy']['memory_gb']), '--max-parallelism', str(cohort['lanes']),
                '--max-log-mib', '1024', '--max-run-log-mib', '256']
            sys.argv = command
            code = shared.paired.main()
            added = set((shared.UAT/'logs').glob('paired43_*')) - before
            assert len(added) == 1
            folder = added.pop()
            report['cohorts'].append(dict(**cohort, command=command, returncode=code, summary=bound(folder/'summary.json')))
            assert code == 0
            report['records'].extend(shared.validate_cohort(folder, cohort, p))
            assert not (shared.UAT/'.ingest-uat.lock').exists()
            assert sources() == read(p['candidate_source']['path'])['source_sha256']
        assert len(report['records']) == p['expected_native_calls']
        assert shared.paired.generation(input_path) == p['input_generation']
        verify(p['input_identity']); verify_protocol(p)
        report.update(status='passed_integrity')
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['workflow_seconds'] = time.perf_counter() - started
        report['lock_released'] = not (shared.UAT/'.ingest-uat.lock').exists()
        save(D/'results.json', report)
    print(json.dumps(dict(status=report['status'], calls=len(report['records']))), flush=True)


def review():
    p = read(D/'protocol.json'); r = read(D/'results.json'); verify_protocol(p)
    assert r['status'] == 'passed_integrity' and r['lock_released']
    supervision_path = O/'native-text-scan-screen-642.json'
    supervision = read(supervision_path)
    assert supervision['status'] == 'passed' and supervision['returncode'] == 0
    assert supervision['process_group_drained'] and supervision['direct_child_reaped']
    assert sha(supervision_path.with_suffix('.log')) == supervision['log_sha256']
    rows, policies, work = [], {}, []
    policy_keys = ['local_primitive_resource_memory_budget_bytes',
        'local_primitive_resource_scan_concurrency_per_worker', 'local_primitive_physical_policy_route_family',
        'execution_resource_admitted_max_parallelism', 'execution_resource_admission_policy']
    for c in r['cohorts']:
        verify(c['summary'])
        rows += shared.validate_cohort(Path(c['summary']['path']).parent, c, p)
        summary = read(c['summary']['path']); raw = archived(summary)
        for row in summary['records']:
            prefix = f"q{row['query']:02d}_run{row['run']}_{row['role']}"
            envelope = shared.strict_json(raw[prefix+'.stdout.json'].decode())
            fields = shared.report_fields(envelope)
            clocks = query_phase_timings(fields, row['seconds'])
            assert clocks['engine_execution_seconds'] == row['engine_execution_seconds']
            nanos = fields['native_query_execution_nanos']
            assert isinstance(nanos, str) and nanos.isdecimal() and int(nanos) > 0
            assert abs(Decimal(str(row['engine_execution_seconds']))-Decimal(nanos)/10**9) < Decimal('0.000000000001')
            key = (row['query'], c['lanes'], row['run'], row['role'])
            assert key not in policies
            policies[key] = {k:fields[k] for k in policy_keys if k in fields}
            if row['query'] != 29 or row['role'] != 'candidate':
                continue
            lines = [line for line in envelope['human_text'].splitlines() if line.startswith('result summary: ')]
            assert len(lines) == 1
            _, delimiter, payload = lines[0].partition(' values='); assert delimiter
            diagnostic = shared.strict_json(payload)
            assert diagnostic['aggregate_text_scan_decoded_chunks'] > 0
            assert diagnostic['aggregate_text_scan_projected_reuses'] > 0
            assert diagnostic['aggregate_text_scan_scope'] == 'query_owned_single_text_comparison;native_pruning_unchanged;zstd_decode_shared_with_projection;other_columns_read_after_filter;encoded_dictionary_paths_preserved;active_range_lifetime;no_cross_query_cache'
            work.append(dict(query=row['query'], lanes=c['lanes'], run=row['run'], role=row['role'],
                evidence={k:v for k,v in diagnostic.items() if k.startswith('aggregate_text_scan_')}))
    assert rows == r['records'] and len(rows) == len(policies) == p['expected_native_calls']
    assert len(work) == 7
    for c in p['cohorts']:
        for query in c['query_ids']:
            first = policies[(query, c['lanes'], 1, 'control')]
            assert all(policies[(query, c['lanes'], run, role)] == first
                for run in range(1, c['pairs']+1) for role in ['control', 'candidate'])
    policy = p['policy']; cases = []
    totals = {family:{role:Decimal(0) for role in ['control', 'candidate']} for family in p['families']}
    for c in p['cohorts']:
        for query in c['query_ids']:
            samples = {role:sorted([x for x in rows if x['query'] == query and x['lanes'] == c['lanes'] and x['role'] == role],
                key=lambda x:x['run']) for role in ['control', 'candidate']}
            assert all([x['run'] for x in xs] == list(range(1,c['pairs']+1)) for xs in samples.values())
            means = {role:sum(Decimal(str(x['engine_execution_seconds'])) for x in xs)/len(xs) for role,xs in samples.items()}
            deltas = [Decimal(str(a['engine_execution_seconds']))-Decimal(str(b['engine_execution_seconds']))
                for a,b in zip(samples['control'], samples['candidate'], strict=True)]
            family = next((name for name, ids in p['families'].items() if query in ids), None)
            target = c['lanes'] == 12 and family is not None
            if target:
                for role, value in means.items(): totals[family][role] += value
            material_regression = means['candidate']-means['control'] > max(
                means['control']*Decimal(str(policy['control_engine_increase_fraction'])),
                Decimal(str(policy['control_engine_increase_seconds']))) and all(d < 0 for d in deltas)
            engine = (means['candidate'] < means['control'] and sum(d > 0 for d in deltas) >= policy['target_positive_pairs']) if target else not material_regression
            cpu = {role:statistics.mean(x['cpu_seconds'] for x in xs) for role,xs in samples.items()}
            rss = {role:max(x['native_peak_rss_bytes'] for x in xs) for role,xs in samples.items()}
            cpu_ok = not target or cpu['candidate'] <= cpu['control']*(1+policy['target_cpu_increase_fraction'])
            rss_ok = rss['candidate'] <= rss['control']+max(rss['control']*policy['rss_increase_fraction'],policy['rss_increase_bytes'])
            cases.append(dict(query=query, lanes=c['lanes'], pairs=c['pairs'], family=family, target=target,
                engine_means={k:str(v) for k,v in means.items()},
                engine_improvement_percent=str(100*(means['control']-means['candidate'])/means['control']),
                paired_engine_savings=[str(x) for x in deltas], positive_pairs=sum(d>0 for d in deltas),
                engine_passed=engine, cpu_passed=cpu_ok, rss_passed=rss_ok, passed=engine and cpu_ok and rss_ok,
                diagnostic_cpu_means=cpu, diagnostic_rss_peaks=rss))
    family_decisions = {}
    for family, values in totals.items():
        gain = (values['control']-values['candidate'])/values['control']
        gain_ok = gain >= Decimal(str(policy['target_family_mean_reduction_fraction']))
        members_ok = all(c['passed'] for c in cases if c['target'] and c['family'] == family)
        family_decisions[family] = dict(engine_means_sum={k:str(v) for k,v in values.items()},
            engine_improvement_percent=str(gain*100), gain_passed=gain_ok, members_passed=members_ok,
            passed=gain_ok and members_ok)
    accepted = all(x['passed'] for x in family_decisions.values()) and all(c['passed'] for c in cases)
    result = dict(status='passed_integrity', decision='retain_for_batch' if accepted else 'drop_failed_component',
        calls=len(rows), all_values_and_schemas=True, native_clocks_independently_verified=True,
        resource_policy_equal_within_each_case=True, target_family_admission_verified=True,
        protocol=bound(D/'protocol.json'), results=bound(D/'results.json'), supervision=bound(supervision_path),
        families=family_decisions, cases=cases, target_work_evidence=work)
    save(D/'review.json', result)
    print(json.dumps({k:result[k] for k in ['status', 'decision', 'calls', 'families', 'cases']}), flush=True)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['preflight', 'run', 'review'])
    args = parser.parse_args()
    {'preflight':preflight, 'run':run, 'review':review}[args.operation]()

