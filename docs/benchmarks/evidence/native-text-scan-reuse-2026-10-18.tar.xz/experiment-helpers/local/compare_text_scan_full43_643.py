"""Prospective all-43 acceptance for shared native text filter/projection decoding."""
import argparse
from decimal import Decimal
import json
import signal
import sys
from pathlib import Path

O = Path(__file__).resolve().parent
sys.path.insert(0, str(O))
import compare_text_scan_642 as focused
from freeze_native_release_298 import save, sha, sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from query_timing_report import query_phase_timings

shared = focused.shared
R = focused.R
D = O / 'native-text-scan-full43-643'
PLAN = O / 'native-text-scan-full43-plan-643.json'
read, bound, verify = shared.read, shared.bound, shared.verify


def preflight():
    plan = read(PLAN)
    prior_protocol_path = focused.D/'protocol.json'
    prior_review_path = focused.D/'review.json'
    prior = read(prior_review_path)
    assert prior['status'] == 'passed_integrity' and prior['decision'] == 'retain_for_batch'
    assert prior['calls'] == 74 and prior['all_values_and_schemas']
    assert prior['native_clocks_independently_verified'] and prior['target_family_admission_verified']
    for key in ['protocol', 'results', 'supervision']:
        verify(prior[key])
    prior_protocol = read(prior_protocol_path)
    focused.verify_protocol(prior_protocol)
    assert prior['protocol'] == bound(prior_protocol_path)
    assert not D.exists()
    require_local_path(D, Path.home(), sys.platform)
    storage = check_budgets(O, D, O/'logs', min_free_bytes=12*GIB,
        reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    assert plan['baseline_revision'] == prior_protocol['baseline_revision']
    assert plan['control_manifest'] == prior_protocol['control_manifest']
    assert plan['candidate_manifest'] == prior_protocol['candidate_manifest']
    assert plan['input'] == prior_protocol['input']
    assert plan['input_sha256'] == prior_protocol['input_identity']['sha256']
    input_path = Path(plan['input'])
    assert shared.paired.generation(input_path) == prior_protocol['input_generation']
    verify(prior_protocol['input_identity'])
    assert shared.paired.generation(input_path) == prior_protocol['input_generation']
    reference = shared.load_reference_packet(shared.REFERENCE, R/'benchmarks/clickbench/queries.sql')
    verify(prior_protocol['schema_source_summary'])
    raw = focused.archived(read(prior_protocol['schema_source_summary']['path']))
    schemas = {}
    for query in range(1, 44):
        envelope = shared.strict_json(raw[f'q{query:02d}_run1_candidate.stdout.json'].decode())
        assert shared.equivalent(shared.extract_result(envelope), reference['values'][query])
        fields = shared.report_fields(envelope)
        schemas[str(query)] = [fields['result_schema_format'], shared.strict_json(fields['result_schema_json'])]
    protocol = dict(prior_protocol)
    protocol.update(plan)
    protocol.update(decision_plan=bound(PLAN), expected_schemas=schemas, storage=storage,
        accepted_focused_candidate=bound(prior_review_path), focused_protocol=bound(prior_protocol_path),
        focused_results=prior['results'], focused_supervision=prior['supervision'],
        helpers=prior_protocol['helpers'] + [bound(Path(__file__)), bound(prior_protocol_path),
            bound(prior_review_path), prior['results'], prior['supervision'], prior_protocol['decision_plan']])
    protocol.pop('families', None)
    assert protocol['expected_native_calls'] == 172
    assert sources() == read(protocol['candidate_source']['path'])['source_sha256']
    D.mkdir()
    save(D/'protocol.json', protocol)
    print(json.dumps(dict(status='preflight_passed', complete_calls=172,
        material_gain='strictly greater than 3%', binary=protocol['identities']['candidate']['binary'])), flush=True)


def run():
    # Reuse the already frozen complete-query runner, with this run's protocol.
    focused.D = D
    focused.run()


def review():
    p = read(D/'protocol.json'); r = read(D/'results.json')
    focused.verify_protocol(p)
    for key in ['accepted_focused_candidate', 'focused_protocol', 'focused_results', 'focused_supervision']:
        verify(p[key])
    assert r['status'] == 'passed_integrity' and r['lock_released']
    supervision_path = O/'native-text-scan-full43-643.json'
    supervision = read(supervision_path)
    assert supervision['status'] == 'passed' and supervision['returncode'] == 0
    assert supervision['process_group_drained'] and supervision['direct_child_reaped']
    assert sha(supervision_path.with_suffix('.log')) == supervision['log_sha256']
    assert len(r['cohorts']) == 1 and p['expected_native_calls'] == 172
    cohort = r['cohorts'][0]
    verify(cohort['summary'])
    rows = shared.validate_cohort(Path(cohort['summary']['path']).parent, cohort, p)
    assert rows == r['records'] and len(rows) == 172
    raw = focused.archived(read(cohort['summary']['path']))
    policy_keys = ['local_primitive_resource_memory_budget_bytes',
        'local_primitive_resource_scan_concurrency_per_worker', 'local_primitive_physical_policy_route_family',
        'execution_resource_admitted_max_parallelism', 'execution_resource_admission_policy']
    nanos, policies, work = {}, {}, []
    for row in rows:
        prefix = f"q{row['query']:02d}_run{row['run']}_{row['role']}"
        envelope = shared.strict_json(raw[prefix+'.stdout.json'].decode())
        fields = shared.report_fields(envelope)
        clocks = query_phase_timings(fields, row['seconds'])
        assert clocks['engine_execution_seconds'] == row['engine_execution_seconds']
        value = fields['native_query_execution_nanos']
        assert isinstance(value, str) and value.isdecimal() and int(value) > 0
        value = int(value)
        assert abs(Decimal(str(row['engine_execution_seconds']))-Decimal(value)/10**9) < Decimal('0.000000000001')
        key = (row['query'], row['run'], row['role'])
        assert key not in nanos
        nanos[key] = value
        policies[key] = {k:fields[k] for k in policy_keys if k in fields}
        if row['query'] == 29 and row['role'] == 'candidate':
            lines = [line for line in envelope['human_text'].splitlines() if line.startswith('result summary: ')]
            assert len(lines) == 1
            _, delimiter, payload = lines[0].partition(' values='); assert delimiter
            diagnostic = shared.strict_json(payload)
            assert diagnostic['aggregate_text_scan_decoded_chunks'] > 0
            assert diagnostic['aggregate_text_scan_projected_reuses'] > 0
            assert diagnostic['aggregate_text_scan_scope'] == 'query_owned_single_text_comparison;native_pruning_unchanged;zstd_decode_shared_with_projection;other_columns_read_after_filter;encoded_dictionary_paths_preserved;active_range_lifetime;no_cross_query_cache'
            work.append(dict(query=29, run=row['run'],
                evidence={k:v for k,v in diagnostic.items() if k.startswith('aggregate_text_scan_')}))
    assert len(nanos) == 172 and len(work) == 2
    paired = {role:{run:sum(nanos[(q,run,role)] for q in range(1,44)) for run in [1,2]}
        for role in ['control', 'candidate']}
    totals = {role:sum(Decimal(paired[role][run]) for run in [1,2])/2/10**9 for role in paired}
    cases = []
    for q in range(1,44):
        samples = {role:[nanos[(q,run,role)] for run in [1,2]] for role in paired}
        means = {role:sum(Decimal(v) for v in values)/2/10**9 for role,values in samples.items()}
        assert all(policies[(q,run,role)] == policies[(q,1,'control')] for run in [1,2] for role in paired)
        deltas = [Decimal(b-a)/10**9 for a,b in zip(samples['control'],samples['candidate'],strict=True)]
        increase = means['candidate']-means['control']
        regressed = increase > max(
            means['control']*Decimal(str(p['policy']['control_engine_increase_fraction'])),
            Decimal(str(p['policy']['control_engine_increase_seconds']))) and all(d > 0 for d in deltas)
        cases.append(dict(query=q,engine_nanos=samples,mean_engine_seconds={k:str(v) for k,v in means.items()},
            paired_candidate_minus_control_engine_seconds=[str(d) for d in deltas],
            mean_candidate_minus_control_engine_seconds=str(increase),
            mean_increase_percent=str(100*increase/means['control']),material_regression=regressed,
            resource_policy=policies[(q,1,'control')]))
    gain = (totals['control']-totals['candidate'])/totals['control']
    gain_ok = gain > Decimal(str(p['policy']['whole_workload_reduction_fraction']))
    both = all(paired['candidate'][run] < paired['control'][run] for run in [1,2])
    regressions = [c['query'] for c in cases if c['material_regression']]
    accepted = gain_ok and both and not regressions
    report = dict(status='passed_integrity',
        decision='accept_material_batch' if accepted else 'drop_failed_material_gate',
        calls=172, all_complete_values_and_schemas=True, no_fallback_evidence_verified=True,
        all_resources_and_physical_policy_equal_within_each_query=True,
        plan=bound(PLAN),protocol=bound(D/'protocol.json'),results=bound(D/'results.json'),
        summary=cohort['summary'],supervision=bound(supervision_path),source_final=p['candidate_source'],
        engine_score_aggregation='sum of 43 per-query means, two counterbalanced executions per role per query; primary native_query_execution_nanos converted to seconds',
        total_engine_means={k:str(v) for k,v in totals.items()},
        paired_full43_engine_totals={role:{str(run):str(Decimal(value)/10**9) for run,value in values.items()}
            for role,values in paired.items()},
        observed_gain_percent=str(gain*100),material_gain_passed=gain_ok,both_paired_totals_improved=both,
        material_regression_queries=regressions,per_query=cases,all_native_records=rows,target_work_evidence=work)
    save(D/'review.json', report)
    print(json.dumps({k:report[k] for k in ['status','decision','calls','total_engine_means',
        'paired_full43_engine_totals','observed_gain_percent','material_gain_passed',
        'both_paired_totals_improved','material_regression_queries']}), flush=True)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['preflight', 'run', 'review'])
    args = parser.parse_args()
    {'preflight':preflight, 'run':run, 'review':review}[args.operation]()
