<!-- SPDX-License-Identifier: Apache-2.0 -->

# Shared mixed-key execution after the ingest-size screen

Status: bounded experiment under PERF-01/04/05/10. After the native text-size
screen rejected all five alternatives, the maintainer redirected immediate work
to shared engine speed. The accepted runtime is PR #1571, merge `d2e6867d`.
Its retained 618 executable and exact comment-only source bridge remain the
control. The new ingest benchmark sources are test-only and change no production
execution. Broader PERF owners and CG-1 through CG-23 remain open.

The expert comparator is an encoded-columnar engine maintainer checking exact
key identity, source ownership, admitted allocation, failure order and complete
query cost. SQL, Python, DataFrame and CLI execution must continue to use the
same native operator families. Vortex input/output and no-fallback execution
remain unchanged; there is no new dependency, file encoding or public API.

## Fresh attribution

Twelve serial diagnostic samples use the accepted executable for the twelve
largest candidate means in the complete 619 comparison. Every complete result
passes its retained reference. All 2,412 selected sources match the merged
runtime, with the original two-line comment correction verified byte-for-byte.
These sampled calls receive attribution credit only, not benchmark timing credit.

Q14 and Q17 expose native `ByteBuffer` acquisition, cloning and release inside
compound partial construction and partition reconciliation. The current code
owns `VarBinViewArray` for the partial lifetime but still acquires temporary
payload owners for hashing, equality, text partitioning and each reducer entry.
Its numeric owner also has one checked primitive dtype per chunk, yet every
40-byte partial slot repeats a signedness flag and its alignment padding.

Q19 exposes persistent triple-key hash-table updates and growth. Its exact key
stores two 64-bit values and a complete kind byte in a padded 24-byte record.
The complete diagnostic records 56,384,822 distinct keys; this is observed
workload shape, not a runtime admission condition. Nested/thread sample counts
and overlapping worker counters are not exclusive stage times.

## Borrow compound values and retain chunk-level signedness once

Use the existing native byte borrow while the partial owns its checked
`VarBinViewArray`. Keep the current UTF-8 validation and full byte equality.
Return a borrowed byte slice for reconciliation; persistent partition state
still copies escaping keys into its independently owned storage. No borrowed
slice may escape the partial's lifetime.

Retain the admitted numeric owner's signedness once in the partial and keep
its full 64-bit value bits in each slot. Reconstruct the original complete key
at visit/reconciliation boundaries. This reduces the partial slot from 40 to
32 bytes without a numeric-width or row-count restriction. Signedness remains
part of equality across source chunks. Charge capacity using the actual slot
size; preserve dictionary-domain binding, null refusal, cancellation, overflow,
provider-error classification and exact pressure prefix/suffix handling.

Vortex-first decision: use the existing Vortex 0.85 native primitive owner,
VarBinView buffers and checked text access. This is a ShardLoom partial-state
layout and ownership correction, not a new Vortex encoding or provider.

## Compact complete triple keys in persistent count tables

An interned string ID at most `u64::MAX >> 8` leaves room for the complete kind
byte in the same 64-bit word. Store that word beside the unchanged numeric bits
in a 16-byte internal key. Preserve every bit of signedness and the transformed
minute identity. Larger IDs use a separate full-width table with disjoint key
admission; they retain exact support without truncation or a global migration.

Both tables keep the existing pinned native hash map and count-overflow checks.
Reserve each required table's capacity before insertion, including old-plus-new
growth overlap, and retain both credits until retirement. The existing partition
mixer, 64 partitions, producer key routing, worker grants, ordered completion,
top-k comparator and complete-group count remain unchanged. Output reconstructs
the original key. A committed reservation failure still cancels and drains the
query without replay. This does not introduce spill or external execution.

Vortex-first decision: implement the private ShardLoom aggregate-state layout.
Vortex Dict codes remain bound to their value domains; a shared native array
provider does not replace this query-owned exact count table. Existing native
scan, primitive, text and allocation providers remain in their approved boundary.

## Frozen focused acceptance

The first comparison uses the same resident 99,997,497-row native input, complete
reference values/schemas, resource policy and counterbalanced public query
runner as the accepted control. It preserves every sample and failed gate.
There is no profiler, pacing, cache purge, automatic retry or best-sample choice.

Run five pairs for Q14/Q17/Q19 at parallelism 12, two single-worker pairs for
the same targets, and two pairs for controls Q2/Q10/Q16/Q23/Q28/Q29/Q33/Q34/Q35.
This is 78 complete native calls. The compound family requires at least 5% lower
sum of Q14/Q17 five-sample engine means, and the triple family requires at least
5% lower Q19 mean. Each target needs four of five positive pairs. No control may
regress by more than the larger of 10% and 0.15 engine seconds with both deltas
positive. Preserve the existing component gates: at most 10% target process-CPU
increase and peak-RSS increase no greater than the larger of 25% and 256 MiB.
These secondary resource measures stay in diagnostic evidence.

Final whole-workload acceptance requires a fresh paired all-43 comparison,
two executions per query per build, with greater than 3% reduction in the sum
of per-query mean engine times, both paired totals improved, and the same
material per-query regression rule. This prospectively uses the maintainer's
accepted greater-than-3% bar; previous failed experiments remain failed under
their original protocols. Focused gains do not add into a whole-workload claim.

Prove compact/full-width boundary identities, signed/unsigned extrema, all kind
bits, exact weighted counts, growth overlap and denial cleanup. Compound tests
must cover inline/outlined Unicode and NUL, independent dictionary domains,
mixed signedness across chunks, escaping ownership, collisions and pressure.
Run required workspace/native gates, direct bindings, public workflows and the
format/oracle matrix before PR acceptance. Review, hosted checks, installed
wheels and production verification remain merge gates. No package release is
authorized by this optimization work.
