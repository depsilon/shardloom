"""Derive the current packet builder from the previously verified archive reader.

Only prepares source; it does not run benchmarks, validation, or packaging.
"""
import ast
import hashlib
import json
from pathlib import Path

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
origin = O / 'package_shared_execution_625.py'
source = origin.read_text()
original_sha = hashlib.sha256(source.encode()).hexdigest()
changes = []


def replace(before, after, *, count=None):
    global source
    found = source.count(before)
    assert found and (count is None or found == count), (before, found, count)
    source = source.replace(before, after)
    changes.append(dict(before=before, after=after, occurrences=found))


def section(start, end, replacement):
    global source
    assert source.count(start) == source.count(end) == 1
    first = source.index(start)
    last = source.index(end, first)
    old = source[first:last]
    source = source[:first] + replacement + source[last:]
    changes.append(dict(start=start, end=end, original_sha256=hashlib.sha256(old.encode()).hexdigest(), replacement=replacement))


for before, after in [
    ('native-shared-execution', 'native-text-scan'),
    ('sharedexecution624', 'textscan644'),
    ('-624', '-644'),
    ('_625', '_645'),
    ('-625', '-645'),
    ('native-text-scan-2026-10-17', 'native-text-scan-reuse-2026-10-18'),
    ("== 2412", "== 2415"),
    ('source_files=2412', 'source_files=2415'),
    ('complete retained 618 selected source', 'complete retained 642 selected source'),
    ('native-text-scan-acceptance-decision-644.json', 'native-text-scan-full43-643/review.json'),
    ("decision['status'] == 'accepted_under_revised_maintainer_bar'", "decision['status'] == 'passed_integrity' and decision['decision'] == 'accept_material_batch'"),
    ("decision['original_gate_passed'] is False", "decision['material_gain_passed'] is True and decision['both_paired_totals_improved']"),
    ('observed_engine_improvement_percent', 'observed_gain_percent'),
    ('maintainer_decision', 'performance_decision'),
    ('shardloom.native_shared_execution_evidence.v1', 'shardloom.native_text_scan_reuse_evidence.v1'),
]:
    replace(before, after)

section('ATTEMPTS = [', 'cohorts = []', '''ATTEMPTS = [
 ('638','native-mixed-key-screen-638',78,O/'native-mixed-key-design-638.md'),
 ('642','native-text-scan-screen-642',74,O/'native-text-scan-design-at-admission-644.md'),
 ('643','native-text-scan-full43-643',172,O/'native-text-scan-design-at-admission-644.md'),
]
''')
replace('for number, folder, expected_calls in ATTEMPTS:', 'for number, folder, expected_calls, design_copy in ATTEMPTS:', count=1)
replace("assert review['status'] == ('partial_integrity_verified' if number == '616' else 'passed_integrity')", "assert review['status'] == 'passed_integrity'", count=1)
replace("assert sha(root/'design.md') == p['design']['sha256']", "assert sha(design_copy) == p['design']['sha256']\n    add(design_copy,'experiments/'+folder+'/design.md','immutable original prospective contract',p['design']['sha256'])", count=1)

section('# Preserve the interrupted fourth 616 cohort,', 'for name in (\'stream-subquery-corrections-509/', '''# Profile samples are diagnostic evidence, separate from the 324 paired calls.
profile = O/'hotspot-profiles-637'
members.tree(profile,'attribution','attribution','all twelve diagnostic profiles; no timing credit',exclusions)
profile_summary=read(profile/'summary.json')
profile_parameters=read(O/'hotspot-profiles-637-parameters.json')
assert profile_summary['status']=='passed' and profile_summary['lock_released']
assert profile_summary['purpose']=='diagnostic_sampling_not_benchmark_timing'
assert profile_summary['query_order']==[29,19,23,34,35,17,28,33,10,16,14,32]
assert profile_summary['source_differences_from_accepted']==[]
assert len(profile_summary['records'])==12
for key in ('helper','launcher','effective_program','historical_comparison','historical_summary'):
    bound_item(profile_parameters[key],'attribution-inputs','original attribution source or reference')
    if Path(profile_parameters[key]['path']).suffix=='.py':helpers.append(Path(profile_parameters[key]['path']))
assert profile_parameters['effective_program']['sha256']==profile_summary['helper_sha256']
for item in profile_parameters['source_proof']:
    bound_item(item,'attribution-inputs','control source bridge and merge identity')
for row in profile_summary['records']:
    assert row['passed'] and row['returncode']==row['sample_returncode']==0
    assert row['native_child_absent'] and row['timing_supervisor_reaped'] and row['sampler_reaped']
    for item in row['files']:assert a.identity(item['path'])==item
for key in ('baseline_summary','artifact_manifest'):
    digest_key='baseline_sha256' if key=='baseline_summary' else key+'_sha256'
    path=Path(profile_summary[key])
    add(path,'attribution-inputs/'+path.name,'original attribution baseline and build identity',profile_summary[digest_key])
for failed in sorted(O.glob('native-text-scan-evidence-645-preflight-failure-*')):
    members.tree(failed,'packaging-corrections/'+failed.name,'packaging-corrections',
                 'preserved packaging failure; measurements unchanged',exclusions)
prefixes = ('native-mixed-key','native-shared-speed','native-text-scan','hotspot-profiles-637',
 'native-release-source-textscan','native-release-artifacts-textscan',
 'native-final-source-gate-results-textscan','native-final-feature-gate-results-textscan')
for path in sorted(O.iterdir()):
    if path.is_file() and path.name.startswith(prefixes) and path.suffix in ('.json','.log','.py','.md','.patch'):
        if path.name.startswith('native-text-scan-archive-645'):
            continue
        add(path,'receipts/'+path.name,'all original attempts, failures, tests, builds and acceptance evidence')
''')
replace("O/'inventory_shared_execution_tests_645.py',", "O/'prepare_text_scan_packet_645.py',", count=1)
replace("if c['attempt'] in ('611','619'):", "if c['attempt'] == '643':", count=1)
replace("and gain<5", "and gain>3", count=1)
replace("assert review['material_gain_passed'] is False and review['decision']=='drop_failed_material_gate'", "assert review['material_gain_passed'] is True and review['decision']=='accept_material_batch'", count=1)
replace('original_5_percent_gate_passed=False', 'prospective_greater_than_3_percent_gate_passed=True', count=1)
replace("full43['619']", "full43['643']", count=1)
replace('==1242', '==324')
replace('complete_paired_calls=1242', 'complete_paired_calls=324')
replace('attempts=15', 'attempts=3', count=1)
section('limitations=[', 'manifest=dict(', '''limitations=[
 'The greater-than-3% whole-workload gate was frozen prospectively and passes; the mixed-key experiment remains rejected under its original component gates.',
 'The two-sample matched comparison has uncontrolled OS cache state and does not establish a single-pass result or external-engine superiority.',
 'Retained native values and paired schemas are regression references; the format/workflow suite uses a separate pandas oracle only.',
 'Twelve profile samples and the decoder-invocation fixture receive diagnostic attribution only, without benchmark timing credit.',
 'Declared memory admission is not a whole-process RSS ceiling.',
 'Selected source identities match measured build642; later docs/site/evidence and the final Git commit are bridged separately.',
 'Large datasets, executable binaries and public output payloads are excluded with exact identities; complete values/envelopes and reproduction sources remain.',
 'Installed-wheel lanes, final-head CI/review and hosted deployment are recorded separately.',
]
''')
replace('bounded matched complete-workload engine comparison accepted under explicit revised maintainer bar', 'bounded matched complete-workload engine comparison passing the prospective greater-than-3% gate', count=1)
replace('Package this shared-execution batch', 'Package the shared text filter/projection decoding batch', count=1)

ast.parse(source)
target = O/'package_text_scan_645.py'
with target.open('x') as stream:
    stream.write(source)
record=dict(status='prepared_not_executed',origin=dict(path=str(origin),sha256=original_sha),
            target=dict(path=str(target),sha256=hashlib.sha256(source.encode()).hexdigest()),changes=changes)
with (O/'native-text-scan-packet-generation-645.json').open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps({key:record[key] for key in ('status','origin','target')}))
