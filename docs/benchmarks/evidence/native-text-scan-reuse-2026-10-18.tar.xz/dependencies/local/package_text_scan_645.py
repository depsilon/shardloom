"""Package the shared text filter/projection decoding batch with existing evidence readers.

This does not execute benchmarks, change a gate, or replace historical records.
"""
from pathlib import Path
from decimal import Decimal
import ast, csv, hashlib, io, json, lzma, re, sys, tarfile

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
DEST = R / 'docs/benchmarks/evidence'
LOCAL = O / 'native-text-scan-evidence-645'
STEM = 'native-text-scan-reuse-2026-10-18'
sys.path[:0] = [str(O), str(R / 'scripts')]
import run_zstd_metadata_acceptance_533 as a
from package_selection_acceptance_409 import Members, verify, sha_stream
from freeze_native_release_298 import save, sha
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from metadata_public_verifier_534 import verify_public
from verify_stream_unary_packet_497 import strict_json, report_fields, full_result, equivalent, safe_member, canonical_hash
from run_clickbench_paired_query_uat import role_order
from query_timing_report import query_phase_timings

read = lambda p: json.loads(Path(p).read_text())
a.SOURCE = O / 'native-release-source-textscan644.json'
a.MANIFEST = O / 'native-release-artifacts-textscan644.json'
frozen = a.unchanged()
build = a.load()
assert len(frozen['source_sha256']) == 2415
assert not LOCAL.exists() and not any(DEST.glob(STEM + '*'))
require_local_path(LOCAL, Path.home(), sys.platform)
check_budgets(O, LOCAL, O/'logs', min_free_bytes=12*GIB, reserve_bytes=512*MIB,
              max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
LOCAL.mkdir()
protocol = read(O/'native-text-scan-acceptance-protocol-644.json')
pubreview = read(O/'native-text-scan-public-inspection-report-644.json')
counts = read(O/'native-text-scan-broad-checks-644.json')
decision = read(O/'native-text-scan-full43-643/review.json')
direct = read(O/'native-text-scan-direct-tests-644.json')
assert direct['status'] == 'passed' and direct['tests'] == 100
assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
assert direct['test_names'] == protocol['expected_direct_names']
assert len(set(direct['test_names'])) == 100
for stem in ('native-text-scan-direct-644', 'native-text-scan-public-644',
             'native-text-scan-modular-644'):
    receipt = read(O/(stem+'.json'))
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(O/(stem+'.log')) == receipt['log_sha256']
assert pubreview['status'] == 'passed' and pubreview['cases'] == 4827 and pubreview['families'] == 36
assert counts['status'] == 'passed' and all(g['counts']['failed'] == 0 for g in counts['groups'])
assert decision['status'] == 'passed_integrity' and decision['decision'] == 'accept_material_batch'
assert decision['material_gain_passed'] is True and decision['both_paired_totals_improved']
assert Decimal(decision['observed_gain_percent']) > Decimal('3')
for item in protocol['helpers'] + [protocol[k] for k in ('source','artifacts','checks','gate_summary','prior_protocol','baseline','contract')]:
    assert a.identity(item['path']) == item

members = Members()
aliases, exclusions, helpers = {}, [], []
excluded_paths = set()
def add(path, name, role, digest=None):
    path = Path(path)
    root = R if path.is_relative_to(R) else O if path.is_relative_to(O) else path.parent
    item = members.add(path, name, root.name, root, role, digest)
    if item.name != name:
        aliases[name] = item.name
    return item

def bound_item(item, prefix, role):
    current = a.identity(item['path'])
    assert all(current[k] == v for k,v in item.items() if k in current), item['path']
    path = Path(item['path']).resolve()
    relative = ('repo/'+path.relative_to(R).as_posix() if path.is_relative_to(R)
                else 'local/'+path.relative_to(O).as_posix() if path.is_relative_to(O)
                else 'external/'+path.as_posix().lstrip('/'))
    return add(path, prefix+'/'+relative, role, item['sha256'])

def exclude(item, reason):
    if item['path'] not in excluded_paths:
        excluded_paths.add(item['path'])
        exclusions.append(dict(original_absolute_path=item['path'], byte_count=item['bytes'],
                               sha256=item['sha256'], reason=reason))

for path, name in [
    (O/'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json','predeclared-reference/unary-predeclared-values.json'),
    (O/'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json','predeclared-reference/subquery-predeclared-results.json'),
    (O/'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json','declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'),
    (O/'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json','declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'),
    (Path(protocol['baseline']['path']),'baseline/summary.json'),
]:
    add(path, name, 'predeclared complete public reference')
for name, digest in frozen['source_sha256'].items():
    add(R/name, 'runtime-source/'+name, 'complete retained 642 selected source', digest)
add(a.SOURCE,'manifests/'+a.SOURCE.name,'frozen selected source hashes')
add(a.MANIFEST,'manifests/'+a.MANIFEST.name,'CLI and binding identity')
bound_item(protocol['contract'],'contracts','immutable PR acceptance contract')
add(R/'docs/rfcs/0044-resident-runtime-resource-ownership.md','contracts/resident-resource-ownership.md','governing ownership RFC')
members.tree(O/'native-text-scan-public-644','public','public',
             'all public values, envelopes and pressure fixtures', exclusions, omit_outputs=True)

ATTEMPTS = [
 ('638','native-mixed-key-screen-638',78,O/'native-mixed-key-design-638.md'),
 ('642','native-text-scan-screen-642',74,O/'native-text-scan-design-at-admission-644.md'),
 ('643','native-text-scan-full43-643',172,O/'native-text-scan-design-at-admission-644.md'),
]
cohorts = []
attempts = []
for number, folder, expected_calls, design_copy in ATTEMPTS:
    root = O/folder
    p, result, review = (read(root/name) for name in ('protocol.json','results.json','review.json'))
    assert review.get('calls',review.get('completed_calls')) == expected_calls
    assert result['lock_released']
    assert review['status'] == 'passed_integrity'
    # The original design path is mutable. Bind its preserved exact bytes.
    assert sha(design_copy) == p['design']['sha256']
    add(design_copy,'experiments/'+folder+'/design.md','immutable original prospective contract',p['design']['sha256'])
    members.tree(root,'experiments/'+folder,'experiment','frozen design, source patch and original decision',exclusions)
    for item in [p['candidate_source'],p['decision_plan'],p['queries'],p['reference']]:
        bound_item(item,'experiment-inputs','original experiment input identity')
    for item in p['helpers']:
        bound_item(item,'experiment-helpers','hash-bound helper used by the original protocol')
        if Path(item['path']).suffix == '.py':
            helpers.append(Path(item['path']))
    for role in p['identities'].values():
        for key, item in role.items():
            if key == 'binary':
                exclude(item,'comparison executable omitted; source, patch and build evidence retained')
            else:
                bound_item(item,'experiment-builds','original exact source/build identity')
    input_item = p.get('input_identity', p['input'])
    assert isinstance(input_item,dict)
    exclude(input_item,'resident input omitted; original full hash and generation retained')
    expected = 0
    for position,c in enumerate(result['cohorts'],1):
        bound_item(c['summary'],f'paired-identities/{number}/{position}','completed cohort summary')
        runroot = Path(c['summary']['path']).parent
        summary = read(runroot/'summary.json')
        assert c['returncode'] == 0
        n = len(c['query_ids'])*c['pairs']*2
        assert len(summary['records']) == n
        expected += n
        prefix = f'paired/{number}/{position}'
        members.tree(runroot,prefix,'paired','all original query archives, timings and host observations',exclusions)
        for path,digest in summary['harness_sha256'].items():
            add(path,'paired-harness/'+Path(path).name,'original paired harness',digest)
            if Path(path).suffix == '.py':
                helpers.append(Path(path))
        cohorts.append(dict(attempt=number,cohort=c,protocol=p,review=review,
                            summary_path=runroot/'summary.json',calls=n))
    assert expected == expected_calls
    attempts.append(dict(attempt=number,calls=expected_calls,decision=review['decision'],
                         original_review=a.identity(root/'review.json'),
                         original_design_sha256=p['design']['sha256']))
# Profile samples are diagnostic evidence, separate from the 324 paired calls.
profile = O/'hotspot-profiles-637'
members.tree(profile,'attribution','attribution','all twelve diagnostic profiles; no timing credit',exclusions)
profile_summary=read(profile/'summary.json')
profile_parameters=read(O/'hotspot-profiles-637-parameters.json')
assert profile_summary['status']=='passed' and profile_summary['lock_released']
assert profile_summary['purpose']=='diagnostic_sampling_not_benchmark_timing'
assert profile_summary['query_order']==[29,19,23,34,35,17,28,33,10,16,14,32]
assert profile_summary['source_differences_from_accepted']==[]
assert len(profile_summary['records'])==12
for key in ('helper','launcher','effective_program','historical_comparison','historical_summary'):
    bound_item(profile_parameters[key],'attribution-inputs','original attribution source or reference')
    if Path(profile_parameters[key]['path']).suffix=='.py':helpers.append(Path(profile_parameters[key]['path']))
assert profile_parameters['effective_program']['sha256']==profile_summary['helper_sha256']
for item in profile_parameters['source_proof']:
    bound_item(item,'attribution-inputs','control source bridge and merge identity')
for row in profile_summary['records']:
    assert row['passed'] and row['returncode']==row['sample_returncode']==0
    assert row['native_child_absent'] and row['timing_supervisor_reaped'] and row['sampler_reaped']
    for item in row['files']:assert a.identity(item['path'])==item
for key in ('baseline_summary','artifact_manifest'):
    digest_key='baseline_sha256' if key=='baseline_summary' else key+'_sha256'
    path=Path(profile_summary[key])
    add(path,'attribution-inputs/'+path.name,'original attribution baseline and build identity',profile_summary[digest_key])
for failed in sorted(O.glob('native-text-scan-evidence-645-preflight-failure-*')):
    members.tree(failed,'packaging-corrections/'+failed.name,'packaging-corrections',
                 'preserved packaging failure; measurements unchanged',exclusions)
prefixes = ('native-mixed-key','native-shared-speed','native-text-scan','hotspot-profiles-637',
 'native-release-source-textscan','native-release-artifacts-textscan',
 'native-final-source-gate-results-textscan','native-final-feature-gate-results-textscan')
for path in sorted(O.iterdir()):
    if path.is_file() and path.name.startswith(prefixes) and path.suffix in ('.json','.log','.py','.md','.patch'):
        if path.name.startswith('native-text-scan-archive-645'):
            continue
        add(path,'receipts/'+path.name,'all original attempts, failures, tests, builds and acceptance evidence')
for name in ('stream-subquery-corrections-509/initial-failures.json','stream-subquery-corrections-509/corrections.json',
             'stream-dynamic-subquery-direct-new-tests-517.json','dynamic-subquery-direct-diagnosis-517.json'):
    add(O/name,'legacy-public-references/'+Path(name).name,'unchanged public reference provenance')
for item in (protocol['prior_protocol'],protocol['baseline']):
    bound_item(item,'prior-identities','retained public reference identity')
mod = O/'fresh-timed-uat-461'
modreport = read(mod/'native-text-scan-matrix-644-report.json')
assert modreport['status']=='passed' and len(modreport['cohorts'])==18
assert modreport['records']==1408 and modreport['native_records']==704
members.tree(mod/'native-text-scan-matrix-644','modular','modular',
             'all 18 complete native and independent reference workflow cohorts',exclusions)
for path in sorted(mod.glob('native-text-scan-matrix-644-*')):
    if path.is_file():
        add(path,'modular-receipts/'+path.name,'complete format/workflow acceptance')
helpers += [Path(i['path']) for i in protocol['helpers'] if Path(i['path']).suffix in ('.py','.sh')]
helpers += [Path(__file__), mod/'run_modular_acceptance.py',O/'verify_stream_destination_integrated_sources_482.py',
 O/'prepare_text_scan_packet_645.py',O/'package_shared_execution_625.py',
 O/'inventory_text_scan_tests_645.py',O/'run_text_scan_final_docs_645.py',
 O/'run_zstd_metadata_acceptance_533.py',O/'package_selection_acceptance_409.py',O/'metadata_public_verifier_534.py',
 O/'verify_stream_unary_packet_497.py',O/'run_guarded.py',R/'scripts/build_native_python.py',
 Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
 Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]
roots = (O,R/'scripts',R/'python/src',Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930'))
visited=set()
while helpers:
    path=helpers.pop().resolve()
    if path in visited: continue
    visited.add(path)
    prefix='local/'+str(path.relative_to(O)) if path.is_relative_to(O) else 'repo/'+str(path.relative_to(R)) if path.is_relative_to(R) else 'external/'+path.parent.name+'/'+path.name
    add(path,'dependencies/'+prefix,'maintained helper and local import closure')
    if path.suffix != '.py': continue
    for node in ast.walk(ast.parse(path.read_text())):
        modules=[x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module and node.level==0 else []
        for module in modules:
            for root in roots:
                candidate=root.joinpath(*module.split('.')).with_suffix('.py')
                if not candidate.is_file(): candidate=root.joinpath(*module.split('.'))/'__init__.py'
                if candidate.is_file(): helpers.append(candidate);break
for item in (build['cli'],build['binding']):
    exclude(item,'frozen executable omitted; full current source/build identity retained')
ordered=sorted(members.paths.values(),key=lambda v:v.name)
raw_bytes=sum(v.size for v in ordered)
assert raw_bytes < 768*MIB
assert {v.name.removeprefix('runtime-source/') for v in ordered if v.name.startswith('runtime-source/')} == set(frozen['source_sha256'])
storage=check_budgets(O,LOCAL,O/'logs',min_free_bytes=12*GIB,reserve_bytes=raw_bytes+64*MIB,
                      max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
save(LOCAL/'selection.json',dict(status='selected',members=[dict(path=str(v.path),archive_path=v.name,bytes=v.size,sha256=v.digest,roles=v.roles) for v in ordered],
                               aliases=aliases,exclusions=exclusions,raw_bytes=raw_bytes))
print(json.dumps(dict(stage='selected',members=len(ordered),raw_bytes=raw_bytes,complete_paired_calls=sum(x['calls'] for x in cohorts))),flush=True)
partitions=[];current=[];size=0
part_bytes=80*MIB
for item in ordered:
    assert item.size <=part_bytes
    if current and size+item.size>part_bytes: partitions.append(current);current=[];size=0
    current.append(item);size+=item.size
if current:partitions.append(current)
archives={};archive_for={};seen=set();portable={}
keep=('paired/','paired-identities/','experiment-inputs/','experiments/','public/','predeclared-reference/','declarations-521/','baseline/')
for number,group in enumerate(partitions,1):
    name=STEM+('.tar.xz' if number==1 else f'.part-{number}.tar.xz')
    path=LOCAL/name
    with path.open('xb') as raw:
        with tarfile.open(fileobj=raw,mode='w:xz',preset=6,format=tarfile.PAX_FORMAT) as tar:
            for item in group:
                verify(item.path,item.digest,item.size)
                info=tarfile.TarInfo(item.name);info.size=item.size;info.mode=0o644;info.mtime=0
                with item.path.open('rb') as stream:tar.addfile(info,stream)
                archive_for[item.name]=name
    with tarfile.open(path,'r|xz') as tar:
        for entry in tar:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item=members.paths[members.names[entry.name]]
            assert archive_for[entry.name]==name
            with tar.extractfile(entry) as stream:
                if entry.name.startswith(keep):
                    data=stream.read()
                    assert (len(data),hashlib.sha256(data).hexdigest())==(item.size,item.digest)
                    portable[entry.name]=data
                else:assert sha_stream(stream)==(item.size,item.digest)
            seen.add(entry.name)
    archives[name]=dict(file=name,bytes=path.stat().st_size,sha256=sha(path),
                        raw_bytes=sum(v.size for v in group),member_count=len(group))
    assert path.stat().st_size<100*MIB
    print(json.dumps(dict(stage='archive_verified',part=number,members=len(group))),flush=True)
assert seen==set(members.names)
for alias,target in aliases.items():
    if target in portable:portable[alias]=portable[target]
pub=verify_public(portable,(O/'native-text-scan-public-644.log').read_bytes(),protocol)
assert pub['pressure_rows']==pubreview['pressure_rows']
def packed_path(path):
    return portable[members.paths[Path(path).resolve()].name]
readback=[];full43={}
policy_keys=('execution_resource_admitted_max_parallelism','execution_resource_admission_policy',
             'local_primitive_physical_policy_route_family','local_primitive_resource_scan_concurrency_per_worker',
             'local_primitive_resource_memory_budget_bytes')
for c in cohorts:
    summary=strict_json(packed_path(c['summary_path']))
    cohort,p=c['cohort'],c['protocol']
    assert summary['completed_identity_check'] and summary['complete_result_validation']
    assert summary['reference_packet_identity_verified'] and summary['scores']['complete']
    assert summary['scores']['timing_available'] and summary['scores']['timing_metric']=='engine_execution_seconds'
    assert summary['source_generation']==p['input_generation']
    ref=strict_json(packed_path(p['reference']['path']))
    expected={row['query_id']:row['values'] for row in ref['records']}
    keys=[(q,n,role) for q in cohort['query_ids'] for n in range(1,cohort['pairs']+1) for role in role_order(q,n)]
    assert [(r['query'],r['run'],r['role']) for r in summary['records']]==keys
    records={(r['query'],r['run'],r['role']):r for r in summary['records']}
    assert len(records)==c['calls']
    raw={};count=0
    for archive in summary['archives']:
        payload=packed_path(archive['path'])
        assert hashlib.sha256(payload).hexdigest()==archive['sha256']
        with tarfile.open(fileobj=io.BytesIO(payload),mode='r:xz') as tar:
            assert tar.getnames()==[m['name'] for m in archive['members']]
            for meta in archive['members']:
                safe_member(meta['name'])
                entry=tar.getmember(meta['name']);assert entry.isfile()
                value=tar.extractfile(entry).read()
                assert (len(value),hashlib.sha256(value).hexdigest())==(meta['bytes'],meta['sha256'])
                assert meta['name'] not in raw
                raw[meta['name']]=value;count+=1
    nanos={};resources={};rows=0
    for key,r in records.items():
        q,n,role=key;name=f'q{q:02d}_run{n}_{role}'
        assert r['passed'] and r['returncode']==0 and not r['guard_failures']
        assert r['validation']=='complete_values' and r['pair_position']==role_order(q,n).index(role)+1
        envelope=strict_json(raw[name+'.stdout.json']);fields=report_fields(envelope)
        values=full_result(envelope,fields)
        assert equivalent(values,expected[q]) and canonical_hash(values)==r['result_sha256']
        assert [fields['result_schema_format'],strict_json(fields['result_schema_json'])]==p['expected_schemas'][str(q)]
        assert fields['fallback_attempted']==fields['external_engine_invoked']=='false'
        assert any(v['kind']=='native_io_certificate' and v['status']=='available' for v in envelope['certificates'])
        value=int(fields['native_query_execution_nanos'])
        assert value/1e9==r['engine_execution_seconds'] and fields['native_query_timing_clock']=='monotonic_wall_not_cpu'
        phases=query_phase_timings(fields,r['seconds'])
        assert phases['engine_execution_seconds']==r['engine_execution_seconds']
        timing=strict_json(raw[name+'.timing.json'])
        assert timing['returncode']==0 and timing['seconds']==r['seconds'] and timing['peak_rss_bytes']==r['native_peak_rss_bytes']
        assert int(raw[name+'.pid'])>0 and not raw[name+'.stderr.txt']
        assert fields['execution_resource_declared_memory_gb']=='24'
        assert fields['execution_resource_declared_max_parallelism']==str(cohort['lanes'])
        resources[key]={k:fields[k] for k in policy_keys if k in fields}
        assert all(k in resources[key] for k in ('execution_resource_admitted_max_parallelism','execution_resource_admission_policy'))
        nanos[key]=value;rows+=len(values)
    for q in cohort['query_ids']:
        assert len({json.dumps(v,sort_keys=True) for k,v in resources.items() if k[0]==q})==1
    csvrows=list(csv.DictReader(io.StringIO(packed_path(summary['timing_csv']).decode())))
    assert len(csvrows)==c['calls'];seen_csv=set()
    for row in csvrows:
        key=(int(row['query']),int(row['run']),row['role'])
        assert key in records and key not in seen_csv;seen_csv.add(key)
        for field,value in row.items():
            assert value==('' if records[key][field] is None else str(records[key][field]))
        assert row['query_statement']==summary['queries'][str(key[0])]
    assert seen_csv==set(records)
    report=dict(attempt=c['attempt'],calls=c['calls'],result_rows=rows,archive_members=count,
                summary=a.identity(c['summary_path']),complete_outputs_schemas_clocks_and_csv_reopened=True)
    readback.append(report)
    if c['attempt'] == '643':
        means={role:Decimal(sum(v for k,v in nanos.items() if k[2]==role))/Decimal(2*10**9) for role in ('control','candidate')}
        gain=(means['control']-means['candidate'])/means['control']*100
        review=c['review']
        assert all(v==Decimal(review['total_engine_means'][role]) for role,v in means.items())
        assert gain==Decimal(review['observed_gain_percent']) and gain>3
        flags=[]
        for q in range(1,44):
            qm={role:Decimal(sum(nanos[(q,n,role)] for n in (1,2)))/Decimal(2*10**9) for role in ('control','candidate')}
            if qm['candidate']-qm['control']>max(qm['control']/10,Decimal('.15')) and all(nanos[(q,n,'candidate')]>nanos[(q,n,'control')] for n in (1,2)):
                flags.append(q)
        assert flags==review['material_regression_queries']==[]
        pairs={role:{str(n):str(Decimal(sum(v for k,v in nanos.items() if k[1]==n and k[2]==role))/Decimal(10**9)) for n in (1,2)} for role in ('control','candidate')}
        assert all(Decimal(pairs[role][str(n)])==Decimal(review['paired_full43_engine_totals'][role][str(n)]) for role in pairs for n in (1,2))
        assert all(Decimal(pairs['candidate'][str(n)])<Decimal(pairs['control'][str(n)]) for n in (1,2))
        assert review['material_gain_passed'] is True and review['decision']=='accept_material_batch'
        full43[c['attempt']]=dict(mean_totals_engine_seconds={k:str(v) for k,v in means.items()},
              paired_totals_engine_seconds=pairs,observed_gain_percent=str(gain),
              prospective_greater_than_3_percent_gate_passed=True,material_query_regressions=flags)
assert sum(x['calls'] for x in readback)==324
assert Decimal(full43['643']['observed_gain_percent'])==Decimal(decision['observed_gain_percent'])
for item in ordered:verify(item.path,item.digest,item.size)
assert a.unchanged()==frozen and a.load()==build
acceptance=dict(complete_paired_calls=324,attempts=3,paired_cohorts=len(cohorts),
 workspace_test_executions=counts['groups'][0]['counts']['passed'],workspace_ignored=counts['groups'][0]['counts']['ignored'],
 native_test_executions=counts['groups'][1]['counts']['passed'],native_manual_exclusions=counts['groups'][1]['counts']['ignored'],
 direct_methods=100,direct_skips=0,public_cases=4827,public_families=36,
 modular_cohorts=18,native_workflows=704,independent_oracle_records=704)
limitations=[
 'The greater-than-3% whole-workload gate was frozen prospectively and passes; the mixed-key experiment remains rejected under its original component gates.',
 'The two-sample matched comparison has uncontrolled OS cache state and does not establish a single-pass result or external-engine superiority.',
 'Retained native values and paired schemas are regression references; the format/workflow suite uses a separate pandas oracle only.',
 'Twelve profile samples and the decoder-invocation fixture receive diagnostic attribution only, without benchmark timing credit.',
 'Declared memory admission is not a whole-process RSS ceiling.',
 'Selected source identities match measured build642; later docs/site/evidence and the final Git commit are bridged separately.',
 'Large datasets, executable binaries and public output payloads are excluded with exact identities; complete values/envelopes and reproduction sources remain.',
 'Installed-wheel lanes, final-head CI/review and hosted deployment are recorded separately.',
]
manifest=dict(schema_version='shardloom.native_text_scan_reuse_evidence.v1',
 status='passed_local_evidence_packaged',base_commit=frozen['head'],uncommitted_source_changes=True,
 source_files=2415,source_manifest=a.identity(a.SOURCE),artifact_manifest=a.identity(a.MANIFEST),
 performance_decision=a.identity(O/'native-text-scan-full43-643/review.json'),
 frozen_contract_copy=protocol['contract'],
 members=[dict(path=str(v.path),archive_path=v.name,archive_file=archive_for[v.name],bytes=v.size,sha256=v.digest,roles=v.roles) for v in ordered],
 member_count=len(ordered),raw_bytes=raw_bytes,archives=archives,archive_aliases=aliases,
 all_members_reopened=True,max_raw_bytes_per_archive=part_bytes,max_archive_bytes=100*MIB,
 exclusions=exclusions,acceptance=acceptance,attempts=attempts,paired_readback=readback,
 whole_workload_readback=full43,public_reopened=pub,
 modular_acceptance=a.identity(mod/'native-text-scan-matrix-644-report.json'),
 storage=storage,source_identity_preserved=True,limitations=limitations,
 publication_attempted=False,performance_claim='bounded matched complete-workload engine comparison passing the prospective greater-than-3% gate')
raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
packed=lzma.compress(raw,preset=6);assert lzma.decompress(packed)==raw
mp=LOCAL/(STEM+'.manifest.json.xz');mp.open('xb').write(packed)
keys=('schema_version','status','base_commit','uncommitted_source_changes','source_files','source_manifest',
 'artifact_manifest','performance_decision','frozen_contract_copy','member_count','raw_bytes','archives',
 'all_members_reopened','max_raw_bytes_per_archive','acceptance','attempts','whole_workload_readback',
 'public_reopened','modular_acceptance','source_identity_preserved','limitations','publication_attempted','performance_claim')
index={k:manifest[k] for k in keys}
index['manifest']=dict(file=mp.name,bytes=len(packed),sha256=sha(mp),raw_sha256=hashlib.sha256(raw).hexdigest())
index['hosted_integration_complete']=False
for path in [*(LOCAL/name for name in archives),mp]:
    target=DEST/path.name;assert not target.exists()
    target.open('xb').write(path.read_bytes());assert sha(target)==sha(path)
save(DEST/(STEM+'.json'),index)
save(LOCAL/'verification.json',dict(status='all_members_reopened',member_count=len(ordered),archives=archives,
 paired_readback=readback,whole_workload_readback=full43,public_reopened=pub,
 manifest=a.identity(mp),index=a.identity(DEST/(STEM+'.json'))))
print(json.dumps(dict(status='passed_local_evidence_packaged',members=len(ordered),archives=len(archives),
 raw_bytes=raw_bytes,archive_bytes=sum(x['bytes'] for x in archives.values()),complete_paired_calls=324)),flush=True)

