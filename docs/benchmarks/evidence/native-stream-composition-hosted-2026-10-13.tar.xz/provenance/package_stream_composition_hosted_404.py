"""Bind finite streaming acceptance to merged source and hosted observations."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

HEAD = 'c1a21e62cae38636b56d28167ef743d17fe73620'
MERGED = '5b5cd6a7cb3c88d20046079c46900d9b323b1274'
SYNTHETIC = '090e74f58c3f14ae7b80be67a4d98b2bfa55c002'
STEM = 'native-stream-composition-hosted-2026-10-13'
EVIDENCE = ROOT / 'docs/benchmarks/evidence'
DOC_OUTPUT = OUT / 'stream-composition-closeout-docs-404'
DOCS = [
    'docs/architecture/native-stream-input-composition-2026-10-13.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/phased-execution-completed-ledger.md',
    'docs/architecture/native-local-completion-scope-2026-10-07.md',
    'docs/benchmarks/native-stream-input-composition-2026-10-13.md',
    'docs/release/v1-inclusion-scope-matrix.md',
]


def read(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    current = read(OUT / 'operator-recovery-source-402-2.json')['source_sha256']
    assert sources() == current and len(current) == 2240
    selected = read(OUT / 'stream-composition-398-source.json')['source_sha256']
    assert len(selected) == 2236
    trees = {commit: git('rev-parse', commit + '^{tree}').decode().strip()
             for commit in [HEAD, MERGED, SYNTHETIC]}
    assert len(set(trees.values())) == 1
    verified_bytes = 0
    with (OUT / 'stream-composition-merged-bind-404.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        try:
            for name, expected in sorted(selected.items()):
                assert '\n' not in name and '\r' not in name
                child.stdin.write((MERGED + ':' + name + '\n').encode())
                child.stdin.flush()
                header = child.stdout.readline().decode().strip().split()
                assert len(header) == 3 and header[1] == 'blob', (name, header)
                remaining = int(header[2])
                verified_bytes += remaining
                result = hashlib.sha256()
                while remaining:
                    data = child.stdout.read(min(1 << 20, remaining))
                    assert data
                    result.update(data)
                    remaining -= len(data)
                assert child.stdout.read(1) == b'\n' and result.hexdigest() == expected, name
            child.stdin.close()
            assert child.wait(timeout=30) == 0
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=30)
    merged_pr = read(OUT / 'stream-composition-merged-pr-404.json')
    assert merged_pr['merged'] and merged_pr['head_sha'] == HEAD
    assert merged_pr['merge_commit_sha'] == MERGED
    ci = read(OUT / 'stream-composition-ci-403/checks.json')
    assert ci['total_count'] == len(ci['check_runs']) == 44
    assert all(row['status'] == 'completed' and row['conclusion'] == 'success'
               and row['head_sha'] == HEAD for row in ci['check_runs'])
    premerge = read(OUT / 'stream-composition-ci-403/summary.json')
    assert premerge['status'] == 'passed' and premerge['review_completed']
    assert not read(OUT / 'stream-composition-ci-403/reviews.json')
    assert not read(OUT / 'stream-composition-ci-403/inline_comments.json')
    comments = read(OUT / 'stream-composition-ci-403/comments.json')
    review = [row for row in comments if '<!-- codex-pull-request-review-summary -->' in row['body']]
    assert len(review) == 1 and '**Completed**' in review[0]['body'] and '`c1a21e6`' in review[0]['body']
    production = read(OUT / 'stream-composition-production-403/report.json')
    assert production['status'] == 'passed' and production['merged_commit'] == MERGED
    assert production['production_deployment']['head_sha'] == MERGED
    assert production['production_deployment']['conclusion'] == 'success'
    for directory, revision in [('stream-composition-hosted-preview-401', HEAD),
                                ('stream-composition-production-403', MERGED)]:
        report = read(OUT / directory / 'report.json')
        assert report['status'] == 'passed' and len(report['responses']) == 4
        for row in report['responses']:
            data = (OUT / directory / row['response']).read_bytes()
            expected = git('show', revision + ':' + row['source'])
            assert len(expected) == row['expected_bytes'] and digest(expected) == row['expected_sha256']
            assert len(data) == row['observed_bytes'] and digest(data) == row['observed_sha256']
            assert row['source_preserved'] and row['http_status'] == 200
            if row['raw_byte_identical']:
                assert expected == data
            else:
                assert directory.endswith('403') and row['insertion_bytes'] == 1305
                prefix = 0
                while prefix < len(expected) and expected[prefix] == data[prefix]:
                    prefix += 1
                assert data[:prefix] + data[prefix + 1305:] == expected
                assert digest(data[prefix:prefix + 1305]) == row['insertion_sha256']
    browser = read(OUT / 'stream-composition-production-browser-404/observations.json')
    preview_browser = read(OUT / 'stream-composition-hosted-browser-401/observations.json')
    assert browser['status'] == preview_browser['status'] == 'passed'
    assert browser['merge_commit'] == MERGED and browser['console'] == []
    assert browser['search']['result_count'] == 5
    wheels = read(OUT / 'stream-composition-wheel-hosted-402/index.json')
    assert len(wheels['jobs']) == 3
    for job in wheels['jobs']:
        row = job['installed_native_integration']
        assert row['reported_tests'] == 80
        assert row['reported_errors'] == row['reported_failures'] == row['reported_skipped'] == 0
        assert job['proof_status'] == 'passed' and job['isolated_extension_load']['step_returncode'] == 0
        log = Path(job['full_log']['path'])
        assert sha(log) == job['full_log']['sha256'] and log.stat().st_size == job['full_log']['bytes']
        assert any(check['id'] == job['job_id'] for check in ci['check_runs'])
    proof_source = wheels['proof_source_code']
    assert Path(proof_source['saved_copy']).read_bytes() == git('show', HEAD + ':' + proof_source['path'])
    assert sha(Path(proof_source['saved_copy'])) == proof_source['sha256']
    payloads = {}

    def add(name, path):
        assert name not in payloads and path.is_file() and not path.is_symlink()
        payloads[name] = path.read_bytes()

    directories = ['stream-composition-ci-403', 'stream-composition-hosted-preview-401',
                   'stream-composition-hosted-browser-401', 'stream-composition-production-403',
                   'stream-composition-production-browser-404', 'stream-composition-wheel-hosted-402']
    for directory in directories:
        for path in sorted((OUT / directory).iterdir()):
            add(directory + '/' + path.name, path)
    for name in ['stream-composition-merged-pr-404.json', 'stream-composition-merged-bind-404.stderr.log',
                 'stream-composition-398-source.json', 'stream-composition-commit-bind-400.json',
                 'capture_stream_composition_ci_403.py', 'check_stream_composition_preview_401.py',
                 'check_stream_composition_production_403.py', Path(__file__).name]:
        add('provenance/' + name, OUT / name)
    for name in ['native-stream-composition-premerge-403', 'native-stream-composition-production-403',
                 'native-stream-composition-hosted-preview-401', 'native-stream-composition-commit-bind-400']:
        receipt = read(OUT / (name + '.json'))
        assert receipt['status'] == 'passed' and receipt['process_group_drained']
        assert sha(OUT / (name + '.log')) == receipt['log_sha256']
        for suffix in ['.json', '.log']:
            add('receipts/' + name + suffix, OUT / (name + suffix))
    binding = dict(status='passed', trees=trees, selected_files_verified=len(selected),
                   selected_bytes_verified=verified_bytes, source_manifest_sha256=sha(OUT / 'stream-composition-398-source.json'),
                   method='All selected merged Git blobs SHA-256 checked against accepted source manifest.',
                   active_recovery_sources_unchanged=True)
    payloads['provenance/merged-source-binding.json'] = (json.dumps(binding, indent=2) + '\n').encode()
    index = dict(schema_version='shardloom.stream_composition_hosted.v1', status='completed_finite_unit',
                 observed_at=datetime.now(timezone.utc).isoformat(), pull_request=1548,
                 reviewed_head=HEAD, merged_commit=MERGED, source_binding=binding,
                 hosted_checks=44, automated_review='completed_without_findings',
                 wheels=dict(jobs=3, native_tests_reported_per_job=80, failures=0, errors=0, skips=0,
                             evidence='stream-composition-wheel-hosted-402/index.json',
                             synthetic_merge_tree_equivalence_proven_by_this_packet=True),
                 production_deployment=production['production_deployment'],
                 documentation=dict(preview_source='four_responses_byte_identical',
                                    production_source='three_HTML_responses_with_1305_byte_insertion_each_and_identical_search_entry',
                                    preview_browser='passed', production_browser='passed',
                                    production_browser_record='stream-composition-production-browser-404/observations.json'),
                 limitations=['Native integration counts are reported by each runner; individual native methods are not logged.',
                              'Wheel artifacts were not downloaded; uninstall was not tested in these jobs.',
                              'Historical wheel-only index retains its then-unproven tree relationship; this packet proves it directly.',
                              'Production HTML has recorded Cloudflare insertions, so raw HTML identity is not claimed.',
                              'Initial stale-scaled mobile capture is historical; final mobile screenshot is accepted.',
                              'No new runtime timing, package release, process-RSS limit or whole PERF/CG completion claim.'])
    index_path = EVIDENCE / (STEM + '.json')
    save(index_path, index)
    DOC_OUTPUT.mkdir()
    checks = []
    commands = [
        ('user-surface-reference', [sys.executable, '-B', 'scripts/check_user_surface_reference.py']),
        ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py', '--output', str(DOC_OUTPUT / 'public-status.json')]),
        ('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py']),
        ('contribution-governance', [sys.executable, '-B', 'scripts/check_contribution_governance.py', '--output', str(DOC_OUTPUT / 'contribution-governance.json')]),
        ('diff-check', ['git', 'diff', '--check']),
    ]
    for name, command in commands:
        log = DOC_OUTPUT / (name + '.log')
        started = time.monotonic()
        with log.open('xb') as output:
            result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=180)
        check = dict(name=name, command=command, returncode=result.returncode, seconds=time.monotonic() - started,
                     log_sha256=sha(log), log=log.name)
        checks.append(check)
        print(json.dumps(check), flush=True)
        result.check_returncode()
    doc_record = dict(status='passed', checks=checks, source_files={name: sha(ROOT / name) for name in DOCS},
                      scope='Metadata/closeout text only; deployed website and accepted runtime sources unchanged.')
    save(DOC_OUTPUT / 'summary.json', doc_record)
    for path in sorted(DOC_OUTPUT.iterdir()):
        add('closeout-documentation/' + path.name, path)
    for name in DOCS:
        add('reviewed-docs/' + name, ROOT / name)
    manifest = dict(schema_version='shardloom.stream_composition_hosted_archive.v1',
                    members={name: dict(bytes=len(data), sha256=digest(data)) for name, data in sorted(payloads.items())})
    archive = OUT / (STEM + '.tar.xz')
    with archive.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as tar:
            for name, data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(data))
    observed = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for item in tar:
            assert item.isfile() and item.name in payloads and item.name not in observed
            assert tar.extractfile(item).read() == payloads[item.name]
            observed.add(item.name)
    assert observed == payloads.keys()
    copied = EVIDENCE / archive.name
    with copied.open('xb') as output:
        output.write(archive.read_bytes())
    assert sha(copied) == sha(archive)
    manifest_path = EVIDENCE / (STEM + '.manifest.json')
    save(manifest_path, manifest)
    assert read(manifest_path) == manifest
    index['archive'] = dict(path=copied.name, bytes=copied.stat().st_size, sha256=sha(copied),
                            members=len(payloads), uncompressed_bytes=sum(len(data) for data in payloads.values()),
                            all_members_verified=True)
    index['manifest'] = dict(path=manifest_path.name, sha256=sha(manifest_path))
    index['closeout_documentation'] = dict(gates=len(checks), status='passed', evidence='closeout-documentation/summary.json')
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    local_index_path = EVIDENCE / 'native-stream-input-composition-2026-10-13.json'
    local_index = read(local_index_path)
    local_index['status'] = 'completed_finite_unit'
    local_index['hosted_integration'] = dict(path=index_path.name, sha256=sha(index_path), pull_request=1548, merged_commit=MERGED)
    local_index['limitations'][0] = 'Local runtime acceptance is macOS arm64; the linked hosted receipt records finite Linux/macOS wheel and CI evidence.'
    local_index_path.write_text(json.dumps(local_index, indent=2) + '\n')
    assert sources() == current
    assert doc_record['source_files'] == {name: sha(ROOT / name) for name in DOCS}
    print(json.dumps(index, indent=2), flush=True)


if __name__ == '__main__':
    main()
