"""Bind the production deployment and four served responses to the merged tree."""
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import urllib.request

from freeze_native_release_298 import ROOT, OUT, save, sources

MERGED = '5b5cd6a7cb3c88d20046079c46900d9b323b1274'
DEST = OUT / 'stream-composition-production-403'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    frozen = json.loads((OUT / 'operator-recovery-source-402-2.json').read_text())
    assert sources() == frozen['source_sha256']
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
        f'repos/depsilon/shardloom/commits/{MERGED}/check-runs?per_page=100'], timeout=60)
    checks = json.loads(raw)
    workers = [row for row in checks['check_runs'] if row['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == MERGED and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    DEST.mkdir()
    with (DEST / 'merged-checks.json').open('xb') as output:
        output.write(raw)
    routes = [f'field-guide/{name}/index.html' for name in ('python-surface', 'runtime-and-io', 'limitations')]
    routes.append('pagefind/pagefind-entry.json')
    responses = []
    for route in routes:
        expected = subprocess.check_output(['git', 'show', MERGED + ':website/' + route], cwd=ROOT)
        url = 'https://shardloom.io/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        with (DEST / filename).open('xb') as output:
            output.write(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        responses.append(dict(source='website/' + route, response=filename, url=url, final_url=final_url,
            http_status=200, expected_bytes=len(expected), expected_sha256=digest(expected),
            observed_bytes=len(actual), observed_sha256=digest(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), insertion_bytes=len(insertion),
            insertion_sha256=digest(insertion) if insertion else None))
    report = dict(schema_version='shardloom.stream_composition_production_source.v1',
        status='passed' if all(row['source_preserved'] for row in responses) else 'failed',
        observed_at=datetime.now(timezone.utc).isoformat(), merged_commit=MERGED,
        production_deployment={key:worker[key] for key in ['id', 'head_sha', 'status', 'conclusion', 'details_url', 'completed_at']},
        responses=responses, active_recovery_source_identity_preserved=True,
        scope='Production deployment and served source/search identity; browser behavior is separately checked.')
    save(DEST / 'report.json', report)
    assert sources() == frozen['source_sha256'] and report['status'] == 'passed'
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
