"""Compare deployed composition guides and search entry with accepted source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

from freeze_native_release_298 import ROOT, OUT, save, sources

HEAD = 'c1a21e62cae38636b56d28167ef743d17fe73620'
ORIGIN = 'https://fdf094ce-shardloom.djheinrich.workers.dev'
VERSION = 'fdf094ce-d3c6-448a-9f40-001ab3789f57'
DESTINATION = OUT / 'stream-composition-hosted-preview-401'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    release = json.loads((OUT / 'stream-composition-398-release.json').read_text())
    assert sources() == release['source_sha256']
    DESTINATION.mkdir(exist_ok=False)
    records = []
    routes = [f'field-guide/{name}/index.html' for name in
              ('python-surface', 'runtime-and-io', 'limitations')]
    routes.append('pagefind/pagefind-entry.json')
    for route in routes:
        expected = (ROOT / 'website' / route).read_bytes()
        url = ORIGIN + '/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        with (DESTINATION / filename).open('xb') as stream:
            stream.write(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        records.append(dict(source='website/' + route, response=filename, url=url,
            final_url=final_url, http_status=200, expected_bytes=len(expected),
            expected_sha256=digest(expected), observed_bytes=len(actual),
            observed_sha256=digest(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), insertion_bytes=len(insertion),
            insertion_sha256=digest(insertion) if insertion else None))
    report = dict(schema_version='shardloom.stream_composition_served_source.v1',
        status='passed' if all(row['source_preserved'] for row in records) else 'failed',
        observed_at=datetime.now(timezone.utc).isoformat(), head=HEAD,
        origin=ORIGIN, deployment_version=VERSION, responses=records,
        source_files_verified=len(release['source_sha256']),
        scope='Served source and search entry identity; browser behavior and production integration are separate checks.')
    save(DESTINATION / 'report.json', report)
    assert sources() == release['source_sha256']
    print(json.dumps(report, indent=2), flush=True)
    assert report['status'] == 'passed'


if __name__ == '__main__':
    main()
