"""Preserve final read-only PR checks and source-tree identity before merge."""
from datetime import datetime, timezone
import json
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sources

HEAD = 'c1a21e62cae38636b56d28167ef743d17fe73620'
BASE = 'ed253d1ec74b724215f71f0b410123656e596696'
SYNTHETIC = '090e74f58c3f14ae7b80be67a4d98b2bfa55c002'
DEST = OUT / 'stream-composition-ci-403'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def main():
    frozen = json.loads((OUT / 'operator-recovery-source-402-2.json').read_text())
    assert sources() == frozen['source_sha256']
    DEST.mkdir()
    records = {}
    endpoints = dict(pr='pulls/1548', checks=f'commits/{HEAD}/check-runs?per_page=100',
                     statuses=f'commits/{HEAD}/status', reviews='pulls/1548/reviews?per_page=100',
                     inline_comments='pulls/1548/comments?per_page=100',
                     comments='issues/1548/comments?per_page=100')
    for name, endpoint in endpoints.items():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', 'repos/depsilon/shardloom/' + endpoint], timeout=60)
        with (DEST / (name + '.json')).open('xb') as output:
            output.write(raw)
        records[name] = json.loads(raw)
    pr = records['pr']
    assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
    assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
    assert pr['mergeable'] and pr['merge_commit_sha'] == SYNTHETIC
    checks = records['checks']
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert all(row['status'] == 'completed' and row['conclusion'] == 'success' and row['head_sha'] == HEAD for row in checks['check_runs'])
    assert all(row['state'] == 'success' for row in records['statuses']['statuses'])
    assert not records['reviews'] and not records['inline_comments']
    review = [row for row in records['comments'] if '<!-- codex-pull-request-review-summary -->' in row['body']]
    assert len(review) == 1 and '**Completed**' in review[0]['body'] and '`c1a21e6`' in review[0]['body']
    subprocess.run(['git', 'fetch', 'origin', 'refs/pull/1548/merge'], cwd=ROOT, check=True, timeout=120)
    assert git('rev-parse', 'FETCH_HEAD') == SYNTHETIC
    tree = git('rev-parse', HEAD + '^{tree}')
    assert git('rev-parse', SYNTHETIC + '^{tree}') == tree
    assert sources() == frozen['source_sha256']
    result = dict(schema_version='shardloom.stream_composition_premerge.v1', status='passed',
                  observed_at=datetime.now(timezone.utc).isoformat(), pull_request=1548,
                  head=HEAD, base=BASE, synthetic_merge=SYNTHETIC, tree=tree,
                  synthetic_merge_tree_identical=True, check_count=44, all_checks_passed=True,
                  review_completed=True, inline_findings=0, review_submissions=0,
                  raw_records=list(endpoints), active_recovery_source_unchanged=True)
    save(DEST / 'summary.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
