"""Validate current queue accounting and existing documentation/status contracts."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'closeout-checks-720'
OUT.mkdir(exist_ok=False)
checks = []


def run(name, command):
    path = OUT / f'{name}.log'
    with path.open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    checks.append({'name': name, 'command': [str(x) for x in command], 'returncode': result.returncode,
                   'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    print(json.dumps({'name': name, 'returncode': result.returncode}), flush=True)
    assert result.returncode == 0, name


try:
    plan = (ROOT / 'docs/architecture/phased-execution-plan.md').read_text()
    owners = re.findall(r'^- \[ \] `((?:PERF-\d+|NATIVE-ENCODED-EXCHANGE))`', plan, re.M)
    children = re.findall(r'^    - \[ \] `((?:PERF-\d+|NATIVE-ENCODED-EXCHANGE)\.[^`]+)`(.*)$', plan, re.M)
    conditional = [name for name, text in children if '**Conditional.**' in text]
    assert len(owners) == len(set(owners)) == 14
    assert len(children) == len({name for name, _ in children}) == 58
    assert len(conditional) == 21 and len(children) - len(conditional) == 37
    assert 'PERF-10.compact_selections' in {name for name, _ in children}
    assert 'PERF-10' in owners and 'PERF-03.codec_preparation' in {name for name, _ in children}
    ledger = (ROOT / 'docs/architecture/phased-execution-completed-ledger.md').read_text()
    assert '- [x] `PERF-10.compact_selections experiment`' in ledger
    for gate in range(1, 24):
        assert f'CG-{gate}' in plan
    (OUT / 'queue.json').write_text(json.dumps({'status': 'passed', 'owners': owners,
        'children': children, 'remaining': 58, 'required': 37, 'conditional': 21,
        'completed': [], 'dropped_experiment': 'contiguous native selection ranges',
        'cg1_through_cg23_preserved': True}, indent=2) + '\n')
    run('whitespace', ['git', 'diff', '--check'])
    run('docs-regressions', [sys.executable, '-m', 'unittest', 'python.tests.test_release_scripts',
                            'python.tests.test_runtime_gap_family_burn_down',
                            'python.tests.test_compute_engine_completion_gate'])
    for name, script, flags in (
        ('contribution', 'check_contribution_governance.py', []),
        ('v1-scope', 'check_v1_inclusion_scope.py', []),
        ('runtime-gaps', 'check_runtime_gap_family_burn_down.py', []),
        ('completion-inspection', 'check_compute_engine_completion_gate.py', ['--allow-incomplete']),
        ('architecture-inspection', 'check_release_architecture_tracker.py', ['--allow-blocked']),
        ('public-status', 'check_public_status_docs.py', []),
        ('website-readiness', 'check_website_readiness.py', []),
    ):
        run(name, [sys.executable, f'scripts/{script}', *flags, '--output', OUT / f'{name}.json'])
    status = 'passed'
except BaseException:
    status = 'failed'
    raise
finally:
    (OUT / 'report.json').write_text(json.dumps({'status': status, 'checks': checks,
        'completion_and_release_inspection_only': True,
        'claim_gate_status': 'not_claim_grade'}, indent=2) + '\n')
