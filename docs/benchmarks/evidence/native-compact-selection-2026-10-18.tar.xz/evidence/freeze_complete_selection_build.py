"""Freeze one freshly compiled selection cost-screen executable and its sources."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--role', choices=('baseline', 'candidate'), required=True)
parser.add_argument('--build', required=True)
args = parser.parse_args()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
base = '61afe0f547885d4ab3efd19ca216b5e083fd04a7' if args.role == 'baseline' else 'f0a67d00'
base = subprocess.check_output(['git', 'rev-parse', base], cwd=ROOT, text=True).strip()
changed = set(subprocess.check_output(['git', 'diff', '--name-only', base, 'HEAD'], cwd=ROOT, text=True).splitlines())
expected = {'shardloom-vortex/src/local_primitive_relational_selection_cost_tests.rs'}
if args.role == 'baseline':
    expected.add('shardloom-vortex/src/local_primitive_relational_tests.rs')
assert changed == expected, changed
receipt = json.loads((OUT / f'{args.build}.json').read_text())
assert receipt['status'] == 'passed' and receipt['process_group_drained']
assert receipt['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert receipt['working_tree'] == ''
log = (OUT / f'{args.build}.log').read_text()
assert 'Compiling shardloom-vortex v0.6.0' in log
matches = re.findall(r'Executable unittests src/lib.rs \(([^\n]+)\)', log)
assert len(matches) == 1, matches
source_binary = Path(matches[0])
if not source_binary.is_absolute():
    source_binary = ROOT / source_binary
directory = OUT / f'selection-{args.role}-complete'
directory.mkdir(exist_ok=False)
binary = directory / 'selection-tests'
shutil.copy2(source_binary, binary)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(binary) == digest(source_binary)
listing = subprocess.check_output([str(binary), 'native_selection_complete_cost_screen', '--list'], text=True)
assert 'native_selection_complete_cost_screen: test' in listing
assert '1 test, 0 benchmarks' in listing, listing
names = subprocess.check_output(['git', 'ls-files', '-cz', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode().split('\0')
sources = {}
for name in sorted(set(names)):
    if name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
        path = ROOT / name
        if path.is_file():
            sources[name] = {'sha256': digest(path), 'bytes': path.stat().st_size}
protocol = OUT / 'complete-selection-protocol.md'
shutil.copy2(protocol, directory / 'protocol.md')
test = ROOT / 'shardloom-vortex/src/local_primitive_relational_selection_cost_tests.rs'
assert digest(test) == digest(OUT / 'complete_selection_cost_tests.rs')
shutil.copy2(test, directory / test.name)
diff = subprocess.check_output(['git', 'diff', 'HEAD', '--'], cwd=ROOT)
(directory / 'source.diff').write_bytes(diff)
record = {
    'role': args.role, 'measurement_correction': 'complete_projection_fields_v2', 'production_base': base, 'only_changed_paths': sorted(changed), 'build_receipt': str(OUT / f'{args.build}.json'),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'binary': str(binary), 'binary_sha256': digest(binary),
    'protocol_sha256': digest(protocol), 'test_sha256': digest(test),
    'sources': sources, 'inventory': listing,
}
(directory / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ('role', 'binary', 'binary_sha256', 'test_sha256')}))
