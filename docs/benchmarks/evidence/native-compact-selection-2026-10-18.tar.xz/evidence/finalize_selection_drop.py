"""Bind the repeated regression decision to an exact restoration of production."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = '61afe0f547885d4ab3efd19ca216b5e083fd04a7'
TEST = 'shardloom-vortex/src/local_primitive_relational_selection_cost_tests.rs'
REGISTRY = 'shardloom-vortex/src/local_primitive_relational_tests.rs'
DOC = 'docs/architecture/native-compact-selection-2026-10-18.md'


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def evidence(name):
    record = read(OUT / f'{name}.json')
    log = OUT / f'{name}.log'
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['direct_child_reaped'] and record['process_group_drained']
    assert record['log_sha256'] == identity(log)['sha256']
    return {'command': record['command'], 'head': record['head'],
            'receipt': identity(OUT / f'{name}.json'), 'log': identity(log)}


assert not git('status', '--porcelain')
head = git('rev-parse', 'HEAD')
assert set(git('diff', '--name-only', BASE, head).splitlines()) == {TEST, REGISTRY, DOC}
baseline = read(OUT / 'selection-baseline-complete/manifest.json')
candidate = read(OUT / 'selection-candidate-complete/manifest.json')
assert identity(ROOT / TEST)['sha256'] == baseline['test_sha256'] == candidate['test_sha256']
assert identity(ROOT / TEST)['sha256'] == identity(OUT / 'complete_selection_cost_tests.rs')['sha256']
before_registry = subprocess.check_output(['git', 'show', f'{BASE}:{REGISTRY}'], cwd=ROOT, text=True)
marker = '#[path = "local_primitive_relational_selection_tests.rs"]\nmod selection_tests;'
addition = '#[path = "local_primitive_relational_selection_cost_tests.rs"]\nmod selection_cost_tests;\n'
assert before_registry.count(marker) == 1
assert (ROOT / REGISTRY).read_text() == before_registry.replace(marker, addition + marker)
assert all(identity(ROOT / name)['sha256'] == ref['sha256'] for name, ref in baseline['sources'].items())
assert identity(baseline['binary'])['sha256'] == baseline['binary_sha256']
assert identity(candidate['binary'])['sha256'] == candidate['binary_sha256']

cost_path = OUT / 'selection-complete-cost-confirmation-720.json'
cost = read(cost_path)
assert cost['schema_version'] == 'shardloom.compact_selection.cost_comparison.complete_fields.v2'
assert cost['status'] == 'drop_repeated_regression'
assert cost['all_resource_gates_passed'] and cost['reversed_order_confirmation_required']
assert cost['first_regression_cells'] == cost['repeated_regression_cells'] == [
    ['band', 'projection'], ['unfiltered', 'projection']]
assert len(cost['cells']) == len(cost['reverse_cells']) == 14
for key in ('cells', 'reverse_cells'):
    assert all(row['resource_gate_passed'] for row in cost[key])
    assert {tuple((row['shape'], row['consumer'])) for row in cost[key]
            if row['lifecycle_regression_gate_triggered']} == {('band', 'projection'), ('unfiltered', 'projection')}
measurement_receipts = {}
for role in ('baseline', 'candidate'):
    for kind in ('screen', 'reverse'):
        name = f'selection-{role}-complete-{kind}-720'
        measurement_receipts[name] = evidence(name)
        text = (OUT / f'{name}.log').read_text()
        assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text
        assert text.count('selection_cost=') == 42

names = ['selection-restored-fmt-720', 'selection-restored-clippy-720',
         'selection-restored-workspace-tests-720', 'selection-restored-native-tests-720',
         'selection-restored-native-clippy-720', 'selection-owner-harness-tests-720']
gates = {name: evidence(name) for name in names}
for name in names[:-1]:
    assert gates[name]['head'] == head
counts = {}
for name, expected in (('selection-restored-workspace-tests-720', 3235),
                       ('selection-restored-native-tests-720', 2969)):
    groups = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT / f'{name}.log').read_text())]
    assert groups and not any(row[1] for row in groups)
    counts[name] = {'passed': sum(row[0] for row in groups), 'ignored': sum(row[2] for row in groups), 'groups': len(groups)}
    assert counts[name]['passed'] == expected
assert 'Ran 4 tests' in (OUT / 'selection-owner-harness-tests-720.log').read_text()

runtime = read(OUT / 'acceptance-final-verified.json')
assert runtime['status'] == 'passed' and runtime['overall_unit_acceptance_complete'] is False
bridge = {'schema_version': 'shardloom.compact_selection.restoration_bridge.v1',
          'status': 'passed', 'production_base': BASE, 'restored_commit': head,
          'baseline_control_commit': baseline['head'], 'rejected_candidate_commit': candidate['head'],
          'production_sources_restored_exactly': True,
          'only_rust_changes_from_base': [TEST, REGISTRY],
          'registry_change': 'two-line ignored cost-test module registration only',
          'test_sha256': baseline['test_sha256'], 'compilation_source_files_verified': len(baseline['sources']),
          'compilation_sources': baseline['sources'], 'baseline_frozen_binary': identity(baseline['binary']),
          'rejected_candidate_frozen_binary': identity(candidate['binary']), 'verifier': identity(__file__)}
with (OUT / 'selection-final-source-bridge.json').open('x') as stream:
    json.dump(bridge, stream, indent=2)
    stream.write('\n')
report = {'schema_version': 'shardloom.perf10.compact_selection_drop.v1',
          'status': 'completed_drop', 'decision': 'drop',
          'investigated_substeps': ['PERF-10.compact_selections'], 'completed_substeps': [],
          'broader_owners_closed': [], 'investigation_remains_open': True,
          'experiment': 'contiguous ranges retained through native scan/filter/count/projection',
          'production_base': BASE, 'restored_commit': head,
          'candidate_runtime_commit': runtime['source_commit'], 'candidate_measurement_commit': candidate['head'],
          'source_bridge': identity(OUT / 'selection-final-source-bridge.json'),
          'cost_comparison': identity(cost_path), 'measurement_receipts': measurement_receipts,
          'corrected_complete_operations': 168, 'projected_fields_verified': ['n', 'keep'],
          'memory_targets_passed': True, 'throughput_retention_gate_passed': False,
          'repeated_regression_cells': cost['repeated_regression_cells'],
          'gates': gates, 'restored_rust_tests': counts,
          'candidate_correctness_evidence': {
              'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
              'public_workflows': 4827, 'public_families': 36, 'direct_binding_tests': 100,
              'native_format_workflows': 704, 'independent_pandas_oracle_workflows': 704,
              'full43_queries': 43, 'full43_complete_rows': 381,
              'full43_engine_execution_seconds': runtime['engine_execution_seconds'],
              'full43_reference_kind': 'retained_native_regression',
              'scope': 'correctness of the dropped candidate; not retained-runtime performance acceptance'},
          'superseded_preliminary_cost': identity(OUT / 'selection-cost-comparison-719.json'),
          'restored_runtime_performance_claim': False, 'claim_gate_status': 'not_claim_grade',
          'fallback_attempted': False, 'external_engine_execution': False,
          'platform_scope': 'local macOS arm64', 'release_version_changed': False,
          'publication_attempted': False,
          'unresolved': ['PERF-10.compact_selections requires a different mechanism and frozen protocol',
                         'PERF-01/03/07/10/11/12 broader obligations', 'CPU package B production-cost evidence',
                         'CG-5/CG-6 and all remaining competitive gates', 'hosted integration and release hold'],
          'verifier': identity(__file__)}
with (OUT / 'perf-10-acceptance.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': report['status'], 'decision': report['decision'],
                  'restored_source_files_verified': len(baseline['sources']),
                  'completed_substeps': report['completed_substeps']}))
