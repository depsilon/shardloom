# Complete projection-field correction to the frozen selection screen

This correction is declared before either corrected executable is built or run.
The original 42 baseline and 42 candidate observations remain retained as a
preliminary screen. Review found that its projection consumer checked the unique
numeric value on every row but omitted the second projected Boolean field. Its
complete-projection validation claim is therefore superseded by this corrected
screen. The production candidate and the original acceptance thresholds stay
unchanged.

Use the exact `complete_selection_cost_tests.rs` beside this protocol for both
versions, including its lint attributes. Add only the `keep` field borrow and the
scalar assertion for every projected row. The predicate reference includes nulls
and is indexed by the independently generated selected row positions. Numeric
validation, exact counts, certified no-fallback execution, shared-owner peak
measurement and zero reservations after cleanup remain required. The timer still
includes native intake, binding, execution, complete output-value validation and
cleanup. Its diagnostic lifecycle clock remains distinct from engine query time.

The baseline is production source `61afe0f5` plus this identical measurement-only
test and its module registration. The candidate is production source `f0a67d00`
plus this corrected ignored test. No production source change is permitted in
either measurement branch. Freeze both release executables, all Rust/Cargo source
identities, the exact measurement file and this protocol before measuring them.
Run serially under the unchanged workload/storage/process guards with two build
jobs and the same compiler/features/release profile as the original comparison.

Keep the seven shapes, two consumers, 16,387 input rows and three fresh complete
operations per cell. Run the corrected baseline first, then the corrected
candidate. Both all-pass filter targets must save at least 32 KiB and 10% of
baseline peak tracked memory. No cell may add more than 32 KiB peak memory.
Investigate a median lifecycle regression exceeding both 5% and 100 microseconds
with one reversed-order cohort of the frozen binaries; drop the candidate if the
same regression repeats. Preserve every observation and failure. No engine-wide
speedup, process-RSS limit, new datatype or new physical-format claim follows.

The already frozen CLI/native library and broad acceptance use the unchanged
production candidate at `f0a67d00`. Their source bridge to the final commit must
verify that only this ignored measurement test changes, with every non-test
runtime file unchanged. The corrected measurement must execute successfully;
formatting and native-feature lint must check the final test source as well.
