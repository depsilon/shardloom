"""Archive source, complete acceptance records and diagnostics; verify each member."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
NAME = 'native-compact-selection-2026-10-18'
BASE = '61afe0f547885d4ab3efd19ca216b5e083fd04a7'
DEST = OUT / 'packet-720'
DEST.mkdir(exist_ok=False)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return {'file': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)}


acceptance = read(OUT / 'perf-10-acceptance.json')
bridge = read(OUT / 'selection-final-source-bridge.json')
assert acceptance['status'] == 'completed_drop' and acceptance['decision'] == 'drop'
assert acceptance['completed_substeps'] == [] and acceptance['investigation_remains_open']
assert read(OUT / 'closeout-checks-720/report.json')['status'] == 'passed'
assert all(digest(ROOT / name) == ref['sha256'] for name, ref in bridge['compilation_sources'].items())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == acceptance['restored_commit']
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
docs = ['docs/architecture/native-compact-selection-2026-10-18.md',
        'docs/architecture/native-roadmap-verification-contracts-2026-10-18.md',
        'docs/architecture/phased-execution-plan.md',
        'docs/architecture/phased-execution-completed-ledger.md']
assert set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()) == set(docs)
(OUT / 'selection-implementation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', BASE, head], cwd=ROOT))
(OUT / 'selection-rejected-candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', BASE, acceptance['candidate_measurement_commit']], cwd=ROOT))
(OUT / 'selection-restoration.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', acceptance['candidate_measurement_commit'], head], cwd=ROOT))
(OUT / 'selection-closeout-documents.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
closeout = {'status': 'passed', 'production_base': BASE,
            'restored_commit': head, 'documents': {name: digest(ROOT / name) for name in docs},
            'runtime_sources_unchanged_since_final_bridge': True, 'verifier_sha256': digest(__file__)}
with (OUT / 'selection-closeout-source-bridge.json').open('x') as stream:
    json.dump(closeout, stream, indent=2)
    stream.write('\n')

candidate_paths = subprocess.check_output(['git', 'diff', '--name-only', BASE, acceptance['candidate_measurement_commit']], cwd=ROOT, text=True).splitlines()
for name in candidate_paths:
    path = OUT / 'rejected-source' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = subprocess.check_output(['git', 'show', f"{acceptance['candidate_measurement_commit']}:{name}"], cwd=ROOT)
    with path.open('xb') as stream:
        stream.write(payload)

members = {}
omitted = []
for path in sorted(OUT.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(OUT)
    if (relative.parts[0] in ('packet-720', '__pycache__') or '__pycache__' in relative.parts
            or relative.as_posix() in ('selection-package-720.log', 'selection-package-720.json')):
        continue
    assert not path.is_symlink(), path
    if relative.parts[0] == 'artifacts' or path.name == 'selection-tests':
        omitted.append({'path': str(relative), **identity(path), 'scope': 'native executable/library retained locally'})
        continue
    if path.suffix in ('.vortex', '.parquet', '.arrow', '.ipc', '.orc', '.avro') and path.stat().st_size > 1 << 20:
        omitted.append({'path': str(relative), **identity(path),
                        'scope': 'generated bulk fixture/output retained locally; complete validation records archived'})
        continue
    assert path.stat().st_size < 128 << 20, (path, path.stat().st_size)
    members['evidence/' + str(relative)] = path
changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, head], cwd=ROOT, text=True).splitlines()
for name in sorted(set(changed + docs)):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    members['source/' + name] = path
support = [
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
]
plan = read(OUT / 'acceptance-plan.json')
support += [Path(ref['path']) for ref in plan['query_harness']]
support += [Path(plan[key]['path']) for key in ('query_source', 'public_runner', 'reference')]
support += [Path(ref['path']) for ref in plan['schema_sources']]
for path in support:
    label = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name
    name = 'support/' + label
    assert name not in members or digest(members[name]) == digest(path)
    members[name] = path

manifest = [{'name': name, 'bytes': path.stat().st_size, 'sha256': digest(path)}
            for name, path in sorted(members.items())]
raw_bytes = sum(item['bytes'] for item in manifest)
assert raw_bytes < 1 << 30, raw_bytes
archive_path = DEST / (NAME + '.tar.xz')
with tarfile.open(archive_path, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
    for item in manifest:
        info = tarfile.TarInfo(item['name'])
        info.size, info.mode, info.mtime = item['bytes'], 0o644, 0
        with members[item['name']].open('rb') as stream:
            archive.addfile(info, stream)
by_name = {item['name']: item for item in manifest}
verified = []
with tarfile.open(archive_path, 'r:xz') as archive:
    for member in archive:
        assert member.isfile() and member.name in by_name
        expected = by_name[member.name]
        payload = archive.extractfile(member).read()
        assert len(payload) == expected['bytes']
        assert hashlib.sha256(payload).hexdigest() == expected['sha256']
        assert digest(members[member.name]) == expected['sha256']
        verified.append(member.name)
assert len(verified) == len(set(verified)) == len(manifest)
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress((json.dumps(manifest, indent=2) + '\n').encode()))
assert read(OUT / 'perf-10-acceptance.json') == acceptance
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
index = {
    'schema_version': 'shardloom.native_compact_selection_investigation.v1',
    'status': 'completed_drop', 'decision': 'drop',
    'completed_substeps': acceptance['completed_substeps'], 'broader_owners_closed': [],
    'investigated_substeps': acceptance['investigated_substeps'], 'investigation_remains_open': True,
    'base': BASE, 'restored_commit': head,
    'candidate_runtime_commit': acceptance['candidate_runtime_commit'],
    'candidate_measurement_commit': acceptance['candidate_measurement_commit'],
    'acceptance': '../../architecture/native-compact-selection-2026-10-18.md',
    'archive': identity(archive_path), 'manifest': identity(manifest_path),
    'member_count': len(manifest), 'uncompressed_bytes': raw_bytes, 'all_members_reopened': True,
    'owner_acceptance': 'evidence/perf-10-acceptance.json',
    'runtime_acceptance': 'evidence/acceptance-final-verified.json',
    'source_bridge': 'evidence/selection-final-source-bridge.json',
    'closeout_source_bridge': 'evidence/selection-closeout-source-bridge.json',
    'cost_comparison': 'evidence/' + Path(acceptance['cost_comparison']['path']).name,
    'corrected_projection_fields': ['n', 'keep'],
    'superseded_preliminary_cost': 'evidence/selection-cost-comparison-719.json',
    'restored_rust_tests': acceptance['restored_rust_tests'],
    'candidate_correctness_evidence': acceptance['candidate_correctness_evidence'],
    'corrected_complete_operations': 168,
    'repeated_regression_cells': acceptance['repeated_regression_cells'],
    'platform_scope': acceptance['platform_scope'],
    'omitted_bulk_artifacts': omitted,
    'external_input': plan['input'],
    'claim_gate_status': 'not_claim_grade', 'whole_engine_speedup_claim': False,
    'release_version_changed': False, 'publication_attempted': False,
    'limitations': acceptance['unresolved'],
    'failed_and_superseded_observations_retained': True,
    'unused_provisional_retain_finalizer': 'evidence/finalize_selection_runtime.py',
}
index_path = DEST / (NAME + '.json')
index_path.write_text(json.dumps(index, indent=2) + '\n')
for path in (archive_path, manifest_path, index_path):
    assert path.stat().st_size < 24 << 20
    destination = ROOT / 'docs/benchmarks/evidence' / path.name
    assert not destination.exists()
    shutil.copyfile(path, destination)
    assert digest(path) == digest(destination)
print(json.dumps({'status': 'passed', 'members': len(manifest), 'all_members_reopened': True,
                  'archive_bytes': archive_path.stat().st_size}))
