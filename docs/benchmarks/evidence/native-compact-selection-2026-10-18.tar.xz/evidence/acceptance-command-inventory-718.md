# Acceptance launch command inventory for bounded scan/filter change

Read-only inventory. No checks or UAT were run and no repository files were edited. Sources read: `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md` (PERF-10/12), `docs/benchmarks/native-roadmap-fresh-uat-2026-10-18.md`, `docs/architecture/public-documentation-api-acceptance-2026-10-18.md`, `docs/benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.json`, `/Users/dylan/LocalData/shardloom/public-docs-api-20261018/acceptance-evidence-index-716.md`, and targeted members of the accepted UAT archive.

## Fresh-roadmap launch materials and immutable identities

Portable evidence points to the accepted launch generator at archive member `helpers/local/prepare_roadmap_fresh_launch_663.py` in `docs/benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.part01.tar.xz`; its verifier is `helpers/local/verify_roadmap_fresh_uat_663.py` in the same archive. Targeted listing of `part03.tar.xz` locates `runtime-source/scripts/run_clickbench_query_uat.py` and `runtime-source/scripts/run_native_relational_suite.py`. These members were selectively read/listed; the large archives were not unpacked.

The accepted local copies also exist at:

- `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/prepare_roadmap_fresh_launch_663.py`
- `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/roadmap-fresh-launch-663.json`
- `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-uat663-plan.json`
- `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/verify_roadmap_fresh_uat_663.py`

The generator is **not replayable unchanged** for this change: it asserts the old source commit `6780e7df564c55f3e256822be1d0383cfabff0c9`, clean tree, source-manifest hashes, and old merged-source identities. The portable plan is a source for argument vectors and guard protocol. New source/build identities and outputs need a newly frozen plan; primary must resolve any stale absolute repository/target paths. The verifier likewise asserts the old commit/source manifest and old output state, so it cannot certify a new run without updating/re-freezing its declared identities.

The existing complete independent reference is `/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json`, SHA-256 `cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39`. The accepted native input artifact requested for reuse is `/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex`, SHA-256 `06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22`, 15,713,610,513 bytes, reported resident. Reuse it as Full43 input only after validating its current identity and generation. This scan/filter change does not itself require re-ingestion; if the intended semantics or fixture identity requires a changed input artifact, the owner must make that decision explicitly.

## Native feature gate and standard code gates

Accepted release-surface feature test vector from `native-feature-checks-714a1.json` (1,087 tests on earlier source):

```text
/Users/dylan/.cargo/bin/rustup run 1.99.0 cargo test --offline --locked -p shardloom-cli --lib --bin shardloom --test vortex_prepare --test public_memory_inputs --test public_workflow_route --test resident_worker --features release-user-surfaces
```

PERF-10's directly relevant launch selectors are:

```text
cargo test -p shardloom-vortex --features release-user-surfaces --lib native_selection_preserves_values_nulls_and_row_order -- --nocapture
cargo test -p shardloom-vortex --features release-user-surfaces --lib count_where_metadata_physical_kernels_evaluate_without_io -- --nocapture
cargo test -p shardloom-cli --features release-user-surfaces --test public_workflow_route public_route_admits_native_vortex_filter_project_payload -- --nocapture
```

Add the new scan/filter selection regression selector to the same feature-enabled test run. The repository's required batch gates remain `cargo fmt --all -- --check`, `cargo clippy --workspace --all-targets -- -D warnings`, and `cargo test --workspace --all-targets`; roadmap contract calls for one coherent batch run, with logs saved. Feature checks do not replace these default workspace gates. Whether a separate `cargo clippy ... --features release-user-surfaces` rerun is required depends on touched feature-specific code; the accepted public-API acceptance used strict release-feature CLI/Vortex Clippy, but the bounded change has no Python/API surface changes.

## Complete public 36-family native workflow regression

The accepted 36-family report is `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/nullable-layout-public-inspection-report-650.json`; its underlying receipt is `nullable-layout-public-650.json`, status passed. It represents 4,827 cases across 36 streaming-input families, not the smaller 18 format/workflow cohorts below. The exact accepted runner vector was:

```text
/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
-B
/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo/scripts/run_native_streaming_input_uat.py
--binary
/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-cli-release-nullable650a1/shardloom
--uat-root
/Users/dylan/LocalData/shardloom/native-python-surface-20261010/nullable-layout-public-650
--operation-timeout
600
--compress-logs
--families
input growth typed-input ordering ordering-pressure aggregate aggregate-pressure join join-pressure window window-pressure protocol preparation multiple multiple-pressure dynamic dynamic-pressure replay replay-pressure destinations sets sets-pressure unary unary-reference unary-composition unary-fault unary-pressure subqueries subqueries-composition subqueries-fault subqueries-pressure dynamic-subqueries dynamic-subqueries-reference dynamic-subqueries-composition dynamic-subqueries-fault dynamic-subqueries-pressure
```

The exact family sequence is 36 entries. Reuse this runner and family set as the launch protocol, but point to a newly built candidate CLI, a new empty UAT output root, and the current checkout's runner only after recording their hashes. The old `nullable-layout-public-650` output is immutable evidence, not a reusable destination or new-run result. Confirm current source/build identity before accepting the result; this broad suite must exercise the changed production scan/filter path. Its actual fixtures are generated/exercised by the runner, so rerun with fresh output paths rather than copying old results. The old exact source commit and dirty tree in its receipt are historical.

## Direct/native Python binding and streaming tests

The accepted source build command for the Python extension (`native-binding-build-714a1.json`) is:

```text
/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/build_native_python.py --output-dir /Users/dylan/LocalData/shardloom/public-docs-api-20261018/current-artifacts --release --offline
```

Rebuild against the changed tree and use the new `_native.abi3.so`. The accepted current-wheel integration receipt says 100 direct/native binding tests passed; its `integration.json` was produced from `python/tests`, pattern `test_native*binding.py`, in isolated installed-wheel mode. A repo-source equivalent should run against the freshly rebuilt extension and current Python tests, for example the exact direct test module:

```text
/usr/bin/env
SHARDLOOM_NATIVE_TEST_LIBRARY=<new-build>/_native.abi3.so
SHARDLOOM_REQUIRE_NATIVE_PYTHON=1
/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python
-m unittest discover -s python/tests -p test_native_binding.py -v
```

The published documentation acceptance additionally has a passed `test_public_context.py` command and 100-test installed-wheel proof; for direct context/streaming integration on current source, rerun `python/tests/test_public_context.py` with the same fresh library environment, then the full Python suite if required by the batch. The earlier exact accepted context command was:

```text
/usr/bin/env SHARDLOOM_NATIVE_TEST_LIBRARY=/Users/dylan/LocalData/shardloom/public-docs-api-20261018/current-artifacts/_native.abi3.so SHARDLOOM_REQUIRE_NATIVE_PYTHON=1 /Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python -m unittest discover -s python/tests -p test_public_context.py -v
```

That extension belongs to prior source and must be replaced. An installed-wheel rebuild/install/uninstall is not necessary to validate a Rust-only scan/filter change unless the primary requires package boundary coverage; the 100 installed-wheel tests are cited as the accepted baseline but test-source direct execution with the freshly built binding is sufficient to exercise the changed native runtime. If repeating the isolated installed wheel proof, create a fresh wheel/worktree package and environment rather than reusing the old install as new evidence.

## 18 format/workflow cohorts

The accepted exact sequential top-level invocation comes from `fresh-uat663-plan.json`:

```text
/usr/bin/env
PYTHONPATH=/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/python-deps
/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
-B
/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-timed-uat-461/run_modular_acceptance.py
--repo
<current repo>
--build-manifest
<fresh current-build manifest>
--prefix
fresh-native-scan-filter
--attempt
<new unique numeric attempt>
```

For all 18 cohorts, omit `--probe`. The driver runs 2 collect cohorts (raw/prepared × JSON and Vortex) and 16 CSV-input output cohorts (raw/prepared × Vortex, JSON, JSONL, CSV, Parquet, Arrow IPC, Avro, ORC). Each underlying cohort runs `benchmarks/traditional_analytics/run.py` with `--rows 1000 --dim-rows 20`, engines `shardloom pandas`, reference `pandas`, repeats 1, timeout 60, 1 GiB, parallelism 2. The exact driver source is `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-timed-uat-461/run_modular_acceptance.py`; its core-source checks require every Rust/Cargo/Python runtime file in the build manifest to match the current tree. It requires a new cohort output root/report name. It creates its 22 workflows from small fixtures; old cohort output is not reusable as candidate evidence. Expected complete matrix is 18 cohorts, 1,408 records (704 native + 704 pandas correctness-oracle records). Pandas remains an independent test oracle, never execution fallback.

The passed old Full43 argument vector (not run here) is recorded verbatim in the `commands.full43` array in `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-uat663-plan.json`: Python 3.13, `scripts/run_clickbench_query_uat.py`, old CLI binary, `--input /Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex`, `--uat-root /Users/dylan/LocalData/shardloom/clickbench-100m-uat`, accepted reference path above, old `--build-commit 6780e7...`, `--memory-gb 24 --max-parallelism 12 --repeats 1 --compress-logs --max-log-mib 1024 --max-run-log-mib 256`. For the new run, preserve every option but substitute the newly built CLI, a fresh isolated UAT root, and current commit/build identity; use the existing verified Vortex target and same reference. It must execute one call for each Q01–Q43 and produce complete 381 result rows with schemas, native certificates, timings and absent child-process checks. The UAT root/logs must satisfy current local storage/process guards.

## Source checks, rebuild, and reuse summary

- **Must rebuild:** release CLI binary with `release-user-surfaces`; native Python extension for direct binding/streaming tests; fresh build manifest with current source hashes; any source-dependent runner proof that enforces compiled-source identity. The Rust selection/filter helper/source itself changed, so stale accepted binaries cannot validate it.
- **Can reuse as immutable inputs after identity checks:** the 100m `fresh-roadmap-663-a1.vortex` source artifact and the complete independent reference JSON. Do not overwrite or regenerate the Vortex artifact for a scan/filter-only change. The old accepted outputs, reports and receipts are evidence only and cannot stand in for new candidate runs.
- **Regenerate in fresh roots:** 36-family public streaming UAT outputs and all 18 modular cohort/workflow outputs. The modular driver demands new destinations; `run_native_streaming_input_uat.py` likewise should receive a fresh output root. Small modular fixtures are produced by its runner. No need to recreate ClickBench Parquet or native Vortex unless its generation identity check fails or user scope changes.
- **Source checks apply:** fresh launch preparation, Full43 verifier, 18-cohort driver, 36-family runner, and Python binding test must bind current HEAD, working tree, runner hashes, CLI/extension hash and all relevant Rust/Cargo/Python source hashes. The old 663 helper hard assertions cannot be trusted against new source without an explicitly updated launch record and verifier.
- **Known unresolved details:** this inventory does not verify the current on-disk identity/residency of the large Vortex/Parquet/reference files, the current absolute Rust toolchain availability, free-space budgets, or the exact full Python 3.13 executable state. The 36-family receipt records an older base worktree and expects its runner/feature environment; primary should check current runner hashes and supported current feature switches before launch. Do not guess if a referenced path is missing or source/fixture identity differs.
