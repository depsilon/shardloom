"""Verify the test-only source bridge and close only the compact-selection unit."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
TEST = 'shardloom-vortex/src/local_primitive_relational_selection_cost_tests.rs'


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def evidence(name):
    record = read(OUT / f'{name}.json')
    log = OUT / f'{name}.log'
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['direct_child_reaped'] and record['process_group_drained']
    assert record['log_sha256'] == identity(log)['sha256']
    return {'command': record['command'], 'head': record['head'],
            'receipt': identity(OUT / f'{name}.json'), 'log': identity(log)}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cost', required=True)
args = parser.parse_args()
build = read(OUT / 'acceptance-build.json')
runtime = read(OUT / 'acceptance-final-verified.json')
assert runtime['status'] == 'passed'
assert runtime['acceptance_scope'] == 'unchanged_production_runtime_only'
assert runtime['source_commit'] == build['source_commit']
assert not git('status', '--porcelain')
head = git('rev-parse', 'HEAD')
assert git('diff', '--name-only', build['source_commit'], head).splitlines() == [TEST]
current = {name: identity(ROOT / name)['sha256'] for name in build['source_hashes']}
changed = [name for name, digest in build['source_hashes'].items() if current[name] != digest]
assert changed == [TEST], changed
assert current[TEST] == identity(OUT / 'complete_selection_cost_tests.rs')['sha256']
assert identity(build['binary'])['sha256'] == build['binary_sha256']
assert identity(build['native_library']['path']) == build['native_library']

cost_path = OUT / args.cost
cost = read(cost_path)
assert cost['schema_version'] == 'shardloom.compact_selection.cost_comparison.complete_fields.v2'
assert cost['status'] == 'passed' and cost['all_resource_gates_passed']
assert not cost.get('repeated_regression_cells', [])
assert len(cost['cells']) == 14
frozen = {}
for role in ('baseline', 'candidate'):
    path = OUT / f'selection-{role}-complete/manifest.json'
    item = read(path)
    assert item['test_sha256'] == current[TEST]
    assert item['protocol_sha256'] == identity(OUT / 'complete-selection-protocol.md')['sha256']
    assert identity(item['binary'])['sha256'] == item['binary_sha256']
    if role == 'candidate':
        assert item['head'] == head
        assert all(identity(ROOT / name)['sha256'] == ref['sha256'] for name, ref in item['sources'].items())
    frozen[role] = identity(path)

names = ['selection-workspace-fmt-719', 'selection-workspace-clippy-719',
         'selection-workspace-tests-719', 'selection-native-vortex-tests-719',
         'selection-native-cli-tests-719', 'selection-direct-binding-tests-719',
         'selection-public-context-tests-719', 'selection-owner-harness-tests-720',
         'selection-final-fmt-720', 'selection-final-native-clippy-720']
gates = {name: evidence(name) for name in names}
for name in ('selection-final-fmt-720', 'selection-final-native-clippy-720'):
    assert gates[name]['head'] == head
rust_counts = {}
for name in ('selection-workspace-tests-719', 'selection-native-vortex-tests-719', 'selection-native-cli-tests-719'):
    groups = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT / f'{name}.log').read_text())]
    assert groups and not any(row[1] for row in groups)
    rust_counts[name] = {'passed': sum(row[0] for row in groups), 'ignored': sum(row[2] for row in groups), 'groups': len(groups)}
assert [rust_counts[name]['passed'] for name in rust_counts] == [3235, 2976, 1087]
native_log = (OUT / 'selection-native-vortex-tests-719.log').read_text()
selectors = [line.split(' ... ')[0][5:] for line in native_log.splitlines()
             if line.startswith('test ') and 'native_compact_selection_' in line and line.endswith(' ... ok')]
assert len(selectors) == 7
for selector in ('native_selection_preserves_values_nulls_and_row_order', 'count_where_metadata_physical_kernels_evaluate_without_io'):
    assert any(selector in line and line.endswith(' ... ok') for line in native_log.splitlines())
assert 'test public_route_admits_native_vortex_filter_project_payload ... ok' in (OUT / 'selection-native-cli-tests-719.log').read_text()
assert 'Ran 100 tests' in (OUT / 'selection-direct-binding-tests-719.log').read_text()
assert 'Ran 4 tests' in (OUT / 'selection-owner-harness-tests-720.log').read_text()

bridge = {'schema_version': 'shardloom.compact_selection.source_bridge.v1', 'status': 'passed',
          'runtime_commit': build['source_commit'], 'measurement_test_commit': head,
          'changed_paths': changed, 'only_ignored_measurement_test_changed': True,
          'source_files_checked': len(current), 'unchanged_files': len(current) - 1,
          'before': build['source_hashes'][TEST], 'after': current[TEST],
          'production_binary': identity(build['binary']), 'native_library': build['native_library'],
          'corrected_measurement': identity(cost_path), 'corrected_frozen_manifests': frozen,
          'final_test_lint_and_format_checked': True, 'source_hashes': current,
          'verifier': identity(__file__)}
with (OUT / 'selection-final-source-bridge.json').open('x') as stream:
    json.dump(bridge, stream, indent=2)
    stream.write('\n')
report = {'schema_version': 'shardloom.perf10.compact_selection_acceptance.v1',
          'status': 'passed_local_scope', 'decision': 'retain',
          'completed_substeps': ['PERF-10.compact_selections'], 'broader_owners_closed': [],
          'runtime_commit': build['source_commit'], 'measurement_test_commit': head,
          'source_bridge': identity(OUT / 'selection-final-source-bridge.json'),
          'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
          'cost_comparison': identity(cost_path), 'gates': gates, 'rust_tests': rust_counts,
          'new_regression_selectors': selectors, 'direct_binding_tests_passed': 100,
          'public_context_tests': {'discovered': 18, 'passed': 17, 'skipped': 1,
                                   'skip_reason': 'clean installed-package opt-in; no installed-wheel acceptance claimed'},
          'public_workflows': 4827, 'public_families': 36,
          'full43': {'queries': 43, 'executions_per_query': 1, 'complete_rows': 381,
                     'engine_execution_seconds': runtime['engine_execution_seconds'],
                     'reference_kind': 'retained_native_regression', 'reingested': False},
          'format_workflows': {'cohorts': 18, 'native': 704, 'independent_pandas_oracle': 704},
          'ownership': {'all_cost_cells_release_reservations': True,
                        'denial_retry_predicate_failure_cancel_and_last_owner_tests': 'passed',
                        'process_rss_ceiling_claimed': False},
          'superseded_preliminary_cost': identity(OUT / 'selection-cost-comparison-719.json'),
          'preliminary_correction': 'Both corrected binaries check every projected numeric and Boolean value; original gates unchanged.',
          'fallback_attempted': False, 'external_engine_execution': False,
          'whole_engine_speedup_claim': False, 'claim_gate_status': 'not_claim_grade',
          'platform_scope': 'local macOS arm64; hosted Linux/Windows runtime acceptance remains open',
          'release_version_changed': False, 'publication_attempted': False,
          'unresolved': ['PERF-01/03/07/10/11/12 broader obligations', 'CPU package B production-cost evidence',
                         'CG-5/CG-6 and all remaining competitive gates', 'hosted integration and release hold'],
          'verifier': identity(__file__)}
with (OUT / 'perf-10-acceptance.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': report['status'], 'decision': report['decision'],
                  'completed_substeps': report['completed_substeps'], 'source_files_checked': len(current)}))
