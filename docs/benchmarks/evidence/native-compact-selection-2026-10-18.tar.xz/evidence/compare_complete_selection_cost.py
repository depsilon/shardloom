"""Evaluate the frozen compact-selection resource and complete-operation gates."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent
SHAPES = ('unfiltered', 'all', 'none', 'band', 'sparse', 'dense', 'nullable')
CONSUMERS = ('projection', 'count')


def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def read(name, role):
    receipt = json.loads((OUT / f'{name}.json').read_text())
    frozen = json.loads((OUT / f'selection-{role}-complete' / 'manifest.json').read_text())
    binary = Path(frozen['binary'])
    assert receipt['command'][0] == str(binary)
    assert identity(binary)['sha256'] == frozen['binary_sha256']
    log = OUT / f'{name}.log'
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['log_sha256'] == identity(log)['sha256']
    observations = [json.loads(line.split('selection_cost=', 1)[1])
                    for line in log.read_text().splitlines() if 'selection_cost=' in line]
    assert len(observations) == 42
    cells = {}
    for shape in SHAPES:
        for consumer in CONSUMERS:
            values = [row for row in observations
                      if row['shape'] == shape and row['consumer'] == consumer]
            assert sorted(row['observation'] for row in values) == [0, 1, 2]
            assert {row['input_rows'] for row in values} == {16387}
            assert {row['reserved_after_cleanup'] for row in values} == {0}
            assert len({row['selected_rows'] for row in values}) == 1
            assert len({row['peak_reserved_bytes'] for row in values}) == 1
            seconds = [row['complete_lifecycle_seconds'] for row in values]
            assert all(math.isfinite(value) and value > 0 for value in seconds)
            cells[(shape, consumer)] = {
                'selected_rows': values[0]['selected_rows'],
                'peak_reserved_bytes': values[0]['peak_reserved_bytes'],
                'median_complete_lifecycle_seconds': statistics.median(seconds),
                'complete_lifecycle_seconds': seconds,
            }
    return cells, {'receipt': identity(OUT / f'{name}.json'), 'log': identity(log)}


def compare(before, after):
    results = []
    for key, base in before.items():
        current = after[key]
        assert base['selected_rows'] == current['selected_rows']
        saved = base['peak_reserved_bytes'] - current['peak_reserved_bytes']
        delta = current['median_complete_lifecycle_seconds'] - base['median_complete_lifecycle_seconds']
        ratio = current['median_complete_lifecycle_seconds'] / base['median_complete_lifecycle_seconds']
        target = key[0] == 'all'
        results.append({
            'shape': key[0], 'consumer': key[1], 'baseline': base, 'candidate': current,
            'saved_peak_bytes': saved, 'saved_peak_fraction': saved / base['peak_reserved_bytes'],
            'target': target,
            'resource_gate_passed': saved >= -32768 and
                (not target or (saved >= 32768 and saved / base['peak_reserved_bytes'] >= .10)),
            'median_lifecycle_ratio': ratio, 'median_lifecycle_delta_seconds': delta,
            'lifecycle_regression_gate_triggered': ratio > 1.05 and delta > .0001,
        })
    return results


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', required=True)
parser.add_argument('--candidate', required=True)
parser.add_argument('--reverse-baseline')
parser.add_argument('--reverse-candidate')
parser.add_argument('--output', required=True)
args = parser.parse_args()
assert bool(args.reverse_baseline) == bool(args.reverse_candidate)
frozen_baseline = json.loads((OUT / 'selection-baseline-complete/manifest.json').read_text())
frozen_candidate = json.loads((OUT / 'selection-candidate-complete/manifest.json').read_text())
assert frozen_baseline['test_sha256'] == frozen_candidate['test_sha256'] == identity(OUT / 'complete_selection_cost_tests.rs')['sha256']
assert frozen_baseline['protocol_sha256'] == frozen_candidate['protocol_sha256'] == identity(OUT / 'complete-selection-protocol.md')['sha256']
baseline, base_receipt = read(args.baseline, 'baseline')
candidate, candidate_receipt = read(args.candidate, 'candidate')
cells = compare(baseline, candidate)
triggers = {(row['shape'], row['consumer']) for row in cells
            if row['lifecycle_regression_gate_triggered']}
report = {'schema_version': 'shardloom.compact_selection.cost_comparison.complete_fields.v2',
          'status': 'passed', 'clock': 'complete_lifecycle_diagnostic_not_engine_clock',
          'performance_claim': False, 'baseline': base_receipt, 'candidate': candidate_receipt,
          'cells': cells, 'all_resource_gates_passed': all(row['resource_gate_passed'] for row in cells),
          'first_regression_cells': sorted(triggers), 'reversed_order_confirmation_required': bool(triggers)}
if not report['all_resource_gates_passed']:
    report['status'] = 'drop_resource_gate'
elif triggers:
    report['status'] = 'needs_reversed_order_confirmation'
if args.reverse_baseline:
    assert triggers, 'Do not repeat the screen without a frozen regression trigger'
    reverse_base, rb_receipt = read(args.reverse_baseline, 'baseline')
    reverse_candidate, rc_receipt = read(args.reverse_candidate, 'candidate')
    repeated = compare(reverse_base, reverse_candidate)
    repeated_triggers = {(row['shape'], row['consumer']) for row in repeated
                         if row['lifecycle_regression_gate_triggered']}
    report.update(reverse_baseline=rb_receipt, reverse_candidate=rc_receipt,
                  reverse_cells=repeated, repeated_regression_cells=sorted(triggers & repeated_triggers))
    if report['all_resource_gates_passed']:
        report['status'] = 'drop_repeated_regression' if triggers & repeated_triggers else 'passed'
    assert all(row['resource_gate_passed'] for row in repeated)
with (OUT / args.output).open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'all_resource_gates_passed', 'first_regression_cells')}))
for row in cells:
    print(json.dumps({key: row[key] for key in ('shape', 'consumer', 'saved_peak_bytes', 'saved_peak_fraction')}))
