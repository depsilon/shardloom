# PERF-10.compact_selections closeout inventory

Read-only inventory for closing only CPU package A’s finite conditional child. No repository changes, builds, tests, or benchmarks were made.

## Active queue and counts

- Edit only the active `PERF-10.compact_selections` checkbox in `docs/architecture/phased-execution-plan.md:362` to completed/remove it from active checklist, and adjust the current-queue accounting at line 270 to **57 substeps: 37 required, 20 conditional**. Keep 14 owners, twelve named investigations (the compact-selection investigation is now completed history but still one of the twelve named intake investigations), and do not close parent `PERF-10` or related owners. Queue authority and one-queue rules are at lines 5–17 and 191–203; finite-child closeout rule is line 281.
- Add a dated completed session near the top of `docs/architecture/phased-execution-completed-ledger.md:18–46`, with implementation/test/acceptance evidence, exact completed ID, and explicit open broader-owner status. The ledger is history rather than a second active queue (lines 5–14). Keep the existing October 18 intake note (line 46) and its earlier pre-bump entry (lines 48–65) as historical snapshots.
- The phase plan’s sequence line 262 says begin A/B cost assessment; after package A closes, revise only if the current next-action wording would misstate that A is pending. Package B remains pending. Do not rewrite the October 18 intake narrative as though its original queue counts were current: `native-cpu-investigations-2026-10-18.md:3–5,18–22` is dated intake history; line 5 records the initial 58/37/21 state. The JSON is likewise intake provenance: `native-cpu-investigations-2026-10-18.json:2–22,95–129` records queued intake, original counts and new-step definitions. Preserve these values as historical facts.

## Verification and evidence consumers

- PERF-10 starting regression selectors and acceptance deliverable remain in `native-roadmap-verification-contracts-2026-10-18.md:3,127–137`. The closeout should add exact selectors for compact representation construction/conversion/composition, count and projection/gather consumers, ownership and semantics described by the package A contract in `native-cpu-investigations-2026-10-18.md:24–32`; it must not imply all PERF-10 acceptance is complete. The generic evidence filename remains `perf-10-acceptance.json`.
- `native-cpu-queue-validation-2026-10-18.json:2–31` is an immutable passed intake-validation packet (58/37/21, package list, and `benchmark_run:false`); its archived validator at member `support/verify_cpu_queue_686.py` asserts those exact historical values and queued status. Leave packet/archive and its source hashes intact. Do not rerun or modify that historical validator as if it were the active queue validator.
- The original verification-contract archive and index are also frozen intake evidence: `native-roadmap-verification-contracts-2026-10-18.json:11–15,186–243`; its PERF-10 check set at markdown lines 127–137 remains a baseline. Regenerating either archive/index would rewrite recorded source identities and is not part of finite closeout.
- Current roadmap/status checks that previously asserted active counts should be rerun or updated only if source search identifies assertions tied to current plan text. In this checkout, direct consumer search found the archived intake verifier only; its embedded Python asserts 58 total and 21 conditional specifically for queue intake. Existing completion/release status validators consume the phase plan’s unchecked counts, so rerun the established documentation validation set recorded in `native-cpu-queue-validation-2026-10-18.json:80–112` (unit regressions plus `check_v1_inclusion_scope.py`, `check_runtime_gap_family_burn_down.py`, `check_compute_engine_completion_gate.py --allow-incomplete`, `check_release_architecture_tracker.py --allow-blocked`, `check_public_status_docs.py`, `check_website_readiness.py`, and `check_contribution_governance.py`) after editing. Expect incomplete/blocking completion status to remain; no broad Rust build/test is implied by this docs-only closeout.

## Machine schema and snapshots

No current machine schema change is indicated. `native-cpu-investigations-2026-10-18.json` describes intake, not live queue state; the passed queue-validation evidence is immutable historical evidence, not a live status API. A new closeout acceptance record may use the existing PERF-10 evidence contract; do not change its schema absent a concrete new field requirement. Preserve the immutable 54-step reconciliation and its JSON (`native-roadmap-reconciliation-2026-10-18.*`), 149 historical rows, 58-step original intake packet, and all source hashes in archived validation artifacts. The historical local-scope note explicitly treats the phase plan as current counts authority and says its dated assessment remains intact: `native-local-completion-scope-2026-10-07.md:3–8,275–277`.

## Closure-policy note

No policy ambiguity found for the requested queue arithmetic and history boundaries: moving one conditional child yields 57/37/20. The implementation acceptance threshold and whether it is met are outside this inventory; the primary must ground those judgments in the finalized runtime artifact and linked evidence before marking the child complete. Do not make any benchmark claim from this report.

## Final experiment disposition

The corrected comparison and its single reversed-order confirmation both trigger
the frozen projection regression gate. The primary dropped the contiguous-range
runtime candidate. The conditional child stays open for a different mechanism;
therefore the active queue remains **58/37/21**. The proposed 57/37/20 closeout
above is not applied. Only this measured experiment moves to the completed ledger.
