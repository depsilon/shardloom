"""Validate every frozen candidate-748 cell before applying its unchanged gates."""
from pathlib import Path
from itertools import product
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / 'codec-cache-protocol-748.json'
assert hashlib.sha256(PROTOCOL.read_bytes()).hexdigest() == 'c84d02710b28bb0f6796d7f1edb0be3a4795b233c9d22055cba4b1abba2ad124'
CELLS = set(product(
    ('nullable_i64', 'nullable_utf8', 'nullable_binary'),
    (4096, 65536),
    ('canonical', 'zstd_no_dictionary', 'zstd_dictionary'),
    ('native_canonical_2048', 'json_2048', 'json_64'),
))
HOTSPOTS = {
    ('nullable_i64', 4096, 'zstd_dictionary', 'json_64'),
    ('nullable_i64', 65536, 'zstd_dictionary', 'json_64'),
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def parse(path, marker):
    result = []
    for line in path.read_text().splitlines():
        # Rust's single-threaded harness can prefix the first captured line with
        # the test name. The marker and complete JSON record remain unchanged.
        if marker in line:
            result.append(json.loads(line.split(marker, 1)[1]))
    return result

prior = parse(ROOT / 'codec-workflow-cohort-a-747.log', 'CODEC_WORKFLOW_ATTRIBUTION ')
physical = {}
for row in prior:
    key = (row['kind'], row['rows'], row['encoding'])
    value = (row['physical_bytes'], row['physical_sha256'])
    assert physical.setdefault(key, value) == value
assert len(physical) == 18

cohorts = []
identities = {}
for cohort in ('a', 'b'):
    path = ROOT / f'codec-cache-cohort-{cohort}-748.log'
    receipt = json.loads(path.with_suffix('.json').read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] is True
    assert receipt['log_sha256'] == sha(path)
    rows = parse(path, 'CODEC_CACHE_WORKFLOW ')
    assert len(rows) == 432, (cohort, len(rows))
    grouped = {}
    for row in rows:
        cell = (row['kind'], row['rows'], row['encoding'], row['consumer'])
        assert cell in CELLS
        observed = row['observation']
        key = (row['sample'], observed['candidate'])
        assert key not in grouped.setdefault(cell, {})
        grouped[cell][key] = observed
        assert row['sample'] in range(4)
        assert row['warmup'] == (row['sample'] == 0)
        operations = 1 if row['warmup'] else 7
        assert observed['operations'] == operations
        assert len(observed['observations']) == operations
        assert row['grant_bytes'] == 64 << 20
        assert (row['physical_bytes'], row['physical_sha256']) == physical[cell[:3]]
        assert observed['denied_reservations'] == 0
        assert observed['peak_reserved_bytes'] <= row['grant_bytes']
        assert observed['final_reserved_bytes'] == 0
        cache = observed['cache']
        if observed['candidate']:
            assert cache is not None
            if row['encoding'] == 'zstd_dictionary':
                assert cache['prepared'] == 1 and cache['misses'] == 1
                assert cache['hits'] > 0
                assert cache['returned'] == cache['hits'] + 1
                assert 0 < cache['idle_bytes'] <= 128 << 10
                assert cache['declined'] == cache['evicted'] == 0
            else:
                assert all(value == 0 for value in cache.values())
        else:
            assert cache is None
        total = observed['initialize_and_prepare_nanoseconds'] + observed['cleanup_nanoseconds']
        idle_credit = 0 if not cache or not cache['idle_bytes'] else cache['idle_bytes'] + 512
        for operation in observed['observations']:
            assert operation['all_values_types_nulls_order_verified'] is True
            assert operation['source_validation_included'] is True
            assert operation['reserved_after_output'] == observed['source_retained_bytes'] + idle_credit
            assert operation['reserved_with_complete_output'] >= operation['reserved_after_output']
            assert operation['native_workflow_nanoseconds'] > 0
            total += operation['native_workflow_nanoseconds'] + operation['output_release_nanoseconds']
            identity_key = (row['kind'], row['rows'])
            identity = (operation['values_sha256'], operation['schema_sha256'])
            assert all(len(value) == 64 for value in identity)
            assert identities.setdefault(identity_key, identity) == identity
        assert total == observed['complete_lifecycle_nanoseconds']
    assert set(grouped) == CELLS
    scores = []
    regression = []
    for cell in sorted(CELLS):
        cases = grouped[cell]
        assert set(cases) == set(product(range(4), (False, True)))
        baseline = [cases[sample, False]['complete_lifecycle_nanoseconds'] for sample in (1, 2, 3)]
        candidate = [cases[sample, True]['complete_lifecycle_nanoseconds'] for sample in (1, 2, 3)]
        base_median = statistics.median(baseline)
        candidate_median = statistics.median(candidate)
        improvement = 1 - candidate_median / base_median
        per_operation_increase = (candidate_median - base_median) / 7
        fails_control = improvement < -0.05 and per_operation_increase > 100_000
        if fails_control:
            regression.append(list(cell))
        scores.append({
            'cell': cell,
            'control_sample_lifecycle_nanoseconds': baseline,
            'candidate_sample_lifecycle_nanoseconds': candidate,
            'control_median_nanoseconds': base_median,
            'candidate_median_nanoseconds': candidate_median,
            'improvement_fraction': improvement,
            'increase_nanoseconds_per_operation': per_operation_increase,
            'fails_control': fails_control,
            'cache': cases[1, True]['cache'],
            'first_use_control_nanoseconds': [cases[s, False]['observations'][0]['native_workflow_nanoseconds'] for s in (1,2,3)],
            'first_use_candidate_nanoseconds': [cases[s, True]['observations'][0]['native_workflow_nanoseconds'] for s in (1,2,3)],
        })
    baseline_total = sum(row['control_median_nanoseconds'] for row in scores)
    candidate_total = sum(row['candidate_median_nanoseconds'] for row in scores)
    improvement = 1 - candidate_total / baseline_total
    hotspot_scores = [row for row in scores if tuple(row['cell']) in HOTSPOTS]
    assert len(hotspot_scores) == 2
    passes = improvement >= 0.02 and not regression and all(row['improvement_fraction'] >= 0.02 for row in hotspot_scores)
    cohorts.append({
        'cohort': cohort, 'records': len(rows), 'cells': len(grouped),
        'log_sha256': sha(path), 'receipt_sha256': sha(path.with_suffix('.json')),
        'control_complete_workload_nanoseconds': baseline_total,
        'candidate_complete_workload_nanoseconds': candidate_total,
        'improvement_fraction': improvement,
        'control_regressions': regression,
        'hotspots': hotspot_scores, 'passes_frozen_gates': passes,
        'scores': scores,
    })
assert len(identities) == 6
report = {
    'protocol_sha256': sha(PROTOCOL),
    'safety_addendum_sha256': sha(ROOT / 'codec-cache-safety-addendum-748.json'),
    'analysis_source_sha256': sha(Path(__file__)),
    'correctness_and_coverage': 'passed',
    'prior_747_physical_artifacts_identical': True,
    'cohorts': cohorts,
    'retain_candidate': all(row['passes_frozen_gates'] for row in cohorts),
    'scope': '54 finite complete native delivery workflows, including preparation/first use/output release/owner cleanup; not a Full43 engine claim',
}
output = ROOT / 'codec-cache-analysis-748.json'
assert not output.exists()
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'correctness_and_coverage': report['correctness_and_coverage'],
    'retain_candidate': report['retain_candidate'],
    'cohorts': [{key: value for key, value in row.items() if key not in ('scores', 'hotspots')}
                | {'hotspots': [{'cell': s['cell'], 'improvement_fraction': s['improvement_fraction']}
                                 for s in row['hotspots']]}
                for row in cohorts],
    'output': str(output),
}, indent=2))
