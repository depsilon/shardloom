// SPDX-License-Identifier: Apache-2.0
//! Temporary probe harness for the frozen October 19 codec attribution protocol.

use super::*;
use vortex::array::Canonical;
use vortex_zstd::preparation_profile::{self, STAGES, Snapshot};

#[path = "native_provider_zstd_workflow_attribution_tests.rs"]
mod workflow_tests;

fn profile_json(snapshot: Snapshot) -> serde_json::Value {
    let mut values = serde_json::Map::new();
    for (index, stage) in STAGES.iter().enumerate() {
        values.insert(
            (*stage).to_owned(),
            serde_json::json!({
                "nanoseconds": snapshot.nanoseconds[index],
                "calls": snapshot.calls[index],
            }),
        );
    }
    serde_json::Value::Object(values)
}

fn add_profile(total: &mut Snapshot, addition: Snapshot) {
    for index in 0..STAGES.len() {
        total.nanoseconds[index] += addition.nanoseconds[index];
        total.calls[index] += addition.calls[index];
    }
}

fn slice_fixture(source: &Fixture, range: std::ops::Range<usize>) -> Fixture {
    Fixture {
        input: source.input.slice(range.clone()).unwrap(),
        expected: match &source.expected {
            Expected::Integers(values) => Expected::Integers(values[range].to_vec()),
            Expected::Bytes(values) => Expected::Bytes(values[range].to_vec()),
        },
    }
}

fn decoder_operation(
    inputs: &[ArrayRef],
    expected: &[Fixture],
    ctx: &mut ExecutionCtx,
    memory: &LiveMemoryPool,
    profiled: bool,
) -> serde_json::Value {
    let before = memory.snapshot().reserved_bytes;
    let mut elapsed = 0;
    let mut retained = 0;
    let mut total = Snapshot::default();
    for (input, expected) in inputs.iter().zip(expected) {
        if profiled {
            preparation_profile::begin();
        }
        let started = Instant::now();
        let output = input.clone().execute::<Canonical>(ctx).unwrap();
        elapsed += started.elapsed().as_nanos();
        if profiled {
            let observed = preparation_profile::finish();
            assert_eq!(observed.calls[1], 1, "one decoder allocation per call");
            assert_eq!(observed.calls[2], 1, "one decoder initialization per call");
            assert_eq!(observed.calls[3], 1, "one selected-frame loop per call");
            add_profile(&mut total, observed);
        }
        retained = retained.max(memory.snapshot().reserved_bytes - before);
        let output = output.into_array();
        assert_eq!(output.dtype(), expected.input.dtype());
        assert_eq!(output.len(), expected.input.len());
        verify_values(output, expected, ctx);
        assert_eq!(memory.snapshot().reserved_bytes, before);
    }
    serde_json::json!({
        "native_execute_nanoseconds": elapsed,
        "native_execute_calls": inputs.len(),
        "retained_output_peak_bytes": retained,
        "post_output_reserved_bytes": memory.snapshot().reserved_bytes,
        "profile": profile_json(total),
    })
}

#[test]
#[ignore = "frozen diagnostic attribution only; not performance acceptance"]
fn native_zstd_preparation_attribution_screen() {
    assert_eq!(
        std::env::var("SHARDLOOM_CODEC_ATTRIBUTION").as_deref(),
        Ok("frozen-v1")
    );
    for kind in ["nullable_i64", "nullable_utf8", "nullable_binary"] {
        for rows in [4096, 65_536] {
            let fixture = fixture(kind, rows);
            let frame_rows = if rows == 4096 { 128 } else { 1024 };
            for encoding in ["zstd_no_dictionary", "zstd_dictionary"] {
                let reference = operation(&fixture, encoding, frame_rows);
                for sample in 0..=SAMPLES {
                    let operations = if sample == 0 { 1 } else { OPERATIONS };
                    for profiled in if sample % 2 == 0 {
                        [false, true]
                    } else {
                        [true, false]
                    } {
                        let mut observations = Vec::with_capacity(operations);
                        for _ in 0..operations {
                            if profiled {
                                preparation_profile::begin();
                            }
                            let started = Instant::now();
                            let observed = operation(&fixture, encoding, frame_rows);
                            let elapsed = started.elapsed().as_nanos();
                            let profile = if profiled {
                                preparation_profile::finish()
                            } else {
                                Snapshot::default()
                            };
                            assert_eq!(observed, reference);
                            if profiled {
                                assert_eq!(profile.calls[4], 1);
                                assert_eq!(profile.calls[5], 1);
                                assert_eq!(profile.calls[1], 1);
                                assert_eq!(
                                    profile.calls[7],
                                    u64::from(encoding == "zstd_dictionary")
                                );
                            }
                            observations.push(serde_json::json!({
                                "complete_lifecycle_nanoseconds": elapsed,
                                "profile": profile_json(profile),
                            }));
                        }
                        println!(
                            "CODEC_ATTRIBUTION {}",
                            serde_json::json!({
                                "kind": kind, "rows": rows, "encoding": encoding,
                                "frame_rows": frame_rows, "grant_bytes": GRANT,
                                "operation": "complete_compression_lifecycle",
                                "sample": sample, "warmup": sample == 0,
                                "profiled": profiled, "observations": observations,
                                "complete_identity": reference,
                            })
                        );
                    }
                }

                let source_memory = LiveMemoryPool::new(GRANT).unwrap();
                let source_session = session(&source_memory);
                let source = encode(
                    &fixture,
                    encoding,
                    frame_rows,
                    &mut source_session.create_execution_ctx(),
                );
                let dictionary_present = source
                    .as_::<Zstd>()
                    .data()
                    .clone()
                    .into_parts(source.validity().unwrap())
                    .dictionary
                    .is_some();
                assert_eq!(dictionary_present, encoding == "zstd_dictionary");
                for sliced in [false, true] {
                    let ranges: Vec<_> = if sliced {
                        let width = rows / 32;
                        (0..16)
                            .map(|index| {
                                let start = (index * 977 + 13) % (rows - width);
                                start..start + width
                            })
                            .collect()
                    } else {
                        vec![0..rows]
                    };
                    let inputs: Vec<_> = ranges
                        .iter()
                        .map(|range| source.slice(range.clone()).unwrap())
                        .collect();
                    let expected: Vec<_> = ranges
                        .into_iter()
                        .map(|range| slice_fixture(&fixture, range))
                        .collect();
                    let memory = LiveMemoryPool::new(GRANT).unwrap();
                    let consumer = session(&memory);
                    let mut ctx = consumer.create_execution_ctx();
                    for sample in 0..=SAMPLES {
                        let operations = if sample == 0 { 1 } else { OPERATIONS };
                        for profiled in if sample % 2 == 0 {
                            [false, true]
                        } else {
                            [true, false]
                        } {
                            let observations: Vec<_> = (0..operations)
                                .map(|_| {
                                    decoder_operation(
                                        &inputs, &expected, &mut ctx, &memory, profiled,
                                    )
                                })
                                .collect();
                            println!(
                                "CODEC_ATTRIBUTION {}",
                                serde_json::json!({
                                    "kind": kind, "rows": rows, "encoding": encoding,
                                    "frame_rows": frame_rows, "grant_bytes": GRANT,
                                    "operation": if sliced { "16_deterministic_slices" } else { "full_array" },
                                    "sample": sample, "warmup": sample == 0,
                                    "profiled": profiled, "observations": observations,
                                    "consumer_peak_bytes": memory.snapshot().peak_reserved_bytes,
                                    "source_retained_bytes": source_memory.snapshot().reserved_bytes,
                                })
                            );
                        }
                    }
                    drop(ctx);
                    drop(consumer);
                    assert_eq!(memory.snapshot().reserved_bytes, 0);
                }
                drop(source);
                drop(source_session);
                assert_eq!(source_memory.snapshot().reserved_bytes, 0);
            }
        }
    }
}
