// SPDX-License-Identifier: Apache-2.0
//! Temporary production-workflow attribution; frozen protocol 747.

use super::*;
use crate::{
    local_primitives::prepared_relational::{
        PreparedVortexRelational, prepare_relational_in_session,
    },
    relational_query::{VortexRelationalPlan, VortexRelationalScan},
    resident_session::ResidentVortexSession,
};
use shardloom_core::DatasetUri;
use shardloom_exec::compute_pool::CancellationToken;
use vortex::{
    array::arrays::{StructArray, struct_::StructArrayExt as _},
    file::WriteOptionsSessionExt as _,
    io::{
        runtime::{BlockingRuntime as _, current::CurrentThreadRuntime},
        session::RuntimeSessionExt as _,
    },
};

fn expected_json(fixture: &Fixture, kind: &str) -> Vec<serde_json::Value> {
    match &fixture.expected {
        Expected::Integers(values) => values
            .iter()
            .map(|value| serde_json::json!({"value": value}))
            .collect(),
        Expected::Bytes(values) => values
            .iter()
            .map(|value| {
                let value = value.as_ref().map(|bytes| {
                    if kind == "nullable_binary" {
                        bytes.iter().map(|byte| format!("{byte:02x}")).collect()
                    } else {
                        String::from_utf8(bytes.clone()).unwrap()
                    }
                });
                serde_json::json!({"value": value})
            })
            .collect(),
    }
}

fn write_fixture(path: &std::path::Path, fixture: &Fixture, encoding: &str, frames: usize) {
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let runtime = CurrentThreadRuntime::new();
    let producer = session(&memory).with_handle(runtime.handle());
    let array = encode(
        fixture,
        encoding,
        frames,
        &mut producer.create_execution_ctx(),
    );
    let rows = array.len();
    let array =
        StructArray::new(["value"].into(), vec![array], rows, Validity::NonNullable).into_array();
    let file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .unwrap();
    let mut writer = producer
        .write_options()
        .with_strategy(
            crate::local_primitives::native_flat_layout::SequentialNativeFlatLayout::strategy(1),
        )
        .with_file_statistics(Vec::new())
        .blocking(&runtime)
        .writer(file, array.dtype().clone());
    writer.push(array).unwrap();
    writer.finish().unwrap();
    drop(producer);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

fn operation(
    prepared: &PreparedVortexRelational,
    fixture: &Fixture,
    expected: &[serde_json::Value],
    consumer: &str,
    profiled: bool,
    encoding: &str,
) -> serde_json::Value {
    let before = prepared.snapshot().memory.reserved_bytes;
    let mut native_outputs = Vec::new();
    let mut json_outputs = Vec::new();
    if profiled {
        preparation_profile::begin();
    }
    let started = Instant::now();
    let execution = if consumer == "native_canonical_2048" {
        prepared
            .for_each_batch(&CancellationToken::default(), |array, context| {
                let mut execution = context.native_session().create_execution_ctx();
                let fields = array.execute::<StructArray>(&mut execution).unwrap();
                let output = fields
                    .unmasked_field_by_name("value")
                    .unwrap()
                    .clone()
                    .execute::<Canonical>(&mut execution)
                    .unwrap()
                    .into_array();
                native_outputs.push(output);
                Ok(())
            })
            .unwrap()
    } else {
        let rows = if consumer == "json_64" { 64 } else { 2048 };
        prepared
            .for_each_json_batch(&CancellationToken::default(), rows, 2 << 20, |batch| {
                json_outputs.push(batch);
                Ok(())
            })
            .unwrap()
    };
    let elapsed = started.elapsed().as_nanos();
    let profile = if profiled {
        preparation_profile::finish()
    } else {
        Snapshot::default()
    };
    let retained = prepared.snapshot().memory.reserved_bytes;
    assert_eq!(execution.output_rows as usize, fixture.input.len());
    assert_eq!(execution.output_columns, ["value"]);
    assert!(
        !execution
            .native_io_certificate
            .side_effects
            .fallback_attempted
    );
    if profiled {
        if encoding == "canonical" {
            assert_eq!(profile.calls[1], 0);
        } else {
            assert!(profile.calls[1] > 0, "missing real decoder activation");
            assert_eq!(profile.calls[1], profile.calls[2]);
            assert_eq!(profile.calls[2], profile.calls[3]);
        }
    }
    let output_batches = execution.output_batches;
    let scan_batches = execution.scan_batches;
    let mut offset = 0;
    let verify_memory = LiveMemoryPool::new(GRANT).unwrap();
    let verifier = session(&verify_memory);
    for output in native_outputs {
        let end = offset + output.len();
        assert_eq!(output.dtype(), fixture.input.dtype());
        verify_values(
            output,
            &slice_fixture(fixture, offset..end),
            &mut verifier.create_execution_ctx(),
        );
        offset = end;
    }
    for output in json_outputs {
        let values: Vec<serde_json::Value> =
            serde_json::from_str(output.values_json.value()).unwrap();
        let end = offset + values.len();
        assert_eq!(values, expected[offset..end]);
        offset = end;
    }
    assert_eq!(offset, fixture.input.len());
    drop(execution);
    drop(verifier);
    assert_eq!(verify_memory.snapshot().reserved_bytes, 0);
    assert_eq!(prepared.snapshot().memory.reserved_bytes, before);
    serde_json::json!({
        "engine_execution_nanoseconds": elapsed,
        "output_batches": output_batches,
        "scan_batches": scan_batches,
        "reserved_before": before,
        "reserved_with_complete_output": retained,
        "reserved_after": prepared.snapshot().memory.reserved_bytes,
        "profile": profile_json(profile),
        "all_values_types_nulls_order_verified": true,
    })
}

#[test]
#[ignore = "frozen codec production-workflow attribution only"]
fn native_zstd_complete_workflow_preparation_attribution() {
    assert_eq!(
        std::env::var("SHARDLOOM_CODEC_WORKFLOW_ATTRIBUTION").as_deref(),
        Ok("frozen-v1")
    );
    let root = std::path::PathBuf::from(std::env::var("SHARDLOOM_CODEC_WORKFLOW_ROOT").unwrap());
    assert!(
        root.starts_with("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
    );
    std::fs::create_dir(&root).unwrap();
    for kind in ["nullable_i64", "nullable_utf8", "nullable_binary"] {
        for rows in [4096, 65_536] {
            let fixture = fixture(kind, rows);
            let expected = expected_json(&fixture, kind);
            let frames = if rows == 4096 { 128 } else { 1024 };
            for encoding in ["canonical", "zstd_no_dictionary", "zstd_dictionary"] {
                let path = root.join(format!("{kind}-{rows}-{encoding}.vortex"));
                write_fixture(&path, &fixture, encoding, frames);
                let bytes = std::fs::read(&path).unwrap();
                let digest: String = Sha256::digest(&bytes)
                    .iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect();
                let physical_bytes = bytes.len();
                drop(bytes);
                let owner = ResidentVortexSession::new(GRANT, 1).unwrap();
                let memory = owner.memory().clone();
                let mut policy =
                    crate::VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 1).unwrap();
                policy.resource_envelope.memory_budget_bytes = GRANT;
                let plan = VortexRelationalPlan::Scan(VortexRelationalScan {
                    source_uri: DatasetUri::new(path.display().to_string()).unwrap(),
                    projection: shardloom_plan::ProjectionRequest::All,
                    predicate: None,
                });
                let preparation_started = Instant::now();
                let prepared = prepare_relational_in_session(&plan, policy, &owner).unwrap();
                let preparation_ns = preparation_started.elapsed().as_nanos();
                for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                    for sample in 0..=3 {
                        for profiled in if sample % 2 == 0 {
                            [false, true]
                        } else {
                            [true, false]
                        } {
                            let observations: Vec<_> = (0..if sample == 0 { 1 } else { 7 })
                                .map(|_| {
                                    operation(
                                        &prepared, &fixture, &expected, consumer, profiled,
                                        encoding,
                                    )
                                })
                                .collect();
                            println!(
                                "CODEC_WORKFLOW_ATTRIBUTION {}",
                                serde_json::json!({
                                    "kind": kind, "rows": rows, "encoding": encoding, "consumer": consumer,
                                    "sample": sample, "warmup": sample == 0, "profiled": profiled,
                                    "frame_rows": frames, "grant_bytes": GRANT,
                                    "preparation_nanoseconds": preparation_ns,
                                    "physical_bytes": physical_bytes, "physical_sha256": digest,
                                    "output_dtype": prepared.output_dtype().unwrap().to_string(),
                                    "observations": observations,
                                })
                            );
                        }
                    }
                }
                assert_eq!(prepared.snapshot().prepared_source_opens, 1);
                drop(prepared);
                drop(owner);
                assert_eq!(memory.snapshot().reserved_bytes, 0);
                std::fs::remove_file(&path).unwrap();
            }
        }
    }
    std::fs::remove_dir(&root).unwrap();
}
