"""Verify complete frozen codec workflow cohorts and apply prospective rules."""
import hashlib
import itertools
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
KINDS = ['nullable_i64', 'nullable_utf8', 'nullable_binary']
ROWS = [4096, 65536]
ENCODINGS = ['canonical', 'zstd_no_dictionary', 'zstd_dictionary']
CONSUMERS = ['native_canonical_2048', 'json_2048', 'json_64']
CELLS = set(itertools.product(KINDS, ROWS, ENCODINGS, CONSUMERS))
PREFIX = 'CODEC_WORKFLOW_ATTRIBUTION '

def evaluate(cohort):
    path = ROOT / f'codec-workflow-cohort-{cohort}-747.log'
    receipt = json.loads(path.with_suffix('.json').read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == receipt['log_sha256']
    records = [json.loads(line.split(PREFIX, 1)[1]) for line in path.read_text().splitlines() if PREFIX in line]
    assert len(records) == len(CELLS) * 8, len(records)
    by_key = {}
    identities = {}
    for record in records:
        cell = tuple(record[name] for name in ['kind', 'rows', 'encoding', 'consumer'])
        assert cell in CELLS
        key = cell + (record['sample'], record['profiled'])
        assert key not in by_key
        by_key[key] = record
        assert record['warmup'] == (record['sample'] == 0)
        assert len(record['observations']) == (1 if record['warmup'] else 7)
        identity_key = cell[:3]
        identity = (record['physical_bytes'], record['physical_sha256'])
        assert identities.setdefault(identity_key, identity) == identity
        for observation in record['observations']:
            assert observation['all_values_types_nulls_order_verified']
            assert observation['reserved_before'] == observation['reserved_after']
            assert observation['engine_execution_nanoseconds'] > 0
            profile = observation['profile']
            counts = [profile[stage]['calls'] for stage in ['decoder_allocation', 'decoder_initialization', 'decoder_frames']]
            if record['profiled'] and record['encoding'] != 'canonical':
                assert counts[0] > 0 and len(set(counts)) == 1
            else:
                assert counts == [0, 0, 0]
            if not record['profiled']:
                assert all(stage['nanoseconds'] == stage['calls'] == 0 for stage in profile.values())
    results = []
    qualified = set()
    for cell in sorted(CELLS):
        samples = []
        for sample in range(1, 4):
            enabled = by_key[cell + (sample, True)]['observations']
            disabled = by_key[cell + (sample, False)]['observations']
            fractions = [sum(o['profile'][stage]['nanoseconds'] for stage in ['decoder_allocation', 'decoder_initialization']) / o['engine_execution_nanoseconds'] for o in enabled]
            on_median = statistics.median(o['engine_execution_nanoseconds'] for o in enabled)
            off_median = statistics.median(o['engine_execution_nanoseconds'] for o in disabled)
            samples.append({
                'sample': sample,
                'setup_fraction_median': statistics.median(fractions),
                'profile_over_control_median': on_median / off_median,
                'control_engine_execution_nanoseconds_median': off_median,
                'decoder_calls': sorted(set(o['profile']['decoder_allocation']['calls'] for o in enabled)),
            })
        qualifies = all(s['setup_fraction_median'] >= 0.10 for s in samples)
        if qualifies:
            qualified.add(cell)
        results.append({'cell': cell, 'samples': samples, 'meets_10pct_all_samples': qualifies})
    return {'cells': results, 'qualified': sorted(qualified), 'identities': [{'cell': k, 'bytes': v[0], 'sha256': v[1]} for k, v in sorted(identities.items())]}, qualified

cohorts = {}
qualifications = []
for cohort in ['a', 'b']:
    cohorts[cohort], qualified = evaluate(cohort)
    qualifications.append(qualified)
assert cohorts['a']['identities'] == cohorts['b']['identities']
common = set.intersection(*qualifications)
result = {
    'status': 'passed',
    'protocol_sha256': hashlib.sha256((ROOT/'codec-workflow-attribution-protocol-747.json').read_bytes()).hexdigest(),
    'cohorts': cohorts,
    'repeatedly_qualified_cells': sorted(common),
    'advance_candidate_materiality_gate': len(common) >= 2,
    'claim': 'Production-workflow attribution only; no retained candidate or speedup claim.',
}
out = ROOT / 'codec-workflow-analysis-747.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'cells_per_cohort': len(CELLS), 'common_qualified_cells': sorted(common), 'advance': len(common) >= 2, 'output': str(out)}, indent=2))
