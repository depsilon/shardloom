// SPDX-License-Identifier: Apache-2.0
//! Complete production workflows for frozen dictionary candidate 748.

use super::*;
use crate::{
    local_primitives::prepared_relational::{
        PreparedVortexRelational, prepare_relational_in_session,
    },
    relational_query::{VortexRelationalPlan, VortexRelationalScan},
    resident_session::ResidentVortexSession,
};
use shardloom_core::{DatasetUri, ShardLoomError};
use shardloom_exec::compute_pool::CancellationToken;
use vortex::{
    array::arrays::{StructArray, struct_::StructArrayExt as _},
    file::WriteOptionsSessionExt as _,
    io::{
        runtime::{BlockingRuntime as _, current::CurrentThreadRuntime},
        session::RuntimeSessionExt as _,
    },
};

fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn expected_json(fixture: &Fixture, kind: &str) -> Vec<serde_json::Value> {
    match &fixture.expected {
        Expected::Integers(values) => values
            .iter()
            .map(|value| serde_json::json!({"value": value}))
            .collect(),
        Expected::Bytes(values) => values
            .iter()
            .map(|value| {
                let value = value.as_ref().map(|bytes| byte_value(bytes, kind));
                serde_json::json!({"value": value})
            })
            .collect(),
    }
}

fn byte_value(bytes: &[u8], kind: &str) -> String {
    if kind == "nullable_binary" {
        bytes.iter().map(|byte| format!("{byte:02x}")).collect()
    } else {
        String::from_utf8(bytes.to_vec()).unwrap()
    }
}

fn native_json(input: &ArrayRef, kind: &str, ctx: &mut ExecutionCtx) -> Vec<serde_json::Value> {
    if kind == "nullable_i64" {
        let values = input.clone().execute::<PrimitiveArray>(ctx).unwrap();
        let valid = values
            .validity()
            .unwrap()
            .execute_mask(values.len(), ctx)
            .unwrap();
        values
            .as_slice::<i64>()
            .iter()
            .enumerate()
            .map(|(index, value)| serde_json::json!({"value": valid.value(index).then_some(value)}))
            .collect()
    } else {
        let values = input.clone().execute::<VarBinViewArray>(ctx).unwrap();
        let valid = values
            .validity()
            .unwrap()
            .execute_mask(values.len(), ctx)
            .unwrap();
        (0..values.len())
            .map(|index| {
                let value = valid
                    .value(index)
                    .then(|| byte_value(values.bytes_at(index).as_slice(), kind));
                serde_json::json!({"value": value})
            })
            .collect()
    }
}

fn write_fixture(path: &std::path::Path, fixture: &Fixture, encoding: &str, frames: usize) {
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let runtime = CurrentThreadRuntime::new();
    let producer = session(&memory).with_handle(runtime.handle());
    let array = encode(
        fixture,
        encoding,
        frames,
        &mut producer.create_execution_ctx(),
    );
    let rows = array.len();
    let array =
        StructArray::new(["value"].into(), vec![array], rows, Validity::NonNullable).into_array();
    let file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .unwrap();
    let mut writer = producer
        .write_options()
        .with_strategy(
            crate::local_primitives::native_flat_layout::SequentialNativeFlatLayout::strategy(1),
        )
        .with_file_statistics(Vec::new())
        .blocking(&runtime)
        .writer(file, array.dtype().clone());
    writer.push(array).unwrap();
    writer.finish().unwrap();
    drop(producer);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

fn operation(
    prepared: &PreparedVortexRelational,
    fixture: &Fixture,
    expected: &[serde_json::Value],
    kind: &str,
    consumer: &str,
) -> serde_json::Value {
    let mut native = Vec::new();
    let mut json = Vec::new();
    let started = Instant::now();
    let execution = if consumer == "native_canonical_2048" {
        prepared
            .for_each_batch(&CancellationToken::default(), |array, context| {
                let mut ctx = context.native_session().create_execution_ctx();
                let fields = array.execute::<StructArray>(&mut ctx).unwrap();
                let output = fields
                    .unmasked_field_by_name("value")
                    .unwrap()
                    .clone()
                    .execute::<Canonical>(&mut ctx)
                    .unwrap()
                    .into_array();
                native.push(output);
                Ok(())
            })
            .unwrap()
    } else {
        prepared
            .for_each_json_batch(
                &CancellationToken::default(),
                if consumer == "json_64" { 64 } else { 2048 },
                2 << 20,
                |batch| {
                    json.push(batch);
                    Ok(())
                },
            )
            .unwrap()
    };
    let execute_ns = started.elapsed().as_nanos();
    let with_output = prepared.snapshot().memory.reserved_bytes;
    assert_eq!(execution.output_rows as usize, fixture.input.len());
    assert_eq!(execution.output_columns, ["value"]);
    assert!(
        !execution
            .native_io_certificate
            .side_effects
            .fallback_attempted
    );
    let verify_memory = LiveMemoryPool::new(GRANT).unwrap();
    let verifier = session(&verify_memory);
    let dtype = DType::struct_(
        [("value", fixture.input.dtype().clone())],
        Nullability::NonNullable,
    );
    let expected_schema =
        crate::local_primitives::collect::serialize_result_schema(&dtype, &verify_memory).unwrap();
    let schema_hash = digest(expected_schema.value().as_bytes());
    let mut actual = Vec::with_capacity(expected.len());
    for output in &native {
        assert_eq!(output.dtype(), fixture.input.dtype());
        actual.extend(native_json(
            output,
            kind,
            &mut verifier.create_execution_ctx(),
        ));
    }
    for output in &json {
        assert_eq!(output.result_schema_json.value(), expected_schema.value());
        let values: Vec<serde_json::Value> =
            serde_json::from_str(output.values_json.value()).unwrap();
        assert_eq!(values.len(), output.rows);
        actual.extend(values);
    }
    assert_eq!(actual, expected);
    let values_hash = digest(&serde_json::to_vec(&actual).unwrap());
    let output_batches = execution.output_batches;
    let scan_batches = execution.scan_batches;
    let release = Instant::now();
    drop((native, json, execution));
    let release_ns = release.elapsed().as_nanos();
    drop((expected_schema, verifier));
    assert_eq!(verify_memory.snapshot().reserved_bytes, 0);
    serde_json::json!({
        "native_workflow_nanoseconds": execute_ns,
        "output_release_nanoseconds": release_ns,
        "values_sha256": values_hash, "schema_sha256": schema_hash,
        "output_batches": output_batches, "scan_batches": scan_batches,
        "reserved_with_complete_output": with_output,
        "reserved_after_output": prepared.snapshot().memory.reserved_bytes,
        "all_values_types_nulls_order_verified": true,
        "source_validation_included": true,
    })
}

#[allow(clippy::too_many_arguments)]
fn sample(
    path: &std::path::Path,
    fixture: &Fixture,
    expected: &[serde_json::Value],
    kind: &str,
    consumer: &str,
    candidate: bool,
    operations: usize,
) -> serde_json::Value {
    let initialize = Instant::now();
    let owner = ResidentVortexSession::new(GRANT, 1).unwrap();
    let memory = owner.memory().clone();
    let cache = candidate.then(|| {
        owner
            .with_native_session(|session, _| {
                crate::native_provider_codec_cache::install(session, &memory)
                    .map_err(|error| ShardLoomError::InvalidOperation(error.to_string()))
            })
            .unwrap()
    });
    let mut policy = crate::VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 1).unwrap();
    policy.resource_envelope.memory_budget_bytes = GRANT;
    let plan = VortexRelationalPlan::Scan(VortexRelationalScan {
        source_uri: DatasetUri::new(path.display().to_string()).unwrap(),
        projection: shardloom_plan::ProjectionRequest::All,
        predicate: None,
    });
    let prepared = prepare_relational_in_session(&plan, policy, &owner).unwrap();
    let initialize_ns = initialize.elapsed().as_nanos();
    let source_credit = memory.snapshot().reserved_bytes;
    let mut observations = Vec::with_capacity(operations);
    for _ in 0..operations {
        observations.push(operation(&prepared, fixture, expected, kind, consumer));
        let idle = cache
            .as_ref()
            .map_or(0, |cache| cache.snapshot().idle_bytes);
        let idle_credit = if idle == 0 { 0 } else { idle as u64 + 2 * 256 };
        assert_eq!(
            memory.snapshot().reserved_bytes,
            source_credit + idle_credit
        );
    }
    assert_eq!(prepared.snapshot().prepared_source_opens, 1);
    let cache_state = cache.as_ref().map(|cache| cache.snapshot());
    let before_cleanup = memory.snapshot();
    let cleanup = Instant::now();
    drop((prepared, owner, cache, plan));
    let cleanup_ns = cleanup.elapsed().as_nanos();
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let workflow_total: u128 = observations
        .iter()
        .map(|value| {
            u128::from(value["native_workflow_nanoseconds"].as_u64().unwrap())
                + u128::from(value["output_release_nanoseconds"].as_u64().unwrap())
        })
        .sum();
    serde_json::json!({
        "candidate": candidate, "operations": operations,
        "initialize_and_prepare_nanoseconds": initialize_ns,
        "cleanup_nanoseconds": cleanup_ns,
        "complete_lifecycle_nanoseconds": initialize_ns + workflow_total + cleanup_ns,
        "source_retained_bytes": source_credit,
        "peak_reserved_bytes": before_cleanup.peak_reserved_bytes,
        "denied_reservations": before_cleanup.denied_reservations,
        "final_reserved_bytes": memory.snapshot().reserved_bytes,
        "cache": cache_state.map(|state| serde_json::json!({
            "hits": state.hits, "misses": state.misses, "prepared": state.prepared,
            "declined": state.declined, "evicted": state.evicted,
            "returned": state.returned, "idle_bytes": state.idle_bytes,
        })),
        "observations": observations,
    })
}

#[test]
#[ignore = "frozen complete workflow comparison; explicit guarded candidate 748"]
fn native_zstd_cache_complete_workflow_comparison() {
    assert_eq!(
        std::env::var("SHARDLOOM_CODEC_CACHE_COMPARISON").as_deref(),
        Ok("frozen-v1")
    );
    let root = std::path::PathBuf::from(std::env::var("SHARDLOOM_CODEC_CACHE_ROOT").unwrap());
    assert!(
        root.starts_with("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
    );
    std::fs::create_dir(&root).unwrap();
    let mut cell = 0;
    for kind in ["nullable_i64", "nullable_utf8", "nullable_binary"] {
        for rows in [4096, 65_536] {
            let fixture = fixture(kind, rows);
            let expected = expected_json(&fixture, kind);
            let frames = if rows == 4096 { 128 } else { 1024 };
            for encoding in ["canonical", "zstd_no_dictionary", "zstd_dictionary"] {
                let path = root.join(format!("{kind}-{rows}-{encoding}.vortex"));
                write_fixture(&path, &fixture, encoding, frames);
                let bytes = std::fs::read(&path).unwrap();
                let physical_sha256 = digest(&bytes);
                let physical_bytes = bytes.len();
                drop(bytes);
                for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                    cell += 1;
                    for index in 0..=3 {
                        for candidate in if (cell + index) % 2 == 0 {
                            [false, true]
                        } else {
                            [true, false]
                        } {
                            let observed = sample(
                                &path,
                                &fixture,
                                &expected,
                                kind,
                                consumer,
                                candidate,
                                if index == 0 { 1 } else { 7 },
                            );
                            if candidate && encoding == "zstd_dictionary" {
                                assert!(observed["cache"]["hits"].as_u64().unwrap() > 0);
                                assert_eq!(observed["cache"]["prepared"], 1);
                            } else if candidate {
                                assert_eq!(observed["cache"]["prepared"], 0);
                                assert_eq!(observed["cache"]["hits"], 0);
                            }
                            println!(
                                "CODEC_CACHE_WORKFLOW {}",
                                serde_json::json!({
                                    "kind": kind, "rows": rows, "encoding": encoding,
                                    "consumer": consumer, "sample": index, "warmup": index == 0,
                                    "frame_rows": frames, "grant_bytes": GRANT,
                                    "physical_bytes": physical_bytes, "physical_sha256": physical_sha256,
                                    "observation": observed,
                                })
                            );
                        }
                    }
                }
                std::fs::remove_file(&path).unwrap();
            }
        }
    }
    assert_eq!(cell, 54);
    std::fs::remove_dir(&root).unwrap();
}

#[test]
#[ignore = "guarded two-process portable file proof before candidate timing"]
fn native_zstd_cache_portable_files_without_retained_session() {
    let phase = std::env::var("SHARDLOOM_CODEC_PORTABILITY_PHASE").unwrap();
    assert!(matches!(phase.as_str(), "write" | "read"));
    let root = std::path::PathBuf::from(std::env::var("SHARDLOOM_CODEC_PORTABILITY_ROOT").unwrap());
    assert!(
        root.starts_with("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
    );
    let manifest_path = root.with_extension("json");
    let prior: Vec<serde_json::Value> = if phase == "write" {
        std::fs::create_dir(&root).unwrap();
        assert!(!manifest_path.exists());
        Vec::new()
    } else {
        serde_json::from_slice(&std::fs::read(&manifest_path).unwrap()).unwrap()
    };
    let mut observed = Vec::new();
    for kind in ["nullable_i64", "nullable_utf8", "nullable_binary"] {
        for rows in [4096, 65_536] {
            let fixture = fixture(kind, rows);
            let expected = expected_json(&fixture, kind);
            let frames = if rows == 4096 { 128 } else { 1024 };
            for encoding in ["canonical", "zstd_no_dictionary", "zstd_dictionary"] {
                let path = root.join(format!("{kind}-{rows}-{encoding}.vortex"));
                if phase == "write" {
                    write_fixture(&path, &fixture, encoding, frames);
                }
                let hash = digest(&std::fs::read(&path).unwrap());
                if phase == "read" {
                    let original = &prior[observed.len()];
                    assert_eq!(
                        original["file"],
                        path.file_name().unwrap().to_str().unwrap()
                    );
                    assert_eq!(original["sha256"], hash);
                    assert_ne!(original["writer_process"], std::process::id());
                }
                // The writer process exercises its cache, then exits. The reader
                // creates ordinary owners, with no marker or retained dictionary.
                for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                    let result = sample(
                        &path,
                        &fixture,
                        &expected,
                        kind,
                        consumer,
                        phase == "write",
                        1,
                    );
                    assert_eq!(result["final_reserved_bytes"], 0);
                    if phase == "read" {
                        assert!(result["cache"].is_null());
                    }
                }
                observed.push(serde_json::json!({
                    "file": path.file_name().unwrap().to_str().unwrap(),
                    "sha256": hash, "writer_process": std::process::id(),
                }));
                if phase == "read" {
                    std::fs::remove_file(path).unwrap();
                }
            }
        }
    }
    assert_eq!(observed.len(), 18);
    if phase == "write" {
        std::fs::write(manifest_path, serde_json::to_vec_pretty(&observed).unwrap()).unwrap();
    } else {
        assert_eq!(prior.len(), observed.len());
        std::fs::remove_dir(root).unwrap();
    }
    println!(
        "CODEC_CACHE_PORTABILITY phase={phase} files=18 workflows=54 all_values_verified=true final_reserved_bytes=0"
    );
}
