//! Opt-in experiment binding one native dictionary cache to its shared pool.

use std::{any::Any, sync::Arc};

use shardloom_exec::live_memory::{IdleMemoryReclaimer, LiveMemoryPool};
use vortex::{
    error::{VortexResult, vortex_ensure, vortex_err},
    session::{SessionVar, VortexSession},
};
use vortex_zstd::preparation_cache::{self, DictionaryCache};

#[derive(Clone, Debug)]
struct CacheOwner(Arc<DictionaryCache>);

impl IdleMemoryReclaimer for CacheOwner {
    fn reclaim_idle(&self) -> bool {
        self.0.reclaim_idle()
    }
}

/// Test-only admission: production installation awaits the frozen acceptance.
pub(crate) fn install(
    session: &VortexSession,
    memory: &LiveMemoryPool,
) -> VortexResult<Arc<DictionaryCache>> {
    vortex_ensure!(
        !preparation_cache::is_installed(session),
        "Native Zstd dictionary preparation is already configured"
    );
    let cache = Arc::new(DictionaryCache::default());
    let owner = Arc::new(CacheOwner(Arc::clone(&cache)));
    let reclaimer: Arc<dyn IdleMemoryReclaimer> = owner.clone();
    memory
        .register_idle_reclaimer(Arc::downgrade(&reclaimer))
        .map_err(|error| vortex_err!("{error}"))?;
    // The session owns the strong reclaimer; the pool holds only its weak link.
    // Buffer leases may retain the pool but cannot retain the cache through it.
    session.register(CacheOwnerSession { _owner: owner });
    preparation_cache::install(session, Arc::clone(&cache))?;
    Ok(cache)
}

#[derive(Clone, Debug)]
struct CacheOwnerSession {
    _owner: Arc<CacheOwner>,
}

impl SessionVar for CacheOwnerSession {
    fn as_any(&self) -> &dyn Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn Any {
        self
    }
}
