// SPDX-License-Identifier: Apache-2.0
//! Correctness/resource prerequisites for frozen candidate 748.

use super::*;
use std::sync::Barrier;
use vortex::array::Canonical;
use vortex::buffer::ByteBuffer;
use vortex_zstd::preparation_cache::DictionaryCache;

#[path = "native_provider_zstd_cache_workflow_tests.rs"]
mod workflow_tests;

#[path = "native_provider_zstd_cache_adversarial_tests.rs"]
mod adversarial_tests;

fn cached_session(memory: &LiveMemoryPool) -> (VortexSession, Arc<DictionaryCache>) {
    let session = session(memory);
    let cache = crate::native_provider_codec_cache::install(&session, memory).unwrap();
    (session, cache)
}

fn encode(
    fixture: &Fixture,
    encoding: &str,
    frame_rows: usize,
    ctx: &mut ExecutionCtx,
) -> ArrayRef {
    if encoding == "canonical" {
        return fixture.input.clone();
    }
    if let Some(values) = fixture.input.as_opt::<Primitive>() {
        let values = values.into_owned();
        let data = if encoding == "zstd_dictionary" {
            ZstdData::from_primitive(&values, 0, frame_rows, ctx)
        } else {
            ZstdData::from_primitive_without_dict(&values, 0, frame_rows, ctx)
        }
        .unwrap();
        Zstd::try_new(values.dtype().clone(), data, values.validity().unwrap())
            .unwrap()
            .into_array()
    } else {
        let values = fixture.input.as_::<VarBinView>().into_owned();
        if encoding == "zstd_dictionary" {
            Zstd::from_var_bin_view(&values, 0, frame_rows, ctx)
        } else {
            Zstd::from_var_bin_view_without_dict(&values, 0, frame_rows, ctx)
        }
        .unwrap()
        .into_array()
    }
}

fn slice_fixture(source: &Fixture, range: std::ops::Range<usize>) -> Fixture {
    Fixture {
        input: source.input.slice(range.clone()).unwrap(),
        expected: match &source.expected {
            Expected::Integers(values) => Expected::Integers(values[range].to_vec()),
            Expected::Bytes(values) => Expected::Bytes(values[range].to_vec()),
        },
    }
}

fn with_dictionary(input: &ArrayRef, dictionary: Vec<u8>) -> ArrayRef {
    let parts = input
        .as_::<Zstd>()
        .data()
        .clone()
        .into_parts(input.validity().unwrap());
    let mut metadata = parts.metadata;
    metadata.dictionary_size = u32::try_from(dictionary.len()).unwrap();
    Zstd::try_new(
        input.dtype().clone(),
        ZstdData::new(
            Some(ByteBuffer::from(dictionary)),
            parts.frames,
            metadata,
            parts.n_rows,
        ),
        parts.validity,
    )
    .unwrap()
    .into_array()
}

fn assert_idle_credit(memory: &LiveMemoryPool, cache: &DictionaryCache) {
    let idle = cache.snapshot().idle_bytes;
    assert!(idle <= 128 << 10);
    assert_eq!(
        memory.snapshot().reserved_bytes,
        if idle == 0 { 0 } else { idle as u64 + 2 * 256 },
        "one dictionary copy and one DDict workspace, including alignment"
    );
}

#[test]
fn native_zstd_cache_preserves_all_types_nulls_slices_and_empty_controls() {
    for kind in ["nullable_i64", "nullable_utf8", "nullable_binary"] {
        let fixture = fixture(kind, 4096);
        for encoding in ["canonical", "zstd_no_dictionary", "zstd_dictionary"] {
            let input = encode(
                &fixture,
                encoding,
                128,
                &mut VortexSession::default().create_execution_ctx(),
            );
            let memory = LiveMemoryPool::new(GRANT).unwrap();
            let (session, cache) = cached_session(&memory);
            let mut ctx = session.create_execution_ctx();
            for _ in 0..2 {
                verify_values(input.clone(), &fixture, &mut ctx);
                for range in [0..0, 0..1, 13..97, 3900..4096] {
                    let expected = slice_fixture(&fixture, range.clone());
                    let output = input.slice(range).unwrap();
                    assert_eq!(output.dtype(), expected.input.dtype());
                    assert_eq!(output.len(), expected.input.len());
                    verify_values(output, &expected, &mut ctx);
                }
                assert_idle_credit(&memory, &cache);
            }
            let snapshot = cache.snapshot();
            if encoding == "zstd_dictionary" {
                assert_eq!(snapshot.prepared, 1);
                assert!(snapshot.hits >= 5);
                assert!(snapshot.idle_bytes > 0);
                assert!(cache.reclaim_idle());
            } else {
                assert_eq!(snapshot, Default::default());
            }
            assert_eq!(memory.snapshot().reserved_bytes, 0);
        }
    }
}

#[test]
fn native_zstd_cache_uses_exact_content_across_distinct_dictionary_owners() {
    let base = primitive(&PrimitiveArray::from_iter([17i64]));
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    for (index, byte) in [b'a', b'a', b'b', b'a'].into_iter().enumerate() {
        let input = with_dictionary(&base, vec![byte; 64]);
        let output = input
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap();
        assert_eq!(output.as_slice::<i64>(), &[17]);
        drop(output);
        let observed = cache.snapshot();
        assert_eq!(observed.hits, u64::from(index > 0));
        assert_eq!(observed.prepared, if index < 2 { 1 } else { index as u64 });
        assert_idle_credit(&memory, &cache);
    }
    assert!(cache.reclaim_idle());
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_zstd_cache_declines_optional_retention_at_the_original_exact_grant() {
    let fixture = fixture("nullable_i64", 4096);
    let input = encode(
        &fixture,
        "zstd_dictionary",
        128,
        &mut VortexSession::default().create_execution_ctx(),
    );
    let baseline = LiveMemoryPool::new(GRANT).unwrap();
    verify_values(
        input.clone(),
        &fixture,
        &mut session(&baseline).create_execution_ctx(),
    );
    assert_eq!(baseline.snapshot().reserved_bytes, 0);
    let peak = baseline.snapshot().peak_reserved_bytes;
    for limit in [peak, peak - 1] {
        let memory = LiveMemoryPool::new(limit).unwrap();
        let (session, cache) = cached_session(&memory);
        let result = input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx());
        if limit == peak {
            let output = result.unwrap();
            verify_values(
                output.into_array(),
                &fixture,
                &mut session.create_execution_ctx(),
            );
        } else {
            assert!(crate::owned_buffers::is_owned_reservation_denial(
                &result.unwrap_err()
            ));
        }
        assert_eq!(cache.snapshot().idle_bytes, 0);
        assert!(cache.snapshot().declined > 0);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
}

#[test]
fn native_zstd_cache_is_reclaimed_by_ordinary_pressure_and_allocation_reduction() {
    let base = primitive(&PrimitiveArray::from_iter([17i64]));
    let input = with_dictionary(&base, vec![b'a'; 64]);
    let memory = LiveMemoryPool::configurable(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    for _ in 0..2 {
        let output = input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap();
        assert_eq!(output.as_slice::<i64>(), &[17]);
        drop(output);
    }
    assert_eq!(cache.snapshot().hits, 1);
    assert_idle_credit(&memory, &cache);
    let ordinary = memory.reserve(GRANT).unwrap();
    assert_eq!(cache.snapshot().idle_bytes, 0);
    assert_eq!(cache.snapshot().evicted, 1);
    drop(ordinary);
    drop(
        input
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap(),
    );
    assert!(cache.snapshot().idle_bytes > 0);
    memory.set_limit_bytes(1).unwrap();
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert_eq!(cache.snapshot().idle_bytes, 0);
    assert_eq!(cache.snapshot().evicted, 2);
}

#[test]
fn native_zstd_cache_owner_drop_releases_all_buffers_without_a_pool_cycle() {
    let input = with_dictionary(
        &primitive(&PrimitiveArray::from_iter([17i64])),
        vec![b'a'; 64],
    );
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    let weak = Arc::downgrade(&cache);
    drop(
        input
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap(),
    );
    assert_idle_credit(&memory, &cache);
    assert!(crate::native_provider_codec_cache::install(&session, &memory).is_err());
    drop(cache);
    assert!(weak.upgrade().is_some());
    drop(session);
    assert!(weak.upgrade().is_none());
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let ordinary = memory.reserve(GRANT).unwrap();
    drop(ordinary);
}

#[test]
fn native_zstd_cache_concurrent_decode_and_pressure_preserve_complete_values() {
    let fixture = fixture("nullable_i64", 4096);
    let input = encode(
        &fixture,
        "zstd_dictionary",
        128,
        &mut VortexSession::default().create_execution_ctx(),
    );
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    let barrier = Barrier::new(5);
    std::thread::scope(|scope| {
        for _ in 0..4 {
            let barrier = &barrier;
            let input = &input;
            let fixture = &fixture;
            let session = &session;
            scope.spawn(move || {
                barrier.wait();
                for _ in 0..24 {
                    verify_values(input.clone(), fixture, &mut session.create_execution_ctx());
                }
            });
        }
        barrier.wait();
        for _ in 0..128 {
            cache.reclaim_idle();
            let retained = memory.reserve(GRANT / 2).unwrap();
            assert!(memory.snapshot().reserved_bytes <= GRANT);
            drop(retained);
        }
    });
    assert_idle_credit(&memory, &cache);
    assert!(cache.snapshot().prepared > 0);
    cache.reclaim_idle();
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert_eq!(memory.snapshot().denied_reservations, 0);
}

#[test]
fn native_zstd_cache_invalid_dictionary_and_decoder_failure_release_the_lease() {
    let base = primitive(&PrimitiveArray::from_iter([17i64]));
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    let input = with_dictionary(&base, vec![b'a'; 64]);
    drop(
        input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap(),
    );
    let mut bad_dictionary = 0xEC30_A437u32.to_le_bytes().to_vec();
    bad_dictionary.extend_from_slice(&1u32.to_le_bytes());
    let error = with_dictionary(&base, bad_dictionary)
        .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
        .unwrap_err();
    assert!(!crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    drop(
        input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap(),
    );
    let mut parts = input
        .as_::<Zstd>()
        .data()
        .clone()
        .into_parts(input.validity().unwrap());
    let mut frame = vec![0x28, 0xb5, 0x2f, 0xfd, 0x24, 8, 0x41, 0, 0];
    frame.extend_from_slice(&17i64.to_ne_bytes());
    frame.extend_from_slice(&[0; 4]);
    parts.frames[0] = ByteBuffer::from(frame);
    let corrupt = Zstd::try_new(
        input.dtype().clone(),
        ZstdData::new(parts.dictionary, parts.frames, parts.metadata, parts.n_rows),
        parts.validity,
    )
    .unwrap()
    .into_array();
    let error = corrupt
        .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
        .unwrap_err();
    assert!(!crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(cache.snapshot().hits, 1);
    assert_eq!(cache.snapshot().idle_bytes, 0);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_zstd_cache_does_not_retain_empty_or_oversized_raw_dictionaries() {
    let base = primitive(&PrimitiveArray::from_iter([17i64]));
    for bytes in [0, 65_537] {
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let (session, cache) = cached_session(&memory);
        let input = with_dictionary(&base, vec![b'x'; bytes]);
        let output = input
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap();
        assert_eq!(output.as_slice::<i64>(), &[17]);
        drop(output);
        assert_eq!(cache.snapshot(), Default::default());
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
}

#[test]
fn native_zstd_cache_all_null_selection_constructs_no_preparation() {
    let values = PrimitiveArray::from_option_iter([None::<i64>; 33]);
    let input = with_dictionary(&primitive(&values), vec![b'x'; 64]);
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    let mut ctx = session.create_execution_ctx();
    let output = input.execute::<PrimitiveArray>(&mut ctx).unwrap();
    assert_eq!(output.dtype(), values.dtype());
    assert_eq!(output.len(), 33);
    assert_eq!(
        output
            .validity()
            .unwrap()
            .execute_mask(33, &mut ctx)
            .unwrap()
            .true_count(),
        0
    );
    drop(output);
    assert_eq!(cache.snapshot(), Default::default());
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_zstd_cache_same_length_trained_dictionary_change_is_not_a_hit() {
    let fixture = fixture("nullable_i64", 4096);
    let input = encode(
        &fixture,
        "zstd_dictionary",
        128,
        &mut VortexSession::default().create_execution_ctx(),
    );
    let parts = input
        .as_::<Zstd>()
        .data()
        .clone()
        .into_parts(input.validity().unwrap());
    let mut changed = parts.dictionary.unwrap().as_slice().to_vec();
    changed[0] ^= 1; // Same length and ID bytes, different complete dictionary.
    let changed = with_dictionary(&input, changed);
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    verify_values(input, &fixture, &mut session.create_execution_ctx());
    assert_eq!(cache.snapshot().prepared, 1);
    let error = changed
        .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
        .unwrap_err();
    assert!(!crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(cache.snapshot().hits, 0);
    assert_eq!(cache.snapshot().misses, 2);
    assert_eq!(cache.snapshot().idle_bytes, 0);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[derive(Debug)]
struct RelocatingAllocator {
    inner: crate::owned_buffers::ReservedHostAllocator,
    allocations: std::sync::atomic::AtomicUsize,
    corrupt_workspace: bool,
}

impl vortex::array::memory::HostAllocator for RelocatingAllocator {
    fn allocate(
        &self,
        len: usize,
        alignment: Alignment,
    ) -> VortexResult<vortex::array::memory::WritableHostBuffer> {
        let buffer = vortex::array::memory::HostAllocator::allocate(&self.inner, len, alignment)?;
        let call = self
            .allocations
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        if matches!(call, 2 | 3) {
            Ok(vortex::array::memory::WritableHostBuffer::new(Box::new(
                RelocatingBuffer {
                    buffer,
                    corrupt: call == 3 && self.corrupt_workspace,
                },
            )))
        } else {
            Ok(buffer)
        }
    }
}

struct RelocatingBuffer {
    buffer: vortex::array::memory::WritableHostBuffer,
    corrupt: bool,
}

struct RelocatedOwner {
    bytes: ByteBuffer,
    _original: ByteBuffer,
}

impl AsRef<[u8]> for RelocatedOwner {
    fn as_ref(&self) -> &[u8] {
        self.bytes.as_slice()
    }
}

impl vortex::array::memory::HostBufferMut for RelocatingBuffer {
    fn len(&self) -> usize {
        self.buffer.len()
    }
    fn alignment(&self) -> Alignment {
        self.buffer.alignment()
    }
    fn as_mut_slice(&mut self) -> &mut [u8] {
        self.buffer.as_mut_slice()
    }
    fn freeze(self: Box<Self>) -> ByteBuffer {
        let Self {
            mut buffer,
            corrupt,
        } = *self;
        // Deliberate test-only allocator relocation. Keep the original credited
        // owner as well; this custom allocator is not a resource-cost observation.
        let mut bytes = ByteBufferMut::empty();
        bytes.extend_from_slice(buffer.as_mut_slice());
        if corrupt {
            bytes[8] ^= 1;
        }
        let owner = RelocatedOwner {
            bytes: bytes.freeze(),
            _original: buffer.freeze(),
        };
        ByteBuffer::from_bytes_aligned(bytes::Bytes::from_owner(owner), Alignment::new(8))
    }
}

#[test]
fn native_zstd_cache_accepts_exact_relocation_and_rejects_changed_frozen_workspace() {
    for corrupt_workspace in [false, true] {
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let allocator = Arc::new(RelocatingAllocator {
            inner: crate::owned_buffers::ReservedHostAllocator::new(memory.clone()),
            allocations: std::sync::atomic::AtomicUsize::new(0),
            corrupt_workspace,
        });
        let session = VortexSession::default().with_allocator(allocator);
        crate::native_provider_memory::install(&session, memory.clone());
        let cache = crate::native_provider_codec_cache::install(&session, &memory).unwrap();
        let input = with_dictionary(
            &primitive(&PrimitiveArray::from_iter([17i64])),
            vec![b'a'; 64],
        );
        let output = input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx());
        if corrupt_workspace {
            assert!(
                output
                    .unwrap_err()
                    .to_string()
                    .contains("changed initialized bytes")
            );
            assert_eq!(cache.snapshot().idle_bytes, 0);
        } else {
            assert_eq!(output.unwrap().as_slice::<i64>(), &[17]);
            let repeated = input
                .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
                .unwrap();
            assert_eq!(repeated.as_slice::<i64>(), &[17]);
            assert_eq!(cache.snapshot().hits, 1);
            drop(repeated);
            cache.reclaim_idle();
        }
        drop((cache, session));
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
}
