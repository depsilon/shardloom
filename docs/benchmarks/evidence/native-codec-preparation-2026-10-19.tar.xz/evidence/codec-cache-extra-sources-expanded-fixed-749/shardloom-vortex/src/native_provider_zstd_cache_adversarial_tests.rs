// SPDX-License-Identifier: Apache-2.0
//! Remaining pre-timing cache lifetime and malformed-input controls.

use super::*;
use std::sync::{
    Mutex,
    atomic::{AtomicBool, AtomicUsize, Ordering},
    mpsc,
};
use std::time::Duration;
use vortex::array::memory::{HostAllocator, HostBufferMut, WritableHostBuffer};

#[test]
fn native_zstd_cache_concurrent_different_trained_dictionaries_preserve_values() {
    let cases: Vec<_> = ["nullable_i64", "nullable_utf8", "nullable_binary"]
        .into_iter()
        .map(|kind| {
            let fixture = fixture(kind, 4096);
            let input = encode(
                &fixture,
                "zstd_dictionary",
                128,
                &mut VortexSession::default().create_execution_ctx(),
            );
            (fixture, input)
        })
        .collect();
    let dictionaries: Vec<_> = cases
        .iter()
        .map(|(_, input)| {
            input
                .as_::<Zstd>()
                .data()
                .clone()
                .into_parts(input.validity().unwrap())
                .dictionary
                .unwrap()
        })
        .collect();
    for left in 0..dictionaries.len() {
        for right in left + 1..dictionaries.len() {
            assert_ne!(
                dictionaries[left].as_slice(),
                dictionaries[right].as_slice()
            );
        }
    }
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let (session, cache) = cached_session(&memory);
    let barrier = Barrier::new(cases.len() + 1);
    std::thread::scope(|scope| {
        for (fixture, input) in &cases {
            let barrier = &barrier;
            let session = &session;
            scope.spawn(move || {
                barrier.wait();
                for _ in 0..24 {
                    verify_values(input.clone(), fixture, &mut session.create_execution_ctx());
                }
            });
        }
        barrier.wait();
        for _ in 0..128 {
            cache.reclaim_idle();
            let ordinary = memory.reserve(GRANT / 2).unwrap();
            assert!(memory.snapshot().reserved_bytes <= GRANT);
            drop(ordinary);
        }
    });
    assert_idle_credit(&memory, &cache);
    assert!(cache.snapshot().prepared >= 3);
    cache.reclaim_idle();
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert_eq!(memory.snapshot().denied_reservations, 0);
}

#[derive(Debug)]
struct PauseContextAllocator {
    inner: crate::owned_buffers::ReservedHostAllocator,
    armed: AtomicBool,
    context_size: AtomicUsize,
    allocations: AtomicUsize,
    ready: mpsc::Sender<()>,
    resume: Arc<Mutex<mpsc::Receiver<()>>>,
}

impl HostAllocator for PauseContextAllocator {
    fn allocate(&self, len: usize, alignment: Alignment) -> VortexResult<WritableHostBuffer> {
        let buffer = self.inner.allocate(len, alignment)?;
        // The one-row non-null fixture allocates its payload, then its context.
        // Observe that real allocation without calling a C API from this crate.
        if self.allocations.fetch_add(1, Ordering::SeqCst) == 1 {
            assert!(len > 4096);
            self.context_size.store(len, Ordering::SeqCst);
        }
        if len == self.context_size.load(Ordering::SeqCst)
            && self.armed.swap(false, Ordering::SeqCst)
        {
            Ok(WritableHostBuffer::new(Box::new(PauseContextBuffer {
                buffer,
                ready: Some(self.ready.clone()),
                resume: Arc::clone(&self.resume),
            })))
        } else {
            Ok(buffer)
        }
    }
}

struct PauseContextBuffer {
    buffer: WritableHostBuffer,
    ready: Option<mpsc::Sender<()>>,
    resume: Arc<Mutex<mpsc::Receiver<()>>>,
}

impl HostBufferMut for PauseContextBuffer {
    fn len(&self) -> usize {
        self.buffer.len()
    }
    fn alignment(&self) -> Alignment {
        self.buffer.alignment()
    }
    fn as_mut_slice(&mut self) -> &mut [u8] {
        // The decoder takes the cache lease before borrowing its context bytes.
        if let Some(ready) = self.ready.take() {
            ready.send(()).unwrap();
            self.resume
                .lock()
                .unwrap()
                .recv_timeout(Duration::from_secs(30))
                .unwrap();
        }
        self.buffer.as_mut_slice()
    }
    fn freeze(self: Box<Self>) -> ByteBuffer {
        self.buffer.freeze()
    }
}

#[test]
fn native_zstd_cache_active_lease_survives_pressure_and_rejected_limit_reduction() {
    let memory = LiveMemoryPool::configurable(GRANT).unwrap();
    let (ready_send, ready_receive) = mpsc::channel();
    let (resume_send, resume_receive) = mpsc::channel();
    let allocator = Arc::new(PauseContextAllocator {
        inner: crate::owned_buffers::ReservedHostAllocator::new(memory.clone()),
        armed: AtomicBool::new(false),
        context_size: AtomicUsize::new(0),
        allocations: AtomicUsize::new(0),
        ready: ready_send,
        resume: Arc::new(Mutex::new(resume_receive)),
    });
    let session = VortexSession::default().with_allocator(allocator.clone());
    crate::native_provider_memory::install(&session, memory.clone());
    let cache = crate::native_provider_codec_cache::install(&session, &memory).unwrap();
    let input = with_dictionary(
        &primitive(&PrimitiveArray::from_iter([17i64])),
        vec![b'a'; 64],
    );
    drop(
        input
            .clone()
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap(),
    );
    assert!(cache.snapshot().idle_bytes > 0);
    allocator.armed.store(true, Ordering::SeqCst);
    std::thread::scope(|scope| {
        let task =
            scope.spawn(|| input.execute::<PrimitiveArray>(&mut session.create_execution_ctx()));
        ready_receive.recv_timeout(Duration::from_secs(30)).unwrap();
        let active = memory.snapshot().reserved_bytes;
        let state = cache.snapshot();
        let reclaimed = cache.reclaim_idle();
        let admission = memory.reserve(GRANT);
        let reduction = memory.set_limit_bytes(active - 1);
        let retained = memory.snapshot().reserved_bytes;
        // Resume before assertions so a failure cannot strand the decoding thread.
        resume_send.send(()).unwrap();
        let output = task.join().unwrap().unwrap();
        assert_eq!(state.hits, 1);
        assert_eq!(state.idle_bytes, 0);
        assert!(!reclaimed);
        assert!(admission.is_err());
        assert!(reduction.is_err());
        assert_eq!(retained, active);
        assert_eq!(output.as_slice::<i64>(), &[17]);
        drop(output);
    });
    assert_idle_credit(&memory, &cache);
    assert!(cache.reclaim_idle());
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    memory.set_limit_bytes(1).unwrap();
}

fn replace_frame(input: &ArrayRef, frame: Vec<u8>) -> ArrayRef {
    let mut parts = input
        .as_::<Zstd>()
        .data()
        .clone()
        .into_parts(input.validity().unwrap());
    parts.frames[0] = ByteBuffer::from(frame);
    Zstd::try_new(
        input.dtype().clone(),
        ZstdData::new(parts.dictionary, parts.frames, parts.metadata, parts.n_rows),
        parts.validity,
    )
    .unwrap()
    .into_array()
}

#[test]
fn native_zstd_cache_preserves_truncated_legacy_and_output_bound_errors() {
    let input = with_dictionary(
        &primitive(&PrimitiveArray::from_iter([17i64])),
        vec![b'a'; 64],
    );
    let frame = input
        .as_::<Zstd>()
        .data()
        .clone()
        .into_parts(input.validity().unwrap())
        .frames[0]
        .as_slice()
        .to_vec();
    let mut tails: Vec<Vec<u8>> = vec![
        vec![0],
        vec![1, 2, 3, 4],
        vec![0x5f, 0x2a, 0x4d, 0x18, 3, 0, 0, 0, 0xff],
        frame.clone(),
    ];
    tails.extend(
        std::iter::once(0x1EB5_2FFDu32)
            .chain(0xFD2F_B522..=0xFD2F_B527)
            .map(|magic| magic.to_le_bytes().to_vec()),
    );
    for tail in tails {
        let mut bytes = frame.clone();
        bytes.extend_from_slice(&tail);
        let bad = replace_frame(&input, bytes);
        let control_memory = LiveMemoryPool::new(GRANT).unwrap();
        let control = bad
            .clone()
            .execute::<PrimitiveArray>(&mut session(&control_memory).create_execution_ctx())
            .unwrap_err();
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let (session, cache) = cached_session(&memory);
        drop(
            input
                .clone()
                .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
                .unwrap(),
        );
        let candidate = bad
            .execute::<PrimitiveArray>(&mut session.create_execution_ctx())
            .unwrap_err();
        assert!(!crate::owned_buffers::is_owned_reservation_denial(
            &candidate
        ));
        assert_eq!(candidate.to_string(), control.to_string());
        // A pre-validation failure never leases the idle entry; a decoder
        // failure drops the active lease. Neither may lose buffer ownership.
        assert_idle_credit(&memory, &cache);
        cache.reclaim_idle();
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        assert_eq!(control_memory.snapshot().reserved_bytes, 0);
    }
}
