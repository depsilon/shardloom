"""Create and reopen the finite rejected codec experiment's portable packet."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import shutil
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'codec-portable-packet-750'
NAME = 'native-codec-preparation-2026-10-19'
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

def digest(data):
    return hashlib.sha256(data).hexdigest()

def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

require_local_path(DEST, Path.home(), sys.platform)
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
assert not DEST.exists(), 'unique packet destination required'
acceptance = json.loads((ROOT / 'perf-03-acceptance.json').read_text())
assert acceptance['status'] == 'completed_drop'
assert acceptance['candidate_removed'] and not acceptance['runtime_changes_retained']
assert not acceptance['completed_substeps'] and not acceptance['broader_owners_closed']
files = {p for p in ROOT.glob('codec*') if p.is_file()}
for directory in ROOT.glob('codec*'):
    if directory.is_dir():
        files.update(p for p in directory.rglob('*') if p.is_file())
files.update(ROOT.glob('analyze_codec*.py'))
files.update((ROOT / 'perf-03-acceptance.json', ROOT / 'run_guarded.py', Path(__file__)))
members = {'evidence/' + str(p.relative_to(ROOT)): p for p in files}
members.update({
    'tools/local_uat_storage.py': REPO / 'scripts/local_uat_storage.py',
    'tools/release_validation_guard.py': Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'tools/bounded_build_process_resume_20260912.py': Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
})
assert digest(members['tools/bounded_build_process_resume_20260912.py'].read_bytes()) == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
assert all(p.is_file() and not p.is_symlink() for p in members.values())
inventory = [{'path': name, 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
             for name, path in sorted(members.items())]
assert sum(row['bytes'] for row in inventory) < 32 * MIB
for value in acceptance.values():
    if isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= value.keys():
        data = (ROOT / value['path']).read_bytes()
        assert len(data) == value['bytes'] and digest(data) == value['sha256']
for path in sorted(ROOT.glob('codec*.json')):
    value = json.loads(path.read_text())
    if isinstance(value, dict) and 'command' in value and 'status' in value:
        assert value['process_group_drained'] is True
        assert value['status'] in ('passed', 'failed')
        log = path.with_suffix('.log')
        assert log.is_file() and digest(log.read_bytes()) == value['log_sha256']

omitted = []
for path in sorted((ROOT / 'artifacts').glob('codec*')):
    data = path.read_bytes()
    omitted.append({'path': str(path.relative_to(ROOT)), 'bytes': len(data),
                    'sha256': digest(data), 'scope': 'frozen executable retained locally; reproducible source patch and build receipts archived'})

DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
    for row in inventory:
        data = members[row['path']].read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        info = tarfile.TarInfo(row['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as source:
    assert source.getnames() == [row['path'] for row in inventory]
    for row in inventory:
        entry = source.getmember(row['path'])
        assert entry.isfile()
        data = source.extractfile(entry).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert digest(members[row['path']].read_bytes()) == row['sha256']
manifest = DEST / (NAME + '.manifest.json.xz')
manifest.write_bytes(lzma.compress(encode({'schema_version': 'shardloom.evidence_member_manifest.v1',
    'all_members_reopened': True, 'members': inventory}), preset=6))
assert json.loads(lzma.decompress(manifest.read_bytes()))['members'] == inventory
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
index = {
    'schema_version': 'shardloom.native_codec_preparation_investigation.v1',
    'status': 'completed_drop', 'decision': 'drop',
    'investigated_substeps': ['PERF-03.codec_preparation'],
    'completed_substeps': [], 'broader_owners_closed': [],
    'investigation_remains_open': True,
    'base': '62754f909f58607654d511d4eb10eff47ada2328', 'restored_commit': head,
    'acceptance': '../../architecture/' + NAME + '.md',
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes())},
    'manifest': {'file': manifest.name, 'bytes': manifest.stat().st_size, 'sha256': digest(manifest.read_bytes())},
    'member_count': len(inventory), 'uncompressed_bytes': sum(row['bytes'] for row in inventory),
    'all_members_reopened': True, 'owner_acceptance': 'evidence/perf-03-acceptance.json',
    'source_bridge': 'evidence/codec-final-source-bridge-749.json',
    'protocol': 'evidence/codec-cache-protocol-748.json',
    'cost_comparison': 'evidence/codec-cache-analysis-748.json',
    'candidate_patch': 'evidence/codec-cache-tracked-candidate-expanded-fixed-749.patch',
    'candidate_extra_sources': 'evidence/codec-cache-extra-sources-expanded-fixed-749',
    'candidate_removed': True, 'restored_rust_cargo_source_files': 1895,
    'candidate_correctness': acceptance['observed_comparison'],
    'candidate_test_counts': acceptance['candidate_test_counts'],
    'fresh_process_portability': acceptance['fresh_process_portability'],
    'failed_builds_preserved': ['codec-workflow-build-747', 'codec-cache-build-748', 'codec-cache-expanded-build-749'],
    'broad_runtime_acceptance': 'not attempted after finite candidate rejection; no Full43 or whole-engine claim',
    'platform_scope': 'local macOS arm64', 'omitted_bulk_artifacts': omitted,
    'replay': 'Use an isolated checkout of the recorded baseline. Apply the candidate patch and add its six extra sources. Diagnostic stages have separate recorded patches. Rebind historical absolute paths to a new local evidence directory, preserve all guards and protocol hashes, and never overwrite original run identities.',
}
index_path = DEST / (NAME + '.json')
index_path.write_bytes(encode(index))
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=0, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
for path in (archive, manifest, index_path):
    target = REPO / 'docs/benchmarks/evidence' / path.name
    assert not target.exists()
    shutil.copyfile(path, target)
    assert digest(target.read_bytes()) == digest(path.read_bytes())
print(json.dumps({'status': 'passed', 'members': len(inventory), 'uncompressed_bytes': index['uncompressed_bytes'],
                  'archive_bytes': index['archive']['bytes'], 'manifest_bytes': index['manifest']['bytes'],
                  'all_members_reopened': True, 'output': str(index_path)}))
