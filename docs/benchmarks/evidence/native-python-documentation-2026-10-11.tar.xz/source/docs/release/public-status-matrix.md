<!-- SPDX-License-Identifier: Apache-2.0 -->

# Public Status Matrix

Status: canonical public status and claim-boundary owner.

Schema marker: `shardloom.public_status_matrix.v1`.

This matrix is the source-owned public posture summary for the README, getting-started docs,
Python README, release readiness docs, and website wording. It describes what a public reader may
infer from the current repository state. v0.5.1 package channels are published where explicitly
listed, but that does not authorize production support, benchmark superiority, Spark displacement,
external execution, or fallback execution.

Finished-product v1 scope is defined in
[`docs/release/finished-product-scope.md`](finished-product-scope.md). Public wording should start
from supported ShardLoom surfaces, not from broad external-engine replacement framing.
The active v1 queue and feasibility firewall is tracked in
[`docs/release/v1-inclusion-scope-matrix.md`](v1-inclusion-scope-matrix.md).
The selected local/source/package v1 release track is tracked in
[`docs/release/v1-local-source-package-release.md`](v1-local-source-package-release.md).
Selected package channels are published for v0.5.1; real production environment gates remain
blocked.
The scoped local SQL/Python/DataFrame front-door runtime boundary is defined in
[`docs/architecture/v1-front-door-runtime-scope.md`](../architecture/v1-front-door-runtime-scope.md).
The scoped local/prepared v1 Vortex runtime boundary is defined in
[`docs/architecture/v1-vortex-runtime-scope.md`](../architecture/v1-vortex-runtime-scope.md).
The scoped local SourceState and prepared-state reuse boundary is defined in
[`docs/architecture/v1-source-prepared-state-scope.md`](../architecture/v1-source-prepared-state-scope.md).
The scoped local output/sink scope is defined in
[`docs/architecture/v1-local-output-sink-scope.md`](../architecture/v1-local-output-sink-scope.md);
append remains unsupported outside a later closed gate.
The scoped local observability/supportability boundary is defined in
[`docs/architecture/v1-observability-support.md`](../architecture/v1-observability-support.md);
support bundles remain local/redacted and remote telemetry/upload surfaces remain unsupported.

## Local Engine Maturity

**Published local engine; operational hardening in progress.** This is the current public
support label. The technical-preview designation describes the support promise, not whether
the engine or packages exist. v0.5.1 is available through GitHub, TestPyPI, PyPI and Homebrew;
the [publication verification](v0.5.1-publication-verification.md) closes the selected-channel
proof requirement.

Current source additionally implements the optional
[native Python surface](../architecture/native-python-surface-2026-10-10.md).
Its [local acceptance](../benchmarks/native-python-surface-2026-10-11.md) covers
native input/results, in-process operations, typed plans, an isolated installed
wheel and six paired complete Python workflows. Hosted integration remains
pending. Published 0.5.1 packages are unchanged; local source/wheel proof does not
change the public platform or production-support promise, or establish a new
ingest or Full43 result.

The local engine executes admitted SQL, Python/DataFrame and CLI workflows through one native
pipeline, including typed and nested results, exact decimal reductions, analytic frames and
local writers. Native ordering spill, cancellation, corrupt-run and quota rejection, slow or
failed consumers, source-generation checks and owned cleanup have executable evidence. Their
scope is recorded in the [resource contract](../architecture/native-relational-resources-2026-10-02.md)
and [current release acceptance](../benchmarks/release-candidate-fresh-uat-2026-10-09.md).

The v0.5.1 release includes reviewed FSST/Zstd buffer ownership,
public resident batch intake and incremental results, plus two retained native
CPU optimizations. The [original acceptance report](../benchmarks/native-engine-acceptance-2026-10-06.md)
records the complete source/public/Full43 checks and the three dropped hardware
prototypes. PR #1526 merged after all 39 hosted checks passed. Published v0.4.0
predates these additions. Target-cohort gains are not a broad engine performance claim.

The subsequent [Zstd workspace acceptance](../benchmarks/native-codec-workspaces-2026-10-07.md)
adds actual decoder and by-reference prepared-dictionary admission to the same
native memory owner. Local ownership and complete regression checks pass;
PR #1528 merged after all 39 hosted checks passed with the accepted runtime
source unchanged. Compression/training state and other
unreviewed allocations remain outside that finite resource proof. The change is included in v0.5.1; the public support label is unchanged.

The [builder acceptance](../benchmarks/native-builder-resources-2026-10-07.md)
further covers native primitive/Boolean/decimal Chunked output and builder
finalization buffers, preserving independent value/validity ownership. Complete
local source/public/Full43 checks and packet inspection pass. PR #1529 merged
after all 39 hosted checks passed with the accepted runtime unchanged; production
verification passes. Child decoder scratch, structural metadata and general operator
spill remain separate. Its measured cost screen is a resource-correction check,
not a speedup or process-RSS guarantee.

The [completion-aware input unit](../architecture/native-input-completion-2026-10-07.md)
adds opt-in `from_batches(..., streaming=True)` for one finite source used once,
with incremental results, bounded small collection or one native Vortex destination. Its
[corrected local acceptance and packet inspection](../benchmarks/native-fsst-admission-2026-10-07.md)
pass, including complete input above the native grant and late-failure safety;
[PR #1530](https://github.com/depsilon/shardloom/pull/1530) completed hosted integration.
The corrected runtime also rejects malformed FSST row lengths before native
decoder allocation. At most one native input batch is retained.
The subsequent [ordering and general aggregate unit](../benchmarks/native-stateful-aggregation-ordering-2026-10-08.md)
has complete local acceptance and packet inspection for Scan/Filter/Project/Sort/Limit/Aggregate.
Limits drain all input; native ordering and general aggregation can share an
explicit spill policy. Hosted integration completed in
[PR #1531](https://github.com/depsilon/shardloom/pull/1531), with all 39 checks
passing and the accepted runtime unchanged. The current
[join pressure unit](../architecture/native-join-pressure-2026-10-08.md) adds an
explicit native strategy for all seven join kinds and one single-use batch source
on either side, alongside ordinary file/resident sources. Its
[complete local acceptance](../benchmarks/native-join-pressure-2026-10-08.md)
passes constrained native spill, all 213 streaming cases, unchanged public/direct
regressions, 129 Full43 results and independent packet inspection. Hosted
integration completed in [PR #1532](https://github.com/depsilon/shardloom/pull/1532)
after all 39 checks passed; production deployment and browser verification pass
with all accepted runtime assets unchanged.
The [window pressure unit](../architecture/native-window-pressure-2026-10-08.md)
extends that explicit policy and single-use input contract to the existing
analytic functions, frames and exclusions. Its
[complete local acceptance](../benchmarks/native-window-pressure-2026-10-08.md)
passes file-backed and streamed 16-MiB native pressure controls, 442 streaming
cases, 28,871 public checks including 1,498 added spill-frame cases, and all 129
Full43 results. Independent packet inspection passes; hosted integration
completed in [PR #1533](https://github.com/depsilon/shardloom/pull/1533) after all
39 checks passed, with unchanged runtime assets and actual preview/production
verification in the [hosted receipt](../benchmarks/evidence/native-window-hosted-2026-10-08.json).
The subsequent [pivot pressure unit](../benchmarks/native-pivot-pressure-2026-10-08.md)
has complete local engine acceptance and independent packet inspection for
file/resident-memory relational pivots. Two native 16-MiB controls return all
6,145 wide-key results; resident denial and a 512-MiB ample control pass.
The public portfolio now contains 32,497 checks and 18,595,284 complete row
comparisons, including 3,626 added pressure checks and 133 incremental proofs;
all 129 Full43 comparisons pass. The original summary-controller failure and
exact two-file harness repair remain explicit in the evidence. Pivot support
alignment passes nine checks, seven native examples and rendered desktop/mobile
search verification. PR #1534 merged at `d7898cb9` after all 39 checks passed on
`1675693e`; the [hosted receipt](../benchmarks/evidence/native-pivot-hosted-2026-10-08.json)
records production deployment, matching preview/production text and search,
primary review and the separately documented test-message cleanup. Direct prepared unary pivots
remain resident, and dynamic one-shot pivot input rejects before demand.
Resident input remains the default. These capabilities are included in v0.5.1;
no process-RSS bound or public maturity change follows from publication.

Source builds after 0.5.1 have complete local
[input growth acceptance](../benchmarks/native-input-growth-2026-10-09.md):
cumulative batch input, top-level schema metadata and compact generated ranges
grow under the shared query grant. All 15 source gates, 20 growth workflows,
five input-pressure controls, complete public/streaming regressions and all 129
Full43 results pass, followed by independent packet inspection and complete
documentation/example/browser checks. PR #1539 merged at `7d8230b2` after all
39 checks passed; the
[hosted receipt](../benchmarks/evidence/native-input-growth-hosted-2026-10-09.json)
binds identical accepted/merged trees and actual production verification.
Per-frame and small-result bounds remain;
richer intake, multiple/repeated producers, streaming destination composition
and deeper traversal remain implementation work. Published 0.5.1 artifacts
retain their release-time behavior. No version bump or support-label change
accompanies this finite unit.

The remaining maturity requirements are an explicit supported local workload/platform envelope,
accounting and safe failure through readers/codecs/operators/writers, and accepted workload-wide
pressure, cancellation, fault and recovery evidence. A query memory grant is not a process-RSS
ceiling; broader allocation, unadmitted state pressure and recovery remain
incomplete. The
[local-engine exit criteria](production-certification-gate.md#local-engine-preview-exit-criteria)
define the required evidence and approval. Missing cloud integrations or complete SQL parity do
not, by themselves, block a stable release for a narrower declared local scope.

The maintainer-approved capability milestone is published as corrected v0.5.1
through GitHub, TestPyPI, PyPI and Homebrew. Its
[publication verification](v0.5.1-publication-verification.md)
records the source, registry builds and channel installation proofs.
The original v0.5.0 tag/assets remain immutable; its
[interruption record](v0.5.0-channel-interruption.md) preserves the failed
Windows build that stopped that version before registry upload.
[Full fresh UAT](../benchmarks/release-candidate-fresh-uat-2026-10-09.md) passed
**before** the version bump: 99,997,497 freshly ingested rows, all 129 complete
query comparisons and all 18 modular input/output cohorts. Those measurements
retain their original pre-bump source and executable identities.

## Claim Boundary

Public claim booleans remain fail-closed unless a later release-approved gate changes them:
the publication-attempt fields below describe this status/gate surface's side effects, not
the history of the already published package channels.

```text
package_publication_status=published_v0.5.1_selected_channels
public_package_release_claim_allowed=true
public_release_claim_allowed=false
public_package_claim_allowed=false
performance_claim_allowed=false
performance_superiority_claim_allowed=false
production_claim_allowed=false
spark_replacement_claim_allowed=false
broad_engine_replacement_claim_allowed=false
drop_in_replacement_claim_allowed=false
production_platform_claim_allowed=false
publication_attempted=false
tag_created=false
package_upload_attempted=false
fallback_attempted=false
external_engine_invoked=false
```

## Current Public Posture

| Surface | Current posture | What this permits | What remains blocked |
| --- | --- | --- | --- |
| Source checkout | Supported for local development and admitted native workflows. | Clone, build, run local CLI/Python workflows, inspect evidence. | Production support and performance claims beyond accepted evidence; a source build alone does not verify package channels. |
| Local first-10-minutes path | Supported through getting-started examples, `scripts/release_dry_run_proof.py`, and local smoke reports. | Local execution proof over installed or source-built artifacts. | Production or performance claims; the proof command itself does not publish, tag, sign or use secrets. |
| CLI and Python front doors | Scoped local CSV, JSON/JSONL/NDJSON, generated rows, local Vortex, and feature-gated flat-scalar Parquet, Arrow IPC/Feather, Avro, and ORC paths through `ctx.read(...)` or explicit helpers. | Evidence-backed local route use with no-fallback fields visible; feature-gated structured readers return deterministic blockers when unavailable. | Broad SQL/DataFrame parity, server/API production support, object-store/table readers, hidden external execution. |
| SQL/DataFrame-style surface | Selected local-source projections, filters, joins, aggregates, bounded collects, and local writes are admitted through ShardLoom routes. | Scoped local workflow evidence and deterministic unsupported blockers. | PySpark/pandas/Polars parity, arbitrary SQL/DataFrame runtime, performance equivalence. |
| Vortex preparation and local primitives | Feature-gated local `vortex_ingest` creates `VortexPreparedState` evidence for scoped flat local inputs. Scoped local Vortex primitives are covered by the feature-gated local Vortex runtime scope. | Explicit preparation, prepared/native route inspection, and local primitive count/filter/project route reports. | Broad writer support, object-store/table/catalog preparation, generalized Vortex Source/Sink runtime, production staging. |
| SourceState and prepared-state reuse | The declarative source/prepared-state scope, golden fixtures, and invalidation matrix define local reuse through `ResidentVortexSession`, with source-generation and declaration validation on each execution and no query-answer cache. This scope report is declarative specification, not runtime evidence; current runtime evidence remains in live tests and harnesses. | Local SourceState normalization and explicit session or VortexPreparedState reuse, with deterministic invalidation behavior where exercised by live tests. | Global hidden cache, external cache service, object-store/table prepared-state reuse, broad non-local preparation, production cache claims. |
| Local output/sink scope | The declarative output/sink scope records the single `native_vortex_query` route through `shared_native_workflow`, its admitted format/method/policy declarations, and no-fallback posture. The scope report is not runtime verification; complete-value readback and writer behavior must be established by live tests or harnesses. | Local output through the shared native workflow for admitted formats and shapes, with runtime sink evidence reported by live executions. | Append mode, object-store output paths, table/catalog writes, Iceberg/Delta transactions, remote URI sinks, broad nested/complex sink claims. |
| Observability/supportability | Scoped local doctor, support-bundle, agent-contract, capability, runtime-report, schema-coverage, plan-only explain/estimate, diagnostic-code, issue-template, and benchmark-field checks are closed by the v1 observability/support boundary. | Local redacted support bundles, deterministic troubleshooting, side-effect-free support surfaces, and no-fallback/no-external-engine support evidence. | OpenTelemetry/OpenLineage export, remote support upload, live profiling collection, production observability/SRE claims, and performance claims. |
| Benchmarks | The parameterized local harness runs one ShardLoom candidate through the public native workflow, with declared input state and output format. It retains source, executable, command, timing, and complete-result evidence. Comparison engines provide independent references only. | Local correctness comparisons with explicit timing boundaries; published historical evidence keeps its original scope. | Public performance superiority, Spark displacement, stale-artifact claims, timing-surface substitution. |
| Object store, lakehouse, Foundry, live/hybrid | Mostly report-only, fixture-scoped, or blocked for broader platform routes. | Capability posture, local fixture proof where explicitly named, blocked diagnostics. | Production platform/runtime claims and managed-service integrations. |
| Website | Static public interpretation layer over checked-in source/evidence. | Claim-safe docs, use-case, benchmark, status, and architecture views. | Runtime expansion, package publication, public benchmark freshness beyond promoted artifacts. |
| Package/release channels | v0.5.1 selected channels are published and proof-backed: GitHub pre-release assets, TestPyPI, PyPI, and Homebrew. | Install access through `gh release download v0.5.1`, `python -m pip install shardloom==0.5.1`, and `brew install depsilon/tap/shardloom`; channel proof refs remain checked in. | Scoop, winget, conda-forge, GHCR, crates.io, real production environment gates, signing/attestation expansion, and production/package-maturity claims remain blocked. |

## Public Docs Ownership

| Public surface | Role | Required source |
| --- | --- | --- |
| `README.md` | Compact public entry point and support-posture summary. | This matrix plus `docs/architecture/compute-engine-flow-reference.md`. |
| `docs/release/finished-product-scope.md` | Canonical v1 support boundary and allowed public claim language. | Phase plan plus per-claim evidence matrix. |
| `docs/release/v1-inclusion-scope-matrix.md` | V1 required/candidate/deferred row classification and unsupported-surface firewall. | Phase plan plus known unsupported paths. |
| `docs/architecture/v1-front-door-runtime-scope.md` | Scoped local v1 SQL/Python/DataFrame front-door boundary. | Python parity matrix, user route capability report, and local scenario runner. |
| `docs/architecture/v1-vortex-runtime-scope.md` | Scoped feature-gated local/prepared v1 Vortex runtime boundary. | Declarative local Vortex primitive and user route reports; live tests and the public workflow harness provide runtime evidence. |
| `docs/architecture/v1-source-prepared-state-scope.md` | Scoped local SourceState and prepared-state reuse boundary. | Declarative source prepared-state scope report, golden fixtures, invalidation matrix, user route capability report; live tests/harnesses provide runtime evidence. |
| `docs/architecture/v1-local-output-sink-scope.md` | Scoped local output/sink scope. | Declarative local output sink scope report, golden fixtures, user route capability report; live tests/harnesses provide complete-value readback and runtime writer evidence. |
| `docs/architecture/v1-observability-support.md` | Scoped local observability/supportability boundary. | Observability support report, diagnostic-code stability doc, troubleshooting guide, issue templates, route capability report, API/schema stability report, and benchmark timing-surface fields. |
| `docs/getting-started/install.md` | Source checkout and local install path. | This matrix plus package-channel readiness docs. |
| `docs/getting-started/source-checkout-install.md` | Source checkout build and local proof path. | This matrix plus release dry-run proof docs. |
| `docs/getting-started/package-user-install.md` | Published package-channel availability, uninstall, upgrade and future-channel boundaries. | Package-channel readiness matrix plus this matrix. |
| `docs/getting-started/first-10-minutes.md` | Local proof walkthrough. | This matrix plus release dry-run proof docs. |
| `docs/getting-started/examples.md` | Copyable scoped examples and blockers. | This matrix plus relevant capability docs. |
| `docs/getting-started/v1-supported-unsupported.md` | Generated current supported/unsupported surface. | Runs-today support matrix plus package-channel matrix. |
| `docs/getting-started/troubleshooting-support.md` | Local troubleshooting and support-bundle guide. | V1 observability/support scope plus diagnostic-code stability docs. |
| `python/README.md` | Python wrapper/API posture. | This matrix plus Python user-surface and parity gates. |
| `docs/release/public-technical-preview-readiness.md` | Historical public-preview readiness pass and checklist. | This matrix for current posture. |
| `website-src/` | Public web interpretation layer. | This matrix, synced data artifacts, and website readiness checks. |

## Maintenance Rules

- Keep this file as the canonical public status matrix; do not create parallel README-only or
  website-only status tables with different claim boundaries.
- Public docs may summarize the matrix, but they must link back here when they mention package,
  production, performance, broad engine replacement, Spark-displacement, SQL/DataFrame,
  object-store/lakehouse, Foundry, or release posture.
- Positive broad replacement, drop-in parity, production platform, performance superiority, or
  broad SQL/DataFrame parity language is blocked unless a matching claim row is closed. Otherwise
  the wording must be framed as blocked, unsupported, baseline-only, historical, or no-fallback
  policy.
- Benchmark wording must state `timing_surface` and `claim_gate_status` before comparing numbers.
- Package wording must distinguish source checkout, local wheel dry run, selected published
  v0.5.1 channels, blocked future channels, and production/package-maturity claims.
- Website and docs changes must preserve `fallback_attempted=false` and
  `external_engine_invoked=false` for ShardLoom execution evidence.
