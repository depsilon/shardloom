"""Validate current native Python documentation and its generated guide."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources

frozen = json.loads((OUT / 'native-release-source-300.json').read_text())['source_sha256']
assert sources() == frozen
destination = OUT / 'native-documentation-checks-302'
destination.mkdir()
node = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
wheel_python = OUT / 'native-wheel-proof-300b/venv/bin/python'
website = ROOT / 'website-src'
record = {'status': 'running', 'checks': [], 'examples': []}

def run(name, command, cwd=ROOT):
    log = destination / (name + '.log')
    start = time.monotonic()
    with log.open('xb') as output:
        completed = subprocess.run([str(p) for p in command], cwd=cwd,
                                   stdout=output, stderr=subprocess.STDOUT,
                                   timeout=300, check=False)
    record['checks'].append({'name': name, 'command': [str(p) for p in command],
                             'returncode': completed.returncode,
                             'seconds': time.monotonic()-start, 'log': log.name,
                             'log_sha256': sha(log)})
    print(name, completed.returncode, flush=True)
    assert completed.returncode == 0, name

try:
    for name, path, section in [
        ('readme-example', ROOT / 'python/README.md', '## Source-only native Python API'),
        ('guide-example', website / 'src/content/docs/field-guide/python-surface.mdx',
         '## Keep results native'),
    ]:
        text = path.read_text().split(section, 1)[1].split('\n## ', 1)[0]
        snippets = re.findall(r'```python\n(.*?)\n```', text, re.S)
        assert len(snippets) == 1
        code = snippets[0]
        check = code + "\nassert table.to_pydict() == {'value': list(range(10, 100))}\nassert pa.types.is_int64(table.schema.field(0).type)\n"
        run(name, [wheel_python, '-I', '-c', check])
        record['examples'].append({'document': str(path.relative_to(ROOT)),
                                    'document_sha256': sha(path), 'code': code,
                                    'complete_values': 90, 'after_session_close': True})
    run('user-surface-index', [sys.executable, '-B', 'scripts/check_user_surface_reference.py'])
    run('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py',
                         '--output', destination / 'public-status.json'])
    run('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py'])
    run('website-link-tests', [sys.executable, '-B', '-m', 'unittest', 'discover',
                              '-s', 'scripts', '-p', 'test_website_links.py', '-v'])
    before = sha(website / 'src/content/docs/field-guide/python-surface.mdx')
    run('static-clean', [node, 'scripts/prebuild-static.mjs'], website)
    run('content-sync', [node, 'scripts/sync-content.mjs'], website)
    assert sha(website / 'src/content/docs/field-guide/python-surface.mdx') == before
    run('astro-check', [node, 'node_modules/astro/bin/astro.mjs', 'check'], website)
    run('static-settle', [node, 'scripts/prebuild-static.mjs', '--settle-output'], website)
    run('search-policy', [node, '--test', 'scripts/pagefind-policy.test.mjs'], website)
    run('static-reset', [node, 'scripts/prebuild-static.mjs', '--reset-output'], website)
    run('content-sync-build', [node, 'scripts/sync-content.mjs'], website)
    run('astro-build', [node, 'node_modules/astro/bin/astro.mjs', 'build'], website)
    run('static-postbuild', [node, 'scripts/postbuild-static.mjs'], website)
    run('website-readiness', [sys.executable, '-B', 'scripts/check_website_readiness.py',
                             '--output', destination / 'website-readiness.json'])
    run('static-assets', [node, 'scripts/validate_static_assets.cjs'])
    run('diff', ['git', 'diff', '--check'])
    assert sources() == frozen
    record.update(status='passed', source_files_unchanged=len(frozen),
                  generated_guide_matches_source=True,
                  guide_html_sha256=sha(ROOT / 'website/field-guide/python-surface/index.html'))
except BaseException as error:
    record.update(status='failed', error=repr(error))
    raise
finally:
    with (destination / 'report.json').open('x') as output:
        json.dump(record, output, indent=2)
        output.write('\n')
