"""Verify the final CI-selection delta and retain documentation/review proof."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources

destination = OUT / 'native-final-support-303'
destination.mkdir()
frozen = json.loads((OUT / 'native-release-source-300.json').read_text())['source_sha256']
current = sources()
expected = {'scripts/check_ci_gate_matrix.py', 'scripts/run_release_validation_evidence.py'}
assert current.keys() == frozen.keys()
changed = {name for name in frozen if frozen[name] != current[name]}
assert changed == expected, sorted(changed)
record = {'schema_version': 'shardloom.native_python_support.v1', 'status': 'running',
          'checks': [], 'source_files': len(current),
          'unchanged_frozen_files': len(current) - len(changed),
          'frozen_runtime_sources_unchanged': True,
          'post_acceptance_validation_script_changes': {
              name: {'accepted_sha256': frozen[name], 'current_sha256': current[name]}
              for name in sorted(changed)}}

def write(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')

def run(name, command, content=None):
    log = destination / (name + '.log')
    start = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, input=content,
                                stdout=output, stderr=subprocess.STDOUT,
                                timeout=120, check=False)
    record['checks'].append({'name': name, 'command': command,
                             'returncode': result.returncode,
                             'seconds': time.monotonic()-start,
                             'log': log.name, 'log_sha256': sha(log)})
    assert result.returncode == 0, name

prior = OUT / 'native-documentation-checks-302'
docs = json.loads((prior / 'report.json').read_text())
assert docs['status'] == 'passed' and len(docs['checks']) == 18
for check in docs['checks']:
    assert check['returncode'] == 0
    assert sha(prior / check['log']) == check['log_sha256']
for example in docs['examples']:
    assert sha(ROOT / example['document']) == example['document_sha256']
assert sha(ROOT / 'website/field-guide/python-surface/index.html') == docs['guide_html_sha256']
preview = json.loads((OUT / 'native-doc-preview-302.json').read_text())
assert preview['status'] == 'passed' and preview['process_group_drained']
assert sha(OUT / 'native-doc-preview-302.log') == preview['log_sha256']

run('ci-gate-matrix', [sys.executable, '-B', 'scripts/check_ci_gate_matrix.py',
                      '--output', str(destination / 'ci-gate-matrix.json')])
for selection in ('ci_gate_matrix', 'release_validation_evidence'):
    run(selection, [sys.executable, '-B', '-m', 'unittest', 'discover',
                    '-s', 'python/tests', '-p', 'test_release_scripts.py',
                    '-k', selection, '-v'])
guide = (ROOT / 'docs/getting-started/source-checkout-install.md').read_text()
section = guide.split('## Optional Native Python Binding\n', 1)[1].split('\n## ', 1)[0]
snippets = re.findall(r'```sh\n(.*?)\n```', section, re.S)
assert len(snippets) == 1
run('native-install-shell-syntax', ['/bin/bash', '-n'], snippets[0].encode())
run('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py',
                     '--output', str(destination / 'public-status.json')])
run('diff-check', ['git', 'diff', '--check'])
delta = subprocess.check_output(['git', 'diff', 'HEAD', '--', *sorted(expected)], cwd=ROOT)
assert delta.count(b'+') > 2
with (destination / 'ci-library-selection.patch').open('xb') as output:
    output.write(delta)
write(destination / 'final-selected-source-sha256.json', current)
record['documentation_checks'] = 18
record['examples'] = docs['examples']
record['rendered_review'] = {
    'method': 'primary visual review through the in-app browser',
    'guide': '/field-guide/python-surface/#keep-results-native',
    'desktop': {'viewport_width': 1280, 'body_scroll_width': 1265,
                'themes': ['dark', 'light']},
    'mobile': {'viewport_width': 390, 'body_scroll_width': 375,
               'themes': ['dark', 'light']},
    'code_scroll': 'contained horizontal code scrolling; no body overflow',
    'search': {'query': 'shardloom.native', 'results': 2,
               'selected_result': 'Keep results native', 'correct_anchor': True},
    'browser_warnings_and_errors': [], 'temporary_tab_closed': True,
    'preview_process_group_drained': True,
}
record['primary_review'] = {
    'scope': 'final boundary review; not an independent security audit',
    'manifest_admission': 'admitted owner precedes inspection; retained text/parser/path/listing credits',
    'result_lifetimes': 'retained native owner and consumer release callbacks; explicit row endpoint',
    'streaming': 'one demanded batch; cancellation and worker drain; no provisional success report',
    'provider_selection': 'shared declaration selection; no error-driven retry; file and memory controls',
    'ci_correction': 'include extracted runtime library unit tests in native lane and local validator',
    'runtime_test_coverage': 'already included in accepted --all-targets native run',
    'remaining': ['hosted final-head acceptance', 'unobserved native platforms and portability',
                  'timestamp compression/statistics and broader six-area/eight-investigation queue'],
}
assert sources() == current
record['status'] = 'passed'
write(destination / 'report.json', record)

members = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink()
    assert name not in members
    members[name] = path

for parent in (prior, destination):
    for path in sorted(parent.iterdir()):
        if path.is_file():
            add(path, 'observations/' + str(path.relative_to(OUT)))
for name in ('verify_native_docs_302.py', 'preview_native_docs_302.py',
             'native-documentation-checks-302.json', 'native-documentation-checks-302.log',
             'native-doc-preview-302.json', 'native-doc-preview-302.log',
             'native-doc-inventory-302.json', 'native-doc-verification-302.json',
             'native-pr-file-inventory-303.json', 'package_native_support_303.py'):
    add(OUT / name, 'observations/' + name)
for path in sorted(OUT.glob('native-doc-*.png')):
    add(path, 'screenshots/' + path.name)
for name in ('docs/architecture/native-python-surface-2026-10-10.md',
             'docs/benchmarks/native-python-surface-2026-10-11.md',
             'docs/getting-started/source-checkout-install.md',
             'docs/reference/shardloom-user-surface-index.md',
             'docs/reference/shardloom-user-surface-index.json',
             'docs/release/ci-gate-matrix.md', 'docs/release/public-status-matrix.md',
             'python/README.md', '.github/workflows/ci.yml',
             'website-src/scripts/sync-content.mjs',
             'website-src/src/content/docs/field-guide/python-surface.mdx',
             'website/field-guide/python-surface/index.html', *sorted(expected)):
    add(ROOT / name, 'source/' + name)
manifest = {name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
            for name, path in sorted(members.items())}
archive = OUT / 'native-python-documentation-303.tar.xz'
with archive.open('xb') as output, tarfile.open(fileobj=output, mode='w:xz') as bundle:
    for name, path in sorted(members.items()):
        bundle.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:xz') as bundle:
    entries = bundle.getmembers()
    assert len(entries) == len(manifest)
    for entry in entries:
        assert entry.isfile() and entry.name in manifest
        original = manifest[entry.name]
        value = bundle.extractfile(entry).read()
        assert len(value) == original['bytes']
        assert hashlib.sha256(value).hexdigest() == original['sha256']
index = {'schema_version': 'shardloom.native_python_documentation_packet.v1',
         'status': 'passed', 'archive': 'native-python-documentation-2026-10-11.tar.xz',
         'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
         'members_verified': len(manifest), 'members': manifest,
         'support': record, 'hosted_acceptance': 'pending'}
write(OUT / 'native-python-documentation-303.json', index)
evidence = ROOT / 'docs/benchmarks/evidence'
copy = evidence / index['archive']
with copy.open('xb') as output, archive.open('rb') as source:
    for chunk in iter(lambda: source.read(1 << 20), b''):
        output.write(chunk)
assert sha(copy) == index['archive_sha256']
write(evidence / 'native-python-documentation-2026-10-11.json', index)
assert sources() == current
print(json.dumps({'status': 'passed', 'members_verified': len(manifest),
                  'archive_bytes': index['archive_bytes'],
                  'unchanged_frozen_files': record['unchanged_frozen_files'],
                  'validation_script_changes': sorted(changed)}))
