#!/usr/bin/env python3
"""Independently replay the frozen dictionary-growth comparison artifacts."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import statistics
import tarfile


OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
RUNS = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/logs')
COMPARISON = OUT / 'dictionary-growth-comparison-471'
PROTOCOL_PATH = COMPARISON / 'protocol.json'
RESULTS_PATH = COMPARISON / 'results.json'
MIB = 1024 * 1024


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def json_bytes(data: bytes, label: str):
    try:
        return json.loads(data)
    except Exception as error:
        raise ValueError(f'{label}: invalid JSON: {error}') from error


def manifest_case(summary: dict, archive_manifest: dict) -> dict:
    archive_path = Path(archive_manifest['path'])
    archive_data = archive_path.read_bytes()
    archive_hash = sha_bytes(archive_data)
    if archive_hash != archive_manifest['sha256']:
        raise ValueError(f'archive sha256 mismatch: {archive_path}')
    expected = archive_manifest['members']
    expected_names = [entry['name'] for entry in expected]
    if len(expected_names) != len(set(expected_names)):
        raise ValueError(f'duplicate declared member names: {archive_path}')

    found = []
    payloads = {}
    with tarfile.open(archive_path, mode='r:xz') as archive:
        for member in archive:
            if not member.isfile() or member.name.startswith('/') or '..' in Path(member.name).parts:
                raise ValueError(f'non-regular or unsafe archive member: {member.name}')
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError(f'missing member stream: {member.name}')
            digest = hashlib.sha256()
            content = bytearray()
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
                content.extend(chunk)
            actual_hash = digest.hexdigest()
            item = {'name': member.name, 'bytes': member.size, 'sha256': actual_hash}
            found.append(item)
            payloads[member.name] = bytes(content)
    if [item['name'] for item in found] != expected_names:
        raise ValueError(f'archive order/name mismatch: {archive_path}')
    for actual, declared in zip(found, expected, strict=True):
        if actual != declared:
            raise ValueError(f'archive member identity mismatch: {archive_path}:{declared["name"]}')
    return {
        'archive': {'path': str(archive_path), 'bytes': len(archive_data), 'sha256': archive_hash},
        'manifest_member_count': len(expected),
        'members_in_original_order': found,
        'payloads': payloads,
    }


def envelope_fields(envelope: dict) -> dict:
    if envelope.get('status') != 'success':
        raise ValueError('raw CLI envelope is not successful')
    fallback = envelope.get('fallback')
    if not isinstance(fallback, dict) or fallback.get('attempted') is not False:
        raise ValueError('raw CLI envelope lacks explicit no-fallback evidence')
    fields = envelope.get('fields')
    if not isinstance(fields, list):
        raise ValueError('raw CLI envelope fields missing')
    result = {}
    for row in fields:
        key = row.get('key') if isinstance(row, dict) else None
        if not isinstance(key, str) or key in result:
            raise ValueError('malformed or duplicate raw envelope field')
        result[key] = row.get('value')
    if result.get('public_workflow_fallback_attempted') != 'false':
        raise ValueError('raw CLI envelope fallback evidence not false')
    if result.get('public_workflow_external_engine_invoked') != 'false':
        raise ValueError('raw CLI envelope external engine evidence not false')
    if result.get('native_query_timing_reported') != 'true':
        raise ValueError('raw CLI envelope did not report engine timing')
    if result.get('native_query_timing_clock') != 'monotonic_wall_not_cpu':
        raise ValueError('unexpected engine timing clock')
    expected_boundary = ('prepared_native_execution_including_io_generation_validation_and_certification_'
                         'excluding_result_serialization')
    if result.get('native_query_timing_boundary') != expected_boundary:
        raise ValueError('unexpected engine timing boundary')
    raw = result.get('native_query_execution_nanos')
    if not isinstance(raw, str) or not raw.isascii() or not raw.isdecimal() or len(raw) > 20:
        raise ValueError('invalid engine execution nanos')
    return result


def median_map(records: list[dict], key: str) -> float:
    values = [r[key] for r in records]
    if not values or any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise ValueError(f'invalid metric: {key}')
    return statistics.median(values)


def run() -> dict:
    protocol_bytes = PROTOCOL_PATH.read_bytes()
    results_bytes = RESULTS_PATH.read_bytes()
    protocol = json_bytes(protocol_bytes, 'protocol')
    results = json_bytes(results_bytes, 'results')
    if results.get('protocol', {}).get('sha256') != sha_bytes(protocol_bytes):
        raise ValueError('results do not identify the frozen protocol bytes')
    if results.get('status') != 'passed' or results.get('decision') != 'drop':
        raise ValueError('frozen result packet is not the expected completed/drop packet')

    cohort_summaries = []
    replayed_records = []
    archive_reports = []
    summary_identities = []
    for cohort, frozen_cohort in zip(results['cohorts'], protocol['cohorts'], strict=True):
        if any(cohort[k] != frozen_cohort[k] for k in ('query_ids', 'lanes', 'pairs')):
            raise ValueError('cohort does not match frozen protocol')
        summary_path = Path(cohort['summary']['path'])
        summary_data = summary_path.read_bytes()
        if len(summary_data) != cohort['summary']['bytes'] or sha_bytes(summary_data) != cohort['summary']['sha256']:
            raise ValueError(f'cohort summary identity mismatch: {summary_path}')
        summary = json_bytes(summary_data, str(summary_path))
        summary_identities.append({**file_identity(summary_path), 'declared_sha256': cohort['summary']['sha256']})
        if summary.get('selected_query_ids') != cohort['query_ids'] or summary.get('max_parallelism') != cohort['lanes']:
            raise ValueError(f'summary query/lanes mismatch: {summary_path}')
        if not summary.get('complete_result_validation') or not summary.get('completed_identity_check'):
            raise ValueError(f'summary lacks complete validation: {summary_path}')
        archives = summary.get('archives', [])
        expected_archives = len(cohort['query_ids'])
        if len(archives) != expected_archives:
            raise ValueError(f'expected {expected_archives} frozen raw archives for cohort')
        payloads = {}
        for archive_manifest in archives:
            checked_archive = manifest_case(summary, archive_manifest)
            archive_reports.append({k: v for k, v in checked_archive.items() if k != 'payloads'})
            overlap = set(payloads) & set(checked_archive['payloads'])
            if overlap:
                raise ValueError(f'duplicate raw member names across cohort archives: {sorted(overlap)[:3]}')
            payloads.update(checked_archive['payloads'])
        summary_records = summary.get('records', [])
        expected_count = len(cohort['query_ids']) * cohort['pairs'] * 2
        if len(summary_records) != expected_count:
            raise ValueError(f'wrong per-call record count for {summary_path}')
        local = []
        for rec in summary_records:
            query, run_id, role = rec['query'], rec['run'], rec['role']
            stem = f'q{query:02d}_run{run_id}_{role}'
            stdout_name, timing_name = stem + '.stdout.json', stem + '.timing.json'
            if stdout_name not in payloads or timing_name not in payloads:
                raise ValueError(f'missing original stdout/timing members: {stem}')
            envelope = json_bytes(payloads[stdout_name], stdout_name)
            fields = envelope_fields(envelope)
            engine_seconds = int(fields['native_query_execution_nanos']) / 1_000_000_000
            timing = json_bytes(payloads[timing_name], timing_name)
            for field, summary_field in (
                ('peak_rss_bytes', 'native_peak_rss_bytes'),
                ('user_cpu_seconds', 'user_cpu_seconds'),
                ('system_cpu_seconds', 'system_cpu_seconds'),
            ):
                if timing[field] != rec[summary_field]:
                    raise ValueError(f'raw resource record mismatch {stem}: {field}')
            cpu = timing['user_cpu_seconds'] + timing['system_cpu_seconds']
            if rec['engine_execution_seconds'] != engine_seconds:
                raise ValueError(f'engine time does not match raw envelope: {stem}')
            if rec['user_cpu_seconds'] + rec['system_cpu_seconds'] != cpu:
                raise ValueError(f'CPU does not match raw resource record: {stem}')
            if rec['native_peak_rss_bytes'] != timing['peak_rss_bytes']:
                raise ValueError(f'RSS does not match raw resource record: {stem}')
            if not rec.get('passed') or rec.get('returncode') != 0 or rec.get('guard_failures'):
                raise ValueError(f'per-call record failed acceptance/guard: {stem}')
            replay = {
                'query': query, 'lanes': cohort['lanes'], 'run': run_id, 'role': role,
                'pair_position': rec['pair_position'], 'engine_seconds_from_envelope': engine_seconds,
                'cpu_seconds_from_resource_member': cpu,
                'rss_bytes_from_resource_member': timing['peak_rss_bytes'],
                'process_wall_seconds_from_resource_member': timing['seconds'],
                'raw_stdout_member': stdout_name, 'raw_timing_member': timing_name,
            }
            local.append(replay)
            replayed_records.append(replay)
        cohort_summaries.append({
            'query_ids': cohort['query_ids'], 'lanes': cohort['lanes'], 'pairs': cohort['pairs'],
            'summary_sha256': sha_bytes(summary_data), 'summary_record_count': len(summary_records),
            'replayed_call_count': len(local),
        })
    if len(replayed_records) != protocol['expected_native_calls']:
        raise ValueError('replayed native-call count differs from frozen protocol')

    # Independently verify the frozen role manifests, binaries, candidate source
    # snapshot, and the two timing/evidence parsers consulted for field semantics.
    frozen_artifacts = []
    for role in ('control', 'candidate'):
        for kind in ('manifest', 'binary'):
            declared = protocol['identities'][role][kind]
            actual = file_identity(Path(declared['path']))
            if actual['bytes'] != declared['bytes'] or actual['sha256'] != declared['sha256']:
                raise ValueError(f'frozen {role} {kind} identity mismatch')
            frozen_artifacts.append({'role': role, 'kind': kind, **actual})
    candidate_source = protocol['candidate_source']
    actual_source = file_identity(Path(candidate_source['path']))
    if actual_source['bytes'] != candidate_source['bytes'] or actual_source['sha256'] != candidate_source['sha256']:
        raise ValueError('candidate source snapshot identity mismatch')
    frozen_source = json_bytes(Path(candidate_source['path']).read_bytes(), 'candidate source snapshot')
    candidate_manifest = json_bytes(
        Path(protocol['identities']['candidate']['manifest']['path']).read_bytes(), 'candidate release manifest')
    if frozen_source.get('source_sha256') != candidate_manifest.get('source_sha256'):
        raise ValueError('candidate source snapshot and candidate release manifest disagree')
    frozen_artifacts.append({'role': 'candidate', 'kind': 'source_snapshot', **actual_source})
    helper_hashes = []
    for item in protocol['helpers']:
        if Path(item['path']).name not in ('native_workflow_protocol.py', 'query_timing_report.py',
                                           'run_clickbench_paired_query_uat.py'):
            continue
        actual = file_identity(Path(item['path']))
        if actual['bytes'] != item['bytes'] or actual['sha256'] != item['sha256']:
            raise ValueError(f'consulted source helper identity mismatch: {item["path"]}')
        helper_hashes.append(actual)

    # The top-level merged records must agree with the three independent raw summary datasets.
    result_records = results.get('records', [])
    if len(result_records) != protocol['expected_native_calls']:
        raise ValueError('results packet record count differs from frozen protocol')
    rec_key = lambda r: (r['query'], r['lanes'], r['run'], r['role'])
    replay_map = {rec_key(r): r for r in replayed_records}
    if len(replay_map) != len(replayed_records):
        raise ValueError('duplicate replay keys')
    top_map = {rec_key(r): r for r in result_records}
    if len(top_map) != len(result_records) or set(top_map) != set(replay_map):
        raise ValueError('merged result record keys mismatch raw summaries')
    for key, raw in replay_map.items():
        top = top_map[key]
        if top['engine_execution_seconds'] != raw['engine_seconds_from_envelope']:
            raise ValueError(f'merged engine clock disagrees with raw envelope at {key}')
        if top['cpu_seconds'] != raw['cpu_seconds_from_resource_member']:
            raise ValueError(f'merged CPU disagrees with raw resource member at {key}')
        if top['native_peak_rss_bytes'] != raw['rss_bytes_from_resource_member']:
            raise ValueError(f'merged RSS disagrees with raw resource member at {key}')

    policy = protocol['policy']
    gates = []
    for case in protocol['cases']:
        q, lanes = case['query'], case['lanes']
        group = [r for r in replayed_records if r['query'] == q and r['lanes'] == lanes]
        control = [r for r in group if r['role'] == 'control']
        candidate = [r for r in group if r['role'] == 'candidate']
        if len(control) != case['pairs'] or len(candidate) != case['pairs']:
            raise ValueError(f'case count mismatch {(q, lanes)}')
        by_pair = {(r['run'], r['role']): r for r in group}
        savings = []
        for run_id in range(1, case['pairs'] + 1):
            c, t = by_pair[(run_id, 'control')], by_pair[(run_id, 'candidate')]
            if c['pair_position'] == t['pair_position']:
                raise ValueError(f'role order does not alternate within pair {(q, lanes, run_id)}')
            if {c['pair_position'], t['pair_position']} != {1, 2}:
                raise ValueError(f'invalid pair positions {(q, lanes, run_id)}')
            expected_first = 'control' if (q + run_id) % 2 == 0 else 'candidate'
            actual_first = 'control' if c['pair_position'] == 1 else 'candidate'
            if actual_first != expected_first:
                raise ValueError(f'pair role order differs from frozen alternating protocol {(q, lanes, run_id)}')
            savings.append(c['engine_seconds_from_envelope'] - t['engine_seconds_from_envelope'])
        cm = statistics.median(r['engine_seconds_from_envelope'] for r in control)
        tm = statistics.median(r['engine_seconds_from_envelope'] for r in candidate)
        c_cpu = statistics.median(r['cpu_seconds_from_resource_member'] for r in control)
        t_cpu = statistics.median(r['cpu_seconds_from_resource_member'] for r in candidate)
        c_rss = statistics.median(r['rss_bytes_from_resource_member'] for r in control)
        t_rss = statistics.median(r['rss_bytes_from_resource_member'] for r in candidate)
        c_wall = statistics.median(r['process_wall_seconds_from_resource_member'] for r in control)
        t_wall = statistics.median(r['process_wall_seconds_from_resource_member'] for r in candidate)
        positive = sum(s > 0 for s in savings)
        paired_median = statistics.median(savings)
        engine_guard = tm <= cm + max(cm * policy['control_engine_increase_fraction'],
                                      policy['control_engine_increase_seconds'])
        cpu_guard = t_cpu <= c_cpu * (1 + policy['target_cpu_increase_fraction'])
        rss_guard = t_rss <= c_rss + max(c_rss * policy['rss_increase_fraction'],
                                         policy['rss_increase_bytes'])
        if case['target']:
            engine_pass = tm < cm and paired_median > 0 and positive >= policy['target_positive_pairs']
        else:
            engine_pass = engine_guard
        gates.append({
            'query': q, 'lanes': lanes, 'pairs': case['pairs'], 'target': case['target'],
            'control_median_engine_seconds': cm, 'candidate_median_engine_seconds': tm,
            'median_engine_saving_seconds': paired_median, 'positive_pairs': positive,
            'paired_engine_savings_seconds': savings,
            'control_median_cpu_seconds': c_cpu, 'candidate_median_cpu_seconds': t_cpu,
            'cpu_increase_fraction': (t_cpu / c_cpu - 1) if c_cpu else None,
            'control_median_rss_bytes': c_rss, 'candidate_median_rss_bytes': t_rss,
            'control_median_process_wall_seconds': c_wall, 'candidate_median_process_wall_seconds': t_wall,
            'engine_target_or_control_guard_passed': engine_pass,
            'cpu_guard_passed': cpu_guard, 'rss_guard_passed': rss_guard,
            'case_passed': engine_pass and cpu_guard and rss_guard,
        })

    reported_by_key = {(g['query'], g['lanes']): g for g in results['gates']}
    disagreements = []
    for g in gates:
        reported = reported_by_key[(g['query'], g['lanes'])]
        for field, actual in (
            ('engine_median_improvement_percent',
             (g['control_median_engine_seconds'] - g['candidate_median_engine_seconds']) /
             g['control_median_engine_seconds'] * 100),
            ('positive_pairs', g['positive_pairs']),
            ('engine_passed', g['engine_target_or_control_guard_passed']),
            ('cpu_passed', g['cpu_guard_passed']),
            ('rss_passed', g['rss_guard_passed']),
            ('passed', g['case_passed']),
        ):
            prior = reported.get(field)
            if isinstance(actual, float):
                same = isinstance(prior, (int, float)) and math.isclose(prior, actual, rel_tol=1e-12, abs_tol=1e-12)
            else:
                same = prior == actual
            if not same:
                disagreements.append({'case': [g['query'], g['lanes']], 'field': field,
                                      'reported': prior, 'independent': actual})
    passed = all(g['case_passed'] for g in gates)
    if (not passed) != (results['decision'] == 'drop'):
        disagreements.append({'field': 'overall_decision', 'reported': results['decision'],
                              'independent': 'retain' if passed else 'drop'})
    return {
        'schema': 'dictionary_growth_independent_replay.v1',
        'status': 'COMPLETE',
        'decision_recomputed': 'retain' if passed else 'drop',
        'decision_in_frozen_results': results['decision'],
        'protocol': file_identity(PROTOCOL_PATH),
        'results': file_identity(RESULTS_PATH),
        'frozen_role_artifacts': frozen_artifacts,
        'candidate_source_file_hashes': frozen_source.get('source_sha256'),
        'consulted_timing_source_hashes': helper_hashes,
        'cohort_summaries': summary_identities,
        'archives': archive_reports,
        'archive_member_count_total': sum(a['manifest_member_count'] for a in archive_reports),
        'expected_native_calls': protocol['expected_native_calls'],
        'replayed_native_calls': len(replayed_records),
        'summary_record_crosscheck_count': len(replayed_records),
        'merged_result_record_crosscheck_count': len(result_records),
        'gates_independently_recomputed': gates,
        'disagreements_with_frozen_gate_claims': disagreements,
        'all_frozen_gate_claims_agree': not disagreements,
        'limitations': [],
    }


if __name__ == '__main__':
    report = run()
    target = OUT / 'dictionary-growth-independent-replay-471.json'
    target.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'decision': report['decision_recomputed'],
                      'replayed_native_calls': report['replayed_native_calls'],
                      'archive_members': report['archive_member_count_total'],
                      'gate_disagreements': len(report['disagreements_with_frozen_gate_claims']),
                      'report': str(target)}, indent=2))
