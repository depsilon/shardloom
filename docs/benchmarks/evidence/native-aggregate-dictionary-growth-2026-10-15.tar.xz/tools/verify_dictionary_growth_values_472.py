"""Reopen every complete recorded result without executing native queries."""
import json
from pathlib import Path
import tarfile
import hashlib

import compare_dictionary_growth_471 as driver

OUT = driver.OUT
protocol = driver.read(driver.DEST / 'protocol.json')
results = driver.read(driver.DEST / 'results.json')
for item in protocol['helpers'] + [protocol['queries'], protocol['reference']]:
    driver.verify(item)
records = []
for cohort in results['cohorts']:
    driver.verify(cohort['summary'])
    records.extend(driver.shared.validate_cohort(Path(cohort['summary']['path']).parent,
                                                 cohort, protocol))
assert records == results['records'] and len(records) == 80
assert driver.shared.gates(protocol, records) == results['gates']
assert results['decision'] == 'drop' and results['lock_released']
assert not (driver.UAT / '.ingest-uat.lock').exists()
source_overlay = OUT / 'dictionary-growth-candidate-source-471.tar.xz'
candidate_source = driver.read(OUT / 'dictionary-growth-471-source.json')['source_sha256']
members = []
with tarfile.open(source_overlay, 'r:xz') as archive:
    for entry in archive:
        assert entry.isfile() and not entry.name.startswith('/') and '..' not in Path(entry.name).parts
        content = archive.extractfile(entry).read()
        digest = hashlib.sha256(content).hexdigest()
        if entry.name.endswith('.rs'):
            name = next(name for name in candidate_source if entry.name.endswith(name))
            assert digest == candidate_source[name]
        else:
            assert entry.name.endswith(Path(protocol['design']['path']).name)
            assert digest == protocol['design']['sha256']
        members.append(dict(name=entry.name, bytes=len(content), sha256=digest))
assert len(members) == 3
receipt = dict(schema_version='shardloom.dictionary_growth_complete_values_replay.v1',
    status='passed', calls=len(records), complete_record_equality=True,
    complete_values_schemas_resources_certificates_fallback_and_source_generation=True,
    complete_gate_equality=True, native_calls_executed=0,
    native_children_absent=True, workload_lock_absent=True,
    protocol=driver.bound(driver.DEST / 'protocol.json'),
    results=driver.bound(driver.DEST / 'results.json'),
    frozen_original_design_and_candidate_source_members=members,
    source_overlay=driver.bound(source_overlay), verifier=driver.bound(__file__))
driver.save(OUT / 'dictionary-growth-complete-values-replay-472.json', receipt)
print(json.dumps(dict(status='passed', complete_calls=80, native_calls_executed=0,
                     source_overlay_members=len(members))))
