#!/usr/bin/env python3
"""Build a portable, deterministic packet for the frozen dictionary-growth DROP."""
from __future__ import annotations

import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
UAT_LOGS = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/logs')
PACKET = OUT / 'dictionary-growth-packet-472'
PREFIX = 'native-aggregate-dictionary-growth-2026-10-15'
COMP = OUT / 'dictionary-growth-comparison-471'
CHUNK = 1024 * 1024
GIB, MIB = 1024**3, 1024**2
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import check_budgets, require_local_path  # noqa: E402


class NeedsReasoning(RuntimeError):
    pass


def need(ok: bool, message: str) -> None:
    if not ok:
        raise NeedsReasoning(message)


def sha_stream(stream) -> tuple[int, str]:
    h = hashlib.sha256()
    size = 0
    while block := stream.read(CHUNK):
        size += len(block)
        h.update(block)
    return size, h.hexdigest()


def identity(path: Path) -> dict:
    path = regular(path)
    before = path.stat()
    with path.open('rb') as stream:
        size, digest = sha_stream(stream)
    after = path.stat()
    before_key = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    after_key = (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    need(before_key == after_key and size == after.st_size, f'file changed while hashing: {path}')
    return {'path': str(path), 'bytes': size, 'sha256': digest}


def regular(path: Path) -> Path:
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode),
         f'expected regular non-symlink file: {path}')
    return path.resolve(strict=True)


def verify(path: Path, expected: dict | None = None) -> dict:
    actual = identity(path)
    if expected is not None:
        need(actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'],
             f'identity mismatch for {path}')
    return actual


class Members:
    def __init__(self) -> None:
        self.items: dict[str, dict] = {}
        self.total = 0

    def add_path(self, path: Path, name: str, role: str, expected: dict | None = None) -> None:
        path = regular(path)
        self._check_name(name)
        if name in self.items:
            prior = self.items[name]
            need(Path(prior['source_path']) == path, f'duplicate archive member name: {name}')
            prior['roles'].append(role)
            return
        item = verify(path, expected)
        self.items[name] = {'archive_path': name, 'source_path': str(path), **item,
                            'roles': [role], 'data': None}
        self.total += item['bytes']

    def add_bytes(self, data: bytes, name: str, role: str, source: str) -> None:
        self._check_name(name)
        need(name not in self.items, f'duplicate archive member name: {name}')
        item = {'archive_path': name, 'source_path': source, 'bytes': len(data),
                'sha256': hashlib.sha256(data).hexdigest(), 'roles': [role], 'data': data}
        self.items[name] = item
        self.total += len(data)

    @staticmethod
    def _check_name(name: str) -> None:
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and bool(p.parts) and '\\' not in name,
             f'unsafe package member path: {name}')

    def ordered(self) -> list[dict]:
        return [self.items[k] for k in sorted(self.items)]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def add_receipt_globs(members: Members) -> None:
    # Preserve all receipts named for this experiment byte-for-byte, including
    # the original independent replay with its earlier all-case CPU guard.
    for path in sorted(OUT.glob('dictionary-growth*.json')):
        members.add_path(path, f'receipts/{path.name}', 'dictionary-growth receipt')
    for path in sorted(OUT.glob('dictionary-growth*.log')):
        members.add_path(path, f'receipts/{path.name}', 'dictionary-growth execution log')
    for name in ('aggregate-dictionary-growth-intake-470.json',
                 'q19-dictionary-growth-inventory-467.json',
                 'q19-dictionary-growth-inventory-468.json',
                 'q19-dictionary-growth-supplement-470.json'):
        members.add_path(OUT / name, f'receipts/{name}', 'related intake/source inventory')
    for name in ('dictionary-growth-candidate-471.patch',
                 'compare_dictionary_growth_471.py',
                 'dictionary-growth-independent-replay-471.py',
                 'dictionary-growth-primary-replay-472.py',
                 'verify_dictionary_growth_values_472.py',
                 'package_dictionary_growth_472.py'):
        members.add_path(OUT / name, f'tools/{name}', 'frozen patch or reproducibility helper')


def check_raw_archive(archive_path: Path, declared: dict) -> dict:
    actual_archive = verify(archive_path, {'bytes': archive_path.stat().st_size,
                                           'sha256': declared['sha256']})
    seen = []
    with tarfile.open(archive_path, mode='r:xz') as archive:
        for item in archive:
            p = PurePosixPath(item.name)
            need(item.isfile() and not p.is_absolute() and '..' not in p.parts,
                 f'unsafe or non-regular nested member: {item.name}')
            stream = archive.extractfile(item)
            need(stream is not None, f'missing nested member bytes: {item.name}')
            size, digest = sha_stream(stream)
            seen.append({'name': item.name, 'bytes': size, 'sha256': digest})
    expected = declared['members']
    need(seen == expected, f'nested archive member list/bytes/hash/order mismatch: {archive_path}')
    return {'path': str(archive_path), 'bytes': actual_archive['bytes'],
            'sha256': actual_archive['sha256'], 'member_count': len(seen),
            'members_in_original_order': seen}


def add_cohorts(members: Members, exclusions: list[dict], raw_archives: list[dict]) -> None:
    results = read_json(COMP / 'results.json')
    protocol = read_json(COMP / 'protocol.json')
    need(results['protocol']['sha256'] == identity(COMP / 'protocol.json')['sha256'],
         'results/protocol frozen hash mismatch')
    need(results['decision'] == 'drop' and protocol['expected_native_calls'] == 80,
         'unexpected frozen comparison decision or call count')
    seen_query_lanes = set()
    for cohort in results['cohorts']:
        summary_path = Path(cohort['summary']['path'])
        summary = read_json(summary_path)
        summary_item = verify(summary_path, cohort['summary'])
        need(summary['selected_query_ids'] == cohort['query_ids'] and
             summary['max_parallelism'] == cohort['lanes'], f'cohort summary identity mismatch: {summary_path}')
        folder = summary_path.parent
        for path in sorted(folder.iterdir()):
            need(not path.is_symlink() and path.is_file(), f'unsupported cohort entry: {path}')
            rel = f'comparison/{folder.name}/{path.name}'
            members.add_path(path, rel, 'complete frozen comparison cohort')
        need(len(summary['archives']) == len(cohort['query_ids']),
             f'expected one raw archive per query in {folder}')
        for archive in summary['archives']:
            archive_path = Path(archive['path'])
            raw_archives.append(check_raw_archive(archive_path, archive))
            for q in cohort['query_ids']:
                if archive_path.name == f'q{q:02d}_completed.tar.xz':
                    seen_query_lanes.add((q, cohort['lanes']))
        if summary_item['bytes'] != cohort['summary']['bytes']:
            raise NeedsReasoning(f'summary bytes mismatch: {summary_path}')
    expected = {(19, 12), (19, 1), (17, 12), (22, 12), (23, 12), (29, 12), (2, 12)}
    need(seen_query_lanes == expected, f'incomplete comparison cohort coverage: {seen_query_lanes}')


def add_protocol_inputs(members: Members, protocol: dict) -> None:
    # Complete query text and full reference-value oracle required to replay.
    for label in ('queries', 'reference'):
        item = protocol[label]
        members.add_path(Path(item['path']), f'inputs/{Path(item["path"]).name}',
                         f'comparison {label}', item)
    for index, item in enumerate(protocol['schema_sources']):
        members.add_path(Path(item['path']), f'inputs/schema-source-{index:02d}-{Path(item["path"]).name}',
                         'frozen expected schema source', item)
    # All helper/source dependencies named by the frozen protocol, checking its hashes.
    for index, item in enumerate(protocol['helpers']):
        path = Path(item['path'])
        members.add_path(path, f'protocol-helpers/{index:02d}/{path.name}',
                         'protocol helper with frozen hash', item)
    for label, item in protocol['identities'].items():
        for kind in ('manifest', 'build_receipt', 'build_log'):
            artifact = item[kind]
            path = Path(artifact['path'])
            members.add_path(path, f'builds/{label}/{kind}/{path.name}',
                             f'{label} {kind}', artifact)
    # Explicit baseline and candidate source hash manifests.
    base_source = OUT / 'selected-views-467-source.json'
    candidate_source = Path(protocol['candidate_source']['path'])
    members.add_path(base_source, f'source-manifests/{base_source.name}', 'baseline source hash manifest')
    members.add_path(candidate_source, f'source-manifests/{candidate_source.name}', 'candidate source hash manifest',
                     protocol['candidate_source'])
    notice = protocol['notice_correction']
    members.add_path(Path(notice['path']), f'builds/baseline-notice/{Path(notice["path"]).name}',
                     'baseline notice correction receipt', notice)


def add_candidate_overlay(members: Members) -> dict:
    archive_path = OUT / 'dictionary-growth-candidate-source-471.tar.xz'
    manifest_path = OUT / 'dictionary-growth-candidate-source-471.json'
    candidate_manifest = read_json(manifest_path)
    archive_id = verify(archive_path, {'bytes': candidate_manifest['bytes'],
                                       'sha256': candidate_manifest['sha256']})
    members.add_path(archive_path, f'candidate-source/{archive_path.name}', 'frozen candidate source tar')
    members.add_path(manifest_path, f'candidate-source/{manifest_path.name}', 'frozen candidate source member manifest')
    extracted = {}
    with tarfile.open(archive_path, mode='r:xz') as archive:
        all_members = archive.getmembers()
        expected = candidate_manifest['members']
        need([m.name for m in all_members] == [r['name'] for r in expected],
             'candidate source archive original member order differs from manifest')
        for member, declaration in zip(all_members, expected, strict=True):
            p = PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts,
                 f'unsafe candidate overlay source member: {member.name}')
            with archive.extractfile(member) as stream:
                data = stream.read()
            actual = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            need(actual == {'bytes': declaration['bytes'], 'sha256': declaration['sha256']},
                 f'candidate source member mismatch: {member.name}')
            extracted[member.name] = data
            # The candidate source files are the exact frozen overlay bytes from
            # this archive, not any currently restored or edited checkout file.
            if member.name.startswith('shardloom-vortex/src/'):
                members.add_bytes(data, f'candidate-overlay/{member.name}',
                                  'exact candidate overlay source from frozen archive',
                                  f'{archive_path}::{member.name}')
            elif member.name.startswith('docs/architecture/'):
                members.add_bytes(data, f'candidate-design/{PurePosixPath(member.name).name}',
                                  'original frozen design from candidate archive',
                                  f'{archive_path}::{member.name}')
    need(len(extracted) == 3, 'candidate source archive must contain two sources plus original design')
    return {'archive': archive_id, 'member_count': len(extracted),
            'members': [{'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in extracted.items()]}


def exclusions_from_protocol(protocol: dict) -> list[dict]:
    exclusions = []
    for role in ('control', 'candidate'):
        item = protocol['identities'][role]['binary']
        path = Path(item['path'])
        need(path.stat().st_size == item['bytes'], f'frozen {role} binary size changed')
        exclusions.append({'role': role, 'path': item['path'], 'bytes': item['bytes'],
                           'sha256': item['sha256'], 'reason': 'frozen native executable excluded; identity from protocol'})
    item = protocol['input']
    path = Path(item['path'])
    need(path.stat().st_size == item['bytes'], 'frozen large input size changed')
    exclusions.append({'role': 'input_dataset', 'path': item['path'], 'bytes': item['bytes'],
                       'sha256': item['sha256'], 'reason': '15.7-GB native payload excluded; identity from protocol'})
    return exclusions


def verify_nested_archive_bytes(name: str, data: bytes, summary_map: dict) -> int:
    declaration = summary_map.get(name)
    need(declaration is not None, f'nested archive lacks matching cohort summary: {name}')
    seen = []
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:xz') as archive:
        for member in archive:
            p = PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts,
                 f'unsafe packaged nested archive member: {member.name}')
            with archive.extractfile(member) as stream:
                size, digest = sha_stream(stream)
            seen.append({'name': member.name, 'bytes': size, 'sha256': digest})
    need(seen == declaration['members'], f'packaged nested archive does not reopen against summary: {name}')
    return len(seen)


def main() -> None:
    require_local_path(PACKET, Path.home(), sys.platform)
    need(not PACKET.exists(), f'packet destination already exists: {PACKET}')
    comp_protocol = read_json(COMP / 'protocol.json')
    comp_results = read_json(COMP / 'results.json')
    members, raw_archives = Members(), []
    add_receipt_globs(members)
    add_cohorts(members, [], raw_archives)
    add_protocol_inputs(members, comp_protocol)
    members.add_path(COMP / 'protocol.json', 'comparison/protocol.json', 'frozen 80-call comparison protocol')
    members.add_path(COMP / 'results.json', 'comparison/results.json', 'frozen 80-call comparison results')
    candidate_source = add_candidate_overlay(members)
    baseline_map = read_json(OUT / 'selected-views-467-source.json')['source_sha256']
    candidate_map = read_json(Path(comp_protocol['candidate_source']['path']))['source_sha256']
    need(set(baseline_map) == set(candidate_map), 'baseline/candidate frozen source inventories differ in paths')
    source_diffs = {name: {'accepted': baseline_map[name], 'candidate': candidate_map[name]}
                    for name in baseline_map if baseline_map[name] != candidate_map[name]}
    exception_path, exception = next(iter(comp_protocol['baseline_metadata_exception'].items()))
    need(baseline_map[exception_path] == exception['measured'] and
         candidate_map[exception_path] == exception['accepted'],
         'frozen baseline metadata exception is inconsistent')
    source_diffs.pop(exception_path)
    need(source_diffs == comp_protocol['source_differences'], 'frozen source difference receipt is inconsistent')
    overlay_names = {row['name']: row for row in candidate_source['members']}
    need(set(overlay_names) == {
        'shardloom-vortex/src/local_primitives.rs',
        'shardloom-vortex/src/local_primitives/utf8_dictionary_ownership_tests.rs',
        'docs/architecture/native-aggregate-dictionary-growth-2026-10-15.md'},
        'candidate overlay archive does not contain exactly two source files and its original design')
    for path, member in overlay_names.items():
        need(candidate_map.get(path) == member['sha256'] if path.startswith('shardloom-vortex/src/') else True,
             f'candidate overlay source hash mismatch: {path}')
    restoration = read_json(OUT / 'dictionary-growth-drop-restoration-471.json')
    patch_id = identity(OUT / 'dictionary-growth-candidate-471.patch')
    need(restoration['status'] == 'passed' and restoration['patch_sha256'] == patch_id['sha256'],
         'restoration receipt does not identify the candidate patch')
    exclusions = exclusions_from_protocol(comp_protocol)

    # The original independent replay's CPU gate applied to all cases. The
    # primary replay explicitly restricts that gate to the target case and adds
    # full execution-order validation; both preserve the same DROP decision.
    limitations = [
        'Local frozen comparison only; operating-system cache was shared and uncontrolled.',
        'The original independent replay receipt is preserved unchanged. It applied the CPU threshold to controls as well as the target; the corrected primary replay records the target-only CPU gate, validates complete call order, and reaches the same DROP.',
        'The separate complete-values replay verifies values, schemas, resources, certificates, source generation, and exact gate equality. No new timing, build, or execution evidence was produced while packaging.',
        'Excluded native executables and the 15.7-GB input are identified by full protocol byte counts and SHA-256 values; they are not packaged.'
    ]
    raw_bytes = members.total
    need(raw_bytes < 192 * MIB, f'compact evidence packet raw size exceeds 192 MiB: {raw_bytes}')
    storage = check_budgets(OUT, PACKET, OUT / 'logs', min_free_bytes=12 * GIB,
                            reserve_bytes=2 * raw_bytes + 64 * MIB,
                            max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    PACKET.mkdir()
    archive_path = PACKET / f'{PREFIX}.tar.xz'
    ordered = members.ordered()
    with archive_path.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                name = item['archive_path']
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = item['bytes'], 0o644, 0
                info.uid, info.gid, info.uname, info.gname = 0, 0, '', ''
                data = item['data']
                if data is None:
                    now = verify(Path(item['source_path']), item)
                    need(now['bytes'] == item['bytes'], f'input changed before packaging: {name}')
                    with Path(item['source_path']).open('rb') as stream:
                        archive.addfile(info, stream)
                else:
                    need(hashlib.sha256(data).hexdigest() == item['sha256'], f'generated source bytes changed: {name}')
                    archive.addfile(info, io.BytesIO(data))

    summary_map = {}
    for cohort in comp_results['cohorts']:
        summary = read_json(Path(cohort['summary']['path']))
        for item in summary['archives']:
            summary_map[f'comparison/{Path(cohort["summary"]["path"]).parent.name}/{Path(item["path"]).name}'] = item
    # Compare every outer package member and, within it, every raw cohort archive.
    seen, nested_member_count = [], 0
    with tarfile.open(archive_path, mode='r:xz') as archive:
        actual_members = archive.getmembers()
        need([m.name for m in actual_members] == [m['archive_path'] for m in ordered],
             'outer archive names/order differ from deterministic member plan')
        for entry, expected in zip(actual_members, ordered, strict=True):
            need(entry.isfile() and entry.size == expected['bytes'], f'outer member type/length mismatch: {entry.name}')
            with archive.extractfile(entry) as stream:
                if entry.name.endswith('_completed.tar.xz') and entry.name.startswith('comparison/'):
                    nested_bytes = stream.read()
                    need(len(nested_bytes) == expected['bytes'] and
                         hashlib.sha256(nested_bytes).hexdigest() == expected['sha256'],
                         f'outer member hash mismatch: {entry.name}')
                    nested_member_count += verify_nested_archive_bytes(entry.name, nested_bytes, summary_map)
                    size, digest = len(nested_bytes), hashlib.sha256(nested_bytes).hexdigest()
                else:
                    size, digest = sha_stream(stream)
            need(size == expected['bytes'] and digest == expected['sha256'],
                 f'outer member hash mismatch: {entry.name}')
            seen.append({'archive_path': entry.name, 'bytes': size, 'sha256': digest})
    need(len(seen) == len(ordered) and nested_member_count == 320,
         f'package readback incomplete: members={len(seen)} nested={nested_member_count}')

    archive_identity = identity(archive_path)
    manifest = {
        'schema_version': 'shardloom.dictionary_growth_packet.v1',
        'status': 'passed', 'decision': 'drop', 'prefix': PREFIX,
        'source_packets': {
            'protocol': identity(COMP / 'protocol.json'), 'results': identity(COMP / 'results.json'),
            'candidate_source_archive': candidate_source,
            'baseline_source_hashes': identity(OUT / 'selected-views-467-source.json'),
            'candidate_source_hashes': identity(Path(comp_protocol['candidate_source']['path'])),
            'base_revision': comp_protocol['baseline_revision'],
            'candidate_source_file_count': len(candidate_map),
            'candidate_source_differences': comp_protocol['source_differences']
        },
        'archive': archive_identity, 'member_count': len(ordered), 'raw_bytes': raw_bytes,
        'all_members_reopened_and_verified': True,
        'nested_raw_archive_member_count': nested_member_count,
        'nested_archives_reopened_against_original_cohort_manifests': len(raw_archives) == 7,
        'members': [{k: v for k, v in item.items() if k != 'data'} for item in ordered],
        'nested_comparison_archives': raw_archives,
        'exclusions': exclusions,
        'storage_guard': storage,
        'replay_limitation': limitations,
        'acceptance_summary': {
            'replayed_native_calls': 80, 'nested_raw_archives': 7, 'nested_raw_members': 320,
            'q19_p12_control_engine_median_seconds': 4.8329276665,
            'q19_p12_candidate_engine_median_seconds': 4.8335464575,
            'q19_p12_median_paired_saving_seconds': -0.0044415405,
            'q19_p12_positive_pairs': 5, 'q19_p12_pairs': 10,
            'q22_p12_control_engine_median_seconds': 1.243627417,
            'q22_p12_candidate_engine_median_seconds': 1.317386458,
            'q22_p12_candidate_increase_percent': 5.930959706398962,
            'primary_replay_and_complete_values_replay_disagreements': 0,
            'decision': 'drop'
        },
        'creation': {'helper': str(Path(__file__).resolve()),
                     'helper_sha256': identity(Path(__file__))['sha256'],
                     'archive_member_order': 'lexicographic by safe POSIX member path',
                     'tar_metadata': 'regular files, mode 0644, uid/gid 0, mtime 0, deterministic xz preset 6'}
    }
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    manifest_path = PACKET / f'{PREFIX}.manifest.json.xz'
    manifest_path.write_bytes(lzma.compress(manifest_raw, preset=6))
    need(lzma.decompress(manifest_path.read_bytes()) == manifest_raw, 'compressed manifest failed readback')
    index = {
        'schema_version': 'shardloom.dictionary_growth_packet_index.v1', 'status': 'passed_local',
        'decision': 'drop', 'member_count': len(ordered), 'raw_bytes': raw_bytes,
        'archive': identity(archive_path), 'manifest': identity(manifest_path),
        'manifest_raw_sha256': hashlib.sha256(manifest_raw).hexdigest(),
        'nested_raw_archives': 7, 'nested_raw_members': nested_member_count,
        'limitations': limitations
    }
    index_path = PACKET / f'{PREFIX}.json'
    index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
    verification = {
        'status': 'passed', 'member_count': len(seen), 'raw_bytes': raw_bytes,
        'all_members_reopened': True, 'nested_raw_archive_members_reopened': nested_member_count,
        'archive': identity(archive_path), 'manifest': identity(manifest_path),
        'index': identity(index_path), 'helper': identity(Path(__file__)),
        'storage_guard': storage, 'exclusions': exclusions
    }
    (PACKET / 'verification.json').write_text(json.dumps(verification, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'passed', 'decision': 'drop', 'members': len(seen),
                      'raw_bytes': raw_bytes, 'archive_bytes': archive_identity['bytes'],
                      'nested_archives': len(raw_archives), 'nested_raw_members': nested_member_count,
                      'packet': str(PACKET)}, indent=2))


if __name__ == '__main__':
    main()
