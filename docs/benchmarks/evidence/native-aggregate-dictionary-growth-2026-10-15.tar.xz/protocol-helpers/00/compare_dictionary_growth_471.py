"""Decide dictionary growth through frozen complete public CLI comparisons."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

import compare_selected_views_467 as shared
from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

DEST = OUT / 'dictionary-growth-comparison-471'
HEAD = 'ba7643df4576c1869dae33ed0c2ef4f9a2e335bb'
INPUT, UAT, REFERENCE = shared.INPUT, shared.UAT, shared.REFERENCE
read, bound, verify = shared.read, shared.bound, shared.verify
paired = shared.paired
CASES = [dict(query=19, lanes=12, pairs=10, target=True),
         dict(query=19, lanes=1, pairs=5, target=False),
         *[dict(query=q, lanes=12, pairs=5, target=False) for q in (17, 22, 23, 29, 2)]]
COHORTS = [dict(query_ids=[19], lanes=12, pairs=10),
           dict(query_ids=[19], lanes=1, pairs=5),
           dict(query_ids=[17, 22, 23, 29, 2], lanes=12, pairs=5)]


def git_source_hashes(names):
    result = {}
    with subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child:
        for name in sorted(names):
            assert '\n' not in name
            child.stdin.write((HEAD + ':' + name + '\n').encode())
            child.stdin.flush()
            header = child.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', name
            data = child.stdout.read(int(header[2]))
            assert child.stdout.read(1) == b'\n'
            result[name] = hashlib.sha256(data).hexdigest()
        child.stdin.close()
        assert child.wait(timeout=30) == 0
    return result


def freeze():
    assert not DEST.exists()
    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(OUT, DEST, OUT / 'logs', min_free_bytes=12*GIB, reserve_bytes=128*MIB,
                  max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    baseline = read(OUT / 'selected-views-467-release.json')
    candidate = read(OUT / 'dictionary-growth-471-release.json')
    assert candidate['head'] == HEAD and candidate['source_sha256'] == sources()
    original = baseline['source_sha256']
    checked = git_source_hashes(original)
    accepted_changes = {name: dict(measured=original[name], accepted=checked[name])
                        for name in original if original[name] != checked[name]}
    assert set(accepted_changes) == {'python/THIRD_PARTY_LICENSES/manifest.json'}
    notice = read(OUT / 'selected-view-hosted-469/notice-correction-470.json')
    assert notice['status'] == 'passed'
    assert set(candidate['source_sha256']) == set(checked)
    changes = {name: dict(accepted=checked[name], candidate=value)
               for name, value in candidate['source_sha256'].items() if value != checked[name]}
    assert set(changes) == {'shardloom-vortex/src/local_primitives.rs',
                           'shardloom-vortex/src/local_primitives/utf8_dictionary_ownership_tests.rs'}
    identities = {}
    for role, manifest, name in [('control', baseline, 'selected-views-467-release.json'),
                                 ('candidate', candidate, 'dictionary-growth-471-release.json')]:
        assert manifest['status'] == 'passed'
        cli = manifest['cli']
        receipt = read(cli['build_receipt'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['direct_child_reaped'] and receipt['process_group_drained']
        assert sha(cli['build_receipt']) == cli['build_receipt_sha256']
        assert sha(cli['build_log']) == receipt['log_sha256']
        assert sha(cli['path']) == cli['sha256']
        identities[role] = dict(manifest=bound(OUT / name), binary=bound(cli['path']),
            build_receipt=bound(cli['build_receipt']), build_log=bound(cli['build_log']))
    assert identities['candidate']['binary']['sha256'] != identities['control']['binary']['sha256']
    records = [json.loads(line) for line in Path(candidate['cli']['build_log']).read_text().splitlines()
               if line.startswith('{')]
    compiled = [r for r in records if r.get('reason') == 'compiler-artifact'
                and r.get('target', {}).get('name') in ('shardloom_vortex', 'shardloom')]
    assert len(compiled) == 2 and all(r['fresh'] is False for r in compiled)
    accepted = read(ROOT / 'docs/benchmarks/evidence/native-query-timing-uat-2026-10-15.json')
    input_receipt = accepted['datasets'][str(INPUT)]
    generation = paired.generation(INPUT)
    assert generation == input_receipt['generation']
    assert INPUT.stat().st_flags == 0 and INPUT.stat().st_blocks * 512 >= INPUT.stat().st_size
    input_identity = bound(INPUT)
    assert input_identity['sha256'] == input_receipt['sha256']
    assert paired.generation(INPUT) == generation
    queries = ROOT / 'benchmarks/clickbench/queries.sql'
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = shared.load_reference_packet(REFERENCE, queries)
    schemas, schema_sources = {}, []
    for query in sorted({case['query'] for case in CASES}):
        path = shared.BASELINE_RUN / f'q{query:02d}_run1.stdout.json'
        envelope = shared.read_json_log(path)
        assert shared.equivalent(shared.extract_result(envelope), reference['values'][query])
        fields = shared.report_fields(envelope)
        schemas[str(query)] = [fields['result_schema_format'], shared.strict_json(fields['result_schema_json'])]
        schema_sources.append(bound(path if path.exists() else path.with_suffix('.json.gz')))
    helpers = [Path(__file__), Path(shared.__file__), OUT / 'freeze_native_release_298.py',
               OUT / 'freeze_query_cli_368.py', OUT / 'run_guarded.py',
               Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helpers += [ROOT / 'scripts' / name for name in ('run_clickbench_paired_query_uat.py',
        'run_clickbench_query_uat.py', 'local_uat_storage.py', 'native_workflow_protocol.py',
        'timed_native_command.py', 'query_timing_report.py', 'clickbench_reference_packet.py')]
    protocol = dict(schema_version='shardloom.dictionary_growth_comparison.v1', frozen_at=time.time(),
        purpose='complete_public_CLI_calls_with_engine_primary_retention_gate', cases=CASES, cohorts=COHORTS,
        expected_native_calls=80, baseline_revision=HEAD, identities=identities,
        candidate_source=bound(OUT / 'dictionary-growth-471-source.json'), source_differences=changes,
        baseline_source_files_checked=len(checked), baseline_metadata_exception=accepted_changes,
        notice_correction=bound(OUT / 'selected-view-hosted-469/notice-correction-470.json'),
        changed_crates_recompiled=compiled, input=input_identity, input_generation=generation, input_rows=99997497,
        queries=bound(queries), reference=bound(REFERENCE), expected_schemas=schemas, schema_sources=schema_sources,
        helpers=[bound(path) for path in helpers],
        design=bound(ROOT / 'docs/architecture/native-aggregate-dictionary-growth-2026-10-15.md'),
        policy=dict(memory_gb=24, target_positive_pairs=9, target_cpu_increase_fraction=0.05,
            control_engine_increase_fraction=0.05, control_engine_increase_seconds=0.005,
            rss_increase_fraction=0.25, rss_increase_bytes=256*MIB, artificial_delay_seconds=0,
            automatic_retry=False, power_or_thermal_admission=False),
        order='Maintained runner role_order(query, run): alternating role order for every pair.',
        timing='Engine execution is primary; complete process, output, CPU, RSS, validation and supervision remain separate.',
        cache='Full input prehash before measurement; ordinary shared OS cache remains uncontrolled. Fresh process per call.',
        hardware=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
                      physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')))
    DEST.mkdir()
    save(DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen', native_calls=80,
        candidate_hash=identities['candidate']['binary']['sha256'])), flush=True)


def run():
    path = DEST / 'protocol.json'
    protocol = read(path)
    for item in protocol['helpers'] + protocol['schema_sources'] + [protocol['design'], protocol['queries'],
            protocol['reference'], protocol['candidate_source'], protocol['notice_correction']]:
        verify(item)
    for identity in protocol['identities'].values():
        for item in identity.values(): verify(item)
    assert sources() == read(protocol['candidate_source']['path'])['source_sha256']
    assert paired.generation(INPUT) == protocol['input_generation']
    verify(protocol['input'])
    report = dict(status='running', protocol=bound(path), cohorts=[], records=[])
    started = time.perf_counter()
    try:
        for cohort in protocol['cohorts']:
            assert paired.generation(INPUT) == protocol['input_generation']
            before = set((UAT / 'logs').glob('paired43_*'))
            command = [str(ROOT / 'scripts/run_clickbench_paired_query_uat.py'),
                '--control-binary', protocol['identities']['control']['binary']['path'], '--control-commit', HEAD,
                '--candidate-binary', protocol['identities']['candidate']['binary']['path'],
                '--candidate-commit', HEAD + '+dictionary-growth-' + protocol['candidate_source']['sha256'][:12],
                '--input', str(INPUT), '--uat-root', str(UAT), '--reference-packet', str(REFERENCE),
                '--query-ids', ','.join(map(str, cohort['query_ids'])), '--repeats', str(cohort['pairs']),
                '--memory-gb', '24', '--max-parallelism', str(cohort['lanes']), '--timeout', '120']
            sys.argv = command
            code = paired.main()
            added = set((UAT / 'logs').glob('paired43_*')) - before
            assert len(added) == 1
            folder = added.pop()
            report['cohorts'].append(dict(**cohort, command=command, returncode=code,
                summary=bound(folder / 'summary.json')))
            assert code == 0
            report['records'].extend(shared.validate_cohort(folder, cohort, protocol))
            assert not (UAT / '.ingest-uat.lock').exists()
            assert sources() == read(protocol['candidate_source']['path'])['source_sha256']
        assert len(report['records']) == protocol['expected_native_calls']
        report['gates'] = shared.gates(protocol, report['records'])
        verify(protocol['input'])
        assert paired.generation(INPUT) == protocol['input_generation']
        for item in protocol['helpers'] + [protocol['design'], protocol['queries'], protocol['reference']]:
            verify(item)
        for identity in protocol['identities'].values():
            for item in identity.values(): verify(item)
        report.update(status='passed', decision='retain' if all(g['passed'] for g in report['gates']) else 'drop')
    except BaseException as error:
        report.update(status='failed', decision='invalid', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['workflow_seconds'] = time.perf_counter() - started
        report['lock_released'] = not (UAT / '.ingest-uat.lock').exists()
        save(DEST / 'results.json', report)
    print(json.dumps(dict(status=report['status'], decision=report['decision'], cases=report['gates'])), flush=True)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['freeze', 'run'])
    args = parser.parse_args()
    freeze() if args.operation == 'freeze' else run()
