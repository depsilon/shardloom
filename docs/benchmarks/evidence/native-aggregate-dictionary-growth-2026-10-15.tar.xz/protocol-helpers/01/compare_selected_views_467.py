"""Freeze and decide selected-view work through the maintained paired CLI runner."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import sys
import tarfile
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT / 'selected-view-comparison-467'
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
MERGE = '2b87cf7f911d667b7ef279fdedb1ba4ef2167459'
INPUT = UAT / 'vortex/timed-native-461-a1.vortex'
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json')
BASELINE_RUN = UAT / 'logs/full43_20261015T090121385273Z'
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from clickbench_reference_packet import load_reference_packet
from freeze_native_release_298 import save, sha, sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent, read_json_log
import run_clickbench_paired_query_uat as paired

CASES = [dict(query=23, lanes=12, pairs=10, target=True),
         dict(query=23, lanes=1, pairs=5, target=False),
         *[dict(query=q, lanes=12, pairs=5, target=False) for q in (22, 19, 29, 2)]]
COHORTS = [dict(query_ids=[23], lanes=12, pairs=10),
           dict(query_ids=[23], lanes=1, pairs=5),
           dict(query_ids=[22, 19, 29, 2], lanes=12, pairs=5)]


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def verify(item):
    assert bound(item['path']) == item, item['path']


def freeze():
    assert not DEST.exists()
    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(OUT, DEST, OUT / 'logs', min_free_bytes=12*GIB, reserve_bytes=128*MIB,
                  max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    candidate = read(OUT / 'selected-views-467-release.json')
    baseline = read(OUT / 'query-timing-460-artifacts.json')
    hosted = read(OUT / 'compression-hosted-466/verification.json')
    assert hosted['status'] == 'passed' and hosted['merge'] == MERGE
    assert hosted['accepted_native_source_preserved']
    assert candidate['source_sha256'] == sources()
    assert candidate['head'] == MERGE
    identities = {}
    for role, manifest, name in [('control', baseline, 'query-timing-460-artifacts.json'),
                                  ('candidate', candidate, 'selected-views-467-release.json')]:
        assert manifest['status'] == 'passed'
        cli = manifest['cli']
        receipt = read(cli['build_receipt'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['direct_child_reaped'] and receipt['process_group_drained']
        assert sha(cli['build_receipt']) == cli['build_receipt_sha256']
        assert sha(cli['build_log']) == receipt['log_sha256']
        assert sha(cli['path']) == cli['sha256']
        identities[role] = dict(manifest=bound(OUT / name), binary=bound(cli['path']),
            build_receipt=bound(cli['build_receipt']), build_log=bound(cli['build_log']))
    assert identities['candidate']['binary']['sha256'] != identities['control']['binary']['sha256']
    records = [json.loads(line) for line in Path(candidate['cli']['build_log']).read_text().splitlines()
               if line.startswith('{')]
    provider = [r for r in records if r.get('reason') == 'compiler-artifact'
                and r.get('target', {}).get('name') == 'vortex_zstd']
    assert len(provider) == 1 and provider[0]['fresh'] is False
    assert '/vendor/vortex-zstd#0.85.0' in provider[0]['package_id']
    baseline_sources = read(baseline['source_manifest']['path'])['source_sha256']
    differences = {name: dict(baseline=baseline_sources.get(name), candidate=digest)
        for name, digest in candidate['source_sha256'].items() if baseline_sources.get(name) != digest}
    assert set(baseline_sources) <= candidate['source_sha256'].keys()
    expected = {'scripts/run_clickbench_query_uat.py', 'scripts/run_clickbench_paired_query_uat.py',
        'scripts/test_clickbench_query_uat.py', 'scripts/test_clickbench_paired_query_uat.py',
        'shardloom-vortex/src/native_provider_zstd_filter.rs',
        'shardloom-vortex/src/native_provider_zstd_filter_tests.rs',
        'vendor/vortex-zstd/src/array.rs', 'vendor/vortex-zstd/src/selected.rs',
        'vendor/vortex-zstd/upstream-provenance.json'}
    assert set(differences) == expected, sorted(differences)
    accepted = read(ROOT / 'docs/benchmarks/evidence/native-query-timing-uat-2026-10-15.json')
    input_receipt = accepted['datasets'][str(INPUT)]
    generation = paired.generation(INPUT)
    assert generation == input_receipt['generation']
    assert INPUT.stat().st_flags == 0 and INPUT.stat().st_blocks * 512 >= INPUT.stat().st_size
    input_identity = bound(INPUT)
    assert input_identity['sha256'] == input_receipt['sha256']
    assert paired.generation(INPUT) == generation
    queries = ROOT / 'benchmarks/clickbench/queries.sql'
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = load_reference_packet(REFERENCE, queries)
    schemas, schema_sources = {}, []
    for query in sorted({case['query'] for case in CASES}):
        path = BASELINE_RUN / f'q{query:02d}_run1.stdout.json'
        envelope = read_json_log(path)
        assert equivalent(extract_result(envelope), reference['values'][query])
        fields = report_fields(envelope)
        schemas[str(query)] = [fields['result_schema_format'], strict_json(fields['result_schema_json'])]
        schema_sources.append(bound(path if path.exists() else path.with_suffix('.json.gz')))
    helper_paths = [Path(__file__), OUT / 'freeze_native_release_298.py', OUT / 'run_guarded.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helper_paths += [ROOT / 'scripts' / name for name in ('run_clickbench_paired_query_uat.py',
        'run_clickbench_query_uat.py', 'local_uat_storage.py', 'native_workflow_protocol.py',
        'timed_native_command.py', 'query_timing_report.py', 'clickbench_reference_packet.py')]
    protocol = dict(schema_version='shardloom.selected_text_views_comparison.v1', frozen_at=time.time(),
        purpose='complete_public_CLI_calls_with_engine_primary_retention_gate', cases=CASES, cohorts=COHORTS,
        expected_native_calls=70, baseline_revision=MERGE, identities=identities,
        candidate_source=bound(OUT / 'selected-views-467-source.json'), source_differences=differences,
        provider_recompiled=True, provider_compiler_artifact=provider[0],
        input=input_identity, input_generation=generation, input_rows=99997497,
        queries=bound(queries), reference=bound(REFERENCE), expected_schemas=schemas, schema_sources=schema_sources,
        helpers=[bound(path) for path in helper_paths],
        design=bound(ROOT / 'docs/architecture/native-selected-text-views-2026-10-15.md'),
        policy=dict(memory_gb=24, target_positive_pairs=9, target_cpu_increase_fraction=0.05,
            control_engine_increase_fraction=0.05, control_engine_increase_seconds=0.005,
            rss_increase_fraction=0.25, rss_increase_bytes=256*MIB, artificial_delay_seconds=0,
            automatic_retry=False, power_or_thermal_admission=False),
        order='Maintained runner role_order(query, run): alternating role order for every pair.',
        timing='Engine execution is primary; complete process, output, CPU, RSS, validation and supervision remain separate.',
        cache='Full input prehash before measurement; ordinary shared OS cache remains uncontrolled. Fresh process per call.',
        hardware=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
                      physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')))
    DEST.mkdir()
    save(DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen', native_calls=70, candidate_hash=identities['candidate']['binary']['sha256'])))


def validate_cohort(folder, cohort, protocol):
    summary = read(folder / 'summary.json')
    assert summary['schema_version'] == 'shardloom.clickbench.counterbalanced_pairs.v2'
    assert summary['completed_identity_check'] and summary['complete_result_validation']
    assert summary['reference_packet_identity_verified'] and summary['scores']['complete']
    assert summary['scores']['timing_available'] and summary['scores']['timing_metric'] == 'engine_execution_seconds'
    expected = [(q, run, role) for q in cohort['query_ids'] for run in range(1, cohort['pairs'] + 1)
                for role in paired.role_order(q, run)]
    assert [(r['query'], r['run'], r['role']) for r in summary['records']] == expected
    assert summary['source_generation'] == protocol['input_generation']
    raw = {}
    for archive in summary['archives']:
        assert sha(archive['path']) == archive['sha256']
        with tarfile.open(archive['path'], 'r:xz') as stream:
            assert stream.getnames() == [m['name'] for m in archive['members']]
            for member in archive['members']:
                payload = stream.extractfile(member['name']).read()
                assert len(payload) == member['bytes'] and hashlib.sha256(payload).hexdigest() == member['sha256']
                assert member['name'] not in raw
                raw[member['name']] = payload
    reference = load_reference_packet(REFERENCE, ROOT / 'benchmarks/clickbench/queries.sql')
    result = []
    for row in summary['records']:
        assert row['passed'] and row['validation'] == 'complete_values'
        assert row['returncode'] == 0 and not row['guard_failures']
        prefix = f"q{row['query']:02d}_run{row['run']}_{row['role']}"
        envelope = strict_json(raw[prefix + '.stdout.json'].decode())
        fields = report_fields(envelope)
        assert equivalent(extract_result(envelope), reference['values'][row['query']])
        assert [fields['result_schema_format'], strict_json(fields['result_schema_json'])] == protocol['expected_schemas'][str(row['query'])]
        assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
        assert fields['execution_resource_declared_max_parallelism'] == str(cohort['lanes'])
        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
        pid = int(raw[prefix + '.pid'])
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError(f'native PID remains: {pid}')
        copy = dict(row, lanes=cohort['lanes'], native_child_absent=True,
                    cpu_seconds=row['user_cpu_seconds'] + row['system_cpu_seconds'])
        for key in ('engine_execution_seconds', 'seconds', 'cpu_seconds', 'native_peak_rss_bytes'):
            assert type(copy[key]) in (int, float) and math.isfinite(copy[key]) and copy[key] > 0
        result.append(copy)
    return result


def gates(protocol, records):
    decisions = []
    policy = protocol['policy']
    for case in protocol['cases']:
        by_role = {role: sorted([r for r in records if r['query'] == case['query'] and r['lanes'] == case['lanes']
                                  and r['role'] == role], key=lambda r:r['run']) for role in ('control', 'candidate')}
        assert all([r['run'] for r in rows] == list(range(1, case['pairs'] + 1)) for rows in by_role.values())
        medians = {role: {key: statistics.median(r[key] for r in rows) for key in
                   ('engine_execution_seconds', 'seconds', 'cpu_seconds', 'native_peak_rss_bytes')}
                   for role, rows in by_role.items()}
        a, b = medians['control'], medians['candidate']
        savings = [x['engine_execution_seconds'] - y['engine_execution_seconds']
                   for x, y in zip(by_role['control'], by_role['candidate'], strict=True)]
        positive = sum(value > 0 for value in savings)
        engine = (b['engine_execution_seconds'] < a['engine_execution_seconds']
                  and statistics.median(savings) > 0 and positive >= policy['target_positive_pairs']) if case['target'] else (
            b['engine_execution_seconds'] <= a['engine_execution_seconds'] + max(
                policy['control_engine_increase_fraction'] * a['engine_execution_seconds'], policy['control_engine_increase_seconds']))
        cpu = not case['target'] or b['cpu_seconds'] <= a['cpu_seconds'] * (1 + policy['target_cpu_increase_fraction'])
        rss = b['native_peak_rss_bytes'] <= a['native_peak_rss_bytes'] + max(
            policy['rss_increase_fraction'] * a['native_peak_rss_bytes'], policy['rss_increase_bytes'])
        decisions.append(dict(**case, medians=medians, paired_engine_savings_seconds=savings,
            positive_pairs=positive, engine_passed=engine, cpu_passed=cpu, rss_passed=rss,
            passed=engine and cpu and rss,
            engine_median_improvement_percent=100*(a['engine_execution_seconds']-b['engine_execution_seconds'])/a['engine_execution_seconds']))
    return decisions


def run():
    protocol_path = DEST / 'protocol.json'
    protocol = read(protocol_path)
    for item in protocol['helpers'] + protocol['schema_sources'] + [protocol['design'], protocol['queries'], protocol['reference'], protocol['candidate_source']]:
        verify(item)
    for identity in protocol['identities'].values():
        for item in identity.values(): verify(item)
    assert sources() == read(protocol['candidate_source']['path'])['source_sha256']
    assert paired.generation(INPUT) == protocol['input_generation']
    verify(protocol['input'])
    report = dict(status='running', protocol=bound(protocol_path), cohorts=[], records=[])
    started = time.perf_counter()
    try:
        for cohort in protocol['cohorts']:
            assert paired.generation(INPUT) == protocol['input_generation']
            before = set((UAT / 'logs').glob('paired43_*'))
            command = [str(ROOT / 'scripts/run_clickbench_paired_query_uat.py'),
                '--control-binary', protocol['identities']['control']['binary']['path'], '--control-commit', MERGE,
                '--candidate-binary', protocol['identities']['candidate']['binary']['path'],
                '--candidate-commit', MERGE + '+selected-views-' + protocol['candidate_source']['sha256'][:12],
                '--input', str(INPUT), '--uat-root', str(UAT), '--reference-packet', str(REFERENCE),
                '--query-ids', ','.join(map(str, cohort['query_ids'])), '--repeats', str(cohort['pairs']),
                '--memory-gb', '24', '--max-parallelism', str(cohort['lanes']), '--timeout', '120']
            sys.argv = command
            code = paired.main()
            added = set((UAT / 'logs').glob('paired43_*')) - before
            assert len(added) == 1
            folder = added.pop()
            report['cohorts'].append(dict(**cohort, command=command, returncode=code, summary=bound(folder / 'summary.json')))
            assert code == 0
            report['records'].extend(validate_cohort(folder, cohort, protocol))
            assert not (UAT / '.ingest-uat.lock').exists()
            assert sources() == read(protocol['candidate_source']['path'])['source_sha256']
        assert len(report['records']) == protocol['expected_native_calls']
        report['gates'] = gates(protocol, report['records'])
        verify(protocol['input'])
        assert paired.generation(INPUT) == protocol['input_generation']
        for item in protocol['helpers'] + [protocol['design'], protocol['queries'], protocol['reference']]: verify(item)
        for identity in protocol['identities'].values():
            for item in identity.values(): verify(item)
        report.update(status='passed', decision='retain' if all(g['passed'] for g in report['gates']) else 'drop')
    except BaseException as error:
        report.update(status='failed', decision='invalid', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['workflow_seconds'] = time.perf_counter() - started
        report['lock_released'] = not (UAT / '.ingest-uat.lock').exists()
        save(DEST / 'results.json', report)
    print(json.dumps(dict(status=report['status'], decision=report['decision'], cases=report['gates'])), flush=True)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['freeze', 'run'])
    args = parser.parse_args()
    freeze() if args.operation == 'freeze' else run()
