# Standalone provider and Parquet fixture inventory r1

Repository HEAD: `0205283370712637305aba07a86f5854e833da6e`.

## Provider runner

The current runner configures 13 providers in groups `arrays, io, buffer, formats`. Exact commands, feature args, fixture variables, manifest hashes and lock hashes are in the JSON report.
The provider lock directory has 13 `.lock` files; 13 match configured providers. Extra lock(s): `none`. Parquet has no standalone config or lock.
The README says `These eight lockfiles freeze the existing excluded provider test configurations.`; the directory contains 13 locks. It describes lock resolution and `cargo metadata --locked`, but states no literal generation command. CI copies each reviewed lock into the provider package and checks its identity afterward.
No test exclusions are inferred; the JSON records the current literal runner commands.

## Parquet 59.3.2 and fixtures

`vendor/parquet/Cargo.toml` declares license `Apache-2.0`, default features `arrow, snap, brotli, flate2-zlib-rs, lz4, zstd, base64, simdutf8`, and 6 explicit `[[test]]` targets (`autotests = False`). Exact target names, paths, required-features and source lines are in JSON. ShardLoom has no configured Parquet command. The Arrow-rs 59.3.2 guide separately documents `cargo test -p parquet` as an upstream example.
Arrow 59.3.2's `parquet_test_data()` uses `PARQUET_TEST_DATA` as an override; its literal default is `../parquet-testing/data` relative to compile-time `CARGO_MANIFEST_DIR`. Parquet source derives sibling `bad_data/` and `shredded_variant/` paths. Source references and lines are in JSON. No `ARROW_TEST_DATA` call was found in scanned Parquet sources; Arrow's helper separately exposes that variable.
The Arrow-rs 59.3.2 tag pins `apache/parquet-testing` to `09f3cdbde45302f0f0c689c950e465e98a9df960`. Pinned Git-tree metadata: `data/` 115 blobs/4144329 bytes; `bad_data/` 23/170012; `shredded_variant/` 276/224870. Repo metadata declares SPDX `Apache-2.0`; pinned `LICENSE.txt` SHA-256 `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`. These are literal metadata, not license conclusions.
Only GitHub metadata, tree entries, README and license text are retained. No Parquet fixture payload was downloaded.

## Official sources

- [Arrow-rs 59.3.2 `.gitmodules`](https://github.com/apache/arrow-rs/blob/59.3.2/.gitmodules)
- [Arrow-rs 59.3.2 contributor instructions](https://github.com/apache/arrow-rs/blob/59.3.2/CONTRIBUTING.md)
- [Pinned parquet-testing revision](https://github.com/apache/parquet-testing/commit/09f3cdbde45302f0f0c689c950e465e98a9df960) and [LICENSE.txt](https://github.com/apache/parquet-testing/blob/09f3cdbde45302f0f0c689c950e465e98a9df960/LICENSE.txt)
- [parquet-testing repository metadata](https://api.github.com/repos/apache/parquet-testing)

## Scope

Read-only inventory. No Cargo commands, builds, tests, lock updates, fixture checkout/download, repository edits, compatibility/license decisions, or inferred test exclusions.
