# Resolved graph inventory r3

Baseline Git commit: `0205283370712637305aba07a86f5854e833da6e`
Current Cargo.lock SHA-256: `8354a8f33c1a311a7aa92118c5b2a3e8e12d02c923b4015603fa3c45986dbcd3` (unchanged at end).
Baseline Cargo.lock SHA-256: `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772`.

## Coverage

Manifest evidence records: 104; status counts: `{"verified": 104}`.
Exact full-identity changes from baseline: 50 updated, 1 added, 3 removed.
Baseline/current changed-evidence records: 53/51. Registry archives reverified: 84.

The current r2-to-r3 lock identity transition is `vortex-arrow 0.93.0`: registry source `registry+https://github.com/rust-lang/crates.io-index` to path source. The current path manifest SHA-256 is `75f8550231fa5f8facbef923f63cac3136649f4beafc973d8471b43a8ad61b3a`; its upstream archive and VCS identity are separately recorded in `r2_manifest_evidence`.

Baseline path-provider manifests were read from the exact baseline Git tree; current path-provider manifests were read from the active worktree. Registry manifests were accepted only after archive SHA-256 matched the exact lock checksum and Cargo.toml member bytes/hash/identity were rechecked. The compatible `r2_manifest_evidence` key is retained.

## Unresolved or mismatched evidence

- None.

No network, Cargo commands, builds, or repository writes were used. This is read-only graph inventory; no license, compatibility, or security acceptance decision is made.
