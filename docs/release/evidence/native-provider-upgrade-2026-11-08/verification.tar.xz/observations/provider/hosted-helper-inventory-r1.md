# Hosted helper inventory (r1)

Scope: six helpers in `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools` and the packet verifier directly invoked by the preparation helper. This records source contracts for later adaptation; it is not approval or implementation.

## `prepare_vector_delivery.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/prepare_vector_delivery.py`; 4837 bytes, 86 lines, SHA-256 `327d98402a39704a873e1c36082d58e4fd2fdf2172f5d4dbb89b1afb71e29b01`.
Relevant lines: `7-25, 27-52, 53-72, 74-86`.
CLI: none.
Key inputs:
- `<ROOT>/docs/release/evidence/native-vector-representations-2026-11-07/acceptance.json`: `status=local_acceptance_passed`, `source_base`, `code_snapshot`, `runtime_and_wheel`, `installed_package` (prepare 27-30, 74-82; verifier 96-105, 230-243).
- `<U>/float16-closeout-r1.json`: `status=complete`, `merge_commit` (prepare 10, 28-31).
- `<U>/vectors-final-docs-r1.json`: `status=passed`, `process_group_drained=true`, `head=base`, `changed_source_inventory` (prepare 58-70).
- `<U>/installed-proof-r1/report.json`: `integrity.cli_sha256`, `integrity.native_library_sha256`, `integrity.wheel_sha256` (prepare 66-72).
- `<ROOT>/docs/release/evidence/native-vector-representations-2026-11-07/corruption-controls.json`: `status=passed`, `positive_controls=2`, `rejected_controls=9`, `exact_fixture_mutations_verified`, `original_packet_unchanged`, `observation.original_files` (prepare 55-57).
- `<ROOT>/docs/release/evidence/native-vector-representations-2026-11-07/{verification.tar.xz,verify.py,README.md}`: `identity checked by verify.py / identity helper` (prepare 53-54, 80-82; verifier 96-117).
- `<ROOT>/docs/release/evidence/native-vector-representations-2026-11-07/{verification.tar.xz,verify.py,README.md}`: `archive SHA/member identities verified by child verifier`, `README.md included in exact expected changed-file set` (prepare_vector_delivery.py:45-54; verify.py:96-117).
Outputs:
- `<U>/delivery-acceptance-r1.json`: `status`, `head`, `tree`, `base`, `base_branch`, `runtime_sources_match_build`, `runtime_source_proof`, `ci_workflow_blob`, `acceptance`.
Hardcoded paths/limits: /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; <ROOT>/docs/release/evidence/native-vector-representations-2026-11-07; parent of script directory (= U); <U parent>/float16-lifecycle-2026-11-07/float16-closeout-r1.json; <U>/runtime-r2/shardloom; <U>/runtime-r2/lib_native.dylib; <U>/installed-proof-r1/dist/<wheel>; Expected diff contains dynamic code_snapshot + 10 fixed docs/user-surface/python README paths + 5 release packet paths (acceptance, archive, verifier, README, corruption controls).; Corruption control threshold is 2 positive and 9 rejected..
Effects: read_only_local_git: git <read-only inspection args>; read_only_subprocess: python3.13 -I <PACKET>/verify.py --repo-root <ROOT>; local_write: exclusive creation of delivery-acceptance-r1.json.
Direct local helper: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo/docs/release/evidence/native-vector-representations-2026-11-07/verify.py` via `/opt/homebrew/opt/python@3.13/libexec/bin/python3 -I <PACKET>/verify.py --repo-root <ROOT>`.

## `final_vector_review.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/final_vector_review.py`; 4777 bytes, 92 lines, SHA-256 `2ec2bac5d596d4cd94838f753a7a68415beb55f0e38a2fdfeb6f609bd9ef99e3`.
Relevant lines: `10-29, 34-49, 50-71, 72-91`.
CLI: `--pre` (Path) required.
Key inputs:
- `--pre JSON`: `status=passed_premerge`, `successful_hosted_checks=58`, `pr positive integer`, `tree_matches_synthetic=true`, `head`, `base` (lines 14-20).
- `GitHub PR via GET`: `head.sha`, `base.sha`, `base.ref=main`, `state=open`, `draft=false`, `mergeable=true` (lines 51-55).
- `GitHub check runs via GET`: `total_count`, `check_runs[].name/head_sha/status/conclusion`; ['count exactly equals required check names; all completed success for exact head'] (lines 56-62).
- `GitHub issue comments via GET`: `user.login`, `body`, `html_url`; ['<100 comments; exactly one current-head Codex review-state marker; completed review; no findings'] (lines 63-71).
- `GitHub GraphQL read`: `reviewDecision`, `mergeable`, `headRefOid`, `baseRefOid`, `reviewThreads.nodes{id,isResolved,isOutdated}`, `reviewThreads.pageInfo.hasNextPage` (lines 72-77).
Outputs:
- `<U>/pr<N>-final-raw-r1/{pull,checks,comments,review}.json`; count 4: `E`, `x`, `a`, `c`, `t`, ` `, `r`, `a`, `w`, ` `, `R`, `E`, `S`, `T`, `/`, `G`, `r`, `a`, `p`, `h`, `Q`, `L`, ` `, `r`, `e`, `s`, `p`, `o`, `n`, `s`, `e`, ` `, `b`, `y`, `t`, `e`, `s`, `;`, ` `, `S`, `H`, `A`, `-`, `2`, `5`, `6`, `s`, ` `, `s`, `u`, `m`, `m`, `a`, `r`, `i`, `z`, `e`, `d`, ` `, `i`, `n`, ` `, `r`, `e`, `p`, `o`, `r`, `t`, ` `, `r`, `a`, `w`, `_`, `s`, `o`, `u`, `r`, `c`, `e`, `s`.
- `<U>/pr<N>-final-checks-r1.json`: `status`, `pr`, `head`, `base`, `observed_at`, `premerge_sha256`, `observer_sha256`, `successful_hosted_checks`, `required_check_names`.
- `<U>/pr<N>-final-review-r1.json`: `status`, `pr`, `head`, `base`, `observed_at`, `premerge_sha256`, `observer_sha256`, `automated_review`, `review_url`.
Hardcoded paths/limits: /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; parent of script directory (= U); depsilon/shardloom; OUT/pr<N>-final-raw-r1, pr<N>-final-checks-r1.json, pr<N>-final-review-r1.json; requires exactly 58 completed hosted checks; maximum raw response <8 MiB each; comments and GraphQL connection pages must not have more than 100 entries.
Effects: read_only_API_query: /opt/homebrew/bin/gh api ...; hosted_api_read: GET pulls/<pr>; hosted_api_read: GET commits/<head>/check-runs?per_page=100&filter=latest; hosted_api_read: GET issues/<pr>/comments?per_page=100; hosted_api_read: GraphQL read query on pullRequest; local_write: create raw-r1 directory; local_write: write four exact raw response JSON files; local_write: exclusive-create two summary JSON receipts.

## `watch_vector_pr.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/watch_vector_pr.py`; 7580 bytes, 135 lines, SHA-256 `2e5ea3c7a7dc6a8fd0df85c42e3f4ae26391ab839c9a1b112961c8b041ec7751`.
Relevant lines: `11-23, 26-52, 54-100, 101-135`.
CLI: `--pr` (int) required; `--acceptance` (Path) required; `--name` required; [a-z0-9]+(?:-[a-z0-9]+)*.
Key inputs:
- `--acceptance JSON`: `status=passed`, `runtime_sources_match_build=true`, `head`, `tree`, `base`, `ci_workflow_blob` (lines 39-47).
- `<U>/float16-lifecycle-2026-11-07/float16-pr1663-r1.json`: `checks array with exactly 58 completed successful check names` (lines 13, 48).
- `local ROOT worktree`: `clean status`, `HEAD=acceptance.head`, `tree=acceptance.tree`, `no workflow diff from base to head`, `CI workflow blob matches acceptance` (lines 39-47).
- `GitHub PR/check/comment/review`: `exact head, open state, stable main base`, `check-runs each with id/name/status/conclusion/head_sha/html_url`, `Codex bot review marker JSON` (lines 54-90).
Outputs:
- `<U>/<name>-progress.json`: `l`, `a`, `t`, `e`, `s`, `t`, ` `, `P`, `R`, `/`, `c`, `h`, `e`, `c`, `k`, `/`, `r`, `e`, `v`, `i`, `e`, `w`, ` `, `s`, `t`, `a`, `t`, `e`, `;`, ` `, `b`, `a`, `s`, `e`, `/`, `b`, `a`, `s`, `e`, `_`, `b`, `r`, `a`, `n`, `c`, `h`, `;`, ` `, `c`, `h`, `e`, `c`, `k`, `s`, `;`, ` `, `m`, `i`, `s`, `s`, `i`, `n`, `g`, `/`, `f`, `a`, `i`, `l`, `u`, `r`, `e`, `s`, `;`, ` `, `c`, `o`, `u`, `n`, `t`, `s`, `;`, ` `, `t`, `i`, `m`, `e`, `s`, `t`, `a`, `m`, `p`, `s`, `;`, ` `, `o`, `p`, `t`, `i`, `o`, `n`, `a`, `l`, ` `, `a`, `u`, `d`, `i`, `t`.
- `<U>/<name>.json`: `status=pending|needs_attention|passed_premerge|deadline|observer_error`, `pr`, `head`, `initial_base`, `source_tree`, `acceptance_sha256`, `prior_check_names_sha256`, `latest observation fields or error`.
Hardcoded paths/limits: /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; parent of script directory (= U); /Users/dylan/LocalData/shardloom/float16-lifecycle-2026-11-07/float16-pr1663-r1.json; depsilon/shardloom; 58 required PR checks; 180 minute deadline; 40 second sleep after transient API failures; 45 seconds between normal polls; GitHub response <8 MiB.
Effects: read_only_local_git: git status/rev-parse/diff; read_only_API_queries: gh api REST + gh api graphql; local_git_write_fetch: git fetch --no-tags origin refs/pull/<pr>/merge; hosted_api_read: GET pulls/<pr>; hosted_api_read: GET commits/<head>/check-runs?per_page=100&filter=latest; hosted_api_read: GET issues/<pr>/comments?per_page=100; hosted_api_read: GraphQL PR audit query; local_write: progress JSON refreshed; local_write: exclusive final JSON receipt.

## `advance_vector_main.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/advance_vector_main.py`; 4788 bytes, 90 lines, SHA-256 `d6888806f60d2483a65fee1bd7ef077c2d266b9acd04355e5e04ab2591287a71`.
Relevant lines: `9-31, 33-57, 58-75, 76-90`.
CLI: `--pre` (Path) required; `--merge-receipt` (Path) required.
Key inputs:
- `--pre JSON`: `status=passed_premerge`, `successful_hosted_checks=58`, `pr`, `head`, `base` (lines 14-15, 43-48).
- `--merge-receipt JSON`: `isError=false`, `structuredContent.merged=true`, `structuredContent.sha` (lines 38-40).
- `<U>/delivery-acceptance-r1.json`: `status=passed`, `head`, `base`, `tree` (lines 35-44).
- `<U>/pr<N>-final-checks-r1.json and pr<N>-final-review-r1.json`: `status=passed`, `head`, `base` (lines 45-47).
- `<U>/float16-lifecycle-2026-11-07/float16-closeout-r1.json`: `status=complete`, `merge_commit=old base` (lines 12, 36, 48).
- `both local worktrees`: `prior worktree on main at old base`, `vector worktree on expected branch/head`, `both clean`, `main branch owned only by prior worktree before transfer` (lines 27-31, 49-57).
Outputs:
- `<U>/vector-main-checkout-r1.json`: `status=needs_attention|passed`, `merge_commit`, `source_tree`, `observed_at`, `signed_commit`, `parents`, `prior_float16_closeout_sha256`, `active_worktree`, `main_branch`.
Hardcoded paths/limits: parent of script directory (= U); /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; /Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo; <U parent>/float16-lifecycle-2026-11-07; exactly one main branch worktree owner expected before/after handoff; merge commit must have parents [old, head] and same source tree; signed verification must be true.
Effects: local_git_write_fetch: git fetch --no-tags origin main; read_only_API_query: gh api repos/depsilon/shardloom/commits/<new>; local_git_mutation: git switch --detach <old> in PRIOR_ROOT; local_branch_ref_mutation: git update-ref refs/heads/main <new> <old> in ROOT; local_git_mutation: git switch main in ROOT; hosted_api_read: GET commits/<new>; local_write: exclusive vector-main-checkout-r1.json receipt; local_write: local fetch refs, detached prior worktree, updated main ref, worktree checkout.

## `observe_vector_main.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/observe_vector_main.py`; 13113 bytes, 227 lines, SHA-256 `e26ea11b726abd50259eb9443f83f710c14503b3caed518f0f189783d883b25f`.
Relevant lines: `10-38, 41-79, 81-106, 108-184, 185-227`.
CLI: `--merge` required; `--pre` (path to passed_premerge receipt) required; `--name` required; [a-z0-9]+(?:-[a-z0-9]+)*.
Key inputs:
- `--pre JSON`: `status=passed_premerge`, `head`, `base`, `source_tree or tree`, `pr/checks array; successful completed names define baseline` (lines 20-28, 50-55, 69-79).
- `local git repository`: `merge commit exists locally`, `merge tree and parents equal pre base/head/tree`, `source commit tree matches` (lines 41-44).
- `GitHub REST GET responses`: `check-runs total_count/check_runs`, `workflow-runs total_count/workflow_runs`, `commit sha/tree/parents/verification` (lines 81-106).
- `Dependabot dynamic jobs when present`: `workflow path allowlist`, `actor=dependabot[bot]`, `event=dynamic`, `successful exact sha`, `check_suite_id and unique successful GitHub Actions check` (lines 11-16, 118-146).
Outputs:
- `<U>/<name>-raw/{checks,workflows,commit}.json`; count 3: `e`, `x`, `a`, `c`, `t`, ` `, `r`, `a`, `w`, ` `, `G`, `i`, `t`, `H`, `u`, `b`, ` `, `r`, `e`, `s`, `p`, `o`, `n`, `s`, `e`, ` `, `b`, `y`, `t`, `e`, `s`.
- `<U>/<name>.json`: `status=passed|failed|pending|review_required`, `observed_at`, `source_commit`, `source_tree`, `website_tree`, `source_sha`, `pr_head`, `pr_base`, `expected_repository_check_names`.
Hardcoded paths/limits: parent of script directory (= U); /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; depsilon/shardloom; ['CodeQL', 'CodeQL rust', 'CodeQL python']; Workers Builds: shardloom; {'dynamic/dependabot/dependabot-updates': 'Dependabot', 'dynamic/dependabot/update-graph': 'update-pip-graph'}; 58 successful PR names expected as source baseline; subtract 3 PR-only CodeQL checks and Workers, then add Workers back: 54 repository names + Workers = 55 required main-hosted checks.; per_page=100 and exact total count checked; all response bodies <8 MiB; workflow allowlist has 2 Dependabot paths.
Effects: read_only_local_git: git rev-parse/show; read_only_API_GET: gh api repos/depsilon/shardloom/<endpoint>; hosted_api_read: GET commits/<sha>/check-runs?per_page=100&filter=latest; hosted_api_read: GET actions/runs?head_sha=<sha>&per_page=100; hosted_api_read: GET commits/<sha>; local_write: create unique raw directory; local_write: write three raw JSON source files; local_write: exclusive-create summary receipt.

## `watch_vector_main.py`

Source: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/watch_vector_main.py`; 2853 bytes, 61 lines, SHA-256 `8dad1acd31b0333d4a44e8af16e052c2a93d8dd6ef3ad2bdd86d8775af2306c2`.
Relevant lines: `11-26, 27-55, 57-61`.
CLI: `--merge` required; `--pre` (Path) required; `--name` required; [a-z0-9-]+.
Key inputs:
- `--pre JSON`: `status=passed_premerge`, `successful_hosted_checks=58`, `checks array with 58 names` (lines 18-24).
- `GitHub check-runs GET`: `total_count`, `check_runs[].head_sha/name/status/conclusion`; ['all exact merge SHA; max 100 rows'] (lines 28-52).
Outputs:
- `none from watcher itself; delegates to observe_vector_main.py`: `c`, `h`, `i`, `l`, `d`, ` `, `o`, `u`, `t`, `p`, `u`, `t`, ` `, `i`, `s`, ` `, `<`, `U`, `>`, `/`, `<`, `n`, `a`, `m`, `e`, `>`, `.`, `j`, `s`, `o`, `n`, ` `, `p`, `l`, `u`, `s`, ` `, `<`, `U`, `>`, `/`, `<`, `n`, `a`, `m`, `e`, `>`, `-`, `r`, `a`, `w`, `/`, `{`, `c`, `h`, `e`, `c`, `k`, `s`, `,`, `w`, `o`, `r`, `k`, `f`, `l`, `o`, `w`, `s`, `,`, `c`, `o`, `m`, `m`, `i`, `t`, `}`, `.`, `j`, `s`, `o`, `n`.
- `stdout only`: `changed status markers with timestamp/counts`, `deadline message if 180 minutes elapse`.
Hardcoded paths/limits: parent of script directory (= U); /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo; ['CodeQL', 'CodeQL rust', 'CodeQL python']; Expected check set is 58 PR checks minus three named PR-only CodeQL checks = 55 main checks.; 180 minute deadline; gh timeout 50s; retry wait 40s for selected transient errors; normal poll sleep 45s; child observer timeout 240s.
Effects: read_only_API_GET: gh api repos/depsilon/shardloom/commits/<merge>/check-runs?...; local_child_process: subprocess.run(observer...); hosted_api_read: GET commit check-runs only in watcher; observer additionally gets workflows and commit; local_write: none directly; child observer writes output files.
Direct local helper: `/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/tools/observe_vector_main.py` via `<sys.executable> <U>/tools/observe_vector_main.py --merge <sha> --pre <path> --name <name>`.

## Shared patterns and schemas

- All six import only Python standard-library modules; Git/digest/`gh` wrappers are defined locally, with no project-local helper import.
- Direct helper edges: `prepare_vector_delivery.py` runs the packet `verify.py` (`prepare_vector_delivery.py:53-54`; verifier CLI `verify.py:315-320`). `watch_vector_main.py` runs `observe_vector_main.py` (`watch_vector_main.py:59-60`).
- GitHub API use is via `/opt/homebrew/bin/gh api`: REST GETs and a GraphQL query; no Codex MCP schema or API write is present.
- REST/GraphQL schemas used: PR `head.sha`, `base.sha/ref`, `state`, `draft`, `mergeable`; check runs `total_count` and `id/name/head_sha/status/conclusion`; comments `user.login/body/html_url` with a `codex-review-state:v1` JSON marker; GraphQL reviewDecision/mergeability/refs/threads/reviews and pagination flags; commit SHA/tree/parents/signature; workflow run count/event/path/actor/suite/status/conclusion.
- Merge receipt consumed by local advancement: `isError=false`, `structuredContent.merged=true`, `structuredContent.sha`.
- Mutation boundary: `advance_vector_main.py` changes only local branch/worktree state; `watch_vector_pr.py` can fetch a PR merge ref into local Git after gates pass. No helper merges/pushes remotely.

Missing files: none among the requested helpers or direct verifier dependency.
