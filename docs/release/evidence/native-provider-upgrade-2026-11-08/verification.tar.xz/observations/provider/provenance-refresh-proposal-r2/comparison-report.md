# Provider provenance refresh comparison

- Status: `generated_with_primary_review_items`
- Primary review items: 53
- Repository: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
- Source manifest SHA-256: `52f353962f8c5ee2e6d314a130e12f0af1784359799bffbe5887a5e9ad9a02c7`
- Candidate installation SHA-256: `ee885b401dfd78739c1fd318e8039002ce5a6232441320b95102b7c320d4bd25`
- Proposals are scratch outputs only; repository files were not written.
- Current migration status remains `candidate_port_under_validation` in every proposal.

## Per-provider comparison

### `arrow-array` 59.3.2
- Archive SHA-256: `72b5b1682924f11ecf6929689c16cbc69efbb6dd141b06ad98ee1cb10d858c43`; members: 66; uncompressed bytes: 1743465
- Current provenance SHA-256: `7d06165d8efa97a399bc8206e1341a6ea0fa9af342a514e5dfac9e86cde66adc`
- Proposed provenance SHA-256: `25b994774ad05b2230fc09ad234819a66fd8e72f11847f25e9f99bf4296ff0ab`
- Archive/manifest mismatches: 0; installation file differences: 3
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `True`

  - URL `license_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt`; candidate `https://static.crates.io/crates/arrow-array/arrow-array-59.3.2.crate#LICENSE.txt`
  - URL `notice_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt`; candidate `https://static.crates.io/crates/arrow-array/arrow-array-59.3.2.crate#NOTICE.txt`
  - URL `additional_license_files[0].url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT`; candidate `https://static.crates.io/crates/arrow-array/arrow-array-59.3.2.crate#LICENSE-MIT`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
### `arrow-avro` 59.3.2
- Archive SHA-256: `cba30bb78cb38952b3f8adea1bd617bc171e4af4ac94fb6db4f03d7cee7b200d`; members: 30; uncompressed bytes: 1662787
- Current provenance SHA-256: `1c51b40a5a2e820523bc44b42ad44ef53ad3a320be9b480e6fb56d482f26dc67`
- Proposed provenance SHA-256: `fe69c5e43f7f0eea87667ad1cc78520a9767e33c392400d24b2fac47a93bcc70`
- Archive/manifest mismatches: 0; installation file differences: 7
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `True`

  - URL `license_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt`; candidate `https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.2.crate#LICENSE.txt`
  - URL `notice_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt`; candidate `https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.2.crate#NOTICE.txt`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
### `arrow-ipc` 59.3.2
- Archive SHA-256: `f5dd1afadda2eb821aaf851bb4c0adef60c30cc0f1a29bd02fb99dd07fb9f58d`; members: 22; uncompressed bytes: 888766
- Current provenance SHA-256: `eac5020b5d9a92bed6c12845adbf851e8d5e9221b40323725d4ededc753d89b4`
- Proposed provenance SHA-256: `a426fa9f0144e4c551e3ec9c9c37346ee88a613396f846e9f779e526222bc2e8`
- Archive/manifest mismatches: 0; installation file differences: 3
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `True`

  - URL `license_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt`; candidate `https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.2.crate#LICENSE.txt`
  - URL `notice_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt`; candidate `https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.2.crate#NOTICE.txt`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
### `parquet` 59.3.2
- Archive SHA-256: `8eb260d566f2fbdabe356d26aaa5d13403aac29b5b4e44463b8f9bd7b2b12680`; members: 227; uncompressed bytes: 5386368
- Current provenance SHA-256: `9db977739febc5f210dee42769c45a831dc908cb3b5a9f187a9fd8f18dcabd51`
- Proposed provenance SHA-256: `e310ef94c4803518f53336d2b99d7a83f23869f39ca7fc6d68272d11c5aa33f9`
- Archive/manifest mismatches: 0; installation file differences: 289
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `True`

  - URL `license_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt`; candidate `https://static.crates.io/crates/parquet/parquet-59.3.2.crate#LICENSE.txt`
  - URL `notice_url`: `verified_exact_member_bytes`; prior `https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt`; candidate `https://static.crates.io/crates/parquet/parquet-59.3.2.crate#NOTICE.txt`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
### `vortex-array` 0.93.0
- Archive SHA-256: `23c3e4aa4f087f646ea72bd7b58a08c5a489569cf01f7e2e2400ff1c9bdb90b7`; members: 871; uncompressed bytes: 7690340
- Current provenance SHA-256: `93773b6d55b944d38911e14710caf7c040d23e784f006d4ffb898ba9a9917e88`
- Proposed provenance SHA-256: `440e2783187c297c59b5cc623682a626474432a4e6cda3e62e8291d856363264`
- Archive/manifest mismatches: 0; installation file differences: 12
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-buffer` 0.93.0
- Archive SHA-256: `26b3b956e4367e5db8c687d78b2e52e71fe62c4205138223528663e339521717`; members: 33; uncompressed bytes: 394622
- Current provenance SHA-256: `b2b56ac30b13fc71add379e804c4d1fc6e3d448bf87c47f3e00401b3616867c1`
- Proposed provenance SHA-256: `6321870360ce6a9ad3ff0d00f53ca0a91e2a1bcf42e6198728870425ee238af6`
- Archive/manifest mismatches: 0; installation file differences: 1
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-datetime-parts` 0.93.0
- Archive SHA-256: `adc55b1fed12f5945ae09746bb14343c8beb76f573e831e2e5b499345d2ef9d6`; members: 21; uncompressed bytes: 185400
- Current provenance SHA-256: `b7a1a88c3672ceb3dcfc706458006ec8d8bbb661647141e7b9edd09b722eb3cf`
- Proposed provenance SHA-256: `483b2284bde669d5d6f20c7097c9beca2c9d01503ae8c51b1e30d847ac4de3d1`
- Archive/manifest mismatches: 0; installation file differences: 5
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-file` 0.93.0
- Archive SHA-256: `f2bc2f2416065106736a37efd903817dc4eb203d3c7c0ddc4d81879b02c81b63`; members: 39; uncompressed bytes: 681731
- Current provenance SHA-256: `2176ee9f104692338187c5cdfaf6c5dc57c0db38fe96a0da5bd8238c39862d77`
- Proposed provenance SHA-256: `1526a4a7bd727b2bb10b7d768926ee4eed7946628540156308b5a1bbe5dae070`
- Archive/manifest mismatches: 0; installation file differences: 7
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-fsst` 0.93.0
- Archive SHA-256: `6dbe48ed4c7e4a53ed9c8a277d53d91d4929324642eefe0907e1d81281d5144a`; members: 26; uncompressed bytes: 305407
- Current provenance SHA-256: `d060e32ae82fb585675654d795d9f1f8a9eef0f28be875cc838a8bcf670efcc5`
- Proposed provenance SHA-256: `256582b18be24ecef78c40452a4c61fccd643514851d9f7b7ea8c850c066bffe`
- Archive/manifest mismatches: 0; installation file differences: 1
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-io` 0.93.0
- Archive SHA-256: `9e33cb1876c91b1eda30427becf783b89158cae4d439e38084125cf271f5eb0e`; members: 49; uncompressed bytes: 308024
- Current provenance SHA-256: `bf928ae50e05bec8a7a9685d5c9525255d962060f3919ebbcc7b574763418f7e`
- Proposed provenance SHA-256: `b626f10e8cfe21672701203c38b41a58a85e79f37afc5089962022f225bceca8`
- Archive/manifest mismatches: 0; installation file differences: 1
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-layout` 0.93.0
- Archive SHA-256: `38dd653aeda78c44a21549740527cbca2d5ceef5fe5ced2dcc7504c9450f4736`; members: 155; uncompressed bytes: 1850730
- Current provenance SHA-256: `2397a4428966d6eb25e8cfa43ad3463bcde30bbd0afa690239a565c481f5146d`
- Proposed provenance SHA-256: `38e063215e004f841d08fbee2517e2026c42266b80ed86808544bd01b728e2bc`
- Archive/manifest mismatches: 0; installation file differences: 4
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)
### `vortex-zstd` 0.93.0
- Archive SHA-256: `ce3be1e195edae8c5a1674ad6c636f84f6bd26e46847a369b66909dae369ca8d`; members: 15; uncompressed bytes: 193029
- Current provenance SHA-256: `e55e89071758d5d7d35330f887cca00bd66a54cc3d7c6d6ee26ce56a09d1da03`
- Proposed provenance SHA-256: `e49cb840a42bb1b84896092bf3fbd97a705e7c7b2858fa598da6a21d1e668573`
- Archive/manifest mismatches: 0; installation file differences: 6
- Unknown extras without inferred provenance: 0; generated files excluded: 2
- Notice hash match: `None`

  - URL `license_url`: `unresolved_no_unique_verified_candidate_member`; prior `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE`; candidate `unresolved`
  - Primary review item: current provider tree differs from candidate installation record
  - Primary review item: one or more legal URLs lack a uniquely verified candidate archive member
  - Primary review item: stored provenance field differs: modified_files_sha256
  - Primary review item: stored provenance field differs: added_files_sha256
  - Primary review item: stored provenance field differs: local_changes_documentation_sha256
  - URL requires primary reconciliation: `license_url` — `https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE` (unresolved_no_unique_verified_candidate_member)

The JSON report contains every archive member identity, final provider file hash, mismatch detail, excluded generated path description, and preserved provenance field comparison.
