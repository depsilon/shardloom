# Portable archive role inventory r2

This inventory assigns current source roles to exact archives already present in `portable-archive-sources-r1`; it does not copy or change blobs.

## Coverage

- Root r3 registry manifest rows: 78; archive source copies verified: 84.
- Reviewed new development identities: 34; recorded archive source copies verified: 82.
- Current vendor provenance identities: 15; archive source copies verified: 35.
- Role source items: 201; existing portable blobs referenced: 119 (11978637 bytes).

Each JSON item records its role, exact identity, original archive path and checksum, Cargo.toml member SHA/bytes, and existing portable blob reference. Every source and referenced blob passed independent byte/hash checks.

## Proof gaps

- None. All requested identities and archive copies were present and verified.

No repository or source archive changed; no network, Cargo, build, or benchmark action was used.
