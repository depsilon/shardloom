# Failure observation inventory (r3)

Read-only refresh at cutoff 2026-11-08T14:10:08Z.

Prior inventory: `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/failure-observation-inventory-r2.json` — 250000 bytes, SHA-256 `f387b27187d0179e1fe8b20665e2f37473e96762a73795b3c3ab9feb07bf4df7`. Its exact original text is embedded in the JSON `r2_inventory_preserved_verbatim.content_utf8` field; all prior records remain recoverable byte-for-byte.

Independently rechecked the r2 inventory’s 61 receipt identities and 80 distinct linked-log identities: 61 receipt hashes and 80 log hashes matched. No referenced prior receipt/log was missing. The prior inventory’s declared missing child report remains `provider-affected-standalone-r1/report.json`.

## Additional terminal observations

### `debug-retirement-r3-preparation-failure-r1.json` — `failed_preparation_before_deletion`

Command: `python3 /Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/tools/retire_provider_debug_r3.py plan`.
Recorded error: `AttributeError: module 'hashlib' has no attribute 'file_digest'`.
Receipt SHA-256: `747b148c6b5652da2d1cd72b31fe5ecff5d2ded48572d9c647ef9551c86f1b7c` (710 bytes).
- Later linked context `debug-retirement-r3/plan.json` status `planned_no_deletion`, SHA-256 `ddb8c21384ec2c49e223a5f1955f4d1cc890da0e75f09c53c42d53038db3904e`; context only.
- Later linked context `debug-retirement-r3/receipt.json` status `passed`, SHA-256 `8f244b35e24d55b3e775d70d90e5a4039a0fb2125ffcbdcd79223aa7a8193d38`; context only.
- **Evidence gap:** original_raw_log is null.
- **Evidence gap:** failure text has no captured raw log.

### `standalone-graph-review-failure-r2.json` — `failed`

Command: `/opt/homebrew/bin/python3.13 /Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/tools/verify_standalone_graph_review.py --inventory standalone-dev-graph-inventory-r2.json --output standalone-graph-primary-review-r2.json`.
Recorded error: `AssertionError: verifier required exactly one local archive copy`.
Return code: `1`.
Receipt SHA-256: `f5c056b34145f993b063b9fc914e8bf0fd9d29407a15442fa386e25cf6f1575d` (846 bytes).
- Raw log `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/standalone-graph-primary-review-r2.log`: exists=True, SHA-256 `2c8d1cfeb6dfa4b1f317b36fb6cde7f06b7c4fbcec197dee837a0e00530ffb33`, receipt match=True.
- Later linked context `standalone-graph-primary-review-r2.json` status `passed_new_development_graph_review`, SHA-256 `d7d578c5b7d943acc392f0c1d5e7ed65788b2ba947782785c8d28a9412ce683c`; context only.

### `provider-validation-sequence-r4.json` — `failed`

Active stage: `provider-native-clippy-r4`; sequence error: `AssertionError: provider-native-clippy-r4`.
Receipt SHA-256: `ee240bde85b209b01e5b8aca1593d2b3da6726e84c1b005ba52867232793b7d6` (446 bytes).
- Linked active-stage receipt `provider-native-clippy-r4.json` status `failed`, SHA-256 `805ed5b114be2822fae7a5f8228a9757f4a26c0b975257601f6da155febdc54e`; its raw log `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/provider-native-clippy-r4.log` SHA-256 `d1fd52156597c01517ae2932e56e11adc832c2ad9d0ba561a5b72c4e250b6bf6`, matches stage receipt=True.
- Protocol `validation-protocol-r4.json` SHA-256 `8cfb5ec2beb046cf16936059303c896811d5e52fb7c886e3b2ddfb95a2a5ea50`, matches sequence receipt=True.
- **Evidence gap:** sequence receipt records no direct raw log path or digest.

### `provider-validation-sequence-r5.json` — `failed`

Active stage: `provider-native-tests-r2`; sequence error: `AssertionError: provider-native-tests-r2`.
Receipt SHA-256: `2b36a59ceddf6c10002120828eeef97759272e9a186a59d97b8df3ad24b59fd2` (477 bytes).
- Linked active-stage receipt `provider-native-tests-r2.json` status `failed`, SHA-256 `bbf0f7f6cf6fc53145de8ebe5faec5d95e6ec99f0a5659e5cc0be742cb4bdde1`; its raw log `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/provider-native-tests-r2.log` SHA-256 `c24c6d10e2bcc5317ed8d4a86cf00c6b80b370f3988cdc4cf838ef147c02c1a9`, matches stage receipt=True.
- Protocol `validation-protocol-r5.json` SHA-256 `cfed3e95ea496eaa7919e96de0703db40598d91e065164547ae2e32cea7e62f5`, matches sequence receipt=True.
- **Evidence gap:** sequence receipt records no direct raw log path or digest.

### `provider-native-clippy-r4.json` — `failed`

Command: `env CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3 cargo clippy --workspace --all-targets --features shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment --locked --offline -- -D warnings`.
Return code: `101`.
Receipt SHA-256: `805ed5b114be2822fae7a5f8228a9757f4a26c0b975257601f6da155febdc54e` (1277616 bytes).
- Raw log `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/provider-native-clippy-r4.log`: exists=True, SHA-256 `d1fd52156597c01517ae2932e56e11adc832c2ad9d0ba561a5b72c4e250b6bf6`, receipt match=True.
- Later linked context `provider-native-clippy-r5.json` status `passed`, SHA-256 `6a54764a61dd27265314a2582f9e295ea21ebe9fe375e15575e0001f845ddbfe`; context only.

### `provider-native-tests-r2.json` — `failed`

Command: `env CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3 cargo test --workspace --all-targets --features shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment --locked --offline`.
Recorded error: `AssertionError: minimum free storage reached`.
Return code: `-15`.
Receipt SHA-256: `bbf0f7f6cf6fc53145de8ebe5faec5d95e6ec99f0a5659e5cc0be742cb4bdde1` (1277563 bytes).
- Raw log `/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/provider-native-tests-r2.log`: exists=True, SHA-256 `c24c6d10e2bcc5317ed8d4a86cf00c6b80b370f3988cdc4cf838ef147c02c1a9`, receipt match=True.

## Excluded current-mutable records

- `provider-validation-sequence-r6.json`: running; running/current mutable at cutoff; not a terminal observation (active stage `provider-native-tests-r3`).
- `provider-native-tests-r3.json`: no receipt; no terminal root receipt existed at cutoff; its active stage was identified by provider-validation-sequence-r6.json.

## Counts at cutoff

- Receipts: 67 total = 61 preserved r2 + 6 new terminal records.
- Status counts: `{"drift_detected": 2, "failed": 55, "failed_before_any_repository_write": 1, "failed_before_mutation": 1, "failed_preparation_before_deletion": 1, "installed_candidate_not_accepted": 1, "prepared_needs_primary_review": 1, "prepared_not_accepted": 4, "simulation_passed": 1}`.
- Distinct linked logs: 83 total, 83 present, 0 missing.
- New logs: 3; all new directly-linked logs hash-match their receipts and all r2 linked logs independently reverified.

No additional acceptance decision is made.
