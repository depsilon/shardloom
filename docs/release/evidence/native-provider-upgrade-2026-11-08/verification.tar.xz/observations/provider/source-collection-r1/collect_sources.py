#!/usr/bin/env python3
"""Collect bounded, checksum-verified published Rust crate source archives."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tarfile
import time
import urllib.error
import urllib.request
from pathlib import Path, PurePosixPath

REPO = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
COLLECTION_ROOT = Path('/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08/source-collection-r1')
OUT = COLLECTION_ROOT / 'corrected'
VORTEX = ['vortex', 'vortex-compressor', 'vortex-array', 'vortex-buffer', 'vortex-datetime-parts', 'vortex-file', 'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-zstd']
ARROW = ['arrow-array', 'arrow-avro', 'arrow-buffer', 'arrow-data', 'arrow-flight', 'arrow-ipc', 'arrow-pyarrow', 'arrow-schema', 'parquet']
CANDIDATES = [(n, '0.93.0') for n in VORTEX] + [(n, '59.3.2') for n in ARROW]
BASELINES = [(n, '0.90.0') for n in ['vortex-array', 'vortex-buffer', 'vortex-datetime-parts', 'vortex-file', 'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-runend', 'vortex-zstd']] + [(n, '59.3.1') for n in ['arrow-array', 'arrow-avro', 'arrow-ipc', 'parquet']]
MAX_COMPRESSED = 32 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
MAX_OUTPUT = 512 * 1024 * 1024
FREE_FLOOR = 12 * 1024**3
RESERVE = len(CANDIDATES + BASELINES) * MAX_COMPRESSED
PRIOR_OUTPUT_BYTES = 0


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, value) -> None:
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)


def free_bytes() -> int:
    return shutil.disk_usage(OUT.parent.parent.parent).free


def safe_members(archive: Path):
    seen = set()
    with tarfile.open(archive, 'r:gz') as tf:
        for member in tf:
            name = member.name
            p = PurePosixPath(name)
            if p.is_absolute() or not name or any(part in ('', '.', '..') for part in p.parts):
                raise ValueError(f'unsafe archive path: {name!r}')
            if name in seen:
                raise ValueError(f'duplicate archive path: {name!r}')
            seen.add(name)
            if not (member.isdir() or member.isreg()):
                raise ValueError(f'unsupported archive member type: {name!r}')
            yield tf, member


def extract_and_inventory(archive: Path, target: Path, totals: dict) -> dict:
    target.mkdir(parents=True, exist_ok=True)
    entries = []
    expanded = 0
    with tarfile.open(archive, 'r:gz') as tf:
        members = tf.getmembers()
        # Reject size-limit violations before creating any extracted payload.
        if sum(m.size for m in members if m.isreg()) + totals['expanded'] + totals['compressed'] + PRIOR_OUTPUT_BYTES > MAX_OUTPUT:
            raise ValueError('total output would exceed 512 MiB limit')
        seen = set()
        for m in members:
            name = m.name
            p = PurePosixPath(name)
            if p.is_absolute() or not name or any(part in ('', '.', '..') for part in p.parts):
                raise ValueError(f'unsafe archive path: {name!r}')
            if name in seen:
                raise ValueError(f'duplicate archive path: {name!r}')
            seen.add(name)
            if not (m.isdir() or m.isreg()):
                raise ValueError(f'unsupported archive member type: {name!r}')
            if m.size < 0 or (m.isdir() and m.size != 0):
                raise ValueError(f'invalid member size: {name!r}')
            expanded += m.size
            if expanded > MAX_EXPANDED:
                raise ValueError('archive exceeds 256 MiB uncompressed limit')
            out = target.joinpath(*p.parts)
            if not out.resolve().is_relative_to(target.resolve()):
                raise ValueError(f'archive path escapes extraction root: {name!r}')
            if m.isdir():
                out.mkdir(parents=True, exist_ok=True)
                entries.append({'path': name, 'bytes': 0, 'type': 'directory', 'sha256': None})
            else:
                out.parent.mkdir(parents=True, exist_ok=True)
                src = tf.extractfile(m)
                if src is None:
                    raise ValueError(f'missing file payload: {name!r}')
                h = hashlib.sha256()
                n = 0
                with out.open('xb') as dst:
                    while True:
                        b = src.read(1024 * 1024)
                        if not b:
                            break
                        n += len(b)
                        if n > m.size:
                            raise ValueError(f'payload exceeds declared size: {name!r}')
                        h.update(b)
                        dst.write(b)
                if n != m.size:
                    raise ValueError(f'payload size differs from header: {name!r}')
                entries.append({'path': name, 'bytes': n, 'type': 'file', 'sha256': h.hexdigest()})
        totals['expanded'] += expanded
        if totals['expanded'] > MAX_OUTPUT:
            raise ValueError('total source output exceeds 512 MiB uncompressed limit')
    return {'member_count': len(entries), 'uncompressed_bytes': expanded, 'members': entries,
            'vcs_info': next((e for e in entries if e['path'].endswith('/.cargo_vcs_info.json')), None)}


def api_fetch(name: str, version: str):
    url = f'https://crates.io/api/v1/crates/{name}/{version}'
    req = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-source-collection/1.0'})
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            body = resp.read(2 * 1024 * 1024 + 1)
            if len(body) > 2 * 1024 * 1024:
                return resp.status, body[:2 * 1024 * 1024], 'response exceeded 2 MiB cap'
            return resp.status, body, None
    except urllib.error.HTTPError as e:
        return e.code, e.read(2 * 1024 * 1024), str(e)
    except Exception as e:
        return None, str(e).encode(), repr(e)


def fetch_archive(name: str, version: str, dest: Path):
    url = f'https://static.crates.io/crates/{name}/{name}-{version}.crate'
    cache = Path.home() / '.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f' / f'{name}-{version}.crate'
    if cache.is_file():
        source = 'cargo-cache'
        with cache.open('rb') as src, dest.open('xb') as dst:
            shutil.copyfileobj(src, dst)
    else:
        source = 'static.crates.io'
        req = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-source-collection/1.0'})
        with urllib.request.urlopen(req, timeout=60) as resp, dest.open('xb') as dst:
            if resp.status != 200:
                raise RuntimeError(f'archive HTTP status {resp.status}')
            count = 0
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > MAX_COMPRESSED:
                    raise ValueError('compressed archive exceeds 32 MiB limit')
                dst.write(chunk)
    if dest.stat().st_size > MAX_COMPRESSED:
        raise ValueError('compressed archive exceeds 32 MiB limit')
    return source, url


def main():
    # Capacity check precedes any output writes. Candidate reserve is worst-case for all pairs.
    free = shutil.disk_usage(OUT.parent.parent.parent).free
    if free < FREE_FLOOR + RESERVE:
        raise SystemExit(f'insufficient free space: {free} < {FREE_FLOOR + RESERVE}')
    global PRIOR_OUTPUT_BYTES
    PRIOR_OUTPUT_BYTES = sum(p.stat().st_size for p in COLLECTION_ROOT.rglob('*') if p.is_file()) if COLLECTION_ROOT.exists() else 0
    if PRIOR_OUTPUT_BYTES > MAX_OUTPUT:
        raise SystemExit(f'prior output already exceeds 512 MiB: {PRIOR_OUTPUT_BYTES}')
    OUT.mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / 'manifest.json'
    manifest = {'schema': 'shardloom-provider-source-collection-r1', 'started_unix': time.time(),
                'repo': str(REPO), 'preflight': {'free_bytes': free, 'floor_bytes': FREE_FLOOR,
                'reserve_bytes': RESERVE, 'required_bytes': FREE_FLOOR + RESERVE},
                'results': []}
    totals = {'compressed': 0, 'expanded': 0}
    pairs = [('candidate', n, v) for n, v in CANDIDATES] + [('baseline', n, v) for n, v in BASELINES]
    for role, name, version in pairs:
        row = {'role': role, 'name': name, 'version': version, 'status': 'failed'}
        pair_key = f'{name}-{version}'
        pair_dir = OUT / role / pair_key
        pair_dir.mkdir(parents=True, exist_ok=True)
        status, raw, api_error = api_fetch(name, version)
        (pair_dir / 'crates-io-response.bin').write_bytes(raw)
        row['api'] = {'url': f'https://crates.io/api/v1/crates/{name}/{version}', 'http_status': status,
                      'raw_response': str((pair_dir / 'crates-io-response.bin').relative_to(OUT)),
                      'error': api_error}
        if status != 200:
            row['status'] = 'unavailable' if status == 404 else 'failed'
            row['reason'] = f'crates.io API returned {status}'
            manifest['results'].append(row)
            atomic_json(manifest_path, manifest)
            continue
        try:
            api = json.loads(raw)
            ver = api.get('version', {})
            row['api_version'] = {'name': ver.get('crate'), 'num': ver.get('num'), 'yanked': ver.get('yanked'),
                                  'checksum': ver.get('checksum')}
            if ver.get('crate') != name or ver.get('num') != version:
                raise ValueError('API crate name/version mismatch')
            if ver.get('yanked') is not False:
                raise ValueError('version is yanked or yanked state missing')
            checksum = ver.get('checksum')
            if not isinstance(checksum, str) or len(checksum) != 64:
                raise ValueError('API checksum missing or malformed')
            expected = checksum
            if role == 'baseline':
                prov_path = REPO / 'vendor' / name / 'upstream-provenance.json'
                prov = json.loads(prov_path.read_text())
                row['provenance_file'] = str(prov_path)
                row['provenance_version'] = prov.get('version')
                row['provenance_archive_sha256'] = prov.get('registry_archive_sha256')
                if prov.get('version') != version:
                    raise ValueError('baseline version does not match upstream-provenance.json')
                if prov.get('registry_archive_sha256') != checksum:
                    raise ValueError('baseline API checksum differs from upstream-provenance.json')
            archive = pair_dir / f'{name}-{version}.crate'
            source, archive_url = fetch_archive(name, version, archive)
            archive_hash = sha256_file(archive)
            row['archive'] = {'url': archive_url, 'source': source, 'path': str(archive.relative_to(OUT)),
                              'bytes': archive.stat().st_size, 'sha256': archive_hash}
            totals['compressed'] += archive.stat().st_size
            if totals['compressed'] + totals['expanded'] + PRIOR_OUTPUT_BYTES > MAX_OUTPUT:
                raise ValueError('total output exceeds 512 MiB limit')
            if archive_hash != expected:
                raise ValueError('archive SHA256 differs from registry checksum')
            row['source_inventory'] = extract_and_inventory(archive, pair_dir / 'source', totals)
            row['status'] = 'passed'
        except Exception as e:
            row['reason'] = f'{type(e).__name__}: {e}'
        manifest['results'].append(row)
        manifest['totals'] = totals
        atomic_json(manifest_path, manifest)
    manifest['finished_unix'] = time.time()
    manifest['totals'] = totals
    manifest['counts'] = {s: sum(1 for r in manifest['results'] if r['status'] == s) for s in ['passed', 'unavailable', 'failed']}
    atomic_json(manifest_path, manifest)
    print(json.dumps({'manifest': str(manifest_path), 'counts': manifest['counts'], 'totals': totals}, indent=2))


if __name__ == '__main__':
    main()
