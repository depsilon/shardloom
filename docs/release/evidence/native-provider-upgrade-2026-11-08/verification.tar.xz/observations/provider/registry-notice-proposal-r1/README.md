# Registry notice proposal r1

Scratch-only proposal based on the exact root registry lock identities. It does not modify the repository bundle or vendored provenance.

## Baseline and proposed coverage

- Root Cargo.lock SHA-256: `32ad9bdfd2bf7f8bb4d704b6e26ce982f2ff3b3020e5f8f68a2be667be62b8f1`.
- Baseline license manifest SHA-256: `1aa755a4b38868954dcf55a71554fa07f498636ef22c6b9449a92c2231153f03`.
- Root registry set: 432; retained exact existing components: 393; proposed new components: 39; obsolete old components removed from proposal: 40.
- Proposed component count: 432; retained-component canonical JSON byte comparisons: 393/393 equal.
- New distinct text blobs: 6 (45603 bytes).

The complete proposal is `manifest.proposed.json`; new notice and license text files are in `texts/`. `verification.json` contains every selected package's archive path, size and checksum; literal Cargo.toml fields; exact root legal member hashes/text; and, for Vortex packages, `.cargo_vcs_info` commit evidence and the common official LICENSE binding.

## Vortex license binding

All 25 Vortex 0.93.0 package archives match their root lock checksums; each Cargo.toml declares `Apache-2.0` and repository `https://github.com/vortex-data/vortex`; each `.cargo_vcs_info` records commit `c1439e69bf833fc702a60335ed674a1674ca358d`. The supplied official LICENSE response matches 11358 UTF-8 bytes, SHA-256 `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`, Git blob `d645695673349e3947e8e5ae42332d0ac3164cd7`, and [https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE](https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE). No archive legal file was substituted.

## Non-Vortex archive notices

All 14 other new packages include every root archive member whose basename begins with LICENSE, NOTICE, or COPYING (case-insensitive): 26 files total. Exact member paths, sizes, SHA-256 values, and UTF-8 text are in `verification.json`; deduplicated text copies are in `texts/`.

## Review boundary

Primary review remains responsible for license policy and final integration. This proposal was prepared without network access, Cargo, builds, tests, or edits to the repository manifest or vendored-provenance records.
