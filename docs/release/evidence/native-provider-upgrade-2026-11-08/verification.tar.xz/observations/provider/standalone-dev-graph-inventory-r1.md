# Standalone provider development graph inventory

- Repository: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
- Root Cargo.lock SHA-256: `32ad9bdfd2bf7f8bb4d704b6e26ce982f2ff3b3020e5f8f68a2be667be62b8f1`
- Provider lockfiles included and hashed: 14
- Exact package identities absent from root: 247
- Matching local registry archives: 208
- Manifest present, archive missing: 0
- Exact local registry source missing: 39
- Input fingerprint: `26f88667e0c5a26c96c395370df7df7c95aa72100c27b3a2662cb9fd7825345c`

The JSON inventory lists each exact name/version/source/checksum tuple, provider lock uses, local manifest/archive paths and hashes, declared license/license-file/rust-version values, and legal archive member hashes. Missing local sources are explicit. No downloads, Cargo commands, builds, or repository writes were used.
