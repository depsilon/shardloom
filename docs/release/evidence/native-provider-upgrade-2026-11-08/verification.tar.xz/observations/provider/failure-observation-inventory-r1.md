# Failure observation inventory r1

Cutoff: 2026-11-08T12:35:31Z UTC. Active `provider-native-tests-r1` under protocol r3 was excluded because its receipt/log was incomplete at cutoff.

Included 41 N JSON records whose root status begins with `fail`; nested report receipts and parent run receipts are listed separately when both are present. This is an evidence map, not an acceptance decision.

| N receipt | Status | Return code | Receipt SHA-256 | Raw linked log |
|---|---|---:|---|---|
| `candidate-installation-failure-r1.json` | `failed_before_mutation` | null | `289a1389f97c3a7e2ebe718a8da261dd4037e1cb5d318c966b2a846c3b577a24` | missing |
| `debug-retirement-plan-r1.json` | `failed` | 1 | `32872a6fb3a319c2c9aae7b9029e823e622a80f66572c47c72ebb0bd69feff3a` | debug-retirement-plan-r1.log (53af8bd16198ea4b4748ec162139421945d4915d31f030a19241beebb3d5c58d, match=True) |
| `inventories-primary-source-binding-failure-r1.json` | `failed` | null | `f83c59fa31da0add80632554216a42f51e486766fd313a844b91085b8f2794aa` | missing |
| `native-compile-r1.json` | `failed` | 101 | `94a6ffedba8e7cd2aac1d1a0f5bf3f91608c037670bafd31b960fa61f5be148f` | native-compile-r1.log (b4a2e56f381ac40fa15ac2900d6e03520ec097fa60751beb78ffd2601a4ce7e6, match=True) |
| `native-compile-r2.json` | `failed` | 101 | `d77b441bc4aa6530cc23895c0ebc1a85a5d72b1c9a10c0f6ece19fd7a72fe2d6` | native-compile-r2.log (f4d9dd6f375f88cb09b47250786195e354b55854cbd2a70a0b01b6a56f4dae08, match=True) |
| `native-compile-r3.json` | `failed` | 101 | `a7ce86257b09e1942b5f8692bbe3563b87902f6a9b515f9681f6999eeda460c8` | native-compile-r3.log (4fe7c9b3bb486ec895a07c3b2347da6956d6ab69e8060524e95acdd8e7dcc619, match=True) |
| `native-decoder-diagnostic-r1.json` | `failed` | 101 | `562ce4de03c1fbd24a2029c994c7b59cd4f203b4967f7ae30d45f741177b2595` | native-decoder-diagnostic-r1.log (9c87cdc8a42b2e60e129e1922b2b9ff918885f00d6672daf9327b22adc459dac, match=True) |
| `native-decoder-diagnostic-r2.json` | `failed` | 101 | `27dc64f7fc72e0256306d4099561e47078dbba3ffe642b42f9fa8ed0faf8f174` | native-decoder-diagnostic-r2.log (6923d139bceb3d49b09652ee5285c04aa6e1ec2210561a9e564e6bc477225389, match=True) |
| `native-provider-regressions-r1.json` | `failed` | 101 | `d3b415af87c6f61763774076a193982a43c11b4701e50ec35646424c842ec8a1` | native-provider-regressions-r1.log (bcb66d042f2661451dc422072bd4c9662b77185050581e260946136fed803388, match=True) |
| `native-provider-regressions-r2.json` | `failed` | 101 | `1a7c5c4268d30be1b5cffd438cf367756f3a4b733942241e63ffd0ddd0471d7d` | native-provider-regressions-r2.log (932de6c3b050df47d5fd0538c607495a29d9563adbb06d8639446f468c4506e9, match=True) |
| `native-tests-compile-r1.json` | `failed` | 101 | `369139557d8228db5c397e872cb13b055c5722aa459c152d1f87d2061eac5091` | native-tests-compile-r1.log (3dd1e21313f92ae38e5a37828945cfe446843507ba74404726bf4099363ee65e, match=True) |
| `native-tests-compile-r2.json` | `failed` | 101 | `e2acae8f48ffbe731b5a4925b971475533ed0d3dcdd27f8b48fae1d866713643` | native-tests-compile-r2.log (e5862c1023dadbe9f72c5ddbf8dd2c66fb3a36109dc1bc383cf42d4edf6388c9, match=True) |
| `native-tests-compile-r3.json` | `failed` | 101 | `3ea2c4d995bf2e7f737f56338dd2721ec6d5e5ad97a17056af8983d1016ecd13` | native-tests-compile-r3.log (b80000df222890ef8e9a20bd9d8e3b559254f7036a93a495e2e59add55ff8493, match=True) |
| `provider-native-clippy-r1.json` | `failed` | 101 | `b387cb8bbe459dc6f272e6ff5e11c1186bace213aa41a9350df637d2e175530d` | provider-native-clippy-r1.log (9b8263d51722d6d3d7414ba727c57608df6afdeb69cd2de5adf2348510742fe6, match=True) |
| `provider-native-clippy-r2.json` | `failed` | 101 | `025e91609fe30d6c23314f687886f6b2da55ecc77ba1f39209df170f54e46dba` | provider-native-clippy-r2.log (b7f2f5168008cf8a4316e90c142a8fb8d9e4d5871a37107875049e35ece7745b, match=True) |
| `provider-provenance-installation-failure-r1.json` | `failed_before_any_repository_write` | null | `9fe65e4eeb0bd86825ea864193447bf08cfb5acdec6056da4a3cb7170dcec36c` | missing |
| `provider-source-replay-development-r1.json` | `failed` | null | `7e033ea3f1142472a442662d83d649601747c75d150e8cd5c386a3926c0a75a3` | provider-source-replay-development-r1.log (8b537d0d855f11c4ee34547e3eb21a9ee44dbd751292a23487b72cbea9b37aca, match=True) |
| `provider-validation-sequence-r1.json` | `failed` | null | `f5c09596446d9e998689126b9344131cce95e66acffe7ddeacc682bc44e168d3` | missing |
| `provider-validation-sequence-r2.json` | `failed` | null | `b962276527e38b597f8aa35e4ef8a784510345c405f7135e64aae76431e058e7` | missing |
| `read-only-inventory-attempt-r1.json` | `failed` | null | `270870050b3c0adc50faab6c34d1ed9308823698292ca37255b4c71ff5b7cbd2` | missing |
| `rebase-preparation-failure-r1.json` | `failed` | null | `c0aa20be7d2be4a6592a3fb3a63066b4dddfab0a96707777d4f30e9bfd5d16fd` | missing |
| `shared-dictionary-root-red-r1.json` | `failed` | 101 | `356c539c404bcad748b23dcc0f59e017165c1b3e4688caa955d8e6bae9acca9b` | shared-dictionary-root-red-r1.log (9edaed32a34c22cce3a687cad162a3351f3aacb4657d64f705ca8bbedc4034ef, match=True) |
| `standalone-arrays-r1/report.json` | `failed` | null | `0cc9b2a7aab81bf6fb8dd5d892745b93899ead076bcd8df410d7a68a8cea76d3` | standalone-arrays-r1/vortex-array-test.log (39bfcd668c3faa77f282ce3b57bef56f945ad3733d05e1b42e6e67de56362874, match=None); standalone-arrays-r1.log (3e989e458d57d44c3f6d22ba26e54b47fc616913b76b90d7c6b2de10be27117d, match=None) |
| `standalone-arrays-r1.json` | `failed` | 1 | `e508a72e3d874708bc2a0ed021a27d0998b7343faa9034e43a4e98af20d4ffe1` | standalone-arrays-r1.log (3e989e458d57d44c3f6d22ba26e54b47fc616913b76b90d7c6b2de10be27117d, match=True) |
| `standalone-arrays-r2/report.json` | `failed` | null | `cad9a94100d372e067be37b49ba1e7c162057a7b3bc8740501779129e39a2569` | standalone-arrays-r2/vortex-array-test.log (2f54c0d9e7ce76c2209ea23234cbedeb7516c689f56695104603a4bf445d490c, match=None); standalone-arrays-r2.log (f0f3b8049d99fbda9bb756ff25f0c02177b5fe11554ddcfe5cd2d069c09945ce, match=None) |
| `standalone-arrays-r2.json` | `failed` | 1 | `1b4526649693bc8fdc1e44f4aaf84e87d401a53cecdfc394d4975783cbe42c3a` | standalone-arrays-r2.log (f0f3b8049d99fbda9bb756ff25f0c02177b5fe11554ddcfe5cd2d069c09945ce, match=True) |
| `standalone-arrays-r3/report.json` | `failed` | null | `3f7d02e23d0c223fb5c40d5ac2e370a31c2821c07fe4a1cd7932d3f535c1702c` | standalone-arrays-r3/vortex-zstd-test.log (a222eb7a591cc5b4029b6fe2066b15c87577863a4f540159564e638d4502565c, match=None); standalone-arrays-r3.log (5dff778ba935d641b593488d08dcb7345b915ba1783f4955ca2fba785f952fd7, match=None) |
| `standalone-arrays-r3.json` | `failed` | 1 | `3530f1d29ec833a11af60cc6f8c577aca6e2c927f4d1ead887a3c8650463a689` | standalone-arrays-r3.log (5dff778ba935d641b593488d08dcb7345b915ba1783f4955ca2fba785f952fd7, match=True) |
| `standalone-file-zstd-size-r1.json` | `failed` | 101 | `1a105653025dc1da21c94a2b2ba093c5bd5c6b7202db1501f7f49ea4f1866148` | standalone-file-zstd-size-r1.log (243808ae8c1afedbe40188d75b0c55848349ef4f5c5eec2ab77e3862e8746612, match=True) |
| `standalone-formats-r2/report.json` | `failed` | null | `639f23efb101bbb0b2df47836a79cf22beab41dcad628d7a743ca667b507206b` | standalone-formats-r2/parquet-test.log (9b9175390215a076ece296ea032328b38cbf69e80da6c04536fa00ebd3fc0b7d, match=None); standalone-formats-r2.log (19a75f5593619fe93639a4994ffa32161bfaed27029abab4e250bbac4dc53531, match=None) |
| `standalone-formats-r2.json` | `failed` | 1 | `7d65c31a7c533dde6d92bc18e6ed4653d0862b795220535710f371d15836aee5` | standalone-formats-r2.log (19a75f5593619fe93639a4994ffa32161bfaed27029abab4e250bbac4dc53531, match=True) |
| `standalone-io-r1/report.json` | `failed` | null | `072c3694904e4bb0644acbb8d0056ebe16f45c239f98031eed6b781b65a4823c` | standalone-io-r1/vortex-layout-test.log (82991fda632ae8fd8233f4c9d979d5ee6868976b94dd2fbc52078177194fd417, match=None); standalone-io-r1.log (577f2588c7a177f45da84f6aee23ed374cd951fcb5d654f77f9b525974a3feaa, match=None) |
| `standalone-io-r1.json` | `failed` | 1 | `5bea9a4e5fe026968be86a2909a3f52f5b79b14a43817b4384cef1597b73df10` | standalone-io-r1.log (577f2588c7a177f45da84f6aee23ed374cd951fcb5d654f77f9b525974a3feaa, match=True) |
| `standalone-io-r2/report.json` | `failed` | null | `d10f9e2b6bd9517d9b8c60417b0e47bf4266f314ad4fa24e9d3d98122c6648fb` | standalone-io-r2/vortex-layout-test.log (94b21ee695c65db5fc6217db248b9137fbbd2a745b8a0a7180487974d64d74d4, match=None); standalone-io-r2.log (e1b11e484e865232b34471d8392de286841ebdbda680b97b3ef246b7372bfdfa, match=None) |
| `standalone-io-r2.json` | `failed` | 1 | `385c7367bcacf1a4f2e1357141831847b45e12e325c3d8b6b3f4fdca313f8492` | standalone-io-r2.log (e1b11e484e865232b34471d8392de286841ebdbda680b97b3ef246b7372bfdfa, match=True) |
| `standalone-io-r3/report.json` | `failed` | null | `a7ac0faf8c05cfe6776d454b47b1ecf59b833bea581366b998a2a72b4c7b60ca` | standalone-io-r3/vortex-file-test.log (563c6af3ab376d89124e2edb940ddb6ad7b01880c1a99c8123f69da1d9bc268f, match=None); standalone-io-r3.log (be1efe3055fdb63acf37e5aa1ec4d358649894d02fa6f50c1e585b154ce9409d, match=None) |
| `standalone-io-r3.json` | `failed` | 1 | `b8aa5f56df51849c825cae5329aaab5fa6c7a6b2c405090dbf759a1e146c6f31` | standalone-io-r3.log (be1efe3055fdb63acf37e5aa1ec4d358649894d02fa6f50c1e585b154ce9409d, match=True) |
| `standalone-io-r4/report.json` | `failed` | null | `5a04f038e1de7f068a7460d8967a75247c2464d555ba830ccfa641d99a5da0b1` | standalone-io-r4/vortex-file-test.log (1693853623ac4e089436f717ee9e221ff38dd1f37a2e180f3d86fd4f8686a7fe, match=None); standalone-io-r4.log (e8949d1ef41d63863dce40e24b7b93f1a8c88c362babd99d55e0628681ab2386, match=None) |
| `standalone-io-r4.json` | `failed` | 1 | `05762c87c7974d7a995f5fa786391aebcdb4ec6300fe8142797f3784e01fb6e0` | standalone-io-r4.log (e8949d1ef41d63863dce40e24b7b93f1a8c88c362babd99d55e0628681ab2386, match=True) |
| `standalone-io-r5/report.json` | `failed` | null | `0c802ff79f2b1823aff6bdbd4f772f3d7a835e13a00c67d021a675c72584e700` | standalone-io-r5/vortex-file-clippy.log (55d707b9748ebddf3cf188b80ac3c247c51ee72449553273ccd982588dc176e0, match=None); standalone-io-r5.log (b908ca44357411a0099616419da6b1db04d0067b16fa9300fb1a9db0dbf3d4da, match=None) |
| `standalone-io-r5.json` | `failed` | 1 | `a8087f011e9eaee5271b26adb324dab0a904812db2728504544d8e1a08bb620d` | standalone-io-r5.log (b908ca44357411a0099616419da6b1db04d0067b16fa9300fb1a9db0dbf3d4da, match=True) |

## Failed sequence to stage links

- Sequence `provider-validation-sequence-r1.json` active stage `provider-native-clippy-r1.json`: receipt SHA-256 `b387cb8bbe459dc6f272e6ff5e11c1186bace213aa41a9350df637d2e175530d`, status `failed`, return code `101`, log SHA-256 `9b8263d51722d6d3d7414ba727c57608df6afdeb69cd2de5adf2348510742fe6`.
- Sequence `provider-validation-sequence-r2.json` active stage `provider-native-clippy-r2.json`: receipt SHA-256 `025e91609fe30d6c23314f687886f6b2da55ecc77ba1f39209df170f54e46dba`, status `failed`, return code `101`, log SHA-256 `b7f2f5168008cf8a4316e90c142a8fb8d9e4d5871a37107875049e35ece7745b`.

## D references

N continuation says: “Preupgrade D/dependency-validation-sequence-r1 PASSED15stages; baseline only, not upgradedacceptance.” The corresponding D sequence is `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/dependency-validation-sequence-r1.json` (SHA-256 `21a8f946d125045ba216d2b717c9b365f6004d1ef0f5f28f0a36e8bd27766941`), status `passed`. No N provider run/receipt or continuation entry names these D failed receipts by path. The earlier evidence-template inventory mentions fixed names from D helper code only, not D observation receipts, and is not treated as inheritance. The three D failed/preparation candidates checked are:
- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/preparation-selection-failure-r1.json` — `failed`, SHA-256 `b44bad696b6ff31a35e93b35b65d31131964584a55b8a54e0fdf3de26c549cb5`, explicitly linked from N: `false`.
- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/dependencies-preparation-selection-r2.json` — `failed`, SHA-256 `590d1b5ab6f693cf1c0001f1e720577f4087ec87835cd5d34c0a13904ad228e4`, explicitly linked from N: `false`.
- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/preparation-r1/notice-preparation-failure-r1/failure.json` — `failed`, SHA-256 `0bbce8926b4d63c58634fb1c81b282e81be89668eb38c34208b6b28bda2f725d`, explicitly linked from N: `false`.

## D raw-evidence links

- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/preparation-selection-failure-r1.json`: no adjacent raw log found; No embedded source snapshot recorded.
- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/dependencies-preparation-selection-r2.json`: `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/dependencies-preparation-selection-r2.log` (SHA-256 `a1884af2af9d9fc94cc630dc63ea4ab76b16a6ee2a0825174aba5651e96291d0`, bytes 656); Embedded source snapshot: 6 paths.
- `/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07/preparation-r1/notice-preparation-failure-r1/failure.json`: no adjacent raw log found; No embedded source snapshot recorded.

## Literal link gaps

- `candidate-installation-failure-r1.json`: no linked raw log path or log_sha256 is recorded.
- `inventories-primary-source-binding-failure-r1.json`: no linked raw log path or log_sha256 is recorded.
- `provider-provenance-installation-failure-r1.json`: no linked raw log path or log_sha256 is recorded.
- `provider-validation-sequence-r1.json`: no linked raw log path or log_sha256 is recorded.
- `provider-validation-sequence-r2.json`: no linked raw log path or log_sha256 is recorded.
- `read-only-inventory-attempt-r1.json`: no linked raw log path or log_sha256 is recorded.
- `rebase-preparation-failure-r1.json`: no linked raw log path or log_sha256 is recorded.

No status, return code, or failure classification was changed. This inventory does not decide packet membership.
