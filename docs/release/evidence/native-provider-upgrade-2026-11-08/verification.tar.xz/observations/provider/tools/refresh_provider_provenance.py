"""Prepare provider provenance refresh proposals from the exact collected archives."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


HERE = Path(__file__).resolve().parent.parent
SOURCE_ROOT = HERE / 'source-collection-r1' / 'corrected'
MANIFEST_PATH = SOURCE_ROOT / 'manifest.json'
INSTALLATION_PATH = HERE / 'candidate-installation-r1.json'
GENERATED_ROOTS = {'target', '.cache', '__pycache__'}
SELF_PROVENANCE = 'upstream-provenance.json'


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'required regular file missing or symlinked: {path}')
    return json.loads(path.read_text(encoding='utf-8'))


def check_no_symlinks(root, skip_generated=False):
    if root.is_symlink() or not root.is_dir():
        raise RuntimeError(f'required directory missing or symlinked: {root}')
    for base, dirs, files in os.walk(root, followlinks=False):
        retained_dirs = []
        for name in dirs:
            path = Path(base) / name
            if path.is_symlink():
                raise RuntimeError(f'symlink is not permitted in provenance inputs: {path}')
            relative = path.relative_to(root).as_posix()
            if not (skip_generated and ignored_generated(relative)):
                retained_dirs.append(name)
        dirs[:] = retained_dirs
        for name in files:
            path = Path(base) / name
            if path.is_symlink():
                raise RuntimeError(f'symlink is not permitted in provenance inputs: {path}')


def ignored_generated(relative):
    path = PurePosixPath(relative)
    if path.as_posix() == 'Cargo.lock':
        return 'generated Cargo.lock is excluded from final provider file hashes'
    if path.parts and path.parts[0] in GENERATED_ROOTS:
        return 'generated target/cache output is excluded from final provider file hashes'
    return None


def tree_hashes(root, exclude_generated=False):
    check_no_symlinks(root, skip_generated=exclude_generated)
    result = {}
    omitted = {}
    for base, dirs, files in os.walk(root, followlinks=False):
        relative_base = Path(base).relative_to(root).as_posix()
        if relative_base == '.':
            relative_base = ''
        retained_dirs = []
        for directory in sorted(dirs):
            relative = (Path(relative_base) / directory).as_posix() if relative_base else directory
            if exclude_generated and ignored_generated(relative):
                omitted[relative + '/'] = 'generated target/cache directory excluded from final provider file hashes'
            else:
                retained_dirs.append(directory)
        dirs[:] = retained_dirs
        for name in sorted(files):
            path = Path(base) / name
            relative = (Path(relative_base) / name).as_posix() if relative_base else name
            if exclude_generated and relative == SELF_PROVENANCE:
                omitted[relative] = 'self upstream-provenance.json excluded to avoid recursive hashing'
                continue
            reason = ignored_generated(relative) if exclude_generated else None
            if reason:
                omitted[relative] = reason
                continue
            if not path.is_file():
                raise RuntimeError(f'non-regular provider file: {path}')
            result[relative] = sha256(path.read_bytes())
    return result, omitted


def archive_identity(archive, crate_root):
    """Hash the downloaded archive and every tar member without extracting it."""
    raw_archive = archive.read_bytes()
    files = {}
    members = []
    with tarfile.open(archive, mode='r:gz') as tar:
        for member in tar.getmembers():
            raw_name = member.name.replace('\\', '/')
            parts = PurePosixPath(raw_name).parts
            if (not parts or raw_name.startswith('/') or '..' in parts or
                    parts[0] != crate_root):
                raise RuntimeError(f'unexpected archive member path: {raw_name}')
            relative = '/'.join(parts[1:])
            if member.isdir():
                members.append({'path': raw_name.rstrip('/'), 'type': 'directory', 'bytes': 0})
                continue
            if member.issym() or member.islnk():
                raise RuntimeError(f'archive symlink/hardlink is not permitted: {raw_name}')
            if not member.isfile():
                raise RuntimeError(f'unexpected archive member type: {raw_name} ({member.type!r})')
            if not relative or relative in files:
                raise RuntimeError(f'empty or duplicate archive file path: {raw_name}')
            stream = tar.extractfile(member)
            if stream is None:
                raise RuntimeError(f'archive member has no data: {raw_name}')
            contents = stream.read()
            if len(contents) != member.size:
                raise RuntimeError(f'archive member size mismatch: {raw_name}')
            digest = sha256(contents)
            files[relative] = digest
            members.append({'path': raw_name, 'type': 'file', 'bytes': len(contents), 'sha256': digest})
    members.sort(key=lambda item: (item['path'], item['type']))
    return {'archive_sha256': sha256(raw_archive), 'archive_bytes': len(raw_archive),
            'member_count': len(files), 'uncompressed_bytes': sum(
                item['bytes'] for item in members if item['type'] == 'file'),
            'files': files, 'members': members}


def map_differences(before, after):
    keys = sorted(set(before) | set(after))
    return [{'path': key, 'before': before.get(key), 'after': after.get(key)}
            for key in keys if before.get(key) != after.get(key)]


def supplemental_paths(provenance):
    paths = set()
    for key, item in provenance.get('supplemental_test_files', {}).items():
        paths.add(item.get('path', key))
    return paths


def provider_proposal(root, candidate, install_row):
    name = candidate['name']
    version = candidate['version']
    if (name, version) != (install_row['provider'], install_row['version']):
        raise RuntimeError(f'candidate/install identity mismatch: {name} {version}')
    archive = SOURCE_ROOT / candidate['archive']['path']
    if archive.is_symlink() or not archive.is_file():
        raise RuntimeError(f'candidate archive missing or symlinked: {archive}')
    archive_data = archive_identity(archive, f'{name}-{version}')
    source_dir = archive.parent / 'source' / f'{name}-{version}'
    extracted_source, _ = tree_hashes(source_dir)
    if extracted_source != archive_data['files']:
        raise RuntimeError(f'extracted original source does not exactly match archive: {name}')

    expected_members = {item['path']: {'bytes': item['bytes'], 'sha256': item['sha256']}
                        for item in candidate['source_inventory']['members']}
    computed_members = {item['path']: {'bytes': item['bytes'], 'sha256': item['sha256']}
                        for item in archive_data['members'] if item['type'] == 'file'}
    expected_archive_sha = candidate['archive']['sha256']
    install_archive_sha = install_row['archive_sha256']
    mismatches = []
    if archive_data['archive_sha256'] != expected_archive_sha:
        mismatches.append({'kind': 'manifest_archive_sha256', 'expected': expected_archive_sha,
                           'computed': archive_data['archive_sha256']})
    if archive_data['archive_sha256'] != install_archive_sha:
        mismatches.append({'kind': 'installation_archive_sha256', 'expected': install_archive_sha,
                           'computed': archive_data['archive_sha256']})
    if archive_data['member_count'] != candidate['source_inventory']['member_count']:
        mismatches.append({'kind': 'manifest_member_count', 'expected': candidate['source_inventory']['member_count'],
                           'computed': archive_data['member_count']})
    if archive_data['uncompressed_bytes'] != candidate['source_inventory']['uncompressed_bytes']:
        mismatches.append({'kind': 'manifest_uncompressed_bytes',
                           'expected': candidate['source_inventory']['uncompressed_bytes'],
                           'computed': archive_data['uncompressed_bytes']})
    if expected_members != computed_members:
        mismatches.append({'kind': 'manifest_member_identity',
                           'differences': map_differences(expected_members, computed_members)})

    provider_root = root / 'vendor' / name
    final_files, generated_omissions = tree_hashes(provider_root, exclude_generated=True)
    provenance_path = provider_root / SELF_PROVENANCE
    old = read_json(provenance_path)
    old_provenance_sha = sha256(provenance_path.read_bytes())
    if old.get('migration_status') != 'candidate_port_under_validation':
        raise RuntimeError(f'unexpected migration_status for {name}: {old.get("migration_status")!r}')
    if not old.get('predecessor'):
        raise RuntimeError(f'missing exact predecessor record: {name}')

    old_original = old.get('original_files_sha256', {})
    old_modified = old.get('modified_files_sha256', {})
    old_added = old.get('added_files_sha256', {})
    old_omitted = old.get('omitted_files', {})
    expected_additions = set(old_added) | supplemental_paths(old)
    original = archive_data['files']
    modified = {path: final_files[path] for path in sorted(set(original) & set(final_files))
                if original[path] != final_files[path]}
    added = {path: final_files[path] for path in sorted(set(final_files) - set(original))
             if path in expected_additions}
    unknown_extras = {path: digest for path, digest in final_files.items()
                      if path not in original and path not in expected_additions}
    omitted = {}
    missing_unexpected = []
    for path in sorted(set(original) - set(final_files)):
        if path in old_omitted:
            omitted[path] = old_omitted[path]
        elif ignored_generated(path):
            omitted[path] = ignored_generated(path)
        else:
            missing_unexpected.append(path)
    if missing_unexpected:
        raise RuntimeError(f'unexpected missing archive source files for {name}: {missing_unexpected}')

    # License identities are retained verbatim and checked against the final provider files.
    license_sha = old.get('license_sha256')
    if not license_sha or license_sha not in final_files.values():
        raise RuntimeError(f'missing or mismatched primary license file for {name}')
    for item in old.get('additional_license_files', []) or []:
        path = item.get('path')
        if not path or path not in final_files or final_files[path] != item.get('sha256'):
            raise RuntimeError(f'missing or mismatched additional license file for {name}: {path}')
    notice_sha = old.get('notice_sha256')
    notice_match = bool(notice_sha and notice_sha in final_files.values()) if notice_sha else None

    local_doc = copy.deepcopy(old.get('local_changes_documentation'))
    if not local_doc or not local_doc.get('path') or local_doc['path'] not in final_files:
        raise RuntimeError(f'missing local README identity for {name}')
    local_doc['sha256'] = final_files[local_doc['path']]

    vcs_bytes = archive_data['files'].get('.cargo_vcs_info.json')
    vcs_info = None
    if vcs_bytes is not None:
        with tarfile.open(archive, mode='r:gz') as tar:
            member = tar.extractfile(f'{name}-{version}/.cargo_vcs_info.json')
            if member is None:
                raise RuntimeError(f'archive VCS identity member could not be read: {name}')
            vcs_info = json.loads(member.read().decode('utf-8'))

    def verified_archive_url(field, expected_sha, old_url, name_filter):
        matching = [path for path, digest in original.items()
                    if digest == expected_sha and name_filter(PurePosixPath(path).name)]
        old_fragment = old_url.partition('#')[2] if old_url else ''
        if old_fragment in matching:
            member_path = old_fragment
        elif len(matching) == 1:
            member_path = matching[0]
        else:
            return old_url, {'field': field, 'prior_url': old_url,
                'candidate_archive_member': None, 'expected_sha256': expected_sha,
                'candidate_members_matching_bytes': matching,
                'status': 'unresolved_no_unique_verified_candidate_member'}
        return candidate['archive']['url'] + '#' + member_path, {
            'field': field, 'prior_url': old_url,
            'candidate_url': candidate['archive']['url'] + '#' + member_path,
            'candidate_archive_member': member_path, 'expected_sha256': expected_sha,
            'verified_member_sha256': original[member_path], 'status': 'verified_exact_member_bytes'}

    url_bindings = []
    candidate_license_url, binding = verified_archive_url('license_url', license_sha,
        old.get('license_url'), lambda basename: 'LICENSE' in basename.upper())
    url_bindings.append(binding)
    candidate_notice_url = old.get('notice_url')
    if old.get('notice_url'):
        if notice_sha:
            candidate_notice_url, binding = verified_archive_url('notice_url', notice_sha,
                old.get('notice_url'), lambda basename: 'NOTICE' in basename.upper())
        else:
            binding = {'field': 'notice_url', 'prior_url': old.get('notice_url'),
                'candidate_archive_member': None, 'status': 'unresolved_no_notice_sha256'}
        url_bindings.append(binding)
    additional_license_files = copy.deepcopy(old.get('additional_license_files', []))
    for index, item in enumerate(additional_license_files or []):
        path = item.get('path')
        expected = item.get('sha256')
        if path in original and original[path] == expected:
            item['url'] = candidate['archive']['url'] + '#' + path
            url_bindings.append({'field': f'additional_license_files[{index}].url',
                'prior_url': old.get('additional_license_files', [])[index].get('url'),
                'candidate_url': item['url'], 'candidate_archive_member': path,
                'expected_sha256': expected, 'verified_member_sha256': original[path],
                'status': 'verified_exact_member_bytes'})
        else:
            url_bindings.append({'field': f'additional_license_files[{index}].url',
                'prior_url': item.get('url'), 'candidate_archive_member': path,
                'expected_sha256': expected, 'candidate_member_sha256': original.get(path),
                'status': 'unresolved_candidate_member_missing_or_hash_mismatch'})

    def collect_nonlegal_urls(value, prefix=''):
        found = {}
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f'{prefix}.{key}' if prefix else key
                if (key in {'license_url', 'notice_url'} or
                        (key == 'url' and prefix.startswith('additional_license_files['))):
                    continue
                found.update(collect_nonlegal_urls(child, child_path))
        elif isinstance(value, list):
            for index, child in enumerate(value):
                found.update(collect_nonlegal_urls(child, f'{prefix}[{index}]'))
        elif prefix.endswith('_url') or prefix.endswith('.url'):
            found[prefix] = value
        return found

    prior_nonlegal_urls = collect_nonlegal_urls(old)

    proposed = copy.deepcopy(old)
    proposed.update(version=version, registry_archive_sha256=archive_data['archive_sha256'],
        registry_archive_file_count=archive_data['member_count'],
        registry_archive_uncompressed_bytes=archive_data['uncompressed_bytes'],
        original_files_sha256=original, modified_files_sha256=modified,
        added_files_sha256=added, omitted_files=omitted, vcs_info=vcs_info,
        source_of_truth=candidate['archive']['url'],
        migration_status='candidate_port_under_validation',
        predecessor=copy.deepcopy(old['predecessor']), local_changes_documentation=local_doc)
    proposed['license_url'] = candidate_license_url
    if old.get('notice_url'):
        proposed['notice_url'] = candidate_notice_url
    if additional_license_files:
        proposed['additional_license_files'] = additional_license_files

    installed = install_row.get('installed_files', {})
    installed_without_self = {path: digest for path, digest in installed.items()
                              if path != SELF_PROVENANCE and not ignored_generated(path)}
    install_tree_differences = map_differences(installed_without_self, final_files)
    provenance_mismatches = {
        'original_files_sha256': map_differences(old_original, original),
        'modified_files_sha256': map_differences(old_modified, modified),
        'added_files_sha256': map_differences(old_added, added),
        'omitted_files': map_differences(old_omitted, omitted),
        'local_changes_documentation_sha256': old.get('local_changes_documentation', {}).get('sha256') != local_doc['sha256'],
        'registry_archive_sha256': old.get('registry_archive_sha256') != archive_data['archive_sha256'],
        'registry_archive_file_count': old.get('registry_archive_file_count') != archive_data['member_count'],
        'registry_archive_uncompressed_bytes': old.get('registry_archive_uncompressed_bytes') != archive_data['uncompressed_bytes'],
        'source_of_truth': old.get('source_of_truth') != candidate['archive']['url'],
        'vcs_info': old.get('vcs_info') != vcs_info,
    }
    report = {'provider': name, 'version': version,
        'archive': {'path': candidate['archive']['path'], 'sha256': archive_data['archive_sha256'],
            'bytes': archive_data['archive_bytes'], 'member_count': archive_data['member_count'],
            'uncompressed_bytes': archive_data['uncompressed_bytes'], 'members': archive_data['members']},
        'archive_manifest_comparison': {'mismatches': mismatches},
        'source_directory_matches_archive': True,
        'current_provenance_path': str(provenance_path),
        'current_provenance_sha256': old_provenance_sha,
        'proposed_provenance_sha256': sha256((json.dumps(proposed, indent=2) + '\n').encode()),
        'final_provider_files_sha256': final_files,
        'generated_files_excluded': generated_omissions,
        'self_provenance_excluded_from_added_hashes': True,
        'unknown_extras_without_inferred_provenance': unknown_extras,
        'installation_record_file_differences_excluding_self': install_tree_differences,
        'stored_provenance_comparison': provenance_mismatches,
        'license_sha256_preserved_and_present': license_sha,
        'final_files_matching_license_sha256': sorted(path for path, digest in final_files.items()
                                                       if digest == license_sha),
        'additional_license_file_paths_and_hashes_preserved': [
            {'path': item.get('path'), 'sha256': item.get('sha256')}
            for item in old.get('additional_license_files', []) or []],
        'proposed_additional_license_files': copy.deepcopy(additional_license_files),
        'notice_sha256_preserved_match': notice_match,
        'predecessor_test_source_preserved_verbatim': proposed.get('predecessor_test_source') == old.get('predecessor_test_source'),
        'legal_url_bindings': url_bindings,
        'nonlegal_url_fields_preserved_verbatim': prior_nonlegal_urls == collect_nonlegal_urls(proposed),
        'nonlegal_url_fields': prior_nonlegal_urls,
        'predecessor_preserved_verbatim': proposed['predecessor'] == old['predecessor'],
        'migration_status': proposed['migration_status'],
        'supplemental_test_files_preserved_verbatim': proposed.get('supplemental_test_files') == old.get('supplemental_test_files'),
        'local_changes_documentation': local_doc}
    report['primary_review_items'] = []
    if mismatches:
        report['primary_review_items'].append('archive identity differs from collection manifest or installation record')
    if install_tree_differences:
        report['primary_review_items'].append('current provider tree differs from candidate installation record')
    if unknown_extras:
        report['primary_review_items'].append('unclassified extra provider files are present')
    if any(binding['status'] != 'verified_exact_member_bytes' for binding in url_bindings):
        report['primary_review_items'].append('one or more legal URLs lack a uniquely verified candidate archive member')
    if notice_match is False:
        report['primary_review_items'].append('stored notice hash does not match a final provider file')
    for field, value in provenance_mismatches.items():
        differs = bool(value) if isinstance(value, list) else value
        if differs:
            report['primary_review_items'].append(f'stored provenance field differs: {field}')
    if prior_nonlegal_urls != collect_nonlegal_urls(proposed):
        report['primary_review_items'].append('historical/nonlegal URL fields changed')
    return proposed, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True, help='Repository root containing candidate vendor providers')
    parser.add_argument('--output', type=Path, required=True, help='New scratch directory for proposals and report')
    args = parser.parse_args()
    if args.root.is_symlink():
        parser.error('--root must not be a symlink')
    root = args.root.resolve(strict=True)
    if args.output.is_symlink():
        parser.error('--output must not be a symlink')
    output = args.output.resolve(strict=False)
    if not root.is_dir() or root.is_symlink():
        parser.error('--root must resolve to a non-symlink directory')
    if output.exists():
        parser.error('--output must be a new, non-existing scratch directory')
    if output == root or output.is_relative_to(root):
        parser.error('--output must be outside the repository root')
    if output == HERE or not output.is_relative_to(HERE):
        parser.error('--output must be a new scratch directory under this provider-upgrade task root')
    if output == SOURCE_ROOT or output.is_relative_to(SOURCE_ROOT):
        parser.error('--output must not overlap the collected source archives')

    manifest = read_json(MANIFEST_PATH)
    installation = read_json(INSTALLATION_PATH)
    if installation.get('status') != 'installed_candidate_not_accepted':
        raise RuntimeError(f'unexpected candidate installation status: {installation.get("status")!r}')
    root_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    candidates = {(row['name'], row['version']): row for row in manifest['results']
                  if row.get('role') == 'candidate'}
    install_rows = installation.get('providers', [])
    if len(install_rows) != 12 or len({row['provider'] for row in install_rows}) != 12:
        raise RuntimeError('expected exactly 12 distinct changed provider installation rows')

    proposals = {}
    reports = []
    for install_row in sorted(install_rows, key=lambda row: row['provider']):
        key = (install_row['provider'], install_row['version'])
        if key not in candidates:
            raise RuntimeError(f'candidate archive missing from source manifest: {key}')
        proposed, report = provider_proposal(root, candidates[key], install_row)
        proposals[install_row['provider']] = proposed
        reports.append(report)

    # Keep proposal creation separate from all repository inputs and require a fresh destination.
    output.mkdir(parents=True, exist_ok=False)
    proposal_root = output / 'proposed'
    for name, proposed in proposals.items():
        destination = proposal_root / name / SELF_PROVENANCE
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(proposed, indent=2) + '\n', encoding='utf-8')
    review_items_count = sum(len(item['primary_review_items']) for item in reports)
    report = {'status': 'generated_with_primary_review_items' if review_items_count else 'generated_for_primary_review',
        'primary_review_items_count': review_items_count, 'root': str(root),
        'root_head': root_head, 'candidate_installation_head': installation.get('head'),
        'root_head_matches_candidate_installation': root_head == installation.get('head'),
        'source_collection': str(SOURCE_ROOT), 'source_manifest_sha256': sha256(MANIFEST_PATH.read_bytes()),
        'candidate_installation_sha256': sha256(INSTALLATION_PATH.read_bytes()),
        'providers': reports,
        'scope_notes': {'source_archive_identity': 'Computed from exact .crate bytes and every regular/directory tar member; member SHA-256 values are reported.',
            'original_files_sha256': 'Hashes every regular archive source file, including archived Cargo.lock; archive member identity and archive SHA bind those bytes.',
            'final_provider_hash_policy': 'Root vendor files exclude any Cargo.lock and target/cache/__pycache__ paths; upstream-provenance.json is omitted to avoid self-recursion.',
            'unknown_extras': 'Reported with hashes but omitted from added_files_sha256 until primary classifies them; no provenance is inferred.',
            'license_and_predecessor_fields': 'Copied from the current provider provenance; license identities and exact predecessor values are not legally or semantically reassessed.',
            'migration_status': 'Retained as candidate_port_under_validation pending primary acceptance.'}}
    report_path = output / 'comparison-report.json'
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    lines = ['# Provider provenance refresh comparison', '',
        f'- Status: `{report["status"]}`',
        f'- Primary review items: {report["primary_review_items_count"]}', f'- Repository: `{root}`',
        f'- Source manifest SHA-256: `{report["source_manifest_sha256"]}`',
        f'- Candidate installation SHA-256: `{report["candidate_installation_sha256"]}`',
        '- Proposals are scratch outputs only; repository files were not written.',
        '- Current migration status remains `candidate_port_under_validation` in every proposal.', '',
        '## Per-provider comparison', '']
    for item in reports:
        lines += [f'### `{item["provider"]}` {item["version"]}',
            f'- Archive SHA-256: `{item["archive"]["sha256"]}`; members: {item["archive"]["member_count"]}; uncompressed bytes: {item["archive"]["uncompressed_bytes"]}',
            f'- Current provenance SHA-256: `{item["current_provenance_sha256"]}`',
            f'- Proposed provenance SHA-256: `{item["proposed_provenance_sha256"]}`',
            f'- Archive/manifest mismatches: {len(item["archive_manifest_comparison"]["mismatches"])}; installation file differences: {len(item["installation_record_file_differences_excluding_self"])}',
            f'- Unknown extras without inferred provenance: {len(item["unknown_extras_without_inferred_provenance"])}; generated files excluded: {len(item["generated_files_excluded"])}',
            f'- Notice hash match: `{item["notice_sha256_preserved_match"]}`', '']
        for binding in item['legal_url_bindings']:
            lines.append(f'  - URL `{binding["field"]}`: `{binding["status"]}`; prior `{binding.get("prior_url")}`; candidate `{binding.get("candidate_url", "unresolved")}`')
        for mismatch in item['archive_manifest_comparison']['mismatches']:
            lines.append(f'  - Archive mismatch: `{mismatch["kind"]}`')
        for path in item['unknown_extras_without_inferred_provenance']:
            lines.append(f'  - Unknown extra: `{path}`')
        for review_item in item['primary_review_items']:
            lines.append(f'  - Primary review item: {review_item}')
        for binding in item['legal_url_bindings']:
            if binding['status'] != 'verified_exact_member_bytes':
                lines.append(f'  - URL requires primary reconciliation: `{binding["field"]}` — `{binding.get("prior_url")}` ({binding["status"]})')
    lines += ['', 'The JSON report contains every archive member identity, final provider file hash, mismatch detail, excluded generated path description, and preserved provenance field comparison.', '']
    (output / 'comparison-report.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'status': report['status'], 'providers': len(reports),
        'output': str(output), 'report': str(report_path),
        'proposals': [str(proposal_root / name / SELF_PROVENANCE) for name in sorted(proposals)]}, indent=2))


if __name__ == '__main__':
    main()
