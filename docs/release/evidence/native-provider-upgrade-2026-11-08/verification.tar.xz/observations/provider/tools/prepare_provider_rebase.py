"""Prepare three-way provider patch candidates without changing the repository."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
SOURCES = OUT / 'source-collection-r1/corrected'
STAGE = OUT / 'rebase-r1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
verification = json.loads((OUT / 'source-collection-primary-verification-r1.json').read_bytes())
assert verification['status'] == 'passed'
assert sha((SOURCES / 'manifest.json').read_bytes()) == verification['manifest_sha256']
assert not STAGE.exists()
assert shutil.disk_usage(OUT).free >= 12 * 1024**3 + 128 * 1024**2
STAGE.mkdir()
records = []
names = ['vortex-array', 'vortex-buffer', 'vortex-datetime-parts', 'vortex-file',
         'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-zstd',
         'arrow-array', 'arrow-avro', 'arrow-ipc', 'parquet']

def write(path, raw):
    assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)

def difference(a, b, old_name, new_name):
    return ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),
        b.decode().splitlines(keepends=True), fromfile=old_name, tofile=new_name))

def merge(local, old, new, dest):
    result = subprocess.run(['git', 'merge-file', '-p', '--diff3',
        '-L', 'retained-local', '-L', 'published-baseline', '-L', 'published-candidate',
        str(local), str(old), str(new)], capture_output=True, check=False, timeout=30)
    assert 0 <= result.returncode < 128, result.stderr.decode()
    write(dest, result.stdout)
    return result.returncode

for name in names:
    old_version, new_version = ('0.90.0', '0.93.0') if name.startswith('vortex-') else ('59.3.1', '59.3.2')
    old = SOURCES / 'baseline' / f'{name}-{old_version}' / 'source' / f'{name}-{old_version}'
    new = SOURCES / 'candidate' / f'{name}-{new_version}' / 'source' / f'{name}-{new_version}'
    local = ROOT / 'vendor' / name
    dest = STAGE / 'vendor' / name
    provenance = json.loads((local / 'upstream-provenance.json').read_bytes())
    expected = dict(provenance['original_files_sha256'])
    expected.update(provenance['modified_files_sha256'])
    expected.update(provenance['added_files_sha256'])
    for path in provenance.get('omitted_files', {}):
        expected.pop(path)
    actual = {p.relative_to(local).as_posix(): sha(p.read_bytes())
              for p in local.rglob('*') if p.is_file() and p.name not in {'upstream-provenance.json', 'Cargo.lock'}}
    expected.pop('Cargo.lock', None)
    assert actual == expected, (name, set(actual) ^ set(expected),
        [p for p in set(actual) & set(expected) if actual[p] != expected[p]])
    files = []
    # Copy all upstream originals except the deliberately omitted local lock.
    for path in sorted(new.rglob('*')):
        if not path.is_file() or path.name == 'Cargo.lock':
            continue
        relative = path.relative_to(new).as_posix()
        if relative in provenance['modified_files_sha256']:
            code = merge(local / relative, old / relative, path, dest / relative)
            status = 'three_way_clean' if code == 0 else 'conflict'
            files.append(dict(path=relative, status=status, conflict_count=code,
                local_sha256=sha((local / relative).read_bytes()),
                baseline_sha256=sha((old / relative).read_bytes()),
                candidate_sha256=sha(path.read_bytes()), result_sha256=sha((dest / relative).read_bytes())))
        else:
            write(dest / relative, path.read_bytes())
    for relative in provenance['modified_files_sha256']:
        if not (new / relative).exists():
            write(STAGE / 'removed-upstream' / name / relative, (local / relative).read_bytes())
            files.append(dict(path=relative, status='upstream_removed_needs_port',
                local_sha256=sha((local / relative).read_bytes())))
    for relative in provenance['added_files_sha256']:
        assert not (new / relative).exists(), (name, relative)
        write(dest / relative, (local / relative).read_bytes())
        files.append(dict(path=relative, status='retained_local_addition',
                          local_sha256=sha((local / relative).read_bytes())))
    old_map = {p.relative_to(old).as_posix(): p for p in old.rglob('*') if p.is_file()}
    new_map = {p.relative_to(new).as_posix(): p for p in new.rglob('*') if p.is_file()}
    upstream_changes = []
    for relative in sorted(old_map.keys() | new_map.keys()):
        a = old_map[relative].read_bytes() if relative in old_map else b''
        b = new_map[relative].read_bytes() if relative in new_map else b''
        if a == b:
            continue
        upstream_changes.append(dict(path=relative, before_sha256=sha(a) if a else None,
                                     after_sha256=sha(b) if b else None))
        if relative.endswith('.rs') or relative in {'Cargo.toml', 'Cargo.toml.orig'}:
            patch = difference(a, b, f'{name}-{old_version}/{relative}', f'{name}-{new_version}/{relative}')
            write(STAGE / 'upstream-diffs' / name / (relative + '.diff'), patch.encode())
    records.append(dict(provider=name, old_version=old_version, candidate_version=new_version,
        local_provenance_sha256=sha((local / 'upstream-provenance.json').read_bytes()),
        patches=files, upstream_changes=upstream_changes))

# The one retained RunEnd source change moved into the array crate upstream.
runend_old = SOURCES / 'baseline/vortex-runend-0.90.0/source/vortex-runend-0.90.0/src/compress.rs'
runend_local = ROOT / 'vendor/vortex-runend/src/compress.rs'
runend_new = SOURCES / 'candidate/vortex-array-0.93.0/source/vortex-array-0.93.0/src/arrays/runend/compress.rs'
runend_dest = STAGE / 'runend-port/compress.rs'
code = merge(runend_local, runend_old, runend_new, runend_dest)
runend = dict(from_path='vendor/vortex-runend/src/compress.rs',
              to_path='vendor/vortex-array/src/arrays/runend/compress.rs',
              conflict_count=code, status='three_way_clean' if code == 0 else 'conflict',
              result_sha256=sha(runend_dest.read_bytes()))
report = dict(status='prepared_needs_primary_review', providers=records, runend_port=runend,
              driver_sha256=sha(Path(__file__).read_bytes()), repository_changed=False)
write(STAGE / 'preparation.json', (json.dumps(report, indent=2) + '\n').encode())
print(json.dumps(dict(status=report['status'], providers=len(records),
    conflicts={r['provider']: [f['path'] for f in r['patches'] if f['status']=='conflict'] for r in records},
    removed={r['provider']: [f['path'] for f in r['patches'] if f['status']=='upstream_removed_needs_port'] for r in records},
    runend=runend), indent=2))
