"""Format current workspace and locally changed provider Rust sources."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
SOURCES = OUT / 'source-collection-r1/corrected'
parser = argparse.ArgumentParser()
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
receipt = args.receipt
assert not receipt.exists()
manifest = json.loads((SOURCES / 'manifest.json').read_text())
env = dict(os.environ, PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:' + os.environ['PATH'])
sha = lambda raw: hashlib.sha256(raw).hexdigest()
entries = []
for item in manifest['results']:
    if item['role'] != 'candidate':
        continue
    provider = ROOT / 'vendor' / item['name']
    if not provider.is_dir():
        continue
    upstream = SOURCES / Path(item['archive']['path']).parent / 'source' / f"{item['name']}-{item['version']}"
    edition = tomllib.loads((provider / 'Cargo.toml').read_text())['package']['edition']
    for path in provider.rglob('*.rs'):
        relative = path.relative_to(provider)
        original = upstream / relative
        before = path.read_bytes()
        if original.is_file() and before == original.read_bytes():
            continue
        command = ['rustfmt', '--edition', edition, '--config', 'skip_children=true', str(path)]
        subprocess.run(command, cwd=provider, env=env, check=True)
        entries.append({'path': str(path.relative_to(ROOT)), 'before': sha(before), 'after': sha(path.read_bytes()), 'command': command})
subprocess.run(['cargo', 'fmt', '--all'], cwd=ROOT, env=env, check=True)
receipt.write_text(json.dumps({'status': 'passed', 'provider_files': entries, 'workspace_command': ['cargo', 'fmt', '--all']}, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'provider_files': len(entries)}))
