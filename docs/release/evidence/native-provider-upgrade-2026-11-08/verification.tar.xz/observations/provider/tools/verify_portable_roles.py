"""Independently check complete current graph/development/provider archive roles."""
import hashlib
import json
from pathlib import Path
import tarfile
import tomllib

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: json.loads((N / name).read_bytes())
value = read('portable-archive-role-inventory-r2.json')
rows = value['items']
roles = {'resolved_graph_r3_registry', 'new_development_package',
         'vendored_upstream_provenance_current_archive'}
assert {r['role'] for r in rows} == roles
keys = [(r['role'], r.get('graph_side'), r['name'], r['version'],
         r['checksum_sha256'], r['archive_original_path']) for r in rows]
assert len(keys) == len(set(keys))
for item in value['inputs'].values():
    for source in item if isinstance(item, list) else [item]:
        raw = Path(source['path']).read_bytes()
        assert sha(raw) == source['sha256']
        if 'bytes' in source:
            assert len(raw) == source['bytes']
expected_graph = set()
for row in read('resolved-graph-inventory-r3.json')['r2_manifest_evidence']:
    p, e = row['lock_record'], row['manifest_evidence']
    if p.get('source') is not None:
        for a in e['archives']:
            expected_graph.add((row['side'], p['name'], p['version'], p['checksum'],
                                a['path'], a['bytes'], e['manifest_sha256']))
actual_graph = {(r['graph_side'], r['name'], r['version'], r['checksum_sha256'],
                 r['archive_original_path'], r['archive_bytes'], r['manifest_member_sha256'])
                for r in rows if r['role'] == 'resolved_graph_r3_registry'}
assert actual_graph == expected_graph
development = read('standalone-graph-primary-review-r2.json')['new_development_packages']
expected_dev = {(r['name'], r['version'], r['checksum'], p, r['manifest_sha256'])
                for r in development for p in r['matching_archive_paths']}
actual_dev = {(r['name'], r['version'], r['checksum_sha256'], r['archive_original_path'],
               r['manifest_member_sha256']) for r in rows if r['role'] == 'new_development_package'}
assert actual_dev == expected_dev
expected_vendor = set()
for path in (V / 'vendor').glob('*/upstream-provenance.json'):
    p = json.loads(path.read_bytes())
    expected_vendor.add((p['provider'], p['version'], p['registry_archive_sha256']))
vendor = [r for r in rows if r['role'] == 'vendored_upstream_provenance_current_archive']
assert {(r['name'], r['version'], r['checksum_sha256']) for r in vendor} == expected_vendor
for r in vendor:
    assert sha(Path(r['upstream_provenance_path']).read_bytes()) == r['upstream_provenance_sha256']
    raw = Path(r['vendor_manifest_path']).read_bytes()
    assert len(raw) == r['vendor_manifest_bytes'] and sha(raw) == r['vendor_manifest_sha256']
blobs = {}
for r in rows:
    checksum = r['checksum_sha256']
    assert r['blob_path'] == 'portable-archive-sources-r1/blobs/' + checksum + '.crate'
    source, blob = Path(r['archive_original_path']), N / r['blob_path']
    assert source.is_file() and not source.is_symlink() and blob.is_file() and not blob.is_symlink()
    raw = blob.read_bytes()
    assert raw == source.read_bytes()
    assert sha(raw) == checksum == r['archive_sha256'] == r['blob_sha256']
    assert len(raw) == r['archive_bytes'] == r['blob_bytes']
    with tarfile.open(blob, 'r:gz') as archive:
        member = archive.getmember(r['manifest_member_path'])
        assert member.isfile() and member.name == r['name'] + '-' + r['version'] + '/Cargo.toml'
        manifest = archive.extractfile(member).read()
    assert len(manifest) == r['manifest_member_bytes'] and sha(manifest) == r['manifest_member_sha256']
    package = tomllib.loads(manifest.decode())['package']
    assert {key: package.get(key) for key in r['package_manifest_fields']} == r['package_manifest_fields']
    assert (package['name'], package['version']) == (r['name'], r['version'])
    blobs[checksum] = len(raw)
assert {p.name for p in (N / 'portable-archive-sources-r1/blobs').iterdir()} == {h + '.crate' for h in blobs}
result = dict(status='passed', inventory_sha256=sha((N / 'portable-archive-role-inventory-r2.json').read_bytes()),
              verifier_sha256=sha(Path(__file__).read_bytes()), graph_archive_copies=len(actual_graph),
              new_development_identities=len(development), development_archive_copies=len(actual_dev),
              current_provider_identities=len(expected_vendor), vendor_archive_copies=len(vendor),
              all_role_source_copies=len(rows), unique_archives=len(blobs), compressed_bytes=sum(blobs.values()),
              scope='Complete roles and every source/blob/manifest identity checked. Runtime acceptance remains separate.')
with (N / 'portable-archive-primary-verification-r2.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
