#!/usr/bin/env python3
"""Read-only local inventory of registry packages missing from the license bundle."""

from __future__ import annotations

import hashlib
import json
import os
import tarfile
import tomllib
import zipfile
from pathlib import Path


V = Path("/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo")
N = Path("/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08")
LOCK = V / "Cargo.lock"
BUNDLE = V / "python/THIRD_PARTY_LICENSES/manifest.json"
CORRECTED = N / "source-collection-r1/corrected"
CARGO_CACHE = Path.home() / ".cargo/registry/cache/index.crates.io-1949cf8c6b5b557f"
OUT_JSON = N / "registry-notice-inventory-r1.json"
OUT_MD = N / "registry-notice-inventory-r1.md"
TEXT_ROOT = N / "registry-notice-inventory-r1"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def archive_candidates(name: str, version: str) -> list[Path]:
    filename = f"{name}-{version}.crate"
    return [
        CARGO_CACHE / filename,
        CORRECTED / "candidate" / f"{name}-{version}" / filename,
        CORRECTED / "baseline" / f"{name}-{version}" / filename,
    ]


def local_source_candidates(name: str, version: str) -> list[Path]:
    dirname = f"{name}-{version}"
    return [
        CORRECTED / role / dirname / "source" / dirname
        for role in ("candidate", "baseline")
    ]


def package_toml_from_tar(path: Path) -> tuple[bytes, list[tuple[str, bytes]]]:
    with tarfile.open(path, mode="r:gz") as tf:
        cargo_members = [m for m in tf.getmembers() if m.isfile() and m.name.count("/") == 1 and m.name.endswith("/Cargo.toml")]
        if len(cargo_members) != 1:
            raise ValueError(f"expected one root Cargo.toml; found {len(cargo_members)}")
        root = cargo_members[0].name.split("/", 1)[0]
        cargo_data = tf.extractfile(cargo_members[0]).read()
        legal = []
        prefixes = ("license", "notice", "copying")
        for member in tf.getmembers():
            if not member.isfile() or not member.name.startswith(root + "/"):
                continue
            relative = member.name[len(root) + 1 :]
            if "/" in relative:
                continue
            if Path(relative).name.lower().startswith(prefixes):
                legal.append((relative, tf.extractfile(member).read()))
        return cargo_data, legal


def package_toml_from_source(path: Path) -> tuple[bytes, list[tuple[str, bytes]]]:
    cargo_data = (path / "Cargo.toml").read_bytes()
    legal = []
    for entry in sorted(path.iterdir()):
        if entry.is_file() and entry.name.lower().startswith(("license", "notice", "copying")):
            legal.append((entry.name, entry.read_bytes()))
    return cargo_data, legal


def main() -> None:
    lock_bytes = LOCK.read_bytes()
    bundle_bytes = BUNDLE.read_bytes()
    lock = tomllib.loads(lock_bytes.decode("utf-8"))
    bundle = json.loads(bundle_bytes)
    bundled = {
        (c.get("name"), c.get("version"), c.get("crate_checksum_sha256"))
        for c in bundle["components"]
    }
    registry_packages = [
        p for p in lock["package"] if p.get("source", "").startswith("registry+")
    ]
    selected = [
        p for p in registry_packages
        if (p["name"], p["version"], p.get("checksum")) not in bundled
    ]

    TEXT_ROOT.mkdir(parents=True, exist_ok=True)
    records = []
    unresolved = []
    for p in sorted(selected, key=lambda p: (p["name"], p["version"])):
        name, version, checksum = p["name"], p["version"], p.get("checksum")
        record = {
            "name": name,
            "version": version,
            "source": p.get("source"),
            "root_lock_checksum_sha256": checksum,
            "archive": None,
            "archive_checksum_match": False,
            "cargo_toml": None,
            "root_legal_files": [],
            "status": "unresolved",
            "unresolved": [],
        }
        archive = next((x for x in archive_candidates(name, version) if x.is_file()), None)
        source_dir = next((x for x in local_source_candidates(name, version) if x.is_dir()), None)
        cargo_data = None
        legal_data = None
        source_kind = None
        if archive:
            archive_hash = digest_file(archive)
            record["archive"] = {
                "path": str(archive),
                "bytes": archive.stat().st_size,
                "sha256": archive_hash,
                "expected_lock_sha256": checksum,
            }
            record["archive_checksum_match"] = archive_hash == checksum
            if record["archive_checksum_match"]:
                source_kind = "verified_registry_archive"
                try:
                    cargo_data, legal_data = package_toml_from_tar(archive)
                except Exception as e:  # retain bounded evidence and report parsing gaps
                    record["unresolved"].append(f"verified archive could not be inspected: {type(e).__name__}: {e}")
            else:
                record["unresolved"].append("local archive SHA-256 does not match root Cargo.lock checksum")
        elif source_dir:
            source_kind = "corrected_source_tree_unverified_archive"
            record["source_tree"] = {"path": str(source_dir)}
            try:
                cargo_data, legal_data = package_toml_from_source(source_dir)
            except Exception as e:
                record["unresolved"].append(f"corrected source tree could not be inspected: {type(e).__name__}: {e}")
            record["unresolved"].append("no exact local crate archive was available to verify the root lock checksum")
        else:
            record["unresolved"].append("no exact local crate archive or corrected source tree found")

        if cargo_data is not None:
            try:
                cargo_toml = tomllib.loads(cargo_data.decode("utf-8"))
                package = cargo_toml.get("package", {})
                fields = {key: package.get(key) for key in ("name", "version", "license", "repository", "rust-version")}
                record["cargo_toml"] = {
                    "source_kind": source_kind,
                    "archive_member": f"{name}-{version}/Cargo.toml" if source_kind == "verified_registry_archive" else "Cargo.toml",
                    "bytes": len(cargo_data),
                    "sha256": sha256(cargo_data),
                    "literal_package_fields": fields,
                }
                if fields["name"] != name or fields["version"] != version:
                    record["unresolved"].append("Cargo.toml package identity differs from root lock identity")
            except Exception as e:
                record["unresolved"].append(f"Cargo.toml was not parseable as UTF-8 TOML: {type(e).__name__}: {e}")

        if legal_data is not None:
            package_dir = TEXT_ROOT / f"{name}-{version}"
            for member, content in sorted(legal_data, key=lambda item: item[0].lower()):
                destination = package_dir / member
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(content)
                try:
                    content_text = content.decode("utf-8")
                    text_encoding = "utf-8"
                except UnicodeDecodeError:
                    content_text = None
                    text_encoding = None
                record["root_legal_files"].append({
                    "archive_member": f"{name}-{version}/{member}" if source_kind == "verified_registry_archive" else member,
                    "bytes": len(content),
                    "sha256": sha256(content),
                    "text_path": str(destination),
                    "utf8": text_encoding is not None,
                    "text": content_text,
                })
            if not legal_data:
                record["unresolved"].append("verified package/source contains no root LICENSE*/NOTICE*/COPYING* member")

        if record["archive_checksum_match"] and record["cargo_toml"] is not None and not record["unresolved"]:
            record["status"] = "complete"
        else:
            unresolved.append({"name": name, "version": version, "reasons": record["unresolved"]})
        records.append(record)

    report = {
        "schema": "shardloom-registry-notice-inventory-r1",
        "scope": "Root Cargo.lock registry package identities absent from python/THIRD_PARTY_LICENSES/manifest.json; archive-sourced Cargo.toml fields and root legal notices only.",
        "read_only_inputs": {
            "repository": str(V),
            "root_cargo_lock": {"path": str(LOCK), "bytes": len(lock_bytes), "sha256": sha256(lock_bytes)},
            "existing_license_manifest": {"path": str(BUNDLE), "bytes": len(bundle_bytes), "sha256": sha256(bundle_bytes)},
            "corrected_source_inventory": str(CORRECTED),
            "cargo_registry_cache": str(CARGO_CACHE),
        },
        "coverage": {
            "root_registry_package_identities": len(registry_packages),
            "already_present_in_license_manifest": len(registry_packages) - len(selected),
            "selected_missing_identities": len(selected),
            "selected_archive_checksum_verified": sum(r["archive_checksum_match"] for r in records),
            "selected_cargo_toml_extracted": sum(r["cargo_toml"] is not None for r in records),
            "selected_with_root_legal_files": sum(bool(r["root_legal_files"]) for r in records),
            "root_legal_file_count": sum(len(r["root_legal_files"]) for r in records),
            "selected_complete": sum(r["status"] == "complete" for r in records),
            "selected_unresolved": len(unresolved),
            "selected_identity_rule": "exact (name, version, root Cargo.lock checksum) comparison against manifest components (name, version, crate_checksum_sha256)",
        },
        "unresolved": unresolved,
        "packages": records,
        "limits": [
            "No network, Cargo command, build, test, or repository edit was performed.",
            "Cargo.toml license/repository/rust-version values are literal archive metadata only; this inventory makes no license-policy or compatibility decision.",
            "Missing legal-file members are reported as missing; no text was inferred or borrowed from another version.",
        ],
    }
    OUT_JSON.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# Registry notice inventory r1",
        "",
        "Read-only, local comparison of root registry package identities against the existing Python third-party license manifest. This is evidence for primary review, not a license-policy decision.",
        "",
        "## Inputs and coverage",
        "",
        f"- Root `Cargo.lock`: SHA-256 `{report['read_only_inputs']['root_cargo_lock']['sha256']}`.",
        f"- Existing `THIRD_PARTY_LICENSES/manifest.json`: SHA-256 `{report['read_only_inputs']['existing_license_manifest']['sha256']}`.",
        f"- Root registry identities: {len(registry_packages)}; exact identities already present: {len(registry_packages) - len(selected)}; selected missing identities: {len(selected)}.",
        f"- Exact local archives checksum-verified: {report['coverage']['selected_archive_checksum_verified']}/{len(selected)}; Cargo.toml metadata extracted: {report['coverage']['selected_cargo_toml_extracted']}/{len(selected)}.",
        f"- Root legal text found for {report['coverage']['selected_with_root_legal_files']}/{len(selected)} packages ({report['coverage']['root_legal_file_count']} files); {len(unresolved)} packages remain unresolved because their verified archives contain no root legal file.",
        "- Identity matching uses `(name, version, root lock checksum)` against `(name, version, crate_checksum_sha256)` in the old manifest.",
        "",
        "## Selected packages",
        "",
        "Each selected identity, expected checksum, local archive path/size/hash, literal Cargo.toml fields, and each root legal file's member path/size/hash/text path are fully recorded in the JSON. Root legal text copies are under `registry-notice-inventory-r1/<name>-<version>/`. No text from a different version is substituted.",
        "",
        "| Package | Version | Archive checksum | Cargo.toml license | Root legal files | Status |",
        "| --- | --- | --- | --- | ---: | --- |",
    ]
    for r in records:
        fields = r.get("cargo_toml", {}).get("literal_package_fields", {})
        license_value = fields.get("license") if fields else None
        lines.append(f"| `{r['name']}` | `{r['version']}` | {'match' if r['archive_checksum_match'] else 'unresolved'} | `{license_value if license_value is not None else 'missing'}` | {len(r['root_legal_files'])} | {r['status']} |")
    lines += ["", "## Unresolved", ""]
    if unresolved:
        for u in unresolved:
            lines.append(f"- `{u['name']} {u['version']}`: " + "; ".join(u["reasons"]))
    else:
        lines.append("None.")
    lines += [
        "",
        "## Scope limits",
        "",
        "- No network, Cargo command, build, test, or repository edit was performed.",
        "- Cargo.toml values are literal package metadata only; no license-policy or compatibility conclusion is made.",
        "- If a package archive lacks root legal files, the absence is recorded; no license content is inferred or copied from a different package version.",
        "",
    ]
    OUT_MD.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(report["coverage"], indent=2))
    print(f"unresolved: {len(unresolved)}; reports: {OUT_JSON}, {OUT_MD}")


if __name__ == "__main__":
    main()
