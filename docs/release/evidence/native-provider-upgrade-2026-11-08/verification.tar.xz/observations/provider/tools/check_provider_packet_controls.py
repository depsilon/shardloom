"""Exercise relocated replay and resealed corruptions of the portable evidence."""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists() and args.packet.is_dir()
names = {'acceptance.json', 'verification.tar.xz', 'verify.py', 'verify_sources.py', 'verify_standalone.py'}
assert {p.name for p in args.packet.iterdir()} == names
original = {name: (args.packet / name).read_bytes() for name in names}
report = json.loads(original['acceptance.json'])
assert sha(original['verification.tar.xz']) == report['archive_sha256']
source = {}
with tarfile.open(fileobj=io.BytesIO(original['verification.tar.xz']), mode='r:xz') as archive:
    assert archive.getnames() == [row['path'] for row in report['members']]
    for row, member in zip(report['members'], archive.getmembers(), strict=True):
        assert member.isfile()
        raw = archive.extractfile(member).read()
        assert identity(raw) == {key: row[key] for key in ('bytes', 'sha256')}
        source[member.name] = raw
args.output.mkdir()
results = []
cases = ['original', 'relocated_source_only', 'unsealed_archive_corruption',
         'native_failed', 'installed_skips', 'omitted_original_failure',
         'compiled_source_changed', 'provider_archive_changed', 'standalone_provider_omitted',
         'standalone_child_failed', 'source_drift', 'audit_policy_failed',
         'dependency_baseline_changed', 'required_stage_omitted', 'unsafe_archive_path']


def write_case(target, data, acceptance):
    with tarfile.open(target / 'verification.tar.xz', 'w:xz', preset=0) as archive:
        members = []
        for path, raw in sorted(data.items()):
            info = tarfile.TarInfo(path)
            info.mode, info.mtime, info.size = 0o644, 0, len(raw)
            archive.addfile(info, io.BytesIO(raw))
            members.append(dict(path=path, **identity(raw)))
    acceptance['members'] = members
    acceptance['archive_sha256'] = sha((target / 'verification.tar.xz').read_bytes())
    (target / 'acceptance.json').write_bytes(encoded(acceptance))


def mutate_json(data, path, change):
    value = json.loads(data[path])
    change(value)
    data[path] = encoded(value)


for case in cases:
    accepted = case in {'original', 'relocated_source_only'}
    with tempfile.TemporaryDirectory(prefix='provider-control-', dir=args.output) as temporary:
        target = Path(temporary)
        for name, raw in original.items():
            (target / name).write_bytes(raw)
        changes = []
        changed_report = copy.deepcopy(report)
        changed = source.copy()
        prefix = 'observations/provider/'
        native = prefix + next(c['receipt'] for c in report['checks'] if c['receipt'].startswith('provider-native-tests-'))
        installed = prefix + report['installed_report']
        if case == 'unsealed_archive_corruption':
            raw = bytearray(original['verification.tar.xz'])
            raw[-1] ^= 1
            (target / 'verification.tar.xz').write_bytes(raw)
        elif case == 'native_failed':
            mutate_json(changed, native, lambda x: x.update(status='failed', returncode=1))
        elif case == 'installed_skips':
            mutate_json(changed, installed, lambda x: x['integration'].update(skipped=1))
            path = str(Path(installed).parent / 'integration.json')
            mutate_json(changed, path, lambda x: x.update(skipped=1))
            changed_report['installed_package']['skipped'] = 1
        elif case == 'omitted_original_failure':
            omitted = report['original_observations'][0]['path']
            del changed[prefix + omitted]
            changed_report['original_observations'] = [p for p in report['original_observations'] if p['path'] != omitted]
        elif case == 'compiled_source_changed':
            item = report['validation_source_snapshot']['shardloom-vortex/src/native_provider_decimal.rs']
            changed['source-blobs/' + item['sha256']] += b'\n// changed after validation\n'
        elif case == 'provider_archive_changed':
            path = next(path for path in sorted(source) if path.startswith('crate-blobs/'))
            changed[path] = changed[path][:-1] + bytes([changed[path][-1] ^ 1])
        elif case == 'standalone_provider_omitted':
            mutate_json(changed, prefix + report['standalone_acceptance'], lambda x: x['providers'].pop())
        elif case == 'standalone_child_failed':
            standalone = json.loads(source[prefix + report['standalone_acceptance']])
            path = prefix + standalone['providers'][0]['child_report']
            mutate_json(changed, path, lambda x: x['commands'][0].update(returncode=1))
        elif case == 'source_drift':
            mutate_json(changed, native, lambda x: x['build_source_verification']['post_execution'].update(changed_paths=['Cargo.lock']))
        elif case == 'audit_policy_failed':
            mutate_json(changed, prefix + report['audit_report'], lambda x: x.update(license_policy_status='failed'))
            changed_report['audit_report_sha256'] = sha(changed[prefix + report['audit_report']])
        elif case == 'dependency_baseline_changed':
            path = 'dependency-baseline/acceptance.json'
            mutate_json(changed, path, lambda x: x['code_snapshot']['Cargo.toml'].update(sha256='0' * 64))
            changed_report['dependency_baseline_acceptance'] = identity(changed[path])
        elif case == 'required_stage_omitted':
            mutate_json(changed, prefix + report['validation_protocol'], lambda x: x['stages'].pop())
        elif case == 'unsafe_archive_path':
            changed['../untrusted.json'] = b'{}\n'
        if not accepted and case != 'unsealed_archive_corruption':
            for path in sorted(source.keys() | changed.keys()):
                if source.get(path) != changed.get(path):
                    changes.append(dict(path=path,
                        before=identity(source[path]) if path in source else None,
                        after=identity(changed[path]) if path in changed else None))
            write_case(target, changed, changed_report)
        run_target = args.packet if case == 'original' else target
        command = [sys.executable, '-B', str(run_target / 'verify.py')]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180, check=False)
        log = args.output / (case + '.log')
        log.write_bytes(result.stdout)
        assert (result.returncode == 0) == accepted, (case, result.returncode, result.stdout[-2000:])
        if accepted:
            assert json.loads(result.stdout)['status'] == 'passed'
        else:
            assert b'AssertionError' in result.stdout or b'KeyError' in result.stdout
        results.append(dict(case=case, expected='accepted' if accepted else 'rejected', returncode=result.returncode,
            log=log.name, log_identity=identity(result.stdout), mutations=changes,
            tested_packet={name: identity((run_target / name).read_bytes()) for name in sorted(names)},
            original_packet_unchanged=all((args.packet / name).read_bytes() == raw for name, raw in original.items())))
        assert results[-1]['original_packet_unchanged']
        print(json.dumps(dict(case=case, outcome='accepted' if accepted else 'rejected')), flush=True)
assert all((args.packet / name).read_bytes() == raw for name, raw in original.items())
receipt = dict(status='passed', cases=results, positive_controls=2, rejected_controls=len(cases) - 2,
    original_packet={name: identity(raw) for name, raw in sorted(original.items())},
    driver_sha256=sha(Path(__file__).read_bytes()),
    scope='Actual subprocess replay of copied portable evidence; negative archives resealed except the explicit checksum control. Temporary mutated payloads retired after observations; sources and original evidence unchanged.')
(args.output / 'receipt.json').write_bytes(encoded(receipt))
print(json.dumps(dict(status='passed', positive_controls=2, rejected_controls=len(cases) - 2)))
