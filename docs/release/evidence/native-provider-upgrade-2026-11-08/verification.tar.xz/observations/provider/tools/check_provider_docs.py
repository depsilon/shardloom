"""Check generated source identities, provider notices and validation wiring."""
import argparse
import subprocess
import sys
from pathlib import Path

N = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--revision', default='r1')
args = parser.parse_args()
assert args.revision.isalnum()
def output(name):
    path = N / f'{name}-{args.revision}.json'
    assert not path.exists(), path
    return str(path)
checks = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', output('public-status-docs')],
    ['scripts/check_contribution_governance.py', '--output', output('contribution-governance')],
    ['scripts/check_ci_gate_matrix.py', '--output', output('ci-gate-matrix')],
    ['scripts/check_python_license_bundle.py'],
    ['-m', 'unittest', '-v', 'scripts.test_python_license_bundle',
     'scripts.test_ci_provider_tests', 'python.tests.test_public_api_reference'],
]
for arguments in checks:
    print('Checking ' + ' '.join(arguments), flush=True)
    subprocess.run([sys.executable, '-B', *arguments], check=True, timeout=120)
