"""Independently bind the complete provider collection to registry and archive bytes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
COLLECTION = OUT / 'source-collection-r1/corrected'
manifest_path = COLLECTION / 'manifest.json'
raw_manifest = manifest_path.read_bytes()
manifest = json.loads(raw_manifest)
digest = lambda raw: hashlib.sha256(raw).hexdigest()
vortex = {'vortex', 'vortex-compressor', 'vortex-array', 'vortex-buffer',
          'vortex-datetime-parts', 'vortex-file', 'vortex-fsst', 'vortex-io',
          'vortex-layout', 'vortex-zstd'}
arrow = {'arrow-array', 'arrow-avro', 'arrow-buffer', 'arrow-data', 'arrow-flight',
         'arrow-ipc', 'arrow-pyarrow', 'arrow-schema', 'parquet'}
expected = {('candidate', name, '0.93.0') for name in vortex}
expected |= {('candidate', name, '59.3.2') for name in arrow}
expected |= {('baseline', name, '0.90.0')
             for name in (vortex - {'vortex', 'vortex-compressor'}) | {'vortex-runend'}}
expected |= {('baseline', name, '59.3.1')
             for name in {'arrow-array', 'arrow-avro', 'arrow-ipc', 'parquet'}}
observed = {(row['role'], row['name'], row['version']) for row in manifest['results']}
assert observed == expected and len(manifest['results']) == len(expected) == 32
records = []
for row in manifest['results']:
    role, name, version = row['role'], row['name'], row['version']
    assert row['status'] == 'passed'
    pair = COLLECTION / role / f'{name}-{version}'
    api_path = pair / 'crates-io-response.bin'
    api_raw = api_path.read_bytes()
    api = json.loads(api_raw)['version']
    assert (api['crate'], api['num'], api['yanked']) == (name, version, False)
    assert row['api']['url'] == f'https://crates.io/api/v1/crates/{name}/{version}'
    assert row['api']['http_status'] == 200 and row['api']['error'] is None
    assert row['api']['raw_response'] == api_path.relative_to(COLLECTION).as_posix()
    archive_path = pair / f'{name}-{version}.crate'
    archive_raw = archive_path.read_bytes()
    assert len(archive_raw) == row['archive']['bytes'] < 32 << 20
    assert digest(archive_raw) == row['archive']['sha256'] == api['checksum']
    assert row['archive']['path'] == archive_path.relative_to(COLLECTION).as_posix()
    source = pair / 'source'
    seen, members, originals = set(), [], {}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for entry in archive:
            parts = entry.name.split('/')
            assert parts[0] == f'{name}-{version}' and len(parts) > 1
            assert not any(part in ('', '.', '..') for part in parts)
            assert not PurePosixPath(entry.name).is_absolute()
            assert entry.name not in seen
            seen.add(entry.name)
            path = source / entry.name
            assert not path.is_symlink()
            assert path.resolve().is_relative_to(source.resolve())
            if entry.isdir():
                assert entry.size == 0 and path.is_dir()
                members.append(dict(path=entry.name, type='directory', bytes=0, sha256=None))
            else:
                assert entry.isfile() and 0 <= entry.size < 256 << 20
                data = archive.extractfile(entry).read()
                assert len(data) == entry.size and path.read_bytes() == data
                sha = digest(data)
                members.append(dict(path=entry.name, type='file', bytes=len(data), sha256=sha))
                originals['/'.join(parts[1:])] = sha
    inv = row['source_inventory']
    assert members == inv['members'] and len(members) == inv['member_count']
    assert sum(m['bytes'] for m in members) == inv['uncompressed_bytes'] < 256 << 20
    assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == {
        m['path'] for m in members if m['type'] == 'file'}
    package_root = source / f'{name}-{version}'
    package = tomllib.loads((package_root / 'Cargo.toml').read_text())['package']
    assert (package['name'], package['version']) == (name, version)
    assert package['license'] == api['license'] and api['license'] in {'Apache-2.0', 'Apache-2.0 AND MIT'}
    vcs_path = package_root / '.cargo_vcs_info.json'
    vcs = json.loads(vcs_path.read_bytes()) if vcs_path.exists() else None
    if role == 'baseline':
        provenance = json.loads((ROOT / 'vendor' / name / 'upstream-provenance.json').read_bytes())
        assert provenance['registry_archive_sha256'] == digest(archive_raw)
        assert provenance['original_files_sha256'] == originals
        assert provenance['registry_archive_file_count'] == len(originals)
    records.append(dict(role=role, name=name, version=version,
        archive_sha256=digest(archive_raw), api_sha256=digest(api_raw),
        members=len(members), license=api['license'], vcs=vcs))
result = dict(status='passed', manifest_sha256=digest(raw_manifest),
              verifier_sha256=digest(Path(__file__).read_bytes()),
              archive_count=len(records), member_count=sum(r['members'] for r in records),
              records=records)
output = OUT / 'source-collection-primary-verification-r1.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'records'}, indent=2))
