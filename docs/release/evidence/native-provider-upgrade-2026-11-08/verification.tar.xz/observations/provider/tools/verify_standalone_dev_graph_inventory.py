"""Build or verify the read-only comparison of standalone provider locks with Cargo.lock."""
import argparse
from collections import defaultdict
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import tomllib


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(package):
    return (package['name'], package['version'], package.get('source'), package.get('checksum'))


def identity_record(key):
    return {'name': key[0], 'version': key[1], 'source': key[2], 'checksum': key[3]}


def package_manifest_metadata(raw):
    data = tomllib.loads(raw.decode('utf-8'))
    package = data.get('package', {})
    return {key: package.get(key) for key in ('name', 'version', 'license', 'license-file', 'rust-version')}


def is_legal_member(path):
    name = PurePosixPath(path).name.lower()
    return any(token in name for token in ('license', 'licence', 'notice', 'copying', 'copyright', 'patent'))


def describe_local_file(path, inputs, kind):
    path = Path(path)
    if path.is_symlink():
        target = os.readlink(path)
        entry = {'path': str(path), 'kind': kind, 'state': 'symlink', 'target': target,
                 'target_sha256': sha256(os.fsencode(target))}
    elif path.is_file():
        raw = path.read_bytes()
        entry = {'path': str(path), 'kind': kind, 'state': 'present',
                 'sha256': sha256(raw), 'bytes': len(raw)}
    else:
        entry = {'path': str(path), 'kind': kind, 'state': 'missing'}
    inputs[str(path)] = entry
    return entry


def registry_indexes(cargo_home, kind):
    directory = cargo_home / 'registry' / kind
    if not directory.is_dir():
        return []
    return sorted((item for item in directory.iterdir() if item.is_dir()),
                  key=lambda item: item.name)


def inspect_archive(archive_path, package_name, version, lock_checksum, inputs):
    archive_input = describe_local_file(archive_path, inputs, 'registry_archive')
    result = {'archive': archive_input, 'checksum_matches_lock': None, 'legal_file_members': [],
              'declared_metadata': None, 'metadata_member': None, 'member_errors': []}
    if archive_input['state'] != 'present':
        return result
    result['checksum_matches_lock'] = (archive_input['sha256'] == lock_checksum) if lock_checksum else None
    crate_root = f'{package_name}-{version}'
    try:
        with tarfile.open(archive_path, 'r:gz') as archive:
            for member in archive.getmembers():
                parts = PurePosixPath(member.name.replace('\\', '/')).parts
                if not parts or parts[0] != crate_root or '..' in parts:
                    result['member_errors'].append({'path': member.name, 'error': 'unexpected archive path'})
                    continue
                relative = '/'.join(parts[1:])
                if not member.isfile():
                    continue
                stream = archive.extractfile(member)
                if stream is None:
                    result['member_errors'].append({'path': member.name, 'error': 'member data unavailable'})
                    continue
                raw = stream.read()
                if relative == 'Cargo.toml':
                    result['metadata_member'] = member.name
                    result['declared_metadata'] = package_manifest_metadata(raw)
                if is_legal_member(relative):
                    result['legal_file_members'].append({'path': member.name, 'bytes': len(raw),
                                                          'sha256': sha256(raw)})
    except (OSError, tarfile.TarError) as error:
        result['member_errors'].append({'path': str(archive_path), 'error': type(error).__name__ + ': ' + str(error)})
    result['legal_file_members'].sort(key=lambda item: item['path'])
    return result


def inspect_source_tree(source_dir, package_name, version, inputs):
    manifest_path = source_dir / 'Cargo.toml'
    manifest = describe_local_file(manifest_path, inputs, 'registry_manifest')
    if manifest['state'] == 'present':
        raw = manifest_path.read_bytes()
        try:
            metadata = package_manifest_metadata(raw)
        except (UnicodeDecodeError, tomllib.TOMLDecodeError) as error:
            metadata = {'parse_error': type(error).__name__ + ': ' + str(error)}
    else:
        metadata = None
    legal_files = []
    symlinks = []
    if source_dir.is_dir() and not source_dir.is_symlink():
        for path in sorted(source_dir.rglob('*')):
            relative = path.relative_to(source_dir).as_posix()
            if path.is_symlink():
                symlinks.append({'path': str(path), 'target': os.readlink(path)})
            elif path.is_file() and is_legal_member(relative):
                raw = path.read_bytes()
                describe_local_file(path, inputs, 'registry_legal_source_file')
                legal_files.append({'path': relative, 'bytes': len(raw), 'sha256': sha256(raw)})
    return {'manifest': manifest, 'declared_metadata': metadata,
            'legal_files': legal_files, 'symlinks': symlinks}


def build_inventory(root, cargo_home):
    root = Path(root).resolve(strict=True)
    cargo_home = Path(cargo_home).resolve(strict=False)
    root_lock_path = root / 'Cargo.lock'
    provider_lock_paths = sorted((root / '.github' / 'provider-locks').glob('*.lock'))
    if not root_lock_path.is_file() or root_lock_path.is_symlink():
        raise RuntimeError(f'root Cargo.lock missing or symlinked: {root_lock_path}')

    lock_contents = {}
    inputs = {}
    for path, kind in [(root_lock_path, 'root_cargo_lock')] + [(p, 'provider_lock') for p in provider_lock_paths]:
        entry = describe_local_file(path, inputs, kind)
        if entry['state'] != 'present':
            raise RuntimeError(f'required lockfile missing or symlinked: {path}')
        lock_contents[str(path)] = tomllib.loads(path.read_text(encoding='utf-8'))
    root_packages = {identity(package) for package in lock_contents[str(root_lock_path)]['package']}
    occurrences = defaultdict(set)
    for path in provider_lock_paths:
        for package in lock_contents[str(path)]['package']:
            key = identity(package)
            if key not in root_packages:
                occurrences[key].add(str(path))

    source_indexes = registry_indexes(cargo_home, 'src')
    cache_indexes = registry_indexes(cargo_home, 'cache')
    source_index_names = {path.name for path in source_indexes}
    cache_index_names = {path.name for path in cache_indexes}
    registry_index_names = sorted(source_index_names | cache_index_names)
    package_records = []
    for key, lock_paths in sorted(occurrences.items()):
        name, version, source, checksum = key
        base = f'{name}-{version}'
        candidates = []
        for index_name in registry_index_names:
            source_dir = cargo_home / 'registry' / 'src' / index_name / base
            archive_path = cargo_home / 'registry' / 'cache' / index_name / f'{base}.crate'
            source_info = inspect_source_tree(source_dir, name, version, inputs)
            archive_info = inspect_archive(archive_path, name, version, checksum, inputs)
            candidates.append({'registry_index': index_name,
                'source_index_present': index_name in source_index_names,
                'cache_index_present': index_name in cache_index_names,
                'manifest': source_info['manifest'], 'declared_metadata_from_manifest': source_info['declared_metadata'],
                'archive': archive_info['archive'], 'archive_checksum_matches_lock': archive_info['checksum_matches_lock'],
                'declared_metadata_from_archive': archive_info['declared_metadata'],
                'archive_manifest_member': archive_info['metadata_member'],
                'archive_legal_file_members': archive_info['legal_file_members'],
                'source_tree_legal_files': source_info['legal_files'],
                'source_tree_symlinks': source_info['symlinks'], 'archive_member_errors': archive_info['member_errors']})
        if registry_index_names:
            present_archives = [candidate for candidate in candidates
                                if candidate['archive']['state'] == 'present']
            present_manifests = [candidate for candidate in candidates
                                 if candidate['manifest']['state'] == 'present']
            if any(candidate['archive_checksum_matches_lock'] for candidate in present_archives):
                status = 'matching_registry_archive_present'
            elif present_archives:
                status = 'registry_archive_present_but_checksum_differs_or_is_unavailable'
            elif present_manifests:
                status = 'registry_manifest_present_archive_missing'
            else:
                status = 'exact_registry_source_missing_from_local_cache'
        else:
            status = 'no_local_registry_source_index'
        package_records.append({**identity_record(key), 'used_in_provider_locks': sorted(lock_paths),
            'registry_lookup_candidates_checked': [
                {'manifest_path': str(cargo_home / 'registry' / 'src' / index_name / base / 'Cargo.toml'),
                 'archive_path': str(cargo_home / 'registry' / 'cache' / index_name / f'{base}.crate')}
                for index_name in registry_index_names],
            'local_registry_status': status, 'local_registry_candidates': candidates})

    # Re-read every actual input and ensure absent cache candidates did not appear while scanning.
    input_changes = []
    for path_string, expected in sorted(inputs.items()):
        path = Path(path_string)
        if expected['state'] == 'present':
            raw = path.read_bytes() if path.is_file() and not path.is_symlink() else None
            current = {'state': 'present', 'sha256': sha256(raw), 'bytes': len(raw)} if raw is not None else {'state': 'missing'}
        elif expected['state'] == 'symlink':
            current = {'state': 'symlink', 'target': os.readlink(path)} if path.is_symlink() else {'state': 'missing'}
        else:
            current = {'state': 'present'} if path.exists() else {'state': 'missing'}
        normalized = {key: value for key, value in expected.items() if key != 'kind' and key != 'path'}
        if expected['state'] == 'present':
            normalized = {'state': 'present', 'sha256': expected['sha256'], 'bytes': expected['bytes']}
        elif expected['state'] == 'symlink':
            normalized = {'state': 'symlink', 'target': expected['target']}
        else:
            normalized = {'state': 'missing'}
        if current != normalized:
            input_changes.append({'path': path_string, 'before': normalized, 'after': current})
    if input_changes:
        raise RuntimeError(f'inputs changed during inventory scan: {input_changes[:10]}')
    if ([path.name for path in registry_indexes(cargo_home, 'src')] != [path.name for path in source_indexes] or
            [path.name for path in registry_indexes(cargo_home, 'cache')] != [path.name for path in cache_indexes]):
        raise RuntimeError('local Cargo registry index directories changed during inventory scan')

    provider_lock_hashes = [inputs[str(path)] for path in provider_lock_paths]
    body = {'title': 'Standalone provider development graph versus root lock inventory',
        'repository': str(root), 'cargo_home': str(cargo_home),
        'comparison': 'Exact (name, version, source, checksum) identity tuples in .github/provider-locks/*.lock absent from root Cargo.lock.',
        'root_lockfile': inputs[str(root_lock_path)],
        'provider_lockfiles': provider_lock_hashes,
        'input_inventory': [inputs[path] for path in sorted(inputs)],
        'registry_search': {'source_indexes': [str(path) for path in source_indexes],
            'cache_indexes': [str(path) for path in cache_indexes],
            'network_access': False, 'cargo_invoked': False},
        'local_manifest_and_archive_inputs': [inputs[path] for path in sorted(inputs)
            if inputs[path]['kind'] in {'registry_manifest', 'registry_archive'}],
        'missing_local_candidates': [inputs[path] for path in sorted(inputs)
            if inputs[path]['state'] == 'missing' and inputs[path]['kind'] in {'registry_manifest', 'registry_archive'}],
        'packages_absent_from_root': package_records}
    body['summary'] = {'provider_lock_count': len(provider_lock_paths),
        'unique_exact_package_identities_absent_from_root': len(package_records),
        'matching_local_registry_archives': sum(p['local_registry_status'] == 'matching_registry_archive_present' for p in package_records),
        'registry_manifest_only': sum(p['local_registry_status'] == 'registry_manifest_present_archive_missing' for p in package_records),
        'exact_local_registry_source_missing': sum(p['local_registry_status'] == 'exact_registry_source_missing_from_local_cache' for p in package_records),
        'other_local_cache_states': sum(p['local_registry_status'] not in {'matching_registry_archive_present', 'registry_manifest_present_archive_missing', 'exact_registry_source_missing_from_local_cache'} for p in package_records)}
    body['input_fingerprint_sha256'] = sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode())
    return body


def markdown_report(inventory):
    summary = inventory['summary']
    lines = ['# Standalone provider development graph inventory', '',
        f'- Repository: `{inventory["repository"]}`',
        f'- Root Cargo.lock SHA-256: `{inventory["root_lockfile"]["sha256"]}`',
        f'- Provider lockfiles included and hashed: {summary["provider_lock_count"]}',
        f'- Exact package identities absent from root: {summary["unique_exact_package_identities_absent_from_root"]}',
        f'- Matching local registry archives: {summary["matching_local_registry_archives"]}',
        f'- Manifest present, archive missing: {summary["registry_manifest_only"]}',
        f'- Exact local registry source missing: {summary["exact_local_registry_source_missing"]}',
        f'- Input fingerprint: `{inventory["input_fingerprint_sha256"]}`', '',
        'The JSON inventory lists each exact name/version/source/checksum tuple, provider lock uses, local manifest/archive paths and hashes, declared license/license-file/rust-version values, and legal archive member hashes. Missing local sources are explicit. No downloads, Cargo commands, builds, or repository writes were used.', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--cargo-home', type=Path,
        default=Path(os.environ.get('CARGO_HOME', str(Path.home() / '.cargo'))))
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write', type=Path, help='write deterministic JSON and companion Markdown outside the repo')
    mode.add_argument('--verify', type=Path, help='compare recomputed inventory with an existing JSON file')
    args = parser.parse_args()
    inventory = build_inventory(args.root, args.cargo_home)
    if args.write:
        output = args.write.resolve(strict=False)
        root = args.root.resolve(strict=True)
        if output == root or output.is_relative_to(root):
            parser.error('--write must target a path outside the repository')
        if output.exists() or output.is_symlink() or output.with_suffix('.md').exists() or output.with_suffix('.md').is_symlink():
            parser.error('--write JSON and companion Markdown paths must be new')
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        output.with_suffix('.md').write_text(markdown_report(inventory), encoding='utf-8')
        print(json.dumps({'status': 'written', 'json': str(output), 'markdown': str(output.with_suffix('.md')),
                          'summary': inventory['summary'], 'input_fingerprint_sha256': inventory['input_fingerprint_sha256']}, indent=2))
        return
    expected = json.loads(args.verify.read_text(encoding='utf-8'))
    if expected == inventory:
        print(json.dumps({'status': 'passed', 'input_fingerprint_sha256': inventory['input_fingerprint_sha256'],
                          'summary': inventory['summary']}, indent=2))
        return
    print(json.dumps({'status': 'mismatch', 'expected_fingerprint': expected.get('input_fingerprint_sha256'),
        'actual_fingerprint': inventory['input_fingerprint_sha256'],
        'expected_provider_lock_hashes': expected.get('provider_lockfiles'),
        'actual_provider_lock_hashes': inventory.get('provider_lockfiles')}, indent=2))
    raise SystemExit(1)


if __name__ == '__main__':
    main()
