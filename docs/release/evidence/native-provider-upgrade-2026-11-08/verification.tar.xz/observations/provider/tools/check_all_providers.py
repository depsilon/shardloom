"""Run every reviewed standalone provider configuration sequentially."""
import subprocess
import sys
from pathlib import Path

N = Path(__file__).resolve().parent.parent
for group in ('arrays', 'io', 'buffer', 'formats'):
    subprocess.run([sys.executable, '-B', 'scripts/ci_provider_tests.py', '--group', group,
                    '--output', str(N / 'standalone-final-r1' / group)], check=True)
