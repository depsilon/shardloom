"""Run a fixed-source validation protocol through the existing bounded guard."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
N = Path(__file__).resolve().parent.parent
PYTHON = '/opt/homebrew/bin/python3.13'
parser = argparse.ArgumentParser()
parser.add_argument('protocol', type=Path)
args = parser.parse_args()
raw = args.protocol.read_bytes()
protocol = json.loads(raw)
assert protocol['prepared_only'] is False
name = protocol['name']
assert name.replace('-', '').isalnum()
receipt = N / (name + '.json')
assert not receipt.exists()
for relative, expected in protocol['requires'].items():
    assert hashlib.sha256((N / relative).read_bytes()).hexdigest() == expected
state = dict(status='running', protocol=args.protocol.name,
             protocol_sha256=hashlib.sha256(raw).hexdigest(), completed=[], active_stage=None)
precompleted = protocol.get('precompleted', [])
assert precompleted == [entry['name'] for entry in protocol['stages'][:len(precompleted)]]

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for entry in protocol['stages']:
        stage_name = entry['name']
        state['active_stage'] = stage_name
        save()
        print('Starting ' + stage_name, flush=True)
        if stage_name not in precompleted:
            result = subprocess.run([PYTHON, '-B', str(N / 'tools/guard_provider_upgrade.py'),
                '--name', stage_name, '--timeout', str(entry['timeout']), '--', *entry['command']],
                cwd=V, check=False)
            assert result.returncode == 0, stage_name
        stage = json.loads((N / (stage_name + '.json')).read_bytes())
        assert stage['status'] == 'passed' and stage['returncode'] == 0, stage_name
        assert stage['process_group_drained'] and stage['direct_child_reaped'], stage_name
        assert stage['fixed_source_validation'] and stage['command'] == entry['command'], stage_name
        assert hashlib.sha256((N / (stage_name + '.log')).read_bytes()).hexdigest() == stage['log_sha256'], stage_name
        assert stage['head'] == protocol['head'], stage_name
        assert stage['build_source_fingerprint_sha256'] == protocol['build_source_fingerprint_sha256'], stage_name
        state['completed'].append(stage_name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
