"""Run selected reviewed provider configurations without altering CI coverage."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'scripts'))
import ci_provider_tests as providers

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('providers', nargs='+', choices=providers.CONFIGURATIONS)
args = parser.parse_args()
providers.GROUPS['selected'] = tuple(args.providers)
print(json.dumps(providers.run_group('selected', args.output, root=ROOT), indent=2))
