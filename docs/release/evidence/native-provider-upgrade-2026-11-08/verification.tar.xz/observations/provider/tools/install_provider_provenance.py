"""Verify final source mappings and bind current fixture/license provenance."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
P = N / 'provenance-refresh-proposal-r2'
OUT = N / 'provider-provenance-installation-r1.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = json.loads((P / 'comparison-report.json').read_text())
legal_receipt = json.loads((N / 'vortex-093-license-r1.json').read_text())
legal = legal_receipt['structuredContent']
legal_bytes = legal['content'].encode()
legal_commit = 'c1439e69bf833fc702a60335ed674a1674ca358d'
assert legal['display_url'] == f'https://github.com/vortex-data/vortex/blob/{legal_commit}/LICENSE'
assert legal['sha'] == hashlib.sha1(f'blob {len(legal_bytes)}\0'.encode() + legal_bytes).hexdigest()
assert sha(legal_bytes) == 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'
pending = []
records = []
for item in report['providers']:
    name = item['provider']
    root = V / 'vendor' / name
    path = root / 'upstream-provenance.json'
    old = path.read_bytes()
    assert sha(old) == item['current_provenance_sha256']
    assert not item['archive_manifest_comparison']['mismatches']
    assert not item['unknown_extras_without_inferred_provenance']
    data = json.loads((P / 'proposed' / name / path.name).read_text())
    original = data['original_files_sha256']
    modified = data['modified_files_sha256']
    added = data['added_files_sha256']
    expected = {k: v for k, v in original.items() if k not in data['omitted_files']}
    expected.update(modified)
    expected.update(added)
    assert expected == item['final_provider_files_sha256']
    for relative, digest in expected.items():
        target = root / relative
        assert target.is_file() and not target.is_symlink() and sha(target.read_bytes()) == digest
    for relative in modified:
        if relative.endswith('.rs'):
            head = '\n'.join((root / relative).read_text().splitlines()[:35])
            assert re.search(r'(?im)^//.*(?:modified by ShardLoom|ShardLoom modification)', head), relative
    if name.startswith('vortex-'):
        assert data['license'] == 'Apache-2.0' and data['vcs_info']['git']['sha1'] == legal_commit
        assert (root / 'LICENSE').read_bytes() == legal_bytes
        data['license_url'] = legal['display_url']
        data['license_git_blob_sha1'] = legal['sha']
    else:
        assert all(row['status'] == 'verified_exact_member_bytes' for row in item['legal_url_bindings'])
    bindings = []
    for relative, fixture in data.get('supplemental_test_files', {}).items():
        current = (root / relative).read_bytes()
        assert sha(current) == fixture.get('current_sha256', fixture['sha256'])
        assert len(current) == fixture.get('current_bytes', fixture['bytes'])
        if fixture.get('current_sha256') is None:
            assert hashlib.sha1(f'blob {len(current)}\0'.encode() + current).hexdigest() == fixture['git_blob_sha1']
        source = fixture.get('test_source')
        if source:
            current_source = (root / source).read_bytes()
            archived = original[source]
            fixture['test_source_sha256'] = archived
            fixture['test_source_published_archive_sha256'] = archived
            fixture['test_source_candidate_archive_sha256'] = archived
            fixture['test_source_current_sha256'] = sha(current_source)
            fixture['test_source_matches_published_archive'] = sha(current_source) == archived
            fixture['test_source_matches_candidate_archive'] = sha(current_source) == archived
            if module := fixture.get('retained_test_module'):
                marker = module['marker'].encode()
                start = current_source.index(marker)
                tail = current_source[start:]
                archive_path = N / 'source-collection-r1/corrected' / item['archive']['path']
                with tarfile.open(archive_path, 'r:gz') as archive:
                    archive_source = archive.extractfile(f'{name}-{data["version"]}/{source}').read()
                assert sha(archive_source) == archived
                archive_tail = archive_source[archive_source.index(marker):]
                assert tail == archive_tail, source
                if len(tail) != module['bytes'] or sha(tail) != module['sha256']:
                    fixture['predecessor_retained_test_module'] = dict(module)
                fixture['retained_test_module'] = dict(marker=module['marker'],
                    bytes=len(tail), sha256=sha(tail), matches_published_archive=True)
            bindings.append({'fixture': relative, 'test_source': source,
                             'archive_sha256': archived, 'current_sha256': sha(current_source)})
    data['migration_status'] = 'retained_local_contract_port'
    output = (json.dumps(data, indent=2) + '\n').encode()
    pending.append((path, output))
    records.append({'provider': name, 'version': data['version'], 'source_files': len(expected),
                    'original_files': len(original), 'modified_files': len(modified),
                    'added_files': len(added), 'fixture_bindings': bindings,
                    'before_sha256': sha(old), 'after_sha256': sha(output)})

# No provider file is updated until every proposed mapping has passed.
for path, raw in pending:
    path.write_bytes(raw)
    assert path.read_bytes() == raw
OUT.write_text(json.dumps({'status': 'verified_and_installed_source_provenance',
    'validation_scope': 'Source/license/fixture identity, not whole-engine acceptance.',
    'comparison_report_sha256': sha((P / 'comparison-report.json').read_bytes()),
    'official_license_receipt_sha256': sha((N / 'vortex-093-license-r1.json').read_bytes()),
    'providers': records}, indent=2) + '\n')
print(json.dumps({'status': 'verified_and_installed_source_provenance', 'providers': len(records)}))
