#!/usr/bin/env python3
"""Prepare a scratch-only replacement registry-notice manifest from verified local crates."""

from __future__ import annotations

import copy
import hashlib
import json
import tarfile
import tomllib
from pathlib import Path


V = Path("/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo")
N = Path("/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08")
LOCK = V / "Cargo.lock"
BUNDLE = V / "python/THIRD_PARTY_LICENSES/manifest.json"
CORRECTED = N / "source-collection-r1/corrected"
CACHE = Path.home() / ".cargo/registry/cache/index.crates.io-1949cf8c6b5b557f"
LICENSE_RESPONSE = N / "vortex-093-license-r1.json"
OUT = N / "registry-notice-proposal-r1"
EXPECTED_VORTEX_COMMIT = "c1439e69bf833fc702a60335ed674a1674ca358d"
EXPECTED_VORTEX_LICENSE_SHA256 = "cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30"
EXPECTED_VORTEX_LICENSE_GIT_BLOB = "d645695673349e3947e8e5ae42332d0ac3164cd7"
EXPECTED_VORTEX_LICENSE_URL = "https://github.com/vortex-data/vortex/blob/c1439e69bf833fc702a60335ed674a1674ca358d/LICENSE"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def canonical_component_bytes(component: dict) -> bytes:
    return json.dumps(component, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def archive_candidates(name: str, version: str) -> list[Path]:
    filename = f"{name}-{version}.crate"
    return [
        CACHE / filename,
        CORRECTED / "candidate" / f"{name}-{version}" / filename,
        CORRECTED / "baseline" / f"{name}-{version}" / filename,
    ]


def inspect_archive(path: Path, name: str, version: str) -> tuple[bytes, list[tuple[str, bytes]], dict | None, dict]:
    with tarfile.open(path, mode="r:gz") as tf:
        prefix = f"{name}-{version}/"
        cargo_members = [m for m in tf.getmembers() if m.isfile() and m.name == prefix + "Cargo.toml"]
        if len(cargo_members) != 1:
            raise ValueError(f"{name} {version}: expected one root Cargo.toml, found {len(cargo_members)}")
        cargo_data = tf.extractfile(cargo_members[0]).read()
        package = tomllib.loads(cargo_data.decode("utf-8")).get("package", {})
        package_fields = {key: package.get(key) for key in ("name", "version", "license", "repository", "rust-version")}

        legal = []
        for member in tf.getmembers():
            if not member.isfile() or not member.name.startswith(prefix):
                continue
            relative = member.name[len(prefix):]
            if "/" not in relative and relative.lower().startswith(("license", "notice", "copying")):
                legal.append((relative, tf.extractfile(member).read()))

        vcs_member = prefix + ".cargo_vcs_info.json"
        vcs_records = [m for m in tf.getmembers() if m.isfile() and m.name == vcs_member]
        vcs = None
        vcs_evidence = {"member": vcs_member, "present": len(vcs_records) == 1}
        if len(vcs_records) == 1:
            vcs_data = tf.extractfile(vcs_records[0]).read()
            vcs = json.loads(vcs_data)
            vcs_evidence.update({"bytes": len(vcs_data), "sha256": sha256(vcs_data), "literal": vcs})
        return cargo_data, legal, vcs, {
            "cargo_toml": {
                "archive_member": prefix + "Cargo.toml",
                "bytes": len(cargo_data),
                "sha256": sha256(cargo_data),
                "literal_package_fields": package_fields,
            },
            "root_legal_member_names": sorted(name for name, _ in legal),
            "vcs_info": vcs_evidence,
        }


def preflight() -> tuple[dict, dict, list[dict], list[dict], bytes]:
    lock_bytes = LOCK.read_bytes()
    manifest_bytes = BUNDLE.read_bytes()
    lock = tomllib.loads(lock_bytes.decode("utf-8"))
    existing = json.loads(manifest_bytes)
    registry = [p for p in lock["package"] if p.get("source", "").startswith("registry+")]
    identities = [(p["name"], p["version"], p.get("checksum")) for p in registry]
    if len(set(identities)) != len(identities):
        raise ValueError("root lock has duplicate registry package identities")
    bundled = existing["components"]
    old_by_identity = {}
    for component in bundled:
        key = (component.get("name"), component.get("version"), component.get("crate_checksum_sha256"))
        if key in old_by_identity:
            raise ValueError(f"old bundle has duplicate component identity {key}")
        old_by_identity[key] = component
    current = set(identities)
    unchanged = [c for c in bundled if (c.get("name"), c.get("version"), c.get("crate_checksum_sha256")) in current]
    selected_packages = [p for p in registry if (p["name"], p["version"], p.get("checksum")) not in old_by_identity]
    if len(unchanged) != 393 or len(selected_packages) != 39:
        raise ValueError(f"unexpected coverage: retained={len(unchanged)}, selected={len(selected_packages)}")

    vortex_response = json.loads(LICENSE_RESPONSE.read_bytes())
    structured = vortex_response.get("structuredContent", {})
    vortex_text = structured.get("content", "").encode("utf-8")
    vortex_receipt = {
        "response_path": str(LICENSE_RESPONSE),
        "encoding": structured.get("encoding"),
        "bytes": len(vortex_text),
        "sha256": sha256(vortex_text),
        "git_blob_sha1": git_blob_sha1(vortex_text),
        "reported_git_blob_sha1": structured.get("sha"),
        "reported_url": structured.get("display_url"),
    }
    exact_license = (
        vortex_receipt["bytes"] == 11358
        and vortex_receipt["sha256"] == EXPECTED_VORTEX_LICENSE_SHA256
        and vortex_receipt["git_blob_sha1"] == EXPECTED_VORTEX_LICENSE_GIT_BLOB
        and vortex_receipt["reported_git_blob_sha1"] == EXPECTED_VORTEX_LICENSE_GIT_BLOB
        and vortex_receipt["reported_url"] == EXPECTED_VORTEX_LICENSE_URL
        and not vortex_response.get("isError", False)
    )
    if not exact_license:
        raise ValueError(f"official Vortex license response differs from the pinned receipt: {vortex_receipt}")

    inspected = []
    package_by_identity = {}
    for p in sorted(selected_packages, key=lambda item: (item["name"], item["version"])):
        name, version, expected = p["name"], p["version"], p.get("checksum")
        if not expected:
            raise ValueError(f"{name} {version}: root lock checksum is absent")
        archives = [path for path in archive_candidates(name, version) if path.is_file()]
        if not archives:
            raise ValueError(f"{name} {version}: no exact local archive found")
        archive = archives[0]
        archive_hash = file_sha256(archive)
        archive_copies = []
        for candidate in archives:
            digest = file_sha256(candidate)
            if digest != expected:
                raise ValueError(f"{name} {version}: archive copy {candidate} SHA-256 {digest} differs from root lock {expected}")
            archive_copies.append({"path": str(candidate), "bytes": candidate.stat().st_size, "sha256": digest, "verified": True})
        cargo_data, legal, vcs, inner = inspect_archive(archive, name, version)
        fields = inner["cargo_toml"]["literal_package_fields"]
        if fields["name"] != name or fields["version"] != version:
            raise ValueError(f"{name} {version}: Cargo.toml package identity mismatch: {fields}")
        if name.startswith("vortex"):
            if fields["repository"] != "https://github.com/vortex-data/vortex" or fields["license"] != "Apache-2.0":
                raise ValueError(f"{name} {version}: Vortex Cargo.toml repository/license mismatch: {fields}")
            if not vcs or vcs.get("git", {}).get("sha1") != EXPECTED_VORTEX_COMMIT:
                raise ValueError(f"{name} {version}: .cargo_vcs_info commit mismatch: {vcs}")
            if legal:
                raise ValueError(f"{name} {version}: expected missing root legal files; found {[n for n, _ in legal]}")
        elif not legal:
            raise ValueError(f"{name} {version}: expected archive legal file(s), found none")
        record = {
            "name": name,
            "version": version,
            "root_lock_checksum_sha256": expected,
            "archive": {"path": str(archive), "bytes": archive.stat().st_size, "sha256": archive_hash, "verified": True, "verified_local_copies": archive_copies},
            **inner,
            "root_legal_files": [
                {"archive_member": f"{name}-{version}/{relative}", "bytes": len(data), "sha256": sha256(data), "text": data.decode("utf-8")}
                for relative, data in sorted(legal, key=lambda x: x[0].lower())
            ],
        }
        package_by_identity[(name, version, expected)] = (p, fields, legal, record)
        inspected.append(record)
    if len(inspected) != 39:
        raise ValueError(f"expected 39 independently inspected package archives; got {len(inspected)}")
    vortex_records = [r for r in inspected if r["name"].startswith("vortex")]
    if len(vortex_records) != 25:
        raise ValueError(f"expected 25 Vortex packages, got {len(vortex_records)}")
    for r in vortex_records:
        fields = r["cargo_toml"]["literal_package_fields"]
        if fields["license"] != "Apache-2.0" or fields["repository"] != "https://github.com/vortex-data/vortex":
            raise ValueError(f"{r['name']}: Vortex package metadata differs from expected repository/license")
    return lock, existing, inspected, unchanged, vortex_text


def main() -> None:
    lock, existing, inspected, unchanged, vortex_text = preflight()
    root_packages = [p for p in lock["package"] if p.get("source", "").startswith("registry+")]
    old_by_identity = {
        (c.get("name"), c.get("version"), c.get("crate_checksum_sha256")): c
        for c in existing["components"]
    }
    new_components = []
    text_data: dict[str, bytes] = {}
    package_records_by_key = {(r["name"], r["version"], r["root_lock_checksum_sha256"]): r for r in inspected}
    verification_by_key = {}
    for p in root_packages:
        key = (p["name"], p["version"], p.get("checksum"))
        if key in old_by_identity:
            continue
        record = package_records_by_key[key]
        fields = record["cargo_toml"]["literal_package_fields"]
        files = []
        if p["name"].startswith("vortex"):
            data = vortex_text
            digest = sha256(data)
            text_path = f"texts/{digest}.txt"
            text_data[text_path] = data
            files.append({
                "text": text_path,
                "sha256": digest,
                "bytes": len(data),
                "upstream_url": EXPECTED_VORTEX_LICENSE_URL,
            })
            record["license_binding"] = {
                "origin": "official_repository_license_for_archive_git_commit",
                "archive_git_commit": EXPECTED_VORTEX_COMMIT,
                "license_sha256": digest,
                "license_git_blob_sha1": EXPECTED_VORTEX_LICENSE_GIT_BLOB,
                "official_url": EXPECTED_VORTEX_LICENSE_URL,
                "response_evidence": "../vortex-093-license-r1.json structuredContent",
            }
        else:
            for legal in record["root_legal_files"]:
                data = legal["text"].encode("utf-8")
                digest = sha256(data)
                text_path = f"texts/{digest}.txt"
                text_data[text_path] = data
                member = legal["archive_member"].split("/", 1)[1]
                files.append({
                    "text": text_path,
                    "sha256": digest,
                    "bytes": len(data),
                    "crate_path": member,
                    "upstream_url": f"https://static.crates.io/crates/{p['name']}/{p['name']}-{p['version']}.crate#{member}",
                })
        component = {
            "name": p["name"],
            "version": p["version"],
            "source": p["source"],
            "license": fields["license"],
            "repository": fields["repository"],
            "crate_checksum_sha256": p["checksum"],
            "files": files,
        }
        new_components.append(component)
        verification_by_key[key] = {k: v for k, v in record.items() if k != "root_legal_files"}

    proposed = copy.deepcopy(existing)
    retained_keys = {(c.get("name"), c.get("version"), c.get("crate_checksum_sha256")) for c in unchanged}
    proposed["components"] = sorted(
        [*unchanged, *new_components],
        key=lambda c: (c["name"], c["version"], c["crate_checksum_sha256"]),
    )
    proposed_keys = [(c["name"], c["version"], c["crate_checksum_sha256"]) for c in proposed["components"]]
    root_keys = [(p["name"], p["version"], p.get("checksum")) for p in root_packages]
    if set(proposed_keys) != set(root_keys) or len(proposed_keys) != len(root_keys):
        raise ValueError("proposed manifest identities do not equal the complete root registry identity set")
    unchanged_comparison = []
    proposed_by_key = {(c["name"], c["version"], c["crate_checksum_sha256"]): c for c in proposed["components"]}
    for component in unchanged:
        key = (component["name"], component["version"], component["crate_checksum_sha256"])
        before = canonical_component_bytes(component)
        after = canonical_component_bytes(proposed_by_key[key])
        if before != after:
            raise ValueError(f"retained component changed: {key}")
        unchanged_comparison.append({
            "identity": {"name": key[0], "version": key[1], "crate_checksum_sha256": key[2]},
            "canonical_json_bytes": len(before),
            "baseline_sha256": sha256(before),
            "proposed_sha256": sha256(after),
            "byte_equal": True,
        })
    non_component_fields = {}
    for field in sorted(set(existing) - {"components"}):
        before = canonical_component_bytes({field: existing[field]})
        after = canonical_component_bytes({field: proposed[field]})
        if before != after:
            raise ValueError(f"non-component manifest field changed: {field}")
        non_component_fields[field] = {
            "canonical_json_bytes": len(before),
            "baseline_sha256": sha256(before),
            "proposed_sha256": sha256(after),
            "byte_equal": True,
        }

    # All validation has passed; now write only to the designated scratch proposal directory.
    OUT.mkdir(parents=True, exist_ok=True)
    for relative, data in text_data.items():
        target = OUT / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    manifest_bytes = json.dumps(proposed, indent=2, ensure_ascii=False).encode("utf-8") + b"\n"
    manifest_path = OUT / "manifest.proposed.json"
    manifest_path.write_bytes(manifest_bytes)
    baseline_bytes = BUNDLE.read_bytes()
    lock_bytes = LOCK.read_bytes()
    excluded_old = [
        {"name": c.get("name"), "version": c.get("version"), "crate_checksum_sha256": c.get("crate_checksum_sha256")}
        for c in existing["components"]
        if (c.get("name"), c.get("version"), c.get("crate_checksum_sha256")) not in retained_keys
    ]
    report = {
        "schema": "shardloom-registry-notice-proposal-r1",
        "scope": "Scratch-only proposed current registry notice manifest; no repository bundle or vendored provenance edits.",
        "source_hashes": {
            "root_cargo_lock": {"path": str(LOCK), "bytes": len(lock_bytes), "sha256": sha256(lock_bytes)},
            "baseline_license_manifest": {"path": str(BUNDLE), "bytes": len(baseline_bytes), "sha256": sha256(baseline_bytes)},
            "vortex_license_response": {"path": str(LICENSE_RESPONSE), "sha256": file_sha256(LICENSE_RESPONSE)},
            "proposed_manifest": {"path": str(manifest_path), "bytes": len(manifest_bytes), "sha256": sha256(manifest_bytes)},
        },
        "coverage": {
            "root_registry_identities": len(root_packages),
            "retained_existing_components": len(unchanged),
            "new_current_registry_components": len(new_components),
            "removed_obsolete_components": len(excluded_old),
            "proposed_component_count": len(proposed["components"]),
            "new_text_blob_count": len(text_data),
            "new_text_blob_total_bytes": sum(len(v) for v in text_data.values()),
        },
        "retained_component_comparison": {
            "method": "each retained component object canonicalized with sorted keys and compact JSON; baseline and proposal bytes compared",
            "count": len(unchanged_comparison),
            "all_byte_equal": all(item["byte_equal"] for item in unchanged_comparison),
            "components": unchanged_comparison,
        },
        "non_component_manifest_fields_comparison": {
            "all_byte_equal": all(item["byte_equal"] for item in non_component_fields.values()),
            "fields": non_component_fields,
        },
        "removed_obsolete_components": excluded_old,
        "vortex_license_source_receipt": {
            "bytes": len(vortex_text),
            "sha256": sha256(vortex_text),
            "git_blob_sha1": git_blob_sha1(vortex_text),
            "expected_sha256": EXPECTED_VORTEX_LICENSE_SHA256,
            "expected_git_blob_sha1": EXPECTED_VORTEX_LICENSE_GIT_BLOB,
            "official_url": EXPECTED_VORTEX_LICENSE_URL,
            "source_commit": EXPECTED_VORTEX_COMMIT,
            "matches_all_expected_values": True,
        },
        "packages": inspected,
        "limits": [
            "No network, Cargo command, build, test, repository edit, bundle update, or vendored-provenance edit was performed.",
            "The proposed manifest is scratch evidence for primary integration and license-policy review, not an adopted license decision.",
            "Vortex archive Cargo.toml values and .cargo_vcs_info identify the package metadata/source commit; the official repository LICENSE response bytes are separately hash-bound to that exact commit.",
        ],
    }
    report_path = OUT / "verification.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    md = [
        "# Registry notice proposal r1",
        "",
        "Scratch-only proposal based on the exact root registry lock identities. It does not modify the repository bundle or vendored provenance.",
        "",
        "## Baseline and proposed coverage",
        "",
        f"- Root Cargo.lock SHA-256: `{report['source_hashes']['root_cargo_lock']['sha256']}`.",
        f"- Baseline license manifest SHA-256: `{report['source_hashes']['baseline_license_manifest']['sha256']}`.",
        f"- Root registry set: {len(root_packages)}; retained exact existing components: {len(unchanged)}; proposed new components: {len(new_components)}; obsolete old components removed from proposal: {len(excluded_old)}.",
        f"- Proposed component count: {len(proposed['components'])}; retained-component canonical JSON byte comparisons: {len(unchanged_comparison)}/{len(unchanged_comparison)} equal.",
        f"- New distinct text blobs: {len(text_data)} ({sum(len(v) for v in text_data.values())} bytes).",
        "",
        "The complete proposal is `manifest.proposed.json`; new notice and license text files are in `texts/`. `verification.json` contains every selected package's archive path, size and checksum; literal Cargo.toml fields; exact root legal member hashes/text; and, for Vortex packages, `.cargo_vcs_info` commit evidence and the common official LICENSE binding.",
        "",
        "## Vortex license binding",
        "",
        f"All 25 Vortex 0.93.0 package archives match their root lock checksums; each Cargo.toml declares `Apache-2.0` and repository `https://github.com/vortex-data/vortex`; each `.cargo_vcs_info` records commit `{EXPECTED_VORTEX_COMMIT}`. The supplied official LICENSE response matches {len(vortex_text)} UTF-8 bytes, SHA-256 `{sha256(vortex_text)}`, Git blob `{git_blob_sha1(vortex_text)}`, and [{EXPECTED_VORTEX_LICENSE_URL}]({EXPECTED_VORTEX_LICENSE_URL}). No archive legal file was substituted.",
        "",
        "## Non-Vortex archive notices",
        "",
        f"All {len(new_components) - 25} other new packages include every root archive member whose basename begins with LICENSE, NOTICE, or COPYING (case-insensitive): {sum(len(r['root_legal_files']) for r in inspected if not r['name'].startswith('vortex'))} files total. Exact member paths, sizes, SHA-256 values, and UTF-8 text are in `verification.json`; deduplicated text copies are in `texts/`.",
        "",
        "## Review boundary",
        "",
        "Primary review remains responsible for license policy and final integration. This proposal was prepared without network access, Cargo, builds, tests, or edits to the repository manifest or vendored-provenance records.",
        "",
    ]
    (OUT / "README.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps(report["coverage"], indent=2))
    print(f"proposal: {manifest_path}\nverification: {report_path}")


if __name__ == "__main__":
    main()
