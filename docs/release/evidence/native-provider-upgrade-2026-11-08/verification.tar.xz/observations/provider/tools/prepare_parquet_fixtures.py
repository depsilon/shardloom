"""Collect bounded, Git-verified upstream fixtures without modifying the repository."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import urllib.request

N = Path(__file__).resolve().parent.parent
OUT = N / 'parquet-fixture-preparation-r1'
assert not OUT.exists()
OUT.mkdir()

def read(relative):
    return json.loads((N / relative).read_text())

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git_blob(raw):
    return hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()

records = []
for name, revision, inventory, prefixes in [
    ('parquet-testing', '09f3cdbde45302f0f0c689c950e465e98a9df960',
     'standalone-fixture-inventory-r1', ('data/', 'bad_data/')),
    ('arrow-testing', '735ae7128d571398dd798d7ff004adebeb342883',
     'standalone-fixture-inventory-r2', ('data/parquet/',)),
]:
    pin_name = 'parquet-testing' if name == 'parquet-testing' else 'arrow-testing'
    pin = read(f'{inventory}/arrow-rs-59.3.2-{pin_name}-submodule.json')
    commit = read(f'{inventory}/{name}-pinned-commit.json')
    tree_name = 'tree' if name == 'parquet-testing' else 'root-tree'
    tree = read(f'{inventory}/{name}-pinned-{tree_name}.json')
    assert pin['sha'] == revision == commit['sha']
    assert tree['sha'] == commit['commit']['tree']['sha'] and not tree['truncated']
    entries = {row['path']: row for row in tree['tree']}
    if name == 'arrow-testing':
        data_tree = read(f'{inventory}/arrow-testing-pinned-data-tree.json')
        assert data_tree['sha'] == entries['data']['sha'] and not data_tree['truncated']
        entries.update({'data/' + row['path']: dict(row, path='data/' + row['path'])
                        for row in data_tree['tree']})
    selected = {path: row for path, row in entries.items()
                if row['type'] == 'blob' and
                (path in {'LICENSE.txt', 'README.md'} or path.startswith(prefixes))}
    assert selected and all(row['mode'] == '100644' for row in selected.values())
    assert sum(row['size'] for row in selected.values()) < 10 * 1024**2
    archive = OUT / f'{name}.tar.gz'
    url = f'https://codeload.github.com/apache/{name}/tar.gz/{revision}'
    request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-provider-review'})
    size = 0
    with urllib.request.urlopen(request, timeout=45) as response, archive.open('xb') as stream:
        while chunk := response.read(1024**2):
            size += len(chunk)
            assert size <= 32 * 1024**2, 'fixture archive exceeds reviewed bound'
            stream.write(chunk)
    members = {}
    rows = []
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == f'{name}-{revision}' and '..' not in parts
            assert not member.issym() and not member.islnk()
            relative = '/'.join(parts[1:])
            if relative not in selected:
                continue
            assert member.isfile() and relative not in members
            expected = selected[relative]
            assert member.size == expected['size']
            raw = tar.extractfile(member).read()
            assert len(raw) == expected['size'] and git_blob(raw) == expected['sha']
            destination = OUT / 'sources' / name / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
            assert destination.read_bytes() == raw
            members[relative] = expected['sha']
            rows.append({'path': relative, 'bytes': len(raw), 'sha256': digest(raw),
                         'git_blob_sha1': expected['sha']})
    assert set(members) == set(selected), 'missing selected fixture members'
    license_hash = digest((OUT / 'sources' / name / 'LICENSE.txt').read_bytes())
    assert license_hash == 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'
    records.append({'repository': f'apache/{name}', 'commit': revision,
                    'arrow_rs_tag': '59.3.2', 'source_tree_sha1': tree['sha'],
                    'selected_prefixes': list(prefixes), 'license': 'Apache-2.0',
                    'license_sha256': license_hash, 'archive_url': url,
                    'archive_sha256': digest(archive.read_bytes()), 'archive_bytes': size,
                    'files': sorted(rows, key=lambda row: row['path'])})

report = {'status': 'prepared_git_blob_verified_not_installed', 'sources': records,
          'scope': 'Parquet default-codec library/integration fixtures; no optional variant fixtures.'}
(OUT / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'sources': [
    {'repository': row['repository'], 'files': len(row['files']),
     'bytes': sum(item['bytes'] for item in row['files'])} for row in records]}))
