"""Bind the final explanatory documentation without changing tested source evidence."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--repo-root', type=Path, required=True)
args = parser.parse_args()
path = args.packet / 'documentation.json'
assert not path.exists()
spec = importlib.util.spec_from_file_location('provider_verifier', args.packet / 'verify.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = json.loads((args.packet / 'acceptance.json').read_bytes())
sources = report['validation_source_snapshot']
changes = {}
for name, before in sources.items():
    current = args.repo_root / name
    if before.get('absent'):
        assert not current.exists() and not current.is_symlink(), name
    elif 'symlink' in before:
        assert current.is_symlink() and str(current.readlink()) == before['symlink'], name
    else:
        assert current.is_file() and not current.is_symlink(), name
        raw = current.read_bytes()
        after = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        if after != before:
            assert name in module.DOCUMENTATION, 'non-documentation drift: ' + name
            changes[name] = dict(before=before, after=after)
assert changes
value = dict(status='documentation_only',
    validation_source_fingerprint_sha256=report['validation_source_fingerprint_sha256'],
    changes=changes,
    scope='Final status and evidence links only. All compiled source, manifests, locks, tests, scripts, provider metadata and notices retain the exact validated identities.')
path.write_text(json.dumps(value, indent=2) + '\n')
result = subprocess.run([sys.executable, '-B', str(args.packet / 'verify.py'),
                         '--repo-root', str(args.repo_root)], check=True)
print(json.dumps(dict(status='passed', changed_documentation_paths=sorted(changes))))
