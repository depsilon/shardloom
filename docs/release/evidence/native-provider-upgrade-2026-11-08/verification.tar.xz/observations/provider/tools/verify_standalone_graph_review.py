"""Verify standalone graph coverage and the exact new development packages."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import tomllib

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
BASE = '0205283370712637305aba07a86f5854e833da6e'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
identity = lambda p: (p['name'], p['version'], p.get('source'), p.get('checksum'))
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--inventory', default='standalone-dev-graph-inventory-r1.json')
parser.add_argument('--output', default='standalone-graph-primary-review-r1.json')
args = parser.parse_args()
assert not (N / args.output).exists()
inventory = json.loads((N / args.inventory).read_text())
root = {identity(p) for p in tomllib.loads((V / 'Cargo.lock').read_text())['package']}
current = set()
graphs = []
for path in sorted((V / '.github/provider-locks').glob('*.lock')):
    raw = path.read_bytes()
    receipt = next(row for row in inventory['provider_lockfiles'] if row['path'] == str(path))
    assert sha(raw) == receipt['sha256']
    packages = tomllib.loads(raw.decode())['package']
    assert not any(any(token in p['name'].lower() for token in
                       ('datafusion', 'duckdb', 'spark', 'velox', 'polars', 'vortex-runend'))
                   for p in packages)
    current.update(identity(p) for p in packages)
    arrow = sorted({p['version'] for p in packages
                    if p['name'] == 'arrow' or p['name'].startswith('arrow-') or p['name'] == 'parquet'})
    assert arrow in ([], ['59.3.2']) or path.stem == 'orc-rust' and arrow == ['58.4.1', '59.3.2']
    assert all(p['version'] == '0.93.0' for p in packages if p['name'] == 'vortex' or p['name'].startswith('vortex-'))
    graphs.append({'path': str(path.relative_to(V)), 'sha256': sha(raw),
                   'package_count': len(packages), 'arrow_versions': arrow})
patches = tomllib.loads((V / 'Cargo.toml').read_text())['patch']['crates-io']
expected_providers = {name for name, spec in patches.items() if 'path' in spec}
assert {Path(row['path']).stem for row in graphs} == expected_providers
assert len(graphs) == len(inventory['provider_lockfiles'])
listed = {identity(p) for p in inventory['packages_absent_from_root']}
assert current - root == listed
old = set()
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '.github/provider-locks'], cwd=V, text=True).splitlines()
for relative in paths:
    if relative.endswith('.lock'):
        parsed = tomllib.loads(subprocess.check_output(['git', 'show', f'{BASE}:{relative}'], cwd=V, text=True))
        old.update(identity(p) for p in parsed['package'])
new = sorted(listed - old)
review = []
for key in new:
    name, version, source, checksum = key
    row = next(p for p in inventory['packages_absent_from_root'] if identity(p) == key)
    candidates = [Path(item['archive']['path']) for item in row['local_registry_candidates']
                  if item['archive']['state'] == 'present']
    if not candidates:
        candidates = list((N / 'standalone-dev-source-supplement-r1/archives').glob(f'{name}-{version}.crate'))
    assert candidates
    for candidate in candidates:
        assert candidate.is_file() and not candidate.is_symlink()
        assert sha(candidate.read_bytes()) == checksum
    archive_path = candidates[0]
    raw = archive_path.read_bytes()
    assert sha(raw) == checksum
    with tarfile.open(archive_path, 'r:gz') as archive:
        prefix = f'{name}-{version}/'
        manifest = archive.extractfile(prefix + 'Cargo.toml').read()
        package = tomllib.loads(manifest.decode())['package']
        assert (package['name'], package['version']) == (name, version)
        assert package.get('license') in {'Apache-2.0', 'MIT', 'MIT OR Apache-2.0',
                                          'Apache-2.0 OR MIT', 'Apache-2.0 AND MIT'}
        msrv = package.get('rust-version')
        assert not msrv or tuple(map(int, msrv.split('.')[:2])) <= (1, 96)
        legal = []
        for member in archive:
            relative = member.name.removeprefix(prefix)
            if member.isfile() and '/' not in relative and relative.lower().startswith(('license', 'notice', 'copying')):
                content = archive.extractfile(member).read()
                legal.append({'path': relative, 'sha256': sha(content), 'bytes': len(content)})
        review.append({'name': name, 'version': version, 'checksum': checksum,
                       'archive_path': str(archive_path),
                       'matching_archive_paths': [str(path) for path in candidates],
                       'manifest_sha256': sha(manifest),
                       'license': package['license'], 'declared_rust_version': msrv,
                       'root_legal_members': legal})
result = {'status': 'passed_new_development_graph_review', 'baseline': BASE,
    'root_lock_sha256': sha((V / 'Cargo.lock').read_bytes()), 'graphs': graphs,
    'new_development_packages': review, 'unchanged_prior_development_identities': len(listed & old),
    'scope': 'All graph identities checked; new development declarations and exact archives reviewed. '
             'Existing unchanged test-only license dispositions remain historical. '
             'Optional/unshipped source archives may omit legal text; this is not a distribution notice bundle.',
    'runtime_arrow_major_count': 1, 'orc_arrow_58_scope': 'unchanged upstream development dependencies only'}
(N / args.output).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'graphs': len(graphs), 'new_development_packages': len(review)}))
