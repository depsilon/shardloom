"""Independently bind every changed package manifest to exact lock sources."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/provider-upgrade-2026-11-08')
BASE = '0205283370712637305aba07a86f5854e833da6e'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--inventory', default='resolved-graph-inventory-r2.json')
parser.add_argument('--output', default='resolved-graph-primary-verification-r2.json')
args = parser.parse_args()
report_path = OUT / args.inventory
report_raw = report_path.read_bytes()
report = json.loads(report_raw)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
raw_locks = {
    'base': subprocess.check_output(['git', 'show', f'{BASE}:Cargo.lock'], cwd=ROOT),
    'current': (ROOT / 'Cargo.lock').read_bytes(),
}
def identity(package):
    return (package['name'], package['version'], package.get('source'), package.get('checksum'))
packages = {side: tomllib.loads(raw.decode())['package'] for side, raw in raw_locks.items()}
identities = {side: {identity(package) for package in values} for side, values in packages.items()}
expected = {(side, key) for side, other in [('base', 'current'), ('current', 'base')]
            for key in identities[side] - identities[other]}
records = report['r2_manifest_evidence']
assert len(records) == len(expected)
assert {(entry['side'], identity(entry['lock_record'])) for entry in records} == expected
for side, raw in raw_locks.items():
    assert report['lockfiles'][side]['sha256'] == sha(raw)
    assert report['lockfiles'][side]['bytes'] == len(raw)

verified = []
archive_count = 0
for entry in records:
    side, package, evidence = entry['side'], entry['lock_record'], entry['manifest_evidence']
    if package['source'] is None:
        relative = f"vendor/{package['name']}/Cargo.toml"
        if side == 'base':
            source = f'{BASE}:{relative}'
            raw = subprocess.check_output(['git', 'show', source], cwd=ROOT)
            assert evidence['path'] == source
        else:
            source = ROOT / relative
            assert Path(evidence['path']) == source and not source.is_symlink()
            raw = source.read_bytes()
        assert evidence['kind'] == 'path-vendor'
    else:
        assert package['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
        assert evidence['kind'] == 'registry-crate'
        assert evidence['archives']
        member = f"{package['name']}-{package['version']}/Cargo.toml"
        assert evidence['manifest_member_path'] == member
        raw = None
        for archive in evidence['archives']:
            path = Path(archive['path'])
            assert not path.is_symlink()
            payload = path.read_bytes()
            assert len(payload) == archive['bytes']
            assert sha(payload) == archive['sha256'] == package['checksum']
            with tarfile.open(path, mode='r:gz') as container:
                item = container.getmember(member)
                assert item.isfile()
                candidate = container.extractfile(item).read()
            assert raw is None or candidate == raw
            raw = candidate
            archive_count += 1
    assert sha(raw) == evidence['manifest_sha256']
    manifest = tomllib.loads(raw.decode())['package']
    for key in ('name', 'version'):
        assert manifest[key] == evidence[key] == package[key]
    for key in ('license', 'rust-version'):
        assert manifest.get(key) == evidence.get(key)
    assert manifest['license'] in ('Apache-2.0', 'Apache-2.0 AND MIT', 'MIT', 'MIT OR Apache-2.0')
    minimum = manifest.get('rust-version')
    if minimum:
        assert tuple(map(int, minimum.split('.'))) <= (1, 96, 0)
    verified.append({'side': side, 'package': package, 'manifest_sha256': sha(raw),
                     'license': manifest['license'], 'rust_version': minimum})

current = packages['current']
assert {p['version'] for p in current if p['name'].startswith('arrow') or p['name'] == 'parquet'} == {'59.3.2'}
assert {p['version'] for p in current if p['name'].startswith('vortex')} == {'0.93.0'}
assert not any(p['name'] == 'vortex-runend' for p in current)
for package in current:
    assert not re.search(r'(^|[-_])(datafusion|duckdb|spark|polars|velox|trino|dask|ray)([-_]|$)', package['name'], re.I)
assert (ROOT / 'Cargo.lock').read_bytes() == raw_locks['current']
result = {'status': 'passed', 'baseline': BASE, 'inventory_sha256': sha(report_raw),
          'verifier_sha256': sha(Path(__file__).read_bytes()),
          'lock_hashes': {side: sha(raw) for side, raw in raw_locks.items()},
          'changed_package_records': len(verified), 'archive_copies_verified': archive_count,
          'verified': verified,
          'scope': 'Exact changed manifest/archive/lock identity; declared license/MSRV policy and package-name checks. Runtime compatibility, complete license text, and security acceptance require their separate validations.'}
path = OUT / args.output
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('status', 'changed_package_records', 'archive_copies_verified')}))
