"""Replay the actual current source maps and frozen graphs without simulation."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
BASE = '0205283370712637305aba07a86f5854e833da6e'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-receipt', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
assert not (N / args.output).exists()
receipt_raw = (N / args.source_receipt).read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['status'] == 'passed' and receipt['fixed_source_validation']
sources = receipt['build_sources']
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()) == receipt['build_source_fingerprint_sha256']
paths = set()
for command in (['git', 'ls-files', '--cached', '-z'], ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    paths.update(p for p in subprocess.check_output(command, cwd=V).decode().split('\0') if p)
paths = {p for p in paths if not p.startswith(('.git/', 'docs/benchmarks/evidence/',
    'docs/release/evidence/', 'docs/dependencies/evidence/')) and '.git' not in Path(p).parts}
assert paths == set(sources)
for path, expected in sources.items():
    current = V / path
    if expected.get('absent'):
        assert not current.exists() and not current.is_symlink()
    elif 'symlink' in expected:
        assert current.is_symlink() and str(current.readlink()) == expected['symlink']
    else:
        raw = current.read_bytes()
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], path

def read(path):
    if path.startswith('source-blobs/'):
        return (N / path).read_bytes()
    if path.startswith('crate-blobs/'):
        return (N / 'portable-archive-sources-r1/blobs' / Path(path).name).read_bytes()
    if path.startswith('observations/provider/'):
        return (N / path.removeprefix('observations/provider/')).read_bytes()
    if path.startswith('baseline/provider/'):
        relative = path.removeprefix('baseline/provider/')
        return subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=V)
    raise AssertionError('Unexpected source replay path: ' + path)

tool = N / 'tools/verify_provider_sources.py'
tool_raw = tool.read_bytes()
(N / 'source-blobs' / sha(tool_raw)).write_bytes(tool_raw)
spec = importlib.util.spec_from_file_location('current_provider_sources', tool)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
baseline_locks = [p for p in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only',
    BASE, '.github/provider-locks'], cwd=V, text=True).splitlines() if p.endswith('.lock')]
result = module.verify(read, sources, baseline_locks)
report = dict(status='passed_actual_current_sources', source_receipt=args.source_receipt,
    source_receipt_sha256=sha(receipt_raw), head=receipt['head'],
    build_source_fingerprint_sha256=receipt['build_source_fingerprint_sha256'],
    verifier_sha256=sha(tool_raw), simulation=False, verification=result)
(N / args.output).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
