"""Retire reproducible pre-upgrade compiler outputs, preserving both runtimes."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
DEBUG = CACHE / 'debug'
DEST = OUT / 'debug-retirement-r2'
PREVIOUS = OUT.parent / 'vector-representations-2026-11-07'
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

def read(path):
    return json.loads(path.read_bytes())

def inventory():
    assert DEBUG.resolve() == DEBUG and DEBUG.is_dir() and not DEBUG.is_symlink()
    rows, links, hashes = [], {}, {}
    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = dict(path=str(path), generation=before)
        if stat.S_ISDIR(before[2]):
            item['kind'] = 'directory'
            rows.append(item)
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            item.update(kind='regular', sha256=hashes[key])
            rows.append(item)
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            item.update(kind='symlink', target=os.readlink(path))
            rows.append(item)
        else:
            raise AssertionError('unexpected generated file type ' + str(path))
        assert base.generation(path) == before
    visit(DEBUG)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths), paths
    return rows

def retained():
    expected = read(PREVIOUS / 'vector-closeout-r1.json')['retained_runtime_and_wheel']
    dependency = OUT.parent / 'dependency-maintenance-2026-11-07'
    assert read(dependency / 'dependency-validation-sequence-r1.json')['status'] == 'passed'
    for directory in (dependency / 'runtime-r1', dependency / 'installed-proof-r1'):
        assert directory.is_dir() and not directory.is_symlink()
        for path in directory.rglob('*'):
            if path.is_symlink():
                expected[str(path)] = {'symlink': os.readlink(path)}
            elif path.is_file():
                expected[str(path)] = dict(bytes=path.stat().st_size, sha256=base.sha(path))
    result = {}
    for name, item in expected.items():
        path = Path(name)
        if 'symlink' in item:
            assert path.is_symlink()
            result[name] = {'symlink': os.readlink(path)}
        else:
            assert path.is_file() and not path.is_symlink()
            result[name] = dict(bytes=path.stat().st_size, sha256=base.sha(path))
        assert result[name] == item
    assert len(result) > 3
    return result

def inputs():
    path = OUT.parent / 'dependency-followup-2026-11-06/dependency-retirement-r1/manifest.json.xz'
    expected = json.loads(lzma.decompress(path.read_bytes()))['input_generations']
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual

def release():
    return {str(path): base.generation(path) for path in sorted((CACHE / 'release').rglob('*'))}

def resolve():
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    value = json.loads(subprocess.check_output(['cargo', 'metadata', '--locked', '--offline',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert value['target_directory'] == str(CACHE)
    completed = read(PREVIOUS / 'vector-closeout-r1.json')
    assert completed['status'] == 'complete'
    assert completed['pr_checks_passed'] == 58 and completed['main_checks_passed'] == 55
    subprocess.run(['git', 'merge-base', '--is-ancestor', completed['merge_commit'], 'HEAD'],
                   cwd=ROOT, check=True, timeout=30)
    assert not DEBUG.is_relative_to(ROOT) and os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize > 128 << 20

def plan():
    resolve()
    assert not DEST.exists()
    base.closed([str(DEBUG)])
    print('Inventorying idle debug outputs', flush=True)
    rows = inventory()
    manifest = dict(root=str(DEBUG), entries=rows, retained=retained(), input_generations=inputs(),
                    release_generations=release(), source_head=subprocess.check_output(
                        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip())
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode())
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', root=str(DEBUG), entries=len(rows),
        regular_files=sum(x['kind'] == 'regular' for x in rows),
        manifest_sha256=base.sha(DEST / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), free_bytes_before=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
        reason='Upgraded standalone provider checks passed. Retire reproducible debug compiler outputs before final whole-workspace checks, preserving the accepted vector runtime/wheel, dependency comparison runtime/installed proof, current inputs, release cache and all compact results.',
        regeneration='Guarded final workspace/native/feature checks regenerate the required debug outputs with debug symbols and incremental compilation disabled.')
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)

def apply():
    resolve()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['root'] == str(DEBUG)
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    rows = manifest['entries']
    assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
    assert release() == manifest['release_generations']
    base.closed([str(DEBUG)])
    print('Rechecking exact debug identities', flush=True)
    assert inventory() == rows
    base.closed([str(DEBUG)])
    receipt = dict(status='running', removed=0, manifest_sha256=summary['manifest_sha256'])
    assert not (DEST / 'receipt.json').exists()
    # Deleting the first name of an accounted hardlink changes nlink/ctime on
    # its other names. Compare content, inode, mode, length and mtime; all names
    # were proved inside the selected root and are removed in this same pass.
    try:
        for row in sorted(rows, key=lambda x: len(Path(x['path']).parts), reverse=True):
            path = Path(row['path'])
            assert path == DEBUG or path.is_relative_to(DEBUG)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                assert current[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert not DEBUG.exists() and not DEBUG.is_symlink()
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert release() == manifest['release_generations']
        receipt.update(status='passed', retained_runtimes_and_wheel_unchanged=True,
            input_generations_unchanged=True, release_cache_unchanged=True,
            regular_files=summary['regular_files'], free_bytes_before=summary['free_bytes_before'],
            free_bytes_after=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
            storage_floor_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
