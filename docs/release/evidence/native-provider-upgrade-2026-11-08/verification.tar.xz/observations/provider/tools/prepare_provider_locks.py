"""Prepare standalone locks while retaining all unchanged resolutions possible."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'scripts'))
import ci_provider_tests as providers

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--seed', type=Path)
parser.add_argument('--provider', choices=providers.CONFIGURATIONS, action='append')
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = {'status': 'running', 'preparation_only': True, 'providers': []}
try:
    for crate, config in providers.CONFIGURATIONS.items():
        if args.provider and crate not in args.provider:
            continue
        frozen = ROOT / '.github/provider-locks' / f'{crate}.lock'
        lock = ROOT / 'vendor' / crate / 'Cargo.lock'
        assert not lock.is_symlink()
        seed = args.seed / f'{crate}.lock' if args.seed else frozen
        if not seed.is_file():
            seed = ROOT / 'Cargo.lock'
        before = seed.read_bytes() if seed.is_file() else None
        if before is not None:
            lock.write_bytes(before)
        command = ['cargo', 'update', '--workspace', '--manifest-path', f'vendor/{crate}/Cargo.toml']
        for patch in config['patches']:
            command += ['--config', f'patch.crates-io.{patch}.path="vendor/{patch}"']
        entry = {'provider': crate, 'command': command, 'seed': str(seed),
                 'before_sha256': sha(before) if before is not None else None}
        report['providers'].append(entry)
        print('Preparing ' + crate, flush=True)
        result = subprocess.run(command, cwd=ROOT, check=False)
        entry['returncode'] = result.returncode
        if result.returncode:
            raise RuntimeError(f'{crate} lock resolution failed')
        entry['compatible_arrow_updates'] = []
        for _ in range(32):
            current = tomllib.loads(lock.read_text())['package']
            pending = sorted((p['name'], p['version']) for p in current
                             if (p['name'] == 'arrow' or p['name'].startswith('arrow-') or p['name'] == 'parquet')
                             and p['version'].startswith('59.') and p['version'] != '59.3.2')
            if not pending:
                break
            name, version = pending[0]
            update = [*command[:2], '--offline', *command[3:], '-p', f'{name}@{version}', '--precise', '59.3.2']
            result = subprocess.run(update, cwd=ROOT, check=False)
            entry['compatible_arrow_updates'].append({'command': update, 'returncode': result.returncode})
            if result.returncode:
                raise RuntimeError(f'{crate}: {name} maintenance update failed')
        else:
            raise RuntimeError('Arrow update failed to converge')
        after = lock.read_bytes()
        parsed = tomllib.loads(after.decode())
        entry.update(after_sha256=sha(after), package_count=len(parsed['package']),
                     arrow_versions=sorted({p['version'] for p in parsed['package']
                                            if p['name'].startswith('arrow-') or p['name'] == 'parquet'}),
                     vortex_versions=sorted({p['version'] for p in parsed['package']
                                             if p['name'].startswith('vortex-')}))
        (args.output / f'{crate}.lock').write_bytes(after)
    report['status'] = 'prepared_not_accepted'
finally:
    (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'providers': len(report['providers'])}))
