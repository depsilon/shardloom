"""Package frozen provider acceptance and the separate prior dependency observation."""
import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
BASE = '0205283370712637305aba07a86f5854e833da6e'
ACCEPTED = 'a157a5ff86c50ff253300848950fed207ce3d72d'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--protocol', required=True)
parser.add_argument('--source-replay', required=True)
parser.add_argument('--standalone', required=True)
parser.add_argument('--destination', type=Path, required=True)
parser.add_argument('--execution-name', required=True,
                    help='Current packaging guard; omit only its in-progress receipt/log.')
args = parser.parse_args()
assert args.destination.is_relative_to(N) and not args.destination.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
identity = lambda raw: dict(bytes=len(raw), sha256=sha(raw))
read = lambda path: json.loads((N / path).read_bytes())
protocol = read(args.protocol)
sequence = read(protocol['name'] + '.json')
assert sequence['status'] == 'passed'
assert sequence['completed'] == [stage['name'] for stage in protocol['stages']]
checks = []
sources = None
for stage in protocol['stages']:
    receipt = read(stage['name'] + '.json')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped'] and receipt['fixed_source_validation']
    assert receipt['head'] == BASE and receipt['base'] == ACCEPTED
    assert receipt['command'] == stage['command']
    if sources is None:
        sources = receipt['build_sources']
    assert receipt['build_sources'] == sources
    log = (N / (stage['name'] + '.log')).read_bytes()
    assert sha(log) == receipt['log_sha256']
    matches = re.findall(rb'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    counts = dict(zip(('passed', 'failed', 'ignored'),
        (sum(int(row[i]) for row in matches) for i in range(3)))) if matches else None
    assert counts is None or counts['failed'] == 0
    checks.append(dict(receipt=stage['name'] + '.json', command=stage['command'], rust_tests=counts))
source_replay = read(args.source_replay)
assert source_replay['status'] == 'passed_actual_current_sources' and source_replay['simulation'] is False
assert source_replay['build_source_fingerprint_sha256'] == protocol['build_source_fingerprint_sha256']
standalone = read(args.standalone)
assert standalone['status'] == 'passed'
installed = read('installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == installed['integration']['status'] == 'passed'
assert installed['integration']['failures'] == installed['integration']['errors'] == installed['integration']['skipped'] == 0
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert sha((N / 'runtime-r1' / name).read_bytes()) == installed['integrity'][key]
wheel = N / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert sha(wheel.read_bytes()) == installed['integrity']['wheel_sha256']
core = read('python-core-r1/core.json')
core_check = next(c for c in checks if c['receipt'].startswith('provider-python-core-'))
core_log = (N / core_check['receipt'].replace('.json', '.log')).read_bytes()
match = re.search(rb'Ran (\d+) tests? in [0-9.]+s', core_log)
assert match and core['status'] == 'passed' and core['failure_count'] == core['error_count'] == 0
files = {}


def add(path, relative):
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    assert relative not in files or files[relative] == raw
    files[relative] = raw


# Keep immutable logs, receipts, source snapshots and execution helpers. Published
# archives provide upstream sources; exclude redundant extracted provider trees,
# compiler outputs, environments and runtime/wheel payloads from this evidence.
excluded = {'source-blobs', 'portable-archive-sources-r1', 'dependency-baseline-packet-r1',
            'rebase-r2', 'runtime-r1', 'installed-proof-r1', '__pycache__'}
suffixes = {'.json', '.log', '.md', '.py', '.txt', '.diff', '.xz', '.stderr'}
for path in sorted(N.rglob('*')):
    relative = path.relative_to(N)
    parts = relative.parts
    if not path.is_file() or path.is_symlink() or any(p == '__pycache__' for p in parts):
        continue
    if parts[0] in excluded or path.is_relative_to(args.destination):
        continue
    if parts[0].startswith(('packet-', 'provider-packet-', 'final-packet-', 'dependency-baseline-packet-')):
        continue
    if len(parts) == 1 and (path.name == 'continuation.md' or path.name in
            {args.execution_name + '.json', args.execution_name + '.log'}):
        continue
    if parts[0] == 'vortex-arrow-preparation-r1' and len(parts) > 1 and parts[1] == 'provider':
        continue
    if parts[0] in {'source-collection-r1', 'parquet-fixture-preparation-r1'} and path.suffix not in {'.json', '.md', '.py'}:
        continue
    if path.suffix in suffixes:
        add(path, 'observations/provider/' + relative.as_posix())
# Preparation trees themselves are disposable, but every inventoried failed
# receipt and linked log must survive even when it lives inside such a tree.
failure_inventory = read('failure-observation-inventory-r3.json')
required_observations = [Path(row['receipt_path']) for row in failure_inventory['observations']]
required_observations += [Path(row['path']) for row in failure_inventory['distinct_logs']]
for path in required_observations:
    assert path.resolve().is_relative_to(N)
    add(path, 'observations/provider/' + path.relative_to(N).as_posix())
for path in sorted((N / 'source-blobs').iterdir()):
    add(path, 'source-blobs/' + path.name)
for path in sorted((N / 'portable-archive-sources-r1/blobs').iterdir()):
    add(path, 'crate-blobs/' + path.name)
add(N / 'portable-archive-sources-r1/inventory.json', 'observations/provider/portable-archive-sources-r1/inventory.json')
for path in sorted((N / 'installed-proof-r1').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.log'}:
        add(path, 'observations/provider/installed-proof-r1/' + path.name)
nested = N / 'dependency-baseline-packet-r2'
assert {p.name for p in nested.iterdir()} == {'acceptance.json', 'verification.tar.xz', 'verify.py', 'verify_sources.py'}
for path in nested.iterdir():
    add(path, 'dependency-baseline/' + path.name)
baseline_locks = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '.github/provider-locks'], cwd=V, text=True).splitlines()
baseline_locks = [p for p in baseline_locks if p.endswith('.lock')]
baseline_manifests = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, 'vendor'], cwd=V, text=True).splitlines()
baseline_manifests = [p for p in baseline_manifests if p.count('/') == 2 and p.endswith('/Cargo.toml')]
for path in ['Cargo.lock', *baseline_locks, *baseline_manifests]:
    files['baseline/provider/' + path] = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=V)
for path, entry in sources.items():
    current = V / path
    if entry.get('absent'):
        assert not current.exists() and not current.is_symlink(), path
    elif 'symlink' in entry:
        assert current.is_symlink() and str(current.readlink()) == entry['symlink'], path
    else:
        assert identity(current.read_bytes()) == entry, path
        assert files['source-blobs/' + entry['sha256']] == current.read_bytes()
observations = []
for path, raw in sorted(files.items()):
    if path.startswith('observations/provider/') and path.endswith('.json'):
        try:
            value = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        status = value.get('status') if isinstance(value, dict) else None
        if not (isinstance(status, str) and (status.startswith('failed') or status in
                {'interrupted', 'drift_detected', 'installed_candidate_not_accepted', 'prepared_not_accepted',
                 'prepared_needs_primary_review', 'simulation_passed'})):
            continue
        relative = path.removeprefix('observations/provider/')
        logs = []
        adjacent = path.removesuffix('.json') + '.log'
        if adjacent in files:
            log_raw = files[adjacent]
            if 'log_sha256' in value:
                assert sha(log_raw) == value['log_sha256']
            logs.append(dict(path=adjacent.removeprefix('observations/provider/'), **identity(log_raw)))
        for command in value.get('commands', []):
            if isinstance(command, dict) and 'log' in command:
                log_path = str(Path(path).parent / command['log'])
                if log_path in files:
                    log_raw = files[log_path]
                    assert sha(log_raw) == command['log_sha256']
                    logs.append(dict(path=log_path.removeprefix('observations/provider/'), **identity(log_raw)))
        observations.append(dict(path=relative, **identity(raw), status=status, logs=logs,
                                 missing_raw_log_link=not logs))
raw_bytes = sum(map(len, files.values()))
assert raw_bytes < 768 << 20
args.destination.mkdir()
manifest = []
archive = args.destination / 'verification.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for path, raw in sorted(files.items()):
        manifest.append(dict(path=path, **identity(raw)))
        info = tarfile.TarInfo(path)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        output.addfile(info, io.BytesIO(raw))
assert archive.stat().st_size < 90 << 20
report = dict(schema_version='shardloom.provider_upgrade_acceptance.v1', status='local_acceptance_passed',
    source_head=BASE, accepted_base=ACCEPTED, validation_source_snapshot=sources,
    validation_source_path_count=len(sources), validation_source_fingerprint_sha256=protocol['build_source_fingerprint_sha256'],
    validation_protocol=args.protocol, validation_sequence=protocol['name'] + '.json', checks=checks,
    source_replay=args.source_replay, source_verification=source_replay['verification'],
    baseline_provider_locks=baseline_locks, standalone_acceptance=args.standalone,
    dependency_baseline_acceptance=identity(files['dependency-baseline/acceptance.json']),
    dependency_notices=source_replay['verification']['dependency_notices'],
    python_core_receipt='python-core-r1/core.json', python_core=dict(status='passed',
        discovered_test_cases=core['test_count'], reported_test_runs=int(match[1]),
        skip_records=core['skipped_count'], failures=0, errors=0),
    installed_report='installed-proof-r1/report.json', installed_package=installed['integration'],
    runtime_identity='runtime-r1-identity.json', runtime_and_wheel={key: installed['integrity'][key]
        for key in ('cli_sha256', 'native_library_sha256', 'wheel_sha256')},
    audit_report='dependency-audit-report-r1.json', audit_report_sha256=sha((N / 'dependency-audit-report-r1.json').read_bytes()),
    original_observations=observations,
    provider_decision='Vortex 0.93.0 and one Arrow/Parquet 59.3.2 runtime graph; Arrow 60 requires coordinated consumer migration.',
    original_hosted_proposals=[dict(pr=1664, disposition='Superseded by coordinated Vortex 0.93 provider migration.'),
        dict(pr=1665, disposition='Reviewed CodeQL SHA-only updates incorporated.'),
        dict(pr=1666, disposition='Close mixed-major proposal; retain single Arrow59 graph pending coordinated Arrow60 consumer migration.'),
        dict(pr=1667, disposition='Reviewed tonic-prost 0.14.9 incorporated.'),
        dict(pr=1668, disposition='Reviewed Jiff patch family incorporated with calendar regressions.')],
    limitations=['Historical-file compatibility remains outside the inherited fresh-lifecycle acceptance contract.',
        'V2 scan execution remains unadmitted; no external-engine fallback, new effects, vector arithmetic or ANN admission.',
        'Saved failures and preparation-only/simulated records remain separate; missing original raw logs are not reconstructed.',
        'The separately sealed small-dependency baseline validates its own prior source, not this provider upgrade.',
        'Default/native opt-in ignores and Python optional/environment skips remain reported; installed acceptance has zero skips.',
        'Local installed-wheel evidence is macOS arm64. Hosted final-head and exact-main checks remain a separate closeout.',
        'No benchmark, performance, publication, item19/item20, RFC0044 or CG1–CG23 completion claim.'],
    publication_attempted=False, performance_claim=False, hosted_integration='pending',
    archive='verification.tar.xz', archive_sha256=sha(archive.read_bytes()), members=manifest)
(args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copyfile(N / 'tools/verify_provider_packet.py', args.destination / 'verify.py')
shutil.copyfile(N / 'tools/verify_provider_sources.py', args.destination / 'verify_sources.py')
shutil.copyfile(N / 'tools/verify_standalone_acceptance.py', args.destination / 'verify_standalone.py')
subprocess.run(['/opt/homebrew/bin/python3.13', '-B', str(args.destination / 'verify.py'), '--repo-root', str(V)],
               check=True, timeout=180)
print(json.dumps(dict(status='local_acceptance_passed', members=len(manifest), raw_bytes=raw_bytes,
                      archive_bytes=archive.stat().st_size, source=protocol['build_source_fingerprint_sha256'])))
