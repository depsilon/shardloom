"""Install only previously verified upstream fixture bytes and provenance."""
import hashlib
import json
from pathlib import Path
import shutil

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PREP = N / 'parquet-fixture-preparation-r1'
manifest = json.loads((PREP / 'manifest.json').read_text())
assert manifest['status'] == 'prepared_git_blob_verified_not_installed'
target = V / 'vendor/parquet/test'
assert not target.exists()
provenance_path = V / 'vendor/parquet/upstream-provenance.json'
before = provenance_path.read_bytes()
provenance = json.loads(before)
assert not provenance.get('supplemental_test_files')
files = {}
for source in manifest['sources']:
    name = source['repository'].split('/')[1]
    for row in source['files']:
        path = PREP / 'sources' / name / row['path']
        raw = path.read_bytes()
        assert len(raw) == row['bytes']
        assert hashlib.sha256(raw).hexdigest() == row['sha256']
        assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == row['git_blob_sha1']
        relative = f'test/{name}/{row["path"]}'
        files[relative] = dict(row, source_repository=source['repository'],
            source_commit=source['commit'], source_path=row['path'], path=relative,
            upstream_url=f'https://raw.githubusercontent.com/{source["repository"]}/{source["commit"]}/{row["path"]}',
            reason='Pinned upstream regression fixture or its preserved license/provenance text.')
for source in manifest['sources']:
    name = source['repository'].split('/')[1]
    shutil.copytree(PREP / 'sources' / name, target / name)
for relative, row in files.items():
    assert hashlib.sha256((V / 'vendor/parquet' / relative).read_bytes()).hexdigest() == row['sha256']
provenance['supplemental_test_files'] = files
provenance['supplemental_test_sources'] = [
    {key: source[key] for key in ('repository', 'commit', 'arrow_rs_tag', 'source_tree_sha1',
                                 'selected_prefixes', 'license', 'license_sha256')}
    for source in manifest['sources']]
provenance_path.write_text(json.dumps(provenance, indent=2) + '\n')
report = {'status': 'installed_verified_fixture_sources', 'files': files,
          'fixture_manifest_sha256': hashlib.sha256((PREP / 'manifest.json').read_bytes()).hexdigest(),
          'prior_provenance_sha256': hashlib.sha256(before).hexdigest(),
          'updated_provenance_sha256': hashlib.sha256(provenance_path.read_bytes()).hexdigest()}
(N / 'parquet-fixture-installation-r1.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'files': len(files),
                  'bytes': sum(row['bytes'] for row in files.values())}))
