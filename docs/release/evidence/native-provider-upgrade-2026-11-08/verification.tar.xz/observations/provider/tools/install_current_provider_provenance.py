"""Install verified source maps and refresh only the changed notice identities."""
import copy
import hashlib
import json
from pathlib import Path
import sys

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
P = N / 'provider-current-provenance-r1'
OUT = N / 'provider-current-provenance-installation-r1.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = json.loads((P / 'report.json').read_text())
pending = []
for row in report['providers']:
    root = V / 'vendor' / row['provider']
    destination = root / 'upstream-provenance.json'
    actual = sha(destination.read_bytes()) if destination.exists() else None
    assert actual == row['before_sha256']
    current = {str(p.relative_to(root)): sha(p.read_bytes()) for p in root.rglob('*')
               if p.is_file() and str(p.relative_to(root)) not in ('Cargo.lock', 'upstream-provenance.json')}
    assert current == row['source_map']
    raw = (P / row['provider'] / 'upstream-provenance.json').read_bytes()
    assert sha(raw) == row['after_sha256']
    pending.append((destination, raw))
for destination, raw in pending:
    destination.write_bytes(raw)
    assert destination.read_bytes() == raw

sys.path.insert(0, str(V / 'scripts'))
from check_python_license_bundle import identity, locked_packages, vendored_components, verify
manifest = V / 'python/THIRD_PARTY_LICENSES/manifest.json'
before = manifest.read_bytes()
old = json.loads(before)
locked = locked_packages(V)
old_registry = {identity(row): row for row in old['components']}
removed = set(old_registry) - set(locked)
assert removed == {('vortex-arrow', '0.93.0', 'registry+https://github.com/rust-lang/crates.io-index')}
assert not (set(locked) - set(old_registry))
assert all(old_registry[key]['crate_checksum_sha256'] == checksum for key, checksum in locked.items())
updated = copy.deepcopy(old)
updated['components'] = [row for row in old['components'] if identity(row) in locked]
updated['vendored_components'] = vendored_components(V)
assert len(updated['vendored_components']) == 15
manifest.write_text(json.dumps(updated, indent=2, ensure_ascii=False) + '\n')
result = verify(V)
OUT.write_text(json.dumps(dict(status='passed_source_identity_refresh',
    scope='Exact source maps and notice identities; whole-engine acceptance remains separate.',
    proposal_report_sha256=sha((P / 'report.json').read_bytes()),
    providers=[{k: row[k] for k in ('provider', 'before_sha256', 'after_sha256')} for row in report['providers']],
    before_notice_manifest_sha256=sha(before), after_notice_manifest_sha256=sha(manifest.read_bytes()),
    registry_to_path_provider=list(removed.pop()), notice_verification=result), indent=2) + '\n')
print(json.dumps(result))
