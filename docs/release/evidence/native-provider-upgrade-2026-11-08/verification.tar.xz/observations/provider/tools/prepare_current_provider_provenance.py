"""Prepare exact source-map updates; keep installation and acceptance separate."""
import argparse
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import tomllib

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists() and args.output.parent.resolve() == N
patches = tomllib.loads((V / 'Cargo.toml').read_text())['patch']['crates-io']
names = sorted(name for name, spec in patches.items() if 'path' in spec)
assert len(names) == 15 and 'vortex-arrow' in names
proposals, rows = {}, []
for name in names:
    root = V / patches[name]['path']
    path = root / 'upstream-provenance.json'
    old_raw = path.read_bytes() if path.exists() else None
    old = json.loads(old_raw) if old_raw else None
    if old is None:
        assert name == 'vortex-arrow'
        receipt = json.loads((N / 'vortex-arrow-primary-source-verification-r1.json').read_text())
        assert receipt['status'] == 'passed'
        commit = 'c1439e69bf833fc702a60335ed674a1674ca358d'
        old = dict(provider=name, version='0.93.0', license='Apache-2.0',
            registry_archive_sha256=receipt['archive_sha256'],
            source_of_truth='https://static.crates.io/crates/vortex-arrow/vortex-arrow-0.93.0.crate',
            license_url=f'https://github.com/vortex-data/vortex/blob/{commit}/LICENSE',
            license_sha256=receipt['license_sha256'],
            license_git_blob_sha1='d645695673349e3947e8e5ae42332d0ac3164cd7',
            migration_status='scoped_storage_preservation_under_validation',
            omitted_files={'Cargo.lock': 'Workspace/standalone checked lockfiles own resolution'},
            local_changes_documentation={'path': 'README.shardloom.md'},
            supplemental_test_files={},
            added_files_sha256={p: None for p in ('LICENSE', 'README.shardloom.md', 'src/preserved_decimal.rs')})
    data = copy.deepcopy(old)
    archive = N / 'portable-archive-sources-r1/blobs' / (old['registry_archive_sha256'] + '.crate')
    assert archive.is_file() and not archive.is_symlink()
    assert sha(archive.read_bytes()) == old['registry_archive_sha256']
    source = {}
    with tarfile.open(archive, 'r:gz') as tar:
        for item in tar:
            parts = PurePosixPath(item.name).parts
            assert parts and parts[0] == f'{name}-{old["version"]}'
            assert not item.name.startswith('/') and '..' not in parts
            if item.isdir():
                continue
            assert item.isfile() and not item.issym() and not item.islnk()
            relative = '/'.join(parts[1:])
            assert relative and relative not in source
            raw = tar.extractfile(item).read()
            assert len(raw) == item.size
            source[relative] = raw
    original = {p: sha(raw) for p, raw in source.items()}
    if old_raw:
        assert original == old['original_files_sha256'], name
    archived_package = tomllib.loads(source['Cargo.toml'].decode())['package']
    current_package = tomllib.loads((root / 'Cargo.toml').read_text())['package']
    for package in (archived_package, current_package):
        assert (package['name'], package['version'], package['license']) == (name, old['version'], old['license'])
    current = {}
    for item in sorted(root.rglob('*')):
        relative = item.relative_to(root).as_posix()
        assert not item.is_symlink(), str(item)
        if item.is_dir() or relative in ('Cargo.lock', 'upstream-provenance.json'):
            continue
        assert not any(part in ('target', '.cache', '__pycache__') for part in item.relative_to(root).parts)
        current[relative] = sha(item.read_bytes())
    assert set(original) - set(current) == set(old.get('omitted_files', {})), name
    assert set(current) - set(original) == set(old['added_files_sha256']), (name, set(current) - set(original))
    assert sha((root / 'LICENSE').read_bytes()) == old['license_sha256']
    if 'license_git_blob_sha1' in old:
        raw = (root / 'LICENSE').read_bytes()
        assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == old['license_git_blob_sha1']
    data.update(original_files_sha256=original,
        registry_archive_file_count=len(source),
        registry_archive_uncompressed_bytes=sum(map(len, source.values())),
        modified_files_sha256={p: current[p] for p in sorted(set(current) & set(original)) if current[p] != original[p]},
        added_files_sha256={p: current[p] for p in sorted(set(current) - set(original))})
    if '.cargo_vcs_info.json' in source:
        data['vcs_info'] = json.loads(source['.cargo_vcs_info.json'])
    doc = data['local_changes_documentation']
    doc['sha256'] = current[doc['path']]
    for relative, fixture in data.get('supplemental_test_files', {}).items():
        raw = (root / relative).read_bytes()
        assert sha(raw) == fixture.get('current_sha256', fixture['sha256'])
        assert len(raw) == fixture.get('current_bytes', fixture['bytes'])
        if source_path := fixture.get('test_source'):
            assert sha((root / source_path).read_bytes()) == fixture['test_source_current_sha256']
    expected = {p: h for p, h in original.items() if p not in data['omitted_files']}
    expected.update(data['modified_files_sha256']); expected.update(data['added_files_sha256'])
    assert current == expected
    encoded = (json.dumps(data, indent=2) + '\n').encode()
    proposals[name] = encoded
    prior_map = dict(old.get('original_files_sha256', {}))
    prior_map.update(old.get('modified_files_sha256', {})); prior_map.update(old.get('added_files_sha256', {}))
    rows.append(dict(provider=name, version=data['version'], before_sha256=sha(old_raw) if old_raw else None,
        after_sha256=sha(encoded), archive_sha256=data['registry_archive_sha256'],
        archive_files=len(original), current_files=len(current),
        changed_source_paths=[p for p in sorted(current) if prior_map.get(p) != current[p]],
        source_map=current))
args.output.mkdir()
for name, raw in proposals.items():
    destination = args.output / name / 'upstream-provenance.json'
    destination.parent.mkdir()
    destination.write_bytes(raw)
report = dict(status='prepared_source_maps_not_acceptance', providers=rows)
(args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'providers': len(rows),
    'changes': {row['provider']: row['changed_source_paths'] for row in rows if row['changed_source_paths']}}))
