"""Independently verify the requested portable archive coverage and every copied byte."""
import hashlib
import json
from pathlib import Path
import tarfile
import tomllib

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
P = N / 'portable-archive-sources-r1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inventory = json.loads((P / 'inventory.json').read_bytes())
records = inventory['items']
inputs = inventory['inputs']
for entry in inputs.values():
    raw = Path(entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
expected_graph = set()
for row in json.loads((N / 'resolved-graph-inventory-r2.json').read_bytes())['r2_manifest_evidence']:
    package, evidence = row['lock_record'], row['manifest_evidence']
    if package.get('source') is None:
        continue
    for archive in evidence['archives']:
        expected_graph.add((row['side'], package['name'], package['version'], package['checksum'],
                            archive['path'], archive['bytes'], evidence['manifest_sha256']))
actual_graph = {(r['graph_side'], r['name'], r['version'], r['checksum_sha256'],
                 r['archive_original_path'], r['archive_bytes'], r['manifest_member_sha256'])
                for r in records if r['role'] == 'resolved_graph_r2_registry'}
assert actual_graph == expected_graph and len(actual_graph) == 85
development = json.loads((N / 'standalone-graph-primary-review-r1.json').read_bytes())['new_development_packages']
expected_development = {(r['name'], r['version'], r['checksum'], r['manifest_sha256']) for r in development}
dev_roles = {r['role'] for r in records if r['role'] != 'resolved_graph_r2_registry'}
assert len(dev_roles) == 2
dev = [r for r in records if 'development' in r['role']]
assert {(r['name'], r['version'], r['checksum_sha256'], r['manifest_member_sha256']) for r in dev} == expected_development
assert len(expected_development) == 33
vendor = [r for r in records if 'vendor' in r['role']]
expected_vendor = set()
for path in sorted((V / 'vendor').glob('*/upstream-provenance.json')):
    value = json.loads(path.read_bytes())
    expected_vendor.add((value['provider'], value['version'], value['registry_archive_sha256']))
assert {(r['name'], r['version'], r['checksum_sha256']) for r in vendor} == expected_vendor
assert len(expected_vendor) == 14 and len(dev) + len(vendor) + len(actual_graph) == len(records)
blobs = {}
for row in records:
    checksum = row['checksum_sha256']
    assert row['archive_sha256'] == checksum and row['blob_path'] == 'blobs/' + checksum + '.crate'
    source = Path(row['archive_original_path'])
    copy = P / row['blob_path']
    assert source.is_file() and copy.is_file() and not source.is_symlink() and not copy.is_symlink()
    raw = copy.read_bytes()
    assert raw == source.read_bytes() and len(raw) == row['archive_bytes'] and sha(raw) == checksum
    with tarfile.open(copy, 'r:gz') as archive:
        member = archive.getmember(row['manifest_member_path'])
        assert member.isfile() and member.name == row['name'] + '-' + row['version'] + '/Cargo.toml'
        manifest = archive.extractfile(member).read()
    assert len(manifest) == row['manifest_member_bytes'] and sha(manifest) == row['manifest_member_sha256']
    package = tomllib.loads(manifest.decode())['package']
    assert {key: package.get(key) for key in row['package_manifest_fields']} == row['package_manifest_fields']
    assert package['name'] == row['name'] and package['version'] == row['version']
    blobs[checksum] = len(raw)
assert {p.name for p in (P / 'blobs').iterdir()} == {h + '.crate' for h in blobs}
assert set(p.name for p in P.iterdir()) == {'inventory.json', 'blobs'}
assert len(blobs) == 119 and sum(blobs.values()) == 11978637
result = dict(status='passed', inventory_sha256=sha((P / 'inventory.json').read_bytes()),
              verifier_sha256=sha(Path(__file__).read_bytes()), graph_archive_copies=len(actual_graph),
              new_development_identities=len(expected_development), current_provider_identities=len(expected_vendor),
              all_role_source_copies=len(records), unique_archives=len(blobs), compressed_bytes=sum(blobs.values()),
              scope='Every requested archive identity, source/copy byte and manifest is independently checked; no runtime or license-policy acceptance inferred.')
with (N / 'portable-archive-primary-verification-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
