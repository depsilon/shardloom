"""Verify the leaf's literal version inventory against every tracked source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent.parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
r1 = json.loads((BASE / 'version-surface-inventory-r1.json').read_text())
r2 = json.loads((BASE / 'version-surface-inventory-r2.json').read_text())
assert r2['r1_facts_retained_verbatim'] == r1
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == r2['git_head']
patterns = {name: re.compile(pattern) for name, pattern in r2['method']['regex'].items()}
checked = set()
facts = 0

def verify(item):
    global facts
    p = ROOT / item['path']
    raw = p.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item['sha256'], p
    content = raw.decode('utf-8')
    assert item['counts'] == {name: len(pattern.findall(content)) for name, pattern in patterns.items()}, p
    lines = content.splitlines()
    for fact in item.get('facts', []):
        line = lines[fact['line'] - 1]
        if fact.get('text_truncated'):
            assert line.startswith(fact['text']), (p, fact)
            assert len(line.encode()) == fact['original_line_bytes']
            assert hashlib.sha256(line.encode()).hexdigest() == fact['original_line_sha256']
        else:
            assert fact['text'] == line, (p, fact)
        assert set(fact['matches']) == {name for name, pattern in patterns.items() if pattern.search(line)}
        facts += 1
    checked.add(item['path'])

for item in r1['active_files']:
    raw = (ROOT / item['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item['sha256']
for group in (r2['active_files'], r2['architecture_status_not_classified']['files'],
              r2['excluded_historical_benchmark_evidence']):
    for item in group:
        verify(item)
for key in ('grouped_cargo_locks', 'grouped_cargo_manifests'):
    for group in r2[key].values():
        for item in group:
            verify(item)
expected = set()
for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0'):
    if not name or name.startswith(('docs/release/', 'docs/dependencies/evidence/', 'docs/architecture/fixtures/',
                                    'target/', 'results/', 'artifacts/', 'benchmarks/results/', 'criterion/')):
        continue
    try:
        text = (ROOT / name).read_text()
    except (UnicodeDecodeError, IsADirectoryError):
        continue
    if any(pattern.search(text) for pattern in patterns.values()):
        expected.add(name)
assert checked == expected, {'missing': sorted(expected - checked), 'extra': sorted(checked - expected)}
record = {'status': 'passed', 'head': r2['git_head'], 'matching_files_verified': len(checked),
          'line_facts_verified': facts, 'inventory_sha256': hashlib.sha256((BASE / 'version-surface-inventory-r2.json').read_bytes()).hexdigest(),
          'scope': 'literal facts and source coverage only; active/historical disposition remains primary'}
(BASE / 'version-inventory-primary-verification-r2.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
