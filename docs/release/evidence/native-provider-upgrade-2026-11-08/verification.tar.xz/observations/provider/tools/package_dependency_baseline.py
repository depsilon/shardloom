"""Package completed pre-provider dependency observations from their frozen source blobs."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/dependency-maintenance-2026-11-07')
DEST = Path(__file__).resolve().parents[1] / 'dependency-baseline-packet-r2'
BASE = 'a157a5ff86c50ff253300848950fed207ce3d72d'
REQUIRED = ['format', 'generated-docs', 'temporal-focused', 'default-clippy',
    'default-tests', 'native-clippy', 'native-tests', 'feature-matrix',
    'msrv-default', 'msrv-native', 'audit', 'release-build', 'freeze-runtime',
    'python-core', 'installed-wheel']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def identity(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


graph = read(OUT / 'combined-graph-r1.json')
assert graph['status'] == 'passed' and graph['base'] == BASE
sources = graph['build_sources']
assert all(identity((OUT / 'source-blobs' / item['sha256']).read_bytes()) == item for item in sources.values())
required = ['dependencies-' + name + '-r1' for name in REQUIRED]
checks = []
for name in required:
    result = read(OUT / (name + '.json'))
    assert result['status'] == 'passed' and result['returncode'] == 0, name
    assert result['process_group_drained'] and result['direct_child_reaped'], name
    assert result['build_sources'] == sources, name
    log = (OUT / (name + '.log')).read_bytes()
    assert sha(log) == result['log_sha256']
    matches = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    counts = dict(zip(('passed', 'failed', 'ignored'),
        (sum(int(row[i]) for row in matches) for i in range(3)))) if matches else None
    assert counts is None or counts['failed'] == 0
    checks.append(dict(receipt=name + '.json', status='passed', command=result['command'], rust_tests=counts))
sequence = read(OUT / 'dependency-validation-sequence-r1.json')
assert sequence['status'] == 'passed' and sequence['completed'] == required
notice = read(OUT / 'notice-update-r1.json')
assert notice['status'] == 'passed'
assert notice['verification'] == dict(status='passed', registry_packages=433,
    vendored_packages=15, license_file_records=833, unique_text_files=250)
installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == installed['integration']['status'] == 'passed'
assert installed['integration']['tests'] == 386
assert installed['integration']['failures'] == installed['integration']['errors'] == installed['integration']['skipped'] == 0
assert not installed['publication_attempted'] and not installed['performance_claim']
assert installed['integrity']['licenses'] == notice['verification']
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert sha((OUT / 'runtime-r1' / name).read_bytes()) == installed['integrity'][key]
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert sha(wheel.read_bytes()) == installed['integrity']['wheel_sha256']
core = read(OUT / 'python-core-r1/core.json')
assert core['status'] == 'passed' and core['failure_count'] == core['error_count'] == 0
match = re.search(rb'Ran (\d+) tests? in [0-9.]+s', (OUT / 'dependencies-python-core-r1.log').read_bytes())
assert match
python_core = dict(status='passed', discovered_test_cases=core['test_count'],
    reported_test_runs=int(match[1]), skip_records=core['skipped_count'],
    failures=0, errors=0,
    counting_note='Discovery, reported runs and optional/environment skips are distinct measures.')
failure_dispositions = {
    'preparation-selection-failure-r1.json': 'An unguarded inventory read treated a comment-bearing upstream configuration as a JSON receipt. The corrected reader preserves nested source bytes and scans only root guard receipts. The original complete command envelope was not separately saved; the tool-output transcription remains explicit.',
    'dependencies-preparation-selection-r2.json': 'Exclusive-create protection stopped a selection attempt after the leaf inventory arrived. The preserved leaf and independently named primary inventory match all 426 file identities before the successful transfer.',
}
failures = []
for path in sorted(OUT.glob('*.json')):
    if path.name.startswith('dependencies-package-'):
        continue
    value = read(path)
    if isinstance(value, dict) and value.get('status') == 'failed':
        assert path.name in failure_dispositions, path
        failures.append(dict(receipt=path.name, status='failed', returncode=value.get('returncode'),
            error=value.get('error'), disposition=failure_dispositions[path.name]))

files = {}
patterns = ['*.json', '*.log', 'tools/*.py', 'source-blobs/*', 'failure-sources/*',
    'preparation-r1/**/*', 'debug-retirement-r1/*', 'python-core-r1/*.json',
    'installed-proof-r1/*.json', 'installed-proof-r1/*.log']
for pattern in patterns:
    for path in OUT.glob(pattern):
        if path.is_file() and not path.name.startswith('dependencies-package-'):
            assert not path.is_symlink()
            files['current/' + path.relative_to(OUT).as_posix()] = path.read_bytes()
corrected_verifier = Path(__file__).resolve().parent / 'verify_dependency_baseline.py'
files['current/tools/verify_dependency_packet-original.py'] = files['current/tools/verify_dependency_packet.py']
files['current/tools/verify_dependency_packet.py'] = corrected_verifier.read_bytes()
notice_raw = (OUT / 'source-blobs' / notice['final_manifest_sha256']).read_bytes()
assert sha(notice_raw) == notice['final_manifest_sha256']
files['reviewed-notices/manifest.json'] = notice_raw
notice_map = json.loads(notice_raw)
for component in notice_map['components'] + notice_map['vendored_components']:
    for entry in component['files']:
        relative = 'python/THIRD_PARTY_LICENSES/' + entry['text']
        raw = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT)
        assert identity(raw) == {key: entry[key] for key in ('bytes', 'sha256')}
        files['reviewed-notices/' + entry['text']] = raw
for relative in [*sources, 'python/THIRD_PARTY_LICENSES/manifest.json']:
    files['baseline/' + relative] = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT)
assert sum(len(raw) for raw in files.values()) < 64 << 20
assert not DEST.exists()
DEST.mkdir(parents=True)
manifest = []
archive_path = DEST / 'verification.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for relative, raw in sorted(files.items()):
        manifest.append(dict(path=relative, **identity(raw)))
        info = tarfile.TarInfo(relative)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert archive.getnames() == [p['path'] for p in manifest]
    for item in manifest:
        assert identity(archive.extractfile(item['path']).read()) == {k: item[k] for k in ('bytes', 'sha256')}
preparation = read(OUT / 'source-replay-primary-r1.json')
assert preparation['status'] == 'passed'
report = dict(schema_version='shardloom.dependency_maintenance_acceptance.v1',
    status='local_acceptance_passed', source_base=BASE, code_snapshot=sources,
    original_proposal_heads=graph['proposal_heads'], changed_runtime_body=False, changed_rust_tests=True,
    checks=checks, preparation_replay=preparation, original_local_failures=failures,
    original_hosted_proposals=[
        dict(pr=1664, disposition='Deferred: mixed Vortex 0.91/0.90 graph, unused retained patches and changed provider APIs require coordinated review.'),
        dict(pr=1665, disposition='Included: exact three SHA-only CodeQL changes; final combined hosted checks remain required.'),
        dict(pr=1666, disposition='Deferred: mixed Arrow 60/59 type identities; no conversion bridge.'),
        dict(pr=1667, disposition='Included: tonic-prost 0.14.9; original generated API identity and notice failures reconciled.'),
        dict(pr=1668, disposition='Included: Jiff family patch versions with independent clock regressions; original generated API identity and notice failures reconciled.')],
    dependency_notices=notice['verification'], python_core=python_core,
    installed_package=installed['integration'], installed_wheel_sha256=installed['integrity']['wheel_sha256'],
    native_library_sha256=installed['integrity']['native_library_sha256'], cli_sha256=installed['integrity']['cli_sha256'],
    audit_report_sha256=sha((OUT / 'dependency-audit-report-r1.json').read_bytes()),
    feature_boundary='Existing calendar and optional encoded-exchange providers; no new runtime body, remote effects, major provider, fallback, vector arithmetic or ANN capability.',
    limitations=[
        'Selected CodeQL source review omits 61 generated paths including the JavaScript execution bundle; no rebuilt-bundle or security-audit claim.',
        'Preparation retains the original postprocessed archive inventory and missing original reader/connector envelope limitations, plus the corrected notice checksum.',
        'The first local selection failure is a tool-output transcription, not a separately retained complete command envelope. Later guarded outcomes retain full logs.',
        'Default/native ignored cases and optional/environment Python core skips are retained as reported; installed proof requires zero skips.',
        'The audit follows the unchanged policy; actual informational advisory observations remain in the complete audit log.',
        'Local installed-wheel proof is macOS arm64. Final hosted checks, review, merge, exact-main verification and retention are separate closeout steps.',
        'There is no benchmark, performance, publication, full item 19/item 20, RFC 0044 or competitive-gate completion claim.'],
    publication_attempted=False, performance_claim=False, hosted_integration='pending',
    archive='verification.tar.xz', archive_sha256=sha(archive_path.read_bytes()), members=manifest)
(DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copyfile(corrected_verifier, DEST / 'verify.py')
shutil.copyfile(OUT / 'tools/verify_preparation.py', DEST / 'verify_sources.py')
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B', str(DEST / 'verify.py'),
    ], check=True, timeout=120)
print(json.dumps(dict(status='local_acceptance_passed', files=len(manifest),
    archive_bytes=archive_path.stat().st_size, installed_package=report['installed_package'], python_core=python_core)))

