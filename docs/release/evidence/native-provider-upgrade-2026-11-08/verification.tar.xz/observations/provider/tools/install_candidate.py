"""Install reviewed source candidates; original sources remain in Git."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent.parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
STAGE = OUT / 'rebase-r2/vendor'
SOURCES = OUT / 'source-collection-r1/corrected'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == '0205283370712637305aba07a86f5854e833da6e'
assert json.loads((OUT / 'version-inventory-primary-verification-r2.json').read_text())['status'] == 'passed'
assert shutil.disk_usage(OUT).free >= 12 * 1024**3 + 128 * 1024**2
manifest = json.loads((SOURCES / 'manifest.json').read_text())
record = {'status': 'preparing', 'head': head, 'providers': [], 'retired_source_provider': 'vortex-runend'}
for dest in sorted(STAGE.iterdir()):
    name = dest.name
    source = next(r for r in manifest['results'] if r['name'] == name and r['role'] == 'candidate')
    version = source['version']
    archive = SOURCES / source['archive']['path']
    assert sha(archive.read_bytes()) == source['archive']['sha256']
    upstream = archive.parent / 'source' / f'{name}-{version}'
    original = {p.relative_to(upstream).as_posix(): sha(p.read_bytes()) for p in upstream.rglob('*') if p.is_file()}
    actual = {p.relative_to(dest).as_posix(): sha(p.read_bytes()) for p in dest.rglob('*') if p.is_file()}
    assert all(not p.is_symlink() for p in dest.rglob('*'))
    for path in dest.rglob('*.rs'):
        text = path.read_text()
        assert not any(line.startswith(('<<<<<<< ', '=======', '>>>>>>> ', '||||||| ')) for line in text.splitlines()), path
    old = json.loads((ROOT / 'vendor' / name / 'upstream-provenance.json').read_text())
    vcs_path = upstream / '.cargo_vcs_info.json'
    vcs = json.loads(vcs_path.read_text()) if vcs_path.exists() else None
    provenance = {k: v for k, v in old.items() if k not in {'omitted_files', 'supplemental_test_files'}}
    provenance.update(version=version, registry_archive_sha256=source['archive']['sha256'],
        registry_archive_file_count=source['source_inventory']['member_count'],
        registry_archive_uncompressed_bytes=source['source_inventory']['uncompressed_bytes'],
        original_files_sha256=original,
        modified_files_sha256={p: h for p, h in actual.items() if p in original and h != original[p]},
        added_files_sha256={p: h for p, h in actual.items() if p not in original},
        omitted_files={p: 'Workspace/standalone checked lockfiles own resolution' for p in original if p not in actual},
        vcs_info=vcs, source_of_truth=source['archive']['url'],
        migration_status='candidate_port_under_validation',
        predecessor={'source_commit': head, 'version': old['version'],
            'registry_archive_sha256': old['registry_archive_sha256'],
            'provenance_path': f'vendor/{name}/upstream-provenance.json'},
        local_changes_documentation={'path': 'README.shardloom.md', 'sha256': actual['README.shardloom.md']})
    if name.startswith('vortex-'):
        license_evidence = json.loads((OUT / 'vortex-093-license-r1.json').read_text())['structuredContent']
        assert sha(license_evidence['content'].encode()) == sha((dest / 'LICENSE').read_bytes())
        provenance.update(license_url=license_evidence['display_url'], license_sha256=actual['LICENSE'])
    if 'supplemental_test_files' in old:
        provenance['supplemental_test_files'] = old['supplemental_test_files']
        for relative, item in provenance['supplemental_test_files'].items():
            item['retained_from_predecessor'] = True
            if item.get('test_source'):
                test = item['test_source']
                item['test_source_current_sha256'] = actual.get(test)
                item['test_source_candidate_archive_sha256'] = original.get(test)
                item['test_source_matches_candidate_archive'] = actual.get(test) == original.get(test)
    (dest / 'upstream-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    actual['upstream-provenance.json'] = sha((dest / 'upstream-provenance.json').read_bytes())
    target = ROOT / 'vendor' / name
    shutil.rmtree(target)
    shutil.copytree(dest, target)
    copied = {p.relative_to(target).as_posix(): sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}
    assert actual == copied
    record['providers'].append({'provider': name, 'version': version, 'installed_files': actual,
        'archive_sha256': source['archive']['sha256']})
shutil.rmtree(ROOT / 'vendor/vortex-runend')
record['status'] = 'installed_candidate_not_accepted'
(OUT / 'candidate-installation-r1.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'providers': len(record['providers'])}))
