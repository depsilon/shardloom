"""Independently verify the registry proposal and refresh the full notice bundle."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

N = Path(__file__).resolve().parent.parent
V = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
P = N / 'registry-notice-proposal-r1'
B = V / 'python/THIRD_PARTY_LICENSES'
OUT = N / 'provider-notice-installation-r1.json'
assert not OUT.exists()
sys.path.insert(0, str(V / 'scripts'))
from check_python_license_bundle import identity, verify, vendored_components

spec = importlib.util.spec_from_file_location('notice_source', N / 'tools/prepare_registry_notice_proposal.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
lock, old, inspected, unchanged, vortex_text = helper.preflight()
proposed = json.loads((P / 'manifest.proposed.json').read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
old_raw = (B / 'manifest.json').read_bytes()
locked = {identity(row): row for row in lock['package'] if row.get('source', '').startswith('registry+')}
registry = {identity(row): row for row in proposed['components']}
assert len(registry) == len(proposed['components']) == len(locked) == 432
assert set(registry) == set(locked)
assert all(row['crate_checksum_sha256'] == locked[key]['checksum'] for key, row in registry.items())
for row in unchanged:
    assert registry[identity(row)] == row
assert len(unchanged) == 393 and len(inspected) == 39
for record in inspected:
    name, version = record['name'], record['version']
    key = (name, version, 'registry+https://github.com/rust-lang/crates.io-index')
    row = registry[key]
    fields = record['cargo_toml']['literal_package_fields']
    assert row['license'] == fields['license'] and row['repository'] == fields['repository']
    if name.startswith('vortex'):
        expected = {'LICENSE': vortex_text}
        assert len(row['files']) == 1 and row['files'][0]['upstream_url'] == helper.EXPECTED_VORTEX_LICENSE_URL
    else:
        expected = {item['archive_member'].split('/', 1)[1]: item['text'].encode()
                    for item in record['root_legal_files']}
        assert set(expected) == {item['crate_path'] for item in row['files']}
    assert len(row['files']) == len(expected)
    for item in row['files']:
        raw = expected[item.get('crate_path', 'LICENSE')]
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        assert item['text'] == f'texts/{sha(raw)}.txt' and (P / item['text']).read_bytes() == raw
        if not name.startswith('vortex'):
            assert item['upstream_url'] == f'https://static.crates.io/crates/{name}/{name}-{version}.crate#{item["crate_path"]}'

updated = copy.deepcopy(proposed)
updated['vendored_components'] = vendored_components(V)
assert len(updated['vendored_components']) == 14
texts = {}
for row in old['components'] + old['vendored_components']:
    for item in row['files']:
        raw = (B / item['text']).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        texts[item['text']] = raw
assert set(texts) == {str(path.relative_to(B)) for path in (B / 'texts').iterdir()}
retained = {}
for row in updated['components'] + updated['vendored_components']:
    for item in row['files']:
        if 'path' in row:
            raw = (V / row['path'] / item['crate_path']).read_bytes()
        elif (P / item['text']).is_file():
            raw = (P / item['text']).read_bytes()
        else:
            raw = texts[item['text']]
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        if item['text'] in texts:
            assert texts[item['text']] == raw
        retained[item['text']] = raw
for relative, raw in retained.items():
    path = B / relative
    assert not path.is_symlink()
    path.write_bytes(raw)
removed = []
for relative in sorted(set(texts) - set(retained)):
    path = B / relative
    assert not path.is_symlink() and path.read_bytes() == texts[relative]
    removed.append({'path': relative, 'sha256': sha(texts[relative]), 'bytes': len(texts[relative])})
    path.unlink()
(B / 'manifest.json').write_text(json.dumps(updated, indent=2, ensure_ascii=False) + '\n')
result = verify(V)
OUT.write_text(json.dumps({'status': 'passed', 'verification': result,
    'prior_manifest_sha256': sha(old_raw), 'final_manifest_sha256': sha((B / 'manifest.json').read_bytes()),
    'root_lock_sha256': sha((V / 'Cargo.lock').read_bytes()),
    'unchanged_registry_components': len(unchanged), 'verified_changed_registry_components': len(inspected),
    'removed_unreferenced_texts': removed, 'added_texts': sorted(set(retained) - set(texts))}, indent=2) + '\n')
print(json.dumps(result))
