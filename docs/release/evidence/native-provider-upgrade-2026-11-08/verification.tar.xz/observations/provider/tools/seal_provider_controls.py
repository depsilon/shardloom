"""Seal saved relocation/corruption observations without retaining duplicate packets."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--controls', type=Path, required=True)
args = parser.parse_args()
receipt = json.loads((args.controls / 'receipt.json').read_bytes())
assert receipt['status'] == 'passed'
assert receipt['positive_controls'] == 2 and receipt['rejected_controls'] == 13
sha = lambda raw: hashlib.sha256(raw).hexdigest()
identity = lambda raw: dict(bytes=len(raw), sha256=sha(raw))
for name, item in receipt['original_packet'].items():
    assert identity((args.packet / name).read_bytes()) == item
logs = {}
for index, case in enumerate(receipt['cases']):
    raw = (args.controls / case['log']).read_bytes()
    assert identity(raw) == case['log_identity']
    assert case['returncode'] == (0 if index < 2 else 1)
    assert case['original_packet_unchanged']
    assert (json.loads(raw)['status'] == 'passed') if index < 2 else (b'AssertionError' in raw or b'KeyError' in raw)
    logs[case['log']] = raw.decode()
result = dict(status='passed', receipt=receipt, logs=logs,
              scope='Saved actual subprocess outcomes, identities and mutation records. No runtime/benchmark rerun.',
              primary_sealer_sha256=sha(Path(__file__).read_bytes()))
destination = args.packet / 'corruption-controls.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
subprocess.run([sys.executable, '-B', str(args.packet / 'verify.py')], check=True, timeout=180)
