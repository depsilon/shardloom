# Active provider version surface inventory — r2

- Repository: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
- Baseline HEAD: `0205283370712637305aba07a86f5854e833da6e`
- Worktree status: `## codex/native-provider-upgrade`
- Scope: corrected r2 view; original r1 facts retained verbatim in the JSON under `r1_facts_retained_verbatim`.

## Method and scope

Tracked UTF-8 files were scanned with the r1 expressions. R2 excludes `docs/benchmarks/evidence/**` as historical benchmark payloads. The earlier r1 blanket exclusion `docs/architecture/**` except `docs/architecture/native-provider-upgrade-2026-11-08.md` is superseded for coverage: all matching excluded architecture Markdown appears below with status unclassified.

Line facts are exact when marked `text_truncated=false`. A truncated fact is a preview; its `original_line_bytes` and `original_line_sha256` identify the exact UTF-8 source line excluding its line terminator. JSON carries the complete metadata.

## Current matched files

### `.github/provider-locks/README.md`
- SHA-256 `0f5d527b023c850473fff8c2613ffadc44912294693b6bc67e04157af5a806a9`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=3, vortex_runend=0
- L69: `runtime graph. The runtime Arrow boundary remains 59.3.1. The` [exact]
- L81: `'arrow-avro.lock' freezes the complete standalone Arrow Avro 59.3.1 library` [exact]
- L100: `'arrow-ipc.lock' fixes the complete Arrow IPC library tests at Arrow 59.3.1 with` [exact]
### `.github/provider-locks/arrow-array.lock`
- SHA-256 `598b83c790c754cb5cdc0757268a158f29814595e47d941348dee17beaf93b3f`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
### `.github/provider-locks/arrow-avro.lock`
- SHA-256 `0aae606673b85fa3d8f28f695d283bf85679cd418b12735df1e0ca93d4604336`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=12, vortex_runend=0
### `.github/provider-locks/arrow-ipc-review.json`
- SHA-256 `d63f34afea0c51fcb49cf3fd7d764d377cac90aeebf110f618b9b4191189520d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L413: `  "arrow_versions": "59.3.1",` [exact]
### `.github/provider-locks/arrow-ipc.lock`
- SHA-256 `e7b0ca692a198801e807e13cec53543f8452668accb4a8a7af4701c888a84a36`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
### `.github/provider-locks/orc-rust.lock`
- SHA-256 `e2471aeb894fd4d56f3233d8fcb3283861b6f8f4d96cc074068cd67f1a77607d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=70, vortex_runend=0
### `.github/provider-locks/vortex-array.lock`
- SHA-256 `ff95a628a094a9047c6f93cea4bbc7ef36b6b4aa7ad047db71fd15ff174b13bc`; literal counts: vortex_0_90=8, arrow_parquet_59_3_1=2, vortex_runend=0
### `.github/provider-locks/vortex-buffer.lock`
- SHA-256 `fb5f904f1871aa50136f7af2d0b604e4179a7a1fb9aa01b78e290e7514f0fd67`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=2, vortex_runend=0
### `.github/provider-locks/vortex-datetime-parts.lock`
- SHA-256 `189b24201e8aad1085b14e460a8542d0180ad28cc67d8865faee613fc663399b`; literal counts: vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
### `.github/provider-locks/vortex-file.lock`
- SHA-256 `3d81a493a945ee62d4944d69b58c50a9ae3a682195f39ccbca3d09d9946e9076`; literal counts: vortex_0_90=31, arrow_parquet_59_3_1=7, vortex_runend=5
### `.github/provider-locks/vortex-fsst.lock`
- SHA-256 `cde54f0e06d84562b78da9dedd1e9c6d15eddf2c0bad3864a17654d59304238d`; literal counts: vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
### `.github/provider-locks/vortex-io.lock`
- SHA-256 `0e9589fdb25f6bf2402e3c17cf67875e9368f05bf45f2471546f91a448277217`; literal counts: vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
### `.github/provider-locks/vortex-layout.lock`
- SHA-256 `4f0a7ca8f2abb6c302c44005b89bbe66e6cd1ceefb093eb6c30b50b27fc1bf52`; literal counts: vortex_0_90=26, arrow_parquet_59_3_1=7, vortex_runend=4
### `.github/provider-locks/vortex-runend.lock`
- SHA-256 `43e31416946dabd8a28e67d507b651e92650a9d3131948fd22feb0a4f155cdca`; literal counts: vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=1
### `.github/provider-locks/vortex-zstd.lock`
- SHA-256 `d4aa052230f037aede67cbc3bea86fa3f678c6d35d74a6777d08912b5d9df1ba`; literal counts: vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
### `Cargo.lock`
- SHA-256 `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772`; literal counts: vortex_0_90=33, arrow_parquet_59_3_1=15, vortex_runend=6
### `Cargo.toml`
- SHA-256 `3772bd45fd74887643e0788b904be8abb704a0a75c1b7e53963ca1befe3ddf71`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=6, vortex_runend=3
- L11: `exclude = ["vendor/arrow-array", "vendor/arrow-avro", "vendor/arrow-data", "vendor/arrow-ipc", "vendor/orc-rust", "vendor/parquet", "vendor/vortex-array", "vendor/vortex-buffer", "vendor/vortex-datetime-parts", "vendor/vortex-file", "vendor/vortex-fsst", "vendor/vortex-io", "vendor/vortex-layout", "vendor/vortex-runend", "vendor/vortex-zstd"]` [exact]
- L28: `vortex-runend = { path = "vendor/vortex-runend" }` [exact]
- L47: `arrow-array = "=59.3.1"` [exact]
- L50: `arrow-avro = { version = "=59.3.1", default-features = false, features = ["deflate", "snappy"] }` [exact]
- L51: `arrow-flight = { version = "=59.3.1", default-features = false, features = ["flight-sql", "tls-ring"] }` [exact]
- L52: `arrow-ipc = "=59.3.1"` [exact]
- L53: `arrow-pyarrow = "=59.3.1"` [exact]
- L61: `parquet = "=59.3.1"` [exact]
- L80: `vortex = { version = "=0.90.0", default-features = false, features = ["files", "zstd"] }` [exact]
- L81: `vortex-zstd = "=0.90.0"` [exact]
### `benchmarks/traditional_analytics/query_surface/expanded_range_replay.py`
- SHA-256 `3be406ce3e6a84315d1f8e646cd4bc11f82f7cd831eb3968bebe11094f7535d2`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L2: `"""Independent bounded replay of the pinned Vortex 0.90 footer/range evidence."""` [exact]
### `docs/architecture/native-provider-upgrade-2026-11-08.md`
- SHA-256 `45b7aaa4beb8ae4d9ac11e9d75cd082529cf547a8c8d44c7961a6341ad94de9b`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=1
- L14: `current 0.90.0 provider. The original bot proposal targets 0.91.0, but` [exact]
- L22: `Arrow buffer, data and schema 59.3.2, with other Arrow/Parquet providers at 59.3.1.` [exact]
- L80: `| Former 'vortex-runend' | Expanded text/binary views retain their shared table reservation after moving into the array provider |` [exact]
### `docs/benchmarks/native-analytical-aggregates-2026-10-27.md`
- SHA-256 `750883a25e2646881f69083d2336f73bd91fa63d771a0d80a2c0126df4c86c55`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L46: `0.90.0 arrays, masks, native gathers, list/constant constructors and persistence.` [exact]
### `docs/benchmarks/native-broad-query-2026-10-26.md`
- SHA-256 `10e339fcfff0e96b73115abf27a134236e6c346ff919f891d40f4447abc65654`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L171: `Vortex-first decision: **wrap_vortex_concept**. The pinned Vortex 0.90.0 filtered` [exact]
### `docs/benchmarks/native-ingest-window-decision-2026-10-25.md`
- SHA-256 `39d048edf3b987e636f71f0626970914e9d0805484253d5ad26581dd011979ed`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L62: `The pinned Parquet 59.3.1 byte-array dictionary reader can retain source codes` [exact]
### `docs/benchmarks/native-shared-analytical-performance-2026-10-27.md`
- SHA-256 `bdebf4c210ace289a6483e16f78b72d12c01a782c22735183d54d1d2c82b0aba`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L49: `Vortex-first review reuses admitted Vortex 0.90.0 primitive buffers, validity` [exact]
### `docs/benchmarks/native-vortex-provider-refresh-2026-10-24.md`
- SHA-256 `3cf56705a09d221bfcc9cb02009e174f828b7b183859d6e945698969c7dcd2d5`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L5: `The controlled Vortex 0.90.0 refresh passes local runtime and UAT acceptance on` [exact]
- L25: `DateTimeParts patch, and uses upstream Arrow/Python 59.3.1 instead of its former` [exact]
### `docs/dependencies/adbc-local-driver-review.md`
- SHA-256 `60f0af1731a7781b22f44f56164a39b2794c38060deadfc53f89211b578a7fff`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L14: `workspace retains its single Arrow 59.3.1 graph. These two crates add no query` [exact]
### `docs/dependencies/arrow-run-end-validation-2026-11-05.md`
- SHA-256 `745de54aafbc43c7c4d45660190aa1dc46efff42b59b7da583c175632bbd501f`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- L5: `for 'arrow-data 59.3.1'. The` [exact]
- L12: `from '59.3.1' to '59.3.2'. The latter two satisfy 'arrow-data''s minimum` [exact]
- L14: `locked packages, Vortex 0.90.0 and the existing IPC/Avro/Parquet/ORC path patches` [exact]
- L46: `failed against '59.3.1': checked construction accepted a parent of length seven` [exact]
### `docs/dependencies/json-digest-dependency-review.md`
- SHA-256 `ec077660f918812df8812d71dc27c4b0d56aecb63552f1b60ff7046433152bf2`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- L13: `'add_extension_module_link_args()'. The root dependency graph now aligns Vortex 0.90.0,` [exact]
- L14: `Arrow 59.3.1, Parquet 59.3.1 and ORC 0.9.0. This updates the compatibility-candidate` [exact]
### `docs/dependencies/rust-vortex-refresh-2026-10-03.json`
- SHA-256 `fe131af75974c7edd15363ad0ba07255a6796b723242b27d6a81ff92e02c90f3`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L129: `    "vortex-runend": "0.85.0",` [exact]
### `docs/dependencies/structured-format-dependency-review.md`
- SHA-256 `17814e5f0afced093c89318b832eb0f3022494769e4d3bbd8f370f2930e9a85c`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=11, vortex_runend=0
- L20: `The root dependency graph now aligns Vortex 0.90.0 with the Arrow family and Parquet 59.3.1;` [exact]
- L22: `not admit new formats, runtime capabilities or external-engine execution. 'arrow-pyarrow' 59.3.1` [exact]
- L29: `the aligned graph and are not included. Parquet 59.3.1 and ORC 0.9.0 are integrated in this` [exact]
- L34: `## 2026-10-17 Arrow 60 / Parquet 59.3.1 Review Deferral` [exact]
- L42: `- Its proposed direct Arrow 60, Parquet 59.3.1, and ORC 0.9.0 updates would split the current` [exact]
- L45: `  types, plus ORC's Arrow 59.3.1 'ArrowReader<File>' not implementing the direct` [exact]
- L67: `- The current candidate uses Vortex 0.90.0, Arrow 59.3.1, Parquet 59.3.1 and 'orc-rust' 0.9.0;` [exact]
- L69: `- 'arrow-pyarrow' 59.3.1 resolves from the registry instead of a workspace path patch. The` [exact]
- L72: `  remains excluded because it would split the selected Arrow graph. Its Parquet 59.3.1 and` [exact]
- L90: `The feature-gated Parquet 59.3.1 reader now has a separate metadata-first source-demand path for` [exact]
### `docs/dependencies/temporal-calendar-provider-review.md`
- SHA-256 `7abe315e9a2b2003f3dfeca96f4fd31a2f18921f1b949b1866550ce7df233d70`; literal counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L48: `The existing vendored Vortex 0.90.0 timestamp patch is expanded from naive` [exact]
- L59: `Vortex 0.90.0 supplies Date, Time and Timestamp extensions but no fixed-duration` [exact]
- L95: `DateTimeParts defect: its 0.90.0 compressor narrows the timestamp day count to` [exact]
- L103: `restore the older comparison patch, which 0.90.0 already incorporates.` [exact]
### `docs/dependencies/vortex-dependency-footprint.md`
- SHA-256 `158d76cc3c08ad7d6cddeeb2e3af0c0414d1c6ce9d69aab79dd1bb7ebb4160c1`; literal counts: vortex_0_90=3, arrow_parquet_59_3_1=3, vortex_runend=1
- L17: `- The optional upstream Vortex umbrella is pinned to 0.90.0 in the workspace and inherited` [exact]
- L19: `- Eight 0.90.0 packages remain local path patches: 'vortex-array', 'vortex-buffer',` [exact]
- L20: `  'vortex-file', 'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-runend' and` [exact]
- L22: `  'vortex-datetime-parts' now resolves from its reviewed 0.90.0 registry archive.` [exact]
- L26: `- The workspace uses Arrow 59.3.1 and Parquet 59.3.1 with ORC 0.9.0. 'arrow-pyarrow'` [exact]
- L27: `  59.3.1 resolves from the registry after its workspace path patch was removed; the unused` [exact]
### `docs/dependencies/vortex-upstream-review.md`
- SHA-256 `15c642d93b42b385698e310f04ecb1d4566705f7f6d095571b51aa49f008f253`; literal counts: vortex_0_90=12, arrow_parquet_59_3_1=6, vortex_runend=3
- L8: `stays pinned, including Vortex 0.90.0 and the existing 59.3.1 Arrow/Parquet` [exact]
- L30: `Vortex 0.90.0, Arrow/Parquet 59.3.1, ORC 0.9.0 and native libzstd 1.5.7 remain` [exact]
- L49: `The root graph now pins Vortex 0.90.0, the Arrow family and Parquet 59.3.1, ORC 0.9.0,` [exact]
- L53: `Vortex manifest requirement: '=0.90.0'.` [exact]
- L54: `'Cargo.lock' records the upstream Vortex crate family at '0.90.0'.` [exact]
- L57: `0.90.0 archive, the registry identity is reviewed, and 87 upstream plus four native` [exact]
- L58: `temporal tests pass. Eight path patches remain at 0.90.0: array, buffer, file, FSST,` [exact]
- L63: `'arrow-pyarrow' 59.3.1 now resolves from the registry instead of the former workspace` [exact]
- L93: `## October 24, 2026 controlled 0.90 intake` [exact]
- L106: `change or 0.90 performance claim is established by this intake note.` [exact]
- L169: `the already-transitive Apache-2.0 'vortex-fsst' and 'vortex-runend' 0.85.0 crates.` [exact]
- L176: `[RunEnd provenance](../../vendor/vortex-runend/upstream-provenance.json) retain` [exact]
- L504: `- Upstream Vortex 0.90.0 remains an optional provider isolated in 'shardloom-vortex' and` [exact]
- L506: `  to 59.3.1 and ORC to 0.9.0.` [exact]
- L508: `  'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-runend' and 'vortex-zstd', all at 0.90.0.` [exact]
- L509: `  'vortex-datetime-parts' resolves from the 0.90.0 registry archive after its local` [exact]
- L511: `- 'arrow-pyarrow' 59.3.1 resolves from the registry; the unused 'vendor/arrow-pyarrow'` [exact]
### `docs/reference/shardloom-user-surface-index.json`
- SHA-256 `a32dacb8fda58449771c381043f962a8577f9915f02ca2f11886c1d36826e573`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L117: `    "native_ipc_provider_version": "0.90.0",` [exact]
### `python/THIRD_PARTY_LICENSES/manifest.json`
- SHA-256 `1aa755a4b38868954dcf55a71554fa07f498636ef22c6b9449a92c2231153f03`; literal counts: vortex_0_90=52, arrow_parquet_59_3_1=41, vortex_runend=7
- L281: `      "version": "59.3.1",` [exact]
- L303: `      "version": "59.3.1",` [exact]
- L347: `      "version": "59.3.1",` [exact]
- L369: `      "version": "59.3.1",` [exact]
- L391: `      "version": "59.3.1",` [exact]
- L413: `      "version": "59.3.1",` [exact]
- L435: `      "version": "59.3.1",` [exact]
- L457: `      "version": "59.3.1",` [exact]
- L479: `      "version": "59.3.1",` [exact]
- L523: `      "version": "59.3.1",` [exact]
- L545: `      "version": "59.3.1",` [exact]
- L7637: `      "version": "0.90.0",` [exact]
- L7653: `      "version": "0.90.0",` [exact]
- L7669: `      "version": "0.90.0",` [exact]
- L7685: `      "version": "0.90.0",` [exact]
- L7701: `      "version": "0.90.0",` [exact]
- L7717: `      "version": "0.90.0",` [exact]
- L7733: `      "version": "0.90.0",` [exact]
- L7749: `      "version": "0.90.0",` [exact]
- L7765: `      "version": "0.90.0",` [exact]
- L7781: `      "version": "0.90.0",` [exact]
- L7797: `      "version": "0.90.0",` [exact]
- L7813: `      "version": "0.90.0",` [exact]
- L7829: `      "version": "0.90.0",` [exact]
- L7845: `      "version": "0.90.0",` [exact]
- L7861: `      "version": "0.90.0",` [exact]
- L7877: `      "version": "0.90.0",` [exact]
- L7893: `      "version": "0.90.0",` [exact]
- L7909: `      "version": "0.90.0",` [exact]
- L7925: `      "version": "0.90.0",` [exact]
- L7941: `      "version": "0.90.0",` [exact]
- L7957: `      "version": "0.90.0",` [exact]
- L7973: `      "version": "0.90.0",` [exact]
- L7989: `      "version": "0.90.0",` [exact]
- L8005: `      "version": "0.90.0",` [exact]
- L9211: `      "version": "59.3.1",` [exact]
- L9224: `            "url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"` [exact]
- L9229: `        "license_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt",` [exact]
- L9241: `        "notice_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt",` [exact]
- L9320: `        "source_of_truth": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate",` [exact]
- L9321: `        "version": "59.3.1"` [exact]
- L9329: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt"` [exact]
- L9336: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt"` [exact]
- L9343: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"` [exact]
- L9349: `      "version": "59.3.1",` [exact]
- L9416: `        "license_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt",` [exact]
- L9432: `        "notice_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt",` [exact]
- L9475: `        "source_of_truth": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate",` [exact]
- L9914: `        "version": "59.3.1"` [exact]
- L9922: `          "upstream_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt"` [exact]
- L9929: `          "upstream_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt"` [exact]
- L10030: `      "version": "59.3.1",` [exact]
- L10054: `        "license_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt",` [exact]
- L10066: `        "notice_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt",` [exact]
- L10101: `        "source_of_truth": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate",` [exact]
- L10103: `        "version": "59.3.1"` [exact]
- L10111: `          "upstream_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt"` [exact]
- L10118: `          "upstream_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt"` [exact]
- L10279: `      "version": "59.3.1",` [exact]
- L10291: `        "license_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt",` [exact]
- L10321: `        "notice_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt",` [exact]
- L10561: `        "source_of_truth": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate",` [exact]
- L10563: `        "version": "59.3.1"` [exact]
- L10571: `          "upstream_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt"` [exact]
- L10578: `          "upstream_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt"` [exact]
- L10584: `      "version": "0.90.0",` [exact]
- L10589: `        "version": "0.90.0",` [exact]
- L11409: `        "source_of_truth": "https://static.crates.io/crates/vortex-array/vortex-array-0.90.0.crate",` [exact]
- L11492: `            "modification": "The local 0.85 pinned clippy.toml was modified to remove the obsolete legacy_session prohibited method; it is supplemental local lint configuration, not an unchanged Vortex 0.90 archive member.",` [exact]
- L11509: `      "version": "0.90.0",` [exact]
- L11514: `        "version": "0.90.0",` [exact]
- L11561: `        "source_of_truth": "https://static.crates.io/crates/vortex-buffer/vortex-buffer-0.90.0.crate",` [exact]
- L11592: `      "version": "0.90.0",` [exact]
- L11597: `        "version": "0.90.0",` [exact]
- L11632: `        "source_of_truth": "https://static.crates.io/crates/vortex-datetime-parts/vortex-datetime-parts-0.90.0.crate",` [exact]
- L11690: `      "version": "0.90.0",` [exact]
- L11695: `        "version": "0.90.0",` [exact]
- L11745: `        "source_of_truth": "https://static.crates.io/crates/vortex-file/vortex-file-0.90.0.crate",` [exact]
- L11794: `      "version": "0.90.0",` [exact]
- L11799: `        "version": "0.90.0",` [exact]
- L11838: `        "source_of_truth": "https://static.crates.io/crates/vortex-fsst/vortex-fsst-0.90.0.crate",` [exact]
- L11896: `      "version": "0.90.0",` [exact]
- L11901: `        "version": "0.90.0",` [exact]
- L11965: `        "source_of_truth": "https://static.crates.io/crates/vortex-io/vortex-io-0.90.0.crate",` [exact]
- L12000: `      "version": "0.90.0",` [exact]
- L12005: `        "version": "0.90.0",` [exact]
- L12170: `        "source_of_truth": "https://static.crates.io/crates/vortex-layout/vortex-layout-0.90.0.crate",` [exact]
- L12253: `      "name": "vortex-runend",` [exact]
- L12254: `      "version": "0.90.0",` [exact]
- L12255: `      "path": "vendor/vortex-runend",` [exact]
- L12258: `        "provider": "vortex-runend",` [exact]
- L12259: `        "version": "0.90.0",` [exact]
- L12304: `        "source_of_truth": "https://static.crates.io/crates/vortex-runend/vortex-runend-0.90.0.crate",` [exact]
- L12312: `          "provenance_path": "vendor/vortex-runend/upstream-provenance.json"` [exact]
- L12329: `            "provider": "vortex-runend",` [exact]
- L12356: `      "version": "0.90.0",` [exact]
- L12420: `        "source_of_truth": "https://static.crates.io/crates/vortex-zstd/vortex-zstd-0.90.0.crate",` [exact]
- L12429: `        "version": "0.90.0"` [exact]
### `python/src/shardloom/adbc.py`
- SHA-256 `bc67d193cf9d386aba3e71b994ad710637e4274398d8ea880d7b86b8a0b1f84d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L181: `                  100: "ShardLoom local ADBC", 101: __version__, 102: "59.3.1", 103: 1_001_000}` [exact]
### `python/tests/test_public_context.py`
- SHA-256 `7a9614a2e87082cbe827f1652d6498c734acdf31944f0617ff89f5cce8718d06`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L214: `                self.assertEqual(result.details.field("resident_provider_version"), "=0.90.0")` [exact]
### `scripts/ci_provider_tests.py`
- SHA-256 `deca0be72ad8e942d93cc91231570e7d025108e818814104054f9ed8f8ba39c1`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- L16: `    "arrays": ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-zstd",` [exact]
- L25: `    "vortex-runend": {"features": "vortex-array/table-display", "patches": ["vortex-array"]},` [exact]
### `scripts/local_io_portable_replay.py`
- SHA-256 `34c7dd8f7983a0d996d23208619a6017466f96058302fe48694dd4fb37a68553`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L470: `             and report['provider_version'] == '0.90.0'` [exact]
### `scripts/native_performance_batch_replay.py`
- SHA-256 `ce918b1aada5aa22038878f298763aea8802224dc6a100864b8a2d6d89493bfd`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L218: `             and physical['provider_version'] == '=0.90.0', 'encoded fixture was not inspected and read back')` [exact]
### `scripts/test_ci_provider_tests.py`
- SHA-256 `7d758f3be72874e7b48b30942b14a44ca1f0a3f7169d15e18dbaeec80e4b75aa`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=5
- L16: `FROZEN_CRATES = ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-layout",` [exact]
- L33: `    "vortex-runend": [` [exact]
- L34: `        'cargo test --manifest-path vendor/vortex-runend/Cargo.toml --config patch.crates-io.vortex-array.path="vendor/vortex-array" --features vortex-array/table-display --lib -- --test-threads=2',` [exact]
- L35: `        'cargo clippy --manifest-path vendor/vortex-runend/Cargo.toml --config patch.crates-io.vortex-array.path="vendor/vortex-array" --features vortex-array/table-display --lib -- -D warnings',` [exact]
- L118: `        for crate in ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-zstd"):` [exact]
### `shardloom-vortex/Cargo.toml`
- SHA-256 `9b79b2cd5f93f2892f3a17a864c1fa21a3f5a28555a5a1ae0a4f8e054b34de41`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L104: `vortex-compressor = { version = "=0.90.0", optional = true }` [exact]
### `shardloom-vortex/src/ingest_arrow_ownership.rs`
- SHA-256 `62e02d5531bb822ec2e7047cc3646bbae3cb54d909fc6890c2615de628314c1d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L337: `                // Arrow 59.3.1 succeeds only for Arc-unique Standard(Layout)` [exact]
### `shardloom-vortex/src/local_primitive_native_sink_tests.rs`
- SHA-256 `91f66ba3d5cb5758eaff16699476f08080a57d7d38954e03d36a69971f21c5a4`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L801: `    // The 0.90 pruning expression proves the constant-false predicate before` [exact]
### `shardloom-vortex/src/local_primitive_native_writer.rs`
- SHA-256 `8bb1668952f7c98595179603d022e194e6786c4a94da7e996985b9d0de49bc24`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Vortex 0.90's blocking push writer queues one array and spawns a layout task.` [exact]
### `shardloom-vortex/src/local_primitive_query_run_store.rs`
- SHA-256 `1768902d7d325f0f09822b14fb535c53fc90a06995dcfa26d47f50570b86b594`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Pinned Vortex 0.90 supplies the file writer, native arrays/Flat layout and` [exact]
### `shardloom-vortex/src/local_primitives.rs`
- SHA-256 `0f9cc3e660753049a7426cb99d3835c5438c95aab0dc3e7c71619bc45db228a1`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L16324: `    // Vortex 0.90 normalizes every small positive step to i64, including` [exact]
### `shardloom-vortex/src/native_provider_decoder_scratch.rs`
- SHA-256 `af8e74f0960c734b8de9fe9b0f9722bc1bb629cc7c9e32170875a8d10c724ec0`; literal counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L1: `//! Finite byte-buffer bounds for the pinned 0.90 physical decoder paths.` [exact]
- L75: `    // Blocked widths/references have different scratch trees in 0.90 and are` [exact]
- L147: `        // 0.90 may expose canonical validity without closing the nullable` [exact]
### `shardloom-vortex/src/native_spill_session.rs`
- SHA-256 `316f92c1c7104bc7b49100f9e772c96cc8d07c0d9d59aba95187a949b6ffdec9`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Vortex 0.90 session clones share a mutable configuration cell. Changing an` [exact]
### `shardloom-vortex/src/owned_buffers.rs`
- SHA-256 `ccb5da920305fd137b04c92e04827372f172ec874806aeaaba25298d7ec9171d`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L30: `        // Pinned Vortex 0.90 DefaultHostAllocator requests len + preferred` [exact]
### `shardloom-vortex/src/resident_memory_encoded_transfer.rs`
- SHA-256 `e8f2f7934ed8c32cb95acbfbcb3c7d837d86c96236ba50cce2aa29fe4014d3a6`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L619: `            // A wire serializer may replace or reorder physical parts in 0.90.` [exact]
### `shardloom-vortex/src/resident_memory_ipc.rs`
- SHA-256 `8df0185e6696cdd56dc7e51caf75f01673a882e92606a14243c19e71fdfb95b8`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L45: `    /// Copy one Vortex 0.90 native IPC record into the receiving resource owner.` [exact]
### `shardloom-vortex/src/resident_source_reuse_bench.rs`
- SHA-256 `187cd94715bb22ca0bc35c2468b8f6e3a7c008cd526cde51a450443d2982ecf7`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L689: `            "writer": "Vortex 0.90.0 default strategy",` [exact]
- L695: `            "release_build": !cfg!(debug_assertions), "vortex_version": "0.90.0",` [exact]
### `shardloom-vortex/src/vortex_ingest_nested.rs`
- SHA-256 `91f61924d47cf73e6acb46c26af88dad67295824ac11fd5500823df18e769681`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L32: `/// their child field is nonnullable. Vortex 0.90 imports each child independently.` [exact]
### `shardloom-vortex/src/vortex_ingest_nested_layout.rs`
- SHA-256 `e3e45e6391f4bc70aae8f296930e237c7cf5d73616c5199f9891d35569b43925`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L39: `    // Vortex 0.90 validates every serialized ID against the file writer's` [exact]
- L127: `        layout.push_str(";timestamp_layout=chunked_flat_native_compressed;file_min_max=provider_exact_when_present;file_other_pruning_stats=retained;timestamp_provider=vortex_array_0.90.0_full_domain_microsecond_patch");` [exact]
### `shardloom-vortex/src/vortex_ingest_source_fsst_bench.rs`
- SHA-256 `6f45461ca27b41f9bfeba007e670945a95a714e13eea8a9360d6eb87a3a49a88`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L153: `        "provider":"Vortex 0.90.0 native FSST compression, Flat persistence, explicit LikeKernel and native scan",` [exact]
### `shardloom-vortex/src/vortex_ingest_text_io_tests.rs`
- SHA-256 `2c8b5dbb09e19201eb79d918f9bdc6b58f2bec44c7cfd3ff53b3d586ae4af248`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L875: `            "native_version": "0.90.0", "intended_validation_feature": "release-user-surfaces",` [exact]
### `shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs`
- SHA-256 `d3f4580378a3fe7dc3cd8c5b59e6eb921123984d4d0d73b58624cad99b83d2ff`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L222: `        "source":source,"provider":"Vortex 0.90.0 native Zstd and native file writer/scan",` [exact]
### `shardloom-vortex/tests/fixtures/independent-vortex-0.85/producer/Cargo.lock`
- SHA-256 `587dd379ebb68158a156f29aba9d968f29371be8594f31c514ad85b046a6ee8b`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
### `shardloom-vortex/tests/fixtures/independent-vortex-0.85/provenance.json`
- SHA-256 `44d62b3ddc150e01deca63a2ea790bfe357ba443c786c5236f803b1a69bf64ff`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L1743: `      "name": "vortex-runend",` [exact]
### `shardloom-vortex/tests/fixtures/native-exchange/freeze.py`
- SHA-256 `12443ddd91291a0a8e9e18849f40c5c4ba1524a237fa5adaaa642f83a8083353`; literal counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L223: `                  "target_geometric_mean_workflow_ratio_max_each_arrow": 0.90,` [exact]
- L226: `                  "winning_target_workflow_ratio_max_each_arrow": 0.90,` [exact]
- L227: `                  "winning_target_wire_or_combined_peer_cpu_ratio_max_each_arrow": 0.90,` [exact]
### `shardloom-vortex/tests/fixtures/native-exchange/producer/Cargo.lock`
- SHA-256 `4fd19ca8f7c4ac6e908f36be3eb72118103d14d6be90302737e19dcaf1d7d88a`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=5
### `vendor/arrow-array/Cargo.toml`
- SHA-256 `45fa3fea7571173d891c16348662507848d428b84cd51bbd71d37d2b8eea158b`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L16: `version = "59.3.1"` [exact]
- L102: `version = "59.3.1"` [exact]
- L105: `version = "59.3.1"` [exact]
- L108: `version = "59.3.1"` [exact]
### `vendor/arrow-array/README.shardloom.md`
- SHA-256 `79907e0379165a6fe2416630a7b44bc2fb257c3307aef907bad8ef3336585754`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L3: `This is the 'arrow-array' 59.3.1 registry source, licensed Apache-2.0 AND MIT.` [exact]
### `vendor/arrow-array/upstream-provenance.json`
- SHA-256 `4ad70e1516a3d69912ee031c888f3111fa4c78e51ba38943cae649cf5b386ca3`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=5, vortex_runend=0
- L11: `      "url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"` [exact]
- L16: `  "license_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt",` [exact]
- L28: `  "notice_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt",` [exact]
- L107: `  "source_of_truth": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate",` [exact]
- L108: `  "version": "59.3.1"` [exact]
### `vendor/arrow-avro/Cargo.toml`
- SHA-256 `b7817d3a0c02de4118e03ceff27a9a0d5579633da8013935d934551221c07fe7`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=7, vortex_runend=0
- L17: `version = "59.3.1"` [exact]
- L100: `version = "59.3.1"` [exact]
- L103: `version = "59.3.1"` [exact]
- L106: `version = "59.3.1"` [exact]
- L109: `version = "59.3.1"` [exact]
- L206: `version = "59.3.1"` [exact]
- L211: `version = "59.3.1"` [exact]
### `vendor/arrow-avro/README.shardloom.md`
- SHA-256 `117cf65757bb2b2853bc0f9ac1e9b348a2ed48e5fa7f5c4419321a9d5652b1c7`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=2, vortex_runend=0
- L3: `This is the Apache-2.0 'arrow-avro' 59.3.1 registry source from the SHA-256` [exact]
- L74: `in 'upstream-provenance.json'. Arrow release 59.3.1 resolves to` [exact]
### `vendor/arrow-avro/upstream-provenance.json`
- SHA-256 `64669bacd0614fec10fd6e2ee77aa761ccccf1fa2a83c55f8f24d6f04b23dbae`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L65: `  "license_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt",` [exact]
- L81: `  "notice_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt",` [exact]
- L124: `  "source_of_truth": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate",` [exact]
- L563: `  "version": "59.3.1"` [exact]
### `vendor/arrow-ipc/Cargo.toml`
- SHA-256 `340b99f50362aea502f43071e562ab272a510370c40e3ce8495220265ba23d48`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
- L16: `version = "59.3.1"` [exact]
- L62: `version = "59.3.1"` [exact]
- L65: `version = "59.3.1"` [exact]
- L68: `version = "59.3.1"` [exact]
- L71: `version = "59.3.1"` [exact]
- L74: `version = "59.3.1"` [exact]
### `vendor/arrow-ipc/README.shardloom.md`
- SHA-256 `cd7da09763e592d149335cf19614659c88e80a11db41ec4673ea7a9e1d1f3784`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=2, vortex_runend=0
- L3: `This is the Apache-2.0 'arrow-ipc' 59.3.1 registry provider with local decoder` [exact]
- L58: `'.github/provider-locks/arrow-ipc.lock' fixes standalone tests at Arrow 59.3.1.` [exact]
### `vendor/arrow-ipc/upstream-provenance.json`
- SHA-256 `a4e560dbb5e7952cf00990edf46bce137d8c8eae96adbd352a4633328c0f1e5c`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L22: `  "license_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt",` [exact]
- L34: `  "notice_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt",` [exact]
- L69: `  "source_of_truth": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate",` [exact]
- L71: `  "version": "59.3.1"` [exact]
### `vendor/orc-rust/src/encoding/integer/rle_v2/mod.rs`
- SHA-256 `1f378ade23cbfd75865c692fa14ff60e50bed2ec7e040de38f47768b55319825`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L488: `    let zigzagged_90_percentile_bit_width = calculate_percentile_bits(&zigzag_literals, 0.90);` [exact]
### `vendor/parquet/Cargo.toml`
- SHA-256 `7aff4b45ac6a99f4688a1686016c51a509bac632fe43519199bcf57e80340e8d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=14, vortex_runend=0
- L16: `version = "59.3.1"` [exact]
- L355: `version = "59.3.1"` [exact]
- L359: `version = "59.3.1"` [exact]
- L363: `version = "59.3.1"` [exact]
- L367: `version = "59.3.1"` [exact]
- L371: `version = "59.3.1"` [exact]
- L375: `version = "59.3.1"` [exact]
- L379: `version = "59.3.1"` [exact]
- L472: `version = "59.3.1"` [exact]
- L476: `version = "59.3.1"` [exact]
- L480: `version = "59.3.1"` [exact]
- L484: `version = "59.3.1"` [exact]
- L540: `version = "59.3.1"` [exact]
- L550: `version = "59.3.1"` [exact]
### `vendor/parquet/README.shardloom.md`
- SHA-256 `78ba2a2086ed6da20ea6476f0b55dd2409040336df451466c77905461dccfcfd`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L3: `This is the 'parquet' 59.3.1 registry source with the following local corrections. Normal and` [exact]
### `vendor/parquet/upstream-provenance.json`
- SHA-256 `d92d6c5a9369863375efe0ecd4a8cbb700fa547dbab46c348ff7af8a7eb90b25`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L10: `  "license_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt",` [exact]
- L40: `  "notice_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt",` [exact]
- L280: `  "source_of_truth": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate",` [exact]
- L282: `  "version": "59.3.1"` [exact]
### `vendor/vortex-array/Cargo.toml`
- SHA-256 `fd87569efbab476134e1df92da1c8e6ecdb51f07c9efd20b0299fb68859aa256`; literal counts: vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
- L17: `version = "0.90.0"` [exact]
- L222: `version = "0.90.0"` [exact]
- L225: `version = "0.90.0"` [exact]
- L229: `version = "0.90.0"` [exact]
- L233: `version = "0.90.0"` [exact]
- L238: `version = "0.90.0"` [exact]
- L242: `version = "0.90.0"` [exact]
- L246: `version = "0.90.0"` [exact]
### `vendor/vortex-array/README.shardloom.md`
- SHA-256 `36de77212e662e0c6d70f6acd4c05b0b1f26d24aec1b4318df35116113e68450`; literal counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L6: `0.90.0 provider. Its upstream 'BufferAllocator' hooks do not provide the` [exact]
- L23: `0.90 port must pass new validation; that earlier measurement is not a performance` [exact]
- L35: `This is the Apache-2.0 'vortex-array' 0.90.0 published source with a focused` [exact]
- L120: `In 0.90, conversion from nullable contiguous text validates only observable` [exact]
### `vendor/vortex-array/src/array/owner_tests.rs`
- SHA-256 `3d05af8ec24e82d605cf78209f65e96827710b31fdbef51fca7cec9f67f23ee3`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `// ShardLoom regression tests, updated for Vortex 0.90 on 2026-10-24.` [exact]
### `vendor/vortex-array/src/arrays/filter/execute/buffer.rs`
- SHA-256 `9740599d802296e1ab5b3b743a137eaa8a14128c38ec6c93dd7c33224066f673`; literal counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L123: `    // | aarch64 |   0.90 |    0.90 |    0.90 |    0.75 |  0.90 |` [exact]
### `vendor/vortex-array/src/host_memory.rs`
- SHA-256 `a392fdf6ee2a85202a97727832a49c7f060ce2add3894446e6d4b75a026aef2c`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L4: `// allocation and foreign-owner contract beside the 0.90 buffer allocator.` [exact]
- L8: `//! The 0.90 'BufferAllocator' API remains separate: allocation denial there aborts.` [exact]
### `vendor/vortex-array/upstream-provenance.json`
- SHA-256 `9897a8eb770c062aef125df6593ae59b57bd47b6d6813ca108e9334294cbadbb`; literal counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L823: `  "source_of_truth": "https://static.crates.io/crates/vortex-array/vortex-array-0.90.0.crate",` [exact]
- L906: `      "modification": "The local 0.85 pinned clippy.toml was modified to remove the obsolete legacy_session prohibited method; it is supplemental local lint configuration, not an unchanged Vortex 0.90 archive member.",` [exact]
### `vendor/vortex-buffer/Cargo.toml`
- SHA-256 `04771e2b07a2dd39e4ef01a4f8ffe79c772d5694678b5b961ff353ec58e1833e`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L17: `version = "0.90.0"` [exact]
- L101: `version = "0.90.0"` [exact]
### `vendor/vortex-buffer/README.shardloom.md`
- SHA-256 `a8509adf59f7880f6da39d8fcbde88d4a978db0597b5581265fe466edfb3e880`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the Apache-2.0 'vortex-buffer' 0.90.0 published source,` [exact]
### `vendor/vortex-buffer/upstream-provenance.json`
- SHA-256 `231802611d3b99c9712f99c595f933e47b571d376b3746c940fc3dfaa7a12855`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L50: `  "source_of_truth": "https://static.crates.io/crates/vortex-buffer/vortex-buffer-0.90.0.crate",` [exact]
### `vendor/vortex-datetime-parts/Cargo.toml`
- SHA-256 `88fe98c5930b37c621611b0fd91aa934b8bdc9c177f9aa54b594ea129faf8693`; literal counts: vortex_0_90=9, arrow_parquet_59_3_1=0, vortex_runend=0
- L16: `version = "0.90.0"` [exact]
- L55: `version = "0.90.0"` [exact]
- L59: `version = "0.90.0"` [exact]
- L63: `version = "0.90.0"` [exact]
- L67: `version = "0.90.0"` [exact]
- L71: `version = "0.90.0"` [exact]
- L75: `version = "0.90.0"` [exact]
- L92: `version = "0.90.0"` [exact]
- L97: `version = "0.90.0"` [exact]
### `vendor/vortex-datetime-parts/README.shardloom.md`
- SHA-256 `b5bbb2542ff6c4ae1889f248df60b4754628ca74c8e436e915da896701dad045`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the Apache-2.0 'vortex-datetime-parts' 0.90.0 published` [exact]
- L27: `0.90.0 archive already contains those fixes. This is an independent storage` [exact]
### `vendor/vortex-datetime-parts/upstream-provenance.json`
- SHA-256 `45b0ac813c3f185908c76bf8d38789438cf0b16d32b4b221b81dec1a15f918b3`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L38: `  "source_of_truth": "https://static.crates.io/crates/vortex-datetime-parts/vortex-datetime-parts-0.90.0.crate",` [exact]
### `vendor/vortex-file/Cargo.toml`
- SHA-256 `ee570c5aee3d89fc8398d143f4e94699b13057ece06f5ca0134150d1de073006`; literal counts: vortex_0_90=31, arrow_parquet_59_3_1=0, vortex_runend=1
- L17: `version = "0.90.0"` [exact]
- L125: `version = "0.90.0"` [exact]
- L129: `version = "0.90.0"` [exact]
- L133: `version = "0.90.0"` [exact]
- L137: `version = "0.90.0"` [exact]
- L141: `version = "0.90.0"` [exact]
- L145: `version = "0.90.0"` [exact]
- L149: `version = "0.90.0"` [exact]
- L153: `version = "0.90.0"` [exact]
- L157: `version = "0.90.0"` [exact]
- L161: `version = "0.90.0"` [exact]
- L165: `version = "0.90.0"` [exact]
- L169: `version = "0.90.0"` [exact]
- L173: `version = "0.90.0"` [exact]
- L177: `version = "0.90.0"` [exact]
- L181: `version = "0.90.0"` [exact]
- L185: `version = "0.90.0"` [exact]
- L189: `version = "0.90.0"` [exact]
- L192: `[dependencies.vortex-runend]` [exact]
- L193: `version = "0.90.0"` [exact]
- L197: `version = "0.90.0"` [exact]
- L201: `version = "0.90.0"` [exact]
- L205: `version = "0.90.0"` [exact]
- L209: `version = "0.90.0"` [exact]
- L213: `version = "0.90.0"` [exact]
- L218: `version = "0.90.0"` [exact]
- L223: `version = "0.90.0"` [exact]
- L227: `version = "0.90.0"` [exact]
- L255: `version = "0.90.0"` [exact]
- L260: `version = "0.90.0"` [exact]
- L265: `version = "0.90.0"` [exact]
- L270: `version = "0.90.0"` [exact]
### `vendor/vortex-file/Cargo.toml.orig`
- SHA-256 `ba3fd2b3662d0f39135c7509fc2734b8cf91773a03cf7ba2013be686d709146d`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L49: `vortex-runend = { workspace = true }` [exact]
### `vendor/vortex-file/README.shardloom.md`
- SHA-256 `dc1b11d11a37d223f415fd5acc70cc5e78347a590bc5adeb8f5ba81f9a072f06`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the reviewed Apache-2.0 'vortex-file' 0.90.0 registry` [exact]
### `vendor/vortex-file/src/lib.rs`
- SHA-256 `67af2e3a160a5cd25bff07266c8fa25016e59b87f026af05355c154ddc66382e`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L191: `    vortex_runend::initialize(session);` [exact]
### `vendor/vortex-file/upstream-provenance.json`
- SHA-256 `cbe29981309a5e9cab8473a00d61dfe00d64132b50bbee0c5f67c1ae7d3390ad`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L53: `  "source_of_truth": "https://static.crates.io/crates/vortex-file/vortex-file-0.90.0.crate",` [exact]
### `vendor/vortex-fsst/Cargo.toml`
- SHA-256 `afcabb8a63f5bbbb7553a1cd716604034293a62b3d9bf376f9c7961b9d32e0c4`; literal counts: vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- L17: `version = "0.90.0"` [exact]
- L71: `version = "0.90.0"` [exact]
- L75: `version = "0.90.0"` [exact]
- L79: `version = "0.90.0"` [exact]
- L83: `version = "0.90.0"` [exact]
- L87: `version = "0.90.0"` [exact]
- L107: `version = "0.90.0"` [exact]
### `vendor/vortex-fsst/README.shardloom.md`
- SHA-256 `dbb169f4e5aeee7f018f425af80e21a1a310b19f7d9cf77b57ef1af764795650`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the Apache-2.0 'vortex-fsst' 0.90.0 published source. Its canonical` [exact]
### `vendor/vortex-fsst/upstream-provenance.json`
- SHA-256 `1b6a1fbf6e2cde5f45632428f6d6fdf6c1ea501cf8dbba0ec3468fdc68f6ef06`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L42: `  "source_of_truth": "https://static.crates.io/crates/vortex-fsst/vortex-fsst-0.90.0.crate",` [exact]
### `vendor/vortex-io/Cargo.toml`
- SHA-256 `5aa7bae1dcfd7da9b181181c6030dc8bd4f799b88edf928af9a434d3c5a3b6e5`; literal counts: vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- L17: `version = "0.90.0"` [exact]
- L120: `version = "0.90.0"` [exact]
- L124: `version = "0.90.0"` [exact]
- L128: `version = "0.90.0"` [exact]
- L132: `version = "0.90.0"` [exact]
- L136: `version = "0.90.0"` [exact]
- L140: `version = "0.90.0"` [exact]
### `vendor/vortex-io/README.shardloom.md`
- SHA-256 `4b50f4b713d4958dc7239a1a9c3f6ac91d392fe8a6eb6391c437f8b96b03f679`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the reviewed Apache-2.0 'vortex-io' 0.90.0 published source. The` [exact]
- L11: `Vortex 0.90 separates its buffer allocator from the older fallible host` [exact]
### `vendor/vortex-io/upstream-provenance.json`
- SHA-256 `ce8c58fc2941f4977540dfb3759dc8eaafeabbedd0e8712d9decfea7841ee92f`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L67: `  "source_of_truth": "https://static.crates.io/crates/vortex-io/vortex-io-0.90.0.crate",` [exact]
### `vendor/vortex-layout/Cargo.toml`
- SHA-256 `b22910b7cce444ff31836f525cbe4cb62ae2f2a4cc710362d7e3135b70321b19`; literal counts: vortex_0_90=16, arrow_parquet_59_3_1=0, vortex_runend=1
- L17: `version = "0.90.0"` [exact]
- L152: `version = "0.90.0"` [exact]
- L156: `version = "0.90.0"` [exact]
- L160: `version = "0.90.0"` [exact]
- L164: `version = "0.90.0"` [exact]
- L168: `version = "0.90.0"` [exact]
- L172: `version = "0.90.0"` [exact]
- L176: `version = "0.90.0"` [exact]
- L180: `version = "0.90.0"` [exact]
- L183: `[dependencies.vortex-runend]` [exact]
- L184: `version = "0.90.0"` [exact]
- L188: `version = "0.90.0"` [exact]
- L192: `version = "0.90.0"` [exact]
- L196: `version = "0.90.0"` [exact]
- L200: `version = "0.90.0"` [exact]
- L251: `version = "0.90.0"` [exact]
- L255: `version = "0.90.0"` [exact]
### `vendor/vortex-layout/Cargo.toml.orig`
- SHA-256 `676e8e53b24dae2f7c616defe5801c8e6997ad5f2cf68295fe6be797368122de`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L53: `vortex-runend = { workspace = true }` [exact]
### `vendor/vortex-layout/README.shardloom.md`
- SHA-256 `5cd7fbb4dda8b3d6608e61fcd657fdd9a5c7d787c0a4899f3e3115e07a2372fa`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the reviewed Apache-2.0 'vortex-layout' 0.90.0 registry` [exact]
- L24: `The October 24 refresh ports those corrections to the 0.90 layout/context APIs.` [exact]
### `vendor/vortex-layout/src/layouts/zoned/zone_map.rs`
- SHA-256 `e24517c1d564a4bb368f963a08e55e4aa38859091ea5af53e0d1ce8ded64eb07`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L47: `use vortex_runend::RunEnd;` [exact]
### `vendor/vortex-layout/upstream-provenance.json`
- SHA-256 `bcde8f289431e87606f7c286b6a46f9c9bd93275bed2abad2eb507b42820df14`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",` [exact]
- L168: `  "source_of_truth": "https://static.crates.io/crates/vortex-layout/vortex-layout-0.90.0.crate",` [exact]
### `vendor/vortex-runend/Cargo.toml`
- SHA-256 `b409dd238dcbe22b4a17031c78aadf01feb6f9427202646fcfecf98a34b132dc`; literal counts: vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=2
- L16: `name = "vortex-runend"` [exact]
- L17: `version = "0.90.0"` [exact]
- L51: `name = "vortex_runend"` [exact]
- L68: `version = "0.90.0"` [exact]
- L72: `version = "0.90.0"` [exact]
- L76: `version = "0.90.0"` [exact]
- L80: `version = "0.90.0"` [exact]
- L84: `version = "0.90.0"` [exact]
- L107: `version = "0.90.0"` [exact]
### `vendor/vortex-runend/Cargo.toml.orig`
- SHA-256 `ef123315691c5b6c42d4dd079213c5104c7e9fc269de705bad09d2cd40021a2f`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L2: `name = "vortex-runend"` [exact]
### `vendor/vortex-runend/README.shardloom.md`
- SHA-256 `1ebe9ee5e6fb1e02587d9bf6ce26b864b785c41971895206b0528e3a8333aab3`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=1
- L3: `This is the Apache-2.0 'vortex-runend' 0.90.0 published source. String and binary` [exact]
### `vendor/vortex-runend/src/array.rs`
- SHA-256 `771149d1b2df930d8e793db5ec4a2499dafe86735c7583a667df2adb36fa4eb5`; literal counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- L427: `    /// # use vortex_runend::RunEnd;` [exact]
- L430: `    /// vortex_runend::initialize(&session);` [exact]
### `vendor/vortex-runend/upstream-provenance.json`
- SHA-256 `60813fd62e8ac202f9b2e5baf97bbf9648f8a9407c20de57784228d56750e669`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=5
- L2: `  "provider": "vortex-runend",` [exact]
- L3: `  "version": "0.90.0",` [exact]
- L48: `  "source_of_truth": "https://static.crates.io/crates/vortex-runend/vortex-runend-0.90.0.crate",` [exact]
- L56: `    "provenance_path": "vendor/vortex-runend/upstream-provenance.json"` [exact]
- L73: `      "provider": "vortex-runend",` [exact]
### `vendor/vortex-zstd/Cargo.toml`
- SHA-256 `b5cf9c5d1c4488cd69f4a07ec2caeab1641d6fe169f1150e552ccc15ebe55397`; literal counts: vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
- L17: `version = "0.90.0"` [exact]
- L61: `version = "0.90.0"` [exact]
- L65: `version = "0.90.0"` [exact]
- L69: `version = "0.90.0"` [exact]
- L73: `version = "0.90.0"` [exact]
- L77: `version = "0.90.0"` [exact]
- L81: `version = "0.90.0"` [exact]
- L102: `version = "0.90.0"` [exact]
### `vendor/vortex-zstd/README.shardloom.md`
- SHA-256 `b1795696cb5c21ae89f3c8f002a44cafca20dcd84d15125f79f52071bb915a51`; literal counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the reviewed Apache-2.0 'vortex-zstd' 0.90.0 published source, with the` [exact]
### `vendor/vortex-zstd/upstream-provenance.json`
- SHA-256 `98b0d35343299e81984d3d69a6be76a48ba295ad334e18a33681987d355c9bd3`; literal counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L62: `  "source_of_truth": "https://static.crates.io/crates/vortex-zstd/vortex-zstd-0.90.0.crate",` [exact]
- L71: `  "version": "0.90.0"` [exact]

## Grouped Cargo lockfiles

### provider standalone locks
- `.github/provider-locks/arrow-array.lock` — SHA-256 `598b83c790c754cb5cdc0757268a158f29814595e47d941348dee17beaf93b3f`; vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- `.github/provider-locks/arrow-avro.lock` — SHA-256 `0aae606673b85fa3d8f28f695d283bf85679cd418b12735df1e0ca93d4604336`; vortex_0_90=0, arrow_parquet_59_3_1=12, vortex_runend=0
- `.github/provider-locks/arrow-ipc.lock` — SHA-256 `e7b0ca692a198801e807e13cec53543f8452668accb4a8a7af4701c888a84a36`; vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
- `.github/provider-locks/orc-rust.lock` — SHA-256 `e2471aeb894fd4d56f3233d8fcb3283861b6f8f4d96cc074068cd67f1a77607d`; vortex_0_90=0, arrow_parquet_59_3_1=70, vortex_runend=0
- `.github/provider-locks/vortex-array.lock` — SHA-256 `ff95a628a094a9047c6f93cea4bbc7ef36b6b4aa7ad047db71fd15ff174b13bc`; vortex_0_90=8, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-buffer.lock` — SHA-256 `fb5f904f1871aa50136f7af2d0b604e4179a7a1fb9aa01b78e290e7514f0fd67`; vortex_0_90=2, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-datetime-parts.lock` — SHA-256 `189b24201e8aad1085b14e460a8542d0180ad28cc67d8865faee613fc663399b`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-file.lock` — SHA-256 `3d81a493a945ee62d4944d69b58c50a9ae3a682195f39ccbca3d09d9946e9076`; vortex_0_90=31, arrow_parquet_59_3_1=7, vortex_runend=5
- `.github/provider-locks/vortex-fsst.lock` — SHA-256 `cde54f0e06d84562b78da9dedd1e9c6d15eddf2c0bad3864a17654d59304238d`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-io.lock` — SHA-256 `0e9589fdb25f6bf2402e3c17cf67875e9368f05bf45f2471546f91a448277217`; vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-layout.lock` — SHA-256 `4f0a7ca8f2abb6c302c44005b89bbe66e6cd1ceefb093eb6c30b50b27fc1bf52`; vortex_0_90=26, arrow_parquet_59_3_1=7, vortex_runend=4
- `.github/provider-locks/vortex-runend.lock` — SHA-256 `43e31416946dabd8a28e67d507b651e92650a9d3131948fd22feb0a4f155cdca`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=1
- `.github/provider-locks/vortex-zstd.lock` — SHA-256 `d4aa052230f037aede67cbc3bea86fa3f678c6d35d74a6777d08912b5d9df1ba`; vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
### root Cargo.lock
- `Cargo.lock` — SHA-256 `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772`; vortex_0_90=33, arrow_parquet_59_3_1=15, vortex_runend=6
### fixture/provider locks
- `shardloom-vortex/tests/fixtures/independent-vortex-0.85/producer/Cargo.lock` — SHA-256 `587dd379ebb68158a156f29aba9d968f29371be8594f31c514ad85b046a6ee8b`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- `shardloom-vortex/tests/fixtures/native-exchange/producer/Cargo.lock` — SHA-256 `4fd19ca8f7c4ac6e908f36be3eb72118103d14d6be90302737e19dcaf1d7d88a`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=5

## Grouped Cargo manifests

### workspace/provider Cargo.toml manifests
- `Cargo.toml` — SHA-256 `3772bd45fd74887643e0788b904be8abb704a0a75c1b7e53963ca1befe3ddf71`; vortex_0_90=2, arrow_parquet_59_3_1=6, vortex_runend=3
  - L11: `exclude = ["vendor/arrow-array", "vendor/arrow-avro", "vendor/arrow-data", "vendor/arrow-ipc", "vendor/orc-rust", "vendor/parquet", "vendor/vortex-array", "vendor/vortex-buffer", "vendor/vortex-datetime-parts", "vendor/vortex-file", "vendor/vortex-fsst", "vendor/vortex-io", "vendor/vortex-layout", "vendor/vortex-runend", "vendor/vortex-zstd"]` [exact]
  - L28: `vortex-runend = { path = "vendor/vortex-runend" }` [exact]
  - L47: `arrow-array = "=59.3.1"` [exact]
  - L50: `arrow-avro = { version = "=59.3.1", default-features = false, features = ["deflate", "snappy"] }` [exact]
  - L51: `arrow-flight = { version = "=59.3.1", default-features = false, features = ["flight-sql", "tls-ring"] }` [exact]
  - L52: `arrow-ipc = "=59.3.1"` [exact]
  - L53: `arrow-pyarrow = "=59.3.1"` [exact]
  - L61: `parquet = "=59.3.1"` [exact]
  - L80: `vortex = { version = "=0.90.0", default-features = false, features = ["files", "zstd"] }` [exact]
  - L81: `vortex-zstd = "=0.90.0"` [exact]
- `shardloom-vortex/Cargo.toml` — SHA-256 `9b79b2cd5f93f2892f3a17a864c1fa21a3f5a28555a5a1ae0a4f8e054b34de41`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
  - L104: `vortex-compressor = { version = "=0.90.0", optional = true }` [exact]
### vendor provider Cargo.toml manifests
- `vendor/arrow-array/Cargo.toml` — SHA-256 `45fa3fea7571173d891c16348662507848d428b84cd51bbd71d37d2b8eea158b`; vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
  - L16: `version = "59.3.1"` [exact]
  - L102: `version = "59.3.1"` [exact]
  - L105: `version = "59.3.1"` [exact]
  - L108: `version = "59.3.1"` [exact]
- `vendor/arrow-avro/Cargo.toml` — SHA-256 `b7817d3a0c02de4118e03ceff27a9a0d5579633da8013935d934551221c07fe7`; vortex_0_90=0, arrow_parquet_59_3_1=7, vortex_runend=0
  - L17: `version = "59.3.1"` [exact]
  - L100: `version = "59.3.1"` [exact]
  - L103: `version = "59.3.1"` [exact]
  - L106: `version = "59.3.1"` [exact]
  - L109: `version = "59.3.1"` [exact]
  - L206: `version = "59.3.1"` [exact]
  - L211: `version = "59.3.1"` [exact]
- `vendor/arrow-ipc/Cargo.toml` — SHA-256 `340b99f50362aea502f43071e562ab272a510370c40e3ce8495220265ba23d48`; vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
  - L16: `version = "59.3.1"` [exact]
  - L62: `version = "59.3.1"` [exact]
  - L65: `version = "59.3.1"` [exact]
  - L68: `version = "59.3.1"` [exact]
  - L71: `version = "59.3.1"` [exact]
  - L74: `version = "59.3.1"` [exact]
- `vendor/parquet/Cargo.toml` — SHA-256 `7aff4b45ac6a99f4688a1686016c51a509bac632fe43519199bcf57e80340e8d`; vortex_0_90=0, arrow_parquet_59_3_1=14, vortex_runend=0
  - L16: `version = "59.3.1"` [exact]
  - L355: `version = "59.3.1"` [exact]
  - L359: `version = "59.3.1"` [exact]
  - L363: `version = "59.3.1"` [exact]
  - L367: `version = "59.3.1"` [exact]
  - L371: `version = "59.3.1"` [exact]
  - L375: `version = "59.3.1"` [exact]
  - L379: `version = "59.3.1"` [exact]
  - L472: `version = "59.3.1"` [exact]
  - L476: `version = "59.3.1"` [exact]
  - L480: `version = "59.3.1"` [exact]
  - L484: `version = "59.3.1"` [exact]
  - L540: `version = "59.3.1"` [exact]
  - L550: `version = "59.3.1"` [exact]
- `vendor/vortex-array/Cargo.toml` — SHA-256 `fd87569efbab476134e1df92da1c8e6ecdb51f07c9efd20b0299fb68859aa256`; vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"` [exact]
  - L222: `version = "0.90.0"` [exact]
  - L225: `version = "0.90.0"` [exact]
  - L229: `version = "0.90.0"` [exact]
  - L233: `version = "0.90.0"` [exact]
  - L238: `version = "0.90.0"` [exact]
  - L242: `version = "0.90.0"` [exact]
  - L246: `version = "0.90.0"` [exact]
- `vendor/vortex-buffer/Cargo.toml` — SHA-256 `04771e2b07a2dd39e4ef01a4f8ffe79c772d5694678b5b961ff353ec58e1833e`; vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"` [exact]
  - L101: `version = "0.90.0"` [exact]
- `vendor/vortex-datetime-parts/Cargo.toml` — SHA-256 `88fe98c5930b37c621611b0fd91aa934b8bdc9c177f9aa54b594ea129faf8693`; vortex_0_90=9, arrow_parquet_59_3_1=0, vortex_runend=0
  - L16: `version = "0.90.0"` [exact]
  - L55: `version = "0.90.0"` [exact]
  - L59: `version = "0.90.0"` [exact]
  - L63: `version = "0.90.0"` [exact]
  - L67: `version = "0.90.0"` [exact]
  - L71: `version = "0.90.0"` [exact]
  - L75: `version = "0.90.0"` [exact]
  - L92: `version = "0.90.0"` [exact]
  - L97: `version = "0.90.0"` [exact]
- `vendor/vortex-file/Cargo.toml` — SHA-256 `ee570c5aee3d89fc8398d143f4e94699b13057ece06f5ca0134150d1de073006`; vortex_0_90=31, arrow_parquet_59_3_1=0, vortex_runend=1
  - L17: `version = "0.90.0"` [exact]
  - L125: `version = "0.90.0"` [exact]
  - L129: `version = "0.90.0"` [exact]
  - L133: `version = "0.90.0"` [exact]
  - L137: `version = "0.90.0"` [exact]
  - L141: `version = "0.90.0"` [exact]
  - L145: `version = "0.90.0"` [exact]
  - L149: `version = "0.90.0"` [exact]
  - L153: `version = "0.90.0"` [exact]
  - L157: `version = "0.90.0"` [exact]
  - L161: `version = "0.90.0"` [exact]
  - L165: `version = "0.90.0"` [exact]
  - L169: `version = "0.90.0"` [exact]
  - L173: `version = "0.90.0"` [exact]
  - L177: `version = "0.90.0"` [exact]
  - L181: `version = "0.90.0"` [exact]
  - L185: `version = "0.90.0"` [exact]
  - L189: `version = "0.90.0"` [exact]
  - L192: `[dependencies.vortex-runend]` [exact]
  - L193: `version = "0.90.0"` [exact]
  - L197: `version = "0.90.0"` [exact]
  - L201: `version = "0.90.0"` [exact]
  - L205: `version = "0.90.0"` [exact]
  - L209: `version = "0.90.0"` [exact]
  - L213: `version = "0.90.0"` [exact]
  - L218: `version = "0.90.0"` [exact]
  - L223: `version = "0.90.0"` [exact]
  - L227: `version = "0.90.0"` [exact]
  - L255: `version = "0.90.0"` [exact]
  - L260: `version = "0.90.0"` [exact]
  - L265: `version = "0.90.0"` [exact]
  - L270: `version = "0.90.0"` [exact]
- `vendor/vortex-fsst/Cargo.toml` — SHA-256 `afcabb8a63f5bbbb7553a1cd716604034293a62b3d9bf376f9c7961b9d32e0c4`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"` [exact]
  - L71: `version = "0.90.0"` [exact]
  - L75: `version = "0.90.0"` [exact]
  - L79: `version = "0.90.0"` [exact]
  - L83: `version = "0.90.0"` [exact]
  - L87: `version = "0.90.0"` [exact]
  - L107: `version = "0.90.0"` [exact]
- `vendor/vortex-io/Cargo.toml` — SHA-256 `5aa7bae1dcfd7da9b181181c6030dc8bd4f799b88edf928af9a434d3c5a3b6e5`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"` [exact]
  - L120: `version = "0.90.0"` [exact]
  - L124: `version = "0.90.0"` [exact]
  - L128: `version = "0.90.0"` [exact]
  - L132: `version = "0.90.0"` [exact]
  - L136: `version = "0.90.0"` [exact]
  - L140: `version = "0.90.0"` [exact]
- `vendor/vortex-layout/Cargo.toml` — SHA-256 `b22910b7cce444ff31836f525cbe4cb62ae2f2a4cc710362d7e3135b70321b19`; vortex_0_90=16, arrow_parquet_59_3_1=0, vortex_runend=1
  - L17: `version = "0.90.0"` [exact]
  - L152: `version = "0.90.0"` [exact]
  - L156: `version = "0.90.0"` [exact]
  - L160: `version = "0.90.0"` [exact]
  - L164: `version = "0.90.0"` [exact]
  - L168: `version = "0.90.0"` [exact]
  - L172: `version = "0.90.0"` [exact]
  - L176: `version = "0.90.0"` [exact]
  - L180: `version = "0.90.0"` [exact]
  - L183: `[dependencies.vortex-runend]` [exact]
  - L184: `version = "0.90.0"` [exact]
  - L188: `version = "0.90.0"` [exact]
  - L192: `version = "0.90.0"` [exact]
  - L196: `version = "0.90.0"` [exact]
  - L200: `version = "0.90.0"` [exact]
  - L251: `version = "0.90.0"` [exact]
  - L255: `version = "0.90.0"` [exact]
- `vendor/vortex-runend/Cargo.toml` — SHA-256 `b409dd238dcbe22b4a17031c78aadf01feb6f9427202646fcfecf98a34b132dc`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=2
  - L16: `name = "vortex-runend"` [exact]
  - L17: `version = "0.90.0"` [exact]
  - L51: `name = "vortex_runend"` [exact]
  - L68: `version = "0.90.0"` [exact]
  - L72: `version = "0.90.0"` [exact]
  - L76: `version = "0.90.0"` [exact]
  - L80: `version = "0.90.0"` [exact]
  - L84: `version = "0.90.0"` [exact]
  - L107: `version = "0.90.0"` [exact]
- `vendor/vortex-zstd/Cargo.toml` — SHA-256 `b5cf9c5d1c4488cd69f4a07ec2caeab1641d6fe169f1150e552ccc15ebe55397`; vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"` [exact]
  - L61: `version = "0.90.0"` [exact]
  - L65: `version = "0.90.0"` [exact]
  - L69: `version = "0.90.0"` [exact]
  - L73: `version = "0.90.0"` [exact]
  - L77: `version = "0.90.0"` [exact]
  - L81: `version = "0.90.0"` [exact]
  - L102: `version = "0.90.0"` [exact]

## Excluded historical benchmark evidence

Files excluded: 52. Their paths, SHA-256 values and literal counts are in JSON under `excluded_historical_benchmark_evidence`.
- `docs/benchmarks/evidence/compact-index-acceptance-source-764.json` — SHA-256 `021867bd6eb39bcc77e9285106249e214fa92e2b4cf6d0f7b88967e12d23f000`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- `docs/benchmarks/evidence/dependency-intake-2026-11-02/acceptance.json` — SHA-256 `dcaeb5d8b0d3ccaa31d1d9912ff9c01fdf2757e0e7867103ec02baf9eba0e66d`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/merge-tail-restoration-778.json` — SHA-256 `26d03c39492c282db2465fdbee65ac26e92a9f5a8f9322e656eaa18dca6b3e79`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- `docs/benchmarks/evidence/native-adaptive-decisions-acceptance-2026-11-02/acceptance.json` — SHA-256 `a8c22699c344853b633ee7a9ddc0befd71c0a3aba0a23b3ea0061fc34ea2f21c`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-adjacent-parquet-reads-2026-10-31/manifest.json` — SHA-256 `884c44c8f8df62d87ceba7426c107d9fba669e7818c796c02041fe2f5e4b8380`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-exchange-2026-10-21/postchecks.json` — SHA-256 `e1977aa5350680d87e5dedb81088aede0089feb53db34774e77dce1a3cf88671`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-exchange-prerequisites-2026-10-20/native-encoded-exchange-acceptance.json` — SHA-256 `8660edf79bdae29bdd95201c91db2d4bb087a943c63b02f1600f96a50b44135a`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-exchange-prerequisites-2026-10-20/record_native_exchange_833.py` — SHA-256 `e7ab49df10714ffc775a92fd858e72bce4591f8a8591d278fbbcc39dc31ce210`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/combined-controls-r1-profile/attempts.jsonl` — SHA-256 `5f410a471bd3a3408490c5fa32d1bd102c3ccd1a1ef020670d64471f905fa77c`; vortex_0_90=5, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/combined-controls-r1/attempts.jsonl` — SHA-256 `860afb5762c79e2551cb4ecb703aeb0315d4a1a7b2e2a28091038220c5e69ae9`; vortex_0_90=55, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/selection-controls-r1/attempts.jsonl` — SHA-256 `157dfe762df9b1363be2dae4d57fb47190dc7e71d03f789d9226343a989eab46`; vortex_0_90=31, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-grouped-cost-2026-10-31/manifest.json` — SHA-256 `56cbd03f6a176dd5d4c60d971d53eeb1f5b1ea463d00000a2fadc0fff0733242`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=27
- `docs/benchmarks/evidence/native-grouped-state-access-2026-10-31/manifest.json` — SHA-256 `0c33e84017bab6451696f15a9701c2368cea2f2ceb27a2f1f68412add1b4d266`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-grouped-state-ci-correction-2026-10-31.json` — SHA-256 `281fae785001b0d4cc1e1869a2e02387f035d1f4d8cb9c02fed917fe6bd9d5dc`; vortex_0_90=27, arrow_parquet_59_3_1=3, vortex_runend=2
- `docs/benchmarks/evidence/native-ingest-ownership-2026-10-25/verify.py` — SHA-256 `c019525e4098febca4a334bc623f8a7482e7c33c88469b2b8b8f0b935c6c2f55`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/compact-group-protocol-r1.json` — SHA-256 `9a8d6a842b4a79ea5286676ad3f1ef2fa3f9e6721c71d2669c78267f96a7b98d`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/group-hash-demand-protocol.json` — SHA-256 `f255abe9abb248c485dc6d65ef95232ca77b7556dfa5361bbdc036be0dc8a373`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol-v2.json` — SHA-256 `ec8d16297897d1dc54e37974e62ecf180730873eb8cb3505109ea23aaea63e2d`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol-v3.json` — SHA-256 `3c06d60f81bfdca55db40edc046d6bdf3f143c2dc25738d86dbffcec8e6f7ef9`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol.json` — SHA-256 `d2ab042341477d085ddde3af922d5972a403a5b6213be451a844721afee21067`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/mixed-integer-expression-protocol.json` — SHA-256 `573c9d083b72e826a5a4d10d4ace23bb23c33ff3a46831126819be28ecfb17dc`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/positive-gain-recovery-protocol.json` — SHA-256 `3ae5891b3bb4666e2d19d1efe96fb49627cf7914910b99793a73f248fa686066`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/selected-payload-correctness-addendum.md` — SHA-256 `80b6316d0a5ec0abc4b021953a891e363e393de773715081ec21392a961117a1`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/selected-payload-validation-protocol.json` — SHA-256 `c0c847c3ef7e86ca0183f9a1b59e1b4d98fb111cda7fd85043019261a48f4e90`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-item20-completion-2026-10-28/typed-numeric-expression-protocol.json` — SHA-256 `7bbe21d5f549ef57f5b0dc9e6d910af59500ecf9cae7bcbd095cc83bb0a3962f`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-local-io-portable-2026-11-03/metadata/manifest.json` — SHA-256 `0974640fe88aa466d1eca2b282a26c186a5ba3ffb4dda4491bda67e5e6f3b895`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-local-table-reader-review-2026-11-02/acceptance.json` — SHA-256 `36042a400f3373b04778c64bb85a27b47795f56ed9d7f183b9386f2147163942`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-local-table-readers-2026-11-02/acceptance.json` — SHA-256 `d4ebe7e3e5b4d3f522612beb5137147971080dd2570fb928f8f6e6b6a1c5adcd`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-ordered-inputs-2026-10-31/manifest.json` — SHA-256 `3962bd8db9aaa5cbe8b24556e76c195acb35ba7305c1949799c3c0f362596312`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-performance-batch-2026-10-31/manifest.json` — SHA-256 `05f617c5829ececb006a7ea0b746c81388ac70f55c0961f370915ab8a50496eb`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=56
- `docs/benchmarks/evidence/native-preparation-contracts-2026-11-02/acceptance.json` — SHA-256 `a3e1a50d44105efd4881d4f676c935a07b7451e599002b3c3d8d8978f5d17004`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-shared-followthrough-2026-10-30/manifest.json` — SHA-256 `0a5390883939e53cb518d1d6208806c8feca108ad5258f4afa27ac1c46f58d53`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-shared-performance-2026-10-30/manifest.json` — SHA-256 `5e2a66840fb2ba0f7a81cd9ecdaadecce69abd0170bd6fda3339233ab91e640e`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=56
- `docs/benchmarks/evidence/native-single-predicate-masks-2026-10-30/manifest.json` — SHA-256 `d45e84568bf56a5d0fc65c0aac1d138edbd58a8b12eb926de643928509ca75be`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-structural-provider-2026-10-21/verify_acceptance.py` — SHA-256 `96acca81f1c9baf4686e2e7e58b4bb3ae2c667732cffe6b8fb50c96ad4f655cd`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- `docs/benchmarks/evidence/native-surface-parity-2026-10-24/ci-repairs.json` — SHA-256 `17f7d9ecd6ef71b7faa98724fe4887098430ebbab89efd7ecec83b7edaed1a64`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- `docs/benchmarks/evidence/native-typed-ordering-2026-10-31/manifest.json` — SHA-256 `b59009f81927c84bb8e2b27d8637b57f6242bb133b847426de4a83a2b137d0cc`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-typed-reductions-package-checker-2026-10-05.json` — SHA-256 `ef0fa625f8bf6b4cceb15eef00bfea284ad8540c8721b06ebf8be04e704f636c`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- `docs/benchmarks/evidence/native-varbin-metadata-resources-2026-10-16.json` — SHA-256 `304ee5884c5552044fed1e3e8d114a7826ec830fee728e49f6ebb2e0a960889a`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-varbin-metadata-review-2026-10-16.json` — SHA-256 `50ff9b0e0f6dac0712a86345ebcd4c0d7fc480bc26a1dcf7be3a900a0e6e34ec`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-check-repair.json` — SHA-256 `6cda58c911aa28a32b942e7081441c3f27238983374ca82d7a4dc16a6ef5735f`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-scripts-local-r1.log` — SHA-256 `7a3772ab99ec736d619e97d1cdfa51ac2afa5ccfc18b8108af4a4ebd5a252ab5`; vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-scripts-remote-r1.log` — SHA-256 `933720bd03ff1de7c257f216f43548e91779089a15cd502dc67c5c43534d5bb1`; vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/clean-checkout.json` — SHA-256 `ffb0e790945b02041617d3532b21fd7054f69aae2410cf85b4c3ff204aa5cd6b`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/manifest.json` — SHA-256 `bf99431f11d4f3cfee6df9d4584fba31b557a1d3bdc3b35f8f7d8685d3262982`; vortex_0_90=61, arrow_parquet_59_3_1=55, vortex_runend=4
- `docs/benchmarks/evidence/native-warm-source-reuse-2026-10-25/cleanup.json` — SHA-256 `1e3bcb2ec5b9ea9a20c912945bf6c7c2aa6e74c44d0c447376fff9c0b8ed136c`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- `docs/benchmarks/evidence/nested-identity-restoration-762.json` — SHA-256 `60a593aad0a0d42c8bbd061d88643b1ffa2a6d4397cc786a152d528880b5e1b0`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- `docs/benchmarks/evidence/nested-key-attribution-760.json` — SHA-256 `001cab8fa974c890d49190d3c84f55a8b9086d594d942ab114da9ee10a4aa04e`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=4
- `docs/benchmarks/evidence/predicate-exclusion-restoration-770.json` — SHA-256 `307c98927a7526a5b4d2c20817f3fac07b6a12c4e2087794e110f2bed4bcfaf3`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- `docs/benchmarks/evidence/prepared-sampling-2026-10-21/verify_acceptance.py` — SHA-256 `d658cc0da3f7937d3a0f063946de5d13074515ac3375a46702e2654ccc3dfc10`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- `docs/benchmarks/evidence/rematerialization-restoration-780.json` — SHA-256 `cedd6dd685e61e64e10407cf2943766405ddb1bdac19333590315544ddf41def`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- `docs/benchmarks/evidence/required-execution-resources-shared-writers-2026-10-10.json` — SHA-256 `be02d72260a7f5aaf4948274bfd092dba030f8db13ff75340a19c4949196dcb5`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1

## Architecture status not classified

Files: 55; matches: vortex_0_90=93, arrow_parquet_59_3_1=31, vortex_runend=3. The r1 blanket exclusion is preserved as a historical scope fact and superseded for r2 coverage by this list. No current/historical classification is made.
### `docs/architecture/compact-candidate-directory-screen-2026-09-27.md`
- SHA-256 `98edcf9308fa76fa1e40e81b38658fa40c87a73d1fab6831c9099ea9a19c4815`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L98: `(3.94%). The earlier '443a532' revision recorded 0.90% lower best time and 0.70%` [exact]
### `docs/architecture/compression-dependency-intake-2026-10-26.md`
- SHA-256 `d0b74f1c63d79cb28ecbae495798129ff13d2b1a9585d96df8a36df953d45251`; counts: vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- L26: `Retain the single Arrow/Parquet 59.3.1 graph, ORC 0.9.0, Vortex 0.90.0 and bundled` [exact]
- L53: `- Decision: 'use_vortex_native_provider'; preserve the existing Vortex 0.90.0` [exact]
### `docs/architecture/dependency-intake-2026-10-25.md`
- SHA-256 `ee513fa2f122a91e05ec73682bb5dda6a95507abbe31a4fd5ceed8f4a397714b`; counts: vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- L24: `| [#1602](https://github.com/depsilon/shardloom/pull/1602) | One Arrow/Parquet 59.3.1 graph | Selected Arrow packages at 60.0.0 | Blocked until the complete Vortex/Arrow/Parquet/Python graph is compatible |` [exact]
- L37: `while IPC and the admitted provider graph remain on 59.3.1. Its lockfile adds` [exact]
- L47: `59.3.1, Vortex 0.90.0, prost-types 0.14.3 and the existing ORC-side prost 0.13.5` [exact]
### `docs/architecture/dependency-intake-2026-11-02.md`
- SHA-256 `13d15c691d5f74354d70cfde879ef7efcb1e96e181b98c21190136e6e6a69fa2`; counts: vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- L23: `package names. Arrow/Parquet remain on 59.3.1, Vortex on 0.90.0 and tonic-prost` [exact]
- L106: `crates to 60.1.0 while other consumers retain 59.3.1. Its MSRV build fails on` [exact]
### `docs/architecture/dependency-intake-2026-11-08.md`
- SHA-256 `8f124489506339b167493068daaf489160d8f4d3fdc586b0d5e86482242a1ac0`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L57: `the current 0.90 zstd path and leaves six retained provider patches unused. Its` [exact]
### `docs/architecture/native-adaptive-execution-2026-11-01.md`
- SHA-256 `59ce0468c9c5eee507650ade8b1225bbb4f5d26ac773df6fe500a4455e1be284`; counts: vortex_0_90=3, arrow_parquet_59_3_1=6, vortex_runend=0
- L122: `| Arrow Avro 59.3.1 | No defaults; Deflate/Snappy, then optional custom types/small decimals | 427 and 448 tests pass; strict library/test lint passes. |` [exact]
- L123: `| Arrow IPC 59.3.1 | LZ4/Zstandard, then default features | 154 and 145 tests pass; strict library/test lint passes. |` [exact]
- L438: `0.90 scan preparation supports explicit row ranges, natural split boundaries,` [exact]
- L478: `Vortex-first decision: use the existing Vortex 0.90 bounded native writer and` [exact]
- L549: `The pinned Parquet 59.3.1, Arrow Avro 59.3.1 and ORC 0.9 reader builders accept a` [exact]
- L617: `none ignored or filtered, using original fixtures from the exact Arrow 59.3.1` [exact]
- L816: `'bytes' version; the new reviewed standalone lock preserves Arrow 59.3.1. The` [exact]
- L1050: `Vortex-first provider check: 'wrap_vortex_concept'. The existing Vortex 0.90` [exact]
### `docs/architecture/native-adjacent-parquet-reads-2026-10-31.md`
- SHA-256 `d5a72b6d4c3581fcddf8c0d98843270103279e6e0a1a6c197f5682b3aad0c8c8`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L37: `compatibility-import read owner. Pinned Vortex 0.90.0 exposes positional reads` [exact]
### `docs/architecture/native-ai-data-workflows-2026-10-24.md`
- SHA-256 `6eaa75a812f47ec18964a3a1c020fbce364dd377020d805e7055e0d515581242`; counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L54: `implementation proof. In 0.90 the preview declaration is empty; that does not` [exact]
- L56: `the exact 0.90 crates, features, registration and callable paths when this` [exact]
- L63: `The [controlled 0.90 refresh](native-vortex-provider-refresh-2026-10-24.md)` [exact]
### `docs/architecture/native-analytical-completion-2026-10-27.md`
- SHA-256 `a3130d1996607bed1b13a847ce211bd2877623048029e457878a8093049904a1`; counts: vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- L753: `Vortex-first decision: wrap existing Vortex 0.90.0 array ownership, primitive` [exact]
- L801: `already admitted in Vortex 0.90.0. 'Columnar' yields a canonical array or a native` [exact]
- L1108: `Vortex-first review checks the pinned 0.90 primitive arrays, masks, dictionary` [exact]
- L1149: `validation and ownership policy around already-admitted Vortex 0.90.0 providers.` [exact]
- L1446: `The pinned Vortex 0.90.0 aggregate registry has no flat relational list-collect` [exact]
- L1521: `aggregate state, over the existing admitted Vortex 0.90.0 arrays/providers.` [exact]
- L1617: `The pinned Vortex 0.90.0 provider already defines Date, Time and Timestamp` [exact]
### `docs/architecture/native-application-batch-functions-2026-10-30.md`
- SHA-256 `ddb72e9a3d5bf2a1704bba82d5270b1bb550b3cbd67e3ee13cccbbe9b80a7856`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L85: `the scoped callback dispatch, using existing Vortex 0.90.0 arrays, DTypes,` [exact]
### `docs/architecture/native-broad-query-program-2026-10-26.md`
- SHA-256 `994597c4064f3754ea6d058ddb458b2c6e28a99524da9bf4166148dee2f7a27c`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L283: `Vortex-first check: the pinned dependency is Vortex '0.90.0' with the repository's` [exact]
### `docs/architecture/native-connected-programming-model-2026-10-24.md`
- SHA-256 `bcf6084dd2a089838ddadd93ac8442415e50825203d72a3e9a5044012620f2cb`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L220: `than upstream array or scan APIs. Reuse the admitted Vortex 0.90 provider through` [exact]
### `docs/architecture/native-decimal-output-2026-10-29.md`
- SHA-256 `fef396aac9f52716d7638822b7d863e162f1a1f251ddd1608462f5aed8b0f0d0`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L69: `The workspace pins Vortex 0.90.0 and patches 'vendor/vortex-array'; an initial` [exact]
### `docs/architecture/native-dense-embedding-lifecycle-2026-11-05.md`
- SHA-256 `a82d57c7df7a4d80ac77005859503e5894f12777fb3c4c1470ebb150a3db16a7`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L79: `Checked Vortex 0.90.0's local 'ExtVTable', 'ExtDType', dtype serialization,` [exact]
- L140: `59.3.1 dependency graph. The correction's rebuilt runtime and installed-package` [exact]
### `docs/architecture/native-direct-source-count-2026-10-31.md`
- SHA-256 `fa2edad57739a110e2d9720977d4f60f3307b7dcbcb7d465bfafb62c5b2a53e0`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L99: `new source abstraction or delegating execution. Vortex 0.90.0 already exposes` [exact]
- L101: `not describe a direct Parquet inventory. The pinned Parquet 59.3.1 metadata` [exact]
### `docs/architecture/native-encoded-exchange-protocol.md`
- SHA-256 `43f94d848e04262febad91a23308e7c267ef5c0fcfe10ad4f8ec8dfbe69d361f`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L93: `is conceptual: its navigation now shows 0.90 draft and 0.89 released. The local` [exact]
### `docs/architecture/native-exchange-experiment-plan-2026-10-20.md`
- SHA-256 `674f9812776d8741973dcf281d86ef6d6f7e3b62d102d53ab971f3ca691a9618`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L219: `   complete-workflow ratios is at most 0.90 against **each** Arrow codec role.` [exact]
### `docs/architecture/native-fixed-tensor-lifecycle-2026-11-07.md`
- SHA-256 `b60903941f85e24796dbd93b2f9f7b8397ef31a8c99d57f9e463eb438b5b10f5`; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L19: `The pinned Vortex 0.90.0 provider already has native 'ExtensionArray',` [exact]
- L24: `The optional published 'vortex-tensor' 0.90.0 source was checked against its` [exact]
### `docs/architecture/native-float-policy-2026-10-29.md`
- SHA-256 `6273f8980346419f52e69c59a1d34952eb2bf6855b57916d859c2031d024a3fb`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L105: `The pinned Vortex 0.90 primitive/scalar implementation uses Rust 'total_cmp'` [exact]
### `docs/architecture/native-float16-lifecycle-2026-11-07.md`
- SHA-256 `f34b89a00ed52bafd8ff1d4d1dec977b97c56c28b2b4dea0d32fdc4770cbb35e`; counts: vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- L72: `The resolved provider graph is Vortex 0.90.0, 'half' 2.7.1, Arrow array/IPC` [exact]
- L73: `59.3.1 with schema 59.3.2, and Parquet 59.3.1. These are existing dependencies;` [exact]
### `docs/architecture/native-foundry-integration-2026-10-25.md`
- SHA-256 `93cfd4bf41c6c3ed6d07bcf7e18c3a6db8b2e525bf3f7a8b752e57b7f5138693`; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L73: `Rust Arrow 59.3.1 does not prescribe the same Python PyArrow version number.` [exact]
### `docs/architecture/native-fused-measure-encoding-correction-2026-10-25.md`
- SHA-256 `82ddae17acf45008a773c268cd61256d3ccd87516f863e00b7f16cf0f70ac984`; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L23: `the pinned Vortex 0.90.0 build reproduces the composed scan projection and` [exact]
- L43: `This is 'use_vortex_native_provider': pinned Vortex 0.90.0 array execution,` [exact]
### `docs/architecture/native-fused-measure-work-elimination-2026-10-25.md`
- SHA-256 `43f1559e42b0583e0c49c380f24be4b317a7fc5931d327d8e62a9c5948bbfff9`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L25: `Pinned Vortex 0.90.0 provides the existing ArrayRef, Dict, native primitive,` [exact]
### `docs/architecture/native-grouped-cost-attribution-2026-10-31.md`
- SHA-256 `f08f3968af0495d232373e78681a713c5745260dac0f005eff5227bd9f96698d`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L86: `prepared-key and source boundaries around Vortex 0.90.0; no provider or kernel` [exact]
### `docs/architecture/native-grouped-state-access-2026-10-31.md`
- SHA-256 `598037f37adaca30616e63e7819ac6a8b72252d3c30290524ab5f2889c3df440`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L30: `ShardLoom flat grouped-state owner. The pinned Vortex 0.90.0 provider and the` [exact]
### `docs/architecture/native-ingest-ownership-preparation-2026-10-24.md`
- SHA-256 `b314ae671af70ce180c5aa00bc144a455996eecfd5d282159c35200c22ba223f`; counts: vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- L101: `as the current 0.90 API baseline; re-evaluate allocator propagation and` [exact]
- L138: `The provider check uses pinned Arrow 59.3.1 buffer/data APIs and Vortex 0.90` [exact]
### `docs/architecture/native-join-count-work-elimination-2026-10-25.md`
- SHA-256 `0a76466c5f46e5726db8f7df3fcb3459204660e54ac5d7ce7683fee81d2645a1`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L48: `Vortex-first check: pinned Vortex 0.90.0 supplies native arrays, builtins,` [exact]
### `docs/architecture/native-managed-binary-objects-2026-11-06.md`
- SHA-256 `0d2835231ec5f4008ce9ff9aa02f91af6b585a72e6bb346160c972bfc0cd6918`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L41: `The checked provider is the pinned Vortex 0.90.0 graph and its reviewed local` [exact]
### `docs/architecture/native-multi-output-work-elimination-2026-10-25.md`
- SHA-256 `3d6b01bdb177f37d2dae51e32ae3a80de7872727349ada0f499054da27926970`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L25: `Pinned Vortex 0.90.0 supplies native arrays, allocation owners, file streams and` [exact]
### `docs/architecture/native-multiway-join-comparison-design-2026-10-20.md`
- SHA-256 `2074c171da0d32eee7170627ea6d3d9b262b09f6c1d20aa236cce4a3c2cddf76`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L143: `  cost and complete cost by at least 10% (candidate/ordinary median <= 0.90).` [exact]
### `docs/architecture/native-ordered-inputs-2026-10-31.md`
- SHA-256 `13b9116e8161ff38f9c87777dc9b0bbcdda96526dac83ec62ffffcfe252bee73`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L32: `Vortex 0.90.0 supplies prepared arrays, validity and encoded value execution.` [exact]
### `docs/architecture/native-parquet-demand-completion-2026-10-26.md`
- SHA-256 `418df812733914548cbd28d7e6e0f83acd547398f58e6c031730f9752524daa0`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L82: `The pinned Vortex 0.90.0 array, projection/filter, selection and native-output` [exact]
- L85: `Parquet 59.3.1 supplies metadata, column chunks, row selections and decoding.` [exact]
### `docs/architecture/native-performance-batch-2026-10-31.md`
- SHA-256 `b09ceb54adc58429820cf7e36e9ce09bc6f0a28154e536fab5078802dfce99dc`; counts: vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- L107: `Pinned Vortex 0.90 array/compute providers already own Constant/RunEnd, primitive` [exact]
- L113: `The patched Parquet 59.3.1 source provides offset indexes, selected page locations,` [exact]
- L189: `  Sliced RunEnd fixtures use Vortex 0.90's validated` [exact]
### `docs/architecture/native-preparation-query-investigations-2026-11-02.md`
- SHA-256 `16ce567025ae1d1e47bd74e79b3e18861638f9c2a96a16837162cfa0054e41fc`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L144: `Vortex-first provider check: B uses the existing Apache-2.0 Vortex 0.90.0 Zstd` [exact]
### `docs/architecture/native-recursive-composition-2026-10-29.md`
- SHA-256 `3304e339c9e2f41eead220f0bf401a6c7874f805c2fff51449a4ca91056c9923`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L28: `action-scoped reuse, while reusing the admitted Vortex 0.90 array providers,` [exact]
### `docs/architecture/native-rich-data-lifecycle-2026-10-24.md`
- SHA-256 `91842e0f00a0b2a76bea73f88ec4be51f761b571f9fc419bc81b9d0848284e0a`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L106: `The subsequent 0.90 intake establishes a concrete Parquet Variant provider,` [exact]
### `docs/architecture/native-runtime-completion-2026-09-20.md`
- SHA-256 `c8a1fe846ec3f91bb575b41a81c2f86d21a9f5d9869ec475a9ff155eb1b2d7eb`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L159: `serving or broad SQL parity. Candidate per-case medians were 0.40–0.90 ms for the` [exact]
### `docs/architecture/native-selection-retention-2026-11-04.md`
- SHA-256 `d1b1958f46610f5124e47019cd2ea474ccdb9c22e8e2a9628caa43159912477b`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L32: `The pinned Vortex 0.90 provider supplies native 'ArrayRef::take', casts,` [exact]
### `docs/architecture/native-shared-performance-2026-10-29.md`
- SHA-256 `9531028c174c83f306cf10e9be6c394f0c597740351d21a19b174d87446f2934`; counts: vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- L70: `LIMIT/Project/Sort contract. The pinned 0.90 provider and no-fallback boundaries` [exact]
- L193: `0.90 and native Vortex input/output contracts stay unchanged.` [exact]
- L479: `or array implementation. Pinned Vortex 0.90 already supplies field/filter/take,` [exact]
- L657: `Vortex-first decision: reuse pinned Vortex 0.90 'VarBinViewArrayExt::utf8_slice_at',` [exact]
- L846: `Vortex-first decision: reuse pinned Vortex 0.90 primitive/validity/array owners` [exact]
- L969: `owner, borrowing the already admitted Vortex 0.90 'PrimitiveArray'/'Mask' owners.` [exact]
- L1064: `test evidence around Vortex 0.90 'ArrayRef::nbytes' and existing ShardLoom owned` [exact]
### `docs/architecture/native-shared-work-reduction-2026-11-03.md`
- SHA-256 `a0344b952a47cf00037289e41017b62254529aca8bcb8d126a68405c4229fea3`; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L95: `The pinned Vortex 0.90 provider supplies native arrays, take, casts, masks,` [exact]
- L172: `pinned 0.90 provider. The diagnostic instrumentation stays in its separate` [exact]
### `docs/architecture/native-single-predicate-masks-2026-10-30.md`
- SHA-256 `307a98bf0e7deee28fa23c8c5f9e74234e5c495ca0f09fdec97c33f2e917589d`; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L34: `ShardLoom program. Pinned Vortex 0.90.0 has allocated primitive comparison arrays,` [exact]
- L38: `'vortex-mask-0.90.0/src/lib.rs'. Reuse Mask/BitBuffer and the session allocator.` [exact]
### `docs/architecture/native-source-demand-2026-10-26.md`
- SHA-256 `33adbb1ba0a8aea4cb587a7fada1f24a285ea10db9ce1b2a49e52a11544e781e`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L35: `Pinned Vortex '0.90.0' supplies DType, owned arrays, Arrow interoperability,` [exact]
- L39: `Parquet '59.3.1' supplies metadata and column/row-group decoding only. It never` [exact]
### `docs/architecture/native-time-series-completion-2026-10-29.md`
- SHA-256 `be5ad144498a5a0a361a786e3683a5f3ef0d1a6b14329c0cc312c4311b808b2d`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L190: `Vortex-first decision: 'implement_shardloom_kernel'. The pinned Vortex 0.90.0` [exact]
### `docs/architecture/native-typed-ordering-2026-10-31.md`
- SHA-256 `be8d169c5a681291a2d787a9bd4ae17bb8b121e4be6c933cabaee77b8df3a1eb`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L62: `over pinned Vortex 0.90.0 primitive arrays and validity masks. The checked Vortex` [exact]
### `docs/architecture/native-universal-io-implementation-2026-10-31.md`
- SHA-256 `d1bef6eabdc73395a6de449659e152a6adb1146bf46c0262305c45b958d4a0eb`; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L287: `framing share the Arrow 59.3.1 boundary, including its LZ4/Zstandard codecs.` [exact]
### `docs/architecture/native-varbin-metadata-resources-2026-10-16.md`
- SHA-256 `2463250c5d7abe8a1aff478979ad6eec0153956d871cf95072e9b991330d9a0a`; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L112: `The already-transitive Apache-2.0 'vortex-fsst' and 'vortex-runend' 0.85.0` [exact]
### `docs/architecture/native-variable-tensor-lifecycle-2026-11-07.md`
- SHA-256 `9c952c32a130c8b9236381111283d75f7970b539628d56897168311e0eb3c6da`; counts: vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- L18: `Use the pinned Vortex 0.90.0 extension, struct, list, fixed-size-list, selection,` [exact]
- L19: `native file and spill providers. The checksum-bound 'vortex-tensor' 0.90.0` [exact]
- L36: `provider graph. The same 'arrow-data' 59.3.2 and 'arrow-array' 59.3.1 sources now` [exact]
### `docs/architecture/native-vector-representations-2026-11-07.md`
- SHA-256 `92e23f43c62094c94724b6d0a16c9e3a9a8e18a08b26c3711f2ee56cbf9c6b43`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L54: `The pinned graph remains Vortex 0.90.0, half 2.7.1, Arrow array/IPC/Parquet 59.3.1` [exact]
### `docs/architecture/native-vortex-provider-refresh-2026-10-24.md`
- SHA-256 `998ab5083ebfb179ac1ed6fbbd6b2c6ea2c697fb344ee012e3986ea370ae11af`; counts: vortex_0_90=12, arrow_parquet_59_3_1=3, vortex_runend=2
- L8: `naming and ingestion. The reviewed target is the released Vortex **0.90.0** tag,` [exact]
- L9: `published October 23, 2026. The candidate now resolves Vortex 0.90.0, one` [exact]
- L10: `Arrow/Parquet 59.3.1 graph and ORC 0.9.0. Standalone provider tests, default/native` [exact]
- L43: `published 0.90 archive, and its 87 standalone tests plus four native timestamp` [exact]
- L44: `regressions pass. Upstream Arrow/Python 59.3.1 replaces the separate path patch;` [exact]
- L57: `| [vortex-runend](../../vendor/vortex-runend/README.shardloom.md) | Expanded string/binary views retain their shared data-buffer table and reservation |` [exact]
- L74: `The [0.90 tagged workspace](https://github.com/vortex-data/vortex/blob/0.90.0/Cargo.toml)` [exact]
- L76: `shared 59.3.1 patch graph across array/schema/IPC/Parquet/Avro/Flight/Python` [exact]
- L83: `The [0.90 release](https://github.com/vortex-data/vortex/releases/tag/0.90.0)` [exact]
- L146: `| Scalar/statistics/aggregate and encoded CPU changes: [0.88](https://github.com/vortex-data/vortex/releases/tag/0.88.0), [0.89](https://github.com/vortex-data/vortex/releases/tag/0.89.0), [0.90](https://github.com/vortex-data/vortex/releases/tag/0.90.0) | Identify activated call paths and unchanged ShardLoom-owned operators. Upstream microbenchmarks are not whole-query evidence; DateTimeParts dec` [preview; truncated; original_line_bytes=451; original_line_sha256=`a330dcecc6f526e3e8bdd39bf68a3ff6fe3f5bc35453d03dc3b6dd5092308af9`]
- L168: `The tagged [Parquet Variant implementation](https://github.com/vortex-data/vortex/blob/0.90.0/encodings/parquet-variant/src/lib.rs)` [exact]
- L195: `The [0.90 umbrella features](https://github.com/vortex-data/vortex/blob/0.90.0/vortex/Cargo.toml)` [exact]
### `docs/architecture/native-warm-source-reuse-2026-10-24.md`
- SHA-256 `e3a05c78e2c7530d907561b33b9fbc650eec74b866e8de5015d0d5c825e26e3f`; counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L27: `The candidate uses the accepted Vortex 0.90.0 provider and the same` [exact]
- L165: `admitted 0.90 scan provider before adding infrastructure. V1 can reuse readers` [exact]
- L331: `0.90 provider refresh](native-vortex-provider-refresh-2026-10-24.md) as the API` [exact]
### `docs/architecture/phased-execution-completed-ledger.md`
- SHA-256 `3de27d39e7949c4f7fde183b2f6e6b816881a591b9048cd21fed47269b2cef70`; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L619: `  0.90.0, one Arrow/Parquet 59.3.1 graph and ORC 0.9.0, with eight bounded` [exact]
### `docs/architecture/phased-execution-plan.md`
- SHA-256 `282b2809b7e7c7b1304a2c623d8337eabfd465ff1119deb21e03b71741f5192a`; counts: vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- L669: `10. **Controlled Vortex provider refresh and portable evidence accepted and merged:** the [October 24 intake](native-vortex-provider-refresh-2026-10-24.md) resolves released Vortex 0.90.0 with a single Arrow/Parquet 59.3.1 graph and ORC 0.9.0. Eight retained patches preserve semantic and allocation obligations, including the 'vortex-buffer' empty-owner bridge: explicit empty Bytes/Arrow owners sur` [preview; truncated; original_line_bytes=3013; original_line_sha256=`6893257a4f021f2cb7cb98caf1fe0d62314ee73f2dbe284f9eed46dc65c7db3e`]
- L670: `    - Dependabot consolidation, October 24: [#1568](https://github.com/depsilon/shardloom/pull/1568)'s 'pyo3-build-config' 0.30.1 and [#1582](https://github.com/depsilon/shardloom/pull/1582)'s Parquet 59.3.1 / ORC 0.9.0 are included in this active acceptance work. PyO3 runtime remains 0.29.3 because Arrow/Python 59.3.1 requires that runtime; the independent build helper only supplies extension-mod` [preview; truncated; original_line_bytes=419; original_line_sha256=`fc9cc99a910e3c8314fd9c7291cbea9498d44648a171aad1b8802337767aa423`]
### `docs/architecture/source-backed-dictionary-screen-2026-09-29.md`
- SHA-256 `9ad2fb9efe300190ad22dbcf901a9b737c93a04fe1c3ca41e3d479310f3c90b3`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L258: `| Q17 | 4.197320 s | 4.235176 s | -0.90% | 4.233673 s | 4.660645 s |` [exact]
### `docs/architecture/vortex-adapter-integration-plan.md`
- SHA-256 `bcfc278e7428d09932f78a66650398060382389756052939aa88ebd7eed1cfe3`; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L4: `targets released 0.90.0 after surface parity and before warm-source/ingestion` [exact]
### `docs/architecture/vortex-public-api-inventory.md`
- SHA-256 `a4444d6382bd5ef6c462e2f715a9baee5f086953b522bf35553eddfc664362a5`; counts: vortex_0_90=5, arrow_parquet_59_3_1=0, vortex_runend=0
- L18: `now resolves Vortex 0.90.0 and has completed local runtime/UAT acceptance. The` [exact]
- L113: `  recorded in the [controlled 0.90 refresh](native-vortex-provider-refresh-2026-10-24.md).` [exact]
- L181: `The current 0.90 builder API passes the allocator into supported typed builders;` [exact]
- L227: `0.85 baseline. It is historical evidence, not the current 0.90 API/caller` [exact]
- L252: `adoption map describe that earlier intake; use the [controlled 0.90 refresh](native-vortex-provider-refresh-2026-10-24.md)` [exact]

## Source integrity and verification

- Rechecked all 162 r1 matching-file source hashes; all unchanged.
- Rechecked baseline and clean worktree before generation; source remains at the same baseline.
- No build, network operation, or source edit was performed.
- R1 is unchanged; R2 JSON retains its original facts verbatim and adds the corrected active-scope view.
