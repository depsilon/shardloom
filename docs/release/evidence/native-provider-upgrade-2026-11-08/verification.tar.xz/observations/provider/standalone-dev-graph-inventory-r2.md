# Standalone provider development graph inventory r2

- Repository: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
- Root Cargo.lock SHA-256: `8354a8f33c1a311a7aa92118c5b2a3e8e12d02c923b4015603fa3c45986dbcd3`
- Baseline git commit: `0205283370712637305aba07a86f5854e833da6e`
- Baseline Cargo.lock SHA-256: `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772`
- Current provider lockfiles included and hashed: 15; baseline lockfiles: 14.
- Current provider-lock union identities absent from current root: 248.
- Baseline development-only identities: 232; current development-only identities: 248; added: 35; removed: 19; retained: 213.
- Matching local registry archives: 218; manifest-only: 0; exact local registry source missing: 30.

Input fingerprint: `3fc363c1a2edc0263b8b50ee95beec9d86100bc7214e7f07a9c4f99aeb83bc50`.

## Lockfile comparison

All current provider lockfiles are compared with the current root and exact baseline git objects. JSON records current-root absent identities per lock plus per-lock hashes and package-identity deltas. The current set includes `vortex-arrow.lock`; `vortex-runend.lock` is present only in baseline.

## Package comparison

The JSON lists every current provider-lock package identity absent from current root Cargo.lock, with full name/version/source/checksum, lock uses, local archive/source-manifest findings, and archive/source legal-file hashes. It separately stores the full baseline and current development-only identity sets and their shared/added/removed members.

Local files from the Cargo cache and existing task evidence were hashed at read time; prior r1 records were not accepted without byte/hash confirmation. Missing archive and manifest candidates are explicit. No network or Cargo commands were used. This is inventory only; it makes no license, risk, or acceptance decision.
