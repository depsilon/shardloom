# Resolved graph inventory r2

Baseline Git commit: `0205283370712637305aba07a86f5854e833da6e`

Fixed current Cargo.lock SHA-256: `32ad9bdfd2bf7f8bb4d704b6e26ce982f2ff3b3020e5f8f68a2be667be62b8f1` (unchanged at end).

## Coverage

Manifest evidence records: 104; status counts: `{"verified": 104}`.
Baseline path-provider manifests are read from the exact baseline Git tree; current path-provider manifests are read from the active worktree. Registry manifests are accepted only when a local .crate SHA-256 matches the lock checksum, then the archive Cargo.toml member hash and identity are recorded.
Missing archives remain unresolved; no fetch was attempted. Literal `license` and `rust-version` values are recorded in JSON. No compatibility or security conclusions are made.

## Unresolved or mismatched evidence

- None.

## Changed-package summary

Package additions, removals, updates, and grouped provider versions are preserved from r1; per-record manifest evidence is in `r2_manifest_evidence` in the JSON.
