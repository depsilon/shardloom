# Registry notice inventory r1

Read-only, local comparison of root registry package identities against the existing Python third-party license manifest. This is evidence for primary review, not a license-policy decision.

## Inputs and coverage

- Root `Cargo.lock`: SHA-256 `32ad9bdfd2bf7f8bb4d704b6e26ce982f2ff3b3020e5f8f68a2be667be62b8f1`.
- Existing `THIRD_PARTY_LICENSES/manifest.json`: SHA-256 `1aa755a4b38868954dcf55a71554fa07f498636ef22c6b9449a92c2231153f03`.
- Root registry identities: 432; exact identities already present: 393; selected missing identities: 39.
- Exact local archives checksum-verified: 39/39; Cargo.toml metadata extracted: 39/39.
- Root legal text found for 14/39 packages (26 files); 25 packages remain unresolved because their verified archives contain no root legal file.
- Identity matching uses `(name, version, root lock checksum)` against `(name, version, crate_checksum_sha256)` in the old manifest.

## Selected packages

Each selected identity, expected checksum, local archive path/size/hash, literal Cargo.toml fields, and each root legal file's member path/size/hash/text path are fully recorded in the JSON. Root legal text copies are under `registry-notice-inventory-r1/<name>-<version>/`. No text from a different version is substituted.

| Package | Version | Archive checksum | Cargo.toml license | Root legal files | Status |
| --- | --- | --- | --- | ---: | --- |
| `arrow` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-arith` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-cast` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-csv` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-flight` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-json` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-ord` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-pyarrow` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-row` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-select` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `arrow-string` | `59.3.2` | match | `Apache-2.0` | 2 | complete |
| `fsst-rs` | `0.7.0` | match | `Apache-2.0` | 1 | complete |
| `onpair` | `0.3.0` | match | `Apache-2.0` | 1 | complete |
| `rand` | `0.10.3` | match | `MIT OR Apache-2.0` | 2 | complete |
| `vortex` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-alp` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-array-macros` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-arrow` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-btrblocks` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-bytebool` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-compressor` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-compute` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-decimal-byte-parts` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-edition` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-error` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-expr` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-fastlanes` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-ipc` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-mask` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-metrics` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-onpair` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-pco` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-scan` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-sequence` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-session` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-sparse` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-utils` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-uuid` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |
| `vortex-zigzag` | `0.93.0` | match | `Apache-2.0` | 0 | unresolved |

## Unresolved

- `vortex 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-alp 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-array-macros 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-arrow 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-btrblocks 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-bytebool 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-compressor 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-compute 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-decimal-byte-parts 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-edition 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-error 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-expr 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-fastlanes 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-ipc 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-mask 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-metrics 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-onpair 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-pco 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-scan 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-sequence 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-session 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-sparse 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-utils 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-uuid 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member
- `vortex-zigzag 0.93.0`: verified package/source contains no root LICENSE*/NOTICE*/COPYING* member

## Scope limits

- No network, Cargo command, build, test, or repository edit was performed.
- Cargo.toml values are literal package metadata only; no license-policy or compatibility conclusion is made.
- If a package archive lacks root legal files, the absence is recorded; no license content is inferred or copied from a different package version.
