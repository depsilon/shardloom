# Parquet fixture inventory r2

Focused repair to Parquet fixture requirements. r1 remains preserved; this report supersedes its statement that no `ARROW_TEST_DATA` call was found in the scanned Parquet source.

## Source helper inventory

The scanned Parquet source contains 1 `arrow_test_data()` occurrence, 79 `parquet_test_data()` occurrences, and 56 `get_test_file()` occurrences (2 definitions and 54 call or documentation examples). Exact source paths, line numbers, text, and literal arguments for all occurrences are recorded in the JSON report. The source-file SHA-256 values are also recorded there; notably, `vendor/parquet/src/arrow/arrow_reader/mod.rs` is `882b910efb82e7a8a4139a7d999cc7d0708effe45e0fda3b94c4d55c990b33c6`.

The corrected Arrow-specific call is `arrow::util::test_util::arrow_test_data()` at `vendor/parquet/src/arrow/arrow_reader/mod.rs:3740`; its helper at lines 3738–3744 appends a relative filename to the Arrow test-data root. Literal calls at lines 1806, 1818, 1941, and 1956 resolve two files in the pinned Arrow-testing data tree:

| Pinned fixture path | Bytes | Git blob SHA | `get_test_file` call sites |
| --- | ---: | --- | --- |
| `data/parquet/generated_simple_numerics/blogs.parquet` | 4,893 | `948d9a1416cdbc95efc8af895d6096c8c85bf5ab` | `arrow_reader/mod.rs:1806, 1941, 1956` |
| `data/parquet/alltypes-java.parquet` | 8,226 | `e7bde73685c849885568e167ae2160ad37077587` | `arrow_reader/mod.rs:1818` |

Arrow 59.3.2's `arrow_test_data()` reads `ARROW_TEST_DATA`, defaulting to `../testing/data`. Its `parquet_test_data()` reads `PARQUET_TEST_DATA`, defaulting to `../parquet-testing/data`. In Parquet, `vendor/parquet/src/util/test_common/file_util.rs:20–36` defines the helper that resolves names under the latter root. The full scan found 56 `get_test_file()` occurrences across nine source files; the JSON report preserves all individual references.

Parquet source also derives `parquet-testing/bad_data` and `parquet-testing/shredded_variant` as sibling directories of `data/`. Pinned tree metadata reports:

| Pinned directory | Files | Git blob bytes |
| --- | ---: | ---: |
| `parquet-testing/data` | 115 | 4,144,329 |
| `parquet-testing/bad_data` | 23 | 170,012 |
| `parquet-testing/shredded_variant` | 276 | 224,870 |

## Pinned source metadata

Arrow-rs 59.3.2 pins `apache/arrow-testing` at [`735ae7128d571398dd798d7ff004adebeb342883`](https://github.com/apache/arrow-testing/commit/735ae7128d571398dd798d7ff004adebeb342883), dated 2024-04-10. The pinned Arrow-testing data tree has 471 files totaling 7,832,050 Git blob bytes; its `parquet/` subtree has 126 files totaling 3,633,486 bytes. The two literal fixtures above were checked against that tree's recorded paths, sizes, and Git blob IDs.

Arrow-rs 59.3.2 pins `apache/parquet-testing` at [`09f3cdbde45302f0f0c689c950e465e98a9df960`](https://github.com/apache/parquet-testing/commit/09f3cdbde45302f0f0c689c950e465e98a9df960). The source metadata records repository SPDX `Apache-2.0` for both repositories and SHA-256 `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` for each pinned `LICENSE.txt`. These are reported metadata values, not a compatibility or legal conclusion.

The Arrow 59.3.2 `Cargo.lock` checksum (`3f04e0a89cc175eaf3740282537851e6fd9d7276f97730b9d0ea2859c11a85df`) matches the local `.crate` archive. The archive member hash for `src/util/test_util.rs` matches the local source hash (`4f00874c9956323c1a32b6eb1adfc2f74cd90182d235538ab92ba02fbfc2f8a6`). All metadata and scanned-source hashes listed in the JSON report were checked against the saved files; the Arrow submodule pin, pinned tree counts and literal fixture entries also agree with the metadata summary.

## Official sources

- [Arrow-rs 59.3.2 `.gitmodules`](https://github.com/apache/arrow-rs/blob/59.3.2/.gitmodules)
- [Arrow-testing pinned commit](https://github.com/apache/arrow-testing/commit/735ae7128d571398dd798d7ff004adebeb342883) and [pinned LICENSE.txt](https://github.com/apache/arrow-testing/blob/735ae7128d571398dd798d7ff004adebeb342883/LICENSE.txt)
- [Parquet-testing pinned commit](https://github.com/apache/parquet-testing/commit/09f3cdbde45302f0f0c689c950e465e98a9df960) and [pinned LICENSE.txt](https://github.com/apache/parquet-testing/blob/09f3cdbde45302f0f0c689c950e465e98a9df960/LICENSE.txt)

No fixture payloads were downloaded. No Cargo commands, builds, tests, fixture checkouts, test-exclusion decisions, or runtime judgments were made.
