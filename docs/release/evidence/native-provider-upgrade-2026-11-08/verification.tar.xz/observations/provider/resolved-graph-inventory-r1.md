# Resolved graph inventory r1

HEAD: `0205283370712637305aba07a86f5854e833da6e`

HEAD lock SHA-256: `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772` (115676 bytes)
Current lock SHA-256: `32ad9bdfd2bf7f8bb4d704b6e26ce982f2ff3b3020e5f8f68a2be667be62b8f1` (115391 bytes)

## Package changes

Added: 1; removed: 3; updated: 50.

## Arrow, Parquet, and Vortex versions

Grouped exact versions are in the JSON report under `versions` (base and current).
Duplicate Arrow package versions: base `{}`; current `{}`.
Multiple Arrow major versions: base `{}`; current `{}`.
`vortex-runend` remaining: base `[{"checksum": null, "name": "vortex-runend", "source": null, "version": "0.90.0"}]`; current `[]`.

## Local manifest metadata

For changed package records, local manifest metadata is recorded in JSON. Status counts: `{"found": 101, "unresolved": 3}`. Missing local sources are unresolved; nothing was fetched.

## Scope

Inventory only; no Cargo commands, builds, tests, downloads, or compatibility/security conclusions.

## Prohibited query-engine integration name matches

Matching uses delimited package-name tokens for DataFusion, DuckDB, Spark, Polars, Velox, Trino, Dask, and Ray; ordinary names such as `arrow-array` are excluded. Base matches: `[]`. Current matches: `[]`. This is name matching only; it makes no license or security acceptance claim.
