# Active provider version surface inventory

- Repository: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
- Git HEAD: `0205283370712637305aba07a86f5854e833da6e`
- Read-only scan date: 2026-11-08
- Included matching files: 162
- Literal occurrences: `vortex_0_90` 595, `arrow_parquet_59_3_1` 326, `vortex_runend` 760

## Method and scope

Scanned tracked UTF-8 files from `git ls-files -z` at the recorded HEAD. Match expressions:
- `vortex_0_90`: `(?<![0-9])0\.90(?:\.0)?(?![0-9])`
- `arrow_parquet_59_3_1`: `(?<![0-9])59\.3\.1(?![0-9])`
- `vortex_runend`: `vortex[-_]runend`

Exact matching lines and SHA-256 values are recorded in the JSON for non-lockfiles. Cargo lockfiles and manifests are grouped by path and literal counts.

Excluded matching-file classes (exact path patterns):
- `docs/release/**`
- `docs/dependencies/evidence/**`
- `docs/architecture/fixtures/**`
- `target/**`
- `results/**`
- `artifacts/**`
- `benchmarks/results/**`
- `criterion/**`
- `docs/architecture/** except docs/architecture/native-provider-upgrade-2026-11-08.md (historical architecture records excluded)`
- `untracked files (git ls-files enumeration at HEAD)`

Matching files excluded under those rules:
- `docs/architecture/compact-candidate-directory-screen-2026-09-27.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/compression-dependency-intake-2026-10-26.md` — vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/dependency-intake-2026-10-25.md` — vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- `docs/architecture/dependency-intake-2026-11-02.md` — vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- `docs/architecture/dependency-intake-2026-11-08.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-adaptive-execution-2026-11-01.md` — vortex_0_90=3, arrow_parquet_59_3_1=6, vortex_runend=0
- `docs/architecture/native-adjacent-parquet-reads-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-ai-data-workflows-2026-10-24.md` — vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-analytical-completion-2026-10-27.md` — vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-application-batch-functions-2026-10-30.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-broad-query-program-2026-10-26.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-connected-programming-model-2026-10-24.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-decimal-output-2026-10-29.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-dense-embedding-lifecycle-2026-11-05.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-direct-source-count-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-encoded-exchange-protocol.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-exchange-experiment-plan-2026-10-20.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-fixed-tensor-lifecycle-2026-11-07.md` — vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-float-policy-2026-10-29.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-float16-lifecycle-2026-11-07.md` — vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- `docs/architecture/native-foundry-integration-2026-10-25.md` — vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-fused-measure-encoding-correction-2026-10-25.md` — vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-fused-measure-work-elimination-2026-10-25.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-grouped-cost-attribution-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-grouped-state-access-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-ingest-ownership-preparation-2026-10-24.md` — vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-join-count-work-elimination-2026-10-25.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-managed-binary-objects-2026-11-06.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-multi-output-work-elimination-2026-10-25.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-multiway-join-comparison-design-2026-10-20.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-ordered-inputs-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-parquet-demand-completion-2026-10-26.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-performance-batch-2026-10-31.md` — vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-preparation-query-investigations-2026-11-02.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-recursive-composition-2026-10-29.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-rich-data-lifecycle-2026-10-24.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-runtime-completion-2026-09-20.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-selection-retention-2026-11-04.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-shared-performance-2026-10-29.md` — vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-shared-work-reduction-2026-11-03.md` — vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-single-predicate-masks-2026-10-30.md` — vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-source-demand-2026-10-26.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-time-series-completion-2026-10-29.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-typed-ordering-2026-10-31.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/native-universal-io-implementation-2026-10-31.md` — vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-varbin-metadata-resources-2026-10-16.md` — vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- `docs/architecture/native-variable-tensor-lifecycle-2026-11-07.md` — vortex_0_90=2, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-vector-representations-2026-11-07.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/native-vortex-provider-refresh-2026-10-24.md` — vortex_0_90=12, arrow_parquet_59_3_1=3, vortex_runend=2
- `docs/architecture/native-warm-source-reuse-2026-10-24.md` — vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/phased-execution-completed-ledger.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/architecture/phased-execution-plan.md` — vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- `docs/architecture/source-backed-dictionary-screen-2026-09-29.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/vortex-adapter-integration-plan.md` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/architecture/vortex-public-api-inventory.md` — vortex_0_90=5, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/channel-proofs/github-prerelease-v0.7.0-transcript.json` — vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- `docs/release/channel-proofs/github-prerelease-v1.0.0-transcript.json` — vortex_0_90=8, arrow_parquet_59_3_1=2, vortex_runend=2
- `docs/release/channel-proofs/github-prerelease-v1.1.0-transcript.json` — vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=2
- `docs/release/evidence/native-dense-embedding-arrow-followup-2026-11-05.json` — vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- `docs/release/evidence/native-fixed-shape-tensor-2026-11-07/acceptance.json` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/evidence/native-fixed-shape-tensor-2026-11-07/corruption-controls.json` — vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/evidence/native-fixed-shape-tensor-2026-11-07/verify.py` — vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/evidence/native-float16-lifecycle-2026-11-07/acceptance.json` — vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- `docs/release/evidence/native-variable-shape-tensor-2026-11-07/acceptance.json` — vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/evidence/native-variable-shape-tensor-2026-11-07/verify.py` — vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- `docs/release/evidence/native-vector-representations-2026-11-07/acceptance.json` — vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- `docs/release/v1.0.0-release-notes.md` — vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0

## Current non-lockfile facts

### `.github/provider-locks/README.md`
- SHA-256: `0f5d527b023c850473fff8c2613ffadc44912294693b6bc67e04157af5a806a9`; bytes: 6771; counts: vortex_0_90=0, arrow_parquet_59_3_1=3, vortex_runend=0
- L69: `runtime graph. The runtime Arrow boundary remains 59.3.1. The`
- L81: `'arrow-avro.lock' freezes the complete standalone Arrow Avro 59.3.1 library`
- L100: `'arrow-ipc.lock' fixes the complete Arrow IPC library tests at Arrow 59.3.1 with`
### `.github/provider-locks/arrow-ipc-review.json`
- SHA-256: `d63f34afea0c51fcb49cf3fd7d764d377cac90aeebf110f618b9b4191189520d`; bytes: 15456; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L413: `  "arrow_versions": "59.3.1",`
### `benchmarks/traditional_analytics/query_surface/expanded_range_replay.py`
- SHA-256: `3be406ce3e6a84315d1f8e646cd4bc11f82f7cd831eb3968bebe11094f7535d2`; bytes: 11425; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L2: `"""Independent bounded replay of the pinned Vortex 0.90 footer/range evidence."""`
### `docs/architecture/native-provider-upgrade-2026-11-08.md`
- SHA-256: `45b7aaa4beb8ae4d9ac11e9d75cd082529cf547a8c8d44c7961a6341ad94de9b`; bytes: 10399; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=1
- L14: `current 0.90.0 provider. The original bot proposal targets 0.91.0, but`
- L22: `Arrow buffer, data and schema 59.3.2, with other Arrow/Parquet providers at 59.3.1.`
- L80: `| Former 'vortex-runend' | Expanded text/binary views retain their shared table reservation after moving into the array provider |`
### `docs/benchmarks/evidence/compact-index-acceptance-source-764.json`
- SHA-256: `021867bd6eb39bcc77e9285106249e214fa92e2b4cf6d0f7b88967e12d23f000`; bytes: 282897; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- L2186: `    "vendor/vortex-runend/Cargo.toml": "38cc3777ebe2200dd5c5e0b43551e746fd8a4778cb73a2f18d6f68849caeae1b",`
- L2187: `    "vendor/vortex-runend/Cargo.toml.orig": "ac1f414c8315fe76feb2c67f71af70df53ae8be9ea3f956974e6b40db7fa5e9e",`
- L2188: `    "vendor/vortex-runend/src/arbitrary.rs": "c5524c0bf2b9f7623d889fbc3361198afbc79e7e14f689b18194db2905a812a0",`
- L2189: `    "vendor/vortex-runend/src/array.rs": "3d8ad9751e0b9ce81186b0da32801be45dde7b3935fc964eedc1f7fc7d63adb6",`
- L2190: `    "vendor/vortex-runend/src/compress.rs": "5234394ed3c6e9f71a2de245eef987227765572833e630da3aec4ab058ac9d27",`
- L2191: `    "vendor/vortex-runend/src/compute/cast.rs": "2ed0ae259e57df74e7d6c62ed9c9b38a6eabcf089d78cad3c29a090863e2e552",`
- L2192: `    "vendor/vortex-runend/src/compute/compare.rs": "a239115a1f106e9bbc5e212a12ce0b3f687a9433e66586d96e7f05e23b548c85",`
- L2193: `    "vendor/vortex-runend/src/compute/fill_null.rs": "07a42d771c16b51afe008a8a6d61d60183e4c4e8b634a4b2172a2a4a88c65a16",`
- L2194: `    "vendor/vortex-runend/src/compute/filter.rs": "b549bfb8b5a2438c314e9fd269f5e6a0a3f7d9c8fd5d7b9df27627be5c111be1",`
- L2195: `    "vendor/vortex-runend/src/compute/is_constant.rs": "4a376d0d52f90b87dcda47abc7afaf4c1352a59afe5e8b5702cb7c429e8cd398",`
- L2196: `    "vendor/vortex-runend/src/compute/is_sorted.rs": "ae6b6beaad73e4924f5b13a1cf8a0ddb542544cc60d103f0c729faa4f5498ed2",`
- L2197: `    "vendor/vortex-runend/src/compute/min_max.rs": "45a7e649b7b5ea9c4a9422b627fd9ab9616a1adf78af084a6f213e7e279d5f55",`
- L2198: `    "vendor/vortex-runend/src/compute/mod.rs": "e56ab5247a2139d52a7a7e63b29a293efa584df65ef7bd425db8811d40ee7fec",`
- L2199: `    "vendor/vortex-runend/src/compute/take.rs": "bc5be9d9e5d44893a6fc159f19f84105ddb76726fa5373d96c1b9dc60fabcb65",`
- L2200: `    "vendor/vortex-runend/src/compute/take_from.rs": "47719bb31906ab7d1bdc6b5863aedfd24906b1426814460f4acb2c28825a8502",`
- L2201: `    "vendor/vortex-runend/src/decompress_bool.rs": "5519f1d25bd7ad841e5283ec4099c87e516705102ceaa97b1110c98606580d3a",`
- L2202: `    "vendor/vortex-runend/src/iter.rs": "5261009721ae79d7a0fc8adca4a89e5897141672f8f70eee76fd2f8becb904d2",`
- L2203: `    "vendor/vortex-runend/src/kernel.rs": "8f096f53927ee42d25e785fc087c946076de50c8bd7846c2fa85963f632ed7ab",`
- L2204: `    "vendor/vortex-runend/src/lib.rs": "239c3dda01bed0dd911ddb515c856c411eaf5b493e557052e9629cf8b172361e",`
- L2205: `    "vendor/vortex-runend/src/ops.rs": "be72d72e25a66818783ee400f49de1176b0c620cb28fe156abd5ee3ed677c83b",`
- L2206: `    "vendor/vortex-runend/src/rules.rs": "f5b0874e0a4b8810c4b07b697f3f9e6af15afddefb5a0ee22c4dde1aeff43947",`
- L2207: `    "vendor/vortex-runend/src/trace_tests.rs": "b4a5266f9b27c4898a4a6417bc9edf65b6228ecfdc5de0d44353ce0f17756b39",`
### `docs/benchmarks/evidence/dependency-intake-2026-11-02/acceptance.json`
- SHA-256: `dcaeb5d8b0d3ccaa31d1d9912ff9c01fdf2757e0e7867103ec02baf9eba0e66d`; bytes: 663169; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L46: `    ".github/provider-locks/vortex-runend.lock": {`
- L13378: `    "vendor/vortex-runend/Cargo.toml": {`
- L13382: `    "vendor/vortex-runend/src/arbitrary.rs": {`
- L13386: `    "vendor/vortex-runend/src/array.rs": {`
- L13390: `    "vendor/vortex-runend/src/compress.rs": {`
- L13394: `    "vendor/vortex-runend/src/compute/cast.rs": {`
- L13398: `    "vendor/vortex-runend/src/compute/compare.rs": {`
- L13402: `    "vendor/vortex-runend/src/compute/fill_null.rs": {`
- L13406: `    "vendor/vortex-runend/src/compute/filter.rs": {`
- L13410: `    "vendor/vortex-runend/src/compute/is_constant.rs": {`
- L13414: `    "vendor/vortex-runend/src/compute/is_sorted.rs": {`
- L13418: `    "vendor/vortex-runend/src/compute/min_max.rs": {`
- L13422: `    "vendor/vortex-runend/src/compute/mod.rs": {`
- L13426: `    "vendor/vortex-runend/src/compute/sum/kernel.rs": {`
- L13430: `    "vendor/vortex-runend/src/compute/sum/mod.rs": {`
- L13434: `    "vendor/vortex-runend/src/compute/sum/runs.rs": {`
- L13438: `    "vendor/vortex-runend/src/compute/sum/tests.rs": {`
- L13442: `    "vendor/vortex-runend/src/compute/take.rs": {`
- L13446: `    "vendor/vortex-runend/src/compute/take_from.rs": {`
- L13450: `    "vendor/vortex-runend/src/decompress_bool.rs": {`
- L13454: `    "vendor/vortex-runend/src/iter.rs": {`
- L13458: `    "vendor/vortex-runend/src/kernel.rs": {`
- L13462: `    "vendor/vortex-runend/src/lib.rs": {`
- L13466: `    "vendor/vortex-runend/src/ops.rs": {`
- L13470: `    "vendor/vortex-runend/src/probe.rs": {`
- L13474: `    "vendor/vortex-runend/src/probe/tests.rs": {`
- L13478: `    "vendor/vortex-runend/src/rules.rs": {`
- L13482: `    "vendor/vortex-runend/src/trace_tests.rs": {`
### `docs/benchmarks/evidence/merge-tail-restoration-778.json`
- SHA-256: `26d03c39492c282db2465fdbee65ac26e92a9f5a8f9322e656eaa18dca6b3e79`; bytes: 498892; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- L11175: `      "path": "vendor/vortex-runend/Cargo.toml",`
- L11181: `      "path": "vendor/vortex-runend/Cargo.toml.orig",`
- L11187: `      "path": "vendor/vortex-runend/src/arbitrary.rs",`
- L11193: `      "path": "vendor/vortex-runend/src/array.rs",`
- L11199: `      "path": "vendor/vortex-runend/src/compress.rs",`
- L11205: `      "path": "vendor/vortex-runend/src/compute/cast.rs",`
- L11211: `      "path": "vendor/vortex-runend/src/compute/compare.rs",`
- L11217: `      "path": "vendor/vortex-runend/src/compute/fill_null.rs",`
- L11223: `      "path": "vendor/vortex-runend/src/compute/filter.rs",`
- L11229: `      "path": "vendor/vortex-runend/src/compute/is_constant.rs",`
- L11235: `      "path": "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L11241: `      "path": "vendor/vortex-runend/src/compute/min_max.rs",`
- L11247: `      "path": "vendor/vortex-runend/src/compute/mod.rs",`
- L11253: `      "path": "vendor/vortex-runend/src/compute/take.rs",`
- L11259: `      "path": "vendor/vortex-runend/src/compute/take_from.rs",`
- L11265: `      "path": "vendor/vortex-runend/src/decompress_bool.rs",`
- L11271: `      "path": "vendor/vortex-runend/src/iter.rs",`
- L11277: `      "path": "vendor/vortex-runend/src/kernel.rs",`
- L11283: `      "path": "vendor/vortex-runend/src/lib.rs",`
- L11289: `      "path": "vendor/vortex-runend/src/ops.rs",`
- L11295: `      "path": "vendor/vortex-runend/src/rules.rs",`
- L11301: `      "path": "vendor/vortex-runend/src/trace_tests.rs",`
### `docs/benchmarks/evidence/native-adaptive-decisions-acceptance-2026-11-02/acceptance.json`
- SHA-256: `a8c22699c344853b633ee7a9ddc0befd71c0a3aba0a23b3ea0061fc34ea2f21c`; bytes: 630372; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L46: `    ".github/provider-locks/vortex-runend.lock": {`
- L13302: `    "vendor/vortex-runend/Cargo.toml": {`
- L13306: `    "vendor/vortex-runend/src/arbitrary.rs": {`
- L13310: `    "vendor/vortex-runend/src/array.rs": {`
- L13314: `    "vendor/vortex-runend/src/compress.rs": {`
- L13318: `    "vendor/vortex-runend/src/compute/cast.rs": {`
- L13322: `    "vendor/vortex-runend/src/compute/compare.rs": {`
- L13326: `    "vendor/vortex-runend/src/compute/fill_null.rs": {`
- L13330: `    "vendor/vortex-runend/src/compute/filter.rs": {`
- L13334: `    "vendor/vortex-runend/src/compute/is_constant.rs": {`
- L13338: `    "vendor/vortex-runend/src/compute/is_sorted.rs": {`
- L13342: `    "vendor/vortex-runend/src/compute/min_max.rs": {`
- L13346: `    "vendor/vortex-runend/src/compute/mod.rs": {`
- L13350: `    "vendor/vortex-runend/src/compute/sum/kernel.rs": {`
- L13354: `    "vendor/vortex-runend/src/compute/sum/mod.rs": {`
- L13358: `    "vendor/vortex-runend/src/compute/sum/runs.rs": {`
- L13362: `    "vendor/vortex-runend/src/compute/sum/tests.rs": {`
- L13366: `    "vendor/vortex-runend/src/compute/take.rs": {`
- L13370: `    "vendor/vortex-runend/src/compute/take_from.rs": {`
- L13374: `    "vendor/vortex-runend/src/decompress_bool.rs": {`
- L13378: `    "vendor/vortex-runend/src/iter.rs": {`
- L13382: `    "vendor/vortex-runend/src/kernel.rs": {`
- L13386: `    "vendor/vortex-runend/src/lib.rs": {`
- L13390: `    "vendor/vortex-runend/src/ops.rs": {`
- L13394: `    "vendor/vortex-runend/src/probe.rs": {`
- L13398: `    "vendor/vortex-runend/src/probe/tests.rs": {`
- L13402: `    "vendor/vortex-runend/src/rules.rs": {`
- L13406: `    "vendor/vortex-runend/src/trace_tests.rs": {`
### `docs/benchmarks/evidence/native-adjacent-parquet-reads-2026-10-31/manifest.json`
- SHA-256: `884c44c8f8df62d87ceba7426c107d9fba669e7818c796c02041fe2f5e4b8380`; bytes: 3332467; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"cohort":{"inputs":{"bytes":7695900,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-adjacent-reads-r1/inputs.json","sha256":"d5d06a6b93ef727b423457dd0fa5bfc86a97602aa4219eb27fcd1fc026cf562a"},"name":"broad-adjacent-reads-r1","protocol":{"bytes":18948,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-adjacent-reads-r1/protocol.jso`
### `docs/benchmarks/evidence/native-exchange-2026-10-21/postchecks.json`
- SHA-256: `e1977aa5350680d87e5dedb81088aede0089feb53db34774e77dce1a3cf88671`; bytes: 387235; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L10403: `      "file": "vendor/vortex-runend/.cargo_vcs_info.json",`
- L10408: `      "file": "vendor/vortex-runend/Cargo.toml",`
- L10413: `      "file": "vendor/vortex-runend/Cargo.toml.orig",`
- L10418: `      "file": "vendor/vortex-runend/LICENSE",`
- L10423: `      "file": "vendor/vortex-runend/README.md",`
- L10428: `      "file": "vendor/vortex-runend/README.shardloom.md",`
- L10433: `      "file": "vendor/vortex-runend/goldenfiles/runend.metadata",`
- L10438: `      "file": "vendor/vortex-runend/src/arbitrary.rs",`
- L10443: `      "file": "vendor/vortex-runend/src/array.rs",`
- L10448: `      "file": "vendor/vortex-runend/src/compress.rs",`
- L10453: `      "file": "vendor/vortex-runend/src/compute/cast.rs",`
- L10458: `      "file": "vendor/vortex-runend/src/compute/compare.rs",`
- L10463: `      "file": "vendor/vortex-runend/src/compute/fill_null.rs",`
- L10468: `      "file": "vendor/vortex-runend/src/compute/filter.rs",`
- L10473: `      "file": "vendor/vortex-runend/src/compute/is_constant.rs",`
- L10478: `      "file": "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L10483: `      "file": "vendor/vortex-runend/src/compute/min_max.rs",`
- L10488: `      "file": "vendor/vortex-runend/src/compute/mod.rs",`
- L10493: `      "file": "vendor/vortex-runend/src/compute/take.rs",`
- L10498: `      "file": "vendor/vortex-runend/src/compute/take_from.rs",`
- L10503: `      "file": "vendor/vortex-runend/src/decompress_bool.rs",`
- L10508: `      "file": "vendor/vortex-runend/src/iter.rs",`
- L10513: `      "file": "vendor/vortex-runend/src/kernel.rs",`
- L10518: `      "file": "vendor/vortex-runend/src/lib.rs",`
- L10523: `      "file": "vendor/vortex-runend/src/ops.rs",`
- L10528: `      "file": "vendor/vortex-runend/src/rules.rs",`
- L10533: `      "file": "vendor/vortex-runend/src/trace_tests.rs",`
- L10538: `      "file": "vendor/vortex-runend/upstream-provenance.json",`
### `docs/benchmarks/evidence/native-exchange-prerequisites-2026-10-20/native-encoded-exchange-acceptance.json`
- SHA-256: `8660edf79bdae29bdd95201c91db2d4bb087a943c63b02f1600f96a50b44135a`; bytes: 83980; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L312: `    "Current Vortex documentation navigation shows 0.90 draft/0.89 released; pinned 0.85 codec source remains authoritative."`
### `docs/benchmarks/evidence/native-exchange-prerequisites-2026-10-20/record_native_exchange_833.py`
- SHA-256: `e7ab49df10714ffc775a92fd858e72bce4591f8a8591d278fbbcc39dc31ce210`; bytes: 13995; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L220: `            'Current Vortex documentation navigation shows 0.90 draft/0.89 released; pinned 0.85 codec source remains authoritative.',`
### `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/combined-controls-r1-profile/attempts.jsonl`
- SHA-256: `5f410a471bd3a3408490c5fa32d1bd102c3ccd1a1ef020670d64471f905fa77c`; bytes: 179088; counts: vortex_0_90=5, arrow_parquet_59_3_1=0, vortex_runend=0
- L1: `{"seq":0,"id":"v2_integer_expression_order_493511db4e216f7c","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3157,"sha256":"cac45e0b76125fa92e5e179dec6db16097c5ca639dbe5a7beab0012c162f5d8e","utf8":"{\n  \"case\": {\n    \"id\": \"v2_integer_expression_order_493511db4e216f7c\",\n    \"archetype\": \"integer_expression_order\",\n`
- L2: `{"seq":1,"id":"v2_integer_expression_order_734362dac326f99a","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3113,"sha256":"e32c8f4f9aa91f6d1001bb765984b56bf84b57b4927231aaa2a9e2343449c7a9","utf8":"{\n  \"case\": {\n    \"id\": \"v2_integer_expression_order_734362dac326f99a\",\n    \"archetype\": \"integer_expression_order\",\n`
### `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/combined-controls-r1/attempts.jsonl`
- SHA-256: `860afb5762c79e2551cb4ecb703aeb0315d4a1a7b2e2a28091038220c5e69ae9`; bytes: 1578713; counts: vortex_0_90=55, arrow_parquet_59_3_1=0, vortex_runend=0
- L1: `{"seq":0,"id":"v2_integer_expression_order_e8b2d3f68c4dcae7","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4595,"sha256":"2615109f79bd80cfb0eacfd258f941ed54e9f132faff8e8bfaecea3199be4e82","utf8":"{\n  \"case\": {\n    \"id\": \"v2_integer_expression_order_e8b2d3f68c4dcae7\",\n    \"archetype\": \"integer_expression_order\",\n`
- L2: `{"seq":1,"id":"v2_nullable_expression_order_4e2ee36d061cdba8","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3215,"sha256":"aed0e369044195853360a52632b719f77311ab5298ddc7abe32c61519d4ec49d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_nullable_expression_order_4e2ee36d061cdba8\",\n    \"archetype\": \"nullable_expression_order\"`
- L3: `{"seq":2,"id":"v2_text_expression_order_be324e9494e51c31","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":11170,"sha256":"a2b9036d52ea47f0f4b7d4f021d2325563e7378d114b29d9629d4369769f34fe","utf8":"{\n  \"case\": {\n    \"id\": \"v2_text_expression_order_be324e9494e51c31\",\n    \"archetype\": \"text_expression_order\",\n    \"fa`
- L4: `{"seq":3,"id":"v2_text_expression_order_5bf1eab1d88be8cd","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":9798,"sha256":"6f2c9916e58b2e2abb205a80aea718734f5fa270992146c5c79ab28f412fa41a","utf8":"{\n  \"case\": {\n    \"id\": \"v2_text_expression_order_5bf1eab1d88be8cd\",\n    \"archetype\": \"text_expression_order\",\n    \"fam`
- L5: `{"seq":4,"id":"v2_text_expression_order_f738d13319d2c762","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4704,"sha256":"1ad2dbff9a24bfd2823b952f39c760298b059de02716986285f2cfa6ebf26ac1","utf8":"{\n  \"case\": {\n    \"id\": \"v2_text_expression_order_f738d13319d2c762\",\n    \"archetype\": \"text_expression_order\",\n    \"fam`
- L6: `{"seq":5,"id":"v2_text_expression_order_6ea2af151da83255","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4709,"sha256":"4412b8b1e2e5070fdb8b4080f7b4e7ca11b2bc9eaa35436bbcb454fc5dcd96af","utf8":"{\n  \"case\": {\n    \"id\": \"v2_text_expression_order_6ea2af151da83255\",\n    \"archetype\": \"text_expression_order\",\n    \"fam`
- L7: `{"seq":6,"id":"v2_calendar_expression_order_3d135f1371c2af6a","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4664,"sha256":"2a6ab7c83ace3bba2340b72c10ced7935c688ed11948b717c8c7e1fe8e8339ce","utf8":"{\n  \"case\": {\n    \"id\": \"v2_calendar_expression_order_3d135f1371c2af6a\",\n    \"archetype\": \"calendar_expression_order\"`
- L8: `{"seq":7,"id":"v2_product_left_group_612dc5dd63944870","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":6170,"sha256":"df7f763546ea1748788fc5ee7b4877b2423b369346d0038dbf629bf6cb61eaaa","utf8":"{\n  \"case\": {\n    \"id\": \"v2_product_left_group_612dc5dd63944870\",\n    \"archetype\": \"product_left_group\",\n    \"family\": \"`
- L9: `{"seq":8,"id":"v2_right_outer_group_c8396388e8c70075","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":5530,"sha256":"d4ff41e6a52f1ea5dee3618449d5c95cb0841425b1abf2f62c9947e30a1b455e","utf8":"{\n  \"case\": {\n    \"id\": \"v2_right_outer_group_c8396388e8c70075\",\n    \"archetype\": \"right_outer_group\",\n    \"family\": \"joi`
- L10: `{"seq":9,"id":"v2_full_outer_group_54ee753adf8f1b20","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":6260,"sha256":"a54a212e1ef2e778aae86851afae40401c3dec50085ae691393d7f21a78ca993","utf8":"{\n  \"case\": {\n    \"id\": \"v2_full_outer_group_54ee753adf8f1b20\",\n    \"archetype\": \"full_outer_group\",\n    \"family\": \"joins\`
- L11: `{"seq":10,"id":"v2_set_union_all_reduction_84d23edf06b37bc4","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3012,"sha256":"f45038c133477de4cb8ea0d98f070aaa2507e014a5845b0b8592aa4fa837622a","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_all_reduction_84d23edf06b37bc4\",\n    \"archetype\": \"set_union_all_reduction\",\n  `
- L12: `{"seq":11,"id":"v2_set_union_all_reduction_33e89ebd132c4b53","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4679,"sha256":"2838267e0f5829126225789d53caf3e4e837476add37a378a9c1434862f8a89d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_all_reduction_33e89ebd132c4b53\",\n    \"archetype\": \"set_union_all_reduction\",\n  `
- L13: `{"seq":12,"id":"v2_set_union_distinct_reduction_dc1928ee77f713a5","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":5340,"sha256":"3c81a1c6c08f0609439388f281ecfcc9b9bca27b3523a45c9f0d2818e8619c28","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_distinct_reduction_dc1928ee77f713a5\",\n    \"archetype\": \"set_union_distinct_r`
- L14: `{"seq":13,"id":"v2_set_intersect_reduction_3c059584b3ec7dda","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3246,"sha256":"f29c841f576a17d7fa463cf2df201a6cf37238cf18ffe50e77e578ab4e68970d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_intersect_reduction_3c059584b3ec7dda\",\n    \"archetype\": \"set_intersect_reduction\",\n  `
- L15: `{"seq":14,"id":"v2_set_except_reduction_c9f0ebc08072b8a1","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4696,"sha256":"ddf509d34ee368a5fe9ff546941315298c09f0744233e84374ea3fea38747ca6","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_except_reduction_c9f0ebc08072b8a1\",\n    \"archetype\": \"set_except_reduction\",\n    \"famil`
- L16: `{"seq":15,"id":"v2_rank_hidden_payload_5dcca5478175cafd","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3667,"sha256":"e73ca89771c9245a35213d240009571e90e4b1dc2389fa0bb2513eba256232e7","utf8":"{\n  \"case\": {\n    \"id\": \"v2_rank_hidden_payload_5dcca5478175cafd\",\n    \"archetype\": \"rank_hidden_payload\",\n    \"family\"`
- L17: `{"seq":16,"id":"v2_rank_hidden_payload_ade4e107deda3e58","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4973,"sha256":"aebd7f7b055c20a45913556d0780d3ff887b177bbe1b855bbcb45f4677d58798","utf8":"{\n  \"case\": {\n    \"id\": \"v2_rank_hidden_payload_ade4e107deda3e58\",\n    \"archetype\": \"rank_hidden_payload\",\n    \"family\"`
- L18: `{"seq":17,"id":"v2_window_row_number_fe55f07e26819375","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4676,"sha256":"25c014a442ee250c5412e869c07d098e89c209981cebd91c54688576d0f48e7a","utf8":"{\n  \"case\": {\n    \"id\": \"v2_window_row_number_fe55f07e26819375\",\n    \"archetype\": \"window_row_number\",\n    \"family\": \"wi`
- L19: `{"seq":18,"id":"v2_window_lag_7563008b9d5c3ba5","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3179,"sha256":"bf5bced09428a8ae2d7a32af2dfa4b9c39121fa465fbde84641a12e44838a90b","utf8":"{\n  \"case\": {\n    \"id\": \"v2_window_lag_7563008b9d5c3ba5\",\n    \"archetype\": \"window_lag\",\n    \"family\": \"windows\",\n    \"cell\`
- L20: `{"seq":19,"id":"v2_window_lead_6b6c3746c71d4830","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3181,"sha256":"ca9eded94a1b32bb11c578aa7040ebafcfe74551dc3c9bbe702b32687f6b0383","utf8":"{\n  \"case\": {\n    \"id\": \"v2_window_lead_6b6c3746c71d4830\",\n    \"archetype\": \"window_lead\",\n    \"family\": \"windows\",\n    \"ce`
- L21: `{"seq":20,"id":"v2_window_rolling_sum_23241f2775513736","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4052,"sha256":"63665f85c65c167f9bff0fdb25c3e9ac2ba6cd60894c2d57ae784309f44e2917","utf8":"{\n  \"case\": {\n    \"id\": \"v2_window_rolling_sum_23241f2775513736\",\n    \"archetype\": \"window_rolling_sum\",\n    \"family\": \`
- L22: `{"seq":21,"id":"v2_subquery_membership_83685c6306e5d1cc","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":2757,"sha256":"2c7953bea9fbf3aaada6d288743eab802e6949e11ba8d92521c8d9e438593cdd","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_83685c6306e5d1cc\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
- L23: `{"seq":22,"id":"v2_subquery_membership_2efe3a9d9a9f20bb","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3502,"sha256":"2133527940ec442493891ea2883f6ee129c46abdb4cdb59461dae19d0930120d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_2efe3a9d9a9f20bb\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
- L24: `{"seq":23,"id":"v2_subquery_membership_8bf597082fe9c468","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3687,"sha256":"48c2f7589488942070fbf411c6c21e859294986ff79433ce834c4136dc0d1c91","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_8bf597082fe9c468\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
### `docs/benchmarks/evidence/native-expanded-query-2026-11-03/selection-retention/selection-controls-r1/attempts.jsonl`
- SHA-256: `157dfe762df9b1363be2dae4d57fb47190dc7e71d03f789d9226343a989eab46`; bytes: 925531; counts: vortex_0_90=31, arrow_parquet_59_3_1=0, vortex_runend=0
- L1: `{"seq":0,"id":"v2_product_left_group_612dc5dd63944870","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":6172,"sha256":"fb1096094c19d8343edeef1174f091341270e2605f1625823119e4a76b0b714d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_product_left_group_612dc5dd63944870\",\n    \"archetype\": \"product_left_group\",\n    \"family\": \"`
- L2: `{"seq":1,"id":"v2_right_outer_group_c8396388e8c70075","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":5532,"sha256":"fe56aeb3cb55c0a334ec236cda6fa424edba61c19c7739b4f1cc31046b34a662","utf8":"{\n  \"case\": {\n    \"id\": \"v2_right_outer_group_c8396388e8c70075\",\n    \"archetype\": \"right_outer_group\",\n    \"family\": \"joi`
- L3: `{"seq":2,"id":"v2_full_outer_group_54ee753adf8f1b20","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":6262,"sha256":"3818e0e38a28a9ab74edc77a1f7efdcee9493578778aab7f8b31c69bc4741207","utf8":"{\n  \"case\": {\n    \"id\": \"v2_full_outer_group_54ee753adf8f1b20\",\n    \"archetype\": \"full_outer_group\",\n    \"family\": \"joins\`
- L4: `{"seq":3,"id":"v2_set_union_all_reduction_84d23edf06b37bc4","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3014,"sha256":"911c896e65207ac4a00b7de850c75d25001497435b6b02f419e70b3d8ac58224","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_all_reduction_84d23edf06b37bc4\",\n    \"archetype\": \"set_union_all_reduction\",\n   `
- L5: `{"seq":4,"id":"v2_set_union_all_reduction_33e89ebd132c4b53","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4681,"sha256":"90d62169bcef46cb415012ebaf16cbdb84f1012316e6f8e9dd85ad8e0a4fdbe9","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_all_reduction_33e89ebd132c4b53\",\n    \"archetype\": \"set_union_all_reduction\",\n   `
- L6: `{"seq":5,"id":"v2_set_union_distinct_reduction_dc1928ee77f713a5","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":5342,"sha256":"cd5babbf46082dda17059cacae11d81e5897f8e4b29bba137a0733d5433c99b4","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_union_distinct_reduction_dc1928ee77f713a5\",\n    \"archetype\": \"set_union_distinct_re`
- L7: `{"seq":6,"id":"v2_set_intersect_reduction_3c059584b3ec7dda","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3248,"sha256":"42340d0f0d2c3dfa74e347d5e50bdde9780d26e88f2b53445522b3d2887007b1","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_intersect_reduction_3c059584b3ec7dda\",\n    \"archetype\": \"set_intersect_reduction\",\n   `
- L8: `{"seq":7,"id":"v2_set_except_reduction_c9f0ebc08072b8a1","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4698,"sha256":"6157dab04c1fff712688f233cbaabf86d3b362151632e8a553d71c244e42c99e","utf8":"{\n  \"case\": {\n    \"id\": \"v2_set_except_reduction_c9f0ebc08072b8a1\",\n    \"archetype\": \"set_except_reduction\",\n    \"family`
- L9: `{"seq":8,"id":"v2_rank_hidden_payload_5dcca5478175cafd","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3669,"sha256":"6937d7b61e21d5bc0153d482d0096a9a1da85c3fca31cfc962c108551d2496f3","utf8":"{\n  \"case\": {\n    \"id\": \"v2_rank_hidden_payload_5dcca5478175cafd\",\n    \"archetype\": \"rank_hidden_payload\",\n    \"family\":`
- L10: `{"seq":9,"id":"v2_rank_hidden_payload_ade4e107deda3e58","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":4975,"sha256":"89be850469e39d59cd1e38a3d7079cc134944696b2dd2d1aeae4b3ede5200e0d","utf8":"{\n  \"case\": {\n    \"id\": \"v2_rank_hidden_payload_ade4e107deda3e58\",\n    \"archetype\": \"rank_hidden_payload\",\n    \"family\":`
- L11: `{"seq":10,"id":"v2_subquery_membership_83685c6306e5d1cc","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":2759,"sha256":"6a3bc5ebf2fc1348a3c02e7e0ac10598fde2103031e9cad4b2a6df441e6a1adf","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_83685c6306e5d1cc\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
- L12: `{"seq":11,"id":"v2_subquery_membership_2efe3a9d9a9f20bb","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3504,"sha256":"6cb23a67d2fea98bb6ba5e1bbf414c943bc5cdf6f733c51e8288589439c77dd0","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_2efe3a9d9a9f20bb\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
- L13: `{"seq":12,"id":"v2_subquery_membership_8bf597082fe9c468","status":"passed","packet":{"classification_detail":null,"classified_status":"passed","files":{"one.job.json":{"bytes":3689,"sha256":"94516a9e9ab8f28a1e811e633dbffe48b89b3dbf05a62596b8f8c8fdd54567ab","utf8":"{\n  \"case\": {\n    \"id\": \"v2_subquery_membership_8bf597082fe9c468\",\n    \"archetype\": \"subquery_membership\",\n    \"family\"`
### `docs/benchmarks/evidence/native-grouped-cost-2026-10-31/manifest.json`
- SHA-256: `56cbd03f6a176dd5d4c60d971d53eeb1f5b1ea463d00000a2fadc0fff0733242`; bytes: 1496398; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=27
- L1: `{"evidence":{"assembly_manifest":{"bytes":2584,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/grouped-assembly-r1/manifest.json","sha256":"9f01087ab6f42de3ae3a07de509d5dd34405316a931b6aa9be2772dda46a397e"},"assembly_review":{"bytes":1059,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/grouped-assembly-r1/review.json","sha256":"bda1d11cf7bdb2b8499a31a5`
### `docs/benchmarks/evidence/native-grouped-state-access-2026-10-31/manifest.json`
- SHA-256: `0c33e84017bab6451696f15a9701c2368cea2f2ceb27a2f1f68412add1b4d266`; bytes: 3341639; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"assembly_manifest":{"bytes":18084,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/grouped-state-assembly-r2/manifest.json","sha256":"8fff75accd74292ad6b3dedf4cd6a814c889522683c763ecab6e613d1778dffd"},"assembly_review":{"bytes":6093,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/grouped-state-assembly-r2/review.json","sha256":"ec4e43890c4`
### `docs/benchmarks/evidence/native-grouped-state-ci-correction-2026-10-31.json`
- SHA-256: `281fae785001b0d4cc1e1869a2e02387f035d1f4d8cb9c02fed917fe6bd9d5dc`; bytes: 980083; counts: vortex_0_90=27, arrow_parquet_59_3_1=3, vortex_runend=2
- L7713: `  "hosted_failure_log": "\ufeff2026-10-31T02:36:44.6990308Z Current runner version: '2.338.2'\n2026-10-31T02:36:44.7025559Z ##[group]Runner Image Provisioner\n2026-10-31T02:36:44.7027357Z Hosted Compute Agent\n2026-10-31T02:36:44.7028415Z Version: 20261021.618\n2026-10-31T02:36:44.7029665Z Commit: 21505ad2541d5be6135ed84fc33697146cf75b8e\n2026-10-31T02:36:44.7030983Z Build Date: 2026-10-21T00:45:2`
### `docs/benchmarks/evidence/native-ingest-ownership-2026-10-25/verify.py`
- SHA-256: `c019525e4098febca4a334bc623f8a7482e7c33c88469b2b8b8f0b935c6c2f55`; bytes: 45515; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L418: `    require(report['provider_version'] == '=0.90.0', 'provider identity')`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/compact-group-protocol-r1.json`
- SHA-256: `9a8d6a842b4a79ea5286676ad3f1ef2fa3f9e6721c71d2669c78267f96a7b98d`; bytes: 8075; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L117: `    "version": "0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/group-hash-demand-protocol.json`
- SHA-256: `f255abe9abb248c485dc6d65ef95232ca77b7556dfa5361bbdc036be0dc8a373`; bytes: 8786; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L93: `      "Vortex 0.90.0 native VarBinView and dictionary code/domain owners, validity and checked utf8_slice_at",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol-v2.json`
- SHA-256: `ec8d16297897d1dc54e37974e62ecf180730873eb8cb3505109ea23aaea63e2d`; bytes: 13082; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L97: `    "provider_version": "Vortex 0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol-v3.json`
- SHA-256: `3c06d60f81bfdca55db40edc046d6bdf3f143c2dc25738d86dbffcec8e6f7ef9`; bytes: 13371; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L97: `    "provider_version": "Vortex 0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/integer-extrema-fusion-protocol.json`
- SHA-256: `d2ab042341477d085ddde3af922d5972a403a5b6213be451a844721afee21067`; bytes: 10114; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L96: `    "provider_version": "Vortex 0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/mixed-integer-expression-protocol.json`
- SHA-256: `573c9d083b72e826a5a4d10d4ace23bb23c33ff3a46831126819be28ecfb17dc`; bytes: 5470; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L67: `    "version": "0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/positive-gain-recovery-protocol.json`
- SHA-256: `3ae5891b3bb4666e2d19d1efe96fb49627cf7914910b99793a73f248fa686066`; bytes: 8242; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L102: `    "provider_version": "Vortex 0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/selected-payload-correctness-addendum.md`
- SHA-256: `80b6316d0a5ec0abc4b021953a891e363e393de773715081ec21392a961117a1`; bytes: 2851; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L19: `first and does not inspect missing parent positions. The local Vortex 0.90.0`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/selected-payload-validation-protocol.json`
- SHA-256: `c0c847c3ef7e86ca0183f9a1b59e1b4d98fb111cda7fd85043019261a48f4e90`; bytes: 7551; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L91: `      "Vortex 0.90.0 native selection, canonical DecimalArray buffers and validity",`
### `docs/benchmarks/evidence/native-item20-completion-2026-10-28/typed-numeric-expression-protocol.json`
- SHA-256: `7bbe21d5f549ef57f5b0dc9e6d910af59500ecf9cae7bcbd095cc83bb0a3962f`; bytes: 9931; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L92: `    "provider_version": "Vortex 0.90.0 pinned and vendored",`
### `docs/benchmarks/evidence/native-local-io-portable-2026-11-03/metadata/manifest.json`
- SHA-256: `0974640fe88aa466d1eca2b282a26c186a5ba3ffb4dda4491bda67e5e6f3b895`; bytes: 9142849; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"archive_code_execution":false,"campaign":{"bytes":1498757,"path":"/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31/local-io-r17/manifest.json","sha256":"e5a6e472e471584647c7c85b5e549eee000e95e254cedf66803863e6eb2a6d40"},"role":"metadata"},"parts":[{"directory":"part-000","manifest_bytes":454,"manifest_sha256":"896a51eb932d1be9721a84981b2a937d7c35e54e56265325903950a1faf`
### `docs/benchmarks/evidence/native-local-table-reader-review-2026-11-02/acceptance.json`
- SHA-256: `36042a400f3373b04778c64bb85a27b47795f56ed9d7f183b9386f2147163942`; bytes: 616660; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L186: `    ".github/provider-locks/vortex-runend.lock": {`
- L13518: `    "vendor/vortex-runend/Cargo.toml": {`
- L13522: `    "vendor/vortex-runend/src/arbitrary.rs": {`
- L13526: `    "vendor/vortex-runend/src/array.rs": {`
- L13530: `    "vendor/vortex-runend/src/compress.rs": {`
- L13534: `    "vendor/vortex-runend/src/compute/cast.rs": {`
- L13538: `    "vendor/vortex-runend/src/compute/compare.rs": {`
- L13542: `    "vendor/vortex-runend/src/compute/fill_null.rs": {`
- L13546: `    "vendor/vortex-runend/src/compute/filter.rs": {`
- L13550: `    "vendor/vortex-runend/src/compute/is_constant.rs": {`
- L13554: `    "vendor/vortex-runend/src/compute/is_sorted.rs": {`
- L13558: `    "vendor/vortex-runend/src/compute/min_max.rs": {`
- L13562: `    "vendor/vortex-runend/src/compute/mod.rs": {`
- L13566: `    "vendor/vortex-runend/src/compute/sum/kernel.rs": {`
- L13570: `    "vendor/vortex-runend/src/compute/sum/mod.rs": {`
- L13574: `    "vendor/vortex-runend/src/compute/sum/runs.rs": {`
- L13578: `    "vendor/vortex-runend/src/compute/sum/tests.rs": {`
- L13582: `    "vendor/vortex-runend/src/compute/take.rs": {`
- L13586: `    "vendor/vortex-runend/src/compute/take_from.rs": {`
- L13590: `    "vendor/vortex-runend/src/decompress_bool.rs": {`
- L13594: `    "vendor/vortex-runend/src/iter.rs": {`
- L13598: `    "vendor/vortex-runend/src/kernel.rs": {`
- L13602: `    "vendor/vortex-runend/src/lib.rs": {`
- L13606: `    "vendor/vortex-runend/src/ops.rs": {`
- L13610: `    "vendor/vortex-runend/src/probe.rs": {`
- L13614: `    "vendor/vortex-runend/src/probe/tests.rs": {`
- L13618: `    "vendor/vortex-runend/src/rules.rs": {`
- L13622: `    "vendor/vortex-runend/src/trace_tests.rs": {`
### `docs/benchmarks/evidence/native-local-table-readers-2026-11-02/acceptance.json`
- SHA-256: `d4ebe7e3e5b4d3f522612beb5137147971080dd2570fb928f8f6e6b6a1c5adcd`; bytes: 661070; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L46: `    ".github/provider-locks/vortex-runend.lock": {`
- L13370: `    "vendor/vortex-runend/Cargo.toml": {`
- L13374: `    "vendor/vortex-runend/src/arbitrary.rs": {`
- L13378: `    "vendor/vortex-runend/src/array.rs": {`
- L13382: `    "vendor/vortex-runend/src/compress.rs": {`
- L13386: `    "vendor/vortex-runend/src/compute/cast.rs": {`
- L13390: `    "vendor/vortex-runend/src/compute/compare.rs": {`
- L13394: `    "vendor/vortex-runend/src/compute/fill_null.rs": {`
- L13398: `    "vendor/vortex-runend/src/compute/filter.rs": {`
- L13402: `    "vendor/vortex-runend/src/compute/is_constant.rs": {`
- L13406: `    "vendor/vortex-runend/src/compute/is_sorted.rs": {`
- L13410: `    "vendor/vortex-runend/src/compute/min_max.rs": {`
- L13414: `    "vendor/vortex-runend/src/compute/mod.rs": {`
- L13418: `    "vendor/vortex-runend/src/compute/sum/kernel.rs": {`
- L13422: `    "vendor/vortex-runend/src/compute/sum/mod.rs": {`
- L13426: `    "vendor/vortex-runend/src/compute/sum/runs.rs": {`
- L13430: `    "vendor/vortex-runend/src/compute/sum/tests.rs": {`
- L13434: `    "vendor/vortex-runend/src/compute/take.rs": {`
- L13438: `    "vendor/vortex-runend/src/compute/take_from.rs": {`
- L13442: `    "vendor/vortex-runend/src/decompress_bool.rs": {`
- L13446: `    "vendor/vortex-runend/src/iter.rs": {`
- L13450: `    "vendor/vortex-runend/src/kernel.rs": {`
- L13454: `    "vendor/vortex-runend/src/lib.rs": {`
- L13458: `    "vendor/vortex-runend/src/ops.rs": {`
- L13462: `    "vendor/vortex-runend/src/probe.rs": {`
- L13466: `    "vendor/vortex-runend/src/probe/tests.rs": {`
- L13470: `    "vendor/vortex-runend/src/rules.rs": {`
- L13474: `    "vendor/vortex-runend/src/trace_tests.rs": {`
### `docs/benchmarks/evidence/native-ordered-inputs-2026-10-31/manifest.json`
- SHA-256: `3962bd8db9aaa5cbe8b24556e76c195acb35ba7305c1949799c3c0f362596312`; bytes: 4153037; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"assembly":[{"bytes":6784,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/ordered-input-assembly-r2/00.asm","sha256":"d81fc2d75711e9e95a80137745cd6709355ebb54be28b7d90b155738861fe9ff"},{"bytes":39019,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/ordered-input-assembly-r2/01.asm","sha256":"36d22e4ff1a8642a4b4c40ca69b48cb91358b7468195c59b4`
### `docs/benchmarks/evidence/native-performance-batch-2026-10-31/manifest.json`
- SHA-256: `05f617c5829ececb006a7ea0b746c81388ac70f55c0961f370915ab8a50496eb`; bytes: 7420456; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=56
- L1: `{"evidence":{"baseline_binding":{"bytes":1009098,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/batch-accepted-baseline-binding.json","sha256":"c1c28a819a7f3c0dd103b2c1c4dd4f39e6a4cd80571f41b3cad3f71dc92b883e"},"cohort":{"inputs":{"bytes":7697159,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-performance-batch-r1/inputs.json","sha256":"33f51ca9`
### `docs/benchmarks/evidence/native-preparation-contracts-2026-11-02/acceptance.json`
- SHA-256: `a3e1a50d44105efd4881d4f676c935a07b7451e599002b3c3d8d8978f5d17004`; bytes: 835803; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L4485: `    ".github/provider-locks/vortex-runend.lock": {`
- L17837: `    "vendor/vortex-runend/Cargo.toml": {`
- L17841: `    "vendor/vortex-runend/src/arbitrary.rs": {`
- L17845: `    "vendor/vortex-runend/src/array.rs": {`
- L17849: `    "vendor/vortex-runend/src/compress.rs": {`
- L17853: `    "vendor/vortex-runend/src/compute/cast.rs": {`
- L17857: `    "vendor/vortex-runend/src/compute/compare.rs": {`
- L17861: `    "vendor/vortex-runend/src/compute/fill_null.rs": {`
- L17865: `    "vendor/vortex-runend/src/compute/filter.rs": {`
- L17869: `    "vendor/vortex-runend/src/compute/is_constant.rs": {`
- L17873: `    "vendor/vortex-runend/src/compute/is_sorted.rs": {`
- L17877: `    "vendor/vortex-runend/src/compute/min_max.rs": {`
- L17881: `    "vendor/vortex-runend/src/compute/mod.rs": {`
- L17885: `    "vendor/vortex-runend/src/compute/sum/kernel.rs": {`
- L17889: `    "vendor/vortex-runend/src/compute/sum/mod.rs": {`
- L17893: `    "vendor/vortex-runend/src/compute/sum/runs.rs": {`
- L17897: `    "vendor/vortex-runend/src/compute/sum/tests.rs": {`
- L17901: `    "vendor/vortex-runend/src/compute/take.rs": {`
- L17905: `    "vendor/vortex-runend/src/compute/take_from.rs": {`
- L17909: `    "vendor/vortex-runend/src/decompress_bool.rs": {`
- L17913: `    "vendor/vortex-runend/src/iter.rs": {`
- L17917: `    "vendor/vortex-runend/src/kernel.rs": {`
- L17921: `    "vendor/vortex-runend/src/lib.rs": {`
- L17925: `    "vendor/vortex-runend/src/ops.rs": {`
- L17929: `    "vendor/vortex-runend/src/probe.rs": {`
- L17933: `    "vendor/vortex-runend/src/probe/tests.rs": {`
- L17937: `    "vendor/vortex-runend/src/rules.rs": {`
- L17941: `    "vendor/vortex-runend/src/trace_tests.rs": {`
### `docs/benchmarks/evidence/native-shared-followthrough-2026-10-30/manifest.json`
- SHA-256: `0a5390883939e53cb518d1d6208806c8feca108ad5258f4afa27ac1c46f58d53`; bytes: 4643672; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"cohorts":[{"inputs":{"bytes":7700814,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-mixed-aggregate-r1/inputs.json","sha256":"6887fbe202172d4a537b42466378b800ce7c63618e889ffff316359f8b53c39a"},"name":"broad-mixed-aggregate-r1","protocol":{"bytes":10134,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-mixed-aggregate-r1/protoco`
### `docs/benchmarks/evidence/native-shared-performance-2026-10-30/manifest.json`
- SHA-256: `5e2a66840fb2ba0f7a81cd9ecdaadecce69abd0170bd6fda3339233ab91e640e`; bytes: 10975131; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=56
- L1: `{"evidence":{"cohorts":[{"inputs":{"bytes":7694749,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-composition-baseline-r1/inputs.json","sha256":"ee8b095de3f1c3680e3a7892e07bf9ec897880374639efe3f17c7e3209d04a4d"},"name":"broad-composition-baseline-r1","protocol":{"bytes":2938,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/broad-composition-basel`
### `docs/benchmarks/evidence/native-single-predicate-masks-2026-10-30/manifest.json`
- SHA-256: `d45e84568bf56a5d0fc65c0aac1d138edbd58a8b12eb926de643928509ca75be`; bytes: 3364257; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"accepted_application_runtime":{"bytes":548297,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/application-batch-release-r1/manifest.json","sha256":"66d3ab6575cfcca6ad69a0e4a419b26267d72a5b2001c4c8ef26e2933b6c84ef"},"application_closeout":[{"bytes":1308819,"path":"/Users/dylan/.codex/worktrees/native-analytic-frames/shardloom-local-repo/docs/benchmarks/evidence/`
### `docs/benchmarks/evidence/native-structural-provider-2026-10-21/verify_acceptance.py`
- SHA-256: `96acca81f1c9baf4686e2e7e58b4bb3ae2c667732cffe6b8fb50c96ad4f655cd`; bytes: 55109; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L28: `           'shardloom_core', 'shardloom_exec', 'vortex_array', 'vortex_runend',`
### `docs/benchmarks/evidence/native-surface-parity-2026-10-24/ci-repairs.json`
- SHA-256: `17f7d9ecd6ef71b7faa98724fe4887098430ebbab89efd7ecec83b7edaed1a64`; bytes: 12091; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- L47: `      "log_text": "   Compiling serde_core v1.0.229\n   Compiling zstd-sys v2.0.16+zstd.1.5.7\n    Checking serde_json v1.0.154\n    Checking arrow-schema v58.3.0\n    Checking vortex-error v0.85.0\n    Checking serde v1.0.229\n    Checking vortex-buffer v0.85.0\n    Checking vortex-session v0.85.0\n    Checking vortex-mask v0.85.0\n    Checking vortex-flatbuffers v0.85.0\n    Checking vortex-comp`
### `docs/benchmarks/evidence/native-typed-ordering-2026-10-31/manifest.json`
- SHA-256: `b59009f81927c84bb8e2b27d8637b57f6242bb133b847426de4a83a2b137d0cc`; bytes: 3850405; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L1: `{"evidence":{"assembly":[{"bytes":8928,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/typed-ordering-assembly-r1/asof_comparison.asm","sha256":"2b8df1185c7b17106711c6dc45504702c8024f86e561060aab8f6de2108a30e5"},{"bytes":7392,"path":"/Users/dylan/LocalData/shardloom/shared-performance-2026-10-29/typed-ordering-assembly-r1/asof_owner.asm","sha256":"12f80de35bab5a3721b0dff5767`
### `docs/benchmarks/evidence/native-typed-reductions-package-checker-2026-10-05.json`
- SHA-256: `ef0fa625f8bf6b4cceb15eef00bfea284ad8540c8721b06ebf8be04e704f636c`; bytes: 670446; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L68: `        "stderr": "\u001b[1m\u001b[92m    Updating\u001b[0m crates.io index\n\u001b[1m\u001b[92m   Compiling\u001b[0m serde_json v1.0.151\n\u001b[1m\u001b[92m   Compiling\u001b[0m serde v1.0.229\n\u001b[1m\u001b[92m   Compiling\u001b[0m shardloom-core v0.4.0 (<repo>/shardloom-core)\n\u001b[1m\u001b[92m   Compiling\u001b[0m shardloom-vortex v0.4.0 (<repo>/shardloom-vortex)\n\u001b[1m\u001b[92m   Co`
### `docs/benchmarks/evidence/native-varbin-metadata-resources-2026-10-16.json`
- SHA-256: `304ee5884c5552044fed1e3e8d114a7826ec830fee728e49f6ebb2e0a960889a`; bytes: 8122; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L110: `    "vendor/vortex-runend/.cargo_vcs_info.json",`
- L111: `    "vendor/vortex-runend/Cargo.toml",`
- L112: `    "vendor/vortex-runend/Cargo.toml.orig",`
- L113: `    "vendor/vortex-runend/LICENSE",`
- L114: `    "vendor/vortex-runend/README.md",`
- L115: `    "vendor/vortex-runend/README.shardloom.md",`
- L116: `    "vendor/vortex-runend/goldenfiles/runend.metadata",`
- L117: `    "vendor/vortex-runend/src/arbitrary.rs",`
- L118: `    "vendor/vortex-runend/src/array.rs",`
- L119: `    "vendor/vortex-runend/src/compress.rs",`
- L120: `    "vendor/vortex-runend/src/compute/cast.rs",`
- L121: `    "vendor/vortex-runend/src/compute/compare.rs",`
- L122: `    "vendor/vortex-runend/src/compute/fill_null.rs",`
- L123: `    "vendor/vortex-runend/src/compute/filter.rs",`
- L124: `    "vendor/vortex-runend/src/compute/is_constant.rs",`
- L125: `    "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L126: `    "vendor/vortex-runend/src/compute/min_max.rs",`
- L127: `    "vendor/vortex-runend/src/compute/mod.rs",`
- L128: `    "vendor/vortex-runend/src/compute/take.rs",`
- L129: `    "vendor/vortex-runend/src/compute/take_from.rs",`
- L130: `    "vendor/vortex-runend/src/decompress_bool.rs",`
- L131: `    "vendor/vortex-runend/src/iter.rs",`
- L132: `    "vendor/vortex-runend/src/kernel.rs",`
- L133: `    "vendor/vortex-runend/src/lib.rs",`
- L134: `    "vendor/vortex-runend/src/ops.rs",`
- L135: `    "vendor/vortex-runend/src/rules.rs",`
- L136: `    "vendor/vortex-runend/src/trace_tests.rs",`
- L137: `    "vendor/vortex-runend/upstream-provenance.json",`
### `docs/benchmarks/evidence/native-varbin-metadata-review-2026-10-16.json`
- SHA-256: `50ff9b0e0f6dac0712a86345ebcd4c0d7fc480bc26a1dcf7be3a900a0e6e34ec`; bytes: 12174; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=28
- L113: `    "vendor/vortex-runend/.cargo_vcs_info.json",`
- L114: `    "vendor/vortex-runend/Cargo.toml",`
- L115: `    "vendor/vortex-runend/Cargo.toml.orig",`
- L116: `    "vendor/vortex-runend/LICENSE",`
- L117: `    "vendor/vortex-runend/README.md",`
- L118: `    "vendor/vortex-runend/README.shardloom.md",`
- L119: `    "vendor/vortex-runend/goldenfiles/runend.metadata",`
- L120: `    "vendor/vortex-runend/src/arbitrary.rs",`
- L121: `    "vendor/vortex-runend/src/array.rs",`
- L122: `    "vendor/vortex-runend/src/compress.rs",`
- L123: `    "vendor/vortex-runend/src/compute/cast.rs",`
- L124: `    "vendor/vortex-runend/src/compute/compare.rs",`
- L125: `    "vendor/vortex-runend/src/compute/fill_null.rs",`
- L126: `    "vendor/vortex-runend/src/compute/filter.rs",`
- L127: `    "vendor/vortex-runend/src/compute/is_constant.rs",`
- L128: `    "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L129: `    "vendor/vortex-runend/src/compute/min_max.rs",`
- L130: `    "vendor/vortex-runend/src/compute/mod.rs",`
- L131: `    "vendor/vortex-runend/src/compute/take.rs",`
- L132: `    "vendor/vortex-runend/src/compute/take_from.rs",`
- L133: `    "vendor/vortex-runend/src/decompress_bool.rs",`
- L134: `    "vendor/vortex-runend/src/iter.rs",`
- L135: `    "vendor/vortex-runend/src/kernel.rs",`
- L136: `    "vendor/vortex-runend/src/lib.rs",`
- L137: `    "vendor/vortex-runend/src/ops.rs",`
- L138: `    "vendor/vortex-runend/src/rules.rs",`
- L139: `    "vendor/vortex-runend/src/trace_tests.rs",`
- L140: `    "vendor/vortex-runend/upstream-provenance.json",`
### `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-check-repair.json`
- SHA-256: `6cda58c911aa28a32b942e7081441c3f27238983374ca82d7a4dc16a6ef5735f`; bytes: 1466; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L9: `  "cause": "The controlled provider review omitted the current manifest-requirement and resolved-lock version markers; the old marker rendered an exact Cargo pin as vortex = =0.90.0.",`
### `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-scripts-local-r1.log`
- SHA-256: `7a3772ab99ec736d619e97d1cdfa51ac2afa5ccfc18b8108af4a4ebd5a252ab5`; bytes: 7070; counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L12: ` : ['PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: vortex = =0.90.0', 'PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: 'Cargo.lock' records the upstream Vortex crate family at '0.90.0'']`
- L112: ` : ['PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: vortex = =0.90.0', 'PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: 'Cargo.lock' records the upstream Vortex crate family at '0.90.0'']`
### `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/ci-release-scripts-remote-r1.log`
- SHA-256: `933720bd03ff1de7c257f216f43548e91779089a15cd502dc67c5c43534d5bb1`; bytes: 34793; counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L269: `2026-10-25T00:31:13.8410651Z  : ['PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: vortex = =0.90.0', 'PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: 'Cargo.lock' records the upstream Vortex crate family at '0.90.0'']`
- L364: `2026-10-25T00:31:13.8445379Z  : ['PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: vortex = =0.90.0', 'PR #1223: docs/dependencies/vortex-upstream-review.md missing marker: 'Cargo.lock' records the upstream Vortex crate family at '0.90.0'']`
### `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/clean-checkout.json`
- SHA-256: `ffb0e790945b02041617d3532b21fd7054f69aae2410cf85b4c3ff204aa5cd6b`; bytes: 3504; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L12: `    "vendor/vortex-runend/Cargo.lock",`
### `docs/benchmarks/evidence/native-vortex-provider-refresh-2026-10-24/manifest.json`
- SHA-256: `bf99431f11d4f3cfee6df9d4584fba31b557a1d3bdc3b35f8f7d8685d3262982`; bytes: 17684375; counts: vortex_0_90=61, arrow_parquet_59_3_1=55, vortex_runend=4
- L1: `{"schema":"shardloom.native_provider_refresh.packet.v1","status":"complete","source_commit":"4117846158edc7b1ab692ef90dd99ba686c5360c","files":[{"bytes":8551,"member":"objects/4afa04814edf3a4c52ff26fd87ea3b5dd92c7264b2d8d69ee718709f3df6f09b","path":"/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/benchmarks/clickbench/queries.sql","sha256":"4afa04814edf3a4c52ff26fd87ea3b5dd92c72`
### `docs/benchmarks/evidence/native-warm-source-reuse-2026-10-25/cleanup.json`
- SHA-256: `1e3bcb2ec5b9ea9a20c912945bf6c7c2aa6e74c44d0c447376fff9c0b8ed136c`; bytes: 88027; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- L779: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend/goldenfiles",`
- L780: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend/src/compute/sum",`
- L781: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend/src/compute",`
- L782: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend/src/probe",`
- L783: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend/src",`
- L784: `    "/Users/dylan/LocalData/shardloom/native-warm-reuse-20261025/clean-checkout-r1/vendor/vortex-runend",`
### `docs/benchmarks/evidence/nested-identity-restoration-762.json`
- SHA-256: `60a593aad0a0d42c8bbd061d88643b1ffa2a6d4397cc786a152d528880b5e1b0`; bytes: 496064; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- L11197: `      "path": "vendor/vortex-runend/Cargo.toml",`
- L11203: `      "path": "vendor/vortex-runend/Cargo.toml.orig",`
- L11209: `      "path": "vendor/vortex-runend/src/arbitrary.rs",`
- L11215: `      "path": "vendor/vortex-runend/src/array.rs",`
- L11221: `      "path": "vendor/vortex-runend/src/compress.rs",`
- L11227: `      "path": "vendor/vortex-runend/src/compute/cast.rs",`
- L11233: `      "path": "vendor/vortex-runend/src/compute/compare.rs",`
- L11239: `      "path": "vendor/vortex-runend/src/compute/fill_null.rs",`
- L11245: `      "path": "vendor/vortex-runend/src/compute/filter.rs",`
- L11251: `      "path": "vendor/vortex-runend/src/compute/is_constant.rs",`
- L11257: `      "path": "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L11263: `      "path": "vendor/vortex-runend/src/compute/min_max.rs",`
- L11269: `      "path": "vendor/vortex-runend/src/compute/mod.rs",`
- L11275: `      "path": "vendor/vortex-runend/src/compute/take.rs",`
- L11281: `      "path": "vendor/vortex-runend/src/compute/take_from.rs",`
- L11287: `      "path": "vendor/vortex-runend/src/decompress_bool.rs",`
- L11293: `      "path": "vendor/vortex-runend/src/iter.rs",`
- L11299: `      "path": "vendor/vortex-runend/src/kernel.rs",`
- L11305: `      "path": "vendor/vortex-runend/src/lib.rs",`
- L11311: `      "path": "vendor/vortex-runend/src/ops.rs",`
- L11317: `      "path": "vendor/vortex-runend/src/rules.rs",`
- L11323: `      "path": "vendor/vortex-runend/src/trace_tests.rs",`
### `docs/benchmarks/evidence/nested-key-attribution-760.json`
- SHA-256: `001cab8fa974c890d49190d3c84f55a8b9086d594d942ab114da9ee10a4aa04e`; bytes: 1209027; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=4
- L13048: `      "path": "/Users/dylan/.cache/shardloom/cargo-target/release/deps/libvortex_runend-2463dbd6d36a61ea.rlib",`
- L13067: `      "path": "/Users/dylan/.cache/shardloom/cargo-target/release/deps/libvortex_runend-2463dbd6d36a61ea.rmeta",`
- L26064: `      "path": "/Users/dylan/.cache/shardloom/cargo-target/release/deps/libvortex_runend-2463dbd6d36a61ea.rlib",`
- L26083: `      "path": "/Users/dylan/.cache/shardloom/cargo-target/release/deps/libvortex_runend-2463dbd6d36a61ea.rmeta",`
### `docs/benchmarks/evidence/predicate-exclusion-restoration-770.json`
- SHA-256: `307c98927a7526a5b4d2c20817f3fac07b6a12c4e2087794e110f2bed4bcfaf3`; bytes: 500777; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- L11175: `      "path": "vendor/vortex-runend/Cargo.toml",`
- L11181: `      "path": "vendor/vortex-runend/Cargo.toml.orig",`
- L11187: `      "path": "vendor/vortex-runend/src/arbitrary.rs",`
- L11193: `      "path": "vendor/vortex-runend/src/array.rs",`
- L11199: `      "path": "vendor/vortex-runend/src/compress.rs",`
- L11205: `      "path": "vendor/vortex-runend/src/compute/cast.rs",`
- L11211: `      "path": "vendor/vortex-runend/src/compute/compare.rs",`
- L11217: `      "path": "vendor/vortex-runend/src/compute/fill_null.rs",`
- L11223: `      "path": "vendor/vortex-runend/src/compute/filter.rs",`
- L11229: `      "path": "vendor/vortex-runend/src/compute/is_constant.rs",`
- L11235: `      "path": "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L11241: `      "path": "vendor/vortex-runend/src/compute/min_max.rs",`
- L11247: `      "path": "vendor/vortex-runend/src/compute/mod.rs",`
- L11253: `      "path": "vendor/vortex-runend/src/compute/take.rs",`
- L11259: `      "path": "vendor/vortex-runend/src/compute/take_from.rs",`
- L11265: `      "path": "vendor/vortex-runend/src/decompress_bool.rs",`
- L11271: `      "path": "vendor/vortex-runend/src/iter.rs",`
- L11277: `      "path": "vendor/vortex-runend/src/kernel.rs",`
- L11283: `      "path": "vendor/vortex-runend/src/lib.rs",`
- L11289: `      "path": "vendor/vortex-runend/src/ops.rs",`
- L11295: `      "path": "vendor/vortex-runend/src/rules.rs",`
- L11301: `      "path": "vendor/vortex-runend/src/trace_tests.rs",`
### `docs/benchmarks/evidence/prepared-sampling-2026-10-21/verify_acceptance.py`
- SHA-256: `d658cc0da3f7937d3a0f063946de5d13074515ac3375a46702e2654ccc3dfc10`; bytes: 66681; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L690: `               'vortex_array', 'vortex_runend', 'vortex_fsst', 'vortex_zstd', 'vortex_datetime_parts', 'vortex_layout', 'vortex_file'}`
### `docs/benchmarks/evidence/rematerialization-restoration-780.json`
- SHA-256: `cedd6dd685e61e64e10407cf2943766405ddb1bdac19333590315544ddf41def`; bytes: 500317; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=22
- L11174: `      "path": "vendor/vortex-runend/Cargo.toml",`
- L11180: `      "path": "vendor/vortex-runend/Cargo.toml.orig",`
- L11186: `      "path": "vendor/vortex-runend/src/arbitrary.rs",`
- L11192: `      "path": "vendor/vortex-runend/src/array.rs",`
- L11198: `      "path": "vendor/vortex-runend/src/compress.rs",`
- L11204: `      "path": "vendor/vortex-runend/src/compute/cast.rs",`
- L11210: `      "path": "vendor/vortex-runend/src/compute/compare.rs",`
- L11216: `      "path": "vendor/vortex-runend/src/compute/fill_null.rs",`
- L11222: `      "path": "vendor/vortex-runend/src/compute/filter.rs",`
- L11228: `      "path": "vendor/vortex-runend/src/compute/is_constant.rs",`
- L11234: `      "path": "vendor/vortex-runend/src/compute/is_sorted.rs",`
- L11240: `      "path": "vendor/vortex-runend/src/compute/min_max.rs",`
- L11246: `      "path": "vendor/vortex-runend/src/compute/mod.rs",`
- L11252: `      "path": "vendor/vortex-runend/src/compute/take.rs",`
- L11258: `      "path": "vendor/vortex-runend/src/compute/take_from.rs",`
- L11264: `      "path": "vendor/vortex-runend/src/decompress_bool.rs",`
- L11270: `      "path": "vendor/vortex-runend/src/iter.rs",`
- L11276: `      "path": "vendor/vortex-runend/src/kernel.rs",`
- L11282: `      "path": "vendor/vortex-runend/src/lib.rs",`
- L11288: `      "path": "vendor/vortex-runend/src/ops.rs",`
- L11294: `      "path": "vendor/vortex-runend/src/rules.rs",`
- L11300: `      "path": "vendor/vortex-runend/src/trace_tests.rs",`
### `docs/benchmarks/evidence/required-execution-resources-shared-writers-2026-10-10.json`
- SHA-256: `be02d72260a7f5aaf4948274bfd092dba030f8db13ff75340a19c4949196dcb5`; bytes: 7227425; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L5031: `        "text": "   Compiling vortex-buffer v0.85.0\n   Compiling shardloom-vortex v0.5.1 (/Users/dylan/.codex/worktrees/native-analytic-frames/shardloom-local-repo/shardloom-vortex)\n   Compiling vortex-flatbuffers v0.85.0\n   Compiling vortex-compute v0.85.0\n   Compiling vortex-mask v0.85.0\n   Compiling serde v1.0.229\n   Compiling vortex-array v0.85.0\n   Compiling arrow-avro v58.3.0\n   Comp`
### `docs/benchmarks/native-analytical-aggregates-2026-10-27.md`
- SHA-256: `750883a25e2646881f69083d2336f73bd91fa63d771a0d80a2c0126df4c86c55`; bytes: 11260; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L46: `0.90.0 arrays, masks, native gathers, list/constant constructors and persistence.`
### `docs/benchmarks/native-broad-query-2026-10-26.md`
- SHA-256: `10e339fcfff0e96b73115abf27a134236e6c346ff919f891d40f4447abc65654`; bytes: 15113; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L171: `Vortex-first decision: **wrap_vortex_concept**. The pinned Vortex 0.90.0 filtered`
### `docs/benchmarks/native-ingest-window-decision-2026-10-25.md`
- SHA-256: `39d048edf3b987e636f71f0626970914e9d0805484253d5ad26581dd011979ed`; bytes: 4840; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L62: `The pinned Parquet 59.3.1 byte-array dictionary reader can retain source codes`
### `docs/benchmarks/native-shared-analytical-performance-2026-10-27.md`
- SHA-256: `bdebf4c210ace289a6483e16f78b72d12c01a782c22735183d54d1d2c82b0aba`; bytes: 12262; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L49: `Vortex-first review reuses admitted Vortex 0.90.0 primitive buffers, validity`
### `docs/benchmarks/native-vortex-provider-refresh-2026-10-24.md`
- SHA-256: `3cf56705a09d221bfcc9cb02009e174f828b7b183859d6e945698969c7dcd2d5`; bytes: 8504; counts: vortex_0_90=1, arrow_parquet_59_3_1=1, vortex_runend=0
- L5: `The controlled Vortex 0.90.0 refresh passes local runtime and UAT acceptance on`
- L25: `DateTimeParts patch, and uses upstream Arrow/Python 59.3.1 instead of its former`
### `docs/dependencies/adbc-local-driver-review.md`
- SHA-256: `60f0af1731a7781b22f44f56164a39b2794c38060deadfc53f89211b578a7fff`; bytes: 5028; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L14: `workspace retains its single Arrow 59.3.1 graph. These two crates add no query`
### `docs/dependencies/arrow-run-end-validation-2026-11-05.md`
- SHA-256: `745de54aafbc43c7c4d45660190aa1dc46efff42b59b7da583c175632bbd501f`; bytes: 3974; counts: vortex_0_90=1, arrow_parquet_59_3_1=3, vortex_runend=0
- L5: `for 'arrow-data 59.3.1'. The`
- L12: `from '59.3.1' to '59.3.2'. The latter two satisfy 'arrow-data''s minimum`
- L14: `locked packages, Vortex 0.90.0 and the existing IPC/Avro/Parquet/ORC path patches`
- L46: `failed against '59.3.1': checked construction accepted a parent of length seven`
### `docs/dependencies/json-digest-dependency-review.md`
- SHA-256: `ec077660f918812df8812d71dc27c4b0d56aecb63552f1b60ff7046433152bf2`; bytes: 7597; counts: vortex_0_90=1, arrow_parquet_59_3_1=2, vortex_runend=0
- L13: `'add_extension_module_link_args()'. The root dependency graph now aligns Vortex 0.90.0,`
- L14: `Arrow 59.3.1, Parquet 59.3.1 and ORC 0.9.0. This updates the compatibility-candidate`
### `docs/dependencies/rust-vortex-refresh-2026-10-03.json`
- SHA-256: `fe131af75974c7edd15363ad0ba07255a6796b723242b27d6a81ff92e02c90f3`; bytes: 35320; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L129: `    "vortex-runend": "0.85.0",`
### `docs/dependencies/structured-format-dependency-review.md`
- SHA-256: `17814e5f0afced093c89318b832eb0f3022494769e4d3bbd8f370f2930e9a85c`; bytes: 13901; counts: vortex_0_90=2, arrow_parquet_59_3_1=11, vortex_runend=0
- L20: `The root dependency graph now aligns Vortex 0.90.0 with the Arrow family and Parquet 59.3.1;`
- L22: `not admit new formats, runtime capabilities or external-engine execution. 'arrow-pyarrow' 59.3.1`
- L29: `the aligned graph and are not included. Parquet 59.3.1 and ORC 0.9.0 are integrated in this`
- L34: `## 2026-10-17 Arrow 60 / Parquet 59.3.1 Review Deferral`
- L42: `- Its proposed direct Arrow 60, Parquet 59.3.1, and ORC 0.9.0 updates would split the current`
- L45: `  types, plus ORC's Arrow 59.3.1 'ArrowReader<File>' not implementing the direct`
- L67: `- The current candidate uses Vortex 0.90.0, Arrow 59.3.1, Parquet 59.3.1 and 'orc-rust' 0.9.0;`
- L69: `- 'arrow-pyarrow' 59.3.1 resolves from the registry instead of a workspace path patch. The`
- L72: `  remains excluded because it would split the selected Arrow graph. Its Parquet 59.3.1 and`
- L90: `The feature-gated Parquet 59.3.1 reader now has a separate metadata-first source-demand path for`
### `docs/dependencies/temporal-calendar-provider-review.md`
- SHA-256: `7abe315e9a2b2003f3dfeca96f4fd31a2f18921f1b949b1866550ce7df233d70`; bytes: 7517; counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L48: `The existing vendored Vortex 0.90.0 timestamp patch is expanded from naive`
- L59: `Vortex 0.90.0 supplies Date, Time and Timestamp extensions but no fixed-duration`
- L95: `DateTimeParts defect: its 0.90.0 compressor narrows the timestamp day count to`
- L103: `restore the older comparison patch, which 0.90.0 already incorporates.`
### `docs/dependencies/vortex-dependency-footprint.md`
- SHA-256: `158d76cc3c08ad7d6cddeeb2e3af0c0414d1c6ce9d69aab79dd1bb7ebb4160c1`; bytes: 18428; counts: vortex_0_90=3, arrow_parquet_59_3_1=3, vortex_runend=1
- L17: `- The optional upstream Vortex umbrella is pinned to 0.90.0 in the workspace and inherited`
- L19: `- Eight 0.90.0 packages remain local path patches: 'vortex-array', 'vortex-buffer',`
- L20: `  'vortex-file', 'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-runend' and`
- L22: `  'vortex-datetime-parts' now resolves from its reviewed 0.90.0 registry archive.`
- L26: `- The workspace uses Arrow 59.3.1 and Parquet 59.3.1 with ORC 0.9.0. 'arrow-pyarrow'`
- L27: `  59.3.1 resolves from the registry after its workspace path patch was removed; the unused`
### `docs/dependencies/vortex-upstream-review.md`
- SHA-256: `15c642d93b42b385698e310f04ecb1d4566705f7f6d095571b51aa49f008f253`; bytes: 53231; counts: vortex_0_90=12, arrow_parquet_59_3_1=6, vortex_runend=3
- L8: `stays pinned, including Vortex 0.90.0 and the existing 59.3.1 Arrow/Parquet`
- L30: `Vortex 0.90.0, Arrow/Parquet 59.3.1, ORC 0.9.0 and native libzstd 1.5.7 remain`
- L49: `The root graph now pins Vortex 0.90.0, the Arrow family and Parquet 59.3.1, ORC 0.9.0,`
- L53: `Vortex manifest requirement: '=0.90.0'.`
- L54: `'Cargo.lock' records the upstream Vortex crate family at '0.90.0'.`
- L57: `0.90.0 archive, the registry identity is reviewed, and 87 upstream plus four native`
- L58: `temporal tests pass. Eight path patches remain at 0.90.0: array, buffer, file, FSST,`
- L63: `'arrow-pyarrow' 59.3.1 now resolves from the registry instead of the former workspace`
- L93: `## October 24, 2026 controlled 0.90 intake`
- L106: `change or 0.90 performance claim is established by this intake note.`
- L169: `the already-transitive Apache-2.0 'vortex-fsst' and 'vortex-runend' 0.85.0 crates.`
- L176: `[RunEnd provenance](../../vendor/vortex-runend/upstream-provenance.json) retain`
- L504: `- Upstream Vortex 0.90.0 remains an optional provider isolated in 'shardloom-vortex' and`
- L506: `  to 59.3.1 and ORC to 0.9.0.`
- L508: `  'vortex-fsst', 'vortex-io', 'vortex-layout', 'vortex-runend' and 'vortex-zstd', all at 0.90.0.`
- L509: `  'vortex-datetime-parts' resolves from the 0.90.0 registry archive after its local`
- L511: `- 'arrow-pyarrow' 59.3.1 resolves from the registry; the unused 'vendor/arrow-pyarrow'`
### `docs/reference/shardloom-user-surface-index.json`
- SHA-256: `a32dacb8fda58449771c381043f962a8577f9915f02ca2f11886c1d36826e573`; bytes: 273494; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L117: `    "native_ipc_provider_version": "0.90.0",`
### `python/THIRD_PARTY_LICENSES/manifest.json`
- SHA-256: `1aa755a4b38868954dcf55a71554fa07f498636ef22c6b9449a92c2231153f03`; bytes: 666812; counts: vortex_0_90=52, arrow_parquet_59_3_1=41, vortex_runend=7
- L281: `      "version": "59.3.1",`
- L303: `      "version": "59.3.1",`
- L347: `      "version": "59.3.1",`
- L369: `      "version": "59.3.1",`
- L391: `      "version": "59.3.1",`
- L413: `      "version": "59.3.1",`
- L435: `      "version": "59.3.1",`
- L457: `      "version": "59.3.1",`
- L479: `      "version": "59.3.1",`
- L523: `      "version": "59.3.1",`
- L545: `      "version": "59.3.1",`
- L7637: `      "version": "0.90.0",`
- L7653: `      "version": "0.90.0",`
- L7669: `      "version": "0.90.0",`
- L7685: `      "version": "0.90.0",`
- L7701: `      "version": "0.90.0",`
- L7717: `      "version": "0.90.0",`
- L7733: `      "version": "0.90.0",`
- L7749: `      "version": "0.90.0",`
- L7765: `      "version": "0.90.0",`
- L7781: `      "version": "0.90.0",`
- L7797: `      "version": "0.90.0",`
- L7813: `      "version": "0.90.0",`
- L7829: `      "version": "0.90.0",`
- L7845: `      "version": "0.90.0",`
- L7861: `      "version": "0.90.0",`
- L7877: `      "version": "0.90.0",`
- L7893: `      "version": "0.90.0",`
- L7909: `      "version": "0.90.0",`
- L7925: `      "version": "0.90.0",`
- L7941: `      "version": "0.90.0",`
- L7957: `      "version": "0.90.0",`
- L7973: `      "version": "0.90.0",`
- L7989: `      "version": "0.90.0",`
- L8005: `      "version": "0.90.0",`
- L9211: `      "version": "59.3.1",`
- L9224: `            "url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"`
- L9229: `        "license_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt",`
- L9241: `        "notice_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt",`
- L9320: `        "source_of_truth": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate",`
- L9321: `        "version": "59.3.1"`
- L9329: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt"`
- L9336: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt"`
- L9343: `          "upstream_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"`
- L9349: `      "version": "59.3.1",`
- L9416: `        "license_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt",`
- L9432: `        "notice_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt",`
- L9475: `        "source_of_truth": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate",`
- L9914: `        "version": "59.3.1"`
- L9922: `          "upstream_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt"`
- L9929: `          "upstream_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt"`
- L10030: `      "version": "59.3.1",`
- L10054: `        "license_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt",`
- L10066: `        "notice_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt",`
- L10101: `        "source_of_truth": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate",`
- L10103: `        "version": "59.3.1"`
- L10111: `          "upstream_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt"`
- L10118: `          "upstream_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt"`
- L10279: `      "version": "59.3.1",`
- L10291: `        "license_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt",`
- L10321: `        "notice_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt",`
- L10561: `        "source_of_truth": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate",`
- L10563: `        "version": "59.3.1"`
- L10571: `          "upstream_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt"`
- L10578: `          "upstream_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt"`
- L10584: `      "version": "0.90.0",`
- L10589: `        "version": "0.90.0",`
- L11409: `        "source_of_truth": "https://static.crates.io/crates/vortex-array/vortex-array-0.90.0.crate",`
- L11492: `            "modification": "The local 0.85 pinned clippy.toml was modified to remove the obsolete legacy_session prohibited method; it is supplemental local lint configuration, not an unchanged Vortex 0.90 archive member.",`
- L11509: `      "version": "0.90.0",`
- L11514: `        "version": "0.90.0",`
- L11561: `        "source_of_truth": "https://static.crates.io/crates/vortex-buffer/vortex-buffer-0.90.0.crate",`
- L11592: `      "version": "0.90.0",`
- L11597: `        "version": "0.90.0",`
- L11632: `        "source_of_truth": "https://static.crates.io/crates/vortex-datetime-parts/vortex-datetime-parts-0.90.0.crate",`
- L11690: `      "version": "0.90.0",`
- L11695: `        "version": "0.90.0",`
- L11745: `        "source_of_truth": "https://static.crates.io/crates/vortex-file/vortex-file-0.90.0.crate",`
- L11794: `      "version": "0.90.0",`
- L11799: `        "version": "0.90.0",`
- L11838: `        "source_of_truth": "https://static.crates.io/crates/vortex-fsst/vortex-fsst-0.90.0.crate",`
- L11896: `      "version": "0.90.0",`
- L11901: `        "version": "0.90.0",`
- L11965: `        "source_of_truth": "https://static.crates.io/crates/vortex-io/vortex-io-0.90.0.crate",`
- L12000: `      "version": "0.90.0",`
- L12005: `        "version": "0.90.0",`
- L12170: `        "source_of_truth": "https://static.crates.io/crates/vortex-layout/vortex-layout-0.90.0.crate",`
- L12253: `      "name": "vortex-runend",`
- L12254: `      "version": "0.90.0",`
- L12255: `      "path": "vendor/vortex-runend",`
- L12258: `        "provider": "vortex-runend",`
- L12259: `        "version": "0.90.0",`
- L12304: `        "source_of_truth": "https://static.crates.io/crates/vortex-runend/vortex-runend-0.90.0.crate",`
- L12312: `          "provenance_path": "vendor/vortex-runend/upstream-provenance.json"`
- L12329: `            "provider": "vortex-runend",`
- L12356: `      "version": "0.90.0",`
- L12420: `        "source_of_truth": "https://static.crates.io/crates/vortex-zstd/vortex-zstd-0.90.0.crate",`
- L12429: `        "version": "0.90.0"`
### `python/src/shardloom/adbc.py`
- SHA-256: `bc67d193cf9d386aba3e71b994ad710637e4274398d8ea880d7b86b8a0b1f84d`; bytes: 11200; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L181: `                  100: "ShardLoom local ADBC", 101: __version__, 102: "59.3.1", 103: 1_001_000}`
### `python/tests/test_public_context.py`
- SHA-256: `7a9614a2e87082cbe827f1652d6498c734acdf31944f0617ff89f5cce8718d06`; bytes: 23847; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L214: `                self.assertEqual(result.details.field("resident_provider_version"), "=0.90.0")`
### `scripts/ci_provider_tests.py`
- SHA-256: `deca0be72ad8e942d93cc91231570e7d025108e818814104054f9ed8f8ba39c1`; bytes: 7047; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- L16: `    "arrays": ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-zstd",`
- L25: `    "vortex-runend": {"features": "vortex-array/table-display", "patches": ["vortex-array"]},`
### `scripts/local_io_portable_replay.py`
- SHA-256: `34c7dd8f7983a0d996d23208619a6017466f96058302fe48694dd4fb37a68553`; bytes: 32339; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L470: `             and report['provider_version'] == '0.90.0'`
### `scripts/native_performance_batch_replay.py`
- SHA-256: `ce918b1aada5aa22038878f298763aea8802224dc6a100864b8a2d6d89493bfd`; bytes: 26650; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L218: `             and physical['provider_version'] == '=0.90.0', 'encoded fixture was not inspected and read back')`
### `scripts/test_ci_provider_tests.py`
- SHA-256: `7d758f3be72874e7b48b30942b14a44ca1f0a3f7169d15e18dbaeec80e4b75aa`; bytes: 15182; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=5
- L16: `FROZEN_CRATES = ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-layout",`
- L33: `    "vortex-runend": [`
- L34: `        'cargo test --manifest-path vendor/vortex-runend/Cargo.toml --config patch.crates-io.vortex-array.path="vendor/vortex-array" --features vortex-array/table-display --lib -- --test-threads=2',`
- L35: `        'cargo clippy --manifest-path vendor/vortex-runend/Cargo.toml --config patch.crates-io.vortex-array.path="vendor/vortex-array" --features vortex-array/table-display --lib -- -D warnings',`
- L118: `        for crate in ("vortex-array", "vortex-fsst", "vortex-runend", "vortex-zstd"):`
### `shardloom-vortex/src/ingest_arrow_ownership.rs`
- SHA-256: `62e02d5531bb822ec2e7047cc3646bbae3cb54d909fc6890c2615de628314c1d`; bytes: 37582; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L337: `                // Arrow 59.3.1 succeeds only for Arc-unique Standard(Layout)`
### `shardloom-vortex/src/local_primitive_native_sink_tests.rs`
- SHA-256: `91f66ba3d5cb5758eaff16699476f08080a57d7d38954e03d36a69971f21c5a4`; bytes: 38871; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L801: `    // The 0.90 pruning expression proves the constant-false predicate before`
### `shardloom-vortex/src/local_primitive_native_writer.rs`
- SHA-256: `8bb1668952f7c98595179603d022e194e6786c4a94da7e996985b9d0de49bc24`; bytes: 7688; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Vortex 0.90's blocking push writer queues one array and spawns a layout task.`
### `shardloom-vortex/src/local_primitive_query_run_store.rs`
- SHA-256: `1768902d7d325f0f09822b14fb535c53fc90a06995dcfa26d47f50570b86b594`; bytes: 45183; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Pinned Vortex 0.90 supplies the file writer, native arrays/Flat layout and`
### `shardloom-vortex/src/local_primitives.rs`
- SHA-256: `0f9cc3e660753049a7426cb99d3835c5438c95aab0dc3e7c71619bc45db228a1`; bytes: 2909403; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L16324: `    // Vortex 0.90 normalizes every small positive step to i64, including`
### `shardloom-vortex/src/native_provider_decoder_scratch.rs`
- SHA-256: `af8e74f0960c734b8de9fe9b0f9722bc1bb629cc7c9e32170875a8d10c724ec0`; bytes: 14194; counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L1: `//! Finite byte-buffer bounds for the pinned 0.90 physical decoder paths.`
- L75: `    // Blocked widths/references have different scratch trees in 0.90 and are`
- L147: `        // 0.90 may expose canonical validity without closing the nullable`
### `shardloom-vortex/src/native_spill_session.rs`
- SHA-256: `316f92c1c7104bc7b49100f9e772c96cc8d07c0d9d59aba95187a949b6ffdec9`; bytes: 13524; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `//! Vortex 0.90 session clones share a mutable configuration cell. Changing an`
### `shardloom-vortex/src/owned_buffers.rs`
- SHA-256: `ccb5da920305fd137b04c92e04827372f172ec874806aeaaba25298d7ec9171d`; bytes: 13736; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L30: `        // Pinned Vortex 0.90 DefaultHostAllocator requests len + preferred`
### `shardloom-vortex/src/resident_memory_encoded_transfer.rs`
- SHA-256: `e8f2f7934ed8c32cb95acbfbcb3c7d837d86c96236ba50cce2aa29fe4014d3a6`; bytes: 26199; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L619: `            // A wire serializer may replace or reorder physical parts in 0.90.`
### `shardloom-vortex/src/resident_memory_ipc.rs`
- SHA-256: `8df0185e6696cdd56dc7e51caf75f01673a882e92606a14243c19e71fdfb95b8`; bytes: 20473; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L45: `    /// Copy one Vortex 0.90 native IPC record into the receiving resource owner.`
### `shardloom-vortex/src/resident_source_reuse_bench.rs`
- SHA-256: `187cd94715bb22ca0bc35c2468b8f6e3a7c008cd526cde51a450443d2982ecf7`; bytes: 27867; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L689: `            "writer": "Vortex 0.90.0 default strategy",`
- L695: `            "release_build": !cfg!(debug_assertions), "vortex_version": "0.90.0",`
### `shardloom-vortex/src/vortex_ingest_nested.rs`
- SHA-256: `91f61924d47cf73e6acb46c26af88dad67295824ac11fd5500823df18e769681`; bytes: 16736; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L32: `/// their child field is nonnullable. Vortex 0.90 imports each child independently.`
### `shardloom-vortex/src/vortex_ingest_nested_layout.rs`
- SHA-256: `e3e45e6391f4bc70aae8f296930e237c7cf5d73616c5199f9891d35569b43925`; bytes: 4927; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L39: `    // Vortex 0.90 validates every serialized ID against the file writer's`
- L127: `        layout.push_str(";timestamp_layout=chunked_flat_native_compressed;file_min_max=provider_exact_when_present;file_other_pruning_stats=retained;timestamp_provider=vortex_array_0.90.0_full_domain_microsecond_patch");`
### `shardloom-vortex/src/vortex_ingest_source_fsst_bench.rs`
- SHA-256: `6f45461ca27b41f9bfeba007e670945a95a714e13eea8a9360d6eb87a3a49a88`; bytes: 10716; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L153: `        "provider":"Vortex 0.90.0 native FSST compression, Flat persistence, explicit LikeKernel and native scan",`
### `shardloom-vortex/src/vortex_ingest_text_io_tests.rs`
- SHA-256: `2c8b5dbb09e19201eb79d918f9bdc6b58f2bec44c7cfd3ff53b3d586ae4af248`; bytes: 35711; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L875: `            "native_version": "0.90.0", "intended_validation_feature": "release-user-surfaces",`
### `shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs`
- SHA-256: `d3f4580378a3fe7dc3cd8c5b59e6eb921123984d4d0d73b58624cad99b83d2ff`; bytes: 16366; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L222: `        "source":source,"provider":"Vortex 0.90.0 native Zstd and native file writer/scan",`
### `shardloom-vortex/tests/fixtures/independent-vortex-0.85/provenance.json`
- SHA-256: `44d62b3ddc150e01deca63a2ea790bfe357ba443c786c5236f803b1a69bf64ff`; bytes: 60157; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L1743: `      "name": "vortex-runend",`
### `shardloom-vortex/tests/fixtures/native-exchange/freeze.py`
- SHA-256: `12443ddd91291a0a8e9e18849f40c5c4ba1524a237fa5adaaa642f83a8083353`; bytes: 15020; counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L223: `                  "target_geometric_mean_workflow_ratio_max_each_arrow": 0.90,`
- L226: `                  "winning_target_workflow_ratio_max_each_arrow": 0.90,`
- L227: `                  "winning_target_wire_or_combined_peer_cpu_ratio_max_each_arrow": 0.90,`
### `vendor/arrow-array/README.shardloom.md`
- SHA-256: `79907e0379165a6fe2416630a7b44bc2fb257c3307aef907bad8ef3336585754`; bytes: 1241; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L3: `This is the 'arrow-array' 59.3.1 registry source, licensed Apache-2.0 AND MIT.`
### `vendor/arrow-array/upstream-provenance.json`
- SHA-256: `4ad70e1516a3d69912ee031c888f3111fa4c78e51ba38943cae649cf5b386ca3`; bytes: 8799; counts: vortex_0_90=0, arrow_parquet_59_3_1=5, vortex_runend=0
- L11: `      "url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE-MIT"`
- L16: `  "license_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#LICENSE.txt",`
- L28: `  "notice_url": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate#NOTICE.txt",`
- L107: `  "source_of_truth": "https://static.crates.io/crates/arrow-array/arrow-array-59.3.1.crate",`
- L108: `  "version": "59.3.1"`
### `vendor/arrow-avro/README.shardloom.md`
- SHA-256: `117cf65757bb2b2853bc0f9ac1e9b348a2ed48e5fa7f5c4419321a9d5652b1c7`; bytes: 6013; counts: vortex_0_90=0, arrow_parquet_59_3_1=2, vortex_runend=0
- L3: `This is the Apache-2.0 'arrow-avro' 59.3.1 registry source from the SHA-256`
- L74: `in 'upstream-provenance.json'. Arrow release 59.3.1 resolves to`
### `vendor/arrow-avro/upstream-provenance.json`
- SHA-256: `64669bacd0614fec10fd6e2ee77aa761ccccf1fa2a83c55f8f24d6f04b23dbae`; bytes: 40688; counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L65: `  "license_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#LICENSE.txt",`
- L81: `  "notice_url": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate#NOTICE.txt",`
- L124: `  "source_of_truth": "https://static.crates.io/crates/arrow-avro/arrow-avro-59.3.1.crate",`
- L563: `  "version": "59.3.1"`
### `vendor/arrow-ipc/README.shardloom.md`
- SHA-256: `cd7da09763e592d149335cf19614659c88e80a11db41ec4673ea7a9e1d1f3784`; bytes: 4370; counts: vortex_0_90=0, arrow_parquet_59_3_1=2, vortex_runend=0
- L3: `This is the Apache-2.0 'arrow-ipc' 59.3.1 registry provider with local decoder`
- L58: `'.github/provider-locks/arrow-ipc.lock' fixes standalone tests at Arrow 59.3.1.`
### `vendor/arrow-ipc/upstream-provenance.json`
- SHA-256: `a4e560dbb5e7952cf00990edf46bce137d8c8eae96adbd352a4633328c0f1e5c`; bytes: 5428; counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L22: `  "license_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#LICENSE.txt",`
- L34: `  "notice_url": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate#NOTICE.txt",`
- L69: `  "source_of_truth": "https://static.crates.io/crates/arrow-ipc/arrow-ipc-59.3.1.crate",`
- L71: `  "version": "59.3.1"`
### `vendor/orc-rust/src/encoding/integer/rle_v2/mod.rs`
- SHA-256: `1f378ade23cbfd75865c692fa14ff60e50bed2ec7e040de38f47768b55319825`; bytes: 34506; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L488: `    let zigzagged_90_percentile_bit_width = calculate_percentile_bits(&zigzag_literals, 0.90);`
### `vendor/parquet/README.shardloom.md`
- SHA-256: `78ba2a2086ed6da20ea6476f0b55dd2409040336df451466c77905461dccfcfd`; bytes: 3094; counts: vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- L3: `This is the 'parquet' 59.3.1 registry source with the following local corrections. Normal and`
### `vendor/parquet/upstream-provenance.json`
- SHA-256: `d92d6c5a9369863375efe0ecd4a8cbb700fa547dbab46c348ff7af8a7eb90b25`; bytes: 28108; counts: vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
- L10: `  "license_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#LICENSE.txt",`
- L40: `  "notice_url": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate#NOTICE.txt",`
- L280: `  "source_of_truth": "https://static.crates.io/crates/parquet/parquet-59.3.1.crate",`
- L282: `  "version": "59.3.1"`
### `vendor/vortex-array/README.shardloom.md`
- SHA-256: `36de77212e662e0c6d70f6acd4c05b0b1f26d24aec1b4318df35116113e68450`; bytes: 9893; counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L6: `0.90.0 provider. Its upstream 'BufferAllocator' hooks do not provide the`
- L23: `0.90 port must pass new validation; that earlier measurement is not a performance`
- L35: `This is the Apache-2.0 'vortex-array' 0.90.0 published source with a focused`
- L120: `In 0.90, conversion from nullable contiguous text validates only observable`
### `vendor/vortex-array/src/array/owner_tests.rs`
- SHA-256: `3d05af8ec24e82d605cf78209f65e96827710b31fdbef51fca7cec9f67f23ee3`; bytes: 8021; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `// ShardLoom regression tests, updated for Vortex 0.90 on 2026-10-24.`
### `vendor/vortex-array/src/arrays/filter/execute/buffer.rs`
- SHA-256: `9740599d802296e1ab5b3b743a137eaa8a14128c38ec6c93dd7c33224066f673`; bytes: 9725; counts: vortex_0_90=4, arrow_parquet_59_3_1=0, vortex_runend=0
- L123: `    // | aarch64 |   0.90 |    0.90 |    0.90 |    0.75 |  0.90 |`
### `vendor/vortex-array/src/host_memory.rs`
- SHA-256: `a392fdf6ee2a85202a97727832a49c7f060ce2add3894446e6d4b75a026aef2c`; bytes: 16872; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L4: `// allocation and foreign-owner contract beside the 0.90 buffer allocator.`
- L8: `//! The 0.90 'BufferAllocator' API remains separate: allocation denial there aborts.`
### `vendor/vortex-array/upstream-provenance.json`
- SHA-256: `9897a8eb770c062aef125df6593ae59b57bd47b6d6813ca108e9334294cbadbb`; bytes: 95033; counts: vortex_0_90=3, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L823: `  "source_of_truth": "https://static.crates.io/crates/vortex-array/vortex-array-0.90.0.crate",`
- L906: `      "modification": "The local 0.85 pinned clippy.toml was modified to remove the obsolete legacy_session prohibited method; it is supplemental local lint configuration, not an unchanged Vortex 0.90 archive member.",`
### `vendor/vortex-buffer/README.shardloom.md`
- SHA-256: `a8509adf59f7880f6da39d8fcbde88d4a978db0597b5581265fe466edfb3e880`; bytes: 1685; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the Apache-2.0 'vortex-buffer' 0.90.0 published source,`
### `vendor/vortex-buffer/upstream-provenance.json`
- SHA-256: `231802611d3b99c9712f99c595f933e47b571d376b3746c940fc3dfaa7a12855`; bytes: 4502; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L50: `  "source_of_truth": "https://static.crates.io/crates/vortex-buffer/vortex-buffer-0.90.0.crate",`
### `vendor/vortex-datetime-parts/README.shardloom.md`
- SHA-256: `b5bbb2542ff6c4ae1889f248df60b4754628ca74c8e436e915da896701dad045`; bytes: 2347; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the Apache-2.0 'vortex-datetime-parts' 0.90.0 published`
- L27: `0.90.0 archive already contains those fixes. This is an independent storage`
### `vendor/vortex-datetime-parts/upstream-provenance.json`
- SHA-256: `45b0ac813c3f185908c76bf8d38789438cf0b16d32b4b221b81dec1a15f918b3`; bytes: 5300; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L38: `  "source_of_truth": "https://static.crates.io/crates/vortex-datetime-parts/vortex-datetime-parts-0.90.0.crate",`
### `vendor/vortex-file/Cargo.toml.orig`
- SHA-256: `ba3fd2b3662d0f39135c7509fc2734b8cf91773a03cf7ba2013be686d709146d`; bytes: 2923; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L49: `vortex-runend = { workspace = true }`
### `vendor/vortex-file/README.shardloom.md`
- SHA-256: `dc1b11d11a37d223f415fd5acc70cc5e78347a590bc5adeb8f5ba81f9a072f06`; bytes: 7512; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the reviewed Apache-2.0 'vortex-file' 0.90.0 registry`
### `vendor/vortex-file/src/lib.rs`
- SHA-256: `67af2e3a160a5cd25bff07266c8fa25016e59b87f026af05355c154ddc66382e`; bytes: 13184; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L191: `    vortex_runend::initialize(session);`
### `vendor/vortex-file/upstream-provenance.json`
- SHA-256: `cbe29981309a5e9cab8473a00d61dfe00d64132b50bbee0c5f67c1ae7d3390ad`; bytes: 6355; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L53: `  "source_of_truth": "https://static.crates.io/crates/vortex-file/vortex-file-0.90.0.crate",`
### `vendor/vortex-fsst/README.shardloom.md`
- SHA-256: `dbb169f4e5aeee7f018f425af80e21a1a310b19f7d9cf77b57ef1af764795650`; bytes: 1414; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the Apache-2.0 'vortex-fsst' 0.90.0 published source. Its canonical`
### `vendor/vortex-fsst/upstream-provenance.json`
- SHA-256: `1b6a1fbf6e2cde5f45632428f6d6fdf6c1ea501cf8dbba0ec3468fdc68f6ef06`; bytes: 5274; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L42: `  "source_of_truth": "https://static.crates.io/crates/vortex-fsst/vortex-fsst-0.90.0.crate",`
### `vendor/vortex-io/README.shardloom.md`
- SHA-256: `4b50f4b713d4958dc7239a1a9c3f6ac91d392fe8a6eb6391c437f8b96b03f679`; bytes: 2260; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the reviewed Apache-2.0 'vortex-io' 0.90.0 published source. The`
- L11: `Vortex 0.90 separates its buffer allocator from the older fallible host`
### `vendor/vortex-io/upstream-provenance.json`
- SHA-256: `ce8c58fc2941f4977540dfb3759dc8eaafeabbedd0e8712d9decfea7841ee92f`; bytes: 6709; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L67: `  "source_of_truth": "https://static.crates.io/crates/vortex-io/vortex-io-0.90.0.crate",`
### `vendor/vortex-layout/Cargo.toml.orig`
- SHA-256: `676e8e53b24dae2f7c616defe5801c8e6997ad5f2cf68295fe6be797368122de`; bytes: 3591; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L53: `vortex-runend = { workspace = true }`
### `vendor/vortex-layout/README.shardloom.md`
- SHA-256: `5cd7fbb4dda8b3d6608e61fcd657fdd9a5c7d787c0a4899f3e3115e07a2372fa`; bytes: 5846; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This directory contains the reviewed Apache-2.0 'vortex-layout' 0.90.0 registry`
- L24: `The October 24 refresh ports those corrections to the 0.90 layout/context APIs.`
### `vendor/vortex-layout/src/layouts/zoned/zone_map.rs`
- SHA-256: `e24517c1d564a4bb368f963a08e55e4aa38859091ea5af53e0d1ce8ded64eb07`; bytes: 40431; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L47: `use vortex_runend::RunEnd;`
### `vendor/vortex-layout/upstream-provenance.json`
- SHA-256: `bcde8f289431e87606f7c286b6a46f9c9bd93275bed2abad2eb507b42820df14`; bytes: 21271; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `  "version": "0.90.0",`
- L168: `  "source_of_truth": "https://static.crates.io/crates/vortex-layout/vortex-layout-0.90.0.crate",`
### `vendor/vortex-runend/Cargo.toml.orig`
- SHA-256: `ef123315691c5b6c42d4dd079213c5104c7e9fc269de705bad09d2cd40021a2f`; bytes: 1472; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=1
- L2: `name = "vortex-runend"`
### `vendor/vortex-runend/README.shardloom.md`
- SHA-256: `1ebe9ee5e6fb1e02587d9bf6ce26b864b785c41971895206b0528e3a8333aab3`; bytes: 1369; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=1
- L3: `This is the Apache-2.0 'vortex-runend' 0.90.0 published source. String and binary`
### `vendor/vortex-runend/src/array.rs`
- SHA-256: `771149d1b2df930d8e793db5ec4a2499dafe86735c7583a667df2adb36fa4eb5`; bytes: 31500; counts: vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=2
- L427: `    /// # use vortex_runend::RunEnd;`
- L430: `    /// vortex_runend::initialize(&session);`
### `vendor/vortex-runend/upstream-provenance.json`
- SHA-256: `60813fd62e8ac202f9b2e5baf97bbf9648f8a9407c20de57784228d56750e669`; bytes: 5615; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=5
- L2: `  "provider": "vortex-runend",`
- L3: `  "version": "0.90.0",`
- L48: `  "source_of_truth": "https://static.crates.io/crates/vortex-runend/vortex-runend-0.90.0.crate",`
- L56: `    "provenance_path": "vendor/vortex-runend/upstream-provenance.json"`
- L73: `      "provider": "vortex-runend",`
### `vendor/vortex-zstd/README.shardloom.md`
- SHA-256: `b1795696cb5c21ae89f3c8f002a44cafca20dcd84d15125f79f52071bb915a51`; bytes: 3672; counts: vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
- L3: `This is the reviewed Apache-2.0 'vortex-zstd' 0.90.0 published source, with the`
### `vendor/vortex-zstd/upstream-provenance.json`
- SHA-256: `98b0d35343299e81984d3d69a6be76a48ba295ad334e18a33681987d355c9bd3`; bytes: 4497; counts: vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
- L62: `  "source_of_truth": "https://static.crates.io/crates/vortex-zstd/vortex-zstd-0.90.0.crate",`
- L71: `  "version": "0.90.0"`

## Cargo lock groups

### provider standalone locks
- `.github/provider-locks/arrow-array.lock` — SHA-256 `598b83c790c754cb5cdc0757268a158f29814595e47d941348dee17beaf93b3f`; vortex_0_90=0, arrow_parquet_59_3_1=1, vortex_runend=0
- `.github/provider-locks/arrow-avro.lock` — SHA-256 `0aae606673b85fa3d8f28f695d283bf85679cd418b12735df1e0ca93d4604336`; vortex_0_90=0, arrow_parquet_59_3_1=12, vortex_runend=0
- `.github/provider-locks/arrow-ipc.lock` — SHA-256 `e7b0ca692a198801e807e13cec53543f8452668accb4a8a7af4701c888a84a36`; vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
- `.github/provider-locks/orc-rust.lock` — SHA-256 `e2471aeb894fd4d56f3233d8fcb3283861b6f8f4d96cc074068cd67f1a77607d`; vortex_0_90=0, arrow_parquet_59_3_1=70, vortex_runend=0
- `.github/provider-locks/vortex-array.lock` — SHA-256 `ff95a628a094a9047c6f93cea4bbc7ef36b6b4aa7ad047db71fd15ff174b13bc`; vortex_0_90=8, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-buffer.lock` — SHA-256 `fb5f904f1871aa50136f7af2d0b604e4179a7a1fb9aa01b78e290e7514f0fd67`; vortex_0_90=2, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-datetime-parts.lock` — SHA-256 `189b24201e8aad1085b14e460a8542d0180ad28cc67d8865faee613fc663399b`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-file.lock` — SHA-256 `3d81a493a945ee62d4944d69b58c50a9ae3a682195f39ccbca3d09d9946e9076`; vortex_0_90=31, arrow_parquet_59_3_1=7, vortex_runend=5
- `.github/provider-locks/vortex-fsst.lock` — SHA-256 `cde54f0e06d84562b78da9dedd1e9c6d15eddf2c0bad3864a17654d59304238d`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-io.lock` — SHA-256 `0e9589fdb25f6bf2402e3c17cf67875e9368f05bf45f2471546f91a448277217`; vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
- `.github/provider-locks/vortex-layout.lock` — SHA-256 `4f0a7ca8f2abb6c302c44005b89bbe66e6cd1ceefb093eb6c30b50b27fc1bf52`; vortex_0_90=26, arrow_parquet_59_3_1=7, vortex_runend=4
- `.github/provider-locks/vortex-runend.lock` — SHA-256 `43e31416946dabd8a28e67d507b651e92650a9d3131948fd22feb0a4f155cdca`; vortex_0_90=9, arrow_parquet_59_3_1=2, vortex_runend=1
- `.github/provider-locks/vortex-zstd.lock` — SHA-256 `d4aa052230f037aede67cbc3bea86fa3f678c6d35d74a6777d08912b5d9df1ba`; vortex_0_90=10, arrow_parquet_59_3_1=2, vortex_runend=0
### root Cargo.lock
- `Cargo.lock` — SHA-256 `faf699a92d7f0ff7d6f1e58233f27b2cb045b62b5683d3b4933b7ad5266c5772`; vortex_0_90=33, arrow_parquet_59_3_1=15, vortex_runend=6
### fixture/provider locks
- `shardloom-vortex/tests/fixtures/independent-vortex-0.85/producer/Cargo.lock` — SHA-256 `587dd379ebb68158a156f29aba9d968f29371be8594f31c514ad85b046a6ee8b`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=6
- `shardloom-vortex/tests/fixtures/native-exchange/producer/Cargo.lock` — SHA-256 `4fd19ca8f7c4ac6e908f36be3eb72118103d14d6be90302737e19dcaf1d7d88a`; vortex_0_90=0, arrow_parquet_59_3_1=0, vortex_runend=5

## Cargo manifest groups

### workspace/provider Cargo.toml manifests
- `Cargo.toml` — SHA-256 `3772bd45fd74887643e0788b904be8abb704a0a75c1b7e53963ca1befe3ddf71`; vortex_0_90=2, arrow_parquet_59_3_1=6, vortex_runend=3
  - L11: `exclude = ["vendor/arrow-array", "vendor/arrow-avro", "vendor/arrow-data", "vendor/arrow-ipc", "vendor/orc-rust", "vendor/parquet", "vendor/vortex-array", "vendor/vortex-buffer", "vendor/vortex-datetime-parts", "vendor/vortex-file", "vendor/vortex-fsst", "vendor/vortex-io", "vendor/vortex-layout", "vendor/vortex-runend", "vendor/vortex-zstd"]`
  - L28: `vortex-runend = { path = "vendor/vortex-runend" }`
  - L47: `arrow-array = "=59.3.1"`
  - L50: `arrow-avro = { version = "=59.3.1", default-features = false, features = ["deflate", "snappy"] }`
  - L51: `arrow-flight = { version = "=59.3.1", default-features = false, features = ["flight-sql", "tls-ring"] }`
  - L52: `arrow-ipc = "=59.3.1"`
  - L53: `arrow-pyarrow = "=59.3.1"`
  - L61: `parquet = "=59.3.1"`
  - L80: `vortex = { version = "=0.90.0", default-features = false, features = ["files", "zstd"] }`
  - L81: `vortex-zstd = "=0.90.0"`
- `shardloom-vortex/Cargo.toml` — SHA-256 `9b79b2cd5f93f2892f3a17a864c1fa21a3f5a28555a5a1ae0a4f8e054b34de41`; vortex_0_90=1, arrow_parquet_59_3_1=0, vortex_runend=0
  - L104: `vortex-compressor = { version = "=0.90.0", optional = true }`
### vendor provider Cargo.toml manifests
- `vendor/arrow-array/Cargo.toml` — SHA-256 `45fa3fea7571173d891c16348662507848d428b84cd51bbd71d37d2b8eea158b`; vortex_0_90=0, arrow_parquet_59_3_1=4, vortex_runend=0
  - L16: `version = "59.3.1"`
  - L102: `version = "59.3.1"`
  - L105: `version = "59.3.1"`
  - L108: `version = "59.3.1"`
- `vendor/arrow-avro/Cargo.toml` — SHA-256 `b7817d3a0c02de4118e03ceff27a9a0d5579633da8013935d934551221c07fe7`; vortex_0_90=0, arrow_parquet_59_3_1=7, vortex_runend=0
  - L17: `version = "59.3.1"`
  - L100: `version = "59.3.1"`
  - L103: `version = "59.3.1"`
  - L106: `version = "59.3.1"`
  - L109: `version = "59.3.1"`
  - L206: `version = "59.3.1"`
  - L211: `version = "59.3.1"`
- `vendor/arrow-ipc/Cargo.toml` — SHA-256 `340b99f50362aea502f43071e562ab272a510370c40e3ce8495220265ba23d48`; vortex_0_90=0, arrow_parquet_59_3_1=6, vortex_runend=0
  - L16: `version = "59.3.1"`
  - L62: `version = "59.3.1"`
  - L65: `version = "59.3.1"`
  - L68: `version = "59.3.1"`
  - L71: `version = "59.3.1"`
  - L74: `version = "59.3.1"`
- `vendor/parquet/Cargo.toml` — SHA-256 `7aff4b45ac6a99f4688a1686016c51a509bac632fe43519199bcf57e80340e8d`; vortex_0_90=0, arrow_parquet_59_3_1=14, vortex_runend=0
  - L16: `version = "59.3.1"`
  - L355: `version = "59.3.1"`
  - L359: `version = "59.3.1"`
  - L363: `version = "59.3.1"`
  - L367: `version = "59.3.1"`
  - L371: `version = "59.3.1"`
  - L375: `version = "59.3.1"`
  - L379: `version = "59.3.1"`
  - L472: `version = "59.3.1"`
  - L476: `version = "59.3.1"`
  - L480: `version = "59.3.1"`
  - L484: `version = "59.3.1"`
  - L540: `version = "59.3.1"`
  - L550: `version = "59.3.1"`
- `vendor/vortex-array/Cargo.toml` — SHA-256 `fd87569efbab476134e1df92da1c8e6ecdb51f07c9efd20b0299fb68859aa256`; vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"`
  - L222: `version = "0.90.0"`
  - L225: `version = "0.90.0"`
  - L229: `version = "0.90.0"`
  - L233: `version = "0.90.0"`
  - L238: `version = "0.90.0"`
  - L242: `version = "0.90.0"`
  - L246: `version = "0.90.0"`
- `vendor/vortex-buffer/Cargo.toml` — SHA-256 `04771e2b07a2dd39e4ef01a4f8ffe79c772d5694678b5b961ff353ec58e1833e`; vortex_0_90=2, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"`
  - L101: `version = "0.90.0"`
- `vendor/vortex-datetime-parts/Cargo.toml` — SHA-256 `88fe98c5930b37c621611b0fd91aa934b8bdc9c177f9aa54b594ea129faf8693`; vortex_0_90=9, arrow_parquet_59_3_1=0, vortex_runend=0
  - L16: `version = "0.90.0"`
  - L55: `version = "0.90.0"`
  - L59: `version = "0.90.0"`
  - L63: `version = "0.90.0"`
  - L67: `version = "0.90.0"`
  - L71: `version = "0.90.0"`
  - L75: `version = "0.90.0"`
  - L92: `version = "0.90.0"`
  - L97: `version = "0.90.0"`
- `vendor/vortex-file/Cargo.toml` — SHA-256 `ee570c5aee3d89fc8398d143f4e94699b13057ece06f5ca0134150d1de073006`; vortex_0_90=31, arrow_parquet_59_3_1=0, vortex_runend=1
  - L17: `version = "0.90.0"`
  - L125: `version = "0.90.0"`
  - L129: `version = "0.90.0"`
  - L133: `version = "0.90.0"`
  - L137: `version = "0.90.0"`
  - L141: `version = "0.90.0"`
  - L145: `version = "0.90.0"`
  - L149: `version = "0.90.0"`
  - L153: `version = "0.90.0"`
  - L157: `version = "0.90.0"`
  - L161: `version = "0.90.0"`
  - L165: `version = "0.90.0"`
  - L169: `version = "0.90.0"`
  - L173: `version = "0.90.0"`
  - L177: `version = "0.90.0"`
  - L181: `version = "0.90.0"`
  - L185: `version = "0.90.0"`
  - L189: `version = "0.90.0"`
  - L192: `[dependencies.vortex-runend]`
  - L193: `version = "0.90.0"`
  - L197: `version = "0.90.0"`
  - L201: `version = "0.90.0"`
  - L205: `version = "0.90.0"`
  - L209: `version = "0.90.0"`
  - L213: `version = "0.90.0"`
  - L218: `version = "0.90.0"`
  - L223: `version = "0.90.0"`
  - L227: `version = "0.90.0"`
  - L255: `version = "0.90.0"`
  - L260: `version = "0.90.0"`
  - L265: `version = "0.90.0"`
  - L270: `version = "0.90.0"`
- `vendor/vortex-fsst/Cargo.toml` — SHA-256 `afcabb8a63f5bbbb7553a1cd716604034293a62b3d9bf376f9c7961b9d32e0c4`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"`
  - L71: `version = "0.90.0"`
  - L75: `version = "0.90.0"`
  - L79: `version = "0.90.0"`
  - L83: `version = "0.90.0"`
  - L87: `version = "0.90.0"`
  - L107: `version = "0.90.0"`
- `vendor/vortex-io/Cargo.toml` — SHA-256 `5aa7bae1dcfd7da9b181181c6030dc8bd4f799b88edf928af9a434d3c5a3b6e5`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"`
  - L120: `version = "0.90.0"`
  - L124: `version = "0.90.0"`
  - L128: `version = "0.90.0"`
  - L132: `version = "0.90.0"`
  - L136: `version = "0.90.0"`
  - L140: `version = "0.90.0"`
- `vendor/vortex-layout/Cargo.toml` — SHA-256 `b22910b7cce444ff31836f525cbe4cb62ae2f2a4cc710362d7e3135b70321b19`; vortex_0_90=16, arrow_parquet_59_3_1=0, vortex_runend=1
  - L17: `version = "0.90.0"`
  - L152: `version = "0.90.0"`
  - L156: `version = "0.90.0"`
  - L160: `version = "0.90.0"`
  - L164: `version = "0.90.0"`
  - L168: `version = "0.90.0"`
  - L172: `version = "0.90.0"`
  - L176: `version = "0.90.0"`
  - L180: `version = "0.90.0"`
  - L183: `[dependencies.vortex-runend]`
  - L184: `version = "0.90.0"`
  - L188: `version = "0.90.0"`
  - L192: `version = "0.90.0"`
  - L196: `version = "0.90.0"`
  - L200: `version = "0.90.0"`
  - L251: `version = "0.90.0"`
  - L255: `version = "0.90.0"`
- `vendor/vortex-runend/Cargo.toml` — SHA-256 `b409dd238dcbe22b4a17031c78aadf01feb6f9427202646fcfecf98a34b132dc`; vortex_0_90=7, arrow_parquet_59_3_1=0, vortex_runend=2
  - L16: `name = "vortex-runend"`
  - L17: `version = "0.90.0"`
  - L51: `name = "vortex_runend"`
  - L68: `version = "0.90.0"`
  - L72: `version = "0.90.0"`
  - L76: `version = "0.90.0"`
  - L80: `version = "0.90.0"`
  - L84: `version = "0.90.0"`
  - L107: `version = "0.90.0"`
- `vendor/vortex-zstd/Cargo.toml` — SHA-256 `b5cf9c5d1c4488cd69f4a07ec2caeab1641d6fe169f1150e552ccc15ebe55397`; vortex_0_90=8, arrow_parquet_59_3_1=0, vortex_runend=0
  - L17: `version = "0.90.0"`
  - L61: `version = "0.90.0"`
  - L65: `version = "0.90.0"`
  - L69: `version = "0.90.0"`
  - L73: `version = "0.90.0"`
  - L77: `version = "0.90.0"`
  - L81: `version = "0.90.0"`
  - L102: `version = "0.90.0"`

## Deterministic primary verification

From the repository root:

```sh
git rev-parse HEAD
git ls-files -z | xargs -0 rg -n '0\.90(\.0)?|59\.3\.1|vortex[-_]runend'
sha256sum <included-paths-from-JSON>
```

Apply listed exclusions to the raw search and group `Cargo.lock`, `.github/provider-locks/*.lock`, fixture Cargo locks, and Cargo manifests as in JSON. No build, network, or source edit was performed.
