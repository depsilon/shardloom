"""Replay archive, selected CodeQL and proposal evidence without network access."""
import argparse
import difflib
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

ORIGINAL = Path('/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07')


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def safe(path):
    p = PurePosixPath(path)
    assert path and not p.is_absolute() and '..' not in p.parts and str(p) == path
    return path


def patch_counts(patch):
    lines = patch.splitlines()
    totals = {'additions': 0, 'deletions': 0, 'hunks': 0}
    position = 0
    while position < len(lines):
        match = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[position])
        assert match, lines[position]
        old_expected, new_expected = int(match[2] or 1), int(match[4] or 1)
        old = new = 0
        totals['hunks'] += 1
        position += 1
        while position < len(lines) and not lines[position].startswith('@@ '):
            line = lines[position]
            assert line and line[0] in ' +-\\', line
            if line[0] in ' -':
                old += 1
            if line[0] in ' +':
                new += 1
            if line[0] == '+':
                totals['additions'] += 1
            if line[0] == '-':
                totals['deletions'] += 1
            if line[0] == '\\':
                assert line == '\\ No newline at end of file'
            position += 1
        assert (old, new) == (old_expected, new_expected)
    return totals


def verify(read):
    def data(relative):
        return read(safe(relative))

    def obj(relative):
        return json.loads(data(relative))

    comparison = obj('dependency-source-comparison-r1.json')
    verified_raw = data('dependency-source-preparation-r1/primary-verification-r1.json')
    verified = json.loads(verified_raw)
    assert verified['status'] == 'verified'
    assert identity(verified_raw) == comparison['primary_archive_verification']
    assert identity(data('dependency-source-preparation-r1/inventory.json')) == comparison['current_leaf_inventory']
    assert identity(data('tools/compare_dependency_sources.py')) == comparison['driver']
    assert len(comparison['archives']) == len(verified['archives']) == 8
    expected_records = {(r['name'], r['version']): r for r in comparison['archives']}
    archives = {}
    for source in verified['archives']:
        name, version = source['name'], source['version']
        raw = data(f'dependency-source-preparation-r1/{name}-{version}.crate')
        assert identity(raw) == {'bytes': source['archive_bytes'], 'sha256': source['archive_sha256']}
        expected = expected_records[(name, version)]
        assert identity(raw) == expected['archive']
        prefix = name + '-' + version + '/'
        members = {}
        with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
            for member in archive.getmembers():
                safe(member.name)
                assert member.isfile() and member.name.startswith(prefix)
                relative = member.name.removeprefix(prefix)
                assert relative not in members
                content = archive.extractfile(member).read()
                assert len(content) == member.size
                members[relative] = content
        assert len(members) == source['members']
        assert {p: identity(raw) for p, raw in members.items()} == expected['members']
        legal = {p: {'identity': identity(raw), 'text': raw.decode()} for p, raw in members.items()
                 if Path(p).name.upper().startswith(('LICENSE', 'LICENCE', 'UNLICENSE', 'COPYING', 'NOTICE'))}
        notices = {}
        for p, raw in members.items():
            if p.endswith('.rs') and raw.startswith(b'/*'):
                text = raw.decode()
                if 'Copyright 2025 gRPC authors.' in text.split('*/', 1)[0]:
                    notices[p] = text.split('*/', 1)[0] + '*/'
        assert legal == expected['legal_texts'] and notices == expected['source_notices']
        archives[(name, version)] = members
    assert len(comparison['comparisons']) == len(verified['pairs']) == 4
    assert {p['name'] for p in verified['pairs']} == {'jiff', 'jiff-core', 'jiff-static', 'tonic-prost'}
    for source, expected in zip(verified['pairs'], comparison['comparisons'], strict=True):
        name, old, new = source['name'], source['old'], source['new']
        before, after = archives[(name, old)], archives[(name, new)]
        assert before.keys() == after.keys()
        changed = sorted(p for p in before if before[p] != after[p])
        unchanged = sorted(p for p in before if before[p] == after[p])
        assert changed == source['changed'] and unchanged == source['unchanged']
        rebuilt = dict(name=name, old=old, new=new, added=[], deleted=[], unchanged=unchanged,
            changed={p: dict(before=identity(before[p]), after=identity(after[p]),
                unified_diff=''.join(difflib.unified_diff(before[p].decode().splitlines(keepends=True),
                    after[p].decode().splitlines(keepends=True), fromfile=f'{name}-{old}/{p}',
                    tofile=f'{name}-{new}/{p}'))) for p in changed})
        assert rebuilt == expected
    for side in ('old', 'new'):
        raw = data(f'tonic-prost-{side}-root-license-r1.json')
        response = json.loads(raw)
        source = response['structuredContent']
        text = source['content'].encode()
        assert response['isError'] is False
        assert hashlib.sha1(b'blob ' + str(len(text)).encode() + b'\0' + text).hexdigest() == source['sha']
        assert comparison['tonic_root_licenses'][side] == dict(receipt=identity(raw), identity=identity(text), source=source)
    assert comparison['tonic_root_licenses']['old']['identity'] == comparison['tonic_root_licenses']['new']['identity']

    inventory_raw = data('codeql-source-preparation-r1/source-inventory-r1.json')
    inventory = json.loads(inventory_raw)
    proof = obj('codeql-primary-verification-r1/report.json')
    assert proof['status'] == 'passed_source_identity_only'
    assert identity(inventory_raw) == proof['source_inventory']
    assert identity(data('tools/verify_codeql_collection.py')) == proof['driver']
    compare = obj('codeql-source-preparation-r1/compare-connector-response.json')['structuredContent']
    assert compare['repository_full_name'] == 'github/codeql-action'
    assert compare['base'] == '9b3254085494b55a0f7c4c2b3d2d52cc712ce370'
    assert compare['head'] == '33d7b85da1a04171e211befe2c739303b9a4c066'
    trees = {}
    for name, expected in proof['raw_requests'].items():
        assert expected['returncode'] == 0
        for suffix, key in [('.json', 'response'), ('.stderr', 'stderr')]:
            assert identity(data('codeql-primary-verification-r1/' + name + suffix)) == expected[key]
    for side in ('base', 'head'):
        commit = obj('codeql-primary-verification-r1/' + side + '-git-commit.json')
        tree = obj('codeql-primary-verification-r1/' + side + '-git-tree.json')
        assert commit['sha'] == compare[side] and tree['sha'] == commit['tree']['sha']
        assert tree['truncated'] is False
        trees[side] = {p['path']: p for p in tree['tree'] if p['type'] == 'blob'}
    changed = {p for p in trees['base'].keys() | trees['head'].keys()
               if trees['base'].get(p, {}).get('sha') != trees['head'].get(p, {}).get('sha')}
    assert changed == {p['filename'] for p in compare['files']} and len(changed) == 220
    skipped = {p['filename'] for p in inventory['selection']['skipped_paths']}
    assert len(skipped) == 61 and 'lib/entry-points.js' in skipped
    selected = {p['path'] for p in inventory['files']} - {'LICENSE'}
    assert selected == changed - skipped and len(selected) == 159
    assert len({(p['side'], p['path']) for p in inventory['files']}) == len(inventory['files']) == 320
    present = absent = total = 0
    for row in inventory['files']:
        side, path = row['side'], safe(row['path'])
        assert side in trees
        if row['status'] == 'retrieved':
            raw = data('codeql-source-preparation-r1/' + side + '/' + path)
            assert identity(raw) == {k: row[k] for k in ('bytes', 'sha256')}
            blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            assert blob == row['git_blob_sha'] == trees[side][path]['sha']
            assert len(raw) == trees[side][path]['size']
            present += 1
            total += len(raw)
        else:
            assert path not in trees[side]
            absent += 1
    assert (present, absent, total) == (304, 16, 3634572)
    for item in inventory['raw_connector_responses'].values():
        relative = str(Path(item['path']).relative_to(ORIGINAL))
        assert identity(data(relative)) == {k: item[k] for k in ('bytes', 'sha256')}
    assert data('codeql-source-preparation-r1/base/LICENSE') == data('codeql-source-preparation-r1/head/LICENSE')

    proposals = obj('dependency-proposal-primary-r1.json')
    assert proposals['status'] == 'literal_inventory_verified' and len(proposals['proposals']) == 5
    for expected in proposals['proposals']:
        raw = data(expected['raw']['path'])
        assert identity(raw) == {k: expected['raw'][k] for k in ('bytes', 'sha256')}
        original = json.loads(raw)
        assert original['metadata_response']['isError'] is False
        assert original['patch_response']['isError'] is False
        metadata = original['metadata_response']['structuredContent']
        patches = original['patch_response']['structuredContent']['patches']
        assert metadata['head_sha'] == expected['head'] and metadata['number'] == expected['number']
        assert metadata['changed_files'] == len(expected['files']) == len(patches)
        by_path = {p['filename']: p['patch'] for p in patches}
        assert set(by_path) == {p['path'] for p in expected['files']}
        totals = {'additions': 0, 'deletions': 0}
        for item in expected['files']:
            patch = by_path[item['path']]
            assert identity(patch.encode()) == {'bytes': item['patch_bytes'], 'sha256': item['patch_sha256']}
            counts = patch_counts(patch)
            assert counts == {k: item[k] for k in ('additions', 'deletions', 'hunks')}
            for k in totals:
                totals[k] += counts[k]
        assert all(totals[k] == metadata[k] == expected['metadata_' + k] for k in totals)
    return dict(status='passed', source_archives=len(archives), source_members=sum(len(p) for p in archives.values()),
        complete_source_comparisons=4, codeql_selected_files=present, codeql_absent_counterparts=absent,
        codeql_generated_paths_omitted=61, original_proposals=5,
        preparation_limitations_preserved=True, downloaded_code_executed=False, network_access_used=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('preparation', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    report = verify(lambda p: (args.preparation / p).read_bytes())
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
