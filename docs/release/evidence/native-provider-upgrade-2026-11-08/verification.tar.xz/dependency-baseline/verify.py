"""Replay saved dependency acceptance offline; no runtime tests are rerun."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import tomllib

REQUIRED = ['format', 'generated-docs', 'temporal-focused', 'default-clippy',
    'default-tests', 'native-clippy', 'native-tests', 'feature-matrix',
    'msrv-default', 'msrv-native', 'audit', 'release-build', 'freeze-runtime',
    'python-core', 'installed-wheel']
SOURCES = {'Cargo.toml', 'Cargo.lock', 'shardloom-vortex/Cargo.toml',
    'shardloom-core/src/temporal_timezone.rs', '.github/workflows/codeql-analysis.yml',
    '.github/workflows/scorecard.yml'}
VERSIONS = {'jiff': ('0.2.38', '0.2.39'), 'jiff-static': ('0.2.38', '0.2.39'),
    'jiff-core': ('0.1.0', '0.1.3'), 'tonic-prost': ('0.14.8', '0.14.9')}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def rust_counts(log):
    rows = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    return dict(zip(('passed', 'failed', 'ignored'),
        (sum(int(row[i]) for row in rows) for i in range(3)))) if rows else None


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, default=Path(__file__).resolve().parent)
parser.add_argument('--repo-root', type=Path)
args = parser.parse_args()
report = json.loads((args.packet / 'acceptance.json').read_bytes())
assert report['schema_version'] == 'shardloom.dependency_maintenance_acceptance.v1'
assert report['status'] == 'local_acceptance_passed' and report['archive'] == 'verification.tar.xz'
raw = (args.packet / report['archive']).read_bytes()
assert sha(raw) == report['archive_sha256']
expected = report['members']
assert len({p['path'] for p in expected}) == len(expected)
assert sum(p['bytes'] for p in expected) < 64 << 20
data = {}
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:xz') as archive:
    assert archive.getnames() == [p['path'] for p in expected]
    for row, member in zip(expected, archive.getmembers(), strict=True):
        path = PurePosixPath(row['path'])
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert str(path) == row['path'] and member.size == row['bytes']
        content = archive.extractfile(member).read()
        assert identity(content) == {k: row[k] for k in ('bytes', 'sha256')}
        data[row['path']] = content
assert Path(__file__).read_bytes() == data['current/tools/verify_dependency_packet.py']
source_verifier = args.packet / 'verify_sources.py'
assert source_verifier.read_bytes() == data['current/tools/verify_preparation.py']
spec = importlib.util.spec_from_file_location('dependency_source_replay', source_verifier)
source_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source_module)
preparation = source_module.verify(lambda p: data['current/preparation-r1/' + p])
assert preparation == report['preparation_replay']


def read(relative):
    return json.loads(data[relative])


selection_raw = data['current/preparation-selection-primary-r2.json']
selection = json.loads(selection_raw)
transfer = read('current/preparation-transfer-r1.json')
assert transfer['status'] == 'passed' and transfer['selection'] == identity(selection_raw)
assert transfer['transferred_files'] == selection['count'] == len(selection['files'])
assert transfer['transferred_bytes'] == selection['total_bytes'] == sum(p['bytes'] for p in selection['files'])
assert {p.removeprefix('current/preparation-r1/') for p in data if p.startswith('current/preparation-r1/')} == {
    p['path'] for p in selection['files']}
for item in selection['files']:
    assert identity(data['current/preparation-r1/' + item['path']]) == {k: item[k] for k in ('bytes', 'sha256')}
required = ['dependencies-' + name + '-r1' for name in REQUIRED]
assert [p['receipt'] for p in report['checks']] == [name + '.json' for name in required]
assert set(report['code_snapshot']) == SOURCES
graph = read('current/combined-graph-r1.json')
assert graph['status'] == 'passed' and graph['build_sources'] == report['code_snapshot']
assert graph['base'] == report['source_base'] and graph['proposal_heads'] == report['original_proposal_heads']
protocol = read('current/validation-protocol-r1.json')
assert protocol['prepared_only'] is False and protocol['build_sources'] == report['code_snapshot']
assert [p['name'] for p in protocol['stages']] == required
for path, expected_sha in protocol['requires'].items():
    assert sha(data['current/' + path]) == expected_sha
    assert read('current/' + path)['status'] == 'passed'
for check, stage in zip(report['checks'], protocol['stages'], strict=True):
    result = read('current/' + check['receipt'])
    assert result['status'] == 'passed' and result['returncode'] == 0
    assert result['process_group_drained'] and result['direct_child_reaped']
    assert result['command'] == check['command'] == stage['command']
    assert result['build_sources'] == report['code_snapshot']
    assert result['base'] == report['source_base'] and not result['query_workload']
    assert sha(data['current/source-blobs/' + result['driver_sha256']]) == result['driver_sha256']
    for item in result['tool_source_inventory'].values():
        assert identity(data['current/source-blobs/' + item['sha256']]) == item
    log = data['current/' + check['receipt'].removesuffix('.json') + '.log']
    assert sha(log) == result['log_sha256']
    assert rust_counts(log) == check['rust_tests']
    if check['rust_tests']:
        assert check['rust_tests']['failed'] == 0
for suffix in ('temporal-focused', 'native-tests'):
    log = data['current/dependencies-' + suffix + '-r1.log']
    for test in ('fixed_zone_clock_seconds_match_independent_civil_conversion',
                 'fixed_zone_fractional_and_calendar_boundaries_match_all_units'):
        assert ('test temporal::timezone::tests::' + test + ' ... ok').encode() in log
assert next(p for p in report['checks'] if p['receipt'] == 'dependencies-temporal-focused-r1.json')['rust_tests'] == {
    'passed': 4, 'failed': 0, 'ignored': 0}
sequence = read('current/dependency-validation-sequence-r1.json')
assert sequence['status'] == 'passed' and sequence['completed'] == required and sequence['active_stage'] is None
assert sequence['protocol_sha256'] == sha(data['current/validation-protocol-r1.json'])
sources = {}
for name, item in report['code_snapshot'].items():
    raw = data['current/source-blobs/' + item['sha256']]
    assert identity(raw) == item
    sources[name] = raw
    if args.repo_root:
        assert (args.repo_root / name).read_bytes() == raw

def package_map(raw):
    return {(p['name'], p['version'], p.get('source')): p for p in tomllib.loads(raw.decode())['package']}

before = package_map(data['baseline/Cargo.lock'])
after = package_map(sources['Cargo.lock'])
added, removed = after.keys() - before.keys(), before.keys() - after.keys()
assert {(k[0], k[1]) for k in added} == {(n, v[1]) for n, v in VERSIONS.items()}
assert {(k[0], k[1]) for k in removed} == {(n, v[0]) for n, v in VERSIONS.items()}
assert all(before[k] == after[k] for k in before.keys() & after.keys())
assert len(before.keys() & after.keys()) == graph['unchanged_package_objects']
assert [after[k] for k in sorted(added)] == graph['added_locked_packages']
assert [before[k] for k in sorted(removed)] == graph['removed_locked_packages']
for name, (old, new) in VERSIONS.items():
    a = next(p for k, p in before.items() if k[:2] == (name, old))
    b = next(p for k, p in after.items() if k[:2] == (name, new))
    excluded = {'version', 'checksum'} | ({'dependencies'} if name == 'jiff-core' else set())
    assert {k: v for k, v in a.items() if k not in excluded} == {k: v for k, v in b.items() if k not in excluded}
    if name == 'jiff-core':
        assert a['dependencies'] == ['defmt'] and b['dependencies'] == ['log']
assert sources['Cargo.toml'] == data['baseline/Cargo.toml'].replace(
    b'version = "=0.2.38"', b'version = "=0.2.39"').replace(b'tonic-prost = "=0.14.8"', b'tonic-prost = "=0.14.9"')
assert sources['shardloom-vortex/Cargo.toml'] == data['baseline/shardloom-vortex/Cargo.toml']
for path, count in [('.github/workflows/codeql-analysis.yml', 2), ('.github/workflows/scorecard.yml', 1)]:
    old = data['baseline/' + path]
    assert old.count(b'9b3254085494b55a0f7c4c2b3d2d52cc712ce370') == count
    assert sources[path] == old.replace(b'9b3254085494b55a0f7c4c2b3d2d52cc712ce370', b'33d7b85da1a04171e211befe2c739303b9a4c066')
path = 'shardloom-core/src/temporal_timezone.rs'
runtime = lambda raw: re.sub(r'//[^\n]*', '', raw.decode().split('#[cfg(test)]', 1)[0])
assert runtime(sources[path]) == runtime(data['baseline/' + path])
assert report['changed_runtime_body'] is False and report['changed_rust_tests'] is True

notices = read('reviewed-notices/manifest.json')
old_notices = read('baseline/python/THIRD_PARTY_LICENSES/manifest.json')
expected_notices = copy.deepcopy(old_notices)
operations = read('current/preparation-r1/notice-preparation-primary-r2.json')['component_record_operations']
for operation in operations:
    component = next(p for p in expected_notices['components'] if p['name'] == operation['name'])
    assert component['version'] == operation['old_version']
    assert component['crate_checksum_sha256'] == operation['old_archive_sha256']
    component['version'], component['crate_checksum_sha256'] = operation['new_version'], operation['new_archive_sha256']
    for item in operation.get('supplemental_notices', []):
        file = next(p for p in component['files'] if p['sha256'] == item['sha256'])
        assert file['upstream_url'] == item['old_upstream_url']
        file['upstream_url'] = item['new_upstream_url']
expected_notices['components'].sort(key=lambda p: (p['name'], p['version'], p['source']))
assert notices == expected_notices
locked = {k: p['checksum'] for k, p in after.items() if p.get('source', '').startswith('registry+')}
assert {(p['name'], p['version'], p['source']): p['crate_checksum_sha256'] for p in notices['components']} == locked
texts, records = set(), 0
for component in notices['components'] + notices['vendored_components']:
    assert component['license'] and component['files']
    for item in component['files']:
        raw = data['reviewed-notices/' + item['text']]
        assert identity(raw) == {k: item[k] for k in ('bytes', 'sha256')}
        assert item['text'] == 'texts/' + item['sha256'] + '.txt'
        assert item.get('crate_path') or item.get('upstream_url')
        texts.add(item['text'])
        records += 1
notice_summary = dict(status='passed', registry_packages=len(notices['components']),
    vendored_packages=len(notices['vendored_components']), license_file_records=records, unique_text_files=len(texts))
assert notice_summary == report['dependency_notices'] == read('current/notice-update-r1.json')['verification']
assert {p.removeprefix('reviewed-notices/') for p in data if p.startswith('reviewed-notices/texts/')} == texts

core = read('current/python-core-r1/core.json')
core_match = re.search(rb'Ran (\d+) tests? in [0-9.]+s', data['current/dependencies-python-core-r1.log'])
assert core_match and core['status'] == 'passed' and core['failure_count'] == core['error_count'] == 0
for name, value in [('status', 'passed'), ('discovered_test_cases', core['test_count']),
    ('reported_test_runs', int(core_match[1])), ('skip_records', core['skipped_count']), ('failures', 0), ('errors', 0)]:
    assert report['python_core'][name] == value
installed = read('current/installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == report['installed_package']
assert installed['integration']['status'] == 'passed' and installed['integration']['tests'] == 386
assert installed['integration']['failures'] == installed['integration']['errors'] == installed['integration']['skipped'] == 0
assert installed['integrity']['licenses'] == notice_summary
assert not installed['publication_attempted'] and not installed['performance_claim']
assert [p['name'] for p in installed['steps']] == ['build', 'create_environment',
    'install_optional_consumer', 'install', 'load', 'integration', 'uninstall', 'verify_uninstalled']
for step in installed['steps']:
    assert step['returncode'] == 0
    assert sha(data['current/installed-proof-r1/' + step['log']]) == step['log_sha256']
assert read('current/installed-proof-r1/integration.json') == installed['integration']
integration_log = data['current/installed-proof-r1/integration.log']
test_names = re.findall(rb'^(test_\S+ \([^\n]+\)) \.\.\. ok$', integration_log, re.MULTILINE)
assert len(test_names) == len(set(test_names)) == installed['integration']['tests']
assert re.search(rb'Ran 386 tests in [0-9.]+s\s+OK\s*$', integration_log)
assert any(b'test_temporal_calendar_workflows_match_all_five_surfaces ' in name for name in test_names)
assert installed['installed_load']['isolated_install'] is True
for key in ('cli_sha256', 'native_library_sha256'):
    assert installed['integrity'][key] == report[key]
assert installed['integrity']['wheel_sha256'] == report['installed_wheel_sha256']
runtime_identity = read('current/runtime-r1-identity.json')
assert runtime_identity['status'] == 'passed' and runtime_identity['build_receipt'] == 'dependencies-release-build-r1.json'
assert runtime_identity['build_receipt_sha256'] == sha(data['current/dependencies-release-build-r1.json'])
runtime_files = {Path(p['path']).name: p['sha256'] for p in runtime_identity['files']}
assert runtime_files == {'shardloom': report['cli_sha256'], 'lib_native.dylib': report['native_library_sha256']}
audit = read('current/dependency-audit-report-r1.json')
assert audit['release_gate'] and audit['fallback_dependency_absent']
for key in ('advisory_status', 'cargo_audit_status', 'cargo_deny_status', 'license_policy_status',
            'pip_audit_status'):
    assert audit[key] == 'passed'
for key in ('unknown_source_status', 'yanked_dependency_status'):
    assert audit[key] == 'covered_by_cargo_deny'
assert report['audit_report_sha256'] == sha(data['current/dependency-audit-report-r1.json'])
for failure in report['original_local_failures']:
    observed = read('current/' + failure['receipt'])
    assert observed['status'] == 'failed'
    assert observed.get('returncode') == failure['returncode']
    if 'log_sha256' in observed:
        assert sha(data['current/' + failure['receipt'].removesuffix('.json') + '.log']) == observed['log_sha256']
failed = set()
for path in data:
    if PurePosixPath(path).parent.as_posix() == 'current' and path.endswith('.json'):
        value = read(path)
        if isinstance(value, dict) and value.get('status') == 'failed':
            failed.add(path.removeprefix('current/'))
assert len(report['original_local_failures']) == len(failed)
assert {p['receipt'] for p in report['original_local_failures']} == failed
assert failed == {'preparation-selection-failure-r1.json', 'dependencies-preparation-selection-r2.json'}
assert not report['publication_attempted'] and not report['performance_claim']
print(json.dumps(dict(status='passed', archive_members=len(data), preparation=preparation,
    dependency_notices=notice_summary, installed_package=report['installed_package'],
    scope='Offline source, graph, notice and saved-check replay; no runtime tests or benchmarks rerun.')))
