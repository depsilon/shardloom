# Primary review of native output validation inventory

Reviewed against the active variable-tensor worktree on November 7. The Luna
inventory is source navigation, not acceptance evidence. Its universal-bypass
concern about `copy_rows::<false>` identity selection is rejected: the extension
branch runs tensor validation before the general selection code, and the latter
continues into struct/list visitation. It avoids a redundant take; it does not
return an unvalidated source to the caller.

The shared relational output chain is established in source:

- `local_primitive_prepared_relational.rs:1308` enters the source execution
  context, then `consume_in_context` at 1420 binds the root and enters
  `consume_bound_with_completion` at 1455.
- That function computes `nested` from each root field using
  `native_payload::is_nested`, which recognizes all registered payload storage
  extensions as well as structural fields (`native_payload.rs:107`).
- Its shared `emit` callback calls `detach_batch` before `consume` for every
  nested output (`local_primitive_prepared_relational.rs:1489`). `detach_batch`
  aliases `native_payload::detach`, which uses `ValidateValues`; the new tensor
  selection validator therefore applies before any downstream sink receives
  these arrays.
- `retain_complete_result` at 2237 collects through this same
  `for_each_batch_with_input` path. Its later owner constructors do not need to
  repeat the cross-field check. Streaming and writer entrypoints still need the
  planned executable public-path acceptance, rather than relying on this source
  argument alone.

`prepare_native_vortex_artifact_controlled` at `vortex_ingest.rs:3847` explicitly
admits an existing native artifact and either preserves its original path or
copies opaque bytes with footer/layout and generation checks. It neither executes
a query nor certifies per-row payload semantics. The variable-tensor contract
already separates native-file observation from typed/Arrow intake. Do not add
an eager full tensor scan to this native artifact preparation path.

Still required: execute new complete lifecycle tests and add an adversarial
native-file fixture created through the existing low-level writer. Observe both
valid-only selection success and malformed-visible-result failure through real
prepared collect/stream/write paths. Existing test writer examples are at
`local_primitive_completed_result_tests.rs:334` and
`local_primitive_native_results_tests.rs:80`; the malformed in-memory tensor
fixture is in `local_primitives/native_payload_tensor_tests.rs`.
