"""Verify exact original provider archives and seal only reviewed local changes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
OUT = Path(__file__).resolve().parents[1]
CHANGES = {
    'arrow-data': {'Cargo.toml', 'src/data.rs'},
    'arrow-array': {'Cargo.toml', 'src/builder/fixed_size_list_builder.rs'},
    'parquet': {'src/arrow/array_reader/fixed_size_list_array.rs'},
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

reports = []
for provider, newly_changed in CHANGES.items():
    directory = ROOT / 'vendor' / provider
    path = directory / 'upstream-provenance.json'
    record = json.loads(path.read_bytes())
    package = tomllib.loads((directory / 'Cargo.toml').read_text())['package']
    assert package['name'] == record['provider'] == provider
    assert package['version'] == record['version'] and package['publish'] is False
    archive = CACHE / f"{provider}-{package['version']}.crate"
    assert sha(archive.read_bytes()) == record['registry_archive_sha256']
    originals = {}
    original_bytes = 0
    with tarfile.open(archive, 'r:gz') as source:
        for member in source.getmembers():
            assert member.isfile()
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and '..' not in name.parts
            assert name.parts[0] == f"{provider}-{package['version']}"
            relative = str(PurePosixPath(*name.parts[1:]))
            assert relative not in originals
            data = source.extractfile(member).read()
            originals[relative] = sha(data)
            original_bytes += len(data)
    assert originals == record['original_files_sha256']
    assert original_bytes == record['registry_archive_uncompressed_bytes']
    assert len(originals) == record['registry_archive_file_count']
    allowed = set(record['modified_files_sha256']) | newly_changed
    modified = {}
    for name, identity in originals.items():
        current = directory / name
        if name in record['omitted_files']:
            assert record['omitted_files'][name]['original_sha256'] == identity
            assert not current.exists(), name
            continue
        assert current.is_file() and not current.is_symlink(), name
        actual = sha(current.read_bytes())
        if actual != identity:
            assert name in allowed, (provider, name)
            modified[name] = actual
    for name in newly_changed:
        assert name in modified, (provider, name)
    extras = set(record.get('added_files_sha256', {})) | {'README.shardloom.md'}
    for item in directory.rglob('*'):
        if item.is_file():
            relative = item.relative_to(directory).as_posix()
            assert relative in originals or relative in extras or relative == 'upstream-provenance.json', relative
    record['license'] = package['license']
    assert record['license'] in {'Apache-2.0', 'Apache-2.0 AND MIT'}
    record['modified_files_sha256'] = dict(sorted(modified.items()))
    record['added_files_sha256'] = {name: sha((directory / name).read_bytes()) for name in sorted(extras)}
    record['local_changes_documentation'] = {
        'path': 'README.shardloom.md', 'sha256': sha((directory / 'README.shardloom.md').read_bytes())}
    if provider == 'arrow-array':
        record['additional_license_files'] = [{
            'path': 'LICENSE-MIT', 'sha256': originals['LICENSE-MIT'],
            'url': record['source_of_truth'] + '#LICENSE-MIT'}]
        assert sha((directory / 'LICENSE-MIT').read_bytes()) == originals['LICENSE-MIT']
    record['migration_status'] = 'variable_tensor_boundary_corrections; lifecycle_and_provider_acceptance_required'
    path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    reports.append({'provider': provider, 'status': 'passed', 'archive_sha256': sha(archive.read_bytes()),
                    'original_files': len(originals), 'modified_files': sorted(modified),
                    'provenance_sha256': sha(path.read_bytes())})
receipt = OUT / 'provider-source-review-r1.json'
assert not receipt.exists()
receipt.write_text(json.dumps({'status': 'passed', 'providers': reports}, indent=2) + '\n')
print(json.dumps(reports))
