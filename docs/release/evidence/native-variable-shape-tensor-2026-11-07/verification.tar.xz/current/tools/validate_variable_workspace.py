"""Run fixed validation configurations sequentially with storage/process guards."""
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
GUARD = OUT / 'tools/guard_variable_tensor.py'
ENV = ['env', 'CARGO_PROFILE_DEV_DEBUG=0', 'CARGO_PROFILE_TEST_DEBUG=0', 'PYO3_PYTHON=' + PYTHON]
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
stages = [
    ('variable-format-r1', 120, ['cargo', 'fmt', '--all', '--', '--check']),
    ('variable-static-controls-r2', 300, [PYTHON, '-B', '-m', 'unittest', '-v', 'test_ci_provider_tests', 'test_python_license_bundle']),
    ('variable-python-schema-r2', 300, [PYTHON, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_variable_tensor_schema.py', '-v']),
    ('variable-provider-formats-r1', 2400, ENV + [PYTHON, '-B', 'scripts/ci_provider_tests.py', '--group', 'formats', '--output', str(OUT / 'provider-formats-r1')]),
    ('variable-default-clippy-r1', 2400, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings']),
    ('variable-default-tests-r1', 3600, ENV + ['cargo', 'test', '--workspace', '--all-targets', '--locked', '--offline']),
    ('variable-native-clippy-r3', 3600, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--features', FEATURES, '--locked', '--offline', '--', '-D', 'warnings']),
    ('variable-native-tests-r1', 5400, ENV + ['cargo', 'test', '--workspace', '--all-targets', '--features', FEATURES, '--locked', '--offline']),
    ('variable-feature-matrix-r1', 3600, ENV + [PYTHON, '-B', str(OUT / 'tools/check_variable_features.py')]),
]
receipt = OUT / 'workspace-sequence-r1.json'
assert not receipt.exists()
state = dict(status='running', completed=[], active_stage=None)

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for name, timeout, command in stages:
        state['active_stage'] = name
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_bytes())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
