"""Seal complete variable-tensor proof and preceding exact-main integration."""
import ast
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

from verify_variable_packet import REQUIRED, FORMAT_PROVIDERS, code_path, identity, rust_counts, verify

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'tensor-lifecycle-2026-11-07'
CACHE = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
DEST = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'


def read(path):
    return json.loads(path.read_bytes())


assert not DEST.exists()
checks = []
for name in REQUIRED:
    result = read(OUT / (name + '.json'))
    assert result['status'] == 'passed' and result['returncode'] == 0 and result['process_group_drained']
    raw = (OUT / (name + '.log')).read_bytes()
    assert identity(raw)['sha256'] == result['log_sha256']
    entry = dict(receipt=name + '.json', status='passed', command=result['command'])
    counts = rust_counts(raw)
    if counts:
        entry['rust_tests'] = counts
    checks.append(entry)
build = read(OUT / 'variable-native-build-r3.json')
build_source = {name: info for name, info in build['changed_source_inventory'].items() if code_path(name)}
final = read(OUT / 'variable-installed-wheel-r1.json')
source = {name: info for name, info in final['changed_source_inventory'].items() if code_path(name)}
correction = read(OUT / 'example-correction-r1.json')
example = 'python/examples/variable_shape_tensor.py'
assert correction['path'] == example and correction['before'] == build_source[example]
assert correction['after'] == source[example]
assert source == {**build_source, example: correction['after']}
old, new = [value.encode() for value in correction['replacement']]
before = (OUT / 'source-blobs' / correction['before']['sha256']).read_bytes()
after = (OUT / 'source-blobs' / correction['after']['sha256']).read_bytes()
assert before.count(old) == 1 and before.replace(old, new) == after
for name, info in source.items():
    assert identity((ROOT / name).read_bytes()) == info, name
installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert identity((OUT / 'runtime-r3' / name).read_bytes())['sha256'] == installed['integrity'][key]
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert identity(wheel.read_bytes())['sha256'] == installed['integrity']['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for name, info in source.items():
        if name.startswith('python/src/shardloom/'):
            assert identity(archive.read(name.removeprefix('python/src/'))) == info

files = {}


def add(prefix, path, relative):
    assert path.is_file() and not path.is_symlink(), path
    name = prefix + '/' + relative
    raw = path.read_bytes()
    assert name not in files or files[name] == raw
    files[name] = raw


selected = [*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('source-blobs/*'), *OUT.glob('tools/*.py')]
selected += [p for p in OUT.glob('*.md') if p.name != 'continuation.md']
for directory in ('provider-formats-r1', 'provider-new-arrow-r2', 'debug-retirement-r1',
                  'parquet-schema-probe-r1', 'parquet-schema-probe-r2', 'python-core-r1'):
    selected += sorted((OUT / directory).glob('*'))
selected += [*OUT.glob('installed-proof-r1/*.json'), *OUT.glob('installed-proof-r1/*.log')]
for path in sorted(set(selected)):
    if path.name.startswith('variable-package-'):
        continue
    add('current', path, path.relative_to(OUT).as_posix())
files['contracts/base-Cargo.lock'] = subprocess.check_output(['git', 'show', build['head'] + ':Cargo.lock'], cwd=ROOT)
for relative in ['python/tests/test_public_context.py', 'scripts/prove_native_python_wheel.py',
                 *['.github/provider-locks/' + name + '.lock' for name in FORMAT_PROVIDERS]]:
    add('contracts', ROOT / relative, relative)
for name in ('arrow-data', 'arrow-array', 'parquet'):
    provenance = read(ROOT / 'vendor' / name / 'upstream-provenance.json')
    prefix = 'providers/' + name
    add(prefix, CACHE / (name + '-' + provenance['version'] + '.crate'), 'original.crate')
    add(prefix, ROOT / 'vendor' / name / 'upstream-provenance.json', 'upstream-provenance.json')
    for relative in set(provenance['modified_files_sha256']) | set(provenance['added_files_sha256']):
        add(prefix + '/current', ROOT / 'vendor' / name / relative, relative)
for name in ('receipt.json', 'registry.json', 'vortex-tensor-0.90.0.crate'):
    add('provider-decision', PRIOR / 'provider-review' / name, name)
closeout = read(PRIOR / 'tensor-closeout-r1.json')
assert closeout['status'] == 'complete'
add('fixed', PRIOR / 'tensor-closeout-r1.json', 'tensor-closeout-r1.json')
for relative, info in closeout['receipts'].items():
    assert identity((PRIOR / relative).read_bytes()) == info
    add('fixed', PRIOR / relative, relative)

dispositions = {
    'variable-example-r1.json': 'The published example used a lower-level colon-delimited predicate where LazyFrame.filter accepts SQL or a typed predicate. Changed only that example expression to id >= 2; corrected example reopens both complete rows. Runtime source and the already-passed core suite remain unchanged.',
    'static-controls-r1.json': 'A mocked command-count assertion retained six commands after the formats group grew to ten. Corrected assertion passes all 21 controls. This compact tool observation has no saved raw log; none is invented.',
    'variable-native-clippy-r1.json': 'Simplified one Boolean test and moved three helper definitions before statements. Strict native Clippy passes on the final source.',
    'variable-native-clippy-r3.json': 'Replaced a truncating usize cast in the new output test with checked u64 conversion. Strict native Clippy and complete final suites pass.',
    'variable-default-tests-r1.json': 'The existing license contract allowed only an Apache-only string. Added a provider-specific check requiring the exact Apache-2.0 AND MIT declaration, provenance and both unchanged legal texts; complete final suites pass.',
    'variable-provider-formats-r1.json': 'The new arrow-data source failed strict Clippy on one upstream literal-only format. Replaced it with to_string and retained exact source provenance; final ten-command provider acceptance passes.',
    'variable-provider-new-arrow-r2.json': 'The new arrow-array source failed strict Clippy on unused map keys. Switched to values_mut with unchanged behavior and recorded provenance; final ten-command provider acceptance passes.',
    'variable-provider-array-tests-r3.json': 'Intentional include-ignored diagnostic fails the unchanged archive-disabled Map offset test: expected 1, implementation returns 0. Standard suite passes 768 tests with that pre-existing ignore. Variable tensor storage does not admit Map.',
    'variable-rust-focused-r1.json': 'Corrected missing trait/module imports and explicit OffsetBuffer construction in the initial implementation and fixtures; focused and complete final suites pass.',
    'variable-rust-focused-r3.json': 'Corrected usize/u64 expected row-count fixture mismatch; focused and complete final suites pass.',
    'variable-rust-focused-r4.json': 'The native-file fixture lacked the new dtype edition registration. Registered the current edition in the fixture; visible/hidden row controls and complete final suites pass.',
    'variable-native-tests-r1.json': 'The unchanged storage floor stopped compilation before native tests executed. Retired only reproducible debug compiler outputs with exact identities and closed handles, then completed a fresh guarded native suite. No credit is assigned to the stopped run.',
    'variable-binding-r1.json': 'Real provider failures exposed double Struct slice offsets, zero-width fixed-list row loss and inherited Parquet null masks. Same-version patches correct those paths; final installed lifecycle tests pass. Original output and diagnostics remain.',
    'variable-binding-backtrace-r1.json': 'Focused original nested-slice panic from the Struct offset defect; corrected provider path is covered by final installed nested-slice tests.',
    'variable-binding-r2.json': 'After provider corrections, assertions still compared raw fields with PyArrow-promoted extension schemas and a noncanonical list child name. Tests now compare independent IPC-interpreted schemas and the existing canonical item field, preserving complete value/nullability checks.',
    'variable-binding-r3.json': 'Remaining independent Parquet schema/read limitations were isolated rather than relabeled. Typed present-parent reads use the actual stored ARROW:schema; full native equality and default-reader present-parent values are both checked.',
    'variable-binding-reopen-diagnostic-r1.json': 'PyArrow 25.0.1 rejects fixed-size lists beneath null parents. The exact external-reader failure is retained; native complete Parquet reopening is independently checked.',
    'variable-binding-schema-diagnostic-r1.json': 'PyArrow default Parquet reads drop variable-tensor metadata. The successful typed independent read now uses the file footer schema, never the expected fixture schema; default complete present-parent values remain compared.',
}
for name in ('native-sequence-r1.json', 'workspace-followup-r1.json', 'workspace-followup-r2.json', 'workspace-sequence-r1.json', 'python-sequence-r1.json'):
    observation = read(OUT / name)
    dispositions[name] = 'Sequence stopped at ' + observation['active_stage'] + '; its completed stages and original failure remain preserved. Final native/Python protocols and provider acceptance complete the required work.'
failures = []
for name, raw in sorted(files.items()):
    if name.startswith('current/') and name.count('/') == 1 and name.endswith('.json'):
        result = json.loads(raw)
        assert result.get('status') != 'running', name
        if result.get('status') == 'failed':
            stem = name.removeprefix('current/')
            assert stem in dispositions, stem
            failures.append(dict(receipt=name, disposition=dispositions[stem]))
core = read(OUT / 'python-core-r1/core.json')
match = re.search(rb'Ran (\d+) tests? in [0-9.]+s', files['current/variable-python-core-r1.log'])
assert match
installed_tests = {}
for label, modules in [('variable_tensor', ['test_native_tensor_variable_binding', 'test_native_tensor_variable_controls_binding']), ('context', ['test_public_context'])]:
    installed_tests[label + '_installed_tests'] = sorted(module + '.' + node.name + '.' + method.name
        for module in modules for node in ast.parse((ROOT / 'python/tests' / (module + '.py')).read_bytes()).body
        if isinstance(node, ast.ClassDef) for method in node.body
        if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'))
members = [dict(path=name, **identity(raw)) for name, raw in sorted(files.items())]
assert sum(row['bytes'] for row in members) < 64 << 20
DEST.mkdir()
archive_path = DEST / 'verification.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for row in members:
        info = tarfile.TarInfo(row['path'])
        info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
        archive.addfile(info, io.BytesIO(files[row['path']]))
report = dict(schema_version='shardloom.variable_shape_tensor_acceptance.v1', status='local_acceptance_passed',
    source_base=build['head'], code_snapshot=source, checks=checks,
    example_correction=dict(receipt='example-correction-r1.json', failed='variable-example-r1.json',
        passed='variable-example-r2.json', runtime_implementation_changed=False),
    dependency_change='same_version_arrow_data_and_arrow_array_path_patches',
    provider_tests=dict(passed=1606, failed=0, ignored=1),
    python_core=dict(status=core['status'], discovered_test_cases=core['test_count'],
        reported_test_runs=int(match.group(1)), skip_records=core['skipped_count'], failures=core['failure_count'], errors=core['error_count']),
    installed_package=installed['integration'], **installed_tests,
    cli_sha256=installed['integrity']['cli_sha256'], native_library_sha256=installed['integrity']['native_library_sha256'],
    wheel_sha256=installed['integrity']['wheel_sha256'], original_failures=failures,
    preceding_integration=dict(pr=1661, merge_commit=closeout['merge_commit'], pr_checks_passed=58, main_checks_passed=55),
    hosted_integration='pending', publication_attempted=False, performance_claim=False, whole_item_19_complete=False,
    contract='Checked variable-shape tensor identity over native struct/list storage, visible-row shape validation, ordinary relational payload carriage, streaming/spill and all five native write interfaces.',
    reader_limitations=[
        'PyArrow 25.0.1 default Parquet schema drops the variable tensor extension; typed present-parent reads use the stored ARROW:schema.',
        'PyArrow 25.0.1 rejects fixed-size lists beneath null parents; complete native Parquet equality passes independently.'],
    limitations=['Boolean, signed/unsigned 8/16/32/64-bit integers, Float32 and Float64 components only.',
        'Tensor arithmetic and tensor key roles are explicitly unsupported.',
        'Text, Avro and ORC writers refuse tensor metadata loss.',
        'Sparse, quantized and lower-precision representations and exact vector expressions retain their queue positions.',
        'Existing opt-in Rust tests and the upstream Map provider test remain ignored; no benchmark or publication was run.'],
    archive=archive_path.name, archive_sha256=identity(archive_path.read_bytes())['sha256'], members=members)
(DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
(DEST / 'verify.py').write_bytes((OUT / 'tools/verify_variable_packet.py').read_bytes())
print(json.dumps(verify(DEST, ROOT)))
