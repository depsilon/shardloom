"""Verify relocation and finite corruption refusal for the saved tensor packet."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
DEST = OUT / 'packet-controls-r1'
assert not DEST.exists()
DEST.mkdir()


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save_report(directory, report):
    (directory / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')


def clone(name):
    directory = DEST / name
    directory.mkdir()
    for filename in ('acceptance.json', 'verification.tar.xz', 'verify.py'):
        shutil.copyfile(PACKET / filename, directory / filename)
    return directory, json.loads((directory / 'acceptance.json').read_bytes())


def rewrite(directory, report, change):
    with tarfile.open(directory / 'verification.tar.xz', 'r:xz') as archive:
        entries = {entry.name: archive.extractfile(entry).read() for entry in archive.getmembers()}
    change(entries, report)
    report['members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(entries.items())]
    with tarfile.open(directory / 'verification.tar.xz', 'w:xz', preset=1) as archive:
        for row in report['members']:
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
            archive.addfile(info, io.BytesIO(entries[row['path']]))
    report['archive_sha256'] = identity((directory / 'verification.tar.xz').read_bytes())['sha256']
    save_report(directory, report)


results = []


def run(name, directory, accepted, repo_root=None):
    command = [sys.executable, '-I', str(directory / 'verify.py'), '--packet', str(directory)]
    if repo_root:
        command += ['--repo-root', str(repo_root)]
    result = subprocess.run(command, capture_output=True, timeout=120)
    raw = result.stdout + result.stderr
    assert len(raw) < 1 << 20
    (DEST / (name + '.log')).write_bytes(raw)
    results.append(dict(name=name, returncode=result.returncode, expected='accept' if accepted else 'reject',
                        log_sha256=identity(raw)['sha256']))
    assert (result.returncode == 0) == accepted, name


def change_json(entries, name, change):
    value = json.loads(entries[name])
    change(value)
    entries[name] = json.dumps(value).encode()


def failed_check(entries, _):
    change_json(entries, 'current/variable-native-tests-r2.json',
                lambda value: value.update(status='failed', returncode=101))


def skipped_test(entries, report):
    change_json(entries, 'current/installed-proof-r1/report.json',
                lambda value: value['integration'].update(skipped=1))
    change_json(entries, 'current/installed-proof-r1/integration.json', lambda value: value.update(skipped=1))
    report['installed_package']['skipped'] = 1


def omit_failure(entries, report):
    name = 'current/variable-binding-r1.json'
    entries.pop(name)
    report['original_failures'] = [row for row in report['original_failures'] if row['receipt'] != name]


def wrong_provider_count(entries, report):
    change_json(entries, 'current/provider-acceptance-r1.json',
                lambda value: next(row for row in value['commands'] if 'tests' in row)['tests'].update(passed=99999))
    report['provider_tests']['passed'] = 99999


def broadened_example_correction(entries, report):
    key = 'current/example-correction-r1.json'
    correction = json.loads(entries[key])
    before = correction['after']
    raw = entries['current/source-blobs/' + before['sha256']] + b'\n'
    after = identity(raw)
    entries['current/source-blobs/' + after['sha256']] = raw
    correction['after'] = after
    entries[key] = json.dumps(correction).encode()
    report['code_snapshot'][correction['path']] = after
    for name in list(entries):
        if name.startswith('current/') and name.count('/') == 1 and name.endswith('.json'):
            value = json.loads(entries[name])
            inventory = value.get('changed_source_inventory', {})
            if inventory.get(correction['path']) == before:
                inventory[correction['path']] = after
                entries[name] = json.dumps(value).encode()


def failed_main_with_updated_links(entries, _):
    closeout = json.loads(entries['fixed/tensor-closeout-r1.json'])
    main_name = next(name for name in closeout['receipts'] if name.startswith('tensor-main1661-r')
                     and name.endswith('.json') and '-raw/' not in name)
    main = json.loads(entries['fixed/' + main_name])
    raw_name = main_name.removesuffix('.json') + '-raw/checks.json'
    checks = json.loads(entries['fixed/' + raw_name])
    required = set(main['required_hosted_check_names'])
    next(row for row in checks['check_runs'] if row['name'] in required)['conclusion'] = 'failure'
    entries['fixed/' + raw_name] = json.dumps(checks).encode()
    main['raw_sources'][raw_name] = identity(entries['fixed/' + raw_name])['sha256']
    entries['fixed/' + main_name] = json.dumps(main).encode()
    for name in (raw_name, main_name):
        closeout['receipts'][name] = identity(entries['fixed/' + name])
    entries['fixed/tensor-closeout-r1.json'] = json.dumps(closeout).encode()


try:
    run('original', PACKET, True, ROOT)
    relocated, _ = clone('relocated')
    run('relocated', relocated, True)
    directory, report = clone('archive-byte-corruption')
    raw = bytearray((directory / 'verification.tar.xz').read_bytes())
    raw[len(raw) // 2] ^= 1
    (directory / 'verification.tar.xz').write_bytes(raw)
    run('archive-byte-corruption', directory, False)
    directory, report = clone('summary-count-corruption')
    report['python_core']['reported_test_runs'] += 1
    save_report(directory, report)
    run('summary-count-corruption', directory, False)
    for name, change in [
        ('failed-native-check-resealed', failed_check),
        ('skipped-installed-test-resealed', skipped_test),
        ('omitted-original-failure-resealed', omit_failure),
        ('provider-test-count-resealed', wrong_provider_count),
        ('missing-provider-source-resealed', lambda entries, _: entries.pop('providers/arrow-data/original.crate')),
        ('failed-preceding-main-resealed', failed_main_with_updated_links),
        ('broadened-example-correction-resealed', broadened_example_correction),
    ]:
        directory, report = clone(name)
        rewrite(directory, report, change)
        run(name, directory, False)
    receipt = dict(status='passed', positive_controls=2, rejected_controls=9, results=results,
        original_packet_sha256=identity((PACKET / 'acceptance.json').read_bytes())['sha256'],
        original_archive_sha256=identity((PACKET / 'verification.tar.xz').read_bytes())['sha256'],
        verifier_sha256=identity((PACKET / 'verify.py').read_bytes())['sha256'],
        driver_sha256=identity(Path(__file__).read_bytes())['sha256'])
except BaseException as error:
    receipt = dict(status='failed', results=results, error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
