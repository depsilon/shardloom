"""Bind final provider results while preserving failed and disabled-test probes."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from ci_provider_tests import commands

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

entries = []
first = read(OUT / 'provider-formats-r1/report.json')
second = read(OUT / 'provider-new-arrow-r2/report.json')
for crate in ('orc-rust', 'arrow-avro', 'arrow-ipc', 'arrow-data', 'arrow-array'):
    for command in commands(crate):
        if crate == 'arrow-array':
            receipt = 'variable-provider-array-tests-r4' if command[1] == 'test' else 'variable-provider-array-r3'
            record = read(OUT / (receipt + '.json'))
            assert record['status'] == 'passed' and record['process_group_drained']
            index = record['command'].index('cargo')
            assert record['command'][index:] == command
            entry = dict(crate=crate, command=command, returncode=record['returncode'],
                         lock_sha256=sha(ROOT / '.github/provider-locks' / (crate + '.lock')),
                         log=receipt + '.log', log_sha256=record['log_sha256'])
        else:
            source = second if crate == 'arrow-data' else first
            directory = 'provider-new-arrow-r2' if crate == 'arrow-data' else 'provider-formats-r1'
            found = [x for x in source['commands'] if x['crate'] == crate and x['command'] == command]
            assert len(found) == 1
            entry = dict(found[0], log=directory + '/' + found[0]['log'])
        assert entry['returncode'] == 0
        assert entry['lock_sha256'] == sha(ROOT / '.github/provider-locks' / (crate + '.lock'))
        assert entry['log_sha256'] == sha(OUT / entry['log'])
        if command[1] == 'test':
            matches = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT / entry['log']).read_bytes())
            assert len(matches) == 1
            entry['tests'] = dict(zip(('passed', 'failed', 'ignored'), map(int, matches[0])))
            assert entry['tests']['failed'] == 0
        entries.append(entry)
assert len(entries) == 10
probe = read(OUT / 'variable-provider-array-tests-r3.json')
assert probe['status'] == 'failed' and probe['process_group_drained']
map_source = ROOT / 'vendor/arrow-array/src/array/map_array.rs'
provenance = read(ROOT / 'vendor/arrow-array/upstream-provenance.json')
assert sha(map_source) == provenance['original_files_sha256']['src/array/map_array.rs']
assert 'fn offset(&self) -> usize {\n        0\n    }' in map_source.read_text()
report = dict(status='passed', configurations='complete formats group; original failures preserved',
              commands=entries, source_review='provider-source-review-r3.json',
              disabled_test_probe=dict(receipt='variable-provider-array-tests-r3.json',
                  result='768 passed, one failed', changed_source=False,
                  reason='The archive-disabled map slice test expects Array::offset() == 1, while its unchanged implementation returns 0. It stays disabled upstream; native tensor storage does not admit Map.'),
              original_failures=['variable-provider-formats-r1.json', 'variable-provider-new-arrow-r2.json'])
with (OUT / 'provider-acceptance-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=report['status'], commands=len(entries),
    passed=sum(x.get('tests', {}).get('passed', 0) for x in entries),
    ignored=sum(x.get('tests', {}).get('ignored', 0) for x in entries))))
