"""Run the published example and compare every displayed value after reopen."""
import ast
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import runpy
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_binding import _load_native

_load_native()
captured = io.StringIO()
with redirect_stdout(captured):
    runpy.run_path(str(ROOT / 'python/examples/variable_shape_tensor.py'), run_name='__main__')
lines = captured.getvalue().splitlines()
assert lines[0] == 'tensor schema: variable_shape_tensor<float32,2>', lines
expected = [
    {'id': 2, 'state': 'active', 'measurement': None},
    {'id': 3, 'state': 'active', 'measurement': {'data': [7.0, None, 9.0], 'shape': [1, 3]}},
]
assert [ast.literal_eval(line) for line in lines[1:]] == expected, lines
print(captured.getvalue(), end='')
print(json.dumps({'status': 'passed', 'complete_reopened_rows': len(expected)}))
