"""Recheck the final provider sources, locks and unchanged legal texts."""
import hashlib
import json
import argparse
from pathlib import Path, PurePosixPath
import sys
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
CACHE = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
sys.path.insert(0, str(ROOT / 'scripts'))
import check_python_license_bundle as notices

def sha(data):
    return hashlib.sha256(data).hexdigest()

parser = argparse.ArgumentParser()
parser.add_argument('--name', default='provider-source-review-r2')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
receipt = OUT / (args.name + '.json')
assert not receipt.exists()
reports = []
root_packages = tomllib.loads((ROOT / 'Cargo.lock').read_text())['package']
known = {(p['name'], p['version'], p.get('source'), p.get('checksum')) for p in root_packages}
for old in ('arrow-ipc', 'arrow-avro'):
    known.update((p['name'], p['version'], p.get('source'), p.get('checksum'))
                 for p in tomllib.loads((ROOT / '.github/provider-locks' / (old + '.lock')).read_text())['package'])
for provider in ('arrow-data', 'arrow-array', 'parquet'):
    directory = ROOT / 'vendor' / provider
    record = json.loads((directory / 'upstream-provenance.json').read_bytes())
    archive = CACHE / f"{provider}-{record['version']}.crate"
    assert sha(archive.read_bytes()) == record['registry_archive_sha256']
    originals = {}
    with tarfile.open(archive, 'r:gz') as source:
        for member in source.getmembers():
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            assert name.parts[0] == f"{provider}-{record['version']}"
            relative = str(PurePosixPath(*name.parts[1:]))
            assert relative not in originals
            originals[relative] = sha(source.extractfile(member).read())
    assert originals == record['original_files_sha256']
    modified = {}
    for name, identity in originals.items():
        path = directory / name
        if name in record['omitted_files']:
            assert record['omitted_files'][name]['original_sha256'] == identity
            if path.exists():
                assert name == 'Cargo.lock' and provider in {'arrow-data', 'arrow-array'}
                frozen = ROOT / '.github/provider-locks' / (provider + '.lock')
                assert not path.is_symlink() and path.read_bytes() == frozen.read_bytes()
                packages = tomllib.loads(frozen.read_text())['package']
                for p in packages:
                    assert (p['name'], p['version'], p.get('source'), p.get('checksum')) in known
            continue
        assert path.is_file() and not path.is_symlink()
        value = sha(path.read_bytes())
        if value != identity:
            assert name in record['modified_files_sha256'] or (
                provider == 'arrow-array' and name == 'src/builder/union_builder.rs'), (provider, name)
            modified[name] = value
    assert set(record['modified_files_sha256']).issubset(modified)
    for item in directory.rglob('*'):
        if item.is_file():
            relative = item.relative_to(directory).as_posix()
            assert relative in originals or relative in record['added_files_sha256'] or relative == 'upstream-provenance.json', relative
    record['modified_files_sha256'] = dict(sorted(modified.items()))
    record['added_files_sha256'] = {name: sha((directory / name).read_bytes())
                                  for name in record['added_files_sha256']}
    record['local_changes_documentation']['sha256'] = sha((directory / 'README.shardloom.md').read_bytes())
    path = directory / 'upstream-provenance.json'
    path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    reports.append(dict(provider=provider, archive_sha256=sha(archive.read_bytes()),
                        modified_files=modified, provenance_sha256=sha(path.read_bytes())))

path = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
before = path.read_bytes()
manifest = json.loads(before)
current = notices.vendored_components(ROOT)
legal = lambda xs: {x['name']: (x['version'], x['license'], {f['sha256'] for f in x['files']}) for x in xs}
assert legal(current) == legal(manifest['vendored_components'])
manifest['vendored_components'] = current
path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
report = dict(status='passed', providers=reports, license_verification=notices.verify(ROOT),
              previous_manifest_sha256=sha(before), manifest_sha256=sha(path.read_bytes()),
              provider_locks_use_only_root_or_existing_provider_versions=True,
              legal_texts_unchanged=True)
receipt.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
