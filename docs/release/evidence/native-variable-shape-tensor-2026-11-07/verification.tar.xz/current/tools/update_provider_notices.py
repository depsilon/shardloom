"""Carry previously verified notices forward across two same-version path patches."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import check_python_license_bundle as notices

path = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
before = path.read_bytes()
manifest = json.loads(before)
expected = notices.locked_packages(ROOT)
removed = [item for item in manifest['components'] if notices.identity(item) not in expected]
assert {(item['name'], item['version']) for item in removed} == {
    ('arrow-array', '59.3.1'), ('arrow-data', '59.3.2')}
kept = [item for item in manifest['components'] if notices.identity(item) in expected]
assert len(kept) == len(expected) and {notices.identity(item) for item in kept} == set(expected)
for item in kept:
    assert item['crate_checksum_sha256'] == expected[notices.identity(item)]
vendored = notices.vendored_components(ROOT)
for original in removed:
    target = next(item for item in vendored if item['name'] == original['name'])
    assert target['version'] == original['version'] and target['license'] == original['license']
    assert target['provenance']['registry_archive_sha256'] == original['crate_checksum_sha256']
    assert {item['sha256'] for item in target['files']} == {item['sha256'] for item in original['files']}
manifest['components'], manifest['vendored_components'] = kept, vendored
path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
report = notices.verify(ROOT)
report.update(previous_manifest_sha256=hashlib.sha256(before).hexdigest(),
              manifest_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
              registry_to_same_version_path=[item['name'] for item in removed])
receipt = OUT / 'provider-notice-update-r1.json'
assert not receipt.exists()
receipt.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
