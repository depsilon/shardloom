"""Bind final source, portable proof and tested artifacts to a clean commit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
PRIOR = OUT.parent / 'tensor-lifecycle-2026-11-07/tensor-closeout-r1.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


assert not git('status', '--porcelain')
assert git('branch', '--show-current') == 'codex/native-variable-tensor-lifecycle'
head = git('rev-parse', 'HEAD')
report = read(PACKET / 'acceptance.json')
prior = read(PRIOR)
assert report['status'] == 'local_acceptance_passed' and prior['status'] == 'complete'
base = report['source_base']
assert base == prior['merge_commit'] and git('show', '-s', '--format=%P', head).split() == [base]
expected_files = set(report['code_snapshot']) | {
    'docs/architecture/native-variable-tensor-lifecycle-2026-11-07.md',
    'docs/architecture/native-fixed-tensor-lifecycle-2026-11-07.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/phased-execution-completed-ledger.md',
    'docs/architecture/native-rich-data-lifecycle-2026-10-24.md',
    'docs/architecture/local-development-storage.md',
    'docs/reference/rich-columns.md',
    'docs/reference/variable-shape-tensors.md',
    'docs/reference/shardloom-user-surface-index.json',
    'docs/reference/shardloom-user-surface-index.md',
    'python/README.md',
}
expected_files.update('docs/release/evidence/native-variable-shape-tensor-2026-11-07/' + name
    for name in ('acceptance.json', 'verification.tar.xz', 'verify.py', 'README.md', 'corruption-controls.json'))
assert set(git('diff', '--name-only', base, head).splitlines()) == expected_files
for name, expected in report['code_snapshot'].items():
    assert identity(ROOT / name) == expected
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-I',
    str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)
controls = read(PACKET / 'corruption-controls.json')
assert controls['status'] == 'passed' and controls['rejected_controls'] == 9
assert controls['exact_fixture_mutations_verified'] and controls['original_packet_unchanged']
for filename, key in [('acceptance.json', 'original_packet_sha256'),
                      ('verification.tar.xz', 'original_archive_sha256'), ('verify.py', 'verifier_sha256')]:
    assert controls['observation'][key] == identity(PACKET / filename)['sha256']
docs = read(OUT / 'variable-final-docs-r1.json')
assert docs['status'] == 'passed' and docs['process_group_drained'] and docs['head'] == base
assert set(docs['changed_source_inventory']) == expected_files
for name in expected_files:
    assert identity(ROOT / name) == docs['changed_source_inventory'][name], name
installed = read(OUT / 'installed-proof-r1/report.json')
for relative, key in [('runtime-r3/shardloom', 'cli_sha256'), ('runtime-r3/lib_native.dylib', 'native_library_sha256'),
        ('installed-proof-r1/dist/' + installed['integrity']['wheel'], 'wheel_sha256')]:
    assert identity(OUT / relative)['sha256'] == installed['integrity'][key] == report[key]
assert not git('diff', '--numstat', base, head, '--', '.github/workflows')
result = dict(status='passed', head=head, tree=git('rev-parse', head + '^{tree}'), base=base, base_branch='main',
    runtime_sources_match_build=True,
    runtime_source_proof='All changed runtime, provider and dependency sources match the final build and complete native/default checks; the installed wheel contains the same Python runtime source and frozen native artifacts. Only the example predicate changed after the build, with exact before/after source and failed/passed observations bound by portable verification.',
    ci_workflow_blob=git('rev-parse', head + ':.github/workflows/ci.yml'),
    acceptance=identity(PACKET / 'acceptance.json'), archive=identity(PACKET / 'verification.tar.xz'),
    verifier=identity(PACKET / 'verify.py'), installed_package=report['installed_package'],
    corruption_controls=identity(PACKET / 'corruption-controls.json'),
    final_documentation_checks=identity(OUT / 'variable-final-docs-r1.json'), changed_files=sorted(expected_files),
    prior_fixed_tensor_closeout=identity(PRIOR), publication_attempted=False, performance_claim=False)
with (OUT / 'delivery-acceptance-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'head', 'tree', 'installed_package')}))
