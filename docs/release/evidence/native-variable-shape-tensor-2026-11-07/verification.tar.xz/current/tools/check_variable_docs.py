"""Validate generated interfaces and current documentation contracts."""
import argparse
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tag', default='r1')
args = parser.parse_args()
assert args.tag.replace('-', '').isalnum()
checks = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', str(OUT / ('public-status-docs-' + args.tag + '.json'))],
    ['scripts/check_contribution_governance.py', '--output', str(OUT / ('contribution-governance-' + args.tag + '.json'))],
]
for command in checks:
    print('Checking ' + ' '.join(command), flush=True)
    subprocess.run([sys.executable, '-B', *command], check=True, timeout=120)
