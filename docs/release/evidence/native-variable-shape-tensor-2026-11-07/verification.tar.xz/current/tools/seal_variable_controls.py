"""Check exact control mutations and preserve their compact observations."""
import copy
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
CONTROL = OUT / 'packet-controls-r1'


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(path.read_bytes())


def contents(directory, report):
    raw = (directory / 'verification.tar.xz').read_bytes()
    assert identity(raw)['sha256'] == report['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in report['members']]
        result = {}
        for entry, row in zip(archive.getmembers(), report['members']):
            assert entry.isfile() and entry.size == row['bytes']
            data = archive.extractfile(entry).read()
            assert identity(data)['sha256'] == row['sha256']
            result[entry.name] = data
        return result


receipt = read(CONTROL / 'receipt.json')
assert receipt['status'] == 'passed' and receipt['positive_controls'] == 2 and receipt['rejected_controls'] == 9
original = read(PACKET / 'acceptance.json')
for filename, key in [('acceptance.json', 'original_packet_sha256'),
                      ('verification.tar.xz', 'original_archive_sha256'), ('verify.py', 'verifier_sha256')]:
    assert identity((PACKET / filename).read_bytes())['sha256'] == receipt[key]
driver = (OUT / 'tools/check_variable_packet_controls.py').read_bytes()
assert identity(driver)['sha256'] == receipt['driver_sha256']
data = contents(PACKET, original)
names = ['original', 'relocated', 'archive-byte-corruption', 'summary-count-corruption',
    'failed-native-check-resealed', 'skipped-installed-test-resealed', 'omitted-original-failure-resealed',
    'provider-test-count-resealed', 'missing-provider-source-resealed', 'failed-preceding-main-resealed',
    'broadened-example-correction-resealed']
assert [row['name'] for row in receipt['results']] == names
logs = {}
for index, row in enumerate(receipt['results']):
    raw = (CONTROL / (row['name'] + '.log')).read_bytes()
    assert identity(raw)['sha256'] == row['log_sha256']
    assert (row['returncode'] == 0) == (index < 2)
    assert row['expected'] == ('accept' if index < 2 else 'reject')
    if index >= 2:
        expected_error = b'KeyError' if row['name'] == 'missing-provider-source-resealed' else b'AssertionError'
        assert expected_error in raw
    logs[row['name']] = raw.decode()
    if row['name'] != 'original':
        assert (CONTROL / row['name'] / 'verify.py').read_bytes() == (PACKET / 'verify.py').read_bytes()
for name in ('acceptance.json', 'verification.tar.xz', 'verify.py'):
    assert (CONTROL / 'relocated' / name).read_bytes() == (PACKET / name).read_bytes()
directory = CONTROL / 'archive-byte-corruption'
assert read(directory / 'acceptance.json') == original
expected = bytearray((PACKET / 'verification.tar.xz').read_bytes())
expected[len(expected) // 2] ^= 1
assert (directory / 'verification.tar.xz').read_bytes() == expected
directory = CONTROL / 'summary-count-corruption'
expected = copy.deepcopy(original)
expected['python_core']['reported_test_runs'] += 1
assert read(directory / 'acceptance.json') == expected
assert (directory / 'verification.tar.xz').read_bytes() == (PACKET / 'verification.tar.xz').read_bytes()

for name in names[4:]:
    directory = CONTROL / name
    report = read(directory / 'acceptance.json')
    actual = contents(directory, report)
    expected_report = copy.deepcopy(original)
    expected_data = dict(data)
    if name == 'failed-native-check-resealed':
        key = 'current/variable-native-tests-r2.json'
        value = json.loads(expected_data[key])
        value['status'], value['returncode'] = 'failed', 101
        expected_data[key] = json.dumps(value).encode()
    elif name == 'skipped-installed-test-resealed':
        key = 'current/installed-proof-r1/report.json'
        value = json.loads(expected_data[key])
        value['integration']['skipped'] = 1
        expected_data[key] = json.dumps(value).encode()
        key = 'current/installed-proof-r1/integration.json'
        value = json.loads(expected_data[key])
        value['skipped'] = 1
        expected_data[key] = json.dumps(value).encode()
        expected_report['installed_package']['skipped'] = 1
    elif name == 'omitted-original-failure-resealed':
        key = 'current/variable-binding-r1.json'
        del expected_data[key]
        expected_report['original_failures'] = [row for row in expected_report['original_failures'] if row['receipt'] != key]
    elif name == 'provider-test-count-resealed':
        key = 'current/provider-acceptance-r1.json'
        value = json.loads(expected_data[key])
        next(row for row in value['commands'] if 'tests' in row)['tests']['passed'] = 99999
        expected_data[key] = json.dumps(value).encode()
        expected_report['provider_tests']['passed'] = 99999
    elif name == 'missing-provider-source-resealed':
        del expected_data['providers/arrow-data/original.crate']
    elif name == 'broadened-example-correction-resealed':
        key = 'current/example-correction-r1.json'
        correction = json.loads(expected_data[key])
        before = correction['after']
        raw = expected_data['current/source-blobs/' + before['sha256']] + b'\n'
        after = identity(raw)
        expected_data['current/source-blobs/' + after['sha256']] = raw
        correction['after'] = after
        expected_data[key] = json.dumps(correction).encode()
        expected_report['code_snapshot'][correction['path']] = after
        for key in list(expected_data):
            if key.startswith('current/') and key.count('/') == 1 and key.endswith('.json'):
                value = json.loads(expected_data[key])
                inventory = value.get('changed_source_inventory', {})
                if inventory.get(correction['path']) == before:
                    inventory[correction['path']] = after
                    expected_data[key] = json.dumps(value).encode()
    else:
        assert name == 'failed-preceding-main-resealed'
        closeout = json.loads(expected_data['fixed/tensor-closeout-r1.json'])
        main_name = next(key for key in closeout['receipts'] if re.fullmatch(r'tensor-main1661-r\d+\.json', key))
        main = json.loads(expected_data['fixed/' + main_name])
        raw_name = main_name.removesuffix('.json') + '-raw/checks.json'
        checks = json.loads(expected_data['fixed/' + raw_name])
        next(row for row in checks['check_runs'] if row['name'] in main['required_hosted_check_names'])['conclusion'] = 'failure'
        expected_data['fixed/' + raw_name] = json.dumps(checks).encode()
        main['raw_sources'][raw_name] = identity(expected_data['fixed/' + raw_name])['sha256']
        expected_data['fixed/' + main_name] = json.dumps(main).encode()
        for key in (raw_name, main_name):
            closeout['receipts'][key] = identity(expected_data['fixed/' + key])
        expected_data['fixed/tensor-closeout-r1.json'] = json.dumps(closeout).encode()
    assert actual == expected_data, name
    expected_report['members'] = report['members']
    expected_report['archive_sha256'] = report['archive_sha256']
    assert report == expected_report, name

result = dict(status='passed', positive_controls=2, rejected_controls=9,
    exact_fixture_mutations_verified=True, original_packet_unchanged=True,
    observation=receipt, logs=logs, driver_source=driver.decode(), driver_sha256=identity(driver)['sha256'],
    primary_verifier_source=Path(__file__).read_text(),
    scope='Saved evidence consistency only; no runtime tests, builds, benchmarks or installation rerun.')
with (PACKET / 'corruption-controls.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'positive_controls', 'rejected_controls', 'exact_fixture_mutations_verified')}))
