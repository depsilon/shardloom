"""Describe the accepted variable-tensor scope and exact saved verification."""
import json
from pathlib import Path

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
report = json.loads((PACKET / 'acceptance.json').read_bytes())
controls = json.loads((PACKET / 'corruption-controls.json').read_bytes())
assert report['status'] == 'local_acceptance_passed' and controls['status'] == 'passed'
assert controls['positive_controls'] == 2 and controls['rejected_controls'] == 9
assert controls['exact_fixture_mutations_verified'] and controls['original_packet_unchanged']
checks = {row['receipt']: row for row in report['checks']}
default = checks['variable-default-tests-r3.json']['rust_tests']
native = checks['variable-native-tests-r2.json']['rust_tests']
content = f'''<!-- SPDX-License-Identifier: Apache-2.0 -->

# Variable-shape tensor lifecycle acceptance

This immutable local acceptance records checked row-specific tensor shapes and
native lifecycle correctness at source base `{report['source_base']}`.
Hosted review and integration of this delivery are pending at this observation.
It does not complete item 19, change independent CG gates, claim a performance
gain or publish a package.

`acceptance.json` binds {len(report['code_snapshot'])} changed source files,
{len(report['checks'])} accepted check stages, the final CLI/library/wheel and
all {len(report['members'])} members of `verification.tar.xz`. Every final
runtime source matches the tested build. The archive includes source snapshots,
all {len(report['original_failures'])} original failed observations, their saved
logs or explicit missing-log statements, provider archives and provenance, and
the preceding fixed-tensor integration. PR #1661 passed all 58 checks; its exact
signed merge passed all 55 required main checks and completed safe retirement.

Default/native Rust suites pass {default['passed']:,}/{native['passed']:,} cases;
{native['ignored']} existing opt-in native tests remain ignored. All seven
feature configurations and strict lint checks pass. The five format providers
pass all ten test/lint commands and {report['provider_tests']['passed']:,} tests,
with one archive-disabled upstream Map test. Its deliberate failing diagnostic
is retained separately. The root dependency versions are unchanged; two existing
Arrow packages now use narrowly patched, provenance-checked local sources.

The public Python shard reports {report['python_core']['reported_test_runs']}
test runs and {report['python_core']['skip_records']} optional/environment skip
records, separately from {report['python_core']['discovered_test_cases']}
discovered cases. The clean installed package passes all
{report['installed_package']['tests']} tests without skips, including all 11 new
variable-tensor and 19 context tests, then uninstalls. The published example
runs through native persistence and checks both complete reopened rows.
Its original colon-delimited predicate was corrected to the SQL expression
`id >= 2`; the exact one-expression change and both outcomes are preserved.
The engine and Python runtime sources are unchanged by that example correction.

Native, IPC and Parquet lifecycle checks preserve supported component bits,
metadata, nullability, shape/data alignment and ownership through ordinary
relational payloads, bounded streams, native spill and all five write interfaces.
Controls cover malformed visible values, hidden/discarded children, cancellation,
source mutation, denied grants, failed publication and last-owner release.

PyArrow 25.0.1 has two explicit Parquet limitations: its default reader drops the
tensor extension, and it rejects fixed-size lists beneath null parents. Typed
independent present-parent reads use the actual file's `ARROW:schema`; the
default reader's complete present-parent values are also checked. Complete native
Parquet equality passes separately. The original reader failure is preserved.

From the repository root, replay with Python 3.11 or later:

```sh
python3 docs/release/evidence/native-variable-shape-tensor-2026-11-07/verify.py --repo-root .
```

Copy this directory elsewhere and run `python3 verify.py` for standalone replay.
Verification hashes and inspects saved evidence without builds, installation,
query reruns or network access. Original and relocated replay pass; nine
controlled corruptions are rejected. `corruption-controls.json` preserves exact
mutation checks, driver source, observations and logs.

See the [implementation contract](../../../architecture/native-variable-tensor-lifecycle-2026-11-07.md)
and [user guide](../../../reference/variable-shape-tensors.md) for the supported
types and boundaries. Tensor arithmetic and tensor key roles remain unsupported;
text, Avro and ORC outputs refuse metadata loss. Sparse, quantized and lower-
precision representations and exact vector expressions retain their queue order.
'''
with (PACKET / 'README.md').open('x') as stream:
    stream.write(content)
print('Wrote verified variable-tensor acceptance README.')
