"""Complete the two new standalone provider configurations after the first run."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from ci_provider_tests import CONFIGURATIONS, commands
from ci_build_artifact import sha

destination = OUT / 'provider-new-arrow-r2'
destination.mkdir()
report = dict(status='running', commands=[], original='provider-formats-r1/report.json')
try:
    for crate in ('arrow-data', 'arrow-array'):
        frozen = ROOT / '.github/provider-locks' / (crate + '.lock')
        lock = ROOT / 'vendor' / crate / 'Cargo.lock'
        assert not frozen.is_symlink() and not lock.is_symlink()
        shutil.copyfile(frozen, lock)
        env = dict(os.environ, CLIPPY_CONF_DIR=str(ROOT / CONFIGURATIONS[crate]['clippy_conf_dir']))
        for command in commands(crate):
            path = destination / (crate + '-' + command[1] + '.log')
            print('Running ' + ' '.join(command), flush=True)
            with path.open('xb') as stream:
                result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
            entry = dict(crate=crate, command=command, returncode=result.returncode,
                         lock_sha256=sha(frozen), log=path.name, log_sha256=sha(path))
            report['commands'].append(entry)
            assert result.returncode == 0 and sha(lock) == sha(frozen), entry
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    (destination / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
