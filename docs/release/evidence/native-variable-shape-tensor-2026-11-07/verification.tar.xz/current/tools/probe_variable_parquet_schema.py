import base64
import json
from pathlib import Path
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1] / 'parquet-schema-probe-r2'
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_tensor_variable_binding import _load_native, _fixture, _independent_schema_equal

_load_native()
import pyarrow as pa
import pyarrow.parquet as pq
import shardloom as sl

OUT.mkdir()
table = _fixture(6)
with sl.context(transport='native', memory_bytes=128 << 20, max_parallelism=1,
                float_policy='extended') as context:
    for name, value in [('full', table), ('present', table.filter(table.column('tensor').is_valid()))]:
        path = OUT / (name + '.parquet')
        context.from_arrow_table(value).write_parquet(path, check=True)
        footer = pq.read_metadata(path)
        embedded = pa.ipc.read_schema(pa.BufferReader(base64.b64decode(footer.metadata[b'ARROW:schema'])))
        native = context.read_parquet(path).collect(check=True).to_arrow()
        print(name, 'input', value.schema)
        print(name, 'embedded', embedded)
        print(name, 'native', native.schema)
        print(name, 'footer schema', footer.schema.to_arrow_schema())
        for enabled in [True, False]:
            try:
                output = pq.read_table(path, arrow_extensions_enabled=enabled)
                print(name, 'independent', enabled, output.schema)
                print(name, 'equal', enabled, _independent_schema_equal(output.schema, value.schema))
            except pa.ArrowInvalid as error:
                print(name, 'error', enabled, str(error))
        print(name, 'embedded equal', _independent_schema_equal(embedded, value.schema))
        try:
            explicit = pq.read_table(path, schema=embedded)
            print(name, 'explicit schema', explicit.schema)
            print(name, 'explicit schema equal', _independent_schema_equal(explicit.schema, value.schema))
        except Exception as error:
            print(name, 'explicit schema error', type(error).__name__, str(error))
