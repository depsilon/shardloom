# Primary variable-tensor review

The review comparator is an encoded-columnar maintainer inspecting correctness,
memory ownership and persistence boundaries. No external execution provider is
introduced. The Vortex-first decision and payload-only restrictions are recorded
in the implementation contract.

## Visibility and row alignment

The common relational emit path detaches nested payloads using `ValidateValues`
before collection, streaming or writers receive them. Extension validation runs
before structural copying, including identity selections. The new validator
applies arbitrary native take indices and ancestor masks before opening data and
shape coordinates. Native list coordinates check addition and bounds; shape
products validate every dimension and uniform constraint even after overflow or
a zero dimension. Rank zero requires exactly one component. The shape check does
not visit component values.

The prior output inventory's suggested identity-selection bypass was rejected
against that source path. Executed native-file regressions now prove valid-only
selection and hidden invalid rows succeed, and observed invalid rows fail before
collect/stream/Vortex/IPC/Parquet publication. The low-level artifact-copy API
continues to certify bytes/footer/generation, not unobserved row semantics.

Arrow validation receives the entire containing schema before provider mask
normalization. Containing struct/list/fixed-list nulls hide malformed tensor
children. Nonzero nested slices and all 32 structural nullability combinations
pass the Python intake/export tests. List child names follow the existing native
canonical `item` convention; the initial hidden-parent fixture accidentally
asserted preservation of a noncanonical list child name and was corrected without
changing the runtime or dropping metadata/nullability assertions.

## Metadata, values and ownership

The native extension retains canonical JSON and optional uniform dimensions in
the receiving allocator. A spill child session replaces the parent allocator's
dtype registration. Tests prove metadata denial, retained clones and last-owner
release. Python simple and explicit declarations use the existing depth/node
budget, while the result descriptors retain all storage nullability flags.

Complete native, IPC and Parquet values are checked including floating bit
patterns, nulls, non-self-inverse permutation, partial uniform dimensions,
duplicate join matches, spill, bounded stream, cancellation and source mutation.
The exact native runtime passes all 11 new Python lifecycle/control methods.
The native focused suite passes 17 tests, including the provider null-parent
regression moved into the engine's existing Parquet test boundary.

## Provider fixes and independent readers

Three same-version provider corrections were required by real failures:
`arrow-data` struct offsets are applied once, `arrow-array` zero-width list
builders retain explicit length, and Parquet required lists retain inherited
null masks. Narrow upstream lint corrections remove a literal-only format and
use values-only map iteration. Exact original archives, all original member
hashes and legal files were independently rechecked. New standalone locks retain
root versions; dev-only additions already exist in approved provider locks.
The MIT license accompanying arrow-array remains in the complete notice bundle.

PyArrow IPC promotes the extension metadata into a type; independent schema
comparisons apply the same IPC interpretation to both schemas. PyArrow's default
Parquet reader drops the variable-tensor annotation. Independent typed reopening
uses the actual file's `ARROW:schema` footer, not the expected fixture schema, and
checks full present-parent values. Default-reader values are also checked.
Its null-parent fixed-list read failure is preserved explicitly; native complete
Parquet reopening passes. Neither reader limitation is called full independent
Parquet support.

The imported arrow-array suite has one archive-disabled map test. An explicit
include-ignored diagnostic confirms its first failure is the unchanged stale
offset expectation (1 versus the implementation's 0). It remains an upstream
disabled test, and Map is not admitted variable-tensor storage. Standard provider
verification passes 1,606 tests with that one existing ignore and all ten strict
test/lint commands passing. Both original lint failures and the diagnostic
failure remain saved.

Broad workspace, feature, clean installed-package, example, portable evidence
and hosted acceptance remain required after this review. This note alone is not
an integration or performance claim.

## Final local acceptance follow-up

The complete default/native suites now pass 3,319/6,972 cases, with 37 existing
native opt-in ignores. All seven feature configurations pass. The public Python
shard reports 845 test runs, 1,210 discovered cases and 51 optional/environment
skip records; the clean installed wheel passes all 361 tests without skips,
including 11 variable-tensor and 19 context methods, and then uninstalls.

The first published-example run correctly rejected its colon-delimited predicate
at the SQL filter boundary. Only that expression changed to `id >= 2`; the
corrected example checks both complete persisted/reopened rows. All other 161
changed runtime/provider/dependency/test sources match the final build byte for
byte. Saved before/after blobs bind the exact expression correction; native or
Python runtime implementation did not change. The earlier successful core suite
remains evidence, and both original example/sequence failures remain visible.

Portable evidence and hosted acceptance still require their own completed
checks; no runtime, performance or publication claim is inferred from packaging.
