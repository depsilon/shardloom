"""Run final native gates sequentially, stopping on the first failed receipt."""
from pathlib import Path
import subprocess
import sys

guard = Path(__file__).with_name('guard_variant.py')
native = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
checks = [
    ('format-r2', 300, ['cargo', 'fmt', '--all', '--', '--check']),
    ('native-clippy-r4', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace',
                             '--all-targets', '--features', native, '--', '-D', 'warnings']),
    ('native-tests-r5', 3600, ['cargo', 'test', '--offline', '--locked', '--workspace',
                            '--all-targets', '--features', native]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, str(guard), '--name', name, '--timeout', str(timeout),
                    '--', *command], check=True)
