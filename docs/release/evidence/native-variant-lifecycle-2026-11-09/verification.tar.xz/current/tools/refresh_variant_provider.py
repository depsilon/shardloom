"""Refresh only the reviewed Arrow provider changes; retain every prior receipt."""
import argparse
import hashlib
import json
from pathlib import Path

root = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
out = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
name = parser.parse_args().name
assert name.replace('-', '').isalnum()
report_path = out / (name + '.json')
assert not report_path.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
provider = root / 'vendor/vortex-arrow'
path = provider / 'upstream-provenance.json'
before = path.read_bytes()
provenance = json.loads(before)
selected = {'README.shardloom.md', 'src/session.rs', 'src/variant_chunks.rs'}
expected = dict(provenance['original_files_sha256'])
for omitted in provenance.get('omitted_files', {}):
    expected.pop(omitted, None)
expected.update(provenance['modified_files_sha256'])
expected.update(provenance['added_files_sha256'])
for relative, digest in expected.items():
    if relative not in selected:
        assert sha((provider / relative).read_bytes()) == digest, relative
for relative in sorted(selected):
    group = 'modified_files_sha256' if relative in provenance['original_files_sha256'] else 'added_files_sha256'
    provenance[group][relative] = sha((provider / relative).read_bytes())
provenance['local_changes_documentation']['sha256'] = sha((provider / 'README.shardloom.md').read_bytes())
manifest_path = root / 'python/THIRD_PARTY_LICENSES/manifest.json'
manifest_before = manifest_path.read_bytes()
manifest = json.loads(manifest_before)
components = [row for row in manifest['vendored_components'] if row['path'] == 'vendor/vortex-arrow']
assert len(components) == 1 and components[0]['provenance'] == json.loads(before)
components[0]['provenance'] = provenance
assert path.read_bytes() == before and manifest_path.read_bytes() == manifest_before
path.write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + '\n')
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
record = {'status': 'passed', 'provider_before': sha(before), 'provider_after': sha(path.read_bytes()),
          'manifest_before': sha(manifest_before), 'manifest_after': sha(manifest_path.read_bytes()),
          'selected_files': {relative: sha((provider / relative).read_bytes()) for relative in sorted(selected)}}
report_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
