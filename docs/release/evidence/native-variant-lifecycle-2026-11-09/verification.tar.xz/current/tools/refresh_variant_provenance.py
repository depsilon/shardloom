"""Record reviewed provider edits and exact new dependency legal evidence."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tomllib

root = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
out = Path(__file__).resolve().parents[1]
registry = Path('/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')
cache = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
report_path = out / 'provenance-refresh-r1.json'
assert not report_path.exists()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

provider = root / 'vendor/vortex-arrow'
provenance_path = provider / 'upstream-provenance.json'
provenance_before = provenance_path.read_bytes()
provenance = json.loads(provenance_before)
selected = {'README.shardloom.md', 'src/session.rs', 'src/variant_chunks.rs'}
expected = dict(provenance['original_files_sha256'])
for name in provenance.get('omitted_files', {}):
    expected.pop(name, None)
expected.update(provenance['modified_files_sha256'])
expected.update(provenance['added_files_sha256'])
for name, identity in expected.items():
    if name not in selected:
        assert sha((provider / name).read_bytes()) == identity, name
for name in sorted(selected):
    group = 'modified_files_sha256' if name in provenance['original_files_sha256'] else 'added_files_sha256'
    provenance[group][name] = sha((provider / name).read_bytes())
for group in ('modified_files_sha256', 'added_files_sha256'):
    provenance[group] = dict(sorted(provenance[group].items()))
provenance['local_changes_documentation']['sha256'] = sha((provider / 'README.shardloom.md').read_bytes())

bundle = root / 'python/THIRD_PARTY_LICENSES'
manifest_path = bundle / 'manifest.json'
manifest_before = manifest_path.read_bytes()
manifest = json.loads(manifest_before)
identity = lambda value: (value['name'], value['version'], value['source'])
before = {identity(value): value for value in manifest['components']}
locked = {identity(value): value for value in tomllib.loads((root / 'Cargo.lock').read_text())['package']
          if value.get('source', '').startswith('registry+')}
new_names = {'chrono', 'parquet-variant', 'parquet-variant-compute', 'parquet-variant-json',
             'vortex-json', 'vortex-parquet-variant'}
assert {key[0] for key in set(locked) - set(before)} == new_names
assert [(key[0], key[1]) for key in set(before) - set(locked)] == [('chrono', '0.4.44')]
parquet = json.loads((root / 'vendor/parquet/upstream-provenance.json').read_bytes())
vortex = json.loads((root / 'vendor/vortex-array/upstream-provenance.json').read_bytes())
report = {'status': 'passed', 'scope': 'reviewed optional Variant providers; no runtime query-engine integration',
          'manifest_before': sha(manifest_before), 'provider_before': sha(provenance_before), 'new_packages': []}

# The missing notices in the published Variant subcrates come from the same
# reviewed Arrow/Parquet workspace release. Read the actual archive members,
# not merely another component's declared license string.
parquet_archive = out / 'parquet-59.3.2.crate'
assert sha(parquet_archive.read_bytes()) == parquet['registry_archive_sha256']
with tarfile.open(fileobj=io.BytesIO(parquet_archive.read_bytes())) as archive:
    for name in ('LICENSE.txt', 'NOTICE.txt'):
        actual = archive.extractfile('parquet-59.3.2/' + name).read()
        field = 'license_sha256' if name.startswith('LICENSE') else 'notice_sha256'
        assert sha(actual) == parquet[field]

for key in sorted(set(locked) - set(before)):
    package = locked[key]
    source = registry / (package['name'] + '-' + package['version'])
    archive_path = cache / (source.name + '.crate')
    archive_bytes = archive_path.read_bytes()
    assert sha(archive_bytes) == package['checksum']
    declaration = tomllib.loads((source / 'Cargo.toml').read_text())['package']
    assert declaration['license'] in ('Apache-2.0', 'MIT OR Apache-2.0')
    files = []
    if package['name'] == 'chrono':
        legal = [('LICENSE.txt', (source / 'LICENSE.txt').read_bytes(), None)]
    elif package['name'].startswith('vortex-'):
        info = json.loads((source / '.cargo_vcs_info.json').read_bytes())
        assert info['git']['sha1'] == 'c1439e69bf833fc702a60335ed674a1674ca358d'
        legal = [('LICENSE', (root / 'vendor/vortex-array/LICENSE').read_bytes(), vortex['license_url'])]
    else:
        assert declaration['repository'] == 'https://github.com/apache/arrow-rs'
        legal = [(name, (root / 'vendor/parquet' / name).read_bytes(), parquet[name.lower() + '_url'])
                 for name in ('LICENSE', 'NOTICE')]
    for name, raw, url in legal:
        digest = sha(raw)
        text = bundle / 'texts' / (digest + '.txt')
        assert text.read_bytes() == raw  # All are already reviewed notice texts.
        files.append({'text': 'texts/' + text.name, 'sha256': digest, 'bytes': len(raw),
                      **({'upstream_url': url} if url else {'crate_path': name})})
    before[key] = {name: package[name] for name in ('name', 'version', 'source')} | {
        'license': declaration['license'], 'repository': declaration['repository'],
        'crate_checksum_sha256': package['checksum'],
        'files': sorted(files, key=lambda item: (item['text'], json.dumps(item, sort_keys=True)))}
    report['new_packages'].append(before[key] | {'registry_manifest_sha256': sha((source / 'Cargo.toml').read_bytes()),
                                                'archive_checksum_matches': True})

manifest['components'] = [before[key] for key in sorted(locked)]
components = [row for row in manifest['vendored_components'] if row['path'] == 'vendor/vortex-arrow']
assert len(components) == 1
components[0]['provenance'] = provenance
assert manifest_path.read_bytes() == manifest_before and provenance_path.read_bytes() == provenance_before
provenance_path.write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + '\n')
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
report.update(provider_after=sha(provenance_path.read_bytes()), manifest_after=sha(manifest_path.read_bytes()),
              selected_provider_files={name: sha((provider / name).read_bytes()) for name in sorted(selected)})
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'new_packages'}))
