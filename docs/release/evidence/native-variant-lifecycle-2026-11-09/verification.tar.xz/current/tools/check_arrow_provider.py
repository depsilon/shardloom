"""Run the repository's exact changed-provider library test and lint commands."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path.insert(0, str(root / 'scripts'))
from ci_provider_tests import commands

frozen = root / '.github/provider-locks/vortex-arrow.lock'
target = root / 'vendor/vortex-arrow/Cargo.lock'
assert not target.is_symlink()
shutil.copyfile(frozen, target)
identity = hashlib.sha256(frozen.read_bytes()).hexdigest()
env = dict(os.environ, CLIPPY_CONF_DIR=str(root / 'vendor/vortex-array'))
for original in commands('vortex-arrow'):
    command = [*original[:2], '--offline', *original[2:]]
    print(command, flush=True)
    subprocess.run(command, cwd=root, env=env, check=True)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == identity
