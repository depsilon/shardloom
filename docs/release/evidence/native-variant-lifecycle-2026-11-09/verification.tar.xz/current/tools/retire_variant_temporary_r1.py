"""Retire six exact generated fixtures left by the interrupted native test process."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import tempfile

OUT = Path(__file__).resolve().parents[1]
DEST = OUT / 'temporary-retirement-r1'
HELPER = OUT / 'tools/retire_variant_debug_r1.py'
spec = importlib.util.spec_from_file_location('variant_retained', HELPER)
kept = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kept)
base = kept.base
TEMP = Path(tempfile.gettempdir()).resolve()
NAMES = (
    'shardloom-pivot-pressure-57363-2416',
    'shardloom-pivot-pressure-57363-2422',
    'shardloom-grid-pressure-57363-2904',
    'shardloom-grid-pressure-57363-2906',
    'shardloom-calendar-pressure-57363-3164',
    'shardloom-calendar-pressure-57363-3166',
)
ROOTS = [TEMP / name for name in NAMES]
RECEIPT = OUT / 'native-tests-r5.json'


def read(path):
    return json.loads(path.read_bytes())


def admit():
    result = read(RECEIPT)
    assert result['status'] == 'failed' and result['returncode'] == -15
    assert result['error'] == 'AssertionError: minimum free storage reached'
    assert result['process_group_drained'] and result['direct_child_reaped']
    assert result['fixed_source_validation'] and result['build_source_verification']['pre_execution']['changed_paths'] == []
    assert base.sha(RECEIPT.with_suffix('.log')) == result['log_sha256']
    assert str(TEMP).startswith('/private/var/folders/')
    for path in ROOTS:
        assert path.parent == TEMP and path.name in NAMES
        assert path.is_dir() and not path.is_symlink() and path.resolve() == path
    base.closed([str(path) for path in ROOTS])


def inventory():
    rows = []
    for root in ROOTS:
        for path in [root, *sorted(root.rglob('*'))]:
            before = base.generation(path)
            assert path.lstat().st_uid == os.getuid()
            if stat.S_ISDIR(before[2]):
                row = dict(path=str(path), generation=before, kind='directory')
            else:
                assert stat.S_ISREG(before[2]) and before[6] == 1
                row = dict(path=str(path), generation=before, kind='regular', sha256=base.sha(path))
            assert base.generation(path) == before
            rows.append(row)
    return rows


def plan():
    admit()
    assert not DEST.exists()
    manifest = dict(roots=[str(path) for path in ROOTS], entries=inventory(),
        native_receipt=RECEIPT.name, native_receipt_sha256=base.sha(RECEIPT),
        retained=kept.retained(), input_generations=kept.inputs(), release_generations=kept.release())
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode())
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', roots=manifest['roots'],
        manifest_sha256=base.sha(DEST / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), entries=len(manifest['entries']),
        regular_files=sum(row['kind'] == 'regular' for row in manifest['entries']),
        regular_bytes=sum(row['generation'][3] for row in manifest['entries'] if row['kind'] == 'regular'),
        reason='The supervised native test attempt stopped at its unchanged free-space floor and drained. These six exact PID-owned generated fixtures remain from the six unfinished pressure cases. Their source constructors and full original source snapshot regenerate them; their hashes and original failure log are preserved. This is cleanup, not native test acceptance.',
        regeneration_sources=[
            'shardloom-vortex/src/local_primitive_relational_pivot_pressure_tests.rs',
            'shardloom-vortex/src/local_primitive_relational_calendar_window_pressure_tests.rs',
            'shardloom-vortex/src/local_primitive_relational_temporal_grid_pressure_tests.rs'],
        storage_limits_changed=False, payload_backup_created=False)
    original = read(RECEIPT)
    summary['regeneration_source_identities'] = {
        name: original['build_sources'][name] for name in summary['regeneration_sources']}
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


def apply():
    admit()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion'
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    assert manifest['roots'] == summary['roots'] == [str(path) for path in ROOTS]
    assert manifest['native_receipt_sha256'] == base.sha(RECEIPT)
    assert kept.retained() == manifest['retained'] and kept.inputs() == manifest['input_generations']
    assert kept.release() == manifest['release_generations']
    assert inventory() == manifest['entries']
    base.closed([str(path) for path in ROOTS])
    receipt = dict(status='running', removed=0, manifest_sha256=summary['manifest_sha256'])
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(manifest['entries'], key=lambda row: len(Path(row['path']).parts), reverse=True):
            path = Path(row['path'])
            assert any(path == root or path.is_relative_to(root) for root in ROOTS)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                assert current == row['generation'] and base.sha(path) == row['sha256']
                path.unlink()
            receipt['removed'] += 1
        assert all(not path.exists() for path in ROOTS)
        assert kept.retained() == manifest['retained'] and kept.inputs() == manifest['input_generations']
        assert kept.release() == manifest['release_generations']
        receipt.update(status='passed', regular_files=summary['regular_files'],
            regular_bytes=summary['regular_bytes'], retained_runtimes_and_wheel_unchanged=True,
            input_generations_unchanged=True, release_cache_unchanged=True,
            storage_limits_changed=False, payload_backup_created=False,
            free_bytes_after=os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
