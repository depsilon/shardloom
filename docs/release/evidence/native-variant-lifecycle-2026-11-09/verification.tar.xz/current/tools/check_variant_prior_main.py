"""Verify the corrected prior-main mutation reaches its intended check."""
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

from check_variant_controls import changes_for, identity, write_case

out = Path(__file__).resolve().parents[1]
packet = out / 'packet-r3'
report = json.loads((packet / 'acceptance.json').read_bytes())
source = {}
with tarfile.open(fileobj=io.BytesIO((packet / 'verification.tar.xz').read_bytes()), mode='r:xz') as archive:
    for entry in archive:
        assert entry.isfile()
        source[entry.name] = archive.extractfile(entry).read()
changed, mutated = changes_for('prior_main_failed', source, report)
with tempfile.TemporaryDirectory(prefix='prior-main-control-', dir=out) as temporary:
    target = Path(temporary)
    shutil.copyfile(packet / 'verify.py', target / 'verify.py')
    write_case(target, changed, mutated)
    result = subprocess.run([sys.executable, '-I', '-B', str(target / 'verify.py')],
                            cwd=target, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=180, check=False)
    print(result.stdout.decode(), flush=True)
    assert result.returncode == 1
    assert b"matching[0]['conclusion'] == 'success'" in result.stdout
    assert b'len(archive_raw)' not in result.stdout
    saved = dict(status='passed', case='prior_main_failed', returncode=result.returncode,
        outcome='rejected_at_prior_main_success_requirement',
        original_packet={name: identity((packet / name).read_bytes())
                         for name in ('acceptance.json', 'verification.tar.xz', 'verify.py')},
        driver_identity=identity((out / 'tools/check_variant_controls.py').read_bytes()),
        original_failure_manifest_resealed=True,
        log=result.stdout.decode(), native_execution_repeated=False)
    with (out / 'prior-main-control-target-r1.json').open('x') as stream:
        json.dump(saved, stream, indent=2)
        stream.write('\n')
print(json.dumps(dict(status='passed', prior_main_control_target_verified=True)))
