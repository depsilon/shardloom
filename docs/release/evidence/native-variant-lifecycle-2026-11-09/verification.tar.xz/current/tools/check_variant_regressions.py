"""Check the two full-suite failures and isolated wheel test selection."""
import subprocess
import sys

native = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
for selected in (
    'native_writer_pins_frozen_core_edition_and_rejects_opt_in_buffer_encoding',
    'unary_melt_',
):
    command = ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
               '--features', native, selected]
    print('Checking ' + ' '.join(command), flush=True)
    subprocess.run(command, check=True, timeout=900)
subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'scripts',
                '-p', 'test_prove_native_python_wheel.py', '-v'], check=True, timeout=120)
