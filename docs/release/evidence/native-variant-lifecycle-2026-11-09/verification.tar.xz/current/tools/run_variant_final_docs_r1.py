"""Run final core, Rust documentation contracts and generated-reference checks."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
out = directory.parent
core_environment = ['env']
for name in ('SHARDLOOM_REQUIRE_NATIVE_PYTHON', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
             'SHARDLOOM_BIN', 'SHARDLOOM_SURFACE_TEST_BINARY', 'SHARDLOOM_REPO_ROOT',
             'SHARDLOOM_PROFILE_ORDER', 'PYTHONPATH', 'PYTHONHOME'):
    core_environment += ['-u', name]
checks = [
    ('python-core-r2', 900, [*core_environment, str(out / 'installed-proof-r1/venv/bin/python'),
        '-B', 'scripts/run_python_test_shard.py', '--shard', 'core',
        '--output-dir', str(out / 'python-core-r2')]),
    ('doc-contracts-r1', 900, ['cargo', 'test', '--offline', '--locked',
        '-p', 'shardloom-contract-tests', '--all-targets']),
    ('docs-r1', 900, [sys.executable, '-B', str(directory / 'check_variant_docs.py'),
        '--runtime', str(out / 'runtime-r2')]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(directory / 'guard_variant.py'),
                    '--name', name, '--timeout', str(timeout), '--', *command], check=True)
