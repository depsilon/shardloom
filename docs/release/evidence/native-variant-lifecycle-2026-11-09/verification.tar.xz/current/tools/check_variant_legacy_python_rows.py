"""Reproduce the existing native mixed-MELT diagnostic row contract."""
import json

from shardloom.models import OutputEnvelope
from shardloom.query import Result

expected = [
    {'account_key': 1, 'kind': 'amount', 'cell': (1 << 64) - 1},
    {'account_key': 1, 'kind': 'label', 'cell': 'π'},
    {'account_key': None, 'kind': 'amount', 'cell': 0},
    {'account_key': None, 'kind': 'label', 'cell': None},
    {'account_key': 3, 'kind': 'amount', 'cell': 42},
    {'account_key': 3, 'kind': 'label', 'cell': 'end'},
]
schema = {'Struct': [{'names': ['account_key', 'kind', 'cell'], 'dtypes': [
    {'Primitive': ['u64', True]}, {'Utf8': False}, {'Variant': True},
]}, False]}
report = Result(None, 'collect', OutputEnvelope.from_field_mapping({
    'result_values_json': json.dumps(expected),
    'result_schema_json': json.dumps(schema),
    'result_schema_format': 'vortex.dtype.serde.v1',
}))
assert report.result_rows == tuple(expected)
assert report.python_objects == tuple(expected)
print('Legacy mixed-MELT complete scalar rows and Python conversion preserved')
