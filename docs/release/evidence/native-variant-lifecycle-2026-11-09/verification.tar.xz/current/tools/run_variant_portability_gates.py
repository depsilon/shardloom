"""Run default, feature and MSRV gates sequentially on the final source."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
checks = [
    ('default-clippy-r1', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace',
                              '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-r1', 1800, ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('features-r1', 3600, [sys.executable, '-B', str(directory / 'check_variant_features.py')]),
    ('msrv-r1', 3600, [sys.executable, '-B', str(directory / 'check_variant_msrv.py')]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, str(directory / 'guard_variant.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], check=True)
