"""Run both existing Rust MSRV CI checks with the installed pinned toolchain."""
import subprocess

commands = [
    ['rustup', 'run', '1.96.0', 'cargo', 'check', '--workspace', '--no-default-features'],
    ['rustup', 'run', '1.96.0', 'cargo', 'check', '--workspace', '--all-targets', '--features', 'release-user-surfaces'],
]
for command in commands:
    command += ['--locked', '--offline']
    print('Checking ' + ' '.join(command), flush=True)
    subprocess.run(command, check=True, timeout=1800)
