"""Execute the checked-in guide's Python and SQL declarations on native data."""
import json
from pathlib import Path
import re
import sys

root = Path.cwd()
sys.path[:0] = [str(root / 'python/src'), str(root / 'python/tests')]
from test_native_binding import _load_native
_load_native()
import shardloom as sl
from shardloom import functions as f, types as t

guide = (root / 'docs/reference/vector-expressions.md').read_text()
python = re.findall(r'```python\n(.*?)```', guide, re.DOTALL)
sql = re.findall(r'```sql\n(.*?)```', guide, re.DOTALL)
assert len(python) == 2 and len(sql) == 1
scope = {}
exec(compile(python[0], 'vector-expressions.md:first-python-example', 'exec'), scope)
exec(compile(python[1], 'vector-expressions.md:embedding-declaration', 'exec'), scope)
with sl.context(transport='native', memory_bytes=128 << 20, max_parallelism=1) as context:
    source = context.from_rows([
        {'id': 40, 'eligible': True, 'v': [3.0, 4.0]},
        {'id': 10, 'eligible': True, 'v': [3.0, 4.0]},
        {'id': 5, 'eligible': False, 'v': [3.0, 4.0]},
        {'id': 20, 'eligible': True, 'v': [4.0, 3.0]},
        {'id': 2, 'eligible': True, 'v': [0.0, 0.0]},
    ], schema={'id': t.int64(), 'eligible': t.boolean(), 'v': t.list_(t.float64())})
    result = context.sql(sql[0], relations={'candidates': source}).collect(check=True)
    rows = result.to_rows()
    assert [row['id'] for row in rows] == [10, 40, 20, 2]
    assert rows[0] == {'id': 10, 'score': 1.0, 'distance': 0.0}
    assert rows[-1] == {'id': 2, 'score': None, 'distance': 5.0}
    assert result.envelope.field('fallback_attempted') == 'false'
    assert result.envelope.field('external_engine_invoked') == 'false'
    embedding = context.from_rows([{'embedding': [3.0, 4.0]}],
        schema={'embedding': t.embedding(t.float32(), 2, metadata={'space_id': 'guide'})})
    assert embedding.select(scope['score'].alias('score')).collect(check=True).to_rows() == ({'score': 1.0},)
print(json.dumps({'status': 'passed', 'python_examples': 2, 'sql_examples': 1,
                  'filtered_order_and_ties': [10, 40, 20, 2], 'fallback_attempted': False}))
