"""Bind the committed vector delivery to its complete accepted source and runtime."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET_REL = 'docs/release/evidence/native-vector-expressions-2026-11-08/'
PACKET = ROOT / PACKET_REL
PRIOR = OUT.parent / 'provider-upgrade-2026-11-08/provider-closeout-r1.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


assert not git('status', '--porcelain')
assert git('branch', '--show-current') == 'codex/native-vector-expressions'
head = git('rev-parse', 'HEAD')
report, prior = read(PACKET / 'acceptance.json'), read(PRIOR)
assert report['status'] == 'local_acceptance_passed' and prior['status'] == 'complete'
base = report['source_base']
assert base == prior['merge_commit']
assert git('show', '-s', '--format=%P', head).split() == [base]
subprocess.run([sys.executable, '-I', '-B', str(PACKET / 'verify.py'),
    '--repo-root', str(ROOT), '--require-controls'], cwd=ROOT, check=True, timeout=180)
packet_names = {'acceptance.json', 'verification.tar.xz', 'verify.py', 'corruption-controls.json', 'README.md'}
assert {path.name for path in PACKET.iterdir()} == packet_names
docs = read(OUT / report['roles']['docs'])
assert docs['status'] == 'passed' and docs['fixed_source_validation']
assert docs['process_group_drained'] and docs['direct_child_reaped']
expected = {name for name in docs['changed_source_inventory'] if not name.startswith(PACKET_REL)}
expected.update(PACKET_REL + name for name in packet_names)
assert set(git('diff', '--no-renames', '--name-only', base, head).splitlines()) == expected
assert not git('diff', '--numstat', base, head, '--', '.github/workflows')
installed = read(OUT / report['installed_report'])
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == report['installed_package']
wheel = (OUT / report['installed_report']).parent / 'dist' / installed['integrity']['wheel']
frozen = read(OUT / report['runtime_identity'])
for row in frozen['files']:
    assert identity(Path(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')}
assert identity(wheel)['sha256'] == report['runtime_and_wheel']['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for name, info in report['source_snapshot'].items():
        if name.startswith('python/src/shardloom/') and name.endswith('.py'):
            raw = archive.read(name.removeprefix('python/src/'))
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == info, name
result = dict(status='passed', head=head, tree=git('rev-parse', head + '^{tree}'), base=base,
    base_branch='main', runtime_sources_match_build=True,
    runtime_source_proof='Complete final source matches docs and contract gates; compiled inputs, fixtures, Python package and public/installed tests match their retained checks under the explicit status-prose and separate Python-test source policy.',
    ci_workflow_blob=git('rev-parse', head + ':.github/workflows/ci.yml'), reviewed_workflow_changes={},
    packet_files={name: identity(PACKET / name) for name in sorted(packet_names)},
    installed_package=report['installed_package'], runtime_and_wheel=report['runtime_and_wheel'],
    changed_files=sorted(expected), prior_provider_closeout=identity(PRIOR),
    publication_attempted=False, performance_claim=False, whole_item_19_complete=False)
with (OUT / 'delivery-acceptance-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'head', 'tree', 'installed_package')}))
