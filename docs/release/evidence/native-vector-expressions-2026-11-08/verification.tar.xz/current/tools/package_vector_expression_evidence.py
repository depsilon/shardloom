"""Seal exact runtime, public/installed checks, frozen references and all attempts."""
import argparse
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import zipfile

from verify_vector_expression_packet import (
    BASE, FROZEN, LIMITATIONS, MODULES, NATIVE_TEST_SOURCES, ROLES,
    digest, fingerprint, identity, rust_counts, source_deltas, test_methods, verify,
)

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'provider-upgrade-2026-11-08'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--plan', type=Path, required=True)
parser.add_argument('--destination', type=Path, required=True)
parser.add_argument('--execution-name', required=True)
args = parser.parse_args()
assert args.destination.is_relative_to(OUT) and not args.destination.exists()
assert args.execution_name.replace('-', '').isalnum()


def read(path):
    return json.loads(path.read_bytes())


plan = read(args.plan)
roles = plan['roles']
assert set(roles) == ROLES
receipts = {role: read(OUT / filename) for role, filename in roles.items()}
source = receipts['docs']['build_sources']
assert all(row['status'] == 'passed' and row['returncode'] == 0 for row in receipts.values())
checks = {}
for role, filename in roles.items():
    receipt = receipts[role]
    raw = (OUT / filename.removesuffix('.json')).with_suffix('.log').read_bytes()
    assert digest(raw) == receipt['log_sha256']
    checks[role] = dict(receipt=filename, status='passed', command=receipt['command'], rust_tests=rust_counts(raw))
installed = read(OUT / plan['installed_report'])
installed_root = (OUT / plan['installed_report']).parent
assert installed['status'] == installed['uninstall_status'] == 'passed'
wheel_path = installed_root / 'dist' / installed['integrity']['wheel']
assert digest(wheel_path.read_bytes()) == installed['integrity']['wheel_sha256']
python_sources = {name: info for name, info in source.items()
                  if name.startswith('python/src/shardloom/') and name.endswith('.py')}
with zipfile.ZipFile(wheel_path) as archive:
    for name, info in python_sources.items():
        assert identity(archive.read(name.removeprefix('python/src/'))) == info
    for suffix, key in [('/_native.abi3.so', 'native_library_sha256'), ('/bin/macos-aarch64/shardloom', 'cli_sha256')]:
        names = [name for name in archive.namelist() if name.endswith(suffix)]
        assert len(names) == 1 and digest(archive.read(names[0])) == installed['integrity'][key]
wheel_sources = dict(status='passed', wheel_sha256=installed['integrity']['wheel_sha256'], python_sources=python_sources)
wheel_identity_path = OUT / 'wheel-source-identity.json'
if wheel_identity_path.exists():
    assert read(wheel_identity_path) == wheel_sources
else:
    wheel_identity_path.write_text(json.dumps(wheel_sources, indent=2) + '\n')

files = {}


def add(path, relative):
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    assert relative not in files or files[relative] == raw
    files[relative] = raw


# Preserve observations and complete original inventories, not temporary runtime,
# installed environment, compiler, package staging or private continuation data.
selected = [*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('source-blobs/*'), *OUT.glob('tools/*.py')]
selected += [*OUT.glob('preparation/*.json'), *OUT.glob('preparation/*.log'), *OUT.glob('preparation/*.py')]
for name in ('selected-contract-r1.md', 'selected-contract-admission-completion-r2.md',
             'numerical-bound-derivation.md', 'numerical-implementation-notes.md'):
    selected.append(OUT / 'preparation' / name)
selected += [*OUT.glob('installed-proof-*/*.json'), *OUT.glob('installed-proof-*/*.log')]
selected += [*OUT.glob('python-core-*/*.json'), *OUT.glob('python-core-*/*.log')]
selected += [path for path in (OUT / 'debug-retirement-r1').glob('*') if path.is_file()]
for path in sorted(set(selected)):
    if path.name in {args.execution_name + '.json', args.execution_name + '.log'}:
        continue
    add(path, 'current/' + path.relative_to(OUT).as_posix())
closeout = read(PRIOR / 'provider-closeout-r1.json')
assert closeout['status'] == 'complete' and closeout['merge_commit'] == BASE
add(PRIOR / 'provider-closeout-r1.json', 'prior/provider-closeout-r1.json')
for relative, info in closeout['receipts'].items():
    assert identity((PRIOR / relative).read_bytes()) == info
    add(PRIOR / relative, 'prior/' + relative)

dispositions = read(OUT / 'failure-dispositions.json')
failures = []
for name, raw in sorted(files.items()):
    if not (name.startswith('current/') and name.endswith('.json') and name.count('/') <= 2):
        continue
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        continue
    if isinstance(value, dict) and (str(value.get('status')).startswith('failed') or value.get('status') == 'interrupted'):
        relative = name.removeprefix('current/')
        assert relative in dispositions and dispositions[relative], relative
        failures.append(dict(receipt=name, identity=identity(raw), disposition=dispositions[relative]))
assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
core = read(OUT / plan['python_core_receipt'])
core_log = (OUT / roles['python_core'].removesuffix('.json')).with_suffix('.log').read_bytes()
count = re.search(rb'Ran (\d+) tests? in [0-9.]+s', core_log)
assert count
native_tests = sorted(name for relative in NATIVE_TEST_SOURCES for name in re.findall(
    r'#\[test\]\s*fn\s+(\w+)\s*\(', (ROOT / relative).read_text()))
public_tests = sorted(name for module in MODULES for name in test_methods(
    (ROOT / 'python/tests' / (module + '.py')).read_bytes(), module))
report = dict(schema_version='shardloom.vector_expressions_acceptance.v1', status='local_acceptance_passed',
    source_base=BASE, source_snapshot=source, source_fingerprint_sha256=fingerprint(source),
    source_deltas={role: source_deltas(receipt['build_sources'], source) for role, receipt in receipts.items()},
    source_scope_policy='Complete original input inventories; only named status prose and Cargo-independent Python test changes can differ. All final public and installed code/fixture inputs match.',
    roles=roles, checks=checks, required_native_tests=native_tests, public_tests=public_tests,
    frozen_references=FROZEN, runtime_identity=plan['runtime_identity'],
    runtime_and_wheel={key: installed['integrity'][key] for key in ('cli_sha256', 'native_library_sha256', 'wheel_sha256')},
    python_core_receipt=plan['python_core_receipt'], python_core=dict(discovered_test_cases=core['test_count'],
        reported_test_runs=int(count[1]), skip_records=core['skipped_count'], failures=core['failure_count'], errors=core['error_count']),
    installed_report=plan['installed_report'], installed_package=installed['integration'],
    original_failures=failures, limitations=LIMITATIONS, hosted_integration='pending',
    performance_claim=False, publication_attempted=False, whole_item_19_complete=False,
    archive='verification.tar.xz', members=[dict(path=name, **identity(raw)) for name, raw in sorted(files.items())])
assert sum(len(raw) for raw in files.values()) < 512 << 20
args.destination.mkdir()
with tarfile.open(args.destination / report['archive'], 'w:xz', preset=6) as archive:
    for row in report['members']:
        entry = tarfile.TarInfo(row['path'])
        entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
        archive.addfile(entry, io.BytesIO(files[row['path']]))
report['archive_sha256'] = digest((args.destination / report['archive']).read_bytes())
(args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copyfile(OUT / 'tools/verify_vector_expression_packet.py', args.destination / 'verify.py')
print(json.dumps(verify(args.destination, ROOT), sort_keys=True))
