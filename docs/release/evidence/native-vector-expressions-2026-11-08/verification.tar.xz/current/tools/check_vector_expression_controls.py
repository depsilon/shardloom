"""Exercise standalone copied evidence and resealed acceptance corruptions."""
import argparse
import copy
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

CASES = (
    'original', 'relocated_source_only', 'unsealed_archive_corruption',
    'required_role_omitted', 'native_failed', 'source_drift', 'old_runtime_build',
    'installed_skips', 'installed_test_omitted', 'public_test_omitted',
    'native_regression_omitted', 'frozen_reference_substituted',
    'compiled_source_changed', 'original_failure_omitted', 'runtime_identity_changed',
    'prior_main_failed', 'unsafe_archive_path',
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def fingerprint(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def mutate(data, path, change):
    value = json.loads(data[path])
    change(value)
    data[path] = encoded(value)


def rebind_freeze(data, report):
    mutate(data, 'current/' + report['runtime_identity'], lambda value: value.update(
        build_receipt_sha256=sha(data['current/' + report['roles']['build']])))


def rebind_cleanup(data):
    path = 'current/debug-retirement-r1/manifest.json.xz'
    value = json.loads(lzma.decompress(data[path]))
    for name in value['native_checks']:
        value['native_checks'][name] = sha(data['current/' + name])
    data[path] = lzma.compress(json.dumps(value, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    for name in ('plan.json', 'receipt.json'):
        mutate(data, 'current/debug-retirement-r1/' + name, lambda item: item.update(manifest_sha256=sha(data[path])))


def rewrite_source(data, report, path, raw):
    """Reseal inventories consistently so frozen-value policy is what rejects."""
    info = identity(raw)
    data['current/source-blobs/' + info['sha256']] = raw
    for name in list(data):
        if not (name.startswith('current/') and name.count('/') == 1 and name.endswith('.json')):
            continue
        value = json.loads(data[name])
        if not isinstance(value, dict) or path not in value.get('build_sources', {}):
            continue
        value['build_sources'][path] = info
        if path in value.get('changed_source_inventory', {}):
            value['changed_source_inventory'][path] = info
        value['build_source_fingerprint_sha256'] = fingerprint(value['build_sources'])
        for observation in value['build_source_verification'].values():
            observation['fingerprint_sha256'] = value['build_source_fingerprint_sha256']
        data[name] = encoded(value)
    report['source_snapshot'][path] = info
    report['source_fingerprint_sha256'] = fingerprint(report['source_snapshot'])
    rebind_freeze(data, report)


def changes_for(case, source, original_report):
    data, report = source.copy(), copy.deepcopy(original_report)
    role = lambda name: 'current/' + report['roles'][name]
    installed = 'current/' + report['installed_report']
    installed_dir = str(Path(installed).parent)
    if case == 'required_role_omitted':
        del report['roles']['public']
    elif case == 'native_failed':
        mutate(data, role('native_tests'), lambda value: value.update(status='failed', returncode=1))
    elif case == 'source_drift':
        mutate(data, role('native_tests'), lambda value: value['build_source_verification']['post_execution'].update(
            changed_paths=['shardloom-vortex/src/local_primitives/native_vector_math.rs']))
    elif case == 'old_runtime_build':
        report['roles']['build'] = 'vector-release-build-r1.json'
        old = json.loads(data[role('build')])
        report['checks']['build'] = dict(receipt=report['roles']['build'], status='passed', command=old['command'], rust_tests=None)
    elif case == 'installed_skips':
        mutate(data, installed, lambda value: value['integration'].update(skipped=1))
        mutate(data, installed_dir + '/integration.json', lambda value: value.update(skipped=1))
        report['installed_package']['skipped'] = 1
    elif case == 'installed_test_omitted':
        path = installed_dir + '/integration.log'
        lines = data[path].decode().splitlines(keepends=True)
        index = next(index for index, line in enumerate(lines)
                     if '(test_native_vector_expression_semantics_binding.' in line and line.rstrip().endswith('... ok'))
        del lines[index]
        raw = ''.join(lines)
        raw = re.sub(r'Ran (\d+) tests in', lambda match: 'Ran ' + str(int(match[1]) - 1) + ' tests in', raw)
        data[path] = raw.encode()
        value = json.loads(data[installed])
        value['integration']['tests'] -= 1
        step = next(step for step in value['steps'] if step['name'] == 'integration')
        step['log_sha256'] = sha(data[path])
        data[installed] = encoded(value)
        data[installed_dir + '/integration.json'] = encoded(value['integration'])
        report['installed_package'] = value['integration']
    elif case in {'public_test_omitted', 'native_regression_omitted'}:
        selected = 'public' if case == 'public_test_omitted' else 'native_tests'
        path = role(selected).removesuffix('.json') + '.log'
        lines = data[path].decode().splitlines(keepends=True)
        if selected == 'public':
            index = next(index for index, line in enumerate(lines)
                         if '(test_native_vector_expression_workflow_binding.' in line and line.rstrip().endswith('... ok'))
        else:
            method = report['required_native_tests'][0]
            index = next(index for index, line in enumerate(lines) if '::' + method + ' ... ok' in line)
        del lines[index]
        data[path] = ''.join(lines).encode()
        mutate(data, role(selected), lambda value: value.update(log_sha256=sha(data[path])))
    elif case == 'frozen_reference_substituted':
        path = 'shardloom-vortex/tests/fixtures/native_vector_numerical_reference_r2.json'
        value = json.loads(data['current/source-blobs/' + report['source_snapshot'][path]['sha256']])
        value['cases'][0]['expected']['dot'] = '3ff0000000000000'
        rewrite_source(data, report, path, encoded(value))
    elif case == 'compiled_source_changed':
        info = report['source_snapshot']['shardloom-vortex/src/local_primitives/native_vector_math.rs']
        data['current/source-blobs/' + info['sha256']] += b'\n// changed after validation\n'
    elif case == 'original_failure_omitted':
        omitted = 'current/vector-literal-regression-r3.json'
        del data[omitted]
        report['original_failures'] = [entry for entry in report['original_failures'] if entry['receipt'] != omitted]
    elif case == 'runtime_identity_changed':
        mutate(data, 'current/' + report['runtime_identity'], lambda value: value['files'][0].update(sha256='0' * 64))
    elif case == 'prior_main_failed':
        raw_path = 'prior/provider-main1670-r1-raw/checks.json'
        receipt_path = 'prior/provider-main1670-r1.json'
        hosted = json.loads(data[receipt_path])
        raw = json.loads(data[raw_path])
        next(row for row in raw['check_runs'] if row['name'] == hosted['required_hosted_check_names'][0])['conclusion'] = 'failure'
        data[raw_path] = encoded(raw)
        hosted['raw_sources']['provider-main1670-r1-raw/checks.json'] = sha(data[raw_path])
        data[receipt_path] = encoded(hosted)
        closeout = json.loads(data['prior/provider-closeout-r1.json'])
        for path in (raw_path, receipt_path):
            closeout['receipts'][path.removeprefix('prior/')] = identity(data[path])
        data['prior/provider-closeout-r1.json'] = encoded(closeout)
        for path in list(data):
            if path.startswith('current/') and path.count('/') == 1 and path.endswith('.json'):
                value = json.loads(data[path])
                if isinstance(value, dict) and 'prior_closeout_sha256' in value:
                    value['prior_closeout_sha256'] = sha(data['prior/provider-closeout-r1.json'])
                    data[path] = encoded(value)
        rebind_freeze(data, report)
        rebind_cleanup(data)
    elif case == 'unsafe_archive_path':
        data['../untrusted.json'] = b'{}\n'
    return data, report


def write_case(target, data, report):
    members = []
    with tarfile.open(target / 'verification.tar.xz', 'w:xz', preset=0) as archive:
        for path, raw in sorted(data.items()):
            entry = tarfile.TarInfo(path)
            entry.mode, entry.mtime, entry.size = 0o644, 0, len(raw)
            archive.addfile(entry, io.BytesIO(raw))
            members.append(dict(path=path, **identity(raw)))
    report['members'] = members
    report['archive_sha256'] = sha((target / 'verification.tar.xz').read_bytes())
    (target / 'acceptance.json').write_bytes(encoded(report))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    names = {'acceptance.json', 'verification.tar.xz', 'verify.py'}
    assert not args.output.exists() and {path.name for path in args.packet.iterdir()} == names
    original = {name: (args.packet / name).read_bytes() for name in names}
    report = json.loads(original['acceptance.json'])
    assert sha(original['verification.tar.xz']) == report['archive_sha256']
    source = {}
    with tarfile.open(fileobj=io.BytesIO(original['verification.tar.xz']), mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in report['members']]
        for row, member in zip(report['members'], archive.getmembers(), strict=True):
            assert member.isfile()
            raw = archive.extractfile(member).read()
            assert identity(raw) == {key: row[key] for key in ('bytes', 'sha256')}
            source[member.name] = raw
    args.output.mkdir()
    results = []
    for case in CASES:
        accepted = case in {'original', 'relocated_source_only'}
        with tempfile.TemporaryDirectory(prefix='vector-expression-control-', dir=args.output) as temporary:
            target = Path(temporary)
            for name, raw in original.items():
                (target / name).write_bytes(raw)
            changed, changed_report = changes_for(case, source, report)
            changes = []
            if case == 'unsealed_archive_corruption':
                raw = bytearray(original['verification.tar.xz'])
                raw[-1] ^= 1
                (target / 'verification.tar.xz').write_bytes(raw)
            elif not accepted:
                for path in sorted(set(source) | set(changed)):
                    if source.get(path) != changed.get(path):
                        changes.append(dict(path=path, before=identity(source[path]) if path in source else None,
                                            after=identity(changed[path]) if path in changed else None))
                write_case(target, changed, changed_report)
            run_target = args.packet if case == 'original' else target
            result = subprocess.run([sys.executable, '-I', '-B', str(run_target / 'verify.py')],
                cwd=target, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False, timeout=180)
            log = args.output / (case + '.log')
            log.write_bytes(result.stdout)
            assert (result.returncode == 0) == accepted, (case, result.returncode, result.stdout[-2000:])
            if accepted:
                observed = json.loads(result.stdout)
                assert observed['status'] == 'passed' and not observed['repository_checked'] and not observed['native_execution_repeated']
            else:
                assert b'AssertionError' in result.stdout or b'KeyError' in result.stdout
            results.append(dict(case=case, expected='accepted' if accepted else 'rejected', returncode=result.returncode,
                log=log.name, log_identity=identity(result.stdout), mutations=changes,
                report_before=identity(original['acceptance.json']), report_after=identity((target / 'acceptance.json').read_bytes()),
                tested_packet={name: identity((run_target / name).read_bytes()) for name in sorted(names)},
                original_packet_unchanged=all((args.packet / name).read_bytes() == raw for name, raw in original.items())))
            assert results[-1]['original_packet_unchanged']
            print(json.dumps(dict(case=case, outcome='accepted' if accepted else 'rejected')), flush=True)
    receipt = dict(status='passed', cases=results, positive_controls=2, rejected_controls=len(CASES) - 2,
        original_packet={name: identity(raw) for name, raw in sorted(original.items())}, driver_sha256=sha(Path(__file__).read_bytes()),
        scope='Actual isolated subprocess replay without a checkout. Negative archives resealed except checksum control; known failures, final source, frozen expectations, test coverage and prior closeout challenged. Temporary mutation payloads removed after each observation; originals unchanged.')
    (args.output / 'receipt.json').write_bytes(encoded(receipt))
    print(json.dumps(dict(status='passed', positive_controls=2, rejected_controls=len(CASES) - 2)))


if __name__ == '__main__':
    main()
