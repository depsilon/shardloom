"""Retain saved subprocess control outcomes and bind their original packet."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--controls', type=Path, required=True)
args = parser.parse_args()
receipt = json.loads((args.controls / 'receipt.json').read_bytes())
assert receipt['status'] == 'passed'
assert receipt['positive_controls'] == 2 and receipt['rejected_controls'] == 15


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


for name, expected in receipt['original_packet'].items():
    assert identity((args.packet / name).read_bytes()) == expected
logs = {}
for index, case in enumerate(receipt['cases']):
    raw = (args.controls / case['log']).read_bytes()
    assert identity(raw) == case['log_identity']
    assert case['returncode'] == (0 if index < 2 else 1)
    assert case['original_packet_unchanged']
    if index < 2:
        assert json.loads(raw)['status'] == 'passed'
    else:
        assert b'AssertionError' in raw or b'KeyError' in raw
    logs[case['log']] = raw.decode()
result = dict(status='passed', receipt=receipt, logs=logs,
    scope='Saved actual subprocess outcomes, identities and mutations. No repeated engine execution.',
    primary_sealer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with (args.packet / 'corruption-controls.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
subprocess.run([sys.executable, '-I', '-B', str(args.packet / 'verify.py'), '--require-controls'],
    check=True, timeout=180)
