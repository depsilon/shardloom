# Shared exact vector expressions: selected implementation contract

Prepared November 8 against clean merged `d29bff42c`. These are the primary's
semantic choices for implementation and independent acceptance; they are not
an implemented capability or acceptance report. Provider integration closeout
still precedes changes to the engine. Freeze expected semantics before running
the candidate kernels; any later revision must preserve the earlier observation.

## Admitted shared surface

Use the shared scalar-function registry, native binder/evaluator, SQL declarations
and `shardloom.functions` declarations. Arithmetic accepts dense List or
FixedSizeList with F16/F32/F64 components and the existing dense embedding
extension. Component widths may differ and widen exactly to F64. Integer,
Boolean, decimal, tensor, sparse, quantized and multi-vector arithmetic is not
implicitly converted. No external query engine, ANN index, model call, implicit
flattening, densification or dequantization is introduced.

| SQL function | Arguments | Result |
| --- | --- | --- |
| `VECTOR_DIMENSION` | dense vector, sparse vector or quantized vector | U64, parent null propagates |
| `TENSOR_SHAPE` | fixed/variable tensor, optional literal `'logical'` or `'physical'` | FixedSizeList<U64 nonnull, rank>, parent null propagates |
| `VECTOR_VALUES` | dense vector or embedding | same native list storage, embedding metadata explicitly removed |
| `VECTOR_ELEMENT` | dense vector, integer index | nullable original component type |
| `VECTOR_SLICE` | dense vector, integer start, optional integer end | List of original component type; parent/control null propagates |
| `VECTOR_DOT` | two dense vectors | nullable F64 |
| `VECTOR_L2_DISTANCE` | two dense vectors | nullable F64 |
| `VECTOR_COSINE_SIMILARITY` | two dense vectors | nullable F64 |
| `VECTOR_NORM` | dense vector | nullable F64, Euclidean norm |
| `VECTOR_NORMALIZE` | dense vector | List/FixedSizeList of nonnull F64 with nullable parent |

`VECTOR_NORMALIZE` preserves list versus fixed-list shape and fixed width, but
returns ordinary list storage even for embeddings. It deliberately carries no
embedding identity or normalization claim. `VECTOR_SLICE` always returns an
ordinary variable List; coordinate slices must not retain the original space
identity. `VECTOR_VALUES` is the explicit value-only escape from semantic identity,
not an operation that reconstructs sparse or quantized values.

Python functions use corresponding lowercase names. Column-position strings
continue to mean column names. `array([...])` may compose with these functions as
an inert literal declaration; it must not drop source/resource bindings from
other arguments. Float literals remain explicit (`1.0`, not implicit conversion
of integer-list columns). Empty or all-null literal ARRAY arguments may receive
contextual F64 nullable component type within this family only; generic ARRAY
inference remains unchanged. Ordinary integer-valued ARRAY arguments remain
outside arithmetic admission unless explicitly converted by an admitted path.

## Dimensions, shape and selection

Reject known unequal fixed dimensions at bind time, including empty-input plans.
For variable dimensions, compare lengths only for a selected row with both
parents present. Unequal lengths are an error before component-null handling.
Empty present dense vectors have dimension zero and dot/norm/distance zero.

Element indices are zero-based; negative indices count from the end. Out of
range or null controls return null. Slices are start-inclusive/end-exclusive,
clamp both bounds, interpret negative bounds from the end, default omitted end
to length, and return an empty list when end precedes start. Handle full signed
and unsigned integer domains without overflow. Both selection operations retain
original component width, nulls, signed zeros and NaN payload bits under either
float policy; carried values are not arithmetic observations.

Dense dimension reads native coordinates and validity. Sparse dimension reads
the selected required U64 `size`; quantized dimension reads selected code-list
length. Enforce declared `uniform_size`. These inspectors do not reconstruct or
certify unused coordinate/code/parameter payloads; existing input admission and
validation are unchanged. They do not turn multi-vector collections into one
vector or return a single dimension for a collection.

Tensor shape defaults to logical order. Physical shape is stored metadata (fixed
tensor) or the selected Int32 shape row (variable tensor). Logical dimension i
is physical dimension `permutation[i]`; omission is identity. Dimension names do
not alter sizes. Preserve rank zero as an empty shape list and zero dimensions
as zeros. For variable tensors, reuse the native shape validator: present data
and shape lists, every nonnull nonnegative dimension, exact rank, uniform-shape
constraints and product equal to data-list length. Inspect data coordinates,
not component values. Do not infer saved file IO from that kernel boundary.

## Embedding comparisons

Binary arithmetic between two embeddings requires equal fixed widths and an
equal, nonempty `space_id`. Then compare `model_id`, `model_version`,
`representation_version` and `preprocessing_id` exactly, normalizing absent/null
to unknown. Both unknown secondary values may match only because the known
space anchor already matches; known-versus-unknown or unequal values refuse.
No whitespace, case or Unicode normalization is invented. `normalization` and
`source_provenance` are not coordinate-space identity fields.

Mixed embedding/bare-list binary arithmetic refuses until the caller explicitly
uses `VECTOR_VALUES`. Unary norm/normalization and selection do not compare two
spaces and therefore do not require known identity. Metadata errors and static
dimension/space refusals remain binding errors even for null or unselected rows.

## Observation order and exceptional values

Bind types, declarations and identity first. Evaluate argument expressions under
their own contracts; vector null shielding does not suppress errors from an
argument expression or a rejected nonfinite literal. For each arithmetic row:

1. Null parent gives null without observing component payloads.
2. Check equal dimensions for two present vectors.
3. Any null component in either vector gives a null result before numeric payload
   observation. Do not skip components or substitute zero.
4. Observe all valid components under the caller's float policy and compute.

Strict policy rejects observed nonfinite components and a nonfinite final result.
Finite intermediates that would overflow ordinary F64 multiplication/subtraction
must not cause a false refusal when the final result is representable. Extended
policy admits the following declared outcomes, using the canonical F64 NaN for
newly computed NaNs:

- Dot follows product classification: NaN or zero-times-infinity gives NaN;
  opposing signed infinite products give NaN; otherwise infinity keeps its sign.
- Norm gives NaN if any component is NaN, otherwise infinity if any is infinite.
- L2 distance gives NaN for NaN input or same-signed infinity minus infinity;
  any other infinite difference gives positive infinity.
- Cosine gives NaN if either vector has a nonfinite component. For finite inputs,
  either zero norm gives null (including empty vectors).
- Normalization gives null for a finite zero norm. A NaN norm gives NaN in every
  component. An infinite norm gives signed zero for finite components and NaN for
  infinite components. Component-null rows have already become parent null.

Dot exact zero is positive zero, while a negative nonzero result that underflows
retains negative zero. Norm/distance zeros are positive. Normalization preserves
the sign of original zero components. Cosine exact-zero dot is positive zero;
negative nonzero underflow preserves its sign. Clamp finite cosine to [-1,1].

## Finite arithmetic contract

Use exact finite products and a narrowly scoped, fixed-capacity signed integer
accumulator. The prepared derivation supplies two 68-limb sign banks at quantum
2^-2148, sufficient for all binary64 products and a 64-bit component count,
including exact squared-distance expansion `a*a - 2*a*b + b*b`.

Dot, norm and L2 distance receive one final nearest-even F64 rounding of the exact
real result, with the true subnormal/overflow boundary. Norm/distance rounding
uses an integer square-root candidate and exact midpoint comparison, not a
rounded squared sum followed by a floating square root. This is a deliberately
bounded numerical helper, not a general arbitrary-precision runtime.

Cosine and normalization use rounded normal mantissas and separately retained
exponents from exact accumulators, so an overflowed norm or underflowed dot is
not an intermediate failure. The pre-implementation error contract is:

- normalization: `abs(result - exact) <= 3*u*abs(exact) + eta/2`;
- cosine: `abs(result - exact) <= 5*u*abs(exact) + eta/2`;

where `u=2^-53` and `eta=2^-1074`. See `numerical-bound-derivation.md` for the
algorithm assumptions and exact rational proof inequalities. The independent
reference defines the exact real comparison through rational radicands. Check
these inequalities directly, plus exceptional classes and zero signs. The
prepared 4-ULP/8-ULP screens are finite-corpus checks, not universal error claims.

Exact filtered retrieval evaluates every eligible candidate using these declared
scores. It does not promise infinite-precision ranking: rounded scores may tie,
and examples/tests must declare deterministic secondary ordering.

## Construction, resources and acceptance

Compose existing ARRAY literals with registered scalar calls and account for
every parser node under the existing 65,536-byte/4,096-node/24-depth limits.
Permit larger all-literal floating lists only within those declaration and live
resource limits; keep the 128-child bound for general expression constructors.
Store a literal vector once in an allocator-owned native child and broadcast by
the existing native ListView coordinate representation. Do not clone a composite
Scalar heap for every row. Retain credits with buffers, including plan-drop,
child extraction, slices, empty results and final-owner release. Address the
source-demonstrated flat literal lifetime gap where the shared path is reused.

Prepare selected component spans with existing native list/numeric owners and
admitted expansion credits. Keep cancellation checks inside long component
loops, as well as at row/batch boundaries. Preserve shared expression reuse,
source binding, checked output shape and runtime/certificate ownership.

Acceptance must cover all ten functions, both front doors, F16/F32/F64 and mixed
widths, actual constant queries beyond 128 components, parent/component nulls,
empty/fixed/variable vectors, index/slice extremes, metadata conflicts, encoded
and chunked children, duplicate selection, independent 270-case numerical
reference, deterministic filtered ranking, retained outputs and native
write/separate-process reopen/export. Include memory denial, cancellation and
cleanup controls plus required default/native/feature/installed-package checks,
portable replay and hosted review/integration. No benchmark, package publication,
whole-item-19 completion or CG-1 through CG-23 completion is claimed.
