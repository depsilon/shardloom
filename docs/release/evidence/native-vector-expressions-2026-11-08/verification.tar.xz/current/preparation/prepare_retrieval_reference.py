"""Freeze a wide-query filtered retrieval fixture before native implementation."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("reference", ROOT / "exact_vector_reference.py")
REFERENCE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REFERENCE)
DIMENSION = 1536


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), "preserve original preparation"
    query = [1.0] + [0.0] * (DIMENSION - 1)
    query_bits = [REFERENCE.to_bits(64, value) for value in query]
    query_sql = "ARRAY[" + ",".join("1.0" if index == 0 else "0.0" for index in range(DIMENSION)) + "]"
    assert len(query_sql.encode()) < 65536 and DIMENSION + 2 < 4096
    cases = []
    for width in (16, 32, 64):
        rows = []
        for identifier, first, second in ((40, 3.0, 4.0), (10, 3.0, 4.0),
                                           (20, 10.0, 0.0), (30, -1.0, 0.0)):
            vector = [first, second] + [0.0] * (DIMENSION - 2)
            raw = [REFERENCE.to_bits(width, component) for component in vector]
            expected = REFERENCE.expected(width, raw, 64, query_bits)
            rows.append(dict(id=identifier, eligible=True,
                vector_bits=[f"{item:0{width // 4}x}" for item in raw],
                expected={name: expected[name] for name in
                          ("dot", "norm_left", "l2_distance", "cosine", "normalized_left")}))
        payload_nan = {16: "fd11", 32: "ff812345", 64: "fff0000000000001"}[width]
        zero = "0" * (width // 4)
        rows.append(dict(id=50, eligible=False, vector_bits=[payload_nan] + [zero] * (DIMENSION - 1),
                         expected="excluded_before_arithmetic"))
        rows.append(dict(id=60, eligible=True, vector_bits=None,
                         expected={name: None for name in
                                   ("dot", "norm_left", "l2_distance", "cosine", "normalized_left")}))
        rows.append(dict(id=70, eligible=True, vector_bits=[None, payload_nan] + [zero] * (DIMENSION - 2),
                         expected={name: None for name in
                                   ("dot", "norm_left", "l2_distance", "cosine", "normalized_left")}))
        by_id = {row["id"]: row for row in rows}
        assert by_id[10]["expected"]["cosine"] == by_id[40]["expected"]["cosine"]
        assert by_id[20]["expected"]["cosine"] == "3ff0000000000000"
        assert by_id[30]["expected"]["cosine"] == "bff0000000000000"
        assert by_id[10]["expected"]["norm_left"] == "4014000000000000"
        cases.append(dict(component_width=width, dimension=DIMENSION, rows=rows,
                          expected_order=[20, 10, 40, 30, 60, 70], expected_top_three=[20, 10, 40]))
    source_names = (Path(__file__).name, "exact_vector_reference.py", "selected-contract-r1.md",
                    "selected-contract-admission-completion-r2.md")
    report = dict(schema="shardloom.vector-retrieval-preparation.v1", status="prepared_not_executed",
                  created_at=datetime.now(timezone.utc).isoformat(), engine_executed=False,
                  dimension=DIMENSION, query_component_width=64,
                  query_bits=[f"{item:016x}" for item in query_bits], query_literal_sql=query_sql,
                  literal_nodes=DIMENSION + 1, cases=cases,
                  selection="WHERE eligible; score cosine DESC NULLS LAST, id ASC; top three",
                  representation_routes=["plain_variable", "plain_fixed", "embedding_with_explicit_vector_values"],
                  notes=[
                      "Expected complete finite values use the independent Fraction/midpoint oracle.",
                      "Cosine and normalization comparisons use the selected error bounds, not exact-bit equality.",
                      "The duplicate candidate vectors at ids 10 and 40 have identical inputs, so deterministic computed-score ties use id ordering.",
                      "This replaces the prepared r1 scaled-vector tie, which relied on an unstated scaling-invariance requirement beyond the public error bound.",
                      "The excluded NaN row and null-component row require a file prepared under extended policy before strict arithmetic tests.",
                      "Existing complete source-intake validation remains mandatory; this fixture does not grant masked invalid intake.",
                      "No performance or payload-IO claim follows from this correctness fixture.",
                  ], source_sha256={name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                    for name in source_names})
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(dict(status=report["status"], widths=len(cases), rows=sum(len(c["rows"]) for c in cases),
                          dimension=DIMENSION, bytes=args.output.stat().st_size,
                          sha256=hashlib.sha256(args.output.read_bytes()).hexdigest())))


if __name__ == "__main__":
    main()
