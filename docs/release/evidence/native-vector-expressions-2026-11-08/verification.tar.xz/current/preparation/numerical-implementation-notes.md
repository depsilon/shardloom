# Numerical implementation notes

Primary design, not code or executed implementation. Read the selected semantic
contract and numerical-bound derivation first. These details preserve the
reasoning for the future native helper; no dependency or copied code is needed.

- Finite binary64 decomposition: normal significand `(1<<52)|fraction`, scale
  `exponent_bits-1075`; subnormal significand `fraction`, scale `-1074`. Separate
  sign. Products fit u128, shift `scale_a+scale_b+2148` lies in 0..4090. A doubled
  cross product uses shift+1. Two 68x64-bit sign banks give 4352 bits, enough for
  all component counts on 32/64-bit usize targets. One squared difference is
  below 2^2050, at most 2^64 components gives each bank below 2^2114, so fewer
  than 4262 bits at quantum 2^-2148. Reject impossible carry/domain violations.
- Add u128 products as at most three shifted u64 words; handle zero bit offset
  separately to avoid a shift by 64. Propagate carries with checked bounds.
  Subtract positive/negative magnitudes once using comparison and borrows.
  Stack scratch is bounded; admit the selected operation's scratch and any
  heap/array owners before constructing them, without claiming process-RSS coverage.
- To round signed magnitude M for dot: highest set bit h; target shift
  `max(h-52,1074)`, retained integer n, round/sticky bits and nearest-even tie.
  Encode n at power `shift-2148`; a carry can reach infinity at the true midpoint.
  Exact signed cancellation returns +0; negative nonzero underflow returns -0.
- For sqrt(M*2^-2148), use q and t from the existing derivation. t is always
  even, so its only value below two is zero. `M >> t` has at most 106 bits;
  its u128 integer square root gives n. When t=0 compare 4*M to (2*n+1)^2
  in u128; otherwise compare M to the at-most-108-bit threshold shifted by
  t-2. This avoids a general multiword square root. Perform one midpoint
  rounding and encode n*2^q, including overflow. Verify the declared MSRV
  supports the selected integer-sqrt API before using it.
- A normalized accumulator pair `(mantissa, exponent)` rounds its top 53 bits
  but never rounds the full value to subnormal or infinity. A rounded mantissa
  of two becomes one and increments exponent. Zero is separate.
- Cosine: rounded dot mantissa divided by sqrt(rounded product of the two
  rounded norm-square mantissas, adjusted by exponent parity). Split exponent
  sums using Euclidean division by two, including negative exponents. All
  intermediate mantissas remain normal. Retain the remaining power of two
  separately and clamp the finite final result to [-1,1].
- Normalization: exact component mantissa divided by sqrt(rounded norm-square
  mantissa times its exact parity factor); retain exponents separately.
- Final scaling of a normal finite ratio can be performed by exponent bits
  for normal output. For subnormal output, shift the original 53-bit integer
  significand with a single nearest-even rounding. Shifts of 54 or more yield
  signed zero; shift 53 still requires midpoint handling. Preserve original
  zero-component signs. Avoid two successive underflow roundings.
- The finite contract is exact final rounding for dot/norm/distance and the
  derived 3u/5u relative-plus-half-minsubnormal bounds for normalize/cosine.
  Keep the 4/8 ULP screens as corpus checks rather than universal proofs.

## Native integration constraints verified in source

`native_relational_expression.rs::evaluate_function` must dispatch vector
functions before converting all arguments to KeyColumn. Evaluate array arguments
with the existing scoped reuse path; use ReservedVec for temporary array owners.
Keep ordinary checked-result validation and cancellation. Static layout controls
may be consumed/truncated at binding, as decimal/temporal controls already are.

`native_list::Column` and `Coordinates` provide validity/offset/count handling.
Use selected child spans, not full-child canonicalization by default.
`native_payload_vector.rs::numeric_range` demonstrates expansion admission before
provider execution, with the temporary owner dropped before its lease. A last-
span cache may retain those owners for repeated constant query spans only if the
credit outlives the owner. No arbitrary unbounded cache is needed.

`NativeNumericOwner::new_with_float_policy` prepares host storage and validity;
it does not observe floating values. `is_null` checks validity only. Its
`numeric_value`, `stat_value` and `visit_numeric` expose widened values without
automatically enforcing float policy, so the vector kernel must enforce policy
after complete component-null shielding. `visit_numeric` dispatches type around
the whole typed loop and can avoid per-component enum dispatch. F16/F32 widening
uses the existing bit-preserving core helpers. Check cancellation inside loops.

`python/tests/test_native_float16_binding.py:243-262` explicitly proves strict
file reads can carry nonfinite bits unchanged, while arithmetic, keys and
selected common-type promotion reject observation. Thus raw element/slice
carriage is consistent, but do not use generic value-validating builders that
would impose an arithmetic observation. Existing CopyPolicy::PreserveUnobserved
is a private raw-copy tool; its comment currently describes private windows.
Any reuse must keep source admission, selected masks, metadata and ownership
checks, and must not accidentally relax arithmetic or public intake.

`native_payload_tensor.rs::validate_selection` checks variable tensor shape and
data-list lengths without reading component values; its metadata validator
checks all dimensions even after a zero product. Reuse this invariant for shape
inspection. Dense/sparse/quantized dimension inspection is separately scoped
to required coordinates by the selected contract.

The flat UTF8/Binary constant accounting gap is source-demonstrated and existed
at pre-upgrade a157a5ff as well. Binder charges and stores the lease on the plan;
scalar buffers use the global allocator and may survive plan drop. Consider
allocator-owned construction at bind or a focused lease transfer. Do not simply
subtract the whole literal envelope from `binding_metadata`: ranked execution
uses that field as a temporary plan/schema copy admission bound
(`local_primitive_relational_ranked.rs:69`). A separate retained buffer allocation
can conservatively coexist with current binder charges. Verify budget, drop,
empty/slice/child-clone and cancellation behavior with a regression before fixing.
