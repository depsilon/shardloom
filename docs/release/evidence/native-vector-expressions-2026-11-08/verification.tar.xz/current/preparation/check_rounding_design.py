"""Check the proposed exact-rounding formulas, without executing native code.

The candidate formulas use unbounded Python integers here only as a design
model. Expectations come from the separate Fraction/binary64-neighbor oracle.
This checks the rounding derivation, not a future fixed-limb implementation.
"""

import argparse
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import importlib.util
import json
from math import isqrt
from pathlib import Path
import random


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "independent_reference", ROOT / "exact_vector_reference.py"
)
REFERENCE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REFERENCE)
QUANTUM = 2148
INF = 0x7FF0000000000000


def nearest_integer(magnitude, shift):
    if shift <= 0:
        return magnitude << -shift
    integer, remainder = divmod(magnitude, 1 << shift)
    midpoint = 1 << (shift - 1)
    return integer + int(remainder > midpoint or
                         (remainder == midpoint and integer & 1))


def encode(integer, exponent):
    """Encode a pre-rounded integer * 2^exponent without another rounding."""
    if not integer:
        return 0
    high = integer.bit_length() - 1
    binary_exponent = high + exponent
    if binary_exponent > 1023:
        return INF
    if binary_exponent < -1022:
        assert exponent >= -1074
        return integer << (exponent + 1074)
    shift = high - 52
    if shift > 0:
        assert integer & ((1 << shift) - 1) == 0
        significand = integer >> shift
    else:
        significand = integer << -shift
    assert (1 << 52) <= significand < (1 << 53)
    return ((binary_exponent + 1023) << 52) | (significand - (1 << 52))


def dot_formula(magnitude):
    if not magnitude:
        return 0
    high = magnitude.bit_length() - 1
    shift = max(high - 52, 1074)
    return encode(nearest_integer(magnitude, shift), shift - QUANTUM)


def sqrt_formula(magnitude):
    if not magnitude:
        return 0
    high = magnitude.bit_length() - 1
    exponent = (high - QUANTUM) // 2
    quantum = max(exponent - 52, -1074)
    shift = QUANTUM + 2 * quantum
    assert shift >= 0 and shift % 2 == 0
    shortened = magnitude >> shift
    assert shortened.bit_length() <= 106
    integer = isqrt(shortened)
    boundary = (2 * integer + 1) ** 2
    assert boundary.bit_length() <= 108
    if shift == 0:
        comparison = (4 * magnitude > boundary) - (4 * magnitude < boundary)
    else:
        threshold = boundary << (shift - 2)
        comparison = (magnitude > threshold) - (magnitude < threshold)
    integer += int(comparison > 0 or (comparison == 0 and integer & 1))
    return encode(integer, quantum)


def scaled_integer(value):
    scaled = value * (1 << QUANTUM)
    assert scaled.denominator == 1
    return scaled.numerator


def rounding_cases():
    cases = {"zero": 0, "minimum_quantum": 1}
    # Every normal exponent plus the subnormal endpoints. Exact powers give
    # direct bit expectations; boundary cases below use the independent oracle.
    for high in range(4262):
        cases[f"power_{high}"] = 1 << high
    for shift in (1, 63, 64, 65, 127, 128, 1073, 1074, 1075,
                  2047, 2048, 2095, 2096, 3117, 3118, 4095, 4096, 4209):
        for integer in ((1 << 52), (1 << 52) + 1, (1 << 53) - 1):
            center = (2 * integer + 1) << (shift - 1)
            for delta in (-1, 0, 1):
                cases[f"dot_midpoint_{shift}_{integer}_{delta}"] = center + delta
    for quantum in (-1074, -1073, -1050, -1023, -1022, -1000,
                    -500, -53, -52, -1, 0, 1, 500, 970, 971, 972, 1005):
        shift = QUANTUM + 2 * quantum
        for integer in (1, 2, 3, (1 << 52), (1 << 52) + 1, (1 << 53) - 1):
            boundary = Fraction((2 * integer + 1) ** 2, 4) * (1 << shift)
            if boundary.denominator != 1:
                # A fractional threshold cannot be an exact tie on the
                # accumulator lattice. Check its two adjacent lattice points.
                floor = boundary.numerator // boundary.denominator
                cases[f"sqrt_boundary_floor_{quantum}_{integer}"] = floor
                cases[f"sqrt_boundary_ceil_{quantum}_{integer}"] = floor + 1
            else:
                for delta in (-1, 0, 1):
                    value = boundary.numerator + delta
                    if value >= 0:
                        cases[f"sqrt_midpoint_{quantum}_{integer}_{delta}"] = value
    rng = random.Random(0x524F554E44564543)
    for index in range(192):
        high = rng.randrange(4262)
        cases[f"random_{index}"] = (1 << high) | rng.getrandbits(high)
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), "preserve earlier observations"
    count = 0
    maximum_bits = 0
    for name, magnitude in rounding_cases().items():
        exact = Fraction(magnitude, 1 << QUANTUM)
        for label, formula, squared in (
                ("dot", dot_formula, False), ("sqrt", sqrt_formula, True)):
            observed = formula(magnitude)
            expected = REFERENCE.rounded_positive(exact, squared)
            assert observed == expected, (name, label, hex(observed), hex(expected))
            count += 1
        maximum_bits = max(maximum_bits, magnitude.bit_length())

    corpus = json.loads((ROOT / "numerical-reference-draft-r2.json").read_bytes())
    rows = corpus["cases"]
    corpus_checks = 0
    for row in rows:
        left = [Fraction.from_float(REFERENCE.to_float(row["left_width"], int(v, 16)))
                for v in row["left"]]
        right = [Fraction.from_float(REFERENCE.to_float(row["right_width"], int(v, 16)))
                 for v in row["right"]]
        dot = sum((a * b for a, b in zip(left, right)), Fraction())
        fields = {
            "dot": dot_formula(scaled_integer(abs(dot))) | ((1 << 63) if dot < 0 else 0),
            "norm_left": sqrt_formula(scaled_integer(sum((v * v for v in left), Fraction()))),
            "norm_right": sqrt_formula(scaled_integer(sum((v * v for v in right), Fraction()))),
            "l2_distance": sqrt_formula(scaled_integer(sum(((a - b) ** 2 for a, b in
                                                            zip(left, right)), Fraction()))),
        }
        for field, value in fields.items():
            assert f"{value:016x}" == row["expected"][field], (row["id"], field)
            corpus_checks += 1
    source_names = (Path(__file__).name, "exact_vector_reference.py",
                    "numerical-reference-draft-r2.json", "selected-contract-r1.md",
                    "numerical-implementation-notes.md")
    result = {
        "status": "passed_design_model_only",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "native_engine_executed": False,
        "runtime_fixed_limb_implementation_verified": False,
        "rounding_formula_checks": count,
        "maximum_tested_magnitude_bits": maximum_bits,
        "independent_corpus_cases": len(rows),
        "independent_corpus_field_checks": corpus_checks,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                          for name in source_names},
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
