"""Freeze manually specified vector/shape expectations; never execute ShardLoom."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "semantic-reference-r1.json"
assert not OUT.exists()
NULL = {"kind": "null"}
NAN = {"kind": "f64_bits", "bits": "7ff8000000000000"}
PINF = {"kind": "f64_bits", "bits": "7ff0000000000000"}
NINF = {"kind": "f64_bits", "bits": "fff0000000000000"}
ZERO = {"kind": "f64_bits", "bits": "0000000000000000"}
ONE = {"kind": "f64_bits", "bits": "3ff0000000000000"}
NONFINITE = {"kind": "error", "category": "observed_nonfinite"}
DIMENSION = {"kind": "error", "category": "unequal_dimensions"}
nan, inf, neginf, negzero, poszero = (
    "fff0000000000001", "7ff0000000000000", "fff0000000000000",
    "8000000000000000", "0000000000000000")
one, two, negone = "3ff0000000000000", "4000000000000000", "bff0000000000000"
cases = []


def dense(values, dtype="f64", fixed=None, metadata=None):
    value = dict(kind="dense_storage", component=dtype, values=values)
    if fixed is not None:
        value["fixed"] = fixed
    if metadata is not None:
        value["embedding"] = {"version": 1, **metadata}
    return value


def add(name, operation, arguments, strict, extended=None):
    cases.append(dict(id=name, operation=operation, arguments=arguments,
                      expected={"strict": strict, "extended": strict if extended is None else extended}))


def component(bits, dtype="f64"):
    return dict(kind="component_bits", component=dtype, bits=bits)


def vector(bits, dtype="f64", fixed=None):
    result = dict(kind="vector_bits", component=dtype, values=bits)
    if fixed is not None:
        result["fixed"] = fixed
    return result


for op in ("vector_dot", "vector_l2_distance", "vector_cosine_similarity"):
    add(op + "_null_parent", op, [dense(None), dense([nan, inf])], NULL)
    add(op + "_null_component_left", op, [dense([nan, None]), dense([one, two])], NULL)
    add(op + "_null_component_right", op, [dense([nan, two]), dense([one, None])], NULL)
    add(op + "_dimension_before_null_component", op,
        [dense([None]), dense([nan, one])], DIMENSION)
    add(op + "_empty", op, [dense([]), dense([])],
        NULL if op == "vector_cosine_similarity" else ZERO)

for op in ("vector_norm", "vector_normalize"):
    add(op + "_null_parent", op, [dense(None)], NULL)
    add(op + "_null_component_before_nan", op, [dense([nan, None])], NULL)
    add(op + "_empty", op, [dense([])], NULL if op == "vector_normalize" else ZERO)

add("dot_zero_times_infinity", "vector_dot", [dense([poszero]), dense([inf])], NONFINITE, NAN)
add("dot_opposing_infinite_products", "vector_dot",
    [dense([inf, inf]), dense([one, negone])], NONFINITE, NAN)
add("dot_negative_infinite_product", "vector_dot", [dense([inf]), dense([negone])], NONFINITE, NINF)
add("dot_negative_zero_exact_sum", "vector_dot", [dense([negzero]), dense([one])], ZERO)
add("norm_nan_before_infinity", "vector_norm", [dense([inf, nan])], NONFINITE, NAN)
add("norm_infinite_component", "vector_norm", [dense([neginf, one])], NONFINITE, PINF)
add("norm_signed_zero", "vector_norm", [dense([negzero, poszero])], ZERO)
add("distance_same_infinity", "vector_l2_distance", [dense([inf]), dense([inf])], NONFINITE, NAN)
add("distance_opposite_infinity", "vector_l2_distance", [dense([inf]), dense([neginf])], NONFINITE, PINF)
add("distance_infinity_finite", "vector_l2_distance", [dense([neginf]), dense([one])], NONFINITE, PINF)
add("cosine_nonfinite_before_zero_norm", "vector_cosine_similarity",
    [dense([poszero, negzero]), dense([nan, one])], NONFINITE, NAN)
add("cosine_zero_norm", "vector_cosine_similarity", [dense([poszero]), dense([one])], NULL)
add("normalize_zero_norm", "vector_normalize", [dense([negzero, poszero])], NULL)
add("normalize_nan_norm", "vector_normalize", [dense([nan, inf, one])], NONFINITE,
    vector([NAN["bits"]] * 3))
add("normalize_infinite_norm", "vector_normalize", [dense([inf, neginf, negone, negzero, poszero])], NONFINITE,
    vector([NAN["bits"], NAN["bits"], negzero, negzero, poszero]))
add("normalize_preserves_zero_signs", "vector_normalize", [dense([negzero, poszero, one])],
    vector([negzero, poszero, one]))
add("normalize_preserves_fixed_width", "vector_normalize", [dense([one, poszero], fixed=2)],
    vector([one, poszero], fixed=2))
add("normalize_strips_embedding_identity", "vector_normalize",
    [dense([one, poszero], fixed=2, metadata={"space_id": "known"})],
    vector([one, poszero], fixed=2))

raw = [nan, inf, negzero, None]
for name, index, expected in (
    ("nan_payload", 0, component(nan)), ("infinity_carriage", 1, component(inf)),
    ("negative_index", -2, component(negzero)), ("null_component", -1, NULL),
    ("positive_oob", 4, NULL), ("negative_oob", -5, NULL),
    ("signed_min", -(1 << 63), NULL), ("unsigned_max", (1 << 64) - 1, NULL),
    ("null_index", None, NULL)):
    add("element_" + name, "vector_element", [dense(raw), index], expected)
add("element_null_parent", "vector_element", [dense(None), 0], NULL)
for dtype, bits in (("f16", "fd11"), ("f32", "ff812345")):
    add("element_" + dtype + "_nan_payload", "vector_element", [dense([bits], dtype), 0], component(bits, dtype))
    add("slice_" + dtype + "_nan_payload", "vector_slice", [dense([bits], dtype), 0, 1], vector([bits], dtype))
for name, bounds, expected in (
    ("nan_payload", [0, 1], vector([nan])), ("negative_bounds", [-3, -1], vector([inf, negzero])),
    ("omitted_end", [2], vector([negzero, None])), ("end_before_start", [3, 1], vector([])),
    ("clamped_extremes", [-(1 << 63), (1 << 64) - 1], vector(raw)),
    ("unsigned_start", [(1 << 64) - 1], vector([])), ("null_start", [None], NULL),
    ("null_end", [0, None], NULL)):
    add("slice_" + name, "vector_slice", [dense(raw), *bounds], expected)
add("slice_null_parent", "vector_slice", [dense(None), 0, 1], NULL)
add("slice_strips_fixed_embedding_identity", "vector_slice",
    [dense([one, two], fixed=2, metadata={"space_id": "known"}), 0, 2], vector([one, two]))
add("values_strips_identity_without_changing_bits", "vector_values",
    [dense([nan, negzero], fixed=2, metadata={"space_id": "known"})], vector([nan, negzero], fixed=2))
add("values_plain_list_identity", "vector_values", [dense(raw)], vector(raw))
add("dimension_dense", "vector_dimension", [dense(raw)], dict(kind="u64", value=4))
add("dimension_empty", "vector_dimension", [dense([])], dict(kind="u64", value=0))
add("dimension_null_parent", "vector_dimension", [dense(None)], NULL)
add("dimension_sparse_max_u64", "vector_dimension",
    [dict(kind="sparse_storage", size=(1 << 64) - 1, indices=[], values=[])], dict(kind="u64", value=(1 << 64) - 1))
add("dimension_quantized_codes", "vector_dimension",
    [dict(kind="quantized_storage", codes=[-128, None, 127], scale=0.5, zero_point=0)], dict(kind="u64", value=3))
add("dimension_uniform_mismatch", "vector_dimension",
    [dict(kind="sparse_storage", size=2, indices=[], values=[], uniform_size=3)],
    dict(kind="error", category="uniform_size"))


def shape_case(name, storage, expected, layout=None):
    add(name, "tensor_shape", [storage] + ([] if layout is None else [layout]), expected)


def shape_result(values):
    return dict(kind="shape_u64", values=values, fixed=len(values))


fixed = dict(kind="fixed_tensor_storage", shape=[2, 3, 4], permutation=[2, 0, 1], present=True)
shape_case("shape_fixed_logical", fixed, shape_result([4, 2, 3]))
shape_case("shape_fixed_physical", fixed, shape_result([2, 3, 4]), "physical")
shape_case("shape_fixed_null", {**fixed, "present": False}, NULL)
shape_case("shape_fixed_rank_zero", dict(kind="fixed_tensor_storage", shape=[], present=True), shape_result([]))
shape_case("shape_fixed_zero_dimension", dict(kind="fixed_tensor_storage", shape=[(1 << 63) - 1, 0], present=True),
           shape_result([(1 << 63) - 1, 0]))
variable = dict(kind="variable_tensor_storage", rank=3, shape=[3, 2, 5], data_length=30,
                permutation=[2, 0, 1], uniform_shape=[None, 2, None], present=True)
shape_case("shape_variable_logical", variable, shape_result([5, 3, 2]))
shape_case("shape_variable_physical", variable, shape_result([3, 2, 5]), "physical")
shape_case("shape_variable_null", {**variable, "present": False}, NULL)
shape_case("shape_variable_rank_zero", dict(kind="variable_tensor_storage", rank=0, shape=[], data_length=1, present=True),
           shape_result([]))
shape_case("shape_variable_later_zero", dict(kind="variable_tensor_storage", rank=4,
    shape=[(1 << 31) - 1] * 3 + [0], data_length=0, present=True), shape_result([(1 << 31) - 1] * 3 + [0]))
for name, change, category in (
    ("uniform_mismatch", dict(shape=[0, 3, 5], data_length=0), "uniform_shape"),
    ("product_mismatch", dict(data_length=29), "shape_product"),
    ("negative_after_zero", dict(shape=[0, -1, 5], data_length=0), "shape_dimension"),
    ("null_after_zero", dict(shape=[0, None, 5], data_length=0), "shape_dimension")):
    shape_case("shape_variable_" + name, {**variable, **change}, dict(kind="error", category=category))

bindings = []


def binding(name, left, right, accepted, category=None):
    bindings.append(dict(id=name, operation="vector_dot", left=left, right=right,
                         accepted=accepted, error_category=category))


base = dense([one], fixed=1, metadata={"space_id": "known"})
binding("known_matching_space", base, base, True)
binding("unknown_spaces", dense([one], fixed=1, metadata={}), dense([one], fixed=1, metadata={}), False, "embedding_space")
binding("conflicting_space", base, dense([one], fixed=1, metadata={"space_id": "Known"}), False, "embedding_space")
binding("mixed_embedding_plain", base, dense([one], fixed=1), False, "embedding_space")
binding("unequal_fixed_dimensions", base, dense([one, two], fixed=2, metadata={"space_id": "known"}), False, "unequal_dimensions")
for field in ("model_id", "model_version", "representation_version", "preprocessing_id"):
    supplied = dense([one], fixed=1, metadata={"space_id": "known", field: "v1"})
    binding(field + "_known_vs_unknown", supplied, base, False, "embedding_identity")
    binding(field + "_matching", supplied, supplied, True)
    binding(field + "_missing_vs_null", base, dense([one], fixed=1, metadata={"space_id": "known", field: None}), True)
for field in ("normalization", "source_provenance"):
    binding(field + "_not_space_identity", dense([one], fixed=1, metadata={"space_id": "known", field: "a"}),
            dense([one], fixed=1, metadata={"space_id": "known", field: "b"}), True)

ids = [case["id"] for case in cases] + [case["id"] for case in bindings]
assert len(ids) == len(set(ids))
assert {case["operation"] for case in cases} == {
    "vector_dimension", "tensor_shape", "vector_values", "vector_element", "vector_slice",
    "vector_dot", "vector_l2_distance", "vector_cosine_similarity", "vector_norm", "vector_normalize"}
assert all(set(case["expected"]) == {"strict", "extended"} for case in cases)
for case in cases:
    for arg in case["arguments"]:
        if isinstance(arg, dict) and arg.get("kind") == "dense_storage":
            width = {"f16": 4, "f32": 8, "f64": 16}[arg["component"]]
            for bits in arg["values"] or []:
                assert bits is None or (len(bits) == width and int(bits, 16) < 1 << (4 * width))
report = dict(schema="shardloom.vector-semantics-preparation.v1", status="prepared_not_executed",
              created_at=datetime.now(timezone.utc).isoformat(),
              source_contract_sha256=hashlib.sha256((ROOT / "selected-contract-r1.md").read_bytes()).hexdigest(),
              generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              engine_executed=False, cases=cases, binding_cases=bindings,
              notes=["Dense floating inputs are original stored bits, not SQL nonfinite literals.",
                     "Expected rows are manually selected semantic facts; no runtime implementation was used.",
                     "Schema/category assertions require routing-specific adapters in future native tests.",
                     "Finite numerical accuracy is governed separately by the 270-case exact reference."])
with OUT.open("x") as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(dict(status=report["status"], row_cases=len(cases), policy_expectations=2 * len(cases),
                      binding_cases=len(bindings), sha256=hashlib.sha256(OUT.read_bytes()).hexdigest())))
