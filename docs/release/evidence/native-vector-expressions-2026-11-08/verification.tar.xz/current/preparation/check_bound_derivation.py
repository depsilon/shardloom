"""Verify the exact rational inequalities in the candidate error derivation."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
u = Fraction(1, 1 << 53)
assert 1 - 5 * u > 0
checks = {
    "normalization_lower": (1-u)**2 > (1-3*u)**2 * (1+u)**3,
    "normalization_upper": (1+u)**2 < (1+3*u)**2 * (1-u)**3,
    "cosine_lower": (1-u)**4 > (1-5*u)**2 * (1+u)**5,
    "cosine_upper": (1+u)**4 < (1+5*u)**2 * (1-u)**5,
}
assert all(checks.values())
source = root / "numerical-bound-derivation.md"
report = dict(status="passed_candidate_bound_inequalities", u_power=-53, checks=checks,
              native_engine_executed=False, implementation_accepted=False,
              derivation_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
              verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              scope="Exact rational checks of the specified candidate algorithm's rounding bounds; no native implementation or public admission acceptance")
with (root / "numerical-bound-derivation-r1.json").open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps(report))
