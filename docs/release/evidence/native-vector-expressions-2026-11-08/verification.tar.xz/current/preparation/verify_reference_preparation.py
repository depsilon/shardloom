"""Cross-check preparation references through independent Decimal arithmetic."""

from decimal import Decimal, Inexact, localcontext
import hashlib
import json
from pathlib import Path
import struct


ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "numerical-reference-draft-r2.json"
FORMATS = {16: ("e", "H"), 32: ("f", "I"), 64: ("d", "Q")}


def read_values(width, bits):
    real, integer = FORMATS[width]
    return [struct.unpack(">" + real, struct.pack(">" + integer, int(value, 16)))[0]
            for value in bits]


def bits(value):
    return struct.pack(">d", float(value)).hex()


def file_identity(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


report = json.loads(REFERENCE.read_bytes())
assert report["status"] == "independent_numerical_preparation"
assert report["native_engine_executed"] is report["implementation_accepted"] is False
assert report["generator_sha256"] == file_identity(ROOT / "exact_vector_reference.py")["sha256"]
assert report["case_count"] == len(report["cases"]) == 270
assert len({row["id"] for row in report["cases"]}) == len(report["cases"])

manual = {
    "three_four": dict(dot="4008000000000000", norm_left="4014000000000000"),
    "unit_orthogonal": dict(cosine="0000000000000000"),
    "unit_equal": dict(cosine="3ff0000000000000", l2_distance="0000000000000000"),
    "unit_opposite": dict(cosine="bff0000000000000", l2_distance="4000000000000000"),
    "overflow_products_cancel_to_one": dict(dot="3ff0000000000000"),
    "overflow_products_cancel_to_small": dict(dot=bits(2.0**-100)),
    "half_subnormal_products": dict(dot="0000000000000001"),
    "negative_underflow_tie": dict(dot="8000000000000000"),
    "cosine_unit_despite_dot_underflow": dict(dot="0000000000000000", cosine="3ff0000000000000"),
    "cosine_unit_despite_dot_overflow": dict(dot="7ff0000000000000", cosine="3ff0000000000000"),
    "normalization_despite_norm_overflow": dict(norm_left="7ff0000000000000", cosine="0000000000000000"),
    "maximum_opposite": dict(l2_distance="7ff0000000000000", cosine="bff0000000000000"),
    "maximum_adjacent": dict(l2_distance=bits(2.0**971)),
    "one_adjacent": dict(l2_distance=bits(2.0**-52)),
}
manual_count = 0
verified = []
for row in report["cases"]:
    expectation = row["expected"]
    for field, value in manual.get(row["id"], {}).items():
        assert expectation[field] == value, (row["id"], field, expectation[field], value)
        manual_count += 1
    left_float = read_values(row["left_width"], row["left"])
    right_float = read_values(row["right_width"], row["right"])
    with localcontext() as context:
        context.prec = 6144
        context.clear_flags()
        left, right = [Decimal(value) for value in left_float], [Decimal(value) for value in right_float]
        dot = sum((a * b for a, b in zip(left, right)), Decimal())
        a2 = sum((value * value for value in left), Decimal())
        b2 = sum((value * value for value in right), Decimal())
        d2 = sum(((a - b) * (a - b) for a, b in zip(left, right)), Decimal())
        product = a2 * b2
        assert not context.flags[Inexact], (row["id"], "Decimal precision was insufficient for exact preparation")
        norm_left, norm_right = a2.sqrt(), b2.sqrt()
        actual = dict(
            dot=bits(dot if dot else Decimal()),
            norm_left=bits(norm_left), norm_right=bits(norm_right),
            l2_distance=bits(d2.sqrt()),
            cosine=bits(dot / product.sqrt() if dot else Decimal()) if product else None,
            normalized_left=[bits(value / norm_left) for value in left] if norm_left else None,
            zero_norm_left=not a2, zero_norm_right=not b2,
        )
        assert actual == expectation, (row["id"], actual, expectation)
    verified.append(row["id"])

earlier = json.loads((ROOT / "numerical-reference-draft-r1.json").read_bytes())
assert earlier["generator_sha256"] == file_identity(ROOT / "exact_vector_reference_draft_r1.py")["sha256"]
result = dict(
    status="passed_independent_reference_crosscheck",
    cases=len(verified), manual_exact_field_controls=manual_count,
    oracle_intrinsic_controls=report["oracle_controls_passed"],
    decimal_precision=6144, decimal_rational_stage_had_no_rounding=True,
    native_engine_executed=False, implementation_accepted=False,
    acceptance_tolerances_frozen=False,
    reference=file_identity(REFERENCE), generator=file_identity(ROOT / "exact_vector_reference.py"),
    verifier=file_identity(Path(__file__)), preserved_prior_reference=file_identity(ROOT / "numerical-reference-draft-r1.json"),
    preserved_prior_generator=file_identity(ROOT / "exact_vector_reference_draft_r1.py"),
    verified_ids=verified,
    limitation="Preparation only. Decimal cross-check is corroboration; exact rational midpoint decisions define reference rounding. Public type/null/nonfinite/identity/resource policy and runtime acceptance remain separate.",
)
with (ROOT / "numerical-reference-crosscheck-r1.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: result[key] for key in ("status", "cases", "manual_exact_field_controls", "oracle_intrinsic_controls")}))
