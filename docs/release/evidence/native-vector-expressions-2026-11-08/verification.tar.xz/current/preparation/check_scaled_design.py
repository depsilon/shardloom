"""Check the proposed normalized-mantissa formulas, not a native kernel.

Compare with exact rational radicands and the independently frozen reference.
Unbounded integers in this preparation are not a runtime dependency.
"""

import argparse
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("rounding_design", ROOT / "check_rounding_design.py")
ROUND = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ROUND)
U = Fraction(1, 1 << 53)
HALF_ETA = Fraction(1, 1 << 1075)
SIGN = 1 << 63
FRACTION_MASK = (1 << 52) - 1


def bits(value):
    return struct.unpack(">Q", struct.pack(">d", value))[0]


def value(raw):
    return struct.unpack(">d", struct.pack(">Q", raw))[0]


def accumulator_pair(exact):
    assert exact > 0
    magnitude = ROUND.scaled_integer(exact)
    high = magnitude.bit_length() - 1
    exponent = high - 2148
    significand = ROUND.nearest_integer(magnitude, high - 52)
    if significand == 1 << 53:
        significand >>= 1
        exponent += 1
    assert 1 << 52 <= significand < 1 << 53
    return value((1023 << 52) | (significand & FRACTION_MASK)), exponent


def component_pair(component):
    raw = bits(abs(component))
    exponent_bits = raw >> 52
    significand = raw & FRACTION_MASK
    if exponent_bits:
        significand |= 1 << 52
        scale = exponent_bits - 1075
    else:
        scale = -1074
    assert significand
    high = significand.bit_length() - 1
    return significand / (1 << high), scale + high


def scale_normal(ratio, exponent, negative):
    assert math.isfinite(ratio) and ratio > 0
    raw = bits(ratio)
    exponent_bits = raw >> 52
    assert 0 < exponent_bits < 2047
    significand = (raw & FRACTION_MASK) | (1 << 52)
    scale = exponent_bits - 1075 + exponent
    if scale + 52 >= -1022:
        result = ROUND.encode(significand, scale)
    else:
        result = ROUND.encode(ROUND.nearest_integer(significand, -1074 - scale), -1074)
    return result | (SIGN if negative else 0)


def cosine(dot, left_square, right_square):
    if not left_square or not right_square:
        return None
    if not dot:
        return 0
    left_m, left_e = accumulator_pair(left_square)
    right_m, right_e = accumulator_pair(right_square)
    dot_m, dot_e = accumulator_pair(abs(dot))
    denominator_e, parity = divmod(left_e + right_e, 2)
    denominator = math.sqrt((left_m * right_m) * (2.0 if parity else 1.0))
    result = scale_normal(dot_m / denominator, dot_e - denominator_e, dot < 0)
    if abs(value(result)) > 1.0:
        result = bits(-1.0 if dot < 0 else 1.0)
    return result


def normalize(component, square):
    if not square:
        return None
    if component == 0.0:
        return bits(component)
    square_m, square_e = accumulator_pair(square)
    denominator_e, parity = divmod(square_e, 2)
    denominator = math.sqrt(square_m * (2.0 if parity else 1.0))
    component_m, component_e = component_pair(component)
    return scale_normal(component_m / denominator, component_e - denominator_e,
                        bool(bits(component) & SIGN))


def check_bound(actual_bits, radicand, negative, factor):
    actual = value(actual_bits)
    assert math.isfinite(actual)
    assert bool(actual_bits & SIGN) == negative
    absolute = Fraction.from_float(abs(actual))
    lower = max(Fraction(), (absolute - HALF_ETA) / (1 + factor * U))
    upper = (absolute + HALF_ETA) / (1 - factor * U)
    assert lower * lower <= radicand <= upper * upper, (actual_bits, factor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), "preserve prior observations"
    rows = json.loads((ROOT / "numerical-reference-draft-r2.json").read_bytes())["cases"]
    cosine_count = component_count = undefined = 0
    maximum_cosine_ulp = maximum_component_ulp = 0
    for row in rows:
        left_float = [ROUND.REFERENCE.to_float(row["left_width"], int(raw, 16)) for raw in row["left"]]
        right_float = [ROUND.REFERENCE.to_float(row["right_width"], int(raw, 16)) for raw in row["right"]]
        left = [Fraction.from_float(component) for component in left_float]
        right = [Fraction.from_float(component) for component in right_float]
        dot = sum((a * b for a, b in zip(left, right)), Fraction())
        square_left = sum((a * a for a in left), Fraction())
        square_right = sum((a * a for a in right), Fraction())
        computed = cosine(dot, square_left, square_right)
        expected = row["expected"]["cosine"]
        if computed is None:
            assert expected is None
            undefined += 1
        else:
            assert expected is not None
            check_bound(computed, dot * dot / (square_left * square_right), dot < 0, 5)
            difference = abs(computed - int(expected, 16))
            assert difference <= 8, (row["id"], "cosine", difference)
            maximum_cosine_ulp = max(maximum_cosine_ulp, difference)
            cosine_count += 1
        if not square_left:
            assert row["expected"]["normalized_left"] is None
            undefined += 1
            continue
        for component, exact, expected in zip(left_float, left, row["expected"]["normalized_left"]):
            computed = normalize(component, square_left)
            check_bound(computed, exact * exact / square_left, bool(bits(component) & SIGN), 3)
            difference = abs(computed - int(expected, 16))
            assert difference <= 4, (row["id"], "component", difference)
            maximum_component_ulp = max(maximum_component_ulp, difference)
            component_count += 1
    sources = (Path(__file__).name, "check_rounding_design.py", "exact_vector_reference.py",
               "numerical-reference-draft-r2.json", "numerical-bound-derivation.md",
               "selected-contract-r1.md", "selected-contract-admission-completion-r2.md")
    report = {
        "status": "passed_design_model_only",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "native_engine_executed": False,
        "runtime_implementation_verified": False,
        "reference_cases": len(rows),
        "cosine_exact_bound_checks": cosine_count,
        "normalization_exact_bound_checks": component_count,
        "undefined_checks": undefined,
        "corpus_maximum_cosine_ulp": maximum_cosine_ulp,
        "corpus_maximum_normalization_ulp": maximum_component_ulp,
        "ulp_observations_are_not_universal_bounds": True,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
