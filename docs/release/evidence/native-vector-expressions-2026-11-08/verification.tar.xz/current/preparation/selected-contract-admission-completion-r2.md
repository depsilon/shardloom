# Selected vector contract: explicit admission completion

Prepared before any vector kernel implementation or execution, against clean
merged `d29bff42c`. Apply this with the frozen `selected-contract-r1.md`; preserve
the original preparation and reference bytes. This resolves the word "dense"
in inspector/selection signatures and the existing decoded-reference boundary.

- A dense vector admitted by this family is a List or FixedSizeList whose direct
  child is F16, F32 or F64, or the already admitted dense embedding extension.
  This applies to `VECTOR_DIMENSION`, `VECTOR_VALUES`, `VECTOR_ELEMENT` and
  `VECTOR_SLICE` as well as arithmetic. A nested list/multi-vector collection,
  integer/Boolean/decimal/text list, tensor, opaque extension or scalar is not
  implicitly a dense vector. Integer index and slice controls remain admitted
  across all existing signed and unsigned widths. `VECTOR_DIMENSION` additionally
  admits the explicitly listed sparse and quantized extensions.
- `TENSOR_SHAPE` accepts the existing fixed/variable tensor types with their
  currently admitted component types. It inspects shape rather than narrowing
  component-type admission to floating values.
- Contextual F64 inference for an empty or all-null literal ARRAY applies only
  at a dense-vector argument position. It never converts an integer-list column,
  tensor argument, index, slice bound or layout control. Existing ordinary ARRAY
  inference and limits for nonliteral expression construction remain unchanged.
- All ten functions use the shared native function registry and native array
  execution. Mark their **decoded reference evaluator** support as false until
  that separate evaluator implements their full declared types and semantics.
  Native execution and the independent Fraction/bit reference are the acceptance
  paths. This is the existing temporal-family discovery convention; it does not
  authorize any execution fallback or reduction of SQL/Python coverage.

Required additional admission controls: each selection/inspection dense position
refuses integer, Boolean, decimal, text, scalar and nested-list inputs; arithmetic
also refuses sparse, quantized and tensors; tensor shape accepts integer/Boolean
tensor components. Empty/all-null literal dense arguments succeed with the
contextual type, whereas integer-valued literals remain unadmitted. Run these
through native binding and both public declaration paths, including empty input
plans, before claiming acceptance.
