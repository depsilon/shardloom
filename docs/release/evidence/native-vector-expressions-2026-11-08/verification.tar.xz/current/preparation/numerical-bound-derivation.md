# Finite vector numerical contract: design derivation

Preparation only, November 8. This derives bounds for a specified candidate
algorithm; it does not assert that a native kernel implements that algorithm.
Public admission, error behavior and implementation acceptance remain separate.

Let `u = 2^-53`, and let `eta = 2^-1074` be the minimum positive binary64
subnormal. All finite inputs first widen exactly from F16/F32/F64. Use integer
products and signed fixed-size accumulators for the exact dot `D`, norm squares
`A` and `B`, and squared distance. The accumulator capacity and exact square-root
rounding derivation are recorded in the provider preparation note. The dot,
norm and L2-distance proposal is one nearest-even binary64 rounding of the exact
real result, including the true overflow boundary. This proposal still needs a
native implementation and proof tests.

For cosine and normalized components, do not convert the full dot or norm to a
binary64 result before division. Instead represent each nonzero positive exact
accumulator as `m * 2^e`, with `1 <= m < 2`, round only its mantissa to binary64,
and carry its exponent separately. Renormalize a rounded mantissa of two by
incrementing the exponent. That mantissa rounding has relative error at most
`u`, independent of cancellation in the original exact sum. A finite original
component's normalized mantissa is exact because it already has at most 53
significand bits.

All intermediate mantissas below are normal finite values. Powers of two for
parity adjustments are exact. Multiplication, division and square root have
one rounding to nearest. The installed Rust 1.99.0 standard-library source
documents correctly rounded `sqrt` at
`/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/lib/rustlib/src/rust/library/std/src/num/f64.rs:360`.
The workspace declares Rust 1.96 as its minimum; local 1.96 source/docs were not
available in this inspection, so future feature/MSRV compilation and numerical
tests remain required. No implementation code was copied from the Rust source.

## Normalization

For `A = mA * 2^eA`, split `eA = 2*q + p`, with `p` either zero or one. Integer
division must round down, including negative exponents. Compute
`r = sqrt(round(mA) * 2^p)`, divide the exact component mantissa by `r`, then
apply the component's remaining power of two with a single final rounding only
if the output becomes subnormal. Avoid an intermediate subnormal scaling step.

Before that final scaling, the computed/exact ratio is between
`(1-u)/(1+u)^(3/2)` and `(1+u)/(1-u)^(3/2)`. For this `u`, these lie strictly
inside `[1-3*u, 1+3*u]`. The two inequalities can be checked with exact rational
arithmetic after squaring positive quantities:

- `(1-u)^2 > (1-3*u)^2 * (1+u)^3`
- `(1+u)^2 < (1+3*u)^2 * (1-u)^3`

Thus for a finite, nonzero-norm input and true component `y`, the candidate
guarantee is `abs(computed-y) <= 3*u*abs(y) + eta/2`. Normal scaling introduces
no additional rounding; a final subnormal conversion contributes at most
`eta/2`. Original zero-component signs are retained. Whole-vector zero norms
are a separately declared undefined case.

## Cosine

For nonzero norm squares, compute the rounded product of their rounded
mantissas, multiply by the exact parity factor of two, then take its square
root. Divide the rounded dot mantissa by that denominator, and finally apply
the separately retained dot-minus-denominator exponent. The mantissa division
is normal even when the full dot would underflow or either norm would overflow.

The computed/exact ratio is between
`(1-u)^2/(1+u)^(5/2)` and `(1+u)^2/(1-u)^(5/2)`. These lie strictly inside
`[1-5*u, 1+5*u]`, checked after squaring as:

- `(1-u)^4 > (1-5*u)^2 * (1+u)^5`
- `(1+u)^4 < (1+5*u)^2 * (1-u)^5`

The candidate guarantee is therefore
`abs(computed-y) <= 5*u*abs(y) + eta/2`. An exact zero dot produces positive
zero. A negative nonzero dot that underflows retains negative zero. Clamping a
finite result to `[-1,1]` cannot increase error because the exact finite cosine
lies in that interval. Nonfinite operands and zero norms are separate semantic
cases and are outside this error derivation.

## Acceptance implications

The exact-rational reference already defines correctly rounded outputs for
all four scalar operations and every normalized component. Its 270 cases and
independent Decimal corroboration are preparation evidence only. Once the
algorithm is frozen, compare native results against the exact mathematical
inequalities as well as convenient bit-distance screens (candidate screens:
8 ULP cosine, 4 ULP normalization). Do not present a corpus bit-distance bound
as an independently proved universal bound. Check sign and exceptional-result
classification separately, so an error allowance cannot hide NaN, wrong-signed
zero, a spurious infinity or an unintended null.

An exact inequality check need not approximate an irrational reference. If
`y = sqrt(rational)` and a finite positive reported result is `r`, the bound
`abs(r-y) <= c*u*y + eta/2` is equivalent to
`max(0, (r-eta/2)/(1+c*u)) <= y <= (r+eta/2)/(1-c*u)`.
Square the nonnegative rational endpoints and compare with the exact rational
radicand. Apply sign separately. This test is independent of the native
mantissa/exponent algorithm and does not need a general big-number runtime.
