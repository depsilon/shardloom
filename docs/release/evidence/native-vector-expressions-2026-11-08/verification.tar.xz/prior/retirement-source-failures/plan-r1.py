"""Retire exact closed provider intermediates after hosted acceptance."""
import argparse
import difflib
import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PRIOR = OUT.parent / 'vector-representations-2026-11-07'
DEPENDENCY = OUT.parent / 'dependency-maintenance-2026-11-07'
PACKET = ROOT / 'docs/release/evidence/native-provider-upgrade-2026-11-08'
TARGET = OUT / 'provider-retirement-r1'
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retirement_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.E = OUT.parent
ARCHIVED_METADATA_ROOTS = (
    'provenance-refresh-proposal-r1', 'provenance-refresh-proposal-r2',
    'provider-current-provenance-r1', 'registry-notice-inventory-r1',
    'registry-notice-proposal-r1',
)
COLLECTION_MANIFESTS = ('source-collection-r1/manifest.json',
                        'source-collection-r1/corrected/manifest.json')


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=base.sha(path))


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


def preparation():
    value = read(OUT / 'delivery-acceptance-r2.json')
    assert value['status'] == 'passed' and value['runtime_sources_match_build']
    prior = read(PRIOR / 'vector-closeout-r1.json')
    assert prior['status'] == 'complete' and prior['merge_commit'] == value['base']
    return value


def collected_sources():
    rows = []
    for relative in COLLECTION_MANIFESTS:
        manifest = OUT / relative
        for row in read(manifest)['results']:
            if row['status'] != 'passed':
                continue
            archive = manifest.parent / row['archive']['path']
            assert archive.is_relative_to(OUT / 'source-collection-r1')
            rows.append((archive, archive.parent / 'source', row))
    return rows


def roots():
    result = {
        str(PRIOR / 'runtime-r2/shardloom'): 'Superseded vector CLI; installed-tested provider CLI retained.',
        str(PRIOR / 'runtime-r2/lib_native.dylib'): 'Superseded vector library; installed-tested provider library retained.',
        str(PRIOR / 'installed-proof-r1/dist'): 'Superseded vector wheel; installed-tested provider wheel retained.',
        str(DEPENDENCY / 'runtime-r1'): 'Completed pre-provider dependency comparison; frozen source, outcomes and tested replacement retained.',
        str(DEPENDENCY / 'installed-proof-r1/package'): 'Completed historical package staging; source and acceptance are in the nested compact packet.',
        str(DEPENDENCY / 'installed-proof-r1/venv'): 'Completed uninstalled historical proof environment; native source and locked wheelhouse retained.',
        str(DEPENDENCY / 'installed-proof-r1/dist'): 'Superseded dependency comparison wheel; installed-tested provider wheel retained.',
        str(DEPENDENCY / 'preparation-r1'): 'All historical preparation files and failures are byte-exact in the nested compact packet.',
        str(DEPENDENCY / 'source-blobs'): 'All historical source snapshots are byte-exact in the nested compact packet.',
        str(OUT / 'installed-proof-r1/package'): 'Completed package staging; committed source and installed-tested wheel retained.',
        str(OUT / 'installed-proof-r1/venv'): 'Completed uninstalled proof environment; locked wheelhouse retained.',
        str(OUT / 'final-packet-r2'): 'Byte-identical six-file temporary packet; committed portable evidence and final documentation binding retained.',
        str(OUT / 'dependency-baseline-packet-r2'): 'Byte-identical historical packet embedded in current portable evidence.',
        str(OUT / 'portable-archive-sources-r1'): 'Exact archive blobs and inventory embedded in current portable evidence.',
        str(OUT / 'standalone-dev-source-supplement-r1/archives'): 'Exact selected development archives embedded in current portable evidence.',
        str(OUT / 'source-blobs'): 'Every snapshot matches retained packet, Git or helper bytes; exact coverage is recorded and all bytes are rehashed before retirement.',
        str(OUT / 'final-packet-r1/verification.tar.xz'): 'Failed first container; every original member byte is preserved in the accepted packet. Its original report, verifier and failed outcome remain.',
        str(OUT / 'dependency-baseline-packet-r1/verification.tar.xz'): 'Failed first historical container; every member is preserved in the corrected nested packet. Original report, verifier and failure remain.',
        str(OUT / 'vortex-arrow-preparation-r1/provider'): 'Exact initial upstream extraction; retained crate archive, member manifest and upstream license regenerate all 34 files.',
        str(OUT / 'parquet-fixture-preparation-r1/sources'): 'Every selected fixture byte remains in compact evidence/current source; pinned Git commit and selected blob identities are retained.',
        str(OUT / 'parquet-fixture-preparation-r1/parquet-testing.tar.gz'): 'Completed download container; pinned Git source, archive identity, selection script and all selected fixture bytes are retained.',
        str(OUT / 'parquet-fixture-preparation-r1/arrow-testing.tar.gz'): 'Completed download container; pinned Git source, archive identity, selection script and all selected fixture bytes are retained.',
        str(OUT / 'rebase-r2/vendor'): 'Superseded three-way preparation. Exact original inputs, generated result hashes, original conflict receipt and accepted final Git source remain.',
        str(OUT / 'rebase-r2/runend-port'): 'Superseded conflict preparation; original input hashes, result hash, generator and accepted final RunEnd port remain.',
        str(OUT / 'rebase-r2/upstream-diffs'): 'Deterministic diffs are independently regenerated from the exact collected source bytes before retirement; manifests and generator remain.',
    }
    result.update({str(OUT / name): 'Every metadata/legal-file byte is already preserved in the committed compact packet.'
                   for name in ARCHIVED_METADATA_ROOTS})
    for archive, source, _ in collected_sources():
        result[str(archive)] = 'Completed published-source download; immutable URL, full archive checksum and original member identities remain in the retained manifest.'
        result[str(source)] = 'Exact extraction from the checksum-pinned published archive; full member identities and generator retained. API responses and original failed observations remain.'
    paths = [Path(name) for name in result]
    assert all(path.exists() and not path.is_symlink() and path.resolve() == path for path in paths)
    assert all(any(path.is_relative_to(root) for root in (OUT, PRIOR, DEPENDENCY)) for path in paths)
    assert not any(a != b and a.is_relative_to(b) for a in paths for b in paths)
    return result


def retained():
    acceptance = read(PACKET / 'acceptance.json')
    installed = read(OUT / 'installed-proof-r1/report.json')
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['integration'] == acceptance['installed_package']
    assert installed['integration']['status'] == 'passed' and installed['integration']['tests'] > 0
    assert all(installed['integration'][key] == 0 for key in ('failures', 'errors', 'skipped'))
    prep = preparation()
    for filename, expected in prep['packet_files'].items():
        assert identity(PACKET / filename) == expected
    files = list(sorted(PACKET.iterdir()))
    assert all(path.is_file() and not path.is_symlink() for path in files)
    for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
        path = OUT / 'runtime-r1' / name
        assert base.sha(path) == installed['integrity'][key] == acceptance['runtime_and_wheel'][key]
        files.append(path)
    wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
    assert base.sha(wheel) == installed['integrity']['wheel_sha256'] == acceptance['runtime_and_wheel']['wheel_sha256']
    files += [wheel, OUT / 'installed-proof-r1/report.json', OUT / 'delivery-acceptance-r1.json',
              OUT / 'delivery-acceptance-r2.json', PRIOR / 'vector-closeout-r1.json',
              OUT / 'precommit-whitespace-r1.json', OUT / 'provider-ci-docs-r2.json',
              OUT / 'pr1670-release-scripts-job-128767154452-r1.json']
    duplicates_path = OUT / 'retirement-source-duplicates-r1.json'
    files.append(duplicates_path)
    for row in read(duplicates_path)['matched']:
        reference = row['retained_reference']
        if reference.startswith('/'):
            files.append(Path(reference))
    return {str(path): identity(path) for path in files}


def inputs():
    previous = read(PRIOR / 'vector-retirement-r1/plan.json')
    path = PRIOR / 'vector-retirement-r1/manifest.json.xz'
    assert base.sha(path) == previous['manifest_sha256']
    expected = json.loads(lzma.decompress(path.read_bytes()))['input_generations']
    assert expected
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def source_preparations(members, archived_identities):
    # Reports are retained byte-for-byte; neither the original source-collection
    # failures nor conflicted three-way results are reclassified as acceptance.
    metadata = [*COLLECTION_MANIFESTS, 'rebase-r2/preparation.json',
        'parquet-fixture-preparation-r1/manifest.json', 'vortex-arrow-preparation-r1/inventory.json',
        'tools/prepare_provider_rebase_r2.py', 'tools/prepare_parquet_fixtures.py',
        'source-collection-r1/collect_sources.py']
    for name in metadata:
        assert identity(OUT / name) == members['observations/provider/' + name], name
    corrected = {}
    for archive, source, row in collected_sources():
        assert identity(archive) == {key: row['archive'][key] for key in ('bytes', 'sha256')}
        expected = {item['path']: {key: item[key] for key in ('bytes', 'sha256')}
                    for item in row['source_inventory']['members'] if item['type'] == 'file'}
        actual = {}
        for path in source.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():
                actual[path.relative_to(source).as_posix()] = identity(path)
        assert actual == expected, str(source)
        if archive.is_relative_to(OUT / 'source-collection-r1/corrected'):
            corrected[(row['role'], row['name'])] = source / (row['name'] + '-' + row['version'])
    preparation_record = read(OUT / 'rebase-r2/preparation.json')
    expected_diffs = {}
    for provider in preparation_record['providers']:
        name = provider['provider']
        old, new = corrected[('baseline', name)], corrected[('candidate', name)]
        old_files = {p.relative_to(old).as_posix(): p.read_bytes() for p in old.rglob('*') if p.is_file()}
        new_files = {p.relative_to(new).as_posix(): p.read_bytes() for p in new.rglob('*') if p.is_file()}
        expected = {path: hashlib.sha256(raw).hexdigest() for path, raw in new_files.items()
                    if Path(path).name != 'Cargo.lock'}
        for change in provider['patches']:
            if change['status'] in {'three_way_clean', 'conflict'}:
                expected[change['path']] = change['result_sha256']
            elif change['status'] == 'retained_local_addition':
                expected[change['path']] = change['local_sha256']
            else:
                raise AssertionError('Inspect unexpected rebase status: ' + change['status'])
        stage = OUT / 'rebase-r2/vendor' / name
        assert {p.relative_to(stage).as_posix(): base.sha(p) for p in stage.rglob('*') if p.is_file()} == expected
        for path in old_files.keys() | new_files.keys():
            before, after = old_files.get(path, b''), new_files.get(path, b'')
            if before == after or not (path.endswith('.rs') or path in {'Cargo.toml', 'Cargo.toml.orig'}):
                continue
            patch = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
                after.decode().splitlines(keepends=True),
                fromfile=name + '-' + provider['old_version'] + '/' + path,
                tofile=name + '-' + provider['candidate_version'] + '/' + path))
            expected_diffs[name + '/' + path + '.diff'] = hashlib.sha256(patch.encode()).hexdigest()
    diff_root = OUT / 'rebase-r2/upstream-diffs'
    assert {p.relative_to(diff_root).as_posix(): base.sha(p) for p in diff_root.rglob('*') if p.is_file()} == expected_diffs
    runend = OUT / 'rebase-r2/runend-port'
    assert {p.name for p in runend.iterdir()} == {'compress.rs'}
    assert base.sha(runend / 'compress.rs') == preparation_record['runend_port']['result_sha256']
    fixture_root = OUT / 'parquet-fixture-preparation-r1'
    fixture_files = {}
    for source in read(fixture_root / 'manifest.json')['sources']:
        name = source['repository'].split('/')[-1]
        assert identity(fixture_root / (name + '.tar.gz')) == dict(
            bytes=source['archive_bytes'], sha256=source['archive_sha256'])
        for row in source['files']:
            expected = {key: row[key] for key in ('bytes', 'sha256')}
            path = fixture_root / 'sources' / name / row['path']
            assert identity(path) == expected
            assert (expected['bytes'], expected['sha256']) in archived_identities, path
            fixture_files[str(path)] = expected
    assert {str(p) for p in (fixture_root / 'sources').rglob('*') if p.is_file()} == set(fixture_files)
    arrow_root = OUT / 'vortex-arrow-preparation-r1'
    arrow = read(arrow_root / 'inventory.json')
    assert members['crate-blobs/' + arrow['archive']['sha256'] + '.crate'] == {
        key: arrow['archive'][key] for key in ('bytes', 'sha256')}
    assert {str(p) for p in (arrow_root / 'provider').rglob('*') if p.is_file()} == {
        str(arrow_root / row['path']) for row in arrow['extraction']['files']}
    for row in arrow['extraction']['files']:
        assert identity(arrow_root / row['path']) == {key: row[key] for key in ('bytes', 'sha256')}


def failed_container(path, retained_members):
    original = read(path.parent / 'acceptance.json')
    assert base.sha(path) == original['archive_sha256']
    expected = {row['path']: {k: row[k] for k in ('bytes', 'sha256')} for row in original['members']}
    assert all((row['bytes'], row['sha256']) in retained_members for row in expected.values())
    observed = set()
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in observed
            raw = archive.extractfile(member).read()
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected[member.name]
            observed.add(member.name)
    assert observed == set(expected)


def preserved_observations():
    acceptance = read(PACKET / 'acceptance.json')
    assert base.sha(PACKET / 'verification.tar.xz') == acceptance['archive_sha256']
    members = {row['path']: {k: row[k] for k in ('bytes', 'sha256')} for row in acceptance['members']}
    with tarfile.open(PACKET / 'verification.tar.xz', 'r:xz') as archive:
        for path in sorted((OUT / 'dependency-baseline-packet-r2').iterdir()):
            assert archive.extractfile('dependency-baseline/' + path.name).read() == path.read_bytes()
    historical = read(OUT / 'dependency-baseline-packet-r2/acceptance.json')
    assert historical['status'] == 'local_acceptance_passed'
    historical_members = {row['path']: {k: row[k] for k in ('bytes', 'sha256')} for row in historical['members']}
    for directory in ('preparation-r1', 'source-blobs'):
        for path in sorted((DEPENDENCY / directory).rglob('*')):
            assert not path.is_symlink(), path
            if path.is_file():
                assert identity(path) == historical_members['current/' + path.relative_to(DEPENDENCY).as_posix()], path
    old_install = read(DEPENDENCY / 'installed-proof-r1/report.json')
    assert old_install['status'] == old_install['uninstall_status'] == 'passed'
    assert old_install['integration'] == historical['installed_package']
    assert {p.name for p in (DEPENDENCY / 'runtime-r1').iterdir()} == {'shardloom', 'lib_native.dylib'}
    for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
        assert base.sha(DEPENDENCY / 'runtime-r1' / name) == old_install['integrity'][key] == historical[key]
    assert {p.name for p in (DEPENDENCY / 'installed-proof-r1/dist').iterdir()} == {old_install['integrity']['wheel']}
    old_wheel = DEPENDENCY / 'installed-proof-r1/dist' / old_install['integrity']['wheel']
    assert base.sha(old_wheel) == old_install['integrity']['wheel_sha256'] == historical['installed_wheel_sha256']
    for directory, prefix in [('portable-archive-sources-r1/blobs', 'crate-blobs/')]:
        for path in sorted((OUT / directory).iterdir()):
            assert identity(path) == members[prefix + path.name], path
    inventory = OUT / 'portable-archive-sources-r1/inventory.json'
    assert identity(inventory) == members['observations/provider/portable-archive-sources-r1/inventory.json']
    archived_identities = {(row['bytes'], row['sha256']) for row in acceptance['members']}
    source_preparations(members, archived_identities)
    failed_container(OUT / 'final-packet-r1/verification.tar.xz', archived_identities)
    failed_container(OUT / 'dependency-baseline-packet-r1/verification.tar.xz',
                     {(row['bytes'], row['sha256']) for row in historical['members']})
    for directory in ARCHIVED_METADATA_ROOTS:
        for path in sorted((OUT / directory).rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                entry = identity(path)
                assert (entry['bytes'], entry['sha256']) in archived_identities, path
    for path in sorted((OUT / 'standalone-dev-source-supplement-r1/archives').iterdir()):
        entry = identity(path)
        assert (entry['bytes'], entry['sha256']) in archived_identities, path
    assert {p.name for p in (OUT / 'final-packet-r2').iterdir()} == {
        'acceptance.json', 'verification.tar.xz', 'verify.py', 'verify_sources.py',
        'verify_standalone.py', 'corruption-controls.json'}
    for path in (OUT / 'final-packet-r2').iterdir():
        assert path.read_bytes() == (PACKET / path.name).read_bytes()
    duplicates = read(OUT / 'retirement-source-duplicates-r1.json')
    assert duplicates['status'] == 'covered' and not duplicates['missing']
    assert duplicates['packet_acceptance_sha256'] == base.sha(PACKET / 'acceptance.json')
    assert {str(p) for p in (OUT / 'source-blobs').iterdir()} == {r['path'] for r in duplicates['matched']}
    for row in duplicates['matched']:
        path = Path(row['path'])
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert path.parent == OUT / 'source-blobs' and identity(path) == expected
        reference = row['retained_reference']
        if reference.startswith('packet-member:'):
            assert members[reference.removeprefix('packet-member:')] == expected
        elif reference.startswith('git:'):
            _, revision, name = reference.split(':', 2)
            assert revision in {'HEAD', read(OUT / 'delivery-acceptance-r1.json')['head']}
            assert name in read(PACKET / 'documentation.json')['changes']
            raw = subprocess.check_output(['git', 'show', revision + ':' + name], cwd=ROOT)
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected
        else:
            retained_path = Path(reference)
            assert (retained_path.parent in {PACKET, OUT / 'tools'}
                    or retained_path == OUT / 'documentation-binding-delivery-r1.json')
            assert identity(retained_path) == expected
    controls = read(PACKET / 'corruption-controls.json')
    assert controls['status'] == controls['receipt']['status'] == 'passed'
    assert controls['receipt']['positive_controls'] == 2 and controls['receipt']['rejected_controls'] == 13
    old = read(PRIOR / 'vector-closeout-r1.json')
    for path, expected in old['retained_runtime_and_wheel'].items():
        assert identity(Path(path)) == expected
    prior_install = read(PRIOR / 'installed-proof-r1/report.json')
    assert {p.name for p in (PRIOR / 'installed-proof-r1/dist').iterdir()} == {prior_install['integrity']['wheel']}


def replay():
    subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-I',
        str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)


def plan():
    assert not TARGET.exists()
    assert shutil.disk_usage(OUT).free >= (12 << 30) + (8 << 20)
    prep = preparation()
    assert git('rev-parse', 'HEAD') == prep['head'] and not git('status', '--porcelain')
    selected = roots()
    preserved_observations()
    replay()
    kept, generations = retained(), inputs()
    rows = [row for name in sorted(selected) for row in base.inventory(Path(name))]
    assert len(rows) == len({row['path'] for row in rows})
    assert not (set(kept) | set(generations)).intersection(row['path'] for row in rows)
    base.closed(selected)
    for row in rows:
        base.unchanged(row)
    manifest = dict(roots=selected, entries=rows, retained=kept, input_generations=generations,
        accepted_head=prep['head'], accepted_tree=prep['tree'])
    TARGET.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode())
    assert len(raw) < 8 << 20
    assert shutil.disk_usage(OUT).free >= (12 << 30) + len(raw)
    (TARGET / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', head=prep['head'], tree=prep['tree'],
        roots=len(selected), entries=len(rows), regular_files=sum(row['kind'] == 'regular' for row in rows),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        manifest_sha256=base.sha(TARGET / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), deleted=False, payload_backup_created=False,
        retained_test_environment='The existing test wheelhouse and current compiler cache remain in use for the next queue unit.')
    (TARGET / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


def apply(main_path, pre_path):
    prep, main, pre = preparation(), read(main_path), read(pre_path)
    assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert main['pr'] == pre['pr'] and main['pr'] > 0 and main['pr_head'] == pre['head'] == prep['head']
    assert main['source_tree'] == pre['source_tree'] == prep['tree']
    assert main['premerge_sha256'] == base.sha(pre_path) and pre['tree_matches_synthetic']
    assert main['commit_verification']['verified'] is True
    assert git('rev-parse', 'HEAD') == main['source_commit'] and not git('status', '--porcelain')
    assert git('branch', '--show-current') == 'main'
    summary = read(TARGET / 'plan.json')
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(TARGET / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET / 'manifest.json.xz').read_bytes()))
    selected, rows = manifest['roots'], manifest['entries']
    assert manifest['accepted_head'] == prep['head'] and manifest['accepted_tree'] == prep['tree']
    assert roots() == selected and retained() == manifest['retained'] and inputs() == manifest['input_generations']
    preserved_observations()
    for _ in range(2):
        assert [row for name in sorted(selected) for row in base.inventory(Path(name))] == rows
        base.closed(selected)
    receipt = dict(status='running', removed=0, main=identity(main_path), premerge=identity(pre_path),
        prior_vector_closeout=identity(PRIOR / 'vector-closeout-r1.json'),
        accepted_head=prep['head'], accepted_tree=prep['tree'], manifest_sha256=summary['manifest_sha256'])
    assert not (TARGET / 'receipt.json').exists()
    try:
        for row in sorted(rows, key=lambda value: len(Path(value['path']).parts), reverse=True):
            path = Path(row['path'])
            base.unchanged(row, removing_children=row['kind'] == 'directory')
            path.rmdir() if row['kind'] == 'directory' else path.unlink()
            receipt['removed'] += 1
        assert all(not Path(name).exists() and not Path(name).is_symlink() for name in selected)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        replay()
        receipt.update(status='passed', retained_files_unchanged=True, input_generations_unchanged=True,
            portable_replay_after_retirement='passed', regular_files=summary['regular_files'],
            symlinks=summary['symlinks'], regular_bytes=summary['regular_bytes'],
            control_observations_preserved=True, storage_limits_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (TARGET / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    parser.add_argument('--main', type=Path)
    parser.add_argument('--pre', type=Path)
    args = parser.parse_args()
    if args.mode == 'plan':
        plan()
    else:
        assert args.main and args.pre
        apply(args.main, args.pre)
