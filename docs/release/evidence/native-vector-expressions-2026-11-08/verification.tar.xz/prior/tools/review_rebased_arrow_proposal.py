"""Record the changed Arrow proposal against its exact post-provider base."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
ORIGINAL = 'aa21283ee02fcf56bfee33bb011f4aaa3f354a9e'
HEAD = '06ed9e1f6c3381cf94e8a6fbddf9eb1395608ec6'
BASE = 'd29bff42c5b3aacf7a61463bf2c8f9cec2bdf216'


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, timeout=60)


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def apply_hunks(source, patch):
    original = source.decode().splitlines(keepends=True)
    lines = patch.splitlines(keepends=True)
    # GitHub omits the final patch newline; the source files both end with one.
    if lines and not lines[-1].endswith('\n'):
        lines[-1] += '\n'
    output, offset, position = [], 0, 0
    while position < len(lines):
        match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[position])
        assert match, lines[position]
        old_start, old_count, new_start, new_count = (
            int(match[1]), int(match[2] or 1), int(match[3]), int(match[4] or 1))
        start = old_start - 1 if old_count else old_start
        assert offset <= start <= len(original)
        output.extend(original[offset:start])
        offset = start
        assert len(output) == (new_start - 1 if new_count else new_start)
        removed = added = 0
        position += 1
        while position < len(lines) and not lines[position].startswith('@@ '):
            line = lines[position]
            assert line[:1] in (' ', '-', '+'), line
            if line[0] != '+':
                assert offset < len(original) and original[offset] == line[1:]
                offset += 1
                removed += 1
            if line[0] != '-':
                output.append(line[1:])
                added += 1
            position += 1
        assert (removed, added) == (old_count, new_count)
    output.extend(original[offset:])
    return ''.join(output).encode()


before_path = OUT / 'dependabot-pr1666-preclose-r1.json'
patch_path = OUT / 'dependabot-pr1666-rebased-patch-r1.json'
before = json.loads(before_path.read_bytes())
patch = json.loads(patch_path.read_bytes())
assert before['isError'] is patch['isError'] is False
pr = before['structuredContent']
assert pr['number'] == 1666 and pr['state'] == 'open' and not pr['merged']
assert pr['head_sha'] == HEAD and pr['base_sha'] == BASE and pr['base'] == 'main'
assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert git('rev-parse', 'FETCH_HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain').strip()
files = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
assert files == ['Cargo.lock', 'Cargo.toml']
patches = patch['structuredContent']['patches']
assert [row['filename'] for row in patches] == files
sources = {}
for row in patches:
    name = row['filename']
    diff = git('diff', '--no-ext-diff', '--unified=3', BASE, HEAD, '--', name)
    before_bytes = git('show', BASE + ':' + name)
    proposed_bytes = git('show', HEAD + ':' + name)
    assert apply_hunks(before_bytes, row['patch']) == proposed_bytes, name
    sources[name] = dict(base=identity(before_bytes), proposed=identity(proposed_bytes),
        diff=identity(diff), connector_patch_reconstructs_exact_proposed_bytes=True)

base_manifest = tomllib.loads(git('show', BASE + ':Cargo.toml').decode())
head_manifest = tomllib.loads(git('show', HEAD + ':Cargo.toml').decode())
changed = ['arrow-buffer', 'arrow-flight', 'arrow-pyarrow', 'arrow-schema']
expected = deepcopy(base_manifest)
for name in changed:
    value = expected['workspace']['dependencies'][name]
    if isinstance(value, str):
        assert value == '=59.3.2'
        expected['workspace']['dependencies'][name] = '=60.1.0'
    else:
        assert value['version'] == '=59.3.2'
        value['version'] = '=60.1.0'
assert head_manifest == expected
packages = tomllib.loads(git('show', HEAD + ':Cargo.lock').decode())['package']
families = {name: sorted({row['version'] for row in packages if row['name'] == name})
    for name in ('arrow-array', 'arrow-buffer', 'arrow-data', 'arrow-ipc', 'arrow-schema')}
assert all(versions == ['59.3.2', '60.1.0'] for versions in families.values())
native = next(row for row in packages if row['name'] == 'shardloom-vortex')
provider = next(row for row in packages if row['name'] == 'vortex-arrow')
assert {'arrow-array 59.3.2', 'arrow-data 59.3.2', 'arrow-ipc 59.3.2',
        'arrow-buffer 60.1.0', 'arrow-schema 60.1.0'} <= set(native['dependencies'])
assert {'arrow-array 59.3.2', 'arrow-buffer 59.3.2', 'arrow-schema 59.3.2'} <= set(provider['dependencies'])
report = dict(status='reviewed_deferral', observed_at=datetime.now(timezone.utc).isoformat(),
    pr=1666, original_head=ORIGINAL, observed_head=HEAD, observed_base=BASE,
    source_tree=git('rev-parse', HEAD + '^{tree}').decode().strip(),
    changed_files=files, changed_manifest_pins=changed, proposed_version='60.1.0',
    runtime_arrow_families=families, native_dependencies=native['dependencies'],
    vortex_arrow_dependencies=provider['dependencies'], source_identities=sources,
    disposition='deferred_coordinated_arrow_60',
    reason='The rebased proposal still mixes Arrow 59.3.2 arrays/data/IPC and Vortex providers with Arrow 60.1.0 buffers/schema/Flight/Python bindings. It does not port the native consumers or retained provider contracts. Keep the accepted coherent 59.3.2 graph; revisit Arrow 60 as a coordinated migration.',
    original_observation_preserved=True, proposal_executed=False,
    engine_source_or_dependency_changed=False, main_verification_still_required=True,
    prior_invocation=dict(status='environment_import_failure_before_review',
        interpreter='python3', error="ModuleNotFoundError: No module named 'tomllib'",
        retry_change='Use the already available Python 3.13 interpreter; no dependency installation.'),
    prior_observer_failure=dict(status='observer_diff_format_mismatch',
        reason='GitHub combines two nearby Cargo.lock hunks that local git separates. Exact hunk-text equality was not a valid byte-identity check.',
        correction='Validate every hunk range and context, then reconstruct exact proposed Git file bytes.'),
    sources={path.relative_to(OUT).as_posix(): identity(path.read_bytes())
             for path in (before_path, patch_path, Path(__file__),
                 OUT / 'tools/review_rebased_arrow_proposal_observer_r1.py',
                 OUT / 'dependabot-pr1666-rebased-review-observer-r1.json')})
with (OUT / 'dependabot-pr1666-rebased-review-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in
    ('status', 'observed_head', 'observed_base', 'runtime_arrow_families', 'disposition')}))
