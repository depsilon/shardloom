"""Adopt the accepted provider merge without modifying another worktree."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PRIOR = OUT.parent / 'vector-representations-2026-11-07/vector-closeout-r1.json'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', type=Path, required=True)
parser.add_argument('--merge-receipt', type=Path, required=True)
parser.add_argument('--acceptance', type=Path, required=True)
args = parser.parse_args()

def read(path):
    return json.loads(path.read_bytes())

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()

def worktrees():
    result = {}
    for block in git('worktree', 'list', '--porcelain').split('\n\n'):
        lines = block.splitlines()
        assert lines[0].startswith('worktree ')
        result[lines[0].removeprefix('worktree ')] = lines[1:]
    return result

def main_owners(inventory):
    return [path for path, lines in inventory.items() if 'branch refs/heads/main' in lines]

destination = OUT / 'provider-main-checkout-r1.json'
assert not destination.exists()
pre, prep, merged = read(args.pre), read(args.acceptance), read(args.merge_receipt)
prior = read(PRIOR)
assert merged.get('isError') is False and merged['structuredContent']['merged'] is True
new = merged['structuredContent']['sha']
old, head, tree = pre['base'], pre['head'], prep['tree']
assert all(re.fullmatch('[0-9a-f]{40}', value) for value in (new, old, head, tree))
record = dict(status='needs_attention', merge_commit=new, source_tree=tree,
              observed_at=datetime.now(timezone.utc).isoformat())
try:
    assert prep['status'] == 'passed' and prep['head'] == head and prep['base'] == old
    assert prep['runtime_sources_match_build']
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert pre['acceptance_sha256'] == hashlib.sha256(args.acceptance.read_bytes()).hexdigest()
    assert prior['status'] == 'complete' and prior['merge_commit'] == old
    for suffix in ('final-checks-r1', 'final-review-r1'):
        final = read(OUT / ('pr' + str(pre['pr']) + '-' + suffix + '.json'))
        assert final['status'] == 'passed' and final['head'] == head and final['base'] == old
    assert git('rev-parse', 'HEAD') == head
    assert git('branch', '--show-current') == 'codex/native-provider-upgrade'
    assert not git('status', '--porcelain')
    assert git('rev-parse', head + '^{tree}') == tree
    inventory = worktrees()
    assert not main_owners(inventory) and git('rev-parse', 'refs/heads/main') == old
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', 'main'], cwd=ROOT, check=True, timeout=90)
    assert git('rev-parse', 'origin/main') == new
    assert git('rev-parse', new + '^{tree}') == tree
    assert git('show', '-s', '--format=%P', new).split() == [old, head]
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/commits/' + new], cwd=ROOT, timeout=50)
    assert len(raw) < 8 << 20
    commit = json.loads(raw)
    assert commit['sha'] == new and commit['commit']['tree']['sha'] == tree
    assert [row['sha'] for row in commit['parents']] == [old, head]
    assert commit['commit']['verification']['verified'] is True
    record.update(signed_commit=commit, parents=[old, head], worktrees_before=inventory,
        prior_vector_closeout_sha256=hashlib.sha256(PRIOR.read_bytes()).hexdigest())
    assert worktrees() == inventory and not git('status', '--porcelain')
    subprocess.run(['git', 'update-ref', 'refs/heads/main', new, old], cwd=ROOT, check=True, timeout=90)
    subprocess.run(['git', 'switch', 'main'], cwd=ROOT, check=True, timeout=90)
    after = worktrees()
    assert main_owners(after) == [str(ROOT)]
    assert {path: rows for path, rows in inventory.items() if path != str(ROOT)} == {
        path: rows for path, rows in after.items() if path != str(ROOT)}
    assert git('rev-parse', 'HEAD') == new and git('rev-parse', 'HEAD^{tree}') == tree
    assert not git('status', '--porcelain')
    record.update(status='passed', active_worktree=str(ROOT), main_branch='main',
        worktrees_after=after, other_worktree_refs_unchanged=True,
        active_worktree_clean=True, accepted_file_tree_unchanged=True)
except BaseException as error:
    record['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with destination.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'merge_commit', 'source_tree', 'active_worktree')}))
