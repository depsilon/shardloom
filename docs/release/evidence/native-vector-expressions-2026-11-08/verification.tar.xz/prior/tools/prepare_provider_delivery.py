"""Bind the committed provider delivery to its frozen source and installed runtime."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-provider-upgrade-2026-11-08'
PRIOR = OUT.parent / 'vector-representations-2026-11-07/vector-closeout-r1.json'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

assert not git('status', '--porcelain')
assert git('branch', '--show-current') == 'codex/native-provider-upgrade'
head = git('rev-parse', 'HEAD')
report, prior = read(PACKET / 'acceptance.json'), read(PRIOR)
assert report['status'] == 'local_acceptance_passed' and prior['status'] == 'complete'
base = report['accepted_base']
assert base == prior['merge_commit']
assert git('show', '-s', '--format=%P', head).split() == [report['source_head']]
subprocess.run(['git', 'merge-base', '--is-ancestor', base, report['source_head']], cwd=ROOT, check=True)
subprocess.run(['/opt/homebrew/bin/python3.13', '-B', str(PACKET / 'verify.py'),
                '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)
packet_names = {'acceptance.json', 'verification.tar.xz', 'verify.py', 'verify_sources.py',
    'verify_standalone.py', 'corruption-controls.json', 'documentation.json', 'README.md'}
assert {p.name for p in PACKET.iterdir()} == packet_names
controls = read(PACKET / 'corruption-controls.json')
assert controls['status'] == controls['receipt']['status'] == 'passed'
assert controls['receipt']['positive_controls'] == 2 and controls['receipt']['rejected_controls'] == 13
for name, expected in controls['receipt']['original_packet'].items():
    assert identity(PACKET / name) == expected
docs_path = OUT / 'provider-final-docs-r1.json'
docs = read(docs_path)
assert docs['status'] == 'passed' and docs['returncode'] == 0
assert docs['process_group_drained'] and docs['direct_child_reaped']
assert docs['head'] == report['source_head'] and docs['base'] == base
expected = docs['changed_source_inventory']
assert set(git('diff', '--no-renames', '--name-only', base, head).splitlines()) == set(expected)
for name, entry in expected.items():
    if entry.get('absent'):
        assert not (ROOT / name).exists() and not (ROOT / name).is_symlink(), name
    elif 'symlink' in entry:
        assert (ROOT / name).is_symlink() and str((ROOT / name).readlink()) == entry['symlink'], name
    else:
        assert identity(ROOT / name) == entry, name
installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == installed['integration']['status'] == 'passed'
assert installed['integration'] == report['installed_package']
assert all(installed['integration'][key] == 0 for key in ('failures', 'errors', 'skipped'))
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
for path, key in [(OUT / 'runtime-r1/shardloom', 'cli_sha256'),
                  (OUT / 'runtime-r1/lib_native.dylib', 'native_library_sha256'),
                  (wheel, 'wheel_sha256')]:
    assert identity(path)['sha256'] == installed['integrity'][key] == report['runtime_and_wheel'][key]
with zipfile.ZipFile(wheel) as archive:
    for name, expected_source in report['validation_source_snapshot'].items():
        if name.startswith('python/src/shardloom/') and 'bytes' in expected_source:
            raw = archive.read(name.removeprefix('python/src/'))
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected_source, name
workflow_paths = set(git('diff', '--name-only', base, head, '--', '.github/workflows').splitlines())
assert workflow_paths == {'.github/workflows/codeql-analysis.yml', '.github/workflows/scorecard.yml'}
assert not git('diff', '--numstat', base, head, '--', '.github/workflows/ci.yml')
workflows = {}
for name in sorted(workflow_paths):
    expected_source = report['validation_source_snapshot'][name]
    assert identity(ROOT / name) == expected_source
    workflows[name] = dict(blob=git('rev-parse', head + ':' + name), source=expected_source)
result = dict(status='passed', head=head, tree=git('rev-parse', head + '^{tree}'), base=base,
    base_branch='main', runtime_sources_match_build=True,
    runtime_source_proof='Complete source snapshot, current graph and all compiled inputs match the accepted provider checks; only five explicitly allowed documentation paths may carry final evidence wording. The wheel contains the same Python source and frozen native artifacts.',
    ci_workflow_blob=git('rev-parse', head + ':.github/workflows/ci.yml'), reviewed_workflow_changes=workflows,
    acceptance=identity(PACKET / 'acceptance.json'), archive=identity(PACKET / 'verification.tar.xz'),
    verifier=identity(PACKET / 'verify.py'), installed_package=report['installed_package'],
    corruption_controls=identity(PACKET / 'corruption-controls.json'),
    packet_files={name: identity(PACKET / name) for name in sorted(packet_names)},
    final_documentation_checks=identity(docs_path), changed_files=sorted(expected),
    prior_vector_closeout=identity(PRIOR), publication_attempted=False, performance_claim=False)
with (OUT / 'delivery-acceptance-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'head', 'tree', 'installed_package')}))
