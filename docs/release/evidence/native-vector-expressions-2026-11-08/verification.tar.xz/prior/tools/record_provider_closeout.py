"""Bind provider acceptance, exact hosted integration, proposals and retirement."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = ROOT / 'docs/release/evidence/native-provider-upgrade-2026-11-08'
PRIOR = OUT.parent / 'vector-representations-2026-11-07/vector-closeout-r1.json'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', required=True, type=Path)
parser.add_argument('--main', required=True, type=Path)
parser.add_argument('--reconciliation', required=True, type=Path)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size,
                    sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT,
                                   text=True, timeout=90).strip()


destination = OUT / 'provider-closeout-r1.json'
assert not destination.exists()
prep_path = OUT / 'delivery-acceptance-r2.json'
prep, pre, main = read(prep_path), read(args.pre), read(args.main)
assert prep['status'] == 'passed' and prep['runtime_sources_match_build']
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
assert main['pr'] == pre['pr'] == 1670
assert main['pr_head'] == pre['head'] == prep['head']
assert main['source_tree'] == pre['source_tree'] == prep['tree']
assert pre['base_branch'] == 'main' and pre['tree_matches_synthetic']
assert pre['acceptance_sha256'] == identity(prep_path)['sha256']
assert main['premerge_sha256'] == identity(args.pre)['sha256']
assert main['commit_verification']['verified'] is True
assert not main['failed'] and not main['pending'] and not main['missing']
assert pre['review']['commit_sha'] == prep['head'] and pre['review']['status'] == 'completed'
assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
assert git('rev-parse', 'HEAD') == main['source_commit']
assert git('rev-parse', 'HEAD^{tree}') == prep['tree']
assert git('branch', '--show-current') == 'main' and not git('status', '--porcelain')
assert git('show', '-s', '--format=%P', 'HEAD').split() == [pre['base'], prep['head']]
prior = read(PRIOR)
assert prior['status'] == 'complete' and prior['merge_commit'] == pre['base'] == prep['base']

final_checks = read(OUT / 'pr1670-final-checks-r1.json')
final_review = read(OUT / 'pr1670-final-review-r1.json')
for report in (final_checks, final_review):
    assert report['status'] == 'passed' and report['head'] == prep['head']
    assert report['base'] == pre['base']
    assert report['premerge_sha256'] == identity(args.pre)['sha256']
assert final_checks['successful_hosted_checks'] == 58 and final_review['unresolved_threads'] == 0
assert final_review['automated_review'] == pre['review']
for observation in (main, final_checks, final_review):
    for name, checksum in observation['raw_sources'].items():
        path = OUT / name
        assert path.resolve().is_relative_to(OUT) and identity(path)['sha256'] == checksum

assert {path.name for path in PACKET.iterdir()} == set(prep['packet_files'])
for name, expected in prep['packet_files'].items():
    assert identity(PACKET / name) == expected
acceptance = read(PACKET / 'acceptance.json')
assert acceptance['status'] == 'local_acceptance_passed' and len(acceptance['checks']) == 15
assert identity(OUT / 'delivery-acceptance-r1.json') == prep['previous_delivery']
assert identity(OUT / 'provider-ci-docs-r2.json') == prep['final_documentation_checks']
assert identity(OUT / 'pr1670-release-scripts-job-128767154452-r1.json') == prep['preserved_hosted_failure']
assert prep['release_script_tests']['status'] == 'passed'
assert prep['release_script_tests']['test_count'] == 173
assert all(prep['release_script_tests'][key] == 0 for key in
           ('failure_count', 'error_count', 'skipped_count'))

installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == acceptance['installed_package'] == prep['installed_package']
assert installed['integration'] == dict(tests=386, failures=0, errors=0, skipped=0, status='passed')
kept = {}
for filename, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    path = OUT / 'runtime-r1' / filename
    actual = identity(path)
    assert actual['sha256'] == installed['integrity'][key] == acceptance['runtime_and_wheel'][key]
    kept[str(path)] = actual
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert identity(wheel)['sha256'] == installed['integrity']['wheel_sha256'] == acceptance['runtime_and_wheel']['wheel_sha256']
kept[str(wheel)] = identity(wheel)

retirement_path = OUT / 'provider-retirement-r1/receipt.json'
retirement = read(retirement_path)
assert retirement['status'] == 'passed' and retirement['accepted_head'] == prep['head']
assert retirement['accepted_tree'] == prep['tree']
assert retirement['main'] == identity(args.main) and retirement['premerge'] == identity(args.pre)
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
assert retirement['control_observations_preserved']
assert not retirement['storage_limits_changed'] and not retirement['payload_backup_created']
plan = read(OUT / 'provider-retirement-r1/plan.json')
assert retirement['removed'] == plan['entries']
assert retirement['manifest_sha256'] == plan['manifest_sha256'] == identity(OUT / 'provider-retirement-r1/manifest.json.xz')['sha256']
assert identity(OUT / 'tools/retire_provider_intermediates.py')['sha256'] == plan['script_sha256']
checkout = read(OUT / 'provider-main-checkout-r1.json')
assert checkout['status'] == 'passed' and checkout['merge_commit'] == main['source_commit']
assert checkout['other_worktree_refs_unchanged'] and checkout['active_worktree_clean']
assert checkout['accepted_file_tree_unchanged']

reconciliation = read(args.reconciliation)
assert reconciliation['status'] == 'complete' and reconciliation['repository'] == 'depsilon/shardloom'
assert reconciliation['accepted_merge'] == main['source_commit']
assert not reconciliation['open_dependabot_prs']
assert {row['number'] for row in reconciliation['proposals']} == set(range(1664, 1669))
assert len(reconciliation['proposals']) == 5
assert reconciliation['dependency_policy_changed'] is False
originals = {row['number']: row for row in prior['pending_independent_dependency_proposals']}
for row in reconciliation['proposals']:
    assert row['original_head'] == originals[row['number']]['head']
    assert row['state'] == 'closed'
    raw_path = OUT / row['raw_pr']['path']
    assert raw_path.resolve().is_relative_to(OUT) and identity(raw_path) == row['raw_pr']['identity']
    response = read(raw_path)
    assert response['isError'] is False
    remote = response['structuredContent']
    assert remote['number'] == row['number'] and remote['state'] == 'closed'
    assert remote['head_sha'] == row['observed_head'] and remote['merged'] == row['merged']
    if row['observed_head'] != row['original_head']:
        assert row['number'] == 1666 and row['changed_head_review']
        reference = row['changed_head_review']
        review_path = OUT / reference['path']
        assert review_path.resolve().is_relative_to(OUT) and identity(review_path) == reference['identity']
        update = read(review_path)
        assert update['status'] == 'reviewed_deferral' and update['pr'] == 1666
        assert update['original_head'] == row['original_head']
        assert update['observed_head'] == row['observed_head']
        assert update['observed_base'] == main['source_commit']
        assert update['disposition'] == row['disposition'] == 'deferred_coordinated_arrow_60'
        assert update['changed_files'] == ['Cargo.lock', 'Cargo.toml']
        assert all(source['connector_patch_reconstructs_exact_proposed_bytes']
                   for source in update['source_identities'].values())
        for name, expected in update['sources'].items():
            source = OUT / name
            assert source.resolve().is_relative_to(OUT) and identity(source) == expected
    else:
        assert row['changed_head_review'] is None
    if row['number'] in (1665, 1667, 1668):
        assert row['disposition'] == 'incorporated_ancestry'
        subprocess.run(['git', 'merge-base', '--is-ancestor', row['original_head'], main['source_commit']],
                       cwd=ROOT, check=True, timeout=90)
    else:
        expected = 'superseded_vortex_0_93' if row['number'] == 1664 else 'deferred_coordinated_arrow_60'
        assert row['disposition'] == expected
for row in reconciliation['sources']:
    path = OUT / row['path']
    assert path.resolve().is_relative_to(OUT) and identity(path) == row['identity']
search = read(OUT / reconciliation['open_search_path'])
assert search['isError'] is False and search['structuredContent']['issues'] == []

receipts = [prep_path, args.pre, args.main, args.reconciliation, retirement_path,
    OUT / 'delivery-acceptance-r1.json', OUT / 'provider-main-checkout-r1.json',
    OUT / 'pr1670-create-r1.json', OUT / 'pr1670-merge-r1.json',
    OUT / 'pr1670-final-checks-r1.json', OUT / 'pr1670-final-review-r1.json',
    OUT / 'provider-ci-docs-r2.json', OUT / 'provider-ci-docs-r2.log',
    OUT / 'provider-pr1670-r1.json', OUT / 'provider-pr1670-r1.log',
    OUT / 'pr1670-original-head-observation-r1.json',
    OUT / 'pr1670-release-scripts-job-128767154452-r1.json',
    OUT / 'documentation-binding-delivery-r1.json',
    OUT / 'provider-retirement-r1/plan.json', OUT / 'provider-retirement-r1/manifest.json.xz',
    OUT / 'installed-proof-r1/report.json', OUT / 'retirement-source-duplicates-r1.json',
    OUT / 'retirement-replay-bytecode-cleanup-r1.json',
    OUT / 'closeout-schema-inventory-r1.md', OUT / 'exact-vector-provider-handoff-r1.md']
receipts += [OUT / name for observation in (main, final_checks, final_review)
             for name in observation['raw_sources']]
receipts += [OUT / row['path'] for row in reconciliation['sources']]
receipts += [OUT / row['raw_pr']['path'] for row in reconciliation['proposals']]
receipts += list(OUT.glob('provider-retirement-*.log'))
receipts += list(OUT.glob('provider-retirement-*.json'))
receipts += list((OUT / 'retirement-source-failures').glob('plan-r*.py'))
receipts += [OUT / 'tools' / (name + '.py') for name in (
    'prepare_provider_delivery', 'prepare_provider_delivery_r2', 'final_provider_review',
    'watch_provider_pr', 'advance_provider_main', 'observe_provider_main',
    'watch_provider_main', 'retire_provider_intermediates', 'record_provider_closeout')]
receipts = sorted(set(receipts))
assert all(path.resolve().is_relative_to(OUT) for path in receipts)
report = dict(status='complete', observed_at=datetime.now(timezone.utc).isoformat(),
    pr_url='https://github.com/depsilon/shardloom/pull/1670', pr_head=prep['head'],
    merge_commit=main['source_commit'], source_tree=prep['tree'],
    pr_checks_passed=58, main_checks_passed=55, review_findings=False,
    review_url=pre['review_url'], main_ci_url=main['ci_run_url'],
    dependency_dispositions=reconciliation['proposals'], open_dependabot_prs=[],
    provider_decision=acceptance['provider_decision'], validation=acceptance['checks'],
    installed_package=installed['integration'], runtime_sources_match_build=True,
    runtime_source_proof=prep['runtime_source_proof'],
    retired_regular_files=retirement['regular_files'], retired_symlinks=retirement['symlinks'],
    retired_regular_bytes=retirement['regular_bytes'], current_inputs_unchanged=True,
    portable_replay_after_retirement='passed', retained_runtime_and_wheel=kept,
    committed_evidence={path.relative_to(ROOT).as_posix(): identity(path) for path in sorted(PACKET.iterdir())},
    receipts={path.relative_to(OUT).as_posix(): identity(path) for path in receipts},
    prior_vector_closeout=identity(PRIOR), closeout_script=identity(Path(__file__)),
    working_tree_clean=True, performance_claim=False, publication_attempted=False,
    whole_item_19_complete=False, next_queue_unit='Shared exact vector expressions',
    original_limitations=acceptance['limitations'],
    limitation_update='Hosted acceptance is now complete for the exact PR head and merged main; other original limits remain.')
with destination.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'merge_commit', 'pr_checks_passed',
    'main_checks_passed', 'installed_package', 'retired_regular_files', 'open_dependabot_prs')}))
