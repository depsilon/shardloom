"""Record observed dependency proposal outcomes after the exact provider merge."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PRIOR = OUT.parent / 'vector-representations-2026-11-07/vector-closeout-r1.json'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--main', type=Path, required=True)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size,
                    sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


main = read(args.main)
assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
merge = main['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == merge
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
prior = read(PRIOR)
assert prior['status'] == 'complete' and prior['merge_commit'] == main['pr_base']
originals = {row['number']: row for row in prior['pending_independent_dependency_proposals']}
assert set(originals) == set(range(1664, 1669))
search_path = OUT / 'dependabot-open-final-r1.json'
search = read(search_path)
assert search['isError'] is False and search['structuredContent']['issues'] == []
request_path = OUT / 'dependabot-open-final-request-r1.json'
request = read(request_path)
assert request == dict(query='is:open author:app/dependabot',
    repository_full_name='depsilon/shardloom', state='open', topn=100)
sources = [search_path, request_path, Path(__file__), OUT / 'dependabot-open-afterclose-r1.json']
rows = []
for number, original in sorted(originals.items()):
    path = OUT / f'dependabot-pr{number}-final-r1.json'
    response = read(path)
    assert response['isError'] is False
    remote = response['structuredContent']
    assert remote['number'] == number and remote['user']['login'] == 'dependabot[bot]'
    assert remote['state'] == 'closed' and remote['base'] == 'main'
    changed_review = None
    if remote['head_sha'] != original['head']:
        assert number == 1666, 'Unreviewed proposal head change.'
        review_path = OUT / 'dependabot-pr1666-rebased-review-r1.json'
        review = read(review_path)
        assert review['status'] == 'reviewed_deferral' and review['pr'] == number
        assert review['original_head'] == original['head']
        assert review['observed_head'] == remote['head_sha']
        assert review['observed_base'] == merge
        assert review['disposition'] == 'deferred_coordinated_arrow_60'
        assert review['changed_files'] == ['Cargo.lock', 'Cargo.toml']
        assert all(row['connector_patch_reconstructs_exact_proposed_bytes']
                   for row in review['source_identities'].values())
        for name, expected in review['sources'].items():
            source = OUT / name
            assert source.resolve().is_relative_to(OUT) and identity(source) == expected
            sources.append(source)
        sources += [review_path, OUT / 'dependabot-pr1666-beforeclose-r1.json']
        changed_review = dict(path=review_path.name, identity=identity(review_path))
    if number in (1665, 1667, 1668):
        subprocess.run(['git', 'merge-base', '--is-ancestor', original['head'], merge],
                       cwd=ROOT, check=True, timeout=90)
        disposition = 'incorporated_ancestry'
        reason = {1665: 'Reviewed CI security-action revisions are included in the accepted merge.',
                  1667: 'tonic-prost 0.14.9 is included in the accepted merge.',
                  1668: 'Jiff patches and calendar regressions are included in the accepted merge.'}[number]
    elif number == 1664:
        disposition = 'superseded_vortex_0_93'
        reason = 'The partial Vortex 0.91 proposal is superseded by the coordinated, accepted Vortex 0.93.0 update.'
    else:
        disposition = 'deferred_coordinated_arrow_60'
        reason = 'The partial Arrow 60 proposal mixes incompatible runtime type families. The accepted graph is Arrow/Parquet 59.3.2; Arrow 60 needs a coordinated Vortex/ADBC/ORC consumer port.'
    sources.append(path)
    mutation = OUT / f'dependabot-pr{number}-close-r1.json'
    if mutation.exists():
        result = read(mutation)
        assert result['isError'] is False
        assert result['structuredContent']['number'] == number
        assert result['structuredContent']['state'] == 'closed'
        assert result['structuredContent']['head_sha'] == remote['head_sha']
        sources.append(mutation)
    rows.append(dict(number=number, title=remote['title'], url=remote['url'],
        original_head=original['head'], observed_head=remote['head_sha'],
        state=remote['state'], merged=remote['merged'], disposition=disposition,
        reason=reason, changed_head_review=changed_review,
        raw_pr=dict(path=path.name, identity=identity(path))))
report = dict(status='complete', observed_at=datetime.now(timezone.utc).isoformat(),
    repository='depsilon/shardloom', accepted_merge=merge, proposals=rows,
    open_dependabot_prs=[], open_search_path=search_path.name, search_request=request,
    dependency_policy_changed=False, public_package_published=False,
    sources=[dict(path=path.relative_to(OUT).as_posix(), identity=identity(path))
             for path in sorted(set(sources))], prior_vector_closeout=identity(PRIOR),
    exact_main=identity(args.main))
with (OUT / 'dependabot-dispositions-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=report['status'], merge=merge,
    dispositions={row['number']: row['disposition'] for row in rows}, open_dependabot_prs=[])))
