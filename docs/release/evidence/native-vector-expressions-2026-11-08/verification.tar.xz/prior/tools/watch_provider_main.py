"""Wait for provider delivery after vector closeout checks, then preserve one observation."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
import time

Q = Path(__file__).resolve().parents[1]
T = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--merge', required=True)
parser.add_argument('--pre', required=True, type=Path)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}', args.merge)
assert re.fullmatch('[a-z0-9-]+', args.name)
assert not (Q / (args.name + '.json')).exists()
pre = json.loads(args.pre.read_bytes())
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
expected = {row['name'] for row in pre['checks']} - {'CodeQL', 'CodeQL rust', 'CodeQL python'}
assert len(expected) == 55
deadline = time.monotonic() + 180 * 60
previous = None
ready = False
while time.monotonic() < deadline:
    try:
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
            f'repos/depsilon/shardloom/commits/{args.merge}/check-runs?per_page=100&filter=latest'],
            cwd=T, stderr=subprocess.PIPE, timeout=50)
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as error:
        if isinstance(error, subprocess.CalledProcessError) and not any(
                value in (error.stderr or b'') for value in
                (b'HTTP 50', b'connection reset', b'i/o timeout', b'TLS handshake timeout')):
            raise
        time.sleep(40)
        continue
    result = json.loads(raw)
    rows = result['check_runs']
    assert len(rows) == result['total_count'] <= 100
    assert all(row['head_sha'] == args.merge for row in rows)
    failures = [row['name'] for row in rows if row['status'] == 'completed'
                and row['conclusion'] != 'success']
    pending = [row['name'] for row in rows if row['status'] != 'completed']
    passed = {row['name'] for row in rows if row['status'] == 'completed' and row['conclusion'] == 'success'}
    marker = (len(passed & expected), len(rows), tuple(sorted(pending)), tuple(sorted(failures)))
    if marker != previous:
        print(datetime.now(timezone.utc).isoformat(), marker, flush=True)
        previous = marker
    if failures or (expected <= passed and not pending):
        ready = True
        break
    time.sleep(45)
if not ready:
    print('Observation deadline reached; preserving current hosted state.', flush=True)
command = [sys.executable, str(Q / 'tools/observe_provider_main.py'),
           '--merge', args.merge, '--pre', str(args.pre), '--name', args.name]
raise SystemExit(subprocess.run(command, cwd=T, timeout=240).returncode)
