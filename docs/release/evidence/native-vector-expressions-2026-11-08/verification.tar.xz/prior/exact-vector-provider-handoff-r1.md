<!-- SPDX-License-Identifier: Apache-2.0 -->

# Exact-vector provider handoff inventory

Read-only source inventory for ShardLoom checkout
`443e092a27aed721aa2cb2b2276b81d9d3d98ead`; pinned `vendor/vortex-array`
is 0.93.0 (`vendor/vortex-array/Cargo.toml:16-17`; `Cargo.lock:3749-3750`).
The previous preparation note is
`/Users/dylan/LocalData/shardloom/vector-representations-2026-11-07/exact-vector-provider-preparation-r1.md`
and covered Vortex 0.90.0. This is a source inventory only: no provider admission,
semantic selection, design, or implementation decision is made here.

## Existing list and storage functions

- `ListLength` is registered as `vortex.list.length` (`vendor/vortex-array/src/scalar_fn/session.rs:84`;
  `vendor/vortex-array/src/scalar_fn/fns/list_length.rs:45-50`). Its declared result is U64 with the
  input List or FixedSizeList parent nullability (`vendor/vortex-array/src/scalar_fn/fns/list_length.rs:76-84`). Execution
  derives fixed-size lengths from the dtype, ListView lengths from `sizes`, and List
  lengths by subtracting adjacent offsets, then carries row validity (`vendor/vortex-array/src/scalar_fn/fns/list_length.rs:124-159`).
  Tests record `[2,3,0,2]`, nullable rows as `[Some(2),None,Some(0),None]`, and a
  nullable null scalar as null (`vendor/vortex-array/src/scalar_fn/fns/list_length.rs:230-285`). The implementation matcher
  includes ListView (`vendor/vortex-array/src/scalar_fn/fns/list_length.rs:172-183`), and direct ListView tests exercise the
  expression (`vendor/vortex-array/src/scalar_fn/fns/list_length.rs:288-324`). ListView is a physical encoding of `DType::List`,
  not a separate dtype (`vendor/vortex-array/src/arrays/listview/array.rs:66-76,565-579`),
  so the declared List dtype rule covers it.
- `ListSum` is registered as `vortex.list.sum` (`vendor/vortex-array/src/scalar_fn/session.rs:85`;
  `vendor/vortex-array/src/scalar_fn/fns/list_sum.rs:41-47`). Its return-type rule accepts List and
  FixedSizeList elements and delegates widening/type eligibility to `SumV2`; output
  is nullable (`vendor/vortex-array/src/scalar_fn/fns/list_sum.rs:72-82`; docs at `vendor/vortex-array/src/scalar_fn/fns/list_sum.rs:28-37`). The contract documented and
  exercised is: null parent, empty list, all-null components, and integer/decimal
  overflow yield null; null components are skipped; default float behavior skips NaNs,
  while `include_nans` lets NaN poison the result (`vendor/vortex-array/src/scalar_fn/fns/list_sum.rs:193-265,306-367`).
  Tests also execute ListView and obtain `[Some(6),Some(6),None,Some(5)]`
  (`vendor/vortex-array/src/scalar_fn/fns/list_sum.rs:370-390`). ListView is a physical encoding of `DType::List`, not a
  separate dtype (`vendor/vortex-array/src/arrays/listview/array.rs:66-76,565-579`),
  so the declared List dtype rule covers it. This helper is a sum, not a dot product
  or norm contract.
- `GetItem` is registered as `vortex.get_item` (`vendor/vortex-array/src/scalar_fn/session.rs:77`;
  `vendor/vortex-array/src/scalar_fn/fns/get_item.rs:144-149`). It looks up a named field in a Struct dtype
  and projects the struct field, combining nullable parent validity into the child
  (`vendor/vortex-array/src/scalar_fn/fns/get_item.rs:191-231`). It is not numeric list-element indexing. The expression
  helper is at `vendor/vortex-array/src/expr/exprs.rs:124-153`.
- `ExtStorage` is registered as `vortex.ext.storage` (`vendor/vortex-array/src/scalar_fn/session.rs:75`;
  `vendor/vortex-array/src/scalar_fn/fns/ext_storage.rs:28-33`). Its result dtype is the extension storage
  dtype; execution returns the underlying `ExtensionArray::storage_array()` (or a
  constant storage scalar), preserving the payload while removing the extension wrapper
  (`vendor/vortex-array/src/scalar_fn/fns/ext_storage.rs:59-85`). It is generic storage access, not vector-semantic or
  embedding-space validation.

## Slicing and fixed-size-list access

- A `FixedSizeListArray` stores a flat `elements` child partitioned into contiguous
  fixed-length rows; the parent validity marks null vector rows, while child validity
  marks null components (`vendor/vortex-array/src/arrays/fixed_size_list/array.rs:25-40`). `list_size()`
  exposes the dimension, and `fixed_size_list_elements_at(index)` returns the component
  child slice `[index*list_size .. (index+1)*list_size]`
  (`vendor/vortex-array/src/arrays/fixed_size_list/array.rs:216-253`).
- Array `slice(range)` is a row-range operation. For fixed-size lists, the slice kernel
  maps row bounds to component bounds by multiplying by list size and slices row validity
  in parallel (`vendor/vortex-array/src/arrays/fixed_size_list/compute/slice.rs:17-35`). Ordinary List row
  slicing slices offsets and parent validity while retaining the shared elements child
  (`vendor/vortex-array/src/arrays/list/compute/slice.rs:16-28`); ListView similarly slices offsets, sizes, and
  validity while retaining its elements (`vendor/vortex-array/src/arrays/listview/compute/slice.rs:16-30`).
  Thus row slicing does not select a component interval within every vector; the
  per-row fixed-list accessor above is the explicit component-slice surface.
- Extension row slicing wraps the sliced storage array in the same extension dtype
  (`vendor/vortex-array/src/arrays/extension/compute/slice.rs:16-25`).

## Optional row visitor example and feature gate

`vendor/vortex-array/src/scalar_fn/unstable/row/visitor/row_visitor.rs:222-244` contains an `ignore`-marked
documentation example that sketches cosine similarity as dot divided by magnitudes,
with caller-provided `vector_magnitude` and `cosine_similarity_with_const_magnitudes`
closures and batch-constant precomputation. It is not a registered cosine function,
executable test, or supplied arithmetic implementation. The row API is experimental
and requires the `unstable_row_fns` feature (`vendor/vortex-array/Cargo.toml:50-68`; `vendor/vortex-array/src/scalar_fn/mod.rs:10-14,44-48`;
`vendor/vortex-array/src/scalar_fn/unstable/mod.rs:4-9`).

## Named vector-kernel search and scope

Scoped searches of `vendor/vortex-array/src/scalar_fn`, `vendor/vortex-array/src/compute`,
the Vortex array implementations under `vendor/vortex-array/src/arrays`, and the
available `vortex-compute` 0.93.0 registry source found no registered dot-product,
vector norm, L2-distance, cosine, or vector-normalize kernel by those operation names.
The lockfile records `vortex-compute` 0.93.0 (`Cargo.lock:3905-3912`); its available
source is `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vortex-compute-0.93.0/src`.
That crate describes lane-level indexed map kernels and exports `IndexedSource`,
`LaneZip`, source/sink interfaces, and map extensions
(`/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vortex-compute-0.93.0/src/lib.rs:6-15`;
`/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vortex-compute-0.93.0/src/lane_kernels/mod.rs:4-41`),
which are generic primitives, not named vector operators.
This is a bounded inventory of the listed pinned/local source surfaces, not a claim
about all upstream Vortex crates, other versions, or unsearched providers.

## Difference from the 0.90.0 preparation

This checkout advances the pinned source inspected from 0.90.0 to 0.93.0. The previously
reported list-length decomposition, list-sum null/NaN caveat, Struct-only `get_item`,
extension storage boundary, row-vs-component distinction, and ignored cosine sketch
remain visible in the current source. Newer-source details recorded here are the
explicit fixed-size-list row accessor and the feature gate on the unstable visitor.
The ListView source confirms it is a `DType::List` physical encoding, so the registered
List dtype rules cover its logical dtype for both list helpers.
The generic compute surface now inspected is the available `vortex-compute` 0.93.0
indexed lane-map source; the absence statement remains scoped and does not imply a
whole-upstream negative.

## Primary verification

The primary independently checked the registrations, declared list result rules,
length decomposition, sum null/NaN contract, extension storage and struct-field
access, fixed-list row accessor, all four row-slice implementations, and the
unstable visitor gate/example. The repeated named-operation search returned only
the ignored cosine example in the bounded directories. The initial inventory's
ListView dtype inference was corrected against its actual constructors: ListView
uses `DType::List`. This accepts the scoped source inventory only; no vector
arithmetic semantics, provider admission or implementation is established.
