# Provider closeout schema inventory (r1)

**Status: NEEDS_REASONING** — literal schema and path coverage checked; reconciliation disposition schema is a future primary-designed input and cannot be validated against a producer yet.

## Existing inputs

- `tools/record_provider_closeout.py` requires `delivery-acceptance-r2.json` fields `status`, `runtime_sources_match_build`, `head`, `tree`, `base`, `packet_files`, `previous_delivery`, `final_documentation_checks`, `preserved_hosted_failure`, `release_script_tests`, and `installed_package`. These keys exist in r2. The script's `release_script_tests` subkeys (`status`, `test_count`, `failure_count`, `error_count`, `skipped_count`) and `packet_files` mapping are present. `delivery-acceptance-r1.json` has the older delivery fields but lacks the r2-only fields above; it is used only for identity in closeout.
- Packet `acceptance.json` has `status`, `checks` (15 entries), `installed_package`, `runtime_and_wheel`, `provider_decision`, and `limitations`; all literal accesses used by the closeout/retirement producers are present. Runtime digest keys are `cli_sha256`, `native_library_sha256`, `wheel_sha256`.
- `installed-proof-r1/report.json` supplies `status`, `uninstall_status`, `integration`, `integrity`, and `wheel`; `integrity` contains the CLI/library/wheel digests referenced by the closeout. `provider-retirement-r1/plan.json` supplies `entries`, `manifest_sha256`, and `script_sha256` (plus the inventory fields consumed by `retire_provider_intermediates.py`). No literal field mismatch found in these existing artifacts.

## Producer-backed future inputs

- `tools/advance_provider_main.py` writes `provider-main-checkout-r1.json` with `status`, `merge_commit`, `source_tree`, `active_worktree`, `main_branch`, `worktrees_before`, `worktrees_after`, `other_worktree_refs_unchanged`, `active_worktree_clean`, and `accepted_file_tree_unchanged`; its initial failure record also has `observed_at` and can add `error`.
- `tools/observe_provider_main.py` produces the main observation consumed as `main`: `status`, `source_commit`, `successful_hosted_checks`, `pr`, `pr_head`, `source_tree`, `failed`, `pending`, `missing`, `commit_verification.verified`, `raw_sources`, and `ci_run_url` are emitted/consumed across the producer and closeout. Its raw source naming is dynamic and must be checked against the resulting receipt.
- `tools/final_provider_review.py` writes checks/review reports with the closeout-required fields: both `status`, `head`, `base`, `premerge_sha256`, `raw_sources`; checks `successful_hosted_checks`; review `unresolved_threads`, `automated_review`, `review_url`.
- `tools/retire_provider_intermediates.py` writes a retirement receipt consumed through `status`, `accepted_head`, `accepted_tree`, `main`, `premerge`, `retained_files_unchanged`, `input_generations_unchanged`, `portable_replay_after_retirement`, `control_observations_preserved`, `storage_limits_changed`, `payload_backup_created`, `removed`, `manifest_sha256`, `regular_files`, `symlinks`, and `regular_bytes`. The checked plan schema provides `entries`, `manifest_sha256`, and `script_sha256`.
- `record_provider_closeout.py` requires the listed fixed receipt filenames, including `pr1670-final-checks-r1.json`, `pr1670-final-review-r1.json`, `provider-retirement-r1/receipt.json`, `provider-main-checkout-r1.json`, and fixed raw evidence names. These are runtime outputs, so no existence/producer-output claim is made here. Dynamic raw-source paths are validated by containment and recorded hashes at execution time.

## Unresolved by design

`--reconciliation` is future input from the primary's reconciliation design. Literal top-level fields are `status`, `repository`, `accepted_merge`, `open_dependabot_prs`, `proposals`, `dependency_policy_changed`, and `sources`; each proposal is expected to carry `number`, `original_head`, `state`, `raw_pr.path`, `raw_pr.identity`, `observed_head`, `merged`, and `disposition`. The script also expects `open_search_path`. No producer schema was supplied for this designed input, so its exact shape and disposition values remain for primary semantic review. Do not treat this inventory as acceptance of proposal semantics.

No source files were edited and no helper, build, network action, deletion, or hash inventory was run.
