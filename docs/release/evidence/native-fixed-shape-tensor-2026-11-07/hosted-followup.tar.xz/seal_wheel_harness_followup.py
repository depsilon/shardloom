"""Preserve original CI failures and the finite test-only fixture correction."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
HEAD = '28098a758e81cdeedbb62cd384d4a1bb7e2f5deb'
SOURCE = 'scripts/test_prove_native_python_wheel.py'


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
before = subprocess.check_output(['git', 'show', HEAD + ':' + SOURCE], cwd=ROOT)
after = (ROOT / SOURCE).read_bytes()
files = ['pr1661-job-128370598824-r1.log', 'pr1661-job-128370598794-r1.log',
         'wheel-harness-regression-r1.json', 'wheel-harness-regression-r1.log',
         'wheel-harness-regression-r2.json', 'wheel-harness-regression-r2.log',
         'tensor-pr1661-r1.json']
values = {name: (OUT / name).read_bytes() for name in files}
values.update({'source-before.py': before, 'source-after.py': after,
               'seal_wheel_harness_followup.py': Path(__file__).read_bytes()})
archive_path = PACKET / 'hosted-followup.tar.xz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'x:xz') as archive:
    for name, raw in sorted(values.items()):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
verifier = PACKET / 'verify_hosted_followup.py'
assert not verifier.exists()
shutil.copyfile(OUT / 'tools/verify_wheel_harness_followup.py', verifier)
report = dict(status='local_fixture_correction_passed', original_head=HEAD,
    original_failed_pr='https://github.com/depsilon/shardloom/pull/1661',
    original_failed_jobs=[128370598824, 128370598794],
    cause='The isolated suite-selection test fixture omitted the newly required public-context suite. Both Linux wheel jobs stopped at this harness test before package integration.',
    correction='Add the public-context fixture and verify both missing and skipped context/adapter suites remain fatal. No production or package-proof selection code changes.',
    source_path=SOURCE, source_before=identity(before), source_after=identity(after),
    runtime_sources_changed=False, installed_wheel_rebuilt=False,
    local_harness_tests=19, negative_cases=['missing adapter suite', 'skipped adapter suite',
        'missing public-context suite', 'skipped public-context suite'],
    original_packet={name: identity((PACKET / name).read_bytes())
        for name in ('acceptance.json', 'verification.tar.xz', 'verify.py')},
    verifier=identity(verifier.read_bytes()), archive=identity(archive_path.read_bytes()),
    members=[dict(path=name, **identity(raw)) for name, raw in sorted(values.items())],
    validation_scope='Existing 350-test installed proof and all runtime checks remain valid for unchanged sources; hosted validation must run on the corrected head. This report does not claim that hosted validation passed.')
with (PACKET / 'hosted-followup.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
subprocess.run([sys.executable, '-B', str(verifier), '--repo-root', str(ROOT)],
               cwd=ROOT, check=True, timeout=240)
