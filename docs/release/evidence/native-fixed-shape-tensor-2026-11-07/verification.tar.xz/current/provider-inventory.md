# Tensor Metadata Lifecycle: Existing Provider Inventory

Read-only source inventory for `/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo`, branch `codex/native-tensor-lifecycle`, HEAD `2df6460cae18eb55b2a0d680a55721d438bc495d`.

## Pinned Vortex graph and tensor-source gap

| Source | Evidence |
|---|---|
| `Cargo.toml:14-27` | Crates.io patches for Vortex crates point at `vendor/vortex-array`, `vendor/vortex-file`, and `vendor/vortex-layout` (among others). |
| `Cargo.lock:3773-3775,4012-4014,4112-4114` | Pinned local package versions: `vortex-array`, `vortex-file`, and `vortex-layout` are `0.90.0`. `Cargo.toml` workspace dependency section pins `vortex = "=0.90.0"` with `files,zstd` features near lines 73-74. |
| `vendor/vortex-file/Cargo.toml:54,212-215`; `vendor/vortex-file/src/lib.rs:195-196` | `vortex-file` declares optional `vortex-tensor = 0.90.0`, feature `tensor = ["dep:vortex-tensor"]`, and conditionally calls `vortex_tensor::initialize(session)`. No `vendor/vortex-tensor` source directory or `vortex-tensor` package entry was present in the inspected worktree's Cargo.lock. Therefore tensor crate implementation/API details are unknown from local source. |

## Existing local Vortex data model and APIs

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `vendor/vortex-array/src/dtype/mod.rs:99-103,135-138` | `DType::FixedSizeList(Arc<DType>, u32, Nullability)` carries a fixed child width; `DType::Extension(ExtDTypeRef)` is the logical extension wrapper. |
| `vendor/vortex-array/src/dtype/extension/vtable.rs:25-49` | `ExtVTable` defines `id`, `serialize_metadata`, `deserialize_metadata`, and `validate_dtype`. The file describes extension dtype as logical wrapper/storage dtype plus metadata, not a distinct physical array layout. |
| `vendor/vortex-array/src/dtype/extension/typed.rs:34-103` | `ExtDType<V>::try_new`, `metadata`, `storage_dtype`, `with_nullability`, and `serialize_metadata`. |
| `vendor/vortex-array/src/dtype/extension/erased.rs:41-52,120-130` | `ExtDTypeRef::id`, `storage_dtype`, nullability, and typed `metadata_opt` / `metadata`. |
| `vendor/vortex-array/src/dtype/serde/serde.rs:706-720,728-780` | Extension dtype serialization emits `id`, `storage_dtype`, `metadata`; deserialization uses a session-aware `DTypeSerde` seed and registry. |
| `vendor/vortex-array/src/arrays/fixed_size_list/array.rs:255-285` | `FixedSizeListArray::new` and `try_new(elements, list_size, validity, len)` construct fixed-list arrays. |
| `vendor/vortex-array/src/arrays/extension/array.rs:41-74` | `ExtensionArray::try_new` checks extension storage dtype equals backing array dtype; `storage_array` exposes backing array. |
| `vendor/vortex-array/src/canonical.rs:100-108,140-147` | Canonical mapping documents `FixedSizeListArray` as corresponding to Arrow's `FixedSizeListArray`; canonical extension wraps the canonical storage form. This is list/extension evidence, not a tensor rank/shape API. |

## Registered ShardLoom extension: embedding

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/native_embedding.rs:26,124-149` | `ID = "shardloom.embedding.v1"`; `Embedding: ExtVTable` with associated `Metadata`. |
| `shardloom-vortex/src/native_embedding.rs:38-75,86-115` | `Metadata` stores immutable canonical JSON, and parser accepts a versioned metadata map with bounded known identity fields and rejects duplicate/unknown fields. |
| `shardloom-vortex/src/native_embedding.rs:151-200` | `serialize_metadata` emits metadata bytes; `deserialize_metadata` checks bounded/canonical bytes and reserves parsing/retained memory using its session allocator. `validate_dtype` admits positive-width `FixedSizeList` with primitive `F32` or `F64` child. Dimension, component nullability and outer nullability live in storage dtype. |
| `shardloom-vortex/src/native_embedding.rs:211-242` | `storage(dtype)` recognizes typed `Embedding` metadata and returns storage; `contains` recurses through list/fixed-list/struct. `register_dtype` registers `Embedding` with session host allocator; `register` also installs edition and feature-gated Arrow mapping. |
| `shardloom-vortex/src/native_embedding_edition.rs:11-37` | Edition family `shardloomembedding`, declaration adds only dtype ID `shardloom.embedding.v1`, then enables it. |
| `shardloom-vortex/src/native_extensions.rs:3-8,10-20` | Central `register(session)` registers temporal, embedding and optional binary-object extensions. Shared `payload_storage(dtype)` returns recognized binary-object or embedding backing storage. Comment explicitly says that payload handling does not admit storage representation as a comparison key. |
| `shardloom-vortex/src/native_embedding.rs:256-364` | Unit tests cover canonical metadata round-trip and invalid metadata; received metadata reservation lifetime; storage width/precision/outer and component nullability; invalid storage shapes/types. |

## Embedding schema, values, and row/payload lifecycle

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/local_primitives/native_input_schema.rs:188-197,290-310` | Native wire `Extension` parser recognizes `native_embedding::ID` and calls `embedding_dtype`; parses storage dtype and metadata bytes, uses `Embedding::deserialize_metadata`, constructs `ExtDType<Embedding>`. Unknown ID not handled there is sent through temporal decoder, which rejects unsupported IDs at lines 383-391. |
| `shardloom-vortex/src/local_primitives/native_typed_input.rs:78-89` | `construct` branch for `native_embedding::storage(dtype)` recursively constructs storage values and wraps with `ExtensionArray::try_new`. |
| `shardloom-vortex/src/local_primitives/native_input_values.rs:32-39,48-50,73-85,103-145` | `Layout::{new,observe,defaults,bytes}` unwraps embedding to storage before generic nested shape/size handling. It validates fixed-list input width, counts nested child values, and calculates validity/data allocation. |
| `shardloom-vortex/src/native_payload_schema.rs:194-242` | `metadata_bytes_with_null` has embedding-specific branch: counts bounded metadata bytes and recursively budgets its storage dtype. |
| `shardloom-vortex/src/local_primitives/native_payload.rs:100-105,427-449` | Nested payload admission recognizes extensions via `native_extensions::payload_storage`. Structural copy unwraps storage array, recursively copies it, and rewraps the original extension dtype. |
| `shardloom-vortex/src/local_primitives/native_json.rs:89-121` | Native JSON output node explicitly unwraps registered embedding ExtensionArray and recursively processes storage; non-embedding generic extension reaches scalar path. |
| `shardloom-vortex/src/local_primitive_collect.rs:889-895,918-924` | Generic schema accounting recursively visits an extension's `storage_dtype`. JSON scalar collection explicitly rejects extensions except admitted temporal storage. |
| `shardloom-vortex/src/local_primitive_result_batch.rs:220-237,748-764,840-852` | `scalar_storage` extracts only accepted temporal scalar extension storage and rejects non-temporal extensions; scalar output's extension branch validates temporal ticks and constructs primitive storage then `ExtensionArray`. These are not generic embedding value conversions. |

## Arrow and compatibility input/output

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/native_embedding_arrow.rs:24-49` | Arrow extension metadata keys are `ARROW:extension:name` and `ARROW:extension:metadata`; `register` registers `EmbeddingArrow` importer/exporter. `admitted(field)` validates extension ID, metadata bound, positive fixed-size list and F32/F64 child. |
| `shardloom-vortex/src/native_embedding_arrow.rs:51-104` | `field` maps typed Vortex extension to Arrow fixed-size list with identity metadata. Private `dtype` reverses Arrow field to typed extension dtype and preserves item/outer nullability and dimension. |
| `shardloom-vortex/src/native_embedding_arrow.rs:106-177` | `ArrowImportVTable::{from_arrow_field,from_arrow_array}` validates storage/metadata and wraps imported storage in `ExtensionArray`; `ArrowExportVTable::{to_arrow_field,execute_arrow}` validates dtype and exports the extension's storage through Arrow session. |
| `shardloom-vortex/src/native_embedding_arrow.rs:193-283+` | Tests cover Arrow round-trip metadata, null bitmaps, special float bits and slices; rejection of invalid metadata and storage shape. |
| `shardloom-vortex/src/native_payload_schema.rs:244-266` | `arrow_field_metadata_admitted` whitelists known Arrow extension metadata IDs, including embedding; unrecognized extension names return false. |
| `shardloom-vortex/src/native_arrow_conversion.rs:20-30,47-65,335-348` | Output `field` and `data_type` special-case embedding to carry metadata and derive physical type from storage. Generic `canonical_extension` canonicalizes storage and reconstructs the same extension dtype. |
| `shardloom-vortex/src/local_primitive_native_text_sink.rs:28-39` | Text sink refuses any schema containing embedding because text cannot preserve embedding identity. |
| `shardloom-vortex/src/local_primitive_columnar_compat_sink.rs:216-223` | Avro/ORC compatibility sink refuses embedding-containing output because the format cannot preserve identity. |

## Spill session metadata ownership

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/native_spill_session.rs:27-69` | `with_memory` clones child registries and session state, gives the child a `ReservedHostAllocator`, checks whether parent DType registry contains `Embedding::id`, and re-registers embedding dtype with child allocator. |
| `shardloom-vortex/src/native_spill_session.rs:95-128` | Test `dense_embedding_spill_metadata_reserves_only_the_receiving_pool` registers parent, creates child, deserializes embedding metadata through child registry and asserts reservation occurs in child pool, not parent pool. |

## Relational/key and arithmetic admission/refusal

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/local_primitive_relational_bind.rs:904-945` | `validate_scalar` allows bool/UTF8/integer/F32/F64 operands only. `validate_key` refuses all dtypes containing embedding with message “embedding values are payload-only; compare, group, order or join on ordinary columns”; otherwise nested values use payload admission and flat extension values are admitted only if known temporal storage. |
| `shardloom-vortex/src/local_primitives/native_relational_keys.rs:295-313` | Generic Extension key execution interprets extension as temporal dtype and requires temporal storage; unsupported/embedding extensions fail with “temporal key requires admitted logical unit and timezone metadata”. |
| `shardloom-vortex/src/local_primitive_result_batch.rs:748-764` | Scalar write path's `DType::Extension` arm requires signed temporal ticks and validates temporal dtype; no embedding arithmetic/scalar path here. |

## Python public schema and typed input/result paths

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `python/src/shardloom/_embedding.py:1-55` | `EXTENSION_ID`, `normalize_metadata`, `metadata_json`, `decode_metadata` implement the public Python versioned, bounded embedding metadata representation. |
| `python/src/shardloom/_result_schema.py:29-42,57-123,138-188,191-223` | Public `ResultType`; schema decoder maps `Extension` payload into embedding `ResultType` after extension ID, metadata and storage validation; row conversion treats it as fixed-size nested list; Arrow result field adds extension metadata; Arrow type uses fixed-size list. |
| `python/src/shardloom/types.py:17-45,174-186` | `types.embedding(item, size, metadata, nullable)` is exported alongside `ResultType`; its doc says component nullability comes from item, outer nullable controls whole vector, identity does not authorize vector comparison. |
| `python/src/shardloom/_input_schema.py:43-75,84-138` | `ResultType` parameters accept embedding with three parameters including immutable metadata pairs. Input normalization enforces positive width and F32/F64 child, normalizes bounded metadata. |
| `python/src/shardloom/_input_schema.py:155-195,264-325` | `wire_schema` encodes declared embedding as native `Extension` ID/storage dtype/metadata bytes; `_value` validates fixed list width and recursively serializes child cells. |
| `shardloom-python/src/schema.rs:18-80` | Native Python boundary schema descriptor detects Arrow FixedSizeList with embedding extension name, requires extension metadata and returns descriptor type `embedding`; otherwise returns `fixed_size_list`. |
| `python/tests/test_embedding_schema.py:12-65` | Python schema tests exercise declarations, metadata validation, scalar restriction and fixed-size embedding schema conversion. |
| `python/tests/test_native_rich_binding.py:138-207,238-257`; `python/tests/test_native_rich_controls_binding.py:40-82,112-205` | Native binding tests cover typed object intake/retained special values, nested propagation and identity-preserving sinks, refusal on identity-losing sinks, metadata strictness, typed CLI declaration, comparison-key refusal and lifecycle ownership. |

## Capability graduation metadata

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/extension_type_capability.rs:6-24,28-78` | `ExtensionTypeSupportStatus` values include `Declared`, `MetadataPreserved`, `ReportOnly`, `Deferred`, `UnsupportedBlocked`; row carries dtype recognition, metadata preservation, scan/expression/write support, certified execution, fallback flags. Constructors define statuses for declared/reference categories. |
| `shardloom-vortex/src/extension_type_capability.rs:92-114` | Matrix includes `vector`, `tensor_matrix`, and `embedding_reference` families. `vector`/`tensor_matrix` use `declared`; `embedding_reference` uses `reference`; no row certifies execution through those constructors. |
| `shardloom-vortex/src/extension_type_capability.rs:166-220` | Tests assert family order, distinction between dtype recognition/metadata preservation and execution, and fallback-free status. These are capability category labels, not registry entries for `shardloom.embedding.v1`. |

## Generic extension preservation and limits

| Exact path and lines | Literal API / observed behavior |
|---|---|
| `shardloom-vortex/src/local_primitives/native_payload.rs:427-449` | Once recognized by the shared extension registry, generic payload copying recurses through storage and rewraps original extension dtype; storage traversal is not hardcoded to embedding ID here. |
| `shardloom-vortex/src/native_arrow_conversion.rs:335-348` | Generic `canonical_extension` preserves extension dtype while canonicalizing backing storage. |
| `shardloom-vortex/src/local_primitive_collect.rs:889-895` | Generic schema budget follows `extension.storage_dtype()`. |
| `shardloom-vortex/src/native_payload_schema.rs:245-266` | Generic Arrow extension intake is intentionally ID-whitelisted; unknown ID rejected. |
| `shardloom-vortex/src/local_primitive_relational_bind.rs:921-945`; `local_primitive_collect.rs:918-924`; `local_primitive_result_batch.rs:220-237` | Generic value support is not implied by storage carriage: key admission is provider-specific, JSON scalar extension collection accepts only temporal extension, and scalar storage extraction rejects non-temporal extensions. |

## Search coverage and explicit gaps

Searched Rust and Python source/tests, excluding generated docs/evidence and `vendor`, for `native_embedding`, `shardloom.embedding.v1`, `Embedding`, `DType::Extension`, `ExtensionArray`, and `metadata_opt`. The inventory covers the direct embedding references found in `shardloom-vortex/src`, `shardloom-python/src`, and `python/src` / `python/tests`, plus generic extension carriers and the identified refusals. The local `vortex-tensor` provider implementation was unavailable; no tensor-specific rank/shape API was identified in the local Vortex array sources inspected. No implementation or test command was run for this report.
