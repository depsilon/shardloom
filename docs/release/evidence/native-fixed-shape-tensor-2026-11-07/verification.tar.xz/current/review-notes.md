# Primary fixed-tensor review

Scope: native fixed-shape tensor identity and lifecycle over existing Vortex
fixed-size lists, with explicit Arrow compatibility and Python declarations.
Comparator: a native columnar engine maintainer reviewing lossless type identity,
allocation admission, owner lifetimes and unsupported semantic boundaries.

1. **Metadata identity and Arrow normalization.** Native metadata validates every
   dimension before computing the zero-aware checked product; rank zero is one
   element. Duplicate/unknown fields, null optional arrays, noninteger dimensions
   and nonbijective permutations fail. Canonical bytes preserve physical shape,
   optional empty arrays, names and permutation exactly. `native_tensor_arrow.rs`
   checks storage width and both nullability levels. PyArrow's canonical extension
   deserializer normalizes child nullability and rank-zero empty optional arrays;
   `_tensor.restore_arrow_schema` restores the native schema on ordinary Arrow
   storage fields. Numeric buffers remain shared. Direct third-party Arrow
   consumers have their own normalization behavior, documented in the contract.

2. **Allocation and receiving-session ownership.** Public Arrow intake computes
   `arrow_extension_metadata_bytes` and reserves metadata before invoking the
   importer (`resident_memory_arrow.rs:94-173`). Typed input reserves JSON
   workspace before dtype parsing and retains schema credit with owned buffers.
   Native deserialize reserves scratch and retained metadata against the registry
   allocator; clones share the reservation. Spill sessions re-register the tensor
   vtable against the receiving pool. Existing native structural execution and
   ownership remain the payload provider; no new decoded execution boundary.

3. **Unsupported roles and wrappers.** Tensor values remain payload-only.
   Recursive `validate_key` refuses key roles; arithmetic fails the existing
   numeric operand check. Text, Avro and ORC refuse metadata loss before output
   publication. Arrow preflight only admits canonical fixed-list tensor fields
   over supported plain Boolean/integer/F32/F64 components; nested/foreign
   component extensions and dictionary wrappers cannot silently become tensors.
   Existing structural payload helpers handle nesting, gathers and native I/O.

Review-driven tests added after the initial nine-test binding pass: scalar and
zero-sized persistence; nested variable/fixed lists and structs with nonzero
slices; direct numeric-buffer address preservation; empty-file readback;
metadata-only allocation denial and final-owner release; oversized metadata;
dictionary wrapper refusal; arithmetic refusal. The leaf coverage inventory is
an earlier read-only source map, not final execution evidence. Duplicate joins
already exercise repeated tensor row selection and reverse output order against
an independently assembled expected row collection.

No production defect was found in this review pass. A signed-to-unsigned cast in
the zero-width Arrow test fixture was replaced by a checked conversion; strict
native Clippy now passes. The minimal feature matrix then exposed one new unused
Arrow ID constant. It now shares the universal-format-io gate of its consumers;
the affected minimal check and strict native Clippy pass. Nine pre-existing
minimal-feature warnings remain. The exact gate-only delta and resolved Cargo
feature sets are preserved in runtime-production-continuity-r2.json; default
builds exclude the module and native/release builds enable the gated constant.
All 12 tensor binding tests pass, including the review-driven additions. The
final release build is frozen as runtime-r2. Broad default/native Rust suites
pass 3,319/6,955 cases, with 37 existing opt-in native tests ignored.

The first mixed Python core invocation was invalid for that suite: SHARDLOOM_BIN
overrode four binary-resolution fixtures, while five native loaders inferred
Python extension loaders from a raw dylib suffix. It also exposed one pre-existing
public-context assertion for older source-change wording. The engine correctly
refused the changed source. Its current stable diagnostic and actionable text
replace that stale assertion; runtime code is unchanged. All original six
failures and four errors remain in python-core-r1.log. The standard public shard
now passes with 838 reported runs and 49 optional/environment skip records,
distinct from 1,192 discovered cases. Ten native context tests pass directly.
The installed-package verifier now explicitly runs all 19 public-context tests
alongside the native suites, including the two clean-package cross-transport
tests. All 350 installed tests pass without skips, and clean installation,
identity and uninstall checks pass. Exact test/harness deltas and
the unchanged diagnostic source are saved in harness-correction-r1.json.

No performance conclusion or whole-item-19 completion follows.
