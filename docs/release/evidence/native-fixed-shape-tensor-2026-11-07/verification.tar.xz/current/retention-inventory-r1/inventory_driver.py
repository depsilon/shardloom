"""Plan-only fixed-tensor retention inventory using approved identity helpers."""
import hashlib, importlib.util, json, lzma, tarfile
from pathlib import Path, PurePosixPath
BASE=Path('/Users/dylan/LocalData/shardloom')
N=BASE/'dependency-followup-2026-11-06'
R=BASE/'tensor-lifecycle-2026-11-07'
OUT=R/'retention-inventory-r1'
HELPER=BASE/'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
ROOTS=[
 N/'runtime-r1/shardloom',N/'runtime-r1/lib_native.dylib',N/'installed-proof-r1/dist',
 R/'runtime-r1/shardloom',R/'runtime-r1/lib_native.dylib',R/'installed-proof-r1/package',
 R/'installed-proof-r1/venv',R/'provider-review/source',BASE/'managed-binary-2026-11-06/test-env']
REPORTS={'dependency-followup-2026-11-06':N/'installed-proof-r1/report.json','tensor-lifecycle-2026-11-07':R/'installed-proof-r1/report.json'}
def digest_bytes(b): return hashlib.sha256(b).hexdigest()
def read_json(p): return json.loads(p.read_bytes())
spec=importlib.util.spec_from_file_location('retention_identity_helpers',HELPER)
helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
helper.E=BASE
assert OUT.is_dir() and OUT.resolve()==OUT
# Check each specified retained runtime pair and wheel against its own saved proof.
identity_checks={}
for label,base,report_path,runtime_name in [('older_dependency',N,REPORTS['dependency-followup-2026-11-06'],'runtime-r1'),('fixed_tensor',R,REPORTS['tensor-lifecycle-2026-11-07'],'runtime-r2')]:
 report=read_json(report_path); ident=report['integrity']
 assert report['status']=='passed' and report['uninstall_status']=='passed' and ident['status']=='passed'
 items=[('cli',base/runtime_name/'shardloom','cli_sha256'),('native_library',base/runtime_name/'lib_native.dylib','native_library_sha256')]
 dist=base/'installed-proof-r1/dist'
 wheels=sorted(dist.glob('*.whl')); assert len(wheels)==1
 items.append(('wheel',wheels[0],'wheel_sha256'))
 checks={}
 for name,path,key in items:
  value=helper.sha(path); checks[name]={'path':str(path),'bytes':path.stat().st_size,'sha256':value,'expected_sha256':ident[key],'matches':value==ident[key]}
 identity_checks[label]={'runtime_root':str(base/runtime_name),'report':str(report_path),'report_status':report['status'],'uninstall_status':report['uninstall_status'],'integration':report.get('integration'),'items':checks}
# Provider source is independently checked against both its receipt file table and the downloaded .crate.
provider=R/'provider-review'; receipt=read_json(provider/'receipt.json'); crate=provider/'vortex-tensor-0.90.0.crate'; src=provider/'source'
crate_sha=helper.sha(crate)
assert crate_sha==receipt['checksum'] and crate.stat().st_size==receipt['archive_bytes']
with tarfile.open(crate,mode='r:gz') as tf:
 members={}
 prefix='vortex-tensor-0.90.0/'
 for m in tf.getmembers():
  if m.isfile():
   assert m.name.startswith(prefix),m.name
   f=tf.extractfile(m); assert f is not None
   members[m.name.removeprefix(prefix)]=f.read()
receipt_files=receipt['files']
source_files={p.relative_to(src).as_posix():p.read_bytes() for p in src.rglob('*') if p.is_file() and not p.is_symlink()}
assert set(receipt_files)==set(source_files)==set(members)
provider_rows=[]
for rel,identity in sorted(receipt_files.items()):
 local=source_files[rel]; archived=members[rel]
 local_sha=digest_bytes(local); archive_sha=digest_bytes(archived)
 provider_rows.append({'path':rel,'bytes':len(local),'receipt_bytes':identity['bytes'],'source_sha256':local_sha,'receipt_sha256':identity['sha256'],'crate_member_sha256':archive_sha,'source_matches_receipt':len(local)==identity['bytes'] and local_sha==identity['sha256'],'source_matches_crate_member':local==archived and archive_sha==identity['sha256']})
provider_check={'status':receipt['status'],'crate_name':'vortex-tensor','version':receipt['version'],'license':receipt['license'],'archive_path':str(crate),'archive_bytes':crate.stat().st_size,'archive_sha256':crate_sha,'expected_archive_sha256':receipt['checksum'],'source_file_count':len(source_files),'crate_regular_member_count':len(members),'receipt_file_count':len(receipt_files),'all_file_sets_equal':set(receipt_files)==set(source_files)==set(members),'files':provider_rows}
assert all(x['source_matches_receipt'] and x['source_matches_crate_member'] for x in provider_rows)
# Inventory only the nine named roots with the established generation/SHA/symlink schema.
root_inventory={}; root_counts={}; all_entries=[]; missing_roots=[]
for requested_root in ROOTS:
 if not requested_root.exists() and not requested_root.is_symlink():
  missing_roots.append(str(requested_root)); root_counts[str(requested_root)]={'status':'missing','entries':0,'directories':0,'regular_files':0,'symlinks':0,'regular_bytes':0}; continue
 root=requested_root.resolve(); rows=helper.inventory(root); root_inventory[str(root)]=rows; all_entries.extend(rows)
 root_counts[str(root)]={'status':'inventoried','entries':len(rows),'directories':sum(x['kind']=='directory' for x in rows),'regular_files':sum(x['kind']=='regular' for x in rows),'symlinks':sum(x['kind']=='symlink' for x in rows),'regular_bytes':sum(x['generation'][3] for x in rows if x['kind']=='regular')}
manifest={'roots':root_inventory,'entry_count':len(all_entries),'regular_files':sum(x['kind']=='regular' for x in all_entries),'symlinks':sum(x['kind']=='symlink' for x in all_entries),'regular_bytes':sum(x['generation'][3] for x in all_entries if x['kind']=='regular')}
raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode(); packed=lzma.compress(raw,preset=6)
(OUT/'identities.json.xz').write_bytes(packed)
all_ok=not missing_roots and all(x['matches'] for y in identity_checks.values() for x in y['items'].values()) and all(x['source_matches_receipt'] and x['source_matches_crate_member'] for x in provider_rows)
receipt_out={'status':'COMPLETE' if all_ok else 'NEEDS_REASONING','mode':'plan_only','deletion_performed':False,'hosted_acceptance_pending':True,'helper_script':str(HELPER),'helper_primitives_used':['inventory','entry','generation','sha'],'mutating_helper_functions_called':False,'base_E':str(BASE),'explicit_roots':[str(p) for p in ROOTS],'missing_roots':missing_roots,'root_counts_and_bytes':root_counts,'total_entries':manifest['entry_count'],'total_regular_files':manifest['regular_files'],'total_symlinks':manifest['symlinks'],'total_regular_bytes':manifest['regular_bytes'],'compressed_inventory':'identities.json.xz','compressed_inventory_sha256':digest_bytes(packed),'retained_binary_wheel_identity_checks':identity_checks,'provider_review_source_check':provider_check}
(OUT/'receipt.json').write_text(json.dumps(receipt_out,indent=2)+'\n')
print(json.dumps(receipt_out,indent=2))
if not all_ok: raise SystemExit(1)
