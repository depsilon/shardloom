"""Verify the exact test-only and feature-gate deltas after broad validation."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
BASE = '2df6460cae18eb55b2a0d680a55721d438bc495d'
receipt = OUT / 'runtime-production-continuity-r2.json'
assert not receipt.exists()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


build = json.loads((OUT / 'native-build-r1.json').read_bytes())
files = {}
gate = b'#[cfg(feature = "universal-format-io")]\npub(crate) const ARROW_ID:'
ungated = b'pub(crate) const ARROW_ID:'
for name, identity in build['changed_source_inventory'].items():
    if not name.endswith('.rs'):
        continue
    before = (OUT / 'source-blobs' / identity['sha256']).read_bytes()
    after = (ROOT / name).read_bytes()
    assert sha(before) == identity['sha256']
    proof = dict(before_sha256=sha(before), current_sha256=sha(after), classification='identical')
    if before != after:
        if name == 'shardloom-vortex/src/native_tensor_arrow.rs':
            marker = b'#[cfg(test)]\nmod tests {'
            assert before.count(marker) == after.count(marker) == 1
            assert before.split(marker)[0] == after.split(marker)[0]
            proof['classification'] = 'test_fixture_only'
        else:
            assert name == 'shardloom-vortex/src/native_tensor.rs'
            assert after.count(gate) == 1 and before.count(gate) == 0
            assert after.replace(gate, ungated, 1) == before
            proof['classification'] = 'arrow_constant_feature_gate_only'
        proof['diff'] = ''.join(difflib.unified_diff(before.decode().splitlines(True),
            after.decode().splitlines(True), fromfile='initial-build/' + name, tofile='final/' + name))
    files[name] = proof

manifests = {}
for name in ('Cargo.toml', 'Cargo.lock', 'shardloom-cli/Cargo.toml',
             'shardloom-python/Cargo.toml', 'shardloom-vortex/Cargo.toml'):
    current = (ROOT / name).read_bytes()
    base = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=ROOT)
    assert current == base
    manifests[name] = dict(bytes=len(current), sha256=sha(current))

variants = {}
env = dict(os.environ, CARGO_TARGET_DIR='/Users/dylan/.cache/shardloom/cargo-target')
for name, features in [('default', []),
    ('native_tests', ['--features', 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment']),
    ('release_runtime', ['--features', 'release-user-surfaces'])]:
    command = ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1', *features]
    metadata = json.loads(subprocess.check_output(command, cwd=ROOT, env=env, timeout=120))
    package = next(p['id'] for p in metadata['packages'] if p['name'] == 'shardloom-vortex')
    active = next(node['features'] for node in metadata['resolve']['nodes'] if node['id'] == package)
    assert ('universal-format-io' in active) == (name != 'default')
    if name == 'default':
        assert not set(active).intersection({'vortex-local-primitives', 'vortex-write'})
    variants[name] = dict(command=command, vortex_features=active)

result = dict(status='passed', source_base=BASE, initial_build='native-build-r1.json',
    files=files, unchanged_manifests=manifests, resolved_feature_variants=variants,
    enabled_runtime_equivalent=True,
    verification_scope='Broad default/native suites precede only a cfg attribute on the Arrow extension ID constant. Default builds exclude this module; native/release builds enable that feature. Final strict native lint and minimal feature check validate both compilation branches. The initial runtime also precedes one cfg(test) checked-cast correction.')
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'rust_files': len(files),
    'changed': {name: row['classification'] for name, row in files.items() if row['classification'] != 'identical'}}))
