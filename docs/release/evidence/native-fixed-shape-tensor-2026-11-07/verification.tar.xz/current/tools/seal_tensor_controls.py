"""Verify exact corruption mutations and preserve the full compact observation."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
CONTROL = OUT / 'packet-controls-r1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def contents(directory, report):
    raw = (directory / 'verification.tar.xz').read_bytes()
    assert sha(raw) == report['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in report['members']]
        result = {}
        for entry, row in zip(archive.getmembers(), report['members']):
            assert entry.isfile() and entry.size == row['bytes']
            data = archive.extractfile(entry).read()
            assert sha(data) == row['sha256']
            result[entry.name] = data
        return result


receipt = read(CONTROL / 'receipt.json')
assert receipt['status'] == 'passed' and receipt['positive_controls'] == 2 and receipt['rejected_controls'] == 5
original = read(PACKET / 'acceptance.json')
assert sha((PACKET / 'acceptance.json').read_bytes()) == receipt['original_packet_sha256']
assert sha((PACKET / 'verification.tar.xz').read_bytes()) == receipt['original_archive_sha256']
assert sha((PACKET / 'verify.py').read_bytes()) == receipt['verifier_sha256']
driver = (OUT / 'tools/check_tensor_packet_controls.py').read_bytes()
assert sha(driver) == receipt['driver_sha256']
data = contents(PACKET, original)
names = ['original', 'relocated', 'archive-byte-corruption', 'summary-count-corruption',
         'failed-check-with-resealed-archive', 'skipped-installed-test-with-resealed-archive',
         'missing-provider-with-resealed-archive']
assert [row['name'] for row in receipt['results']] == names
logs = {}
for index, row in enumerate(receipt['results']):
    raw = (CONTROL / (row['name'] + '.log')).read_bytes()
    assert sha(raw) == row['log_sha256']
    assert (row['returncode'] == 0) == (index < 2)
    assert row['expected'] == ('accept' if index < 2 else 'reject')
    if index >= 2:
        expected_error = b'KeyError' if row['name'] == 'missing-provider-with-resealed-archive' else b'AssertionError'
        assert expected_error in raw
    logs[row['name']] = raw.decode()
    if row['name'] != 'original':
        assert (CONTROL / row['name'] / 'verify.py').read_bytes() == (PACKET / 'verify.py').read_bytes()
for name in ('acceptance.json', 'verification.tar.xz', 'verify.py'):
    assert (CONTROL / 'relocated' / name).read_bytes() == (PACKET / name).read_bytes()

directory = CONTROL / 'archive-byte-corruption'
assert read(directory / 'acceptance.json') == original
expected_raw = bytearray((PACKET / 'verification.tar.xz').read_bytes())
expected_raw[len(expected_raw) // 2] ^= 1
assert (directory / 'verification.tar.xz').read_bytes() == expected_raw

directory = CONTROL / 'summary-count-corruption'
expected = copy.deepcopy(original)
expected['python_core']['reported_test_runs'] += 1
assert read(directory / 'acceptance.json') == expected
assert (directory / 'verification.tar.xz').read_bytes() == (PACKET / 'verification.tar.xz').read_bytes()

for name in names[4:]:
    directory = CONTROL / name
    report = read(directory / 'acceptance.json')
    actual = contents(directory, report)
    expected_report = copy.deepcopy(original)
    expected_data = dict(data)
    if name == 'failed-check-with-resealed-archive':
        key = 'current/native-tests-r1.json'
        value = json.loads(expected_data[key])
        value['status'], value['returncode'] = 'failed', 101
        expected_data[key] = json.dumps(value).encode()
    elif name == 'skipped-installed-test-with-resealed-archive':
        key = 'current/installed-proof-r1/report.json'
        value = json.loads(expected_data[key])
        value['integration']['skipped'] = 1
        expected_report['installed_package']['skipped'] = 1
        expected_data[key] = json.dumps(value).encode()
    else:
        del expected_data['current/provider-review/vortex-tensor-0.90.0.crate']
    assert actual == expected_data
    expected_report['members'] = report['members']
    expected_report['archive_sha256'] = report['archive_sha256']
    assert report == expected_report

result = dict(status='passed', positive_controls=2, rejected_controls=5,
    exact_fixture_mutations_verified=True, original_packet_unchanged=True,
    observation=receipt, logs=logs, driver_source=driver.decode(), driver_sha256=sha(driver),
    primary_verifier_source=Path(__file__).read_text(),
    scope='Saved evidence consistency only; no runtime tests, builds, benchmarks or installation rerun.')
with (PACKET / 'corruption-controls.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'positive_controls', 'rejected_controls', 'exact_fixture_mutations_verified')}))
