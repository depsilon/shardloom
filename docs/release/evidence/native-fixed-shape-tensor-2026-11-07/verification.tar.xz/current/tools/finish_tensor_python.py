"""Run standard public-shard and isolated installed-native checks separately."""
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
TEST_PYTHON = str(OUT / 'test-env/bin/python')
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
GUARD = OUT / 'tools/guard_tensor.py'
prior = json.loads((OUT / 'python-sequence-r1.json').read_bytes())
assert prior['status'] == 'failed' and prior['active_stage'] == 'python-core-r1'
assert prior['completed'] == ['format-r2', 'tensor-minimal-feature-r2', 'native-clippy-r3',
    'tensor-binding-r2', 'native-build-r2', 'freeze-runtime-r2']
original = json.loads((OUT / 'python-core-r1.json').read_bytes())
assert original['status'] == 'failed' and original['process_group_drained']
clean_env = ['env']
for name in ('SHARDLOOM_REQUIRE_NATIVE_PYTHON', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
             'SHARDLOOM_BIN', 'SHARDLOOM_SURFACE_TEST_BINARY', 'SHARDLOOM_REPO_ROOT',
             'SHARDLOOM_PROFILE_ORDER', 'PYTHONPATH', 'PYTHONHOME'):
    clean_env += ['-u', name]
stages = [
    ('context-native-r1', 300, ['env', 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
        'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(OUT / 'runtime-r2/lib_native.dylib'),
        TEST_PYTHON, '-B', '-m', 'unittest', '-v',
        'python.tests.test_public_context.PublicNativeContextTests']),
    ('python-core-r2', 1800, clean_env + [TEST_PYTHON, '-B', 'scripts/run_python_test_shard.py',
        '--shard', 'core', '--output-dir', str(OUT / 'python-core-r2')]),
    ('static-docs-r1', 300, [TEST_PYTHON, '-B', str(OUT / 'tools/check_tensor_docs.py')]),
    ('installed-wheel-r1', 2400, [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(OUT / 'installed-proof-r1'), '--native-library',
        str(OUT / 'runtime-r2/lib_native.dylib'), '--cli-binary', str(OUT / 'runtime-r2/shardloom'),
        '--wheelhouse', WHEELHOUSE]),
]
receipt = OUT / 'python-followup-sequence-r1.json'
assert not receipt.exists()
state = dict(status='running', prior_sequence='python-sequence-r1.json', completed=[], active_stage=None)


def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')


try:
    for name, timeout, command in stages:
        state['active_stage'] = name
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, '-B', str(GUARD), '--name', name,
            '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_bytes())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
