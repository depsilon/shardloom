"""Seal complete local tensor evidence and preceding integration closeouts."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

from verify_tensor_packet import REQUIRED, verify

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


assert not DEST.exists()
checks = []
for name in REQUIRED:
    result = read(OUT / (name + '.json'))
    assert result['status'] == 'passed' and result['returncode'] == 0 and result['process_group_drained'], name
    log = (OUT / (name + '.log')).read_bytes()
    assert sha(log) == result['log_sha256']
    check = dict(receipt=name + '.json', status='passed', command=result['command'])
    matches = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    if matches:
        check['rust_tests'] = dict(zip(('passed', 'failed', 'ignored'),
            (sum(int(row[i]) for row in matches) for i in range(3))))
    checks.append(check)
build = read(OUT / 'native-build-r2.json')
installed_check = read(OUT / 'installed-wheel-r1.json')
source = {name: identity for name, identity in installed_check['changed_source_inventory'].items()
          if Path(name).suffix in {'.rs', '.py', '.toml'}}
harness = read(OUT / 'harness-correction-r1.json')
validation_only = harness['validation_only_files']
build_source = {name: identity for name, identity in build['changed_source_inventory'].items()
                if Path(name).suffix in {'.rs', '.py', '.toml'}}
assert set(source) == set(build_source) | set(validation_only)
assert not set(build_source).intersection(validation_only)
assert all(source[name] == identity for name, identity in build_source.items())
assert all(source[name] == proof['after'] for name, proof in validation_only.items())
for name, identity in source.items():
    content = (ROOT / name).read_bytes()
    assert len(content) == identity['bytes'] and sha(content) == identity['sha256'], name
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'Cargo.toml', 'Cargo.lock', '**/Cargo.toml'], cwd=ROOT)
installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert sha((OUT / 'runtime-r2' / name).read_bytes()) == installed['integrity'][key]
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert sha(wheel.read_bytes()) == installed['integrity']['wheel_sha256']
core = read(OUT / 'python-core-r2/core.json')
match = re.search(rb'Ran (\d+) tests? in [0-9.]+s', (OUT / 'python-core-r2.log').read_bytes())
assert match
integration_log = (OUT / 'installed-proof-r1/integration.log').read_text()
tensor_tests = sorted(re.findall(r'^(test_fixed_tensor_\S+) .* \.\.\. ok$', integration_log, re.MULTILINE))
assert len(tensor_tests) == len(set(tensor_tests)) == 12
context_tests = sorted(re.findall(r'^test_\S+ \((test_public_context\.\S+)\) \.\.\. ok$', integration_log, re.MULTILINE))
assert len(context_tests) == len(set(context_tests)) == 19

files = {}
selected = [*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('source-blobs/*'),
    *OUT.glob('tools/*.py'), *OUT.glob('installed-proof-r1/*.json'), *OUT.glob('installed-proof-r1/*.log'),
    *OUT.glob('retention-inventory-r1/*'),
    OUT / 'python-core-r1/core.json', OUT / 'python-core-r2/core.json',
    OUT / 'provider-inventory.md', OUT / 'validation-inventory.md',
    OUT / 'coverage-inventory.md', OUT / 'documentation-inventory.md', OUT / 'review-notes.md', OUT / 'provider-review/receipt.json',
    OUT / 'provider-review/registry.json', OUT / 'provider-review/vortex-tensor-0.90.0.crate']
for path in sorted(set(selected)):
    if path.name.startswith('package-evidence-'):
        continue
    assert path.is_file() and not path.is_symlink()
    files['current/' + path.relative_to(OUT).as_posix()] = path.read_bytes()
integrations = {}
for prefix, number, folder, stem in [
    ('managed', 1659, 'managed-binary-2026-11-06', 'binary'),
    ('dependency', 1660, 'dependency-followup-2026-11-06', 'dependency'),
]:
    prior = OUT.parent / folder
    name = stem + '-closeout-r1.json'
    closeout = read(prior / name)
    assert closeout['status'] == 'complete'
    files[prefix + '/' + name] = (prior / name).read_bytes()
    for relative, identity in closeout['receipts'].items():
        content = (prior / relative).read_bytes()
        assert len(content) == identity['bytes'] and sha(content) == identity['sha256']
        files[prefix + '/' + relative] = content
    integrations[prefix] = dict(pr=number, merge_commit=closeout['merge_commit'],
        pr_checks_passed=closeout['pr_checks_passed'], main_checks_passed=closeout['main_checks_passed'])
assert sum(len(raw) for raw in files.values()) < 64 << 20
dispositions = {
    'current/native-clippy-r1.json': 'One signed-to-unsigned cast in a zero-width test fixture was replaced by a checked conversion; strict native Clippy passes at r2.',
    'current/python-core-r1.json': 'The initial mixed run injected the real CLI into resolver fixtures and a raw dylib path into suffix-based Python loaders. One stale public-context error assertion was corrected against the unchanged native diagnostic. The standard core shard and expanded clean installed-native proof pass separately; all original failures remain preserved.',
    'current/python-sequence-r1.json': 'Stopped after the original mixed core run failed; its successful build and focused stages remain valid. The separate Python follow-up sequence completes corrected core, documentation and expanded installed-native proof.',
}
failures = []
for name, raw in sorted(files.items()):
    if name.startswith('current/') and name.count('/') == 1 and name.endswith('.json'):
        result = json.loads(raw)
        if result.get('status') == 'failed':
            assert name in dispositions, name
            failures.append(dict(receipt=name, disposition=dispositions[name]))
members = [dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(files.items())]
DEST.mkdir()
archive_path = DEST / 'verification.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for row in members:
        info = tarfile.TarInfo(row['path'])
        info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
        archive.addfile(info, io.BytesIO(files[row['path']]))
report = dict(schema_version='shardloom.fixed_shape_tensor_acceptance.v1', status='local_acceptance_passed',
    source_base=build['head'], code_snapshot=source, changed_dependencies=False, checks=checks,
    source_verification_scope=read(OUT / 'runtime-production-continuity-r2.json')['verification_scope'],
    validation_fixture_correction=read(OUT / 'harness-correction-r1.json')['correction'],
    python_core=dict(status=core['status'], discovered_test_cases=core['test_count'],
        reported_test_runs=int(match.group(1)), skip_records=core['skipped_count'],
        failures=core['failure_count'], errors=core['error_count']),
    installed_package=installed['integration'], tensor_installed_tests=tensor_tests,
    context_installed_tests=context_tests,
    cli_sha256=installed['integrity']['cli_sha256'], native_library_sha256=installed['integrity']['native_library_sha256'],
    wheel_sha256=installed['integrity']['wheel_sha256'], original_failures=failures,
    preceding_integrations=integrations, hosted_integration='pending', publication_attempted=False,
    performance_claim=False, whole_item_19_complete=False,
    contract='Checked fixed-shape tensor identity over native fixed lists, ordinary relational payload carriage, streaming/spill, all five native write interfaces and explicit lossless compatibility boundaries.',
    limitations=['Fixed shapes only; variable shapes and other rich representations remain queued.',
        'Boolean, signed/unsigned 8/16/32/64-bit integers, Float32 and Float64 only.',
        'Tensor arithmetic and key roles are explicitly unsupported.',
        'Text, Avro and ORC writers refuse tensor metadata loss.',
        'PyArrow may normalize canonical tensor types; ShardLoom to_arrow helpers restore authoritative metadata over shared numeric buffers.',
        'PyArrow may reject intermediate shape products that overflow before a later zero; native storage remains valid.',
        'Existing opt-in Rust tests remain ignored; no performance campaign or publication was run.'],
    archive=archive_path.name, archive_sha256=sha(archive_path.read_bytes()), members=members)
(DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
(DEST / 'verify.py').write_bytes((OUT / 'tools/verify_tensor_packet.py').read_bytes())
result = verify(DEST, ROOT)
print(json.dumps(result))
