"""Retire only sealed tensor intermediates after exact hosted acceptance."""
import argparse
import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import subprocess
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
PRIOR = OUT.parent / 'dependency-followup-2026-11-06'
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
INVENTORY = OUT / 'retention-inventory-r1'
TARGET = OUT / 'tensor-retirement-r1'
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
spec = importlib.util.spec_from_file_location('retirement_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.E = OUT.parent


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=base.sha(path))


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


def preparation():
    value = read(OUT / 'delivery-acceptance-r1.json')
    assert value['status'] == 'passed' and value['runtime_sources_match_build']
    prior = read(PRIOR / 'dependency-closeout-r1.json')
    assert prior['status'] == 'complete' and prior['merge_commit'] == value['base']
    return value


def roots():
    result = {
        str(PRIOR / 'runtime-r1/shardloom'): 'Superseded accepted dependency CLI; final tensor CLI retained.',
        str(PRIOR / 'runtime-r1/lib_native.dylib'): 'Superseded accepted dependency native library; final tensor library retained.',
        str(PRIOR / 'installed-proof-r1/dist'): 'Superseded dependency wheel; final installed-tested tensor wheel retained.',
        str(OUT / 'runtime-r1/shardloom'): 'Earlier tensor build; exact final tested build retained.',
        str(OUT / 'runtime-r1/lib_native.dylib'): 'Earlier tensor library; exact final tested build retained.',
        str(OUT / 'installed-proof-r1/package'): 'Completed package staging; Git and installed-tested wheel retained.',
        str(OUT / 'installed-proof-r1/venv'): 'Completed uninstalled proof environment; locked wheelhouse retained.',
        str(OUT / 'provider-review/source'): 'All reviewed source members preserved exactly in the checksum-bound crate archive.',
        str(OUT / 'packet-controls-r1'): 'Exact driver, mutations and full observation/logs preserved in the committed controls record.',
    }
    paths = [Path(name) for name in result]
    assert all(path.exists() and not path.is_symlink() and path.resolve() == path for path in paths)
    assert not any(a != b and a.is_relative_to(b) for a in paths for b in paths)
    assert str(OUT / 'test-env') not in result
    return result


def retained():
    acceptance = read(PACKET / 'acceptance.json')
    installed = read(OUT / 'installed-proof-r1/report.json')
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['integration'] == acceptance['installed_package'] == dict(
        tests=350, failures=0, errors=0, skipped=0, status='passed')
    files = [PACKET / name for name in ('acceptance.json', 'verification.tar.xz', 'verify.py',
                                      'README.md', 'corruption-controls.json')]
    for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
        path = OUT / 'runtime-r2' / name
        assert base.sha(path) == installed['integrity'][key] == acceptance[key]
        files.append(path)
    wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
    assert base.sha(wheel) == installed['integrity']['wheel_sha256'] == acceptance['wheel_sha256']
    files += [wheel, OUT / 'installed-proof-r1/report.json', OUT / 'delivery-acceptance-r1.json',
              INVENTORY / 'receipt.json', INVENTORY / 'primary-acceptance.json',
              INVENTORY / 'identities.json.xz', INVENTORY / 'inventory_driver.py']
    return {str(path): identity(path) for path in files}


def inputs():
    prior_manifest = json.loads(lzma.decompress((PRIOR / 'dependency-retirement-r1/manifest.json.xz').read_bytes()))
    expected = prior_manifest['input_generations']
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def archived_sources():
    provider = read(OUT / 'provider-review/receipt.json')
    archive_path = OUT / 'provider-review/vortex-tensor-0.90.0.crate'
    assert base.sha(archive_path) == provider['checksum']
    with tarfile.open(archive_path, 'r:gz') as archive:
        entries = {entry.name.removeprefix('vortex-tensor-0.90.0/'): entry
                   for entry in archive.getmembers() if entry.isfile()}
        assert len(entries) == 27 and set(entries) == set(provider['files'])
        for name, expected in provider['files'].items():
            raw = archive.extractfile(entries[name]).read()
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected
            assert identity(OUT / 'provider-review/source' / name) == expected
    acceptance = read(PACKET / 'acceptance.json')
    assert base.sha(PACKET / 'verification.tar.xz') == acceptance['archive_sha256']
    with tarfile.open(PACKET / 'verification.tar.xz', 'r:xz') as archive:
        assert archive.extractfile('current/provider-review/vortex-tensor-0.90.0.crate').read() == archive_path.read_bytes()
        assert archive.extractfile('current/provider-review/receipt.json').read() == (OUT / 'provider-review/receipt.json').read_bytes()
    controls = read(PACKET / 'corruption-controls.json')
    assert controls['status'] == 'passed' and controls['exact_fixture_mutations_verified']
    assert controls['observation'] == read(OUT / 'packet-controls-r1/receipt.json')
    assert controls['driver_source'] == (OUT / 'tools/check_tensor_packet_controls.py').read_text()
    for name, content in controls['logs'].items():
        assert (OUT / 'packet-controls-r1' / (name + '.log')).read_text() == content
    old = read(PRIOR / 'dependency-closeout-r1.json')
    for path, expected in old['retained_runtime_and_wheel'].items():
        assert identity(Path(path)) == expected
    frozen = read(OUT / 'runtime-r1-identity.json')
    assert frozen['status'] == 'passed'
    for row in frozen['files']:
        assert identity(Path(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')}


def plan():
    assert not TARGET.exists()
    prep = preparation()
    proof = read(INVENTORY / 'primary-acceptance.json')
    assert proof['status'] == 'passed_plan_review' and not proof['deletion_performed']
    assert identity(INVENTORY / 'identities.json.xz') == proof['inventory']
    assert identity(INVENTORY / 'receipt.json') == proof['original_inventory_receipt']
    inventory = json.loads(lzma.decompress((INVENTORY / 'identities.json.xz').read_bytes()))
    selected = roots()
    assert set(inventory['roots']) == set(proof['roots']) == set(selected) - {str(OUT / 'packet-controls-r1')}
    existing = [row for name in sorted(inventory['roots']) for row in inventory['roots'][name]]
    assert len(existing) == proof['entries']
    for row in existing:
        base.unchanged(row)
    by_root = dict(inventory['roots'])
    by_root[str(OUT / 'packet-controls-r1')] = base.inventory(OUT / 'packet-controls-r1')
    rows = [row for name in sorted(selected) for row in by_root[name]]
    assert len(rows) == len({row['path'] for row in rows})
    kept, generations = retained(), inputs()
    assert not (set(kept) | set(generations)).intersection(row['path'] for row in rows)
    archived_sources()
    manifest = dict(roots=selected, entries=rows, retained=kept, input_generations=generations,
        accepted_head=prep['head'], accepted_tree=prep['tree'])
    TARGET.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode())
    (TARGET / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', head=prep['head'], tree=prep['tree'],
        roots=len(selected), entries=len(rows), regular_files=sum(row['kind'] == 'regular' for row in rows),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        manifest_sha256=base.sha(TARGET / 'manifest.json.xz'),
        script_sha256=base.sha(Path(__file__)), helper_sha256=base.sha(HELPER),
        inventory_review=identity(INVENTORY / 'primary-acceptance.json'),
        retained_test_environment='The current tensor test environment is retained for immediately following authorized queue work.')
    (TARGET / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


def apply(main_path, pre_path):
    prep, main, pre = preparation(), read(main_path), read(pre_path)
    assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert main['pr'] == pre['pr'] and main['pr_head'] == pre['head'] == prep['head']
    assert main['source_tree'] == pre['source_tree'] == prep['tree']
    assert main['premerge_sha256'] == base.sha(pre_path) and pre['tree_matches_synthetic']
    assert main['commit_verification']['verified'] is True
    assert git('rev-parse', 'HEAD') == main['source_commit'] and not git('status', '--porcelain')
    assert git('branch', '--show-current') == 'main'
    summary = read(TARGET / 'plan.json')
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(TARGET / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET / 'manifest.json.xz').read_bytes()))
    selected, rows = manifest['roots'], manifest['entries']
    assert manifest['accepted_head'] == prep['head'] and manifest['accepted_tree'] == prep['tree']
    assert roots() == selected and retained() == manifest['retained'] and inputs() == manifest['input_generations']
    archived_sources()
    for _ in range(2):
        assert [row for name in sorted(selected) for row in base.inventory(Path(name))] == rows
        base.closed(selected)
    receipt = dict(status='running', removed=0, main=identity(main_path), premerge=identity(pre_path),
        prior_dependency_closeout=identity(PRIOR / 'dependency-closeout-r1.json'),
        accepted_head=prep['head'], accepted_tree=prep['tree'], manifest_sha256=summary['manifest_sha256'])
    assert not (TARGET / 'receipt.json').exists()
    try:
        for row in sorted(rows, key=lambda value: len(Path(value['path']).parts), reverse=True):
            path = Path(row['path'])
            base.unchanged(row, removing_children=row['kind'] == 'directory')
            path.rmdir() if row['kind'] == 'directory' else path.unlink()
            receipt['removed'] += 1
        assert all(not Path(name).exists() and not Path(name).is_symlink() for name in selected)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
            str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)
        receipt.update(status='passed', retained_files_unchanged=True, input_generations_unchanged=True,
            portable_replay_after_retirement='passed', regular_files=summary['regular_files'],
            symlinks=summary['symlinks'], regular_bytes=summary['regular_bytes'],
            provider_files_preserved_in_archive=27, control_observations_preserved=True)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (TARGET / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    parser.add_argument('--main', type=Path)
    parser.add_argument('--pre', type=Path)
    args = parser.parse_args()
    if args.mode == 'plan':
        plan()
    else:
        assert args.main and args.pre
        apply(args.main, args.pre)
