"""Create this task's optional Arrow test environment from the retained wheelhouse."""
from pathlib import Path
import hashlib
import json
import subprocess
import venv

out = Path(__file__).resolve().parents[1]
target = out / 'test-env'
wheel = Path('/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse/pyarrow-25.0.1-cp313-cp313-macosx_12_0_arm64.whl')
assert not target.exists() and wheel.is_file() and not wheel.is_symlink()
identity = hashlib.sha256(wheel.read_bytes()).hexdigest()
venv.EnvBuilder(with_pip=True).create(target)
python = target / 'bin/python'
subprocess.run([str(python), '-m', 'pip', 'install', '--no-index', '--no-deps', str(wheel)], check=True, timeout=180)
result = subprocess.check_output([str(python), '-B', '-c',
    'import json,pyarrow; print(json.dumps(dict(version=pyarrow.__version__,path=pyarrow.__file__)))'], text=True, timeout=30)
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == identity
(out / 'test-environment-r1.json').write_text(json.dumps(dict(status='passed', source_wheel=str(wheel),
    sha256=identity, installed=json.loads(result)), indent=2) + '\n')
print(result)
