"""Adopt an accepted signed tensor merge after its dependency closeout."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
PRIOR_ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
PRIOR = OUT.parent / 'dependency-followup-2026-11-06'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', type=Path, required=True)
parser.add_argument('--merge-receipt', type=Path, required=True)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def git(root, *arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, text=True, timeout=90).strip()


def main_owners():
    blocks = git(ROOT, 'worktree', 'list', '--porcelain').split('\n\n')
    return [block.splitlines()[0].removeprefix('worktree ') for block in blocks
            if 'branch refs/heads/main' in block.splitlines()]


destination = OUT / 'tensor-main-checkout-r1.json'
assert not destination.exists()
pre = read(args.pre)
prep = read(OUT / 'delivery-acceptance-r1.json')
merged = read(args.merge_receipt)
prior = read(PRIOR / 'dependency-closeout-r1.json')
assert merged.get('isError') is False and merged['structuredContent']['merged'] is True
new = merged['structuredContent']['sha']
old, head, tree = pre['base'], pre['head'], prep['tree']
record = dict(status='needs_attention', merge_commit=new, source_tree=tree,
              observed_at=datetime.now(timezone.utc).isoformat())
try:
    assert prep['status'] == 'passed' and prep['head'] == head and prep['base'] == old
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert prior['status'] == 'complete' and prior['merge_commit'] == old
    for suffix in ('final-checks-r1', 'final-review-r1'):
        final = read(OUT / ('pr' + str(pre['pr']) + '-' + suffix + '.json'))
        assert final['status'] == 'passed' and final['head'] == head and final['base'] == old
    assert git(PRIOR_ROOT, 'rev-parse', 'HEAD') == old
    assert git(PRIOR_ROOT, 'branch', '--show-current') == 'main'
    assert git(ROOT, 'rev-parse', 'HEAD') == head
    assert git(ROOT, 'branch', '--show-current') == 'codex/native-tensor-lifecycle'
    assert not git(PRIOR_ROOT, 'status', '--porcelain') and not git(ROOT, 'status', '--porcelain')
    assert git(ROOT, 'rev-parse', head + '^{tree}') == tree
    assert main_owners() == [str(PRIOR_ROOT)]
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', 'main'], cwd=ROOT, check=True, timeout=90)
    assert git(ROOT, 'rev-parse', 'origin/main') == new
    assert git(ROOT, 'rev-parse', new + '^{tree}') == tree
    assert git(ROOT, 'show', '-s', '--format=%P', new).split() == [old, head]
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/commits/' + new], cwd=ROOT, timeout=50)
    assert len(raw) < 8 << 20
    commit = json.loads(raw)
    assert commit['sha'] == new and commit['commit']['tree']['sha'] == tree
    assert [row['sha'] for row in commit['parents']] == [old, head]
    assert commit['commit']['verification']['verified'] is True
    record.update(signed_commit=commit, parents=[old, head],
        prior_dependency_closeout_sha256=hashlib.sha256((PRIOR / 'dependency-closeout-r1.json').read_bytes()).hexdigest())
    subprocess.run(['git', 'switch', '--detach', old], cwd=PRIOR_ROOT, check=True, timeout=90)
    assert not main_owners() and git(ROOT, 'rev-parse', 'refs/heads/main') == old
    subprocess.run(['git', 'update-ref', 'refs/heads/main', new, old], cwd=ROOT, check=True, timeout=90)
    subprocess.run(['git', 'switch', 'main'], cwd=ROOT, check=True, timeout=90)
    assert main_owners() == [str(ROOT)]
    assert git(ROOT, 'rev-parse', 'HEAD') == new and git(ROOT, 'rev-parse', 'HEAD^{tree}') == tree
    assert git(PRIOR_ROOT, 'rev-parse', 'HEAD') == old and not git(PRIOR_ROOT, 'branch', '--show-current')
    assert not git(ROOT, 'status', '--porcelain') and not git(PRIOR_ROOT, 'status', '--porcelain')
    record.update(status='passed', active_worktree=str(ROOT), main_branch='main',
        previous_worktree=str(PRIOR_ROOT), previous_worktree_detached_at=old,
        both_worktrees_clean=True, accepted_file_trees_unchanged=True)
except BaseException as error:
    record['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with destination.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'merge_commit', 'source_tree', 'active_worktree')}))
