"""Preserve the invalid mixed-run setup and exact test-only correction."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
BASE = '2df6460cae18eb55b2a0d680a55721d438bc495d'
LOG = OUT / 'python-core-r1.log'
REPLACEMENTS = {
    'python/tests/test_public_context.py': [
        ('            self.assertIn("source generation changed", str(changed.exception))',
         '            self.assertEqual(changed.exception.diagnostics[0].code, "SL_INVALID_INPUT")\n'
         '            self.assertIn("prepared source changed; prepare the source again", str(changed.exception))')],
    'scripts/prove_native_python_wheel.py': [
        ('            "test_recursion_policy.py")',
         '            "test_recursion_policy.py", "test_public_context.py")'),
        ('               PIP_DISABLE_PIP_VERSION_CHECK="1", SHARDLOOM_REQUIRE_NATIVE_PYTHON="1")',
         '               PIP_DISABLE_PIP_VERSION_CHECK="1", SHARDLOOM_REQUIRE_NATIVE_PYTHON="1",\n'
         '               SHARDLOOM_TEST_INSTALLED_QUICKSTART="1")')],
}


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


result = json.loads((OUT / 'python-core-r1.json').read_bytes())
core = json.loads((OUT / 'python-core-r1/core.json').read_bytes())
log = LOG.read_bytes()
assert result['status'] == 'failed' and result['process_group_drained']
assert hashlib.sha256(log).hexdigest() == result['log_sha256']
assert core['status'] == 'failed' and core['failure_count'] == 6 and core['error_count'] == 4
assert re.search(rb'Ran 1070 tests in [0-9.]+s', log)
files = {}
for name, replacements in REPLACEMENTS.items():
    before = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=ROOT)
    after = (ROOT / name).read_bytes()
    expected = before.decode()
    for old, new in replacements:
        assert expected.count(old) == 1, name
        expected = expected.replace(old, new, 1)
    assert expected.encode() == after, name
    for raw in (before, after):
        path = OUT / 'source-blobs' / identity(raw)['sha256']
        if path.exists():
            assert path.read_bytes() == raw
        else:
            path.write_bytes(raw)
    files[name] = dict(before=identity(before), after=identity(after), replacements=replacements)
native_source = subprocess.check_output(['git', 'show', BASE + ':shardloom-vortex/src/source_identity.rs'], cwd=ROOT)
assert b'prepared source changed; prepare the source again' in native_source
assert (ROOT / 'shardloom-vortex/src/source_identity.rs').read_bytes() == native_source
path = OUT / 'source-blobs' / identity(native_source)['sha256']
if path.exists():
    assert path.read_bytes() == native_source
else:
    path.write_bytes(native_source)
report = dict(status='passed', source_base=BASE, original_outcome=core,
    original_log=identity(log), validation_only_files=files,
    unchanged_diagnostic_source=dict(path='shardloom-vortex/src/source_identity.rs', **identity(native_source)),
    causes=[
        dict(failures=4, cause='SHARDLOOM_BIN forced the real CLI into missing-binary and fixture-resolution tests.'),
        dict(failures=1, errors=4, cause='Five native fixture loaders infer the extension loader from the suffix; raw lib_native.dylib does not have the installed Python extension suffix.'),
        dict(failures=1, cause='One public-context test expected older source-generation wording; the pre-existing native diagnostic correctly refused the changed source.')],
    correction='Run the public core shard with the standard unset overrides; use the isolated installed wheel for native loaders. Update only the stale assertion and include public-context ownership/cross-transport tests in installed proof with its explicit clean-package flag.',
    runtime_implementation_changed=False, native_rebuild_required=False,
    followup='python-followup-sequence-r1.json')
with (OUT / 'harness-correction-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=report['status'], validation_only_files=list(files))))
