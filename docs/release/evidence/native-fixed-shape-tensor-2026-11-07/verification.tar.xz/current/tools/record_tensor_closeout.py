"""Bind the fixed-tensor merge, main checks, retained runtime and cleanup."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
PRIOR = OUT.parent / 'dependency-followup-2026-11-06'
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', type=Path, required=True)
parser.add_argument('--main', type=Path, required=True)
parser.add_argument('--reconciliation', type=Path, required=True)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


prep_path = OUT / 'delivery-acceptance-r1.json'
prep, pre, main = read(prep_path), read(args.pre), read(args.main)
assert prep['status'] == 'passed' and prep['runtime_sources_match_build']
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
assert main['pr'] == pre['pr']
assert main['pr_head'] == pre['head'] == prep['head']
assert main['source_tree'] == pre['source_tree'] == prep['tree']
assert pre['base_branch'] == 'main' and pre['tree_matches_synthetic']
assert main['premerge_sha256'] == identity(args.pre)['sha256']
assert pre['acceptance_sha256'] == identity(prep_path)['sha256']
assert pre['review']['commit_sha'] == prep['head'] and pre['review']['status'] == 'completed'
assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
assert main['commit_verification']['verified'] is True
assert git('rev-parse', 'HEAD') == main['source_commit'] and git('rev-parse', 'HEAD^{tree}') == prep['tree']
assert git('branch', '--show-current') == 'main' and not git('status', '--porcelain')
assert git('show', '-s', '--format=%P', 'HEAD').split() == [pre['base'], prep['head']]
prior = read(PRIOR / 'dependency-closeout-r1.json')
assert prior['status'] == 'complete' and prior['merge_commit'] == pre['base'] == prep['base']
pr = str(pre['pr'])
final_checks = read(OUT / ('pr' + pr + '-final-checks-r1.json'))
final_review = read(OUT / ('pr' + pr + '-final-review-r1.json'))
assert final_checks['status'] == final_review['status'] == 'passed'
assert final_checks['head'] == final_review['head'] == prep['head']
assert final_checks['base'] == final_review['base'] == pre['base']
assert final_checks['premerge_sha256'] == identity(args.pre)['sha256']

acceptance = read(PACKET / 'acceptance.json')
for filename, key in [('acceptance.json', 'acceptance'), ('verification.tar.xz', 'archive'),
                      ('verify.py', 'verifier'), ('corruption-controls.json', 'corruption_controls')]:
    assert identity(PACKET / filename) == prep[key]
for relative, expected in acceptance['code_snapshot'].items():
    assert identity(ROOT / relative) == expected
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
    str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)
installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == acceptance['installed_package'] == dict(
    tests=350, failures=0, errors=0, skipped=0, status='passed')
kept = {}
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    path = OUT / 'runtime-r2' / name
    assert identity(path)['sha256'] == installed['integrity'][key] == acceptance[key]
    kept[str(path)] = identity(path)
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert identity(wheel)['sha256'] == installed['integrity']['wheel_sha256'] == acceptance['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for relative, expected in acceptance['code_snapshot'].items():
        if relative.startswith('python/src/shardloom/'):
            raw = archive.read(relative.removeprefix('python/src/'))
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected
kept[str(wheel)] = identity(wheel)

retirement_path = OUT / 'tensor-retirement-r1/receipt.json'
retirement = read(retirement_path)
assert retirement['status'] == 'passed' and retirement['accepted_head'] == prep['head']
assert retirement['accepted_tree'] == prep['tree']
assert retirement['main'] == identity(args.main) and retirement['premerge'] == identity(args.pre)
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
reconciliation = read(args.reconciliation)
assert reconciliation['status'] == 'passed' and reconciliation['open_prs'] == [] and reconciliation['pages_complete']
receipts = [prep_path, args.pre, args.main, args.reconciliation, retirement_path,
    OUT / ('pr' + pr + '-create-r1.json'), OUT / ('pr' + pr + '-merge-r1.json'),
    OUT / ('pr' + pr + '-final-checks-r1.json'), OUT / ('pr' + pr + '-final-review-r1.json'),
    OUT / 'tools/advance_tensor_main.py', OUT / 'tensor-main-checkout-r1.json',
    OUT / 'workspace-sequence-r1.json', OUT / 'python-sequence-r1.json',
    OUT / 'python-followup-sequence-r1.json', OUT / 'runtime-production-continuity-r2.json',
    OUT / 'harness-correction-r1.json', OUT / 'package-evidence-r1.json', OUT / 'final-docs-r1.json',
    OUT / 'tensor-retirement-r1/plan.json', OUT / 'tensor-retirement-r1/manifest.json.xz',
    OUT / 'tensor-retirement-apply-r1.json', OUT / 'installed-proof-r1/report.json']
receipts += sorted(OUT.glob('codeql-*.json'))
for relative, digest in main['raw_sources'].items():
    path = OUT / relative
    assert identity(path)['sha256'] == digest
    receipts.append(path)
report = dict(status='complete', observed_at=datetime.now(timezone.utc).isoformat(),
    pr_url='https://github.com/depsilon/shardloom/pull/' + pr, pr_head=prep['head'],
    merge_commit=main['source_commit'], source_tree=prep['tree'], pr_checks_passed=58, main_checks_passed=55,
    review_findings=False, review_url=pre['review_url'], main_ci_url=main['ci_run_url'],
    no_open_prs_at_observation=True, validation=acceptance['checks'],
    core_python=acceptance['python_core'], installed_package=installed['integration'],
    tensor_installed_tests=acceptance['tensor_installed_tests'],
    context_installed_tests=acceptance['context_installed_tests'],
    source_verification_scope=acceptance['source_verification_scope'],
    validation_fixture_correction=acceptance['validation_fixture_correction'],
    original_failures_and_review_corrections_preserved=True, retained_runtime_and_wheel=kept,
    retired_regular_files=retirement['regular_files'], retired_symlinks=retirement['symlinks'],
    current_inputs_unchanged=True, portable_replay_after_retirement='passed',
    committed_evidence={path.relative_to(ROOT).as_posix(): identity(path) for path in sorted(PACKET.iterdir()) if path.is_file()},
    receipts={path.relative_to(OUT).as_posix(): identity(path) for path in receipts},
    prior_dependency_closeout=identity(PRIOR / 'dependency-closeout-r1.json'),
    closeout_script=identity(Path(__file__)), working_tree_clean=True,
    whole_item_19_complete=False, next_queue_item='variable-shape tensor lifecycle under item 19',
    shared_compiler_outputs='Retained for immediately following authorized native work.',
    test_environment='The current tensor test environment remains for the next authorized tensor unit.',
    publication_attempted=False, performance_campaign_run=False, performance_claim=False)
with (OUT / 'tensor-closeout-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'merge_commit', 'pr_checks_passed', 'main_checks_passed', 'installed_package', 'retired_regular_files')}))
