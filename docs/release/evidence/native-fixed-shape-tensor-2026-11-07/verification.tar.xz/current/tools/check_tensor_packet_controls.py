"""Challenge saved-evidence verification with finite corrupted packet controls."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
DEST = OUT / 'packet-controls-r1'
assert not DEST.exists()
DEST.mkdir()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save_report(directory, report):
    (directory / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')


def clone(name):
    directory = DEST / name
    directory.mkdir()
    for filename in ('acceptance.json', 'verification.tar.xz', 'verify.py'):
        shutil.copyfile(PACKET / filename, directory / filename)
    return directory, json.loads((directory / 'acceptance.json').read_bytes())


def rewrite(directory, report, change):
    with tarfile.open(directory / 'verification.tar.xz', 'r:xz') as archive:
        entries = {entry.name: archive.extractfile(entry).read() for entry in archive.getmembers()}
    change(entries, report)
    report['members'] = [dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(entries.items())]
    with tarfile.open(directory / 'verification.tar.xz', 'w:xz', preset=1) as archive:
        for row in report['members']:
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
            archive.addfile(info, io.BytesIO(entries[row['path']]))
    report['archive_sha256'] = sha((directory / 'verification.tar.xz').read_bytes())
    save_report(directory, report)


results = []


def run(name, directory, accepted, repo_root=None):
    command = [sys.executable, '-I', str(directory / 'verify.py'), '--packet', str(directory)]
    if repo_root:
        command += ['--repo-root', str(repo_root)]
    result = subprocess.run(command, capture_output=True, timeout=120)
    raw = result.stdout + result.stderr
    assert len(raw) < 1 << 20
    (DEST / (name + '.log')).write_bytes(raw)
    results.append(dict(name=name, returncode=result.returncode, expected='accept' if accepted else 'reject',
                        log_sha256=sha(raw)))
    assert (result.returncode == 0) == accepted, name


try:
    run('original', PACKET, True, ROOT)
    relocated, _ = clone('relocated')
    run('relocated', relocated, True)
    directory, report = clone('archive-byte-corruption')
    raw = bytearray((directory / 'verification.tar.xz').read_bytes())
    raw[len(raw) // 2] ^= 1
    (directory / 'verification.tar.xz').write_bytes(raw)
    run('archive-byte-corruption', directory, False)

    directory, report = clone('summary-count-corruption')
    report['python_core']['reported_test_runs'] += 1
    save_report(directory, report)
    run('summary-count-corruption', directory, False)

    directory, report = clone('failed-check-with-resealed-archive')

    def failed_check(entries, _):
        name = 'current/native-tests-r1.json'
        value = json.loads(entries[name])
        value['status'], value['returncode'] = 'failed', 101
        entries[name] = json.dumps(value).encode()

    rewrite(directory, report, failed_check)
    run('failed-check-with-resealed-archive', directory, False)

    directory, report = clone('skipped-installed-test-with-resealed-archive')

    def skipped_test(entries, report):
        name = 'current/installed-proof-r1/report.json'
        value = json.loads(entries[name])
        value['integration']['skipped'] = 1
        report['installed_package']['skipped'] = 1
        entries[name] = json.dumps(value).encode()

    rewrite(directory, report, skipped_test)
    run('skipped-installed-test-with-resealed-archive', directory, False)

    directory, report = clone('missing-provider-with-resealed-archive')
    rewrite(directory, report, lambda entries, _: entries.pop('current/provider-review/vortex-tensor-0.90.0.crate'))
    run('missing-provider-with-resealed-archive', directory, False)
    receipt = dict(status='passed', positive_controls=2, rejected_controls=5, results=results,
        original_packet_sha256=sha((PACKET / 'acceptance.json').read_bytes()),
        original_archive_sha256=sha((PACKET / 'verification.tar.xz').read_bytes()),
        verifier_sha256=sha((PACKET / 'verify.py').read_bytes()), driver_sha256=sha(Path(__file__).read_bytes()))
except BaseException as error:
    receipt = dict(status='failed', results=results, error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
