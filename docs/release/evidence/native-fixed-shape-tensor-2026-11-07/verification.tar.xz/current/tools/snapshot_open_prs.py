"""Preserve the complete current open-PR REST collection, including raw pages."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists() and args.output.parent.is_dir()
rows, pages = [], []
for page in range(1, 21):
    endpoint = ('repos/depsilon/shardloom/pulls?state=open&sort=created&direction=asc'
                '&per_page=100&page=' + str(page))
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', endpoint], timeout=50)
    assert len(raw) < 8 << 20
    value = json.loads(raw)
    assert isinstance(value, list) and all(row['state'] == 'open' for row in value)
    pages.append(dict(endpoint=endpoint, sha256=hashlib.sha256(raw).hexdigest(), raw_json=raw.decode()))
    rows += value
    if len(value) < 100:
        break
else:
    raise AssertionError('Open-PR collection exceeded bounded pagination; inspect explicitly.')
assert len({row['number'] for row in rows}) == len(rows)
report = dict(status='passed' if not rows else 'needs_reconciliation',
    observed_at=datetime.now(timezone.utc).isoformat(), repository='depsilon/shardloom',
    pages_complete=True, open_prs=[dict(number=row['number'], title=row['title'],
        head=row['head']['sha'], base=row['base']['ref'], url=row['html_url']) for row in rows],
    raw_pages=pages, observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with args.output.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'pages_complete', 'open_prs')}))
