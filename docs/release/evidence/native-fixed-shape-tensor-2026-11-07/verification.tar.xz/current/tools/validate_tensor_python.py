"""Validate final tensor helpers, rebuild the exact runtime, then prove its wheel."""
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
TEST_PYTHON = str(OUT / 'test-env/bin/python')
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
GUARD = OUT / 'tools/guard_tensor.py'
ENV = ['env', 'CARGO_PROFILE_DEV_DEBUG=0', 'CARGO_PROFILE_TEST_DEBUG=0', 'PYO3_PYTHON=' + PYTHON]
RUNTIME_ENV = ['env', 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
    'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(OUT / 'runtime-r2/lib_native.dylib'),
    'SHARDLOOM_SURFACE_TEST_BINARY=' + str(OUT / 'runtime-r2/shardloom'),
    'SHARDLOOM_BIN=' + str(OUT / 'runtime-r2/shardloom')]
INITIAL_RUNTIME_ENV = [value.replace('/runtime-r2/', '/runtime-r1/') for value in RUNTIME_ENV]
assert json.loads((OUT / 'workspace-sequence-r1.json').read_bytes())['status'] == 'passed'
stages = [
    ('format-r2', 120, ['cargo', 'fmt', '--all', '--', '--check']),
    ('tensor-minimal-feature-r2', 1200, ENV + ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'vortex-local-primitives', '--locked', '--offline']),
    ('native-clippy-r3', 3600, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment', '--locked', '--offline', '--', '-D', 'warnings']),
    ('tensor-binding-r2', 900, INITIAL_RUNTIME_ENV + [TEST_PYTHON, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_native_tensor*binding.py', '-v']),
    ('native-build-r2', 5400, ENV + ['cargo', 'build', '--locked', '--offline', '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime-r2', 300, [PYTHON, '-B', str(OUT / 'tools/freeze_runtime.py'), '--build', 'native-build-r2.json', '--name', 'runtime-r2']),
    ('python-core-r1', 1800, RUNTIME_ENV + [TEST_PYTHON, '-B', 'scripts/run_python_test_shard.py', '--shard', 'core', '--output-dir', str(OUT / 'python-core-r1')]),
    ('static-docs-r1', 300, [TEST_PYTHON, '-B', str(OUT / 'tools/check_tensor_docs.py')]),
    ('installed-wheel-r1', 2400, [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py', '--output-dir', str(OUT / 'installed-proof-r1'), '--native-library', str(OUT / 'runtime-r2/lib_native.dylib'), '--cli-binary', str(OUT / 'runtime-r2/shardloom'), '--wheelhouse', WHEELHOUSE]),
]
receipt = OUT / 'python-sequence-r1.json'
assert not receipt.exists()
state = {'status': 'running', 'completed': [], 'active_stage': None}

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for name, timeout, command in stages:
        state['active_stage'] = name
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_text())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
