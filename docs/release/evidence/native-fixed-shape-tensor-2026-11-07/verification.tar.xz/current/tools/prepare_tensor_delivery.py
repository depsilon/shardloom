"""Bind final tensor source, portable proof and tested binaries to a clean commit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-fixed-shape-tensor-2026-11-07'
BASE = '2df6460cae18eb55b2a0d680a55721d438bc495d'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


assert not git('status', '--porcelain')
assert git('branch', '--show-current') == 'codex/native-tensor-lifecycle'
head = git('rev-parse', 'HEAD')
report = read(PACKET / 'acceptance.json')
assert report['status'] == 'local_acceptance_passed' and report['source_base'] == BASE
assert git('show', '-s', '--format=%P', head).split() == [BASE]
expected_files = set(report['code_snapshot']) | {
    'docs/architecture/native-fixed-tensor-lifecycle-2026-11-07.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/phased-execution-completed-ledger.md',
    'docs/architecture/native-rich-data-lifecycle-2026-10-24.md',
    'docs/architecture/native-managed-binary-objects-2026-11-06.md',
    'docs/architecture/dependency-intake-2026-11-06.md',
    'docs/architecture/local-development-storage.md',
    'docs/reference/rich-columns.md',
    'docs/reference/shardloom-user-surface-index.json',
    'docs/reference/shardloom-user-surface-index.md',
    'python/README.md',
}
expected_files.update('docs/release/evidence/native-fixed-shape-tensor-2026-11-07/' + name
    for name in ('acceptance.json', 'verification.tar.xz', 'verify.py', 'README.md', 'corruption-controls.json'))
assert set(git('diff', '--name-only', BASE, head).splitlines()) == expected_files
for name, expected in report['code_snapshot'].items():
    assert identity(ROOT / name) == expected
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
    str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)
controls = read(PACKET / 'corruption-controls.json')
assert controls['status'] == 'passed' and controls['rejected_controls'] == 5
assert controls['observation']['original_packet_sha256'] == identity(PACKET / 'acceptance.json')['sha256']
assert controls['observation']['original_archive_sha256'] == identity(PACKET / 'verification.tar.xz')['sha256']
assert controls['observation']['verifier_sha256'] == identity(PACKET / 'verify.py')['sha256']
final_docs = read(OUT / 'final-docs-r1.json')
assert final_docs['status'] == 'passed' and final_docs['process_group_drained']
assert final_docs['head'] == BASE
assert set(final_docs['changed_source_inventory']) == expected_files
for name in expected_files:
    assert identity(ROOT / name) == final_docs['changed_source_inventory'][name], name
installed = read(OUT / 'installed-proof-r1/report.json')
for relative, key in [('runtime-r2/shardloom', 'cli_sha256'),
        ('runtime-r2/lib_native.dylib', 'native_library_sha256'),
        ('installed-proof-r1/dist/' + installed['integrity']['wheel'], 'wheel_sha256')]:
    assert identity(OUT / relative)['sha256'] == installed['integrity'][key] == report[key]
prior = read(OUT.parent / 'dependency-followup-2026-11-06/dependency-closeout-r1.json')
assert prior['status'] == 'complete' and prior['merge_commit'] == BASE
assert not git('diff', '--numstat', BASE, head, '--', '.github/workflows')
result = dict(status='passed', head=head, tree=git('rev-parse', head + '^{tree}'), base=BASE, base_branch='main',
    runtime_sources_match_build=True,
    runtime_source_proof='Every changed Rust/Python runtime source matches the final build and installed-package checks. Two later test/harness-only changes correct a stale diagnostic assertion and add public-context checks to the installed proof. Broad default/native suites precede only the Arrow ID constant feature gate; exact source projections and resolved feature graphs prove equivalent enabled code. Final strict native lint and the minimal feature check cover both branches. The saved base commit fixes unchanged sources and dependencies.',
    validation_harness_correction=identity(OUT / 'harness-correction-r1.json'),
    feature_gate_source_verification=identity(OUT / 'runtime-production-continuity-r2.json'),
    ci_workflow_blob=git('rev-parse', head + ':.github/workflows/ci.yml'),
    acceptance=identity(PACKET / 'acceptance.json'), archive=identity(PACKET / 'verification.tar.xz'),
    verifier=identity(PACKET / 'verify.py'), installed_package=report['installed_package'],
    corruption_controls=identity(PACKET / 'corruption-controls.json'),
    final_documentation_checks=identity(OUT / 'final-docs-r1.json'), changed_files=sorted(expected_files),
    prior_dependency_closeout=identity(OUT.parent / 'dependency-followup-2026-11-06/dependency-closeout-r1.json'),
    publication_attempted=False, performance_claim=False)
with (OUT / 'delivery-acceptance-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'head', 'tree', 'installed_package')}))
