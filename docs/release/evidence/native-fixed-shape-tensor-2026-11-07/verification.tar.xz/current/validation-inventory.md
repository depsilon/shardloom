# Fixed Shape Tensor Validation and Static Surface Inventory

Read-only follow-up for `/Users/dylan/.codex/worktrees/native-tensor-lifecycle/shardloom-local-repo`. The primary worktree already contained uncommitted tensor implementation edits when inspected; this inventory did not modify those files. Contract read: `docs/architecture/native-fixed-tensor-lifecycle-2026-11-07.md`.

## Python API reference and generated typing surfaces

| Source | Exact authority / command | Effect for `types.fixed_shape_tensor` |
|---|---|---|
| `python/src/shardloom/types.py:17-46,194-200` | `types.__all__` lists constructors; `fixed_shape_tensor` is currently listed and defined in `types.py`. | The public namespace constructor is discovered from `types.__all__`. It is not a top-level `shardloom` symbol. |
| `scripts/write_public_api_reference.py:113-174,280-330` | API reference generator: `python scripts/write_public_api_reference.py`; freshness check: `python scripts/write_public_api_reference.py --check`. Source-only mode validates command registry identity against existing generated data; `--binary PATH` reads fresh executable command metadata. | `python_reference()` imports modules `functions`, `types`, `adbc`, `dbapi`, `notebook`; adds every `types.__all__` member to Python symbols with signature, source and doc summary; source hash inputs include `_exports.py`, `types.py` and the defining module source. It writes `docs/reference/shardloom-user-surface-index.json`, `.md`, and `docs/status/cli-command-registry.md`. Regeneration/check required after the new public member. |
| `python/tests/test_public_api_reference.py:64-70,91-115` | `python -m unittest python.tests.test_public_api_reference` (also included in the core shard). | Tests deterministic/current generated reference output and requires the generated `shardloom.types` entries to match `types.__all__` exactly, without duplicates. |
| `scripts/check_user_surface_reference.py:201-228,230-245` | `python scripts/check_user_surface_reference.py` | Recomputes generated files via `generated_files()` and rejects stale API reference; also validates required backlink and JSON pointer contract. It has no fixed per-type constructor allowlist. |
| `scripts/write_python_api_exports.py:14-18,30-88,91-114`; `python/tests/test_public_exports.py:209-225` | Stub generation: `python scripts/write_python_api_exports.py`; check: `python scripts/write_python_api_exports.py --check`; tested by `python -m unittest python.tests.test_public_exports`. | This generator consumes `_exports.py` for top-level exports and `diagnostics.pyi` / `testing.pyi`; `__init__.pyi` exposes the `types` module namespace but does not declare its members individually. `types.fixed_shape_tensor` does not need a top-level `_exports.py` entry or an `__init__.pyi` import unless a separate top-level API is intended. Current Python package ships `.pyi` files and `types.py` through package discovery (`python/pyproject.toml:44-48`). |
| `python/src/shardloom/_exports.py:10-12` and `python/src/shardloom/__init__.py:21-26,38-47` | `_exports.py` is the lazy top-level export authority; `types` is a namespace module in package exports. | Adding a member under `shardloom.types` is separate from adding a top-level `shardloom.fixed_shape_tensor` export. No `_exports.py` edit is required for the former. |

The `REQUIRED_PYTHON_METHODS` static list in `scripts/check_user_surface_reference.py:110-133` concerns context/query methods and does not enumerate `shardloom.types` declarations. No static Python type-constructor classification list was found; `types.__all__` is the source of truth.

## Python test discovery, shard assignment, and wheel proof

| Source | Exact authority / command | Effect for `test_native_tensor_binding.py` |
|---|---|---|
| `scripts/run_python_test_shard.py:20-25,41-58` | Local shard command: `python scripts/run_python_test_shard.py --shard core`. | `discover_test_modules()` includes sorted `python/tests/test*.py`. Only `test_release_scripts` and `test_front_door_benchmark_publication` are specially assigned outside core via `SHARDS`; a new `test_native_tensor_binding.py` therefore goes automatically to core. |
| `.github/workflows/ci.yml:350-366` | Python shard CI matrix is `core`, `front_door_benchmark_publication`, `release_scripts`; invokes `python scripts/run_python_test_shard.py --shard ${{ matrix.shard }}`. | No matrix edit is needed while the new test remains in core. |
| `scripts/merge_python_test_shard_evidence.py:55-116,125-147`; `python/tests/test_ci_python_test_shards.py:39-67` | Evidence merge command: `python scripts/merge_python_test_shard_evidence.py`; tests: `python -m unittest python.tests.test_ci_python_test_shards`. | Merger derives the expected module set from `discover_test_modules()` and checks exact-once complete coverage. A newly discovered `test*.py` is expected automatically; no per-file list edit. If a future change assigns it to a distinct shard, update `SHARDS`, `SHARD_ORDER`, the workflow matrix, and shard coverage expectations coherently. |
| `scripts/prove_native_python_wheel.py:54-72` | Installed-wheel integration suite is `RUN_TESTS`, launched by the proof script after isolated install. | First discovery pattern is `test_native*binding.py`, which matches `test_native_tensor_binding.py`; each required pattern must discover at least one test, and the suite fails on failures, errors, or skips. No explicit tensor filename allowlist exists. |
| `scripts/test_prove_native_python_wheel.py:16-42` | `python -B -m unittest discover -s scripts -p 'test_*native_python*.py' -v` in CI; focused selector test can also be run with that module suite. | The fixture test checks that each wheel-proof discovery pattern has a suite and rejects missing or skipped selected modules. Its fixture tuple lists representative module names, not a hard-coded binding glob expansion; the actual broad pattern picks up the tensor test. |
| `scripts/ci_native_package.py:73-119,122-147`; `.github/workflows/ci.yml:650-660,691-700` | Installed proof command in CI: `python scripts/ci_native_package.py test --package ... --output ... --wheelhouse ...`. | Reuses exact wheel, invokes `prove_native_python_wheel.prove()`, requires passed integration and uninstall, no skipped tests. Package proof is run on Linux Python 3.10/3.13 and macOS Python 3.13 per workflow matrices. No test count constant applies to this binding suite. |
| `.github/workflows/ci.yml:392-393` | Python source/test compile check: `python -m compileall -q python/src python/tests scripts examples benchmarks/traditional_analytics`. | The new Python module and test are included automatically. |

## Rust module registration and line-count rules

| Source | Exact authority / observed rule |
|---|---|
| `shardloom-vortex/src/lib.rs:132-141` | Crate module list explicitly registers `native_embedding`, shared `native_extensions`, `native_temporal`, and currently `native_tensor` behind `#[cfg(any(feature = "vortex-local-primitives", feature = "vortex-write"))]`. This is the Rust module declaration point for `native_tensor.rs`. |
| `shardloom-vortex/src/native_tensor.rs:261-269` | `native_tensor_arrow.rs` is registered behind `universal-format-io`; `native_tensor_edition.rs` is a path module; `native_tensor_tests.rs` is registered with `#[cfg(all(test, feature = "vortex-local-primitives"))]`. These are explicit submodule/test declarations for the new native module files. |
| `scripts/check_repo_wide_audit.py:73-76,131-143` | Repo-wide audit records a text file's `line_count` in inventory output, alongside SHA-256; no line threshold or failing size rule was found in this path. |
| `Cargo.toml:81-86` | Workspace Rust lints forbid unsafe and set Clippy `all` and `pedantic` to warning. Search found no file-length/module-size limit configuration; `clippy::too_many_lines` occurs as a function lint/selected local allowances, not as a source-file registry limit. |

## Relevant exact validation commands

```bash
python scripts/write_public_api_reference.py --check
python scripts/check_user_surface_reference.py
python scripts/write_python_api_exports.py --check
python -m unittest python.tests.test_public_api_reference python.tests.test_public_exports python.tests.test_ci_python_test_shards
python scripts/run_python_test_shard.py --shard core
python scripts/merge_python_test_shard_evidence.py
python -m unittest discover -s scripts -p 'test_*native_python*.py' -v
python scripts/ci_native_package.py test --package <package-dir> --output <new-proof-dir> --wheelhouse <wheelhouse>
python -m compileall -q python/src python/tests scripts examples benchmarks/traditional_analytics
```

Commands above are repository entry points and workflow commands read from source; none were run for this inventory.

## Unknowns / caveats

- The installed wheel selector's broad `test_native*binding.py` pattern means the new tensor test is auto-included if named exactly as requested. The checked-in selector unit test uses representative synthetic files, so it does not currently assert the exact future tensor filename.
- The local source-only public-reference `--check` may depend on current generated registry identity and release provenance state; the reference-generation code documents that fresh CLI binary metadata is supplied with `--binary` when updating command facts.
- No independent Python `types.pyi` exists. The types module is regular Python source and the package includes `*.pyi` in addition to `.py`; no module/file-length ceiling was discovered.
