"""Adopt the signed accepted merge without changing either checkout's files."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

N = Path(__file__).resolve().parents[1]
D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
T = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
Q = N.parent / 'managed-binary-2026-11-06'


def read(path):
    return json.loads(path.read_bytes())


def git(root, *arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, text=True, timeout=90).strip()


def main_owners():
    blocks = git(D, 'worktree', 'list', '--porcelain').split('\n\n')
    return [block.splitlines()[0].removeprefix('worktree ') for block in blocks
            if 'branch refs/heads/main' in block.splitlines()]


destination = N / 'dependency-main-checkout-r1.json'
assert not destination.exists()
pre = read(N / 'dependency-pr1660-r1.json')
prep = read(N / 'delivery-acceptance-r1.json')
merged = read(N / 'pr1660-merge-r1.json')
binary = read(Q / 'binary-closeout-r1.json')
assert merged.get('isError') is False and merged['structuredContent']['merged'] is True
new = merged['structuredContent']['sha']
old, head, tree = pre['base'], pre['head'], prep['tree']
record = dict(status='needs_attention', merge_commit=new, source_tree=tree,
              observed_at=datetime.now(timezone.utc).isoformat())
try:
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert binary['status'] == 'complete' and binary['merge_commit'] == old
    assert read(N / 'pr1660-final-checks-r1.json')['status'] == 'passed'
    assert read(N / 'pr1660-final-review-r1.json')['status'] == 'passed'
    assert git(T, 'rev-parse', 'HEAD') == old and git(T, 'branch', '--show-current') == 'main'
    assert git(D, 'rev-parse', 'HEAD') == head
    assert git(D, 'branch', '--show-current') == 'codex/native-dependency-followup'
    assert not git(T, 'status', '--porcelain') and not git(D, 'status', '--porcelain')
    assert git(D, 'rev-parse', head + '^{tree}') == tree
    assert main_owners() == [str(T)]
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', 'main'], cwd=D, check=True, timeout=90)
    assert git(D, 'rev-parse', 'origin/main') == new
    assert git(D, 'rev-parse', new + '^{tree}') == tree
    assert git(D, 'show', '-s', '--format=%P', new).split() == [old, head]
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/commits/' + new], cwd=D, timeout=50)
    assert len(raw) < 8 << 20
    commit = json.loads(raw)
    assert commit['sha'] == new and commit['commit']['tree']['sha'] == tree
    assert [row['sha'] for row in commit['parents']] == [old, head]
    assert commit['commit']['verification']['verified'] is True
    record.update(signed_commit=commit, parents=[old, head],
                  prior_binary_closeout_sha256=hashlib.sha256((Q / 'binary-closeout-r1.json').read_bytes()).hexdigest())
    for parent in prep['parents']:
        subprocess.run(['git', 'merge-base', '--is-ancestor', parent, new], cwd=D, check=True)
    subprocess.run(['git', 'switch', '--detach', old], cwd=T, check=True, timeout=90)
    assert not main_owners() and git(D, 'rev-parse', 'refs/heads/main') == old
    subprocess.run(['git', 'update-ref', 'refs/heads/main', new, old], cwd=D, check=True, timeout=90)
    subprocess.run(['git', 'switch', 'main'], cwd=D, check=True, timeout=90)
    assert main_owners() == [str(D)]
    assert git(D, 'rev-parse', 'HEAD') == new and git(D, 'rev-parse', 'HEAD^{tree}') == tree
    assert git(T, 'rev-parse', 'HEAD') == old and not git(T, 'branch', '--show-current')
    assert not git(D, 'status', '--porcelain') and not git(T, 'status', '--porcelain')
    record.update(status='passed', active_worktree=str(D), main_branch='main',
                  previous_worktree=str(T), previous_worktree_detached_at=old,
                  both_worktrees_clean=True, accepted_file_trees_unchanged=True)
except BaseException as error:
    record['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with destination.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'merge_commit', 'source_tree', 'active_worktree')}))
