"""Package only follow-up observations and source bytes absent from the base packet."""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('followup', OUT / 'tools/verify_vector_proof_followup.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
args.output.mkdir()
core_packet = ROOT / 'docs/release/evidence' / v.CORE
base = json.loads((core_packet / 'acceptance.json').read_bytes())
old = v.read_archive(core_packet, base, 90 << 20)
known = {v.sha(raw) for raw in old.values()} | {info['sha256'] for info in v.CORE_FILES.values()}
paths = set(v.ROLES.values()) | {name.replace('.json', '.log') for name in v.ROLES.values()}
paths.update('ci-failures-r1/' + name for name in v.CI_FILES)
paths.update({'vector-installed-wheel-r3-launch.json', 'public-status-docs-r2.json', 'contribution-governance-r2.json'})
paths.update('tools/' + name for name in ('verify_vector_proof_followup.py', 'check_vector_proof_controls.py', 'package_vector_proof_followup.py'))
paths.update(str(path.relative_to(OUT)) for path in (OUT / 'installed-proof-r3').iterdir() if path.is_file())
data = {name: (OUT / name).read_bytes() for name in sorted(paths)}
source = json.loads(data[v.ROLES['docs']])['build_sources']
for role, filename in v.ROLES.items():
    receipt = json.loads(data[filename])
    for info in list(receipt['build_sources'].values()) + list(receipt['tool_source_inventory'].values()):
        if 'sha256' in info and 'symlink' not in info and info['sha256'] not in known:
            name = 'source-blobs/' + info['sha256']
            raw = (OUT / name).read_bytes()
            assert v.identity(raw) == info
            data[name] = raw
members = []
with tarfile.open(args.output / 'verification.tar.xz', 'w:xz', preset=6) as archive:
    for name, raw in sorted(data.items()):
        entry = tarfile.TarInfo(name)
        entry.mode, entry.mtime, entry.size = 0o644, 0, len(raw)
        archive.addfile(entry, io.BytesIO(raw))
        members.append(dict(path=name, **v.identity(raw)))
report = dict(schema_version='shardloom.vector_proof_followup.v1', status='local_acceptance_passed',
    validated_parent=v.HEAD, core_files=v.CORE_FILES, roles=v.ROLES,
    source_snapshot=source, source_fingerprint_sha256=v.fingerprint(source),
    source_deltas={name: dict(before=base['source_snapshot'].get(name), after=source.get(name))
        for name in sorted(set(source) | set(base['source_snapshot'])) if source.get(name) != base['source_snapshot'].get(name)},
    ci_failure_files={name: v.identity(data['ci-failures-r1/' + name]) for name in sorted(v.CI_FILES)},
    dispositions={
        'original_ci_attempts': 'Both original Linux Python 3.13 attempts hit the unchanged aggregate 600-second subprocess deadline after 321 completed tests and no observed failed assertions. Both failures and dependent gates remain failures. The same wheel passed all 397 tests under Linux Python 3.10. The bounded integration-only 1200-second budget is a candidate fix pending fresh hosted acceptance.',
        'local_launch': 'The first follow-up guard invocation used the older system Python, which lacks hashlib.file_digest, and stopped before launching any child. Its observation is retained; the unchanged guard then ran with the supported Python 3.13 interpreter.',
        'unchanged_native_checks': 'The pinned core packet retains complete local native validation. Every compiled/runtime/package input is byte-exact; only the two named proof-runner files and three named status-prose documents differ. Fresh unit, installed-package, docs, doc-contract and formatter checks cover the follow-up. Full hosted checks must pass at the new head before merge.'},
    hosted_integration='pending', native_runtime_rebuilt=False, performance_claim=False,
    publication_attempted=False, whole_item_19_complete=False,
    archive='verification.tar.xz', archive_sha256=v.sha((args.output / 'verification.tar.xz').read_bytes()), members=members)
(args.output / 'acceptance.json').write_bytes(v.encoded(report))
(args.output / 'verify.py').write_bytes(data['tools/verify_vector_proof_followup.py'])
print(json.dumps(dict(status='packaged', members=len(members), archive_bytes=(args.output / 'verification.tar.xz').stat().st_size,
    changed_source_paths=sorted(report['source_deltas']))))
