"""Exercise actual standalone follow-up replay, including resealed bad evidence."""
import argparse
import copy
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--core-packet', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    args.output.mkdir()
    spec = importlib.util.spec_from_file_location('followup', args.packet / 'verify.py')
    v = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(v)
    original = {name: (args.packet / name).read_bytes() for name in ('acceptance.json', 'verification.tar.xz', 'verify.py')}
    report = json.loads(original['acceptance.json'])
    data = v.read_archive(args.packet, report, 12 << 20)
    core_files = {name: v.identity((args.core_packet / name).read_bytes()) for name in v.CORE_FILES}
    assert core_files == v.CORE_FILES
    results = []
    for case in v.CASES:
        with tempfile.TemporaryDirectory(prefix='proof-control-', dir=args.output) as temporary:
            root = Path(temporary)
            packet, core = root / 'followup', root / v.CORE
            packet.mkdir()
            core.mkdir()
            # Copies are isolated; no mutation can affect the authoritative packet.
            for name in v.CORE_FILES:
                shutil.copyfile(args.core_packet / name, core / name)
            for name, raw in original.items():
                (packet / name).write_bytes(raw)
            changed, state = data.copy(), copy.deepcopy(report)

            def change_json(name, change):
                value = json.loads(changed[name])
                change(value)
                changed[name] = v.encoded(value)

            def rebind_log(role):
                name = state['roles'][role]
                change_json(name, lambda value: value.update(log_sha256=v.sha(changed[name.replace('.json', '.log')])))

            def rewrite_source(name, raw):
                info = v.identity(raw)
                changed['source-blobs/' + info['sha256']] = raw
                state['source_snapshot'][name] = info
                state['source_fingerprint_sha256'] = v.fingerprint(state['source_snapshot'])
                state['source_deltas'][name] = dict(before=report['source_snapshot'][name], after=info)
                for filename in state['roles'].values():
                    value = json.loads(changed[filename])
                    value['build_sources'][name] = info
                    value['build_source_fingerprint_sha256'] = v.fingerprint(value['build_sources'])
                    for observation in value['build_source_verification'].values():
                        observation['fingerprint_sha256'] = value['build_source_fingerprint_sha256']
                    changed[filename] = v.encoded(value)

            if case == 'base_changed':
                with (core / 'README.md').open('ab') as stream:
                    stream.write(b'\nchanged\n')
            elif case == 'compiled_source_changed':
                name = 'shardloom-vortex/src/local_primitives/native_vector_math.rs'
                rewrite_source(name, b'// changed compiled input\n')
            elif case == 'unit_omitted':
                del state['roles']['unit']
            elif case == 'unit_failed':
                change_json(state['roles']['unit'], lambda value: value.update(status='failed', returncode=1))
            elif case == 'unit_test_omitted':
                name = state['roles']['unit'].replace('.json', '.log')
                lines = changed[name].splitlines(keepends=True)
                del lines[next(i for i, line in enumerate(lines) if b'test_complete_integration_has_a_separate_finite_budget' in line)]
                changed[name] = b''.join(lines)
                rebind_log('unit')
            elif case == 'installed_skipped':
                change_json('installed-proof-r3/report.json', lambda value: value['integration'].update(skipped=1))
                change_json('installed-proof-r3/integration.json', lambda value: value.update(skipped=1))
            elif case in {'installed_test_omitted', 'budget_log_changed'}:
                name = 'installed-proof-r3/integration.log'
                if case == 'installed_test_omitted':
                    lines = changed[name].splitlines(keepends=True)
                    del lines[next(i for i, line in enumerate(lines) if line.startswith(b'test_') and line.rstrip().endswith(b'... ok'))]
                    changed[name] = b''.join(lines)
                    change_json('installed-proof-r3/report.json', lambda value: next(step for step in value['steps'] if step['name'] == 'integration').update(log_sha256=v.sha(changed[name])))
                else:
                    change_json('installed-proof-r3/report.json', lambda value: next(step for step in value['steps'] if step['name'] == 'integration').update(timeout_seconds=0))
            elif case == 'budget_source_changed':
                name = 'scripts/prove_native_python_wheel.py'
                raw = changed['source-blobs/' + state['source_snapshot'][name]['sha256']]
                assert b'timeout = 1200' in raw
                rewrite_source(name, raw.replace(b'timeout = 1200', b'timeout = 0'))
            elif case == 'original_failure_omitted':
                del changed['ci-failures-r1/py313-retry-report.json']
                del state['ci_failure_files']['py313-retry-report.json']
            elif case == 'unsafe_archive_path':
                changed['../unsafe.json'] = b'{}\n'
            mutated = []
            if case not in {'original', 'relocated', 'base_changed', 'archive_checksum'}:
                for name in sorted(set(data) | set(changed)):
                    if data.get(name) != changed.get(name):
                        mutated.append(dict(path=name, before=v.identity(data[name]) if name in data else None,
                                            after=v.identity(changed[name]) if name in changed else None))
                members = []
                with tarfile.open(packet / 'verification.tar.xz', 'w:xz', preset=0) as archive:
                    for name, raw in sorted(changed.items()):
                        entry = tarfile.TarInfo(name)
                        entry.mode, entry.mtime, entry.size = 0o644, 0, len(raw)
                        archive.addfile(entry, io.BytesIO(raw))
                        members.append(dict(path=name, **v.identity(raw)))
                state.update(members=members, archive_sha256=v.sha((packet / 'verification.tar.xz').read_bytes()))
                (packet / 'acceptance.json').write_bytes(v.encoded(state))
            if case == 'archive_checksum':
                raw = bytearray(original['verification.tar.xz'])
                raw[-1] ^= 1
                (packet / 'verification.tar.xz').write_bytes(raw)
            target = args.packet if case == 'original' else packet
            target_core = args.core_packet if case == 'original' else core
            command = [sys.executable, '-I', '-B', str(target / 'verify.py'), '--core-packet', str(target_core)]
            completed = subprocess.run(command, cwd=root, capture_output=True, check=False, timeout=180)
            log = completed.stdout + completed.stderr
            (args.output / (case + '.log')).write_bytes(log)
            expected = case in {'original', 'relocated'}
            assert completed.returncode == (0 if expected else 1), (case, completed.returncode, log[-3000:])
            if expected:
                observed = json.loads(completed.stdout)
                assert observed['status'] == 'passed' and not observed['repository_checked']
            else:
                assert b'AssertionError' in log or b'KeyError' in log, (case, log[-3000:])
            unchanged = (all((args.packet / name).read_bytes() == raw for name, raw in original.items())
                and all(v.identity((args.core_packet / name).read_bytes()) == info for name, info in core_files.items()))
            assert unchanged
            results.append(dict(case=case, returncode=completed.returncode, command=command,
                log_identity=v.identity(log), mutations=mutated, originals_unchanged=unchanged,
                tested_packet={name: v.identity((target / name).read_bytes()) for name in original},
                tested_core={name: v.identity((target_core / name).read_bytes()) for name in core_files}))
            print(json.dumps(dict(case=case, outcome='accepted' if expected else 'rejected')), flush=True)
    receipt = dict(status='passed', cases=results, positive_controls=2, rejected_controls=len(v.CASES)-2,
        driver_sha256=v.sha(Path(__file__).read_bytes()), original_packet={name: v.identity(raw) for name, raw in original.items()}, core_files=core_files)
    (args.output / 'receipt.json').write_bytes(v.encoded(receipt))
    print(json.dumps(dict(status='passed', positive_controls=2, rejected_controls=len(v.CASES)-2)), flush=True)


if __name__ == '__main__':
    main()
