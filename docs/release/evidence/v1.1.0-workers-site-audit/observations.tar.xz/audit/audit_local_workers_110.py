"""Verify exact PR assets through local Wrangler, redirects, headers, 404 handling and browser flows."""
from __future__ import annotations

import hashlib
from html.parser import HTMLParser
import http.client
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
from urllib.parse import quote,urljoin,urlsplit,unquote

V=Path(__file__).resolve().parent.parent
C=Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
A=V/'workers-local-audit-r1'
project=A/'project'
site=project/'website'
head='2cd1167724b4866010ad16baeefdc6293891308b'
def git(*arg):
    return subprocess.check_output(['git',*arg],cwd=C,text=True).strip()
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def dump(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
tracked={r.split('\t')[1]:r.split()[2] for r in git('ls-tree','-r',head,'website','wrangler.jsonc','wrangler.toml').splitlines()}
files={}
for name,oid in tracked.items():
    path=project/name;data=path.read_bytes()
    assert not path.is_symlink() and hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==oid
    files[name]={'git_blob':oid,'bytes':len(data),'sha256':sha(data)}
assert set(tracked)=={'wrangler.jsonc','wrangler.toml'}|{p.relative_to(project).as_posix() for p in site.rglob('*') if p.is_file()}
lines=[s.split() for s in (site/'_redirects').read_text().splitlines() if s.strip() and not s.startswith('#')]
rules=[(s[0],s[1],int(s[2]) if len(s)>2 else 302) for s in lines]
headers=[s for s in (site/'_headers').read_text().splitlines() if s.strip()]
assert len(rules)==len({x[0] for x in rules})
assert len(files)<20000 and max(v['bytes'] for v in files.values())<25*2**20
assert sum('*' not in a for a,_,_ in rules)<=2000 and sum('*' in a for a,_,_ in rules)<=100
assert max(len(' '.join(s)) for s in lines)<=1000 and len([s for s in headers if not s[0].isspace()])<=100 and max(map(len,headers))<=2000

def choose_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]

class Anchors(HTMLParser):
    def __init__(self):
        super().__init__();self.ids=set()
    def handle_starttag(self,tag,attrs):
        self.ids.update(v for k,v in attrs if k=='id' or k=='name' and tag=='a')

port=choose_port();inspector=choose_port();assert port!=inspector
origin=f'http://127.0.0.1:{port}'
wrangler=A/'toolchain/node_modules/.bin/wrangler'
env=dict(os.environ,WRANGLER_SEND_METRICS='false',CI='1')
log=A/'local-dev.log'
results={'source_commit':head,'site_tree':git('rev-parse',head+':website'),'origin':origin,
         'wrangler':'4.157.0','files':files,'routes':[],'redirects':[],'failures':[]}
def get(path):
    h=http.client.HTTPConnection('127.0.0.1',port,timeout=15)
    try:
        h.request('GET',quote(path,safe='/%?=:_-.'),headers={'Accept-Encoding':'identity'})
        r=h.getresponse()
        return r.status,{k.lower():v for k,v in r.getheaders()},r.read(25*2**20+1)
    finally:h.close()
def follow(start):
    current=start; visited=set()
    while current not in visited and len(visited)<8:
        visited.add(current)
        s,h,b=get(current)
        if s not in (301,302,303,307,308):return current,s,h,b
        dest=urlsplit(urljoin(origin+current,h['location']))
        if dest.netloc!=urlsplit(origin).netloc:return h['location'],s,h,b
        current=dest.path
    raise ValueError('redirect cycle '+str(visited))

def match(rule,path):
    if '*' not in rule: return '' if path==rule else None
    before,after=rule.split('*',1)
    return path[len(before):len(path)-len(after) if after else len(path)] if path.startswith(before) and path.endswith(after) else None

def expected_url(path):
    for rule,to,_ in rules:
        wild=match(rule,path)
        if wild is not None:return to.replace(':splat',wild)
    return path
def doc_for(path):
    p=site/path.strip('/')
    if p.is_dir():
        return p/'index.html'
    if p.is_file():
        return p
    return p.with_suffix('.html')
with log.open('xb') as out:
    process=subprocess.Popen([str(wrangler),'dev','--local','--ip','127.0.0.1','--port',str(port),'--inspector-port',str(inspector),
                '--persist-to',str(A/'state'),'--live-reload=false','--show-interactive-dev-session=false'],
                cwd=project,env=env,start_new_session=True,stdout=out,stderr=subprocess.STDOUT)
    try:
        for _ in range(150):
            if process.poll() is not None:raise RuntimeError('Wrangler exited during startup')
            try:
                if get('/')[0]==200:break
            except OSError:pass
            time.sleep(.2)
        else:raise RuntimeError('Wrangler did not serve the site')
        for name in sorted(tracked):
            if not name.startswith('website/') or name in ('website/_redirects','website/_headers'):continue
            rel=name.removeprefix('website/')
            route='/'+(rel.removesuffix('index.html') if rel.endswith('index.html') else rel)
            target=urlsplit(expected_url(route)).path
            final,status,h,b=follow(route)
            expected=doc_for(target)
            same=expected.is_file() and sha(b)==sha(expected.read_bytes())
            default_headers=(h.get('x-content-type-options')=='nosniff' and h.get('x-frame-options')=='DENY'
                            and "frame-ancestors 'none'" in h.get('content-security-policy',''))
            row=dict(file=name,route=route,final=final,status=status,matches_authored_bytes=same,sha256=sha(b),
                     response_headers_match=default_headers,content_type=h.get('content-type'))
            results['routes'].append(row)
            if status not in (200,404) or not same or not default_headers or status==404 and name!='website/404.html':
                results['failures'].append(row)
        for rule,to,expected_status in rules:
            source=rule.replace('*','sample');target=to.replace(':splat','sample'); s,h,_=get(source)
            actual=h.get('location','')
            loc=urlsplit(urljoin(origin+source,actual))
            expected=urlsplit(urljoin(origin+source,target))
            anchor_ok=True
            if expected.fragment and expected.netloc==urlsplit(origin).netloc:
                _,status,_,b=follow(expected.path)
                parser=Anchors();parser.feed(b.decode());anchor_ok=status==200 and unquote(expected.fragment) in parser.ids
            row=dict(rule=rule,request=source,expected=target,expected_status=expected_status,
                     status=s,location=actual,anchor_exists=anchor_ok)
            results['redirects'].append(row)
            if s!=expected_status or loc!=expected or not anchor_ok:results['failures'].append(row)
        path,status,h,b=follow('/shardloom-missing-110-proof')
        results['not_found']={'status':status,'matches_authored_404':b==(site/'404.html').read_bytes()}
        if results['not_found']!={'status':404,'matches_authored_404':True}:results['failures'].append(results['not_found'])
        # Exercise the same exact installation, navigation, search and viewport
        # assertions at the locally packaged Workers URL.
        p=V/'release-tools/browser_110.cjs'
        program=p.read_text()
        assert program.count("const ORIGIN = 'https://shardloom.io';")==1
        local=program.replace("const ORIGIN = 'https://shardloom.io';",f"const ORIGIN = '{origin}';").replace('merge_revision: revision','source_revision: revision')
        js=A/'browser.cjs'
        with js.open('x') as f:f.write(local)
        run=subprocess.run(['node',str(js),'publication-browser-workers-local-r1',head],cwd=project,
            env={**env,'NODE_PATH':'/Users/dylan/.npm/_npx/31e32ef8478fbf80/node_modules'},capture_output=True,timeout=180)
        (A/'browser.log').write_bytes(run.stdout+run.stderr)
        results['browser']={'exitcode':run.returncode,'receipt':str(V/'publication-browser-workers-local-r1/browser.json')}
        if run.returncode:results['failures'].append(results['browser'])
    finally:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:process.wait(timeout=6)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=6)
        for _ in range(25):
            try:os.killpg(process.pid,0)
            except ProcessLookupError: break
            time.sleep(.2)
        else:
            os.killpg(process.pid,signal.SIGKILL);time.sleep(.2)
        try:os.killpg(process.pid,0)
        except ProcessLookupError:results['local_group_drained']=True
        else:results['failures'].append('local Workers dev group still active')
        results['status']='failed' if results['failures'] else 'passed'
        dump(A/'audit.json',results)
print(json.dumps(dict(files=len(files),served=len(results['routes']),redirects=len(rules),failures=len(results['failures']),
                      largest=max(v['bytes'] for v in files.values()),status=results['status'])),flush=True)
raise SystemExit(bool(results['failures']))

