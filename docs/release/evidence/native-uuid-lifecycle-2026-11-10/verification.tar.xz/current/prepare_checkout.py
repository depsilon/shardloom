"""Populate a task-owned worktree from verified resident source files."""
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

SOURCE = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
WORK = Path('/Users/dylan/.codex/worktrees/native-uuid-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = '7ee43de766a85f3b5ca145e9330a80a69a9155aa'
BRANCH = 'codex/native-uuid-lifecycle'


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, timeout=60)


def generation(path):
    value = path.lstat()
    return [value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns, value.st_nlink]


def blob(path, mode):
    if mode == '120000':
        data = os.fsencode(os.readlink(path))
        return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    digest = hashlib.sha1(b'blob ' + str(path.stat().st_size).encode() + b'\0')
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


assert not (OUT / 'checkout-r2.json').exists()
assert not WORK.exists() and not WORK.is_symlink()
assert git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == HEAD
assert git(SOURCE, 'rev-parse', BRANCH).decode().strip() == HEAD
assert not git(SOURCE, 'status', '--porcelain')
assert shutil.disk_usage(SOURCE).free > 12 << 30
records = []
for raw in git(SOURCE, 'ls-files', '-s', '-z').split(b'\0'):
    if not raw:
        continue
    header, name = raw.split(b'\t', 1)
    mode, oid, stage = header.decode().split()
    name = os.fsdecode(name)
    relative = Path(name)
    assert stage == '0' and mode in {'100644', '100755', '120000'}
    assert not relative.is_absolute() and '..' not in relative.parts and '.git' not in relative.parts
    path = SOURCE / relative
    assert path.is_symlink() == (mode == '120000')
    assert blob(path, mode) == oid, name
    records.append(dict(path=name, mode=mode, blob=oid, generation=generation(path)))

libc = ctypes.CDLL(None, use_errno=True)
clone = libc.clonefile
clone.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
clone.restype = ctypes.c_int
result = dict(status='running', base=HEAD, worktree=str(WORK), branch=BRANCH,
    observed_at=datetime.now(timezone.utc).isoformat(), source=str(SOURCE),
    method='git_metadata_then_verified_resident_copy_on_write', copied=0,
    source_manifest=records, observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
try:
    subprocess.run(['git', 'worktree', 'add', '--no-checkout', str(WORK), BRANCH],
                   cwd=SOURCE, check=True, timeout=90)
    subprocess.run(['git', 'read-tree', HEAD], cwd=WORK, check=True, timeout=60)
    for record in records:
        source = SOURCE / record['path']
        target = WORK / record['path']
        assert generation(source) == record['generation']
        assert not target.exists() and not target.is_symlink()
        target.parent.mkdir(parents=True, exist_ok=True)
        if record['mode'] == '120000':
            target.symlink_to(source.readlink())
        else:
            assert stat.S_ISREG(source.lstat().st_mode)
            if clone(os.fsencode(source), os.fsencode(target), 0) != 0:
                raise OSError(ctypes.get_errno(), 'resident source clone failed', str(source))
        assert blob(target, record['mode']) == record['blob'], record['path']
        assert generation(source) == record['generation']
        result['copied'] += 1
    subprocess.run(['git', 'update-index', '--refresh'], cwd=WORK, check=True, timeout=90)
    assert not git(WORK, 'status', '--porcelain')
    assert git(WORK, 'rev-parse', 'HEAD').decode().strip() == HEAD
    assert git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == HEAD
    assert not git(SOURCE, 'status', '--porcelain')
    assert all(generation(SOURCE / row['path']) == row['generation'] for row in records)
    assert shutil.disk_usage(WORK).free > 12 << 30
    result.update(status='passed', source_unchanged=True, all_blobs_exact=True,
                  worktree_clean=True, source_files=len(records), shared_mutable_files=False)
except BaseException as error:
    result.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    with (OUT / 'checkout-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'base', 'worktree', 'copied')}))
