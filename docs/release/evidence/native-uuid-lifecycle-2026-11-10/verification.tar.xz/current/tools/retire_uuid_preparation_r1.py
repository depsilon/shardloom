"""Retire superseded UUID preparation runtimes and idle debug outputs before full validation."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-uuid-lifecycle/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
DEBUG = CACHE / 'debug'
DEST = OUT / 'preparation-retirement-r1'
ROOTS = (DEBUG, OUT / 'runtime-preparation-r1', OUT / 'runtime-preparation-r2')
PRIOR = OUT.parent / 'vector-expressions-2026-11-08'
CHECKS = ('public-build-r3.json', 'public-python-r7.json', 'schema-tests-r2.json', 'docs-preparation-r2.json')
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def read(path):
    return json.loads(path.read_bytes())


def inventory():
    assert DEBUG.resolve() == DEBUG and DEBUG.is_dir() and not DEBUG.is_symlink()
    rows, links, hashes = [], {}, {}
    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = dict(path=str(path), generation=before)
        if stat.S_ISDIR(before[2]):
            item['kind'] = 'directory'
            rows.append(item)
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            item.update(kind='regular', sha256=hashes[key])
            rows.append(item)
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            item.update(kind='symlink', target=os.readlink(path))
            rows.append(item)
        else:
            raise AssertionError('unexpected generated file type ' + str(path))
        assert base.generation(path) == before
    for root in ROOTS:
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
        visit(root)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths)
    return rows


def retained():
    expected = {}
    for family, name in [('vector-expressions-2026-11-08', 'vector-closeout-r1.json'),
                         ('wide-schema-2026-11-09', 'wide-closeout-r1.json')]:
        expected.update(read(OUT.parent / family / name)['retained_runtime_and_wheel'])
    variant = OUT.parent / 'variant-lifecycle-2026-11-09'
    for manifest in (variant / 'runtime-r2-identity.json', OUT / 'runtime-preparation-r3-identity.json'):
        for row in read(manifest)['files']:
            expected[row['path']] = {key: row[key] for key in ('bytes', 'sha256')}
    installed = read(variant / 'installed-proof-r1/report.json')
    wheel = variant / 'installed-proof-r1/dist' / installed['integrity']['wheel']
    expected[str(wheel)] = dict(bytes=wheel.stat().st_size, sha256=installed['integrity']['wheel_sha256'])
    result = {}
    for name, info in expected.items():
        path = Path(name)
        assert path.is_file() and not path.is_symlink()
        assert not any(path.is_relative_to(root) for root in ROOTS)
        result[name] = dict(bytes=path.stat().st_size, sha256=base.sha(path))
        assert result[name] == info
    assert len(result) >= 11
    return result


def superseded():
    result = {}
    for root in ROOTS[1:]:
        identity = read(OUT / (root.name + '-identity.json'))
        assert identity['status'] == 'passed'
        build = read(OUT / identity['build_receipt'])
        assert base.sha(OUT / identity['build_receipt']) == identity['build_receipt_sha256']
        assert build['status'] == 'passed' and build['process_group_drained']
        assert set(path.name for path in root.iterdir()) == {'shardloom', 'lib_native.dylib'}
        for row in identity['files']:
            path = Path(row['path'])
            assert path.parent == root and not path.is_symlink()
            assert path.stat().st_size == row['bytes'] and base.sha(path) == row['sha256']
        result[root.name] = identity
    return result


def inputs():
    prior = PRIOR / 'vector-retirement-r2'
    assert base.sha(prior / 'manifest.json.xz') == read(prior / 'plan.json')['manifest_sha256']
    expected = json.loads(lzma.decompress((prior / 'manifest.json.xz').read_bytes()))['input_generations']
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def release():
    return {str(path): base.generation(path) for path in sorted((CACHE / 'release').rglob('*'))}


def resolve():
    for name in CHECKS:
        receipt = read(OUT / name)
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['source_validation_mode'] == 'preparation_no_source_changes'
        assert receipt['build_source_verification']['pre_execution']['changed_paths'] == []
        assert receipt['build_source_verification']['post_execution']['changed_paths'] == []
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert base.sha((OUT / name).with_suffix('.log')) == receipt['log_sha256']
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    value = json.loads(subprocess.check_output(['cargo', 'metadata', '--locked', '--offline',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert value['target_directory'] == str(CACHE)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == receipt['head']
    accepted = read(ROOT / 'docs/release/evidence/native-variant-lifecycle-2026-11-09/acceptance.json')
    assert accepted['status'] == 'local_acceptance_passed'
    assert receipt['base'] == '7ee43de766a85f3b5ca145e9330a80a69a9155aa'
    assert not DEBUG.is_relative_to(ROOT) and os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize >= 12 << 30


def plan():
    resolve()
    assert not DEST.exists()
    base.closed([str(root) for root in ROOTS])
    print('Inventorying idle debug compiler output', flush=True)
    rows = inventory()
    manifest = dict(roots=[str(root) for root in ROOTS], superseded_runtimes=superseded(), entries=rows, retained=retained(), input_generations=inputs(),
        release_generations=release(), source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        native_checks={name: base.sha(OUT / name) for name in CHECKS})
    helper_blob = OUT / 'source-blobs' / base.sha(HELPER)
    if not helper_blob.exists():
        helper_blob.write_bytes(HELPER.read_bytes())
    assert helper_blob.read_bytes() == HELPER.read_bytes()
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', roots=[str(root) for root in ROOTS], entries=len(rows),
        regular_files=sum(row['kind'] == 'regular' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        manifest_sha256=base.sha(DEST / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), free_bytes_before=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
        reason='The corrected preparation runtime passed all nine public UUID workflows and ten schema tests; provider tests/lint and documentation checks pass. Retire only the two superseded preparation runtimes and closed reproducible debug compiler output before full workspace validation. Earlier attempts remain preserved; no final acceptance is claimed.',
        regeneration='Each original build receipt, complete source inventory, lockfile and command is retained. Preserve current Variant, wide-schema and vector runtime/wheels, the corrected UUID preparation runtime, all input generations, release cache and all observations/source blobs. No payload backup or storage-limit change.')
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


def apply():
    resolve()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['roots'] == [str(root) for root in ROOTS]
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    rows = manifest['entries']
    assert superseded() == manifest['superseded_runtimes']
    assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
    assert release() == manifest['release_generations']
    assert all(base.sha(OUT / name) == sha for name, sha in manifest['native_checks'].items())
    base.closed([str(root) for root in ROOTS])
    print('Rechecking exact debug identities and closed handles', flush=True)
    assert inventory() == rows
    base.closed([str(root) for root in ROOTS])
    receipt = dict(status='running', removed=0, manifest_sha256=summary['manifest_sha256'])
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(rows, key=lambda item: len(Path(item['path']).parts), reverse=True):
            path = Path(row['path'])
            assert any(path == root or path.is_relative_to(root) for root in ROOTS)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                # All hardlink names are accounted for in the selected root.
                assert current[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert all(not root.exists() and not root.is_symlink() for root in ROOTS)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert release() == manifest['release_generations']
        receipt.update(status='passed', retained_runtimes_and_wheel_unchanged=True,
            input_generations_unchanged=True, release_cache_unchanged=True,
            regular_files=summary['regular_files'], regular_bytes=summary['regular_bytes'], symlinks=summary['symlinks'],
            free_bytes_before=summary['free_bytes_before'], free_bytes_after=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
            storage_floor_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
