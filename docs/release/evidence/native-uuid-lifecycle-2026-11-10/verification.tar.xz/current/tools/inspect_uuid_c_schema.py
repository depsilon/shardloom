"""Inspect only the known-owned PyArrow schema fixture; do not import its data."""
import ctypes as c
import json
import pyarrow as pa


class Schema(c.Structure):
    pass


Schema._fields_ = [
    ('format', c.c_char_p), ('name', c.c_char_p), ('metadata', c.c_void_p),
    ('flags', c.c_int64), ('n_children', c.c_int64),
    ('children', c.POINTER(c.POINTER(Schema))), ('dictionary', c.POINTER(Schema)),
    ('release', c.c_void_p), ('private_data', c.c_void_p),
]
pointer = c.pythonapi.PyCapsule_GetPointer
pointer.argtypes = [c.py_object, c.c_char_p]
pointer.restype = c.c_void_p


def metadata(address):
    if not address:
        return {}
    cursor = address
    def integer():
        nonlocal cursor
        value = c.c_int32.from_address(cursor).value
        cursor += 4
        assert 0 <= value <= 4096
        return value
    result = {}
    for _ in range(integer()):
        length = integer()
        key = c.string_at(cursor, length).decode()
        cursor += length
        length = integer()
        value = c.string_at(cursor, length).decode()
        cursor += length
        result[key] = value
    return result


field = pa.field('uid', pa.dictionary(pa.int8(), pa.uuid()))
capsule = field.__arrow_c_schema__()
outer = c.cast(pointer(capsule, b'arrow_schema'), c.POINTER(Schema)).contents
assert outer.format == b'c' and outer.n_children == 0 and outer.dictionary
inner = outer.dictionary.contents
assert inner.format == b'w:16' and inner.n_children == 0 and not inner.dictionary
result = dict(pyarrow=pa.__version__, outer_format=outer.format.decode(),
              outer_metadata=metadata(outer.metadata), dictionary_format=inner.format.decode(),
              dictionary_metadata=metadata(inner.metadata))
assert not result['outer_metadata']
assert result['dictionary_metadata'] == {'ARROW:extension:name': 'arrow.uuid', 'ARROW:extension:metadata': ''}
print(json.dumps(result, sort_keys=True))
