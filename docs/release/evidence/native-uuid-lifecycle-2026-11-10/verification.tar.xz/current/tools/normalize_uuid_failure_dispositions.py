"""Bind each actual failed UUID observation to its explicit preserved disposition."""
import argparse
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert re.fullmatch(r'failure-dispositions-final-r\d+\.json', args.name)
notes = json.loads((OUT / 'failure-dispositions.json').read_bytes())
known = {row['receipt']: row for row in notes['observations']}
assert len(known) == len(notes['observations'])
checkout = json.loads((OUT / 'checkout-r1-failure.json').read_bytes())
known['checkout-r1-failure.json'] = dict(
    classification='local_git_mmap_timeout', original=checkout,
    correction='The separate checkout-r2 observation verifies a complete APFS-cloned checkout against every indexed Git blob; the original incomplete helper record remains unchanged.',
    followup='checkout-r2.json')
files = [*OUT.glob('*.json'), *OUT.glob('*/*.json')]
failed = {}
for path in sorted(files):
    if path.parent.name.startswith(('packet-', 'source-blobs', 'tools', 'runtime-')):
        continue
    value = json.loads(path.read_bytes())
    if not isinstance(value, dict):
        continue
    if str(value.get('status')).startswith('failed') or value.get('status') == 'interrupted':
        name = path.relative_to(OUT).as_posix()
        assert name in known, 'Missing explicit failure disposition: ' + name
        failed[name] = known[name]
assert set(known) == set(failed), 'Disposition inventory contains missing or nonfailed observations'
destination = OUT / args.name
raw = (json.dumps(failed, indent=2) + '\n').encode()
if destination.exists():
    assert destination.read_bytes() == raw, 'Do not rewrite an already sealed disposition map'
else:
    with destination.open('xb') as stream:
        stream.write(raw)
print(json.dumps(dict(status='passed', original_failed_receipts=len(failed))))
