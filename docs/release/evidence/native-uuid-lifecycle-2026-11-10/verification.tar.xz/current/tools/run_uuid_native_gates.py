"""Run final native gates sequentially, stopping on the first failed receipt."""
from pathlib import Path
import subprocess
import sys

guard = Path(__file__).with_name('guard_uuid.py')
native = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
checks = [
    ('format-r1', 300, ['cargo', 'fmt', '--all', '--', '--check']),
    ('native-clippy-r1', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace',
                             '--all-targets', '--features', native, '--', '-D', 'warnings']),
    ('native-tests-r1', 3600, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace',
                            '--all-targets', '--features', native]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, str(guard), '--name', name, '--timeout', str(timeout),
                    '--', *command], check=True)
