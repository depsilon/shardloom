"""Check final documentation and repository contracts after verified base adoption."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
out = directory.parent
python = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
checks = [
    ('doc-contracts-r1', 900, ['cargo', 'test', '--offline', '--locked',
        '-p', 'shardloom-contract-tests', '--all-targets']),
    ('docs-r1', 900, [python, '-B', str(directory / 'check_uuid_docs.py'),
        '--tag', 'final-r1', '--runtime', str(out / 'runtime-r1')]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(directory / 'guard_uuid.py'),
                    '--name', name, '--timeout', str(timeout), '--', *command], check=True)
