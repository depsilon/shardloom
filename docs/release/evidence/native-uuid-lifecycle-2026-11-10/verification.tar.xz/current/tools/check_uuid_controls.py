"""Challenge saved UUID acceptance with relocated replay and intentional corruption."""
import argparse
import copy
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

from verify_uuid_packet import fingerprint, identity, rust_counts, source_deltas

CASES = (
    'original', 'relocated_source_only', 'archive_byte', 'preparation_relabelled',
    'adopted_tree_changed', 'adopted_sources_changed', 'native_source_changed',
    'provider_source_changed', 'provider_lock_changed', 'preparation_prior_changed',
    'unclosed_process', 'native_clippy_failed', 'native_test_missing',
    'public_test_missing', 'public_test_skipped', 'installed_skip',
    'installed_binary_changed', 'wheel_python_changed', 'frozen_fixture_changed',
    'provider_test_missing', 'failure_missing', 'prior_main_failed',
    'prior_retirement_incomplete',
)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
ROOT = Path(__file__).resolve().parents[1]
assert args.packet.resolve().is_relative_to(ROOT) and args.output.resolve().is_relative_to(ROOT)
assert not args.output.exists()
args.output.mkdir()
NAMES = ('acceptance.json', 'verification.tar.xz', 'verify.py')
original = {name: (args.packet / name).read_bytes() for name in NAMES}
original_identities = {name: identity(raw) for name, raw in original.items()}
base_report = json.loads(original['acceptance.json'])
with tarfile.open(fileobj=io.BytesIO(original['verification.tar.xz']), mode='r:xz') as archive:
    base_data = {entry.name: archive.extractfile(entry).read() for entry in archive.getmembers()}


def write_json(data, name, value):
    data[name] = (json.dumps(value, indent=2) + '\n').encode()


def read(data, name):
    return json.loads(data[name])


def receipt_name(report, role):
    return 'current/' + report['roles'][role]


def change_source(report, data, role, path):
    name = receipt_name(report, role)
    receipt = read(data, name)
    old = receipt['build_sources'][path]
    raw = data['current/source-blobs/' + old['sha256']] + b'\n// intentional source identity corruption\n'
    changed = identity(raw)
    data['current/source-blobs/' + changed['sha256']] = raw
    receipt['build_sources'][path] = changed
    receipt['build_source_fingerprint_sha256'] = fingerprint(receipt['build_sources'])
    for phase in ('pre_execution', 'post_execution'):
        receipt['build_source_verification'][phase]['fingerprint_sha256'] = receipt['build_source_fingerprint_sha256']
    report['source_deltas'][role] = source_deltas(receipt['build_sources'], report['source_snapshot'])
    write_json(data, name, receipt)


def change_log(report, data, role, pattern, replacement=b''):
    receipt_path = receipt_name(report, role)
    path = receipt_path.removesuffix('.json') + '.log'
    matches = list(re.finditer(pattern, data[path], re.MULTILINE))
    assert matches
    match = matches[0]
    data[path] = data[path][:match.start()] + replacement + data[path][match.end():]
    receipt = read(data, receipt_path)
    receipt['log_sha256'] = identity(data[path])['sha256']
    write_json(data, receipt_path, receipt)
    report['checks'][role]['rust_tests'] = rust_counts(data[path])


def mutate(case, report, data):
    if case in {'preparation_relabelled', 'preparation_prior_changed', 'unclosed_process', 'native_clippy_failed'}:
        role = 'native_clippy'
        name = receipt_name(report, role)
        value = read(data, name)
        if case == 'preparation_relabelled':
            value.update(fixed_source_validation=True, source_validation_mode='fixed_source_validation')
        elif case == 'preparation_prior_changed':
            value['prior_closeout_sha256'] = '0' * 64
        elif case == 'unclosed_process':
            value['process_group_drained'] = False
        else:
            value.update(status='failed', returncode=101)
        write_json(data, name, value)
    elif case in {'adopted_tree_changed', 'adopted_sources_changed'}:
        name = 'current/uuid-base-adoption-r1.json'
        value = read(data, name)
        if case == 'adopted_tree_changed':
            value['tree'] = '0' * 40
        else:
            value['after']['diff']['sha256'] = '0' * 64
        write_json(data, name, value)
        report['base_adoption'] = identity(data[name])
    elif case in {'native_source_changed', 'provider_source_changed', 'provider_lock_changed'}:
        role, path = {
            'native_source_changed': ('native_tests', 'shardloom-vortex/src/native_uuid_values.rs'),
            'provider_source_changed': ('provider_arrow', 'vendor/arrow-array/src/ffi_stream/schema.rs'),
            'provider_lock_changed': ('provider_arrow', '.github/provider-locks/arrow-array.lock'),
        }[case]
        change_source(report, data, role, path)
    elif case == 'native_test_missing':
        method = report['required_native_tests'][0].encode()
        change_log(report, data, 'native_tests', rb'^test .*::' + re.escape(method) + rb' \.\.\. ok\n')
    elif case in {'public_test_missing', 'public_test_skipped'}:
        pattern = rb'^test_uuid_\S+ \(test_native_uuid_binding\.[^\n]+\) \.\.\. ok\n'
        change_log(report, data, 'public', pattern,
            b"test_uuid_control (test_native_uuid_binding.Control.test_uuid_control) ... skipped 'control'\n"
            if case == 'public_test_skipped' else b'')
    elif case in {'installed_skip', 'installed_binary_changed'}:
        name = 'current/' + report['installed_report']
        value = read(data, name)
        if case == 'installed_skip':
            value['integration']['skipped'] = 1
            report['installed_package'] = value['integration']
            write_json(data, str(Path(name).with_name('integration.json')), value['integration'])
        else:
            value['integrity']['native_library_sha256'] = '0' * 64
        write_json(data, name, value)
    elif case == 'wheel_python_changed':
        name = 'current/wheel-source-identity.json'
        value = read(data, name)
        value['python_sources']['python/src/shardloom/_result_schema.py']['sha256'] = '0' * 64
        write_json(data, name, value)
    elif case == 'frozen_fixture_changed':
        report['frozen_references']['python/tests/test_native_uuid_binding.py'][1] = '0' * 64
    elif case == 'provider_test_missing':
        change_log(report, data, 'provider_arrow', rb'^test ffi_stream::stream_schema::tests::[^\n]+ \.\.\. ok\n')
    elif case == 'failure_missing':
        del data['current/public-python-r1.json']
    elif case == 'prior_main_failed':
        name = 'prior/variant-main-r1-raw/checks.json'
        value = read(data, name)
        value['check_runs'][0]['conclusion'] = 'failure'
        write_json(data, name, value)
        main = read(data, 'prior/variant-main-r1.json')
        main['raw_sources'][name.removeprefix('prior/')] = identity(data[name])['sha256']
        write_json(data, 'prior/variant-main-r1.json', main)
        closeout = read(data, 'prior/variant-closeout-r1.json')
        for path in (name, 'prior/variant-main-r1.json'):
            closeout['receipts'][path.removeprefix('prior/')] = identity(data[path])
        write_json(data, 'prior/variant-closeout-r1.json', closeout)
    elif case == 'prior_retirement_incomplete':
        name = 'prior/variant-retirement-r1/receipt.json'
        value = read(data, name)
        value['removed'] -= 1
        write_json(data, name, value)
        closeout = read(data, 'prior/variant-closeout-r1.json')
        closeout['receipts'][name.removeprefix('prior/')] = identity(data[name])
        write_json(data, 'prior/variant-closeout-r1.json', closeout)
    else:
        raise AssertionError('unhandled control ' + case)


def seal(directory, report, data):
    report['members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(data.items())]
    with tarfile.open(directory / 'verification.tar.xz', 'w:xz', preset=1) as archive:
        for row in report['members']:
            entry = tarfile.TarInfo(row['path'])
            entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
            archive.addfile(entry, io.BytesIO(data[row['path']]))
    report['archive_sha256'] = identity((directory / 'verification.tar.xz').read_bytes())['sha256']
    (directory / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    (directory / 'verify.py').write_bytes(original['verify.py'])


receipt = dict(status='running', driver_sha256=identity(Path(__file__).read_bytes())['sha256'],
    original_packet=original_identities, cases=[], positive_controls=0, rejected_controls=0)
try:
    for index, case in enumerate(CASES):
        with tempfile.TemporaryDirectory(prefix='control-', dir=args.output) as scratch:
            directory = Path(scratch)
            if index < 2 or case == 'archive_byte':
                for name, raw in original.items():
                    (directory / name).write_bytes(raw)
                if case == 'archive_byte':
                    raw = bytearray(original['verification.tar.xz'])
                    raw[len(raw) // 2] ^= 1
                    (directory / 'verification.tar.xz').write_bytes(raw)
            else:
                report, data = copy.deepcopy(base_report), dict(base_data)
                mutate(case, report, data)
                seal(directory, report, data)
            tested_packet = {name: identity((directory / name).read_bytes()) for name in NAMES}
            # A rewritten negative case must reach the intended semantic checks,
            # not be rejected merely for the verification archive's size limit.
            assert tested_packet['verification.tar.xz']['bytes'] < 90 << 20
            command = [sys.executable, '-I', '-B', str(directory / 'verify.py')]
            result = subprocess.run(command, cwd=directory, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, timeout=180, check=False)
            log = case + '.log'
            (args.output / log).write_bytes(result.stdout)
            unchanged = {name: identity((args.packet / name).read_bytes()) for name in NAMES} == original_identities
            record = dict(case=case, expected='accepted' if index < 2 else 'rejected',
                returncode=result.returncode, log=log, log_identity=identity(result.stdout),
                tested_packet=tested_packet, report_before=original_identities['acceptance.json'],
                original_packet_unchanged=unchanged)
            receipt['cases'].append(record)
            assert unchanged and result.returncode == (0 if index < 2 else 1), case
            if index < 2:
                observed = json.loads(result.stdout)
                assert observed['status'] == 'passed' and not observed['native_execution_repeated']
                assert not observed['repository_checked']
                receipt['positive_controls'] += 1
            else:
                assert b'AssertionError' in result.stdout or b'KeyError' in result.stdout, case
                if case == 'prior_main_failed':
                    assert b"matching[0]['conclusion'] == 'success'" in result.stdout
                receipt['rejected_controls'] += 1
            print(case + ': ' + record['expected'], flush=True)
    receipt['status'] = 'passed'
except BaseException as error:
    receipt.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    with (args.output / 'receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
