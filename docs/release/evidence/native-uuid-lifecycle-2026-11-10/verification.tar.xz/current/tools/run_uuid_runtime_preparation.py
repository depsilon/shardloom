"""Prepare a fresh UUID runtime and isolated wheel proof for later exact source binding."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
out = directory.parent
python = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
build_python = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
runtime = out / 'runtime-r1'
installed = out / 'installed-proof-r1'
public_work = out / 'public-r1-work'
assert not public_work.exists()
public_work.mkdir()
core_environment = ['env']
for name in ('SHARDLOOM_REQUIRE_NATIVE_PYTHON', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
             'SHARDLOOM_BIN', 'SHARDLOOM_SURFACE_TEST_BINARY', 'SHARDLOOM_REPO_ROOT',
             'SHARDLOOM_PROFILE_ORDER', 'PYTHONPATH', 'PYTHONHOME'):
    core_environment += ['-u', name]
checks = [
    ('release-build-preparation-r1', 3600, ['env', 'PYO3_PYTHON=' + python, 'cargo', 'build',
        '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
        '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime-preparation-r1', 300, [python, '-B', str(directory / 'freeze_runtime.py'),
        '--build', 'release-build-preparation-r1.json', '--name', runtime.name]),
    ('public-release-preparation-r1', 1200, ['env', 'PYTHONPATH=python/src:python/tests',
        'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
        'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(runtime / 'lib_native.dylib'),
        'SHARDLOOM_BINARY=' + str(runtime / 'shardloom'),
        'TMPDIR=' + str(public_work), build_python, '-B', '-m', 'unittest', '-v',
        'test_native_uuid_binding', 'test_native_result_schema']),
    ('installed-preparation-r1', 2400, [build_python, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(installed), '--native-library', str(runtime / 'lib_native.dylib'),
        '--cli-binary', str(runtime / 'shardloom'), '--wheelhouse',
        '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse']),
    ('python-core-preparation-r1', 900, [*core_environment, str(installed / 'venv/bin/python'),
        '-B', 'scripts/run_python_test_shard.py', '--shard', 'core',
        '--output-dir', str(out / 'python-core-r1')]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(directory / 'guard_uuid_preparation.py'),
                    '--preparation', '--name', name, '--timeout', str(timeout), '--', *command], check=True)
