"""Run full source-stable checks while the preceding hosted closeout finishes."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
guard = directory / 'guard_uuid_preparation.py'
native = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
checks = [
    ('format-preparation-r1', 300, ['cargo', 'fmt', '--all', '--', '--check']),
    ('native-clippy-preparation-r1', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace',
        '--all-targets', '--features', native, '--', '-D', 'warnings']),
    ('native-tests-preparation-r1', 3600, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked',
        '--workspace', '--all-targets', '--features', native]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(guard), '--preparation', '--name', name,
                    '--timeout', str(timeout), '--', *command], check=True)
