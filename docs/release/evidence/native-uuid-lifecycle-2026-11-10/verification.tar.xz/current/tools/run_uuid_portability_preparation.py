"""Run unchanged-source portability checks while prior hosted closeout is pending."""
from pathlib import Path
import subprocess
import sys

directory = Path(__file__).parent
checks = [
    ('default-clippy-preparation-r1', 1800, ['cargo', 'clippy', '--offline', '--locked',
        '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-preparation-r1', 1800, ['cargo', 'test', '--offline', '--locked',
        '--workspace', '--all-targets']),
    ('features-preparation-r1', 3600, [sys.executable, '-B', str(directory / 'check_uuid_features.py')]),
    ('msrv-preparation-r1', 3600, [sys.executable, '-B', str(directory / 'check_uuid_msrv.py')]),
]
for name, timeout, command in checks:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(directory / 'guard_uuid_preparation.py'),
        '--preparation', '--name', name, '--timeout', str(timeout), '--', *command], check=True)
