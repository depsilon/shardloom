"""Use the repository's committed Arrow array provider test and lint contract."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/native-uuid-lifecycle/shardloom-local-repo')
sys.path.insert(0, str(root / 'scripts'))
from ci_provider_tests import commands

frozen = root / '.github/provider-locks/arrow-array.lock'
target = root / 'vendor/arrow-array/Cargo.lock'
assert not target.is_symlink()
shutil.copyfile(frozen, target)
identity = hashlib.sha256(frozen.read_bytes()).hexdigest()
env = dict(os.environ, CLIPPY_CONF_DIR=str(root / 'vendor/arrow-array'))
for original in commands('arrow-array'):
    command = [*original[:2], '--offline', *original[2:]]
    print(command, flush=True)
    subprocess.run(command, cwd=root, env=env, check=True)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == identity
