"""Seal UUID source, runtime and saved verification observations for portable replay."""
import argparse
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import zipfile

from verify_uuid_packet import (
    BASE, BASE_TREE, FROZEN, LIMITATIONS, MODULES, NATIVE_TEST_SOURCES,
    PRIOR_CORE_RECEIPTS, ROLES, SOURCE_POLICY, digest, embedded_evidence,
    failed_records, fingerprint, identity, rust_counts, source_deltas, test_methods, verify,
)

ROOT = Path('/Users/dylan/.codex/worktrees/native-uuid-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'variant-lifecycle-2026-11-09'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--plan', type=Path, required=True)
parser.add_argument('--destination', type=Path, required=True)
parser.add_argument('--execution-name', required=True)
args = parser.parse_args()
assert args.destination.resolve().is_relative_to(OUT) and not args.destination.exists()
assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)


def read(path):
    return json.loads(path.read_bytes())


plan = read(args.plan)
roles = plan['roles']
assert set(roles) == ROLES and len(set(roles.values())) == len(ROLES)
receipts = {role: read(OUT / filename) for role, filename in roles.items()}
source = receipts['docs']['build_sources']
checks, reused = {}, {}
for role, filename in roles.items():
    receipt = receipts[role]
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    raw = (OUT / filename).with_suffix('.log').read_bytes()
    assert digest(raw) == receipt['log_sha256']
    checks[role] = dict(receipt=filename, status='passed', command=receipt['command'], rust_tests=rust_counts(raw))
    if receipt['source_validation_mode'] == 'preparation_no_source_changes':
        reused[role] = dict(receipt=filename, original_mode=receipt['source_validation_mode'],
            original_head=receipt['head'], final_base=BASE, equal_base_tree=BASE_TREE,
            compared_scope='complete_vendor_provider_graph' if role == 'provider_arrow' else 'all_inputs_except_named_status_prose')
installed = read(OUT / plan['installed_report'])
installed_root = (OUT / plan['installed_report']).parent
assert installed['status'] == installed['uninstall_status'] == 'passed'
wheel_path = installed_root / 'dist' / installed['integrity']['wheel']
assert digest(wheel_path.read_bytes()) == installed['integrity']['wheel_sha256']
python_sources = {name: info for name, info in source.items()
    if name.startswith('python/src/shardloom/') and name.endswith('.py')}
with zipfile.ZipFile(wheel_path) as archive:
    for name, info in python_sources.items():
        assert identity(archive.read(name.removeprefix('python/src/'))) == info
    for suffix, key in (('/_native.abi3.so', 'native_library_sha256'), ('/bin/macos-aarch64/shardloom', 'cli_sha256')):
        names = [name for name in archive.namelist() if name.endswith(suffix)]
        assert len(names) == 1 and digest(archive.read(names[0])) == installed['integrity'][key]
wheel_sources = dict(status='passed', wheel_sha256=installed['integrity']['wheel_sha256'], python_sources=python_sources)
wheel_identity = OUT / 'wheel-source-identity.json'
if wheel_identity.exists():
    assert read(wheel_identity) == wheel_sources
else:
    with wheel_identity.open('x') as stream:
        json.dump(wheel_sources, stream, indent=2)
        stream.write('\n')
files = {}


def add(path, relative):
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    assert relative not in files or files[relative] == raw
    files[relative] = raw


# Current results and immutable source snapshots are retained. Runtime payloads,
# installed environments and generated staging are represented by identities.
selected = [*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('*.py'),
            *OUT.glob('source-blobs/*'), *OUT.glob('tools/*.py')]
for pattern in ('installed-proof-*/*.json', 'installed-proof-*/*.log', 'python-core-*/*.json',
                'python-core-*/*.log', 'controls-*/*.json', 'controls-*/*.log',
                '*-retirement-*/*.json', '*-retirement-*/*.xz'):
    selected.extend(OUT.glob(pattern))
for path in sorted(set(selected)):
    if path.name in {args.execution_name + '.json', args.execution_name + '.log'}:
        continue
    add(path, 'current/' + path.relative_to(OUT).as_posix())
omitted = embedded_evidence(files)
for row in omitted:
    assert identity(files.pop('current/source-blobs/' + row['sha256'])) == {key: row[key] for key in ('bytes', 'sha256')}
closeout = read(PRIOR / 'variant-closeout-r1.json')
assert closeout['status'] == 'complete' and closeout['merge_commit'] == BASE
add(PRIOR / 'variant-closeout-r1.json', 'prior/variant-closeout-r1.json')
add(ROOT / 'docs/release/evidence/native-variant-lifecycle-2026-11-09/acceptance.json', 'prior/acceptance.json')
prior_names = set(PRIOR_CORE_RECEIPTS)
for name in ('pr1674-premerge-r1.json', 'variant-main-r1.json'):
    prior_names.update(read(PRIOR / name)['raw_sources'])
for name in sorted(prior_names):
    assert identity((PRIOR / name).read_bytes()) == closeout['receipts'][name]
    add(PRIOR / name, 'prior/' + name)
dispositions = read(OUT / plan['failure_dispositions'])
failures = failed_records(files)
assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
for row in failures:
    row['disposition'] = dispositions[row['receipt'].removeprefix('current/')]
    assert row['disposition']
core = read(OUT / plan['python_core_receipt'])
core_log = (OUT / roles['python_core']).with_suffix('.log').read_bytes()
count = re.search(rb'Ran (\d+) tests? in [0-9.]+s', core_log)
assert count
native_tests = sorted(name for path in NATIVE_TEST_SOURCES for name in re.findall(
    r'\bfn\s+(native_uuid_\w+)\s*\(', (ROOT / path).read_text()))
public_tests = sorted(name for module in MODULES for name in test_methods(
    (ROOT / 'python/tests' / (module + '.py')).read_bytes(), module))
report = dict(schema_version='shardloom.uuid_lifecycle_acceptance.v1', status='local_acceptance_passed',
    source_base=BASE, source_snapshot=source, source_fingerprint_sha256=fingerprint(source),
    source_deltas={role: source_deltas(receipt['build_sources'], source) for role, receipt in receipts.items()},
    source_scope_policy=SOURCE_POLICY, preparation_reuse=reused,
    base_adoption=identity((OUT / 'uuid-base-adoption-r1.json').read_bytes()),
    roles=roles, checks=checks, required_native_tests=native_tests, public_tests=public_tests,
    prior_included_receipts=sorted(prior_names), frozen_references=FROZEN,
    runtime_identity=plan['runtime_identity'], omitted_embedded_evidence=omitted,
    runtime_and_wheel={key: installed['integrity'][key] for key in ('cli_sha256', 'native_library_sha256', 'wheel_sha256')},
    python_core_receipt=plan['python_core_receipt'], python_core=dict(discovered_test_cases=core['test_count'],
        reported_test_runs=int(count[1]), skip_records=core['skipped_count'], failures=core['failure_count'], errors=core['error_count']),
    installed_report=plan['installed_report'], installed_package=installed['integration'],
    original_failures=failures, failure_dispositions=plan['failure_dispositions'],
    limitations=LIMITATIONS, hosted_integration='pending',
    performance_claim=False, publication_attempted=False, whole_item_19_complete=False,
    archive='verification.tar.xz', members=[dict(path=name, **identity(raw)) for name, raw in sorted(files.items())])
assert sum(len(raw) for raw in files.values()) < 512 << 20
args.destination.mkdir()
with tarfile.open(args.destination / report['archive'], 'w:xz', preset=6) as archive:
    for row in report['members']:
        entry = tarfile.TarInfo(row['path'])
        entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
        archive.addfile(entry, io.BytesIO(files[row['path']]))
report['archive_sha256'] = digest((args.destination / report['archive']).read_bytes())
(args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copyfile(OUT / 'tools/verify_uuid_packet.py', args.destination / 'verify.py')
print(json.dumps(verify(args.destination, ROOT), sort_keys=True))
