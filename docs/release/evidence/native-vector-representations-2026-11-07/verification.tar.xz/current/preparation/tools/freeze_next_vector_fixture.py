"""Freeze the complete independent mixed fixture before native implementation."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc
import pyarrow.parquet as pq

from next_vector_fixture import fixture

OUT = Path(__file__).resolve().parents[1] / "next-vector-fixture-r2"
assert not OUT.exists()
OUT.mkdir()


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def row_bytes(rows):
    # This distinguishes signed zero and preserves all integer magnitudes.
    return json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode()


def field_shape(field, *, list_child=False):
    dtype = field.type
    metadata = dict(field.metadata or {})
    extension = None
    if isinstance(dtype, pa.BaseExtensionType):
        # Built-in tensor types own their interpretation and participate in
        # Arrow type equality; the Python custom-extension serializer is not
        # exposed by every built-in extension. Keep this exact type as well
        # as the recursively inspected storage and ordinary field metadata.
        extension = dtype
        dtype = dtype.storage_type
    if pa.types.is_list(dtype) or pa.types.is_large_list(dtype) or pa.types.is_fixed_size_list(dtype):
        shape = ["fixed" if pa.types.is_fixed_size_list(dtype) else "list",
                 dtype.list_size if pa.types.is_fixed_size_list(dtype) else None,
                 field_shape(dtype.value_field, list_child=True)]
    elif pa.types.is_struct(dtype):
        shape = ["struct", [field_shape(child) for child in dtype]]
    else:
        shape = str(dtype)
    return ["item" if list_child else field.name, field.nullable, shape, extension,
            sorted((key.decode(), value.decode()) for key, value in metadata.items())]


def schema_shape(schema):
    # Apply the independent Arrow extension interpretation to both sides.
    schema = ipc.read_schema(schema.serialize())
    return [field_shape(field) for field in schema]


table, expected = fixture(pa)
assert table.num_rows == 6 and len(table.schema) == 11
assert row_bytes(table.to_pylist()) == row_bytes(expected)
(OUT / "expected-rows.json").write_bytes(row_bytes(expected) + b"\n")
(OUT / "schema.arrow").write_bytes(table.schema.serialize().to_pybytes())
with ipc.new_file(OUT / "input.arrow", table.schema) as writer:
    writer.write_table(table)
pq.write_table(table, OUT / "input.parquet")
with ipc.open_file(OUT / "input.arrow") as reader:
    arrow = reader.read_all()
embedded = ipc.read_schema(pa.BufferReader(base64.b64decode(
    pq.read_metadata(OUT / "input.parquet").metadata[b"ARROW:schema"], validate=True)))
parquet = pq.read_table(OUT / "input.parquet", schema=embedded)
for name, actual in (("arrow", arrow), ("parquet", parquet)):
    assert row_bytes(actual.to_pylist()) == row_bytes(expected), name
    assert schema_shape(actual.schema) == schema_shape(table.schema), (name, actual.schema)

report = {"status": "passed", "rows": len(expected), "fields": len(table.schema),
    "pyarrow_version": pa.__version__, "complete_values_including_signed_zero": True,
    "logical_schema_and_metadata_exact": True, "formats": ["arrow_ipc", "parquet"],
    "scope": "independent frozen reference only; no ShardLoom execution or performance claim",
    "source": identity(Path(__file__)), "fixture_source": identity(Path(__file__).with_name("next_vector_fixture.py")),
    "artifacts": {path.name: identity(path) for path in sorted(OUT.iterdir()) if path.is_file()}}
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "rows", "fields", "formats", "scope")}))
