# Provisional next-unit reasoning

Prepared while Float16 PR #1663 checks run. This is a design draft, not an
implementation or an accepted contract. First finish Float16 exact-main
verification and guarded retirement. Then ground a new source branch in the
accepted merge and write its architecture contract before code.

The next coherent unit is item 19 step 4's sparse and quantized vector carriage.
It must retain original codes/indices/values and interpretation, with no
densification, sorting/merging of stored values, dequantization or vector
arithmetic. Existing Float16, lists, tensor owners and five public interfaces
provide the baseline. No new dependency or provider version is needed.

## Candidate contract for primary review

- `shardloom.sparse_vector.v1`: prefer a logical extension over native struct
  fields `size` (U64), `indices` and `values` (lists). Keeping dimension per row
  avoids imposing a fixed-dimension-column limitation on sparse carriage;
  optional `uniform_size` metadata can constrain homogeneous collections.
  Indices use any native signed/unsigned integer width (their width stays intact), and values are
  F16/F32/F64. Parent-present rows require a present dimension and lists of equal
  length, nonnull indices in [0, size), and the declared ordering/duplicate
  policy. Values retain separate component nullability, explicit zeros, signed
  zeros and admitted nonfinite representations. Empty vectors and dimension
  zero are valid. Dimension must not cause dimension-sized allocation.
- Prefer one versioned `index_policy=preserve|strictly_increasing` field.
  Preserve carries any order and duplicates verbatim, without defining a
  duplicate-combination arithmetic operation. Strictly increasing verifies
  ascending unique coordinates without extra per-row storage. This admits every
  supplied ordering/duplicate pattern for carriage while avoiding an unnecessary
  unordered-uniqueness scratch allocation. Arbitrary combinations of separate
  ordering/uniqueness annotations are not part of this v1 identity. Do not sort,
  merge or densify supplied arrays. Exact operations remain later contracts.
- `shardloom.quantized_vector.v1`: a logical affine-code extension over struct
  fields `codes`, `scale`, `zero_point`. Codes use an exact native integer type
  and a list, whose length is the vector dimension; optional `uniform_size`
  metadata constrains homogeneous collections. Scale uses F16/F32/F64, and zero
  point uses the code integer type. Per-vector parameters are scalars. A positive
  `block_size` declares list parameters of ceil(dimension / block_size); block
  size 1 is per-component. Validate with checked arithmetic, no reconstructed float
  buffer. Present parameters require finite positive scales and nonnull zero
  points. Preserve code/parameter primitive widths and bits. Zero dimensions
  and component-null code values need explicit contracts and tests.
- Exact integer codes up to 64 bits are storage, not a promise of floating
  reconstruction precision. Affine interpretation is (code - zero_point)*scale;
  rounding/output precision belongs to a later explicit operation. No claim to
  every packed sub-byte/nonlinear/codebook quantization or quantized tensor
  representation. Admit only the named version and layout; reject unsupported
  schemes rather than stripping them.
- Optional embedding identity should reuse the existing versioned embedding
  identity fields. A promising simple shape is the same optional flat identity
  fields alongside version/dimension/policies, using the existing shared field
  allowlist and Python normalization. This avoids a second nested metadata
  parser or JSON strings inside JSON. Decide and document this before code:
  typed identity must survive without assuming dimensions establish same space.
- Use matching ShardLoom Arrow extension IDs over structural storage. These are
  custom column extensions, not Arrow's SparseTensor IPC message or canonical
  Arrow sparse/quantized types. Vortex SparseArray is an encoded array provider,
  not this logical sparse-vector representation. See the verified inventory.

## Existing ownership and validation boundaries

Reuse session extension registration, charged metadata parsing, recursive
payload copy/gather, typed JSON, native Arrow conversion, import preparation,
spill, results, columnar sinks and Python schema/result paths. Complete Arrow
intake validates cross-field relations with original ancestor visibility before
masks can hide invalid source data. Native selected copying validates only the
observed selection and original valid-parent domain. Null parents must not
expose invalid hidden children. Include slices/nonzero offsets, empty files,
source-free child reopen and exact child widths. Current Arrow file-ingest
dictionary admission is scalar-only (native_payload_schema.rs:399-407); rich
dictionary import is a separate admission decision, not an existing guarantee.
Test explicit refusal unless it is deliberately implemented and proved here.

Keep Vortex-native persistence and schema-bearing Arrow IPC/Parquet exports.
Limited formats must refuse before producer/staging work under existing rich
extension policies. No hidden Arrow execution substrate or external fallback.

## Acceptance to freeze

Mixed scalar/nested/Float16/dense/tensor/sparse/quantized fixtures through import,
retain, selection/reordering/duplicates, ordinary-key join, stream, forced native
spill, write, separate-process reopen after source removal, and independent
export readback. Verify complete values/metadata, all five public interfaces,
declared policies, huge sparse dimension with tiny nnz, empty/null data,
malformed dimensions/lengths/index ranges/duplicates/order/parameters, parent
visibility, cancellation, denial/shrink, source change, retained owners and
preflight/fanout failures. Explicitly preserve all original failures. No
performance claim or new benchmark campaign is authorized by this preparation.

Use focused tests, required default/native workspace gates, feature builds,
ordinary installed wheel proof, portable evidence and corruption controls.
Implementation/test design and final acceptance remain with the primary.

## Additional source findings before choosing kernels

The primary verified the leaf's complete validation caller inventory in
next-validation-caller-inventory.json. The legacy ingest provider_batch call has
no explicit LiveMemoryPool and relies on existing batch headroom; the two owned
intake calls have pools. This reinforces avoiding new per-row duplicate sets.

Vortex array source is the pinned local vendor/vortex-array, not a registry
directory. ArrayRef::execute_scalar is a one-off probe (array/erased.rs:303).
ExecutionCtx is not an across-row result cache. The provider has repeated_probe
and RepeatedArrayProbe (array/probe/repeated.rs:24-58), retaining encoding,
validity and child-probe state across reads. No production ShardLoom call to
repeated_probe was found. Assess memory/selection/cancellation and certify a
selected use before adopting it; do not assume existing admission or claim
performance. Existing native_list::Column::into_indexed prepares only list
coordinates through NativeNumericOwner. Numeric owners retain original-width
primitive buffers and validity. A validator must inspect selected coordinates
and required interpretation parameters without eagerly reading vector values
or quantization codes merely to validate lengths.

## Primary review decisions to carry into the implementation contract

The November 7 primary review favors all eight native integer widths for sparse
coordinates and affine codes. `NativeNumericOwner::integer_ordinal` reads these
exactly into i128 registers; Float16/32/64 scale validation can use
`numeric_value` because every such source value widens exactly. Do not route
integer range validation through f64. Size remains U64 per row, permitting a
huge logical dimension with tiny stored nnz and without dimension-sized memory.

Keep representation and optional embedding identity fields flat. Sparse wire
metadata requires `version=1` and `index_policy=preserve|strictly_increasing`;
`uniform_size` is an optional U64. Quantized metadata requires `version=1` and
`parameter_mode=per_vector|blocked`; `block_size` is present and positive only
for blocked mode. A missing block_size in blocked mode, a block_size in
per_vector mode, unknown fields/versions, duplicate keys and noninteger sizes
are deterministic refusals. The extension ID defines affine interpretation;
do not add a redundant scheme selector or silently accept alternative schemes.
The seven existing embedding identity fields are optional nonempty strings or
null. Preserve supplied omission/null distinctions for those identity fields.
Public constructors fill mandatory interpretation defaults before serialization.

For present sparse rows, size, indices and values must be present; coordinates
must be nonnull, in range and obey index_policy, and the two list lengths must
match. Values may contain null components when declared nullable. Repeated
coordinates under preserve remain exactly ordered stored entries and do not
imply an addition/overwrite policy. Sparse dimension zero requires empty lists.
For present quantized rows, codes and required parameters must be present;
codes may contain null components when declared nullable. Scales are finite and
strictly positive, and zero points are nonnull with the same primitive code
type. A per-vector zero-dimensional row still requires its scalar parameters;
blocked zero-dimensional rows require empty parameter lists. Use quotient and
remainder for ceil division rather than potentially overflowing addition.

Nullable storage-field declarations can be retained, as in variable tensors;
the cross-field row validator enforces required values only for visible,
present extension rows. Convenience constructors declare size/list containers
and zero-point storage nonnullable, preserving the supplied item/code/index/scale
type nullability. A null parent does not expose its hidden storage. Sparse
and quantized values can themselves be nested under lists and structs; a list
of such vectors is explicitly a collection, not flattened vector storage.

Native validation should select rows first, reuse native_list coordinates, and
resolve only selected coordinate/parameter ranges into original-width numeric
owners under explicit memory admission and cancellation. Avoid a new repeated
probe API intake merely for this unit: its retained metadata allocations and
encoding behavior would require separate proof. Scalar probing is suitable for
constant-count size/per-vector fields; do not use it for each sparse index.
Existing numeric decode comments explicitly disclaim provider allocation/RSS
bounds. Any selected-range decode must carry the existing provider headroom
contract and a bounded expansion grant; do not claim all provider allocations
are credited. Codes and sparse values are not read just to establish structure;
ordinary observed payload validation still applies the declared float policy.

Extend the existing complete Arrow intake traversal for cross-field rich
extensions rather than copying its ancestor-visibility traversal into a second
module. Keep the existing variable-tensor failure semantics and tests intact.
The new visitor can identify tensor/sparse/quantized rules, while native payload
and typed-JSON checks share each representation's scalar/length policy.

Public type constructors should follow the existing `types` conventions:
`sparse_vector(item, *, index="uint32", index_policy="preserve",
uniform_size=None, metadata=None, nullable=True)` and
`quantized_vector(code, *, scale="float32", block_size=None,
uniform_size=None, metadata=None, nullable=True)`. The item/code declaration
controls component nullability; structural storage plus metadata remains the
exact round-trip form, like variable_shape_tensor. Matching dimensions or
metadata labels alone authorize no vector comparison.

This remains scratch preparation. No source contract is frozen, source branch
created or implementation started before Float16 exact-main closeout.
