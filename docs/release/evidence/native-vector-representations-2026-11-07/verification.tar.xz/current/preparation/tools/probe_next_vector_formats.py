"""Independent format grounding only; no ShardLoom execution or support claim."""
from __future__ import annotations

import hashlib
import json
import argparse
from pathlib import Path

import pyarrow as pa
import pyarrow.ipc as ipc
import pyarrow.parquet as pq

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--name", required=True, choices=("next-vector-format-probe-r2",))
args = parser.parse_args()
OUT = Path(__file__).resolve().parents[1] / args.name
assert not OUT.exists()
OUT.mkdir()


def tagged(name, dtype, metadata):
    raw = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode()
    return pa.field(name, dtype, metadata={
        b"ARROW:extension:name": ("shardloom." + name + ".v1").encode(),
        b"ARROW:extension:metadata": raw,
    })


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def logical_field(field, *, list_child=False):
    dtype = field.type
    if pa.types.is_list(dtype):
        dtype = pa.list_(logical_field(dtype.value_field, list_child=True))
    elif pa.types.is_struct(dtype):
        dtype = pa.struct([logical_field(child) for child in dtype])
    # Parquet's compliant nested encoding returns the element field name.
    # Vortex List DType owns element dtype/nullability, not an element name.
    # Preserve every struct field name, primitive width and metadata value.
    return pa.field("item" if list_child else field.name, dtype,
                    nullable=field.nullable, metadata=field.metadata)


def logical_schema(schema):
    return pa.schema([logical_field(field) for field in schema], metadata=schema.metadata)


observations = []
integers = [pa.int8(), pa.int16(), pa.int32(), pa.int64(),
            pa.uint8(), pa.uint16(), pa.uint32(), pa.uint64()]
floating = [pa.float16(), pa.float32(), pa.float64()]
for integer in integers:
    signed = pa.types.is_signed_integer(integer)
    lo = -(1 << (integer.bit_width - 1)) if signed else 0
    hi = (1 << (integer.bit_width - int(signed))) - 1
    for real in floating:
        for required_nullable in (False, True):
            for blocked in (False, True):
                scalar = pa.field("item", real, nullable=required_nullable)
                zero = pa.field("item", integer, nullable=required_nullable)
                params = {
                    "version": 1,
                    "parameter_mode": "blocked" if blocked else "per_vector",
                    "space_id": "unknown-space Ω",
                    "model_version": None,
                }
                if blocked:
                    params["block_size"] = 2
                quantized = tagged("quantized_vector", pa.struct([
                    pa.field("codes", pa.list_(integer), nullable=required_nullable),
                    pa.field("scale", pa.list_(scalar) if blocked else real,
                             nullable=required_nullable),
                    pa.field("zero_point", pa.list_(zero) if blocked else integer,
                             nullable=required_nullable),
                ]), params)
                sparse = tagged("sparse_vector", pa.struct([
                    pa.field("size", pa.uint64(), nullable=required_nullable),
                    pa.field("indices", pa.list_(pa.field("item", integer, nullable=False)),
                             nullable=required_nullable),
                    pa.field("values", pa.list_(real), nullable=required_nullable),
                ]), {"version": 1, "index_policy": "preserve", "space_id": "unknown-space Ω"})
                qrows = [
                    {"codes": [lo, hi, None], "scale": [0.5, 2.0] if blocked else 0.5,
                     "zero_point": [lo, hi] if blocked else lo},
                    None,
                    {"codes": [], "scale": [] if blocked else 0.25,
                     "zero_point": [] if blocked else hi},
                ]
                srows = [
                    {"size": (1 << 64) - 1, "indices": [hi, 0, hi],
                     "values": [-0.0, 1.5, None]},
                    None,
                    {"size": 0, "indices": [], "values": []},
                ]
                # Slice a nonzero top-level offset while retaining parent nulls.
                schema = pa.schema([sparse, quantized])
                source = pa.Table.from_arrays([
                    pa.array([srows[2], *srows], type=sparse.type),
                    pa.array([qrows[2], *qrows], type=quantized.type),
                ], schema=schema).slice(1)
                stem = f"{integer}-{real}-{int(required_nullable)}-{int(blocked)}"
                paths = {"ipc": OUT / (stem + ".arrow"),
                         "parquet": OUT / (stem + ".parquet")}
                with pa.OSFile(str(paths["ipc"]), "wb") as stream:
                    with ipc.new_file(stream, source.schema) as writer:
                        writer.write_table(source)
                pq.write_table(source, paths["parquet"])
                for format_name, path in paths.items():
                    if format_name == "ipc":
                        with ipc.open_file(path) as reader:
                            actual = reader.read_all()
                    else:
                        actual = pq.read_table(path)
                    assert logical_schema(actual.schema).equals(logical_schema(schema), check_metadata=True), (stem, format_name, actual.schema)
                    assert actual.to_pylist() == source.to_pylist(), (stem, format_name)
                    # Python equality ignores signed zero. Read the original-width
                    # sparse floating bytes independently to prove that bit too.
                    values = actual.column(0).combine_chunks().field("values").values
                    negative_zero = int.from_bytes(values.buffers()[1].to_pybytes()[:real.bit_width // 8], "little")
                    assert negative_zero == 1 << (real.bit_width - 1), (stem, format_name, negative_zero)
                    observations.append({"case": stem, "format": format_name,
                        "rows": actual.num_rows, "logical_schema_and_metadata_exact": True,
                        "list_child_names_changed": not actual.schema.equals(schema, check_metadata=True),
                        "complete_values_exact": True, "signed_zero_exact": True,
                        "artifact": path.name, **identity(path)})

report = {"status": "passed", "pyarrow_version": pa.__version__,
          "cases": len(observations), "observations": observations,
          "scope": "independent PyArrow reference format proof only; no ShardLoom execution",
          "native_support_claim": False, "performance_claim": False,
          "list_child_name_contract": "Only generated list element names normalize; struct field names, primitive widths, nullability and extension metadata are exact.",
          "source": identity(Path(__file__))}
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "pyarrow_version", "cases", "scope")}))
