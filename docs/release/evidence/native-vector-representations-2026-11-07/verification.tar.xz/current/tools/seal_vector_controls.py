"""Independently check exact corruption fixtures and preserve their outputs."""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = ROOT / 'docs/release/evidence/native-vector-representations-2026-11-07'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', default='r1')
args = parser.parse_args()
assert args.attempt.replace('-', '').isalnum()
CONTROL = OUT / ('packet-controls-' + args.attempt)


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(path.read_bytes())


def contents(directory, report):
    raw = (directory / 'verification.tar.xz').read_bytes()
    assert identity(raw)['sha256'] == report['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in report['members']]
        result = {}
        for entry, row in zip(archive.getmembers(), report['members']):
            assert entry.isfile() and entry.size == row['bytes']
            raw = archive.extractfile(entry).read()
            assert identity(raw)['sha256'] == row['sha256']
            result[entry.name] = raw
        return result


receipt = read(CONTROL / 'receipt.json')
assert receipt['status'] == 'passed' and receipt['positive_controls'] == 2 and receipt['rejected_controls'] == 9
original = read(PACKET / 'acceptance.json')
for name, info in receipt['original_files'].items():
    assert identity((PACKET / name).read_bytes()) == info
driver = (OUT / 'tools/check_vector_packet_controls.py').read_bytes()
assert identity(driver)['sha256'] == receipt['driver_sha256']
data = contents(PACKET, original)
names = ['original', 'relocated', 'archive-byte-corruption', 'summary-count-corruption',
    'failed-native-check-resealed', 'skipped-installed-test-resealed', 'omitted-original-failure-resealed',
    'changed-source-blob-resealed', 'changed-installed-source-resealed', 'omitted-exhaustive-test-resealed',
    'failed-preceding-main-resealed']
assert [row['name'] for row in receipt['results']] == names
logs = {}
for index, row in enumerate(receipt['results']):
    raw = (CONTROL / (row['name'] + '.log')).read_bytes()
    assert identity(raw)['sha256'] == row['log_sha256']
    assert (row['returncode'] == 0) == (index < 2)
    assert row['expected'] == ('accept' if index < 2 else 'reject')
    if index >= 2:
        assert b'AssertionError' in raw or b'KeyError' in raw
    else:
        assert json.loads(raw)['status'] == 'passed'
    logs[row['name']] = raw.decode()
    if index:
        assert (CONTROL / row['name'] / 'verify.py').read_bytes() == (PACKET / 'verify.py').read_bytes()
for name in receipt['original_files']:
    assert (CONTROL / 'relocated' / name).read_bytes() == (PACKET / name).read_bytes()
directory = CONTROL / 'archive-byte-corruption'
assert read(directory / 'acceptance.json') == original
expected = bytearray((PACKET / 'verification.tar.xz').read_bytes())
expected[len(expected) // 2] ^= 1
assert (directory / 'verification.tar.xz').read_bytes() == expected
directory = CONTROL / 'summary-count-corruption'
expected = copy.deepcopy(original)
expected['python_core']['reported_test_runs'] += 1
assert read(directory / 'acceptance.json') == expected
assert (directory / 'verification.tar.xz').read_bytes() == (PACKET / 'verification.tar.xz').read_bytes()

for name in names[4:]:
    directory = CONTROL / name
    report = read(directory / 'acceptance.json')
    actual = contents(directory, report)
    wanted_report = copy.deepcopy(original)
    wanted = dict(data)
    if name == 'failed-native-check-resealed':
        key = 'current/' + original['roles']['native_tests']
        value = json.loads(wanted[key])
        value.update(status='failed', returncode=101)
        wanted[key] = json.dumps(value).encode()
    elif name == 'skipped-installed-test-resealed':
        for key in ('current/installed-proof-r1/report.json', 'current/installed-proof-r1/integration.json'):
            value = json.loads(wanted[key])
            target = value['integration'] if 'integration' in value else value
            target['skipped'] = 1
            wanted[key] = json.dumps(value).encode()
        wanted_report['installed_package']['skipped'] = 1
    elif name == 'omitted-original-failure-resealed':
        key = 'current/vectors-native-clippy-r1.json'
        del wanted[key]
        wanted_report['original_failures'] = [row for row in wanted_report['original_failures'] if row['receipt'] != key]
    elif name == 'changed-source-blob-resealed':
        info = original['code_snapshot']['python/tests/test_native_vector_representations_binding.py']
        wanted['current/source-blobs/' + info['sha256']] += b'\n'
    elif name == 'changed-installed-source-resealed':
        path = 'python/src/shardloom/types.py'
        old = original['code_snapshot'][path]
        raw = wanted['current/source-blobs/' + old['sha256']] + b'\n'
        new = identity(raw)
        wanted['current/source-blobs/' + new['sha256']] = raw
        wanted_report['code_snapshot'][path] = new
        key = 'current/' + original['roles']['installed']
        value = json.loads(wanted[key])
        value['changed_source_inventory'][path] = new
        wanted[key] = json.dumps(value).encode()
    elif name == 'omitted-exhaustive-test-resealed':
        key = 'current/installed-proof-r1/integration.log'
        raw = wanted[key]
        pattern = rb'^test_vector_every_integer_and_float_width_retains_typed_and_arrow_storage [^\n]*\n'
        assert len(re.findall(pattern, raw, re.MULTILINE)) == 1
        raw = re.sub(pattern, b'', raw, flags=re.MULTILINE)
        count = original['installed_package']['tests'] - 1
        raw = re.sub(rb'Ran \d+ tests in', b'Ran ' + str(count).encode() + b' tests in', raw)
        wanted[key] = raw
        wanted_report['installed_package']['tests'] = count
        key = 'current/installed-proof-r1/integration.json'
        value = json.loads(wanted[key])
        value['tests'] = count
        wanted[key] = json.dumps(value).encode()
        key = 'current/installed-proof-r1/report.json'
        value = json.loads(wanted[key])
        value['integration']['tests'] = count
        next(step for step in value['steps'] if step['log'] == 'integration.log')['log_sha256'] = identity(raw)['sha256']
        wanted[key] = json.dumps(value).encode()
    else:
        assert name == 'failed-preceding-main-resealed'
        closeout = json.loads(wanted['prior/float16-closeout-r1.json'])
        main_name = next(key for key in closeout['receipts'] if re.fullmatch(r'float16-main1663-r\d+\.json', key)
            and json.loads(wanted['prior/' + key])['status'] == 'passed')
        main = json.loads(wanted['prior/' + main_name])
        raw_name = main_name.removesuffix('.json') + '-raw/checks.json'
        checks = json.loads(wanted['prior/' + raw_name])
        next(row for row in checks['check_runs'] if row['name'] in main['required_hosted_check_names'])['conclusion'] = 'failure'
        wanted['prior/' + raw_name] = json.dumps(checks).encode()
        main['raw_sources'][raw_name] = identity(wanted['prior/' + raw_name])['sha256']
        wanted['prior/' + main_name] = json.dumps(main).encode()
        for key in (raw_name, main_name):
            closeout['receipts'][key] = identity(wanted['prior/' + key])
        wanted['prior/float16-closeout-r1.json'] = json.dumps(closeout).encode()
        key = 'current/preparation-transfer-r1.json'
        value = json.loads(wanted[key])
        value['prior_float16_closeout_sha256'] = identity(wanted['prior/float16-closeout-r1.json'])['sha256']
        wanted[key] = json.dumps(value).encode()
    assert actual == wanted, name
    wanted_report['members'] = report['members']
    wanted_report['archive_sha256'] = report['archive_sha256']
    assert report == wanted_report, name

result = dict(status='passed', positive_controls=2, rejected_controls=9,
    exact_fixture_mutations_verified=True, original_packet_unchanged=True,
    observation=receipt, logs=logs, driver_source=driver.decode(), driver_sha256=identity(driver)['sha256'],
    primary_verifier_source=Path(__file__).read_text(),
    scope='Saved evidence consistency only; no native tests, builds, benchmarks or installation rerun.')
with (PACKET / 'corruption-controls.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'positive_controls', 'rejected_controls', 'exact_fixture_mutations_verified')}))
