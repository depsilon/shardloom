"""Preserve a complete, read-only open-PR observation after integration."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
destination = OUT / (args.name + '.json')
assert not destination.exists()
raw_pages, opened = [], []
complete = False
for page in range(1, 11):
    endpoint = ('repos/depsilon/shardloom/pulls?state=open&sort=created'
                '&direction=asc&per_page=100&page=' + str(page))
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', endpoint],
                                  stderr=subprocess.PIPE, timeout=50)
    assert len(raw) < 8 << 20
    rows = json.loads(raw)
    assert isinstance(rows, list) and len(rows) <= 100
    assert all(row['state'] == 'open' for row in rows)
    raw_pages.append(dict(endpoint=endpoint, sha256=hashlib.sha256(raw).hexdigest(),
                          raw_json=raw.decode()))
    opened.extend(dict(number=row['number'], title=row['title'], url=row['html_url'],
                       head=row['head']['sha'], base=row['base']['ref']) for row in rows)
    if len(rows) < 100:
        complete = True
        break
assert len({row['number'] for row in opened}) == len(opened)
source = Path(__file__).read_bytes()
record = dict(status='passed' if complete and not opened else 'needs_attention',
              observed_at=datetime.now(timezone.utc).isoformat(),
              repository='depsilon/shardloom', pages_complete=complete,
              open_prs=opened, raw_pages=raw_pages,
              observer_sha256=hashlib.sha256(source).hexdigest(),
              observer_source=source.decode())
with destination.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'pages_complete', 'open_prs')}))
raise SystemExit(0 if record['status'] == 'passed' else 2)
