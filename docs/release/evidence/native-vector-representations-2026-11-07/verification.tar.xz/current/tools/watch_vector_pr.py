"""Observe one immutable vector representation delivery after Float16 closeout."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = Path('/Users/dylan/LocalData/shardloom/float16-lifecycle-2026-11-07/float16-pr1663-r1.json')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pr', type=int, required=True)
parser.add_argument('--acceptance', type=Path, required=True)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert args.pr > 0 and re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', args.name)
destination = OUT / (args.name + '.json')
assert not destination.exists()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def gh(*arguments):
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', *arguments], cwd=ROOT,
        stderr=subprocess.PIPE, timeout=45)
    assert len(raw) < 8 << 20
    return json.loads(raw)

def api(path):
    return gh('api', 'repos/depsilon/shardloom/' + path)

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()

acceptance_raw = args.acceptance.read_bytes()
local = json.loads(acceptance_raw)
assert local['status'] == 'passed' and local['runtime_sources_match_build']
head = local['head']
assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == head
assert git('rev-parse', head + '^{tree}') == local['tree']
assert not git('diff', '--numstat', local['base'], head, '--', '.github/workflows')
assert git('rev-parse', head + ':.github/workflows/ci.yml') == local['ci_workflow_blob']
prior = json.loads(PRIOR.read_bytes())
required = {row['name'] for row in prior['checks'] if row['status'] == 'completed' and row['conclusion'] == 'success'}
assert len(required) == len(prior['checks']) == 58
result = dict(status='pending', pr=args.pr, head=head, initial_base=local['base'],
    source_tree=local['tree'], acceptance_sha256=digest(acceptance_raw),
    prior_check_names_sha256=digest(PRIOR.read_bytes()))
failure_conclusions = {'failure', 'cancelled', 'timed_out', 'action_required', 'startup_failure', 'stale'}

def observe():
    assert args.acceptance.read_bytes() == acceptance_raw
    pr = api(f'pulls/{args.pr}')
    assert pr['head']['sha'] == head and pr['state'] == 'open'
    base, branch = pr['base']['sha'], pr['base']['ref']
    assert re.fullmatch('[0-9a-f]{40}', base)
    assert base == local['base'] and branch == 'main', 'accepted base changed; revalidate integration'
    raw_checks = api(f'commits/{head}/check-runs?per_page=100&filter=latest')
    rows = raw_checks['check_runs']
    assert len(rows) == raw_checks['total_count'] <= 100
    assert all(row['head_sha'] == head for row in rows)
    selected = [{key: row[key] for key in ('id', 'name', 'status', 'conclusion', 'head_sha', 'html_url')} for row in rows]
    comments = api(f'issues/{args.pr}/comments?per_page=100')
    assert len(comments) < 100, 'review comments require pagination'
    states = [(json.loads(match.group(1))['code_review'], row['html_url']) for row in comments
        if row['user']['login'] == 'chatgpt-codex-connector[bot]'
        and (match := re.search(r'<!-- codex-review-state:v1 (.*?) -->', row['body']))]
    current = [(state, url) for state, url in states if state.get('commit_sha') == head]
    assert len(current) <= 1
    review, review_url = current[0] if current else ({}, None)
    names = {row['name'] for row in selected}
    failed = [row for row in selected if row['status'] == 'completed' and row['conclusion'] in failure_conclusions]
    passed = [row for row in selected if row['status'] == 'completed' and row['conclusion'] == 'success']
    details = dict(base=base, base_branch=branch, checks=selected, review=review, review_url=review_url,
        review_scope='automated_current_head', base_transitions=[],
        missing=sorted(required - names), failures=failed, successful_hosted_checks=len(passed),
        observed_checks=len(selected), observed_at=datetime.now(timezone.utc).isoformat(), mergeable=pr['mergeable'])
    if failed or review.get('has_unresolved_findings') is True:
        return 'needs_attention', details
    if len(passed) != len(selected) or required - names or review.get('status') != 'completed':
        return 'pending', details
    assert len(names) == len(selected) and names == required, 'inspect changed hosted check set'
    assert review.get('has_any_findings') is False and review.get('has_unresolved_findings') is False
    query = 'query($n:Int!){repository(owner:"depsilon",name:"shardloom"){pullRequest(number:$n){reviewDecision mergeable headRefOid baseRefOid reviewThreads(first:100){nodes{id isResolved isOutdated} pageInfo{hasNextPage}} reviews(first:100){nodes{state author{login}} pageInfo{hasNextPage}}}}}'
    audit = gh('api', 'graphql', '-F', 'n=' + str(args.pr), '-f', 'query=' + query)['data']['repository']['pullRequest']
    assert audit['headRefOid'] == head and audit['baseRefOid'] == base
    assert all(not audit[key]['pageInfo']['hasNextPage'] for key in ('reviewThreads', 'reviews'))
    details['audit'] = audit
    if (any(not row['isResolved'] for row in audit['reviewThreads']['nodes'])
            or audit['reviewDecision'] == 'CHANGES_REQUESTED' or audit['mergeable'] != 'MERGEABLE'):
        return 'needs_attention', details
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', f'refs/pull/{args.pr}/merge'], cwd=ROOT, check=True, timeout=90)
    assert git('rev-parse', 'FETCH_HEAD') == pr['merge_commit_sha']
    assert git('rev-parse', 'FETCH_HEAD^{tree}') == local['tree']
    details.update(synthetic=pr['merge_commit_sha'], tree_matches_synthetic=True)
    return 'passed_premerge', details

deadline, previous = time.monotonic() + 180 * 60, None
try:
    while time.monotonic() < deadline:
        try:
            status, details = observe()
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as error:
            if isinstance(error, subprocess.CalledProcessError) and not any(value in (error.stderr or b'')
                    for value in (b'HTTP 50', b'connection reset', b'i/o timeout', b'TLS handshake timeout')):
                raise
            result['latest_transient_observation_error'] = dict(observed_at=datetime.now(timezone.utc).isoformat(),
                error=type(error).__name__ + ': ' + str(error))
            time.sleep(40)
            continue
        result.update(details, status=status)
        (OUT / (args.name + '-progress.json')).write_text(json.dumps(result, indent=2) + '\n')
        marker = (status, details['successful_hosted_checks'], details['observed_checks'],
                  details['review'].get('status'), details['base_branch'])
        if marker != previous:
            print(datetime.now(timezone.utc).isoformat(), marker, flush=True)
            previous = marker
        if status != 'pending':
            break
        time.sleep(45)
    else:
        result['status'] = 'deadline'
except BaseException as error:
    result.update(status='observer_error', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(result['status'], str(destination), flush=True)
raise SystemExit(0 if result['status'] == 'passed_premerge' else 2)

