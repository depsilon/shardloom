"""Check original/relocated replay and meaningful resealed corruptions."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/release/evidence/native-vector-representations-2026-11-07'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', default='r1')
args = parser.parse_args()
assert args.attempt.replace('-', '').isalnum()
DEST = OUT / ('packet-controls-' + args.attempt)
assert not DEST.exists()
DEST.mkdir()
FILENAMES = ('acceptance.json', 'verification.tar.xz', 'verify.py')


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


original = {name: identity((PACKET / name).read_bytes()) for name in FILENAMES}
results = []


def clone(name):
    directory = DEST / name
    directory.mkdir()
    for filename in FILENAMES:
        shutil.copyfile(PACKET / filename, directory / filename)
        assert identity((directory / filename).read_bytes()) == original[filename]
    return directory, json.loads((directory / 'acceptance.json').read_bytes())


def save(directory, report):
    (directory / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')


def change_json(entries, name, update):
    value = json.loads(entries[name])
    update(value)
    entries[name] = json.dumps(value).encode()


def rewrite(directory, report, change):
    with tarfile.open(directory / 'verification.tar.xz', 'r:xz') as archive:
        entries = {entry.name: archive.extractfile(entry).read() for entry in archive.getmembers()}
    change(entries, report)
    report['members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(entries.items())]
    with tarfile.open(directory / 'verification.tar.xz', 'w:xz', preset=1) as archive:
        for row in report['members']:
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
            archive.addfile(info, io.BytesIO(entries[row['path']]))
    report['archive_sha256'] = identity((directory / 'verification.tar.xz').read_bytes())['sha256']
    save(directory, report)


def run(name, directory, accepted, repo_root=None):
    command = [sys.executable, '-I', str(directory / 'verify.py'), '--packet', str(directory)]
    if repo_root:
        command += ['--repo-root', str(repo_root)]
    result = subprocess.run(command, capture_output=True, timeout=120)
    raw = result.stdout + result.stderr
    assert len(raw) < 1 << 20
    (DEST / (name + '.log')).write_bytes(raw)
    results.append(dict(name=name, command=command, returncode=result.returncode,
        expected='accept' if accepted else 'reject', log_sha256=identity(raw)['sha256']))
    assert (result.returncode == 0) == accepted, name
    if accepted:
        assert json.loads(result.stdout)['status'] == 'passed'
    else:
        assert b'AssertionError' in raw or b'KeyError' in raw, (name, raw)


def failed_native(entries, report):
    change_json(entries, 'current/' + report['roles']['native_tests'], lambda v: v.update(status='failed', returncode=101))


def skipped_installed(entries, report):
    change_json(entries, 'current/installed-proof-r1/report.json', lambda v: v['integration'].update(skipped=1))
    change_json(entries, 'current/installed-proof-r1/integration.json', lambda v: v.update(skipped=1))
    report['installed_package']['skipped'] = 1


def omitted_failure(entries, report):
    name = 'current/vectors-native-clippy-r1.json'
    entries.pop(name)
    report['original_failures'] = [entry for entry in report['original_failures'] if entry['receipt'] != name]


def changed_blob(entries, report):
    name = 'python/tests/test_native_vector_representations_binding.py'
    key = 'current/source-blobs/' + report['code_snapshot'][name]['sha256']
    entries[key] += b'\n'


def changed_installed_source(entries, report):
    name = 'python/src/shardloom/types.py'
    old = report['code_snapshot'][name]
    raw = entries['current/source-blobs/' + old['sha256']] + b'\n'
    new = identity(raw)
    entries['current/source-blobs/' + new['sha256']] = raw
    report['code_snapshot'][name] = new
    change_json(entries, 'current/' + report['roles']['installed'], lambda v: v['changed_source_inventory'].update({name: new}))


def missing_exhaustive_test(entries, report):
    key = 'current/installed-proof-r1/integration.log'
    raw = entries[key]
    lines = raw.splitlines(keepends=True)
    removed = [line for line in lines if line.startswith(b'test_vector_every_integer_and_float_width_retains_typed_and_arrow_storage ')]
    assert len(removed) == 1
    raw = b''.join(line for line in lines if line not in removed)
    count = report['installed_package']['tests'] - 1
    raw = re.sub(rb'Ran \d+ tests in', b'Ran ' + str(count).encode() + b' tests in', raw)
    entries[key] = raw
    report['installed_package']['tests'] = count
    change_json(entries, 'current/installed-proof-r1/integration.json', lambda v: v.update(tests=count))
    def update(value):
        value['integration']['tests'] = count
        step = next(row for row in value['steps'] if row['log'] == 'integration.log')
        step['log_sha256'] = identity(raw)['sha256']
    change_json(entries, 'current/installed-proof-r1/report.json', update)


def failed_prior_main(entries, _):
    closeout = json.loads(entries['prior/float16-closeout-r1.json'])
    main_name = next(name for name in closeout['receipts'] if re.fullmatch(r'float16-main1663-r\d+\.json', name)
        and json.loads(entries['prior/' + name])['status'] == 'passed')
    main = json.loads(entries['prior/' + main_name])
    raw_name = main_name.removesuffix('.json') + '-raw/checks.json'
    checks = json.loads(entries['prior/' + raw_name])
    required = set(main['required_hosted_check_names'])
    next(row for row in checks['check_runs'] if row['name'] in required)['conclusion'] = 'failure'
    entries['prior/' + raw_name] = json.dumps(checks).encode()
    main['raw_sources'][raw_name] = identity(entries['prior/' + raw_name])['sha256']
    entries['prior/' + main_name] = json.dumps(main).encode()
    for name in (raw_name, main_name):
        closeout['receipts'][name] = identity(entries['prior/' + name])
    entries['prior/float16-closeout-r1.json'] = json.dumps(closeout).encode()
    change_json(entries, 'current/preparation-transfer-r1.json',
        lambda value: value.update(prior_float16_closeout_sha256=identity(entries['prior/float16-closeout-r1.json'])['sha256']))


try:
    run('original', PACKET, True, ROOT)
    relocated, _ = clone('relocated')
    run('relocated', relocated, True)
    directory, report = clone('archive-byte-corruption')
    raw = bytearray((directory / 'verification.tar.xz').read_bytes())
    raw[len(raw) // 2] ^= 1
    (directory / 'verification.tar.xz').write_bytes(raw)
    run('archive-byte-corruption', directory, False)
    directory, report = clone('summary-count-corruption')
    report['python_core']['reported_test_runs'] += 1
    save(directory, report)
    run('summary-count-corruption', directory, False)
    for name, change in [
        ('failed-native-check-resealed', failed_native),
        ('skipped-installed-test-resealed', skipped_installed),
        ('omitted-original-failure-resealed', omitted_failure),
        ('changed-source-blob-resealed', changed_blob),
        ('changed-installed-source-resealed', changed_installed_source),
        ('omitted-exhaustive-test-resealed', missing_exhaustive_test),
        ('failed-preceding-main-resealed', failed_prior_main),
    ]:
        directory, report = clone(name)
        rewrite(directory, report, change)
        run(name, directory, False)
    assert original == {name: identity((PACKET / name).read_bytes()) for name in FILENAMES}
    assert len(results) == 11
    receipt = dict(status='passed', positive_controls=2, rejected_controls=9,
        results=results, original_files=original, original_packet_unchanged=True,
        driver_sha256=identity(Path(__file__).read_bytes())['sha256'])
except BaseException as error:
    receipt = dict(status='failed', results=results, error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
