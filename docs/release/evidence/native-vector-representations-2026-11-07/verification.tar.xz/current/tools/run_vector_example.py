"""Execute the public rich-vector example and check every reopened value."""
import ast
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import runpy
import struct
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_binding import _load_native

_load_native()
captured = io.StringIO()
with redirect_stdout(captured):
    runpy.run_path(str(ROOT / 'python/examples/float16_vectors.py'), run_name='__main__')
lines = captured.getvalue().splitlines()
assert lines[0] == 'Dense, sparse and quantized vectors reopened from Vortex unchanged.', lines
expected = [
    {'id': 2, 'score': None, 'passages': [], 'image': None, 'samples': {'data': [], 'shape': [0, 2]},
     'sparse': {'size': 0, 'indices': [], 'values': []},
     'quantized': {'codes': [], 'scale': 0.25, 'zero_point': -2},
     'blocked': {'codes': [], 'scale': [], 'zero_point': []}},
    {'id': 1, 'score': 1.5, 'passages': [[0.5, -0.0, None], [1.0, 2.0, 3.0]],
     'image': [0.5, 1.0, None, 2.0], 'samples': {'data': [1.0, 2.0], 'shape': [1, 2]},
     'sparse': {'size': 10, 'indices': [7, 2, 2], 'values': [1.5, -0.0, None]},
     'quantized': {'codes': [-128, None, 127], 'scale': 0.25, 'zero_point': -2},
     'blocked': {'codes': [0, (1 << 64) - 1, None], 'scale': [0.5, 2.0], 'zero_point': [0, (1 << 64) - 1]}},
]
actual = [ast.literal_eval(line) for line in lines[1:]]
assert actual == expected, lines
for value in (actual[1]['passages'][0][1], actual[1]['sparse']['values'][1]):
    assert struct.pack('<d', value) == struct.pack('<d', -0.0)
print(captured.getvalue(), end='')
print(json.dumps({'status': 'passed', 'complete_reopened_rows': len(expected),
    'signed_zero_preserved': True, 'sparse_order_and_duplicates_preserved': True,
    'integer_code_extremes_preserved': True}))
