"""Execute a saved validation protocol with one guarded process at a time."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
parser = argparse.ArgumentParser()
parser.add_argument('protocol', type=Path)
args = parser.parse_args()
raw = args.protocol.read_bytes()
protocol = json.loads(raw)
name = protocol['name']
assert name.replace('-', '').isalnum()
receipt = OUT / (name + '.json')
assert not receipt.exists()
state = dict(status='running', protocol=args.protocol.name,
    protocol_sha256=hashlib.sha256(raw).hexdigest(), completed=[], active_stage=None)

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for entry in protocol['stages']:
        stage_name = entry['name']
        state['active_stage'] = stage_name
        save()
        print('Starting ' + stage_name, flush=True)
        result = subprocess.run([PYTHON, '-B', str(OUT / 'tools/guard_vectors.py'),
            '--name', stage_name, '--timeout', str(entry['timeout']), '--', *entry['command']],
            cwd=ROOT, check=False)
        stage = json.loads((OUT / (stage_name + '.json')).read_bytes())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], stage_name
        state['completed'].append(stage_name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
