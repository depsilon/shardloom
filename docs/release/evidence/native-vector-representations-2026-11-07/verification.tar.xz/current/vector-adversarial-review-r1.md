# Sparse and quantized representation review

The implementation stays within item 19 step 4: representation carriage through
the existing native source, selection, spill and sink owners. It adds no vector
arithmetic, quantization, query-engine integration, dependency or feature.

The primary review challenged three main risks:

1. Hidden children and sliced coordinates. The shared Arrow visitor applies
   every ancestor validity range before vector cross-field rules. Native copy
   validates selected row order and parent validity before accessing coordinate
   or parameter ranges. The new native-file tests distinguish an invalid hidden
   row from an observed invalid row, including stream and sink publication.
   Existing variable-tensor traversal and regression coverage remain present.
2. Integer rounding and loss of representation. Sparse bounds use original-width
   integer owners and i128 registers, including UInt64 maximum dimensions.
   Quantized carriage copies original integer codes and float scales; it never
   reconstructs a floating vector. Schema/metadata, component bits, ordering,
   duplicates and nullability are checked against the frozen reference.
3. Memory and accidental capability expansion. Selected validation acquires
   grants before provider execution, releases numeric owners before their grants,
   and checks cancellation during loops. Received metadata retains its allocator
   credit. Neither sparse dimensions nor quantized dimensions allocate a dense
   reconstruction. Rich-key refusal precedes generic nested-key admission;
   limited-format refusal precedes producer/staging work.

Inspection also covered exact metadata versions and duplicate/unknown fields,
   canonical JSON receive rules, block-size overflow and empty-vector semantics,
   typed-input preflight, new Python descriptors/constructors, native spill
   registration, source-free reopen, independent export readback and the two
   Clippy-driven helper splits. No unresolved code finding remains from this
   pass. Final default/native workspace checks pass 3,321/6,988 tests; the native
   suite retains 37 existing opt-in ignores. All seven feature configurations
   pass. The canonical Python core shard reports 857 runs among 1,247 discovered
   cases, 56 optional/environment skip records and no failures/errors. All 386
   isolated installed-package tests pass with zero failures, errors or skips,
   including all 11 new vector and 37 fixed/variable tensor/Float16 methods.
   Install, isolated load and uninstall pass. All 13 accepted stages have the
   same 39 runtime/test source records, including the removed tensor-only visitor.
   Portable evidence controls remain the next acceptance step.

Before packaging, static review corrected an overescaped required-test-name
   regular expression in the evidence verifier. All 23 required native test names
   were then matched against their passing workspace log records. This was found
   before any packet attempt; no native verification result was changed. The
   installed wheel was built after the public Python README update. Final
   architecture/status documentation is checked separately before delivery.

Known limits remain explicit: provider decode allocations are not all charged
   through the host allocator; this does not establish an RSS bound or a
   zero-decode validation guarantee. Rich dictionaries, vector keys/arithmetic,
   quantization/dequantization, ANN and text/Avro/ORC persistence are unadmitted.
   List offset width remains the existing compatibility boundary. There is no
   performance claim or package publication.
