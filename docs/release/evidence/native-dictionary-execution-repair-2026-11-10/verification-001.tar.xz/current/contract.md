# Dictionary execution repair

Repair the confirmed ShardLoom execute-parent callback error introduced during the Vortex 0.93 update. Vortex's executor may detach the codes slot before invoking the dictionary callback. Use the supplied current child, preserve complete native dictionary metadata and existing allocation admission, and decline other child/type combinations before touching parent child slots.

Vortex-first check: use_vortex_native_provider. The pinned Vortex 0.93 executor, ArrayParts, DictSlots and DictData already provide the necessary native concepts. Keep the repair within shardloom-vortex's existing feature-gated provider; no new dependency, unsafe restoration, Arrow materialization or external execution fallback. Existing output/scratch owner and last-buffer release contracts remain mandatory.

Verification: first reproduce against old implementation through actual executor stack; repair and exercise primitive/bool/decimal plus nullable/text/exclusion controls and memory denial/escape. Run required default and native workspace checks. Freeze a relevant correctness cohort containing all 96 failed requests and predefined passing controls before executing the repaired runtime. Preserve the original 10,000 exactly-once observation, all original outcomes and runtime identities. No automatic full 10k rerun or whole-suite performance claim.

The old full10k observation contains 9904 verified passes, 76 dictionary panics and 20 CLI no-JSON errors. The latter category's underlying cause remains unconfirmed. All 55 hosted main checks passed but do not prove this failed cohort. Prior runtimes, wheels, inputs and original failed evidence remain protected; only independently verified obsolete compiler output may be retired for storage.

Maintainer timing discussion: same 9904 passing cases used 1516.098849185 engine seconds versus 1478.577252992 previously (2.5376825% increase). This retrospective partial diagnostic excludes all 96 failures and is not a valid full10k comparison. The maintainer considers the difference modest. Earlier shared-work optimization delivered 17.1193% on the complete cohort and is already in the baseline. Subsequent capability/provider work has no demonstrated speedup on this suite; new index/window optimizations remain queued.

