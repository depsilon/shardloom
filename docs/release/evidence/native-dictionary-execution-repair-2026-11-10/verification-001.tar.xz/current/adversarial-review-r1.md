# Dictionary callback review

The review target is the three-file dictionary repair against
`8f426b3d2e774be2a9d30a731c33b8c830378d99`, before executing the frozen correctness
cohort. This is an implementation review, not a performance acceptance.

1. **Does the test reproduce the actual executor contract?** The pinned
   `vortex-array/src/executor.rs` detaches an `ExecuteSlot` child and invokes
   execute-parent kernels against its suspended parent. The installed-session
   text test reaches that path and failed on the original provider with the exact
   `DictSlots codes slot` panic. The fixed-width fixture uses Vortex's own empty
   kernel session to prevent eager kernels from bypassing `ExecuteSlot`; a
   counter proves the detached-slot callback ran. It never constructs an
   incomplete array itself.
2. **Can the repair still read missing parent data or use stale codes?** Admission
   checks the supplied child's encoding and index and the parent's dtype before
   reading child slots. A complete parent is reused only when its codes pointer
   equals the current child. Otherwise `Array::try_from_parts` validates a native
   dictionary built from that current child, the remaining values, original
   dtype/length/data, and inherited statistics. The executor detaches one slot;
   slot zero is the only admitted case. No vendored executor mutation, unsafe
   restoration, Arrow conversion or external engine is added.
3. **Does reconstructing the wrapper bypass resource admission or release?** Both
   paths use the existing fixed-width decoder and its memory owner. Tests use
   independently calculated bounds for numeric, Boolean and decimal output,
   gather scratch, and code buffers, including one-byte-short denial, exact peak
   charge, and retention until the last output buffer drops. Shared and exclusive
   parents, nullable codes and values, all-null values and empty inputs are
   covered. The original shared parent remains complete.

The full 10,000-request observation remains failed and immutable. The 20 CLI
no-JSON observations do not independently establish their underlying cause.
All 96 original failed requests are included in the new 517-case correctness
cohort; only its completed saved-result verification can establish their repaired
behavior. Callback families without proven detached-slot reachability remain
outside this repair.
