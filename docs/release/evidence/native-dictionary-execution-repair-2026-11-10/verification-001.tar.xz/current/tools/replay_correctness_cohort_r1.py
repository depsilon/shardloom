"""Replay all selected saved results and clocks without executing a query."""
from collections import Counter
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_correctness_cohort_r1 as current
import replay_current_10k as prior_verifier
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify

def main():
    target = current.TARGET
    output_path = target / 'verified-correctness-r1.json'
    cases_path = target / 'verified-cases-r1.jsonl.gz'
    partial = target / 'verified-cases-r1.partial.jsonl.gz'
    lock = target / '.offline-replay-r1.lock'
    assert not any(p.exists() for p in (output_path,cases_path,partial,lock))
    design,inputs,frozen,admitted = current.admission(current.E)
    selection = read(current.SELECTION)
    done = read(target/'complete.json')
    binding = read(target/'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 517
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert done['updated'] == admitted
    assert binding['contract'] == {key:done[key] for key in ('frozen','stage','prerequisites','updated')}
    assert done['ledger']['path'] == str(target/'attempts.sqlite')
    assert done['binding']['path'] == str(target/'binding.json')
    verify([done['ledger'],done['binding'],done['frozen']])
    guard_path = current.D/'correctness-cohort-r1.json'
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['active_output'] == str(target)
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B',str(current.D/'tools/run_correctness_cohort_r1.py')]
    assert guard['log_sha256'] == current.file_identity(guard_path.with_suffix('.log'))['sha256']
    previous = read(current.S/'current-baseline-10k-r1/complete.json')
    observed = read(current.S/'current-baseline-10k-r1/failed-observation-replay-r1.json')
    assert previous['ledger'] == observed['ledger']
    verify([previous['ledger'],observed['case_rows']])
    old_inputs = dict(inputs,runtime=previous['updated']['runtime'])
    prepared = read(current.E/'native-preparation/complete.json')
    definitions = {spec.name:spec for spec in spaces()}
    originals = {item.id:item for item in corpus(interactions='all',include_pending=False)}
    candidate_outcomes,old_outcomes = Counter(),Counter()
    failures,values,controls,old_controls = [],[],[],[]
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        candidate = stack.enter_context(closing_db(Path(done['ledger']['path']),readonly=True))
        baseline = stack.enter_context(closing_db(Path(previous['ledger']['path']),readonly=True))
        entries = iter(candidate.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs = {profile:stack.enter_context(closing_db(current.E/('reference-'+profile)/'expectations.sqlite',readonly=True))
            for profile in {row['case']['profile'] for row in selection['cases']}}
        output = stack.enter_context(gzip.open(partial,'wt',encoding='utf-8'))
        for ordinal,selected in enumerate(selection['cases']):
            row,original_seq = selected['case'],selected['seq']
            item = build(row,definitions) if 'cell' in row else originals[row['id']]
            reference = refs[row['profile']].execute('SELECT identity,value FROM expected WHERE id=?',(item.id,)).fetchone()
            assert reference and reference[0] == item.identity == row['case_identity']
            expected = unpack(reference[1])
            candidate_entry = next(entries,None)
            old_entry = baseline.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?',(original_seq,)).fetchone()
            assert candidate_entry and candidate_entry[:2] == (ordinal,item.id)
            assert old_entry and old_entry[:3] == (original_seq,item.id,selected['previous_status'])
            records,jobs = {},{}
            for role,entry,config in (('candidate',candidate_entry,inputs),('baseline',old_entry,old_inputs)):
                record = replay(entry,row,'native',expected,item,config,prepared,design['execution'])
                assert record['status'] == entry[2]
                jobs[role] = hashlib.sha256(raw_files(unpack(entry[3]))['one.job.json']).hexdigest()
                if record['status'] == 'passed' or record['engine_seconds'] is not None:
                    prior_verifier.verify_clock(entry,record)
                else:
                    assert record['engine_seconds'] is None
                records[role] = record
            assert jobs['baseline'] == selected['previous_job_sha256']
            old_outcomes[records['baseline']['status']] += 1
            candidate_outcomes[records['candidate']['status']] += 1
            if records['candidate']['status'] != 'passed':
                failures.append(dict(original_seq=original_seq,id=item.id,status=records['candidate']['status'],
                    detail=records['candidate']['failure_detail']))
            else:
                values.append(records['candidate']['engine_seconds'])
                if records['baseline']['status'] == 'passed':
                    controls.append(records['candidate']['engine_seconds'])
                    old_controls.append(records['baseline']['engine_seconds'])
            output.write(json.dumps(dict(seq=ordinal,original_seq=original_seq,id=item.id,
                case_identity=item.identity,reasons=selected['reasons'],job_sha256=jobs,**records),
                separators=(',',':'),allow_nan=False)+'\n')
        assert next(entries,None) is None
    assert old_outcomes == {'passed':421,'crashed':76,'harness_error':20}
    assert dict(candidate_outcomes) == done['outcomes']
    assert sum(candidate_outcomes.values()) == 517
    verify(frozen)
    verify([done['ledger'],done['binding'],previous['ledger'],observed['case_rows']])
    partial.rename(cases_path)
    passed = candidate_outcomes == {'passed':517}
    result = dict(schema='shardloom.dictionary_repair_correctness.v1',
        status='passed' if passed else 'failed_correctness',verification_completed=True,
        query_executions_during_replay=0,selected_cases=517,candidate_outcomes=dict(candidate_outcomes),
        original_selected_outcomes=dict(old_outcomes),original_failed_cases=96,passing_controls=421,
        original_observation_unchanged=True,attempts_per_case=1,requested_repeats=0,
        failures=failures,all_selected_results_correct=passed,native_no_fallback=passed,
        complete_10k_performance_claim=False,
        engine_execution_seconds=math.fsum(values) if passed else None,
        primary_clock='engine_execution_seconds',
        matched_passing_control_diagnostic=(dict(cases=421,candidate_engine_seconds=math.fsum(controls),
            baseline_engine_seconds=math.fsum(old_controls),performance_acceptance=False) if passed else None),
        comparison_limit='This is the frozen 517-case correctness cohort, not a replacement full10k observation. The original 96 failures remain in the original ledger. One observation supplies no individual optimization attribution.',
        selection=identity(current.SELECTION),protocol=identity(current.PROTOCOL),
        runtime_binding=admitted,complete=identity(target/'complete.json'),ledger=done['ledger'],
        previous_ledger=previous['ledger'],case_rows=identity(cases_path),guard=identity(guard_path),
        verifier=identity(Path(__file__)))
    with output_path.open('x') as output:
        json.dump(result,output,indent=2,allow_nan=False);output.write('\n')
    lock.unlink()
    print(json.dumps({key:result[key] for key in ('status','selected_cases','candidate_outcomes',
        'original_selected_outcomes','all_selected_results_correct','complete_10k_performance_claim')}))
    assert passed, 'candidate correctness failed; preserved all selected outcomes'

if __name__ == '__main__':
    main()

