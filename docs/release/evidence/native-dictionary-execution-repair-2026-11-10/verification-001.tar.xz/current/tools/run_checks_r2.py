"""Finish the native gates after a documentation-only test lint correction."""
from pathlib import Path
import subprocess
import sys
D = Path(__file__).resolve().parents[1]
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
for name, timeout, command in [
    ('format-r2', 300, ['cargo','fmt','--all','--','--check']),
    ('native-clippy-r2', 2400, ['cargo','clippy','--offline','--locked','--workspace','--all-targets','--features',FEATURES,'--','-D','warnings']),
    ('native-tests-r1', 3600, ['env','RUST_TEST_THREADS=4','cargo','test','--offline','--locked','--workspace','--all-targets','--features',FEATURES]),
]:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable,'-B',str(D/'tools/guard_dictionary_repair.py'),
        '--name',name,'--timeout',str(timeout),'--',*command],check=True)

