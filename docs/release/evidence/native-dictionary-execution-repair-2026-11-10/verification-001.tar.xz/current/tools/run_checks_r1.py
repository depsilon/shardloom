"""Run the required default and native checks sequentially on the unchanged repair sources."""
from pathlib import Path
import subprocess
import sys

D = Path(__file__).resolve().parents[1]
GUARD = D / 'tools/guard_dictionary_repair.py'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
CHECKS = [
    ('format-r1', 300, ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-clippy-r1', 2400, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-r1', 3600, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('native-clippy-r1', 2400, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', FEATURES, '--', '-D', 'warnings']),
    ('native-tests-r1', 3600, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets', '--features', FEATURES]),
]
for name, timeout, command in CHECKS:
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(GUARD), '--name', name, '--timeout', str(timeout),
        '--', *command], check=True)

