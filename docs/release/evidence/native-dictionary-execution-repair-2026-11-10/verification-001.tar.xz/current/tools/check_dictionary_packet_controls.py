"""Challenge the archive, source/claim bindings and source-only replay boundary."""
import argparse
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import verify_dictionary_repair_packet as verifier

D = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    report,data = verifier.read_archive(args.packet)
    verifier.verify_sources(report,data)
    outcomes = []

    def rejected(name,mutate):
        changed,description = dict(data),copy.deepcopy(report)
        mutate(description,changed)
        try:
            verifier.verify_sources(description,changed)
        except (AssertionError,KeyError,ValueError):
            outcomes.append(dict(name=name,status='rejected'))
        else:
            raise AssertionError('invalid evidence accepted: '+name)

    def update_json(changed,name,callback):
        value = json.loads(changed[name])
        callback(value)
        changed[name] = json.dumps(value,indent=2).encode()+b'\n'

    def receipt_field(name,key,value):
        return lambda _report,changed:update_json(changed,'current/'+name+'.json',lambda row:row.__setitem__(key,value))

    rejected('native_test_failure',receipt_field('native-tests-r1','returncode',1))
    rejected('undrained_native_process',receipt_field('native-tests-r1','process_group_drained',False))
    rejected('mutable_source_validation',receipt_field('release-build-r1','fixed_source_validation',False))

    def alter_source(name):
        def mutate(description,changed):
            sha = description['source_snapshot'][name]['sha256']
            changed['source-blobs/'+sha] += b'\n'
        return mutate

    rejected('provider_source_changed',alter_source(verifier.PROVIDER_SOURCE))
    rejected('provider_lock_changed',alter_source('Cargo.lock'))
    rejected('supplemental_protocol_source_changed',alter_source(verifier.REPLAY_SUPPORT[0]))

    def missing_test(description,changed):
        test = description['required_native_tests'][0].encode()
        key = 'current/dictionary-focused-r2.log'
        lines = changed[key].splitlines(keepends=True)
        removed = [line for line in lines if b'::'+test+b' ... ok' in line]
        assert len(removed) == 1
        changed[key] = b''.join(line for line in lines if line not in removed)
        update_json(changed,'current/dictionary-focused-r2.json',
            lambda row:row.__setitem__('log_sha256',verifier.digest(changed[key])))
    rejected('regression_test_missing_with_rebound_log',missing_test)

    def wrong_library(_description,changed):
        update_json(changed,'current/runtime-library-copy-r1.json',
            lambda row:row['identity'].__setitem__('sha256','0'*64))
    rejected('runtime_library_mismatch',wrong_library)
    rejected('original_failed_check_omitted',lambda description,_changed:description['original_failed_checks'].pop())

    def original_success(_description,changed):
        update_json(changed,'original/current-baseline-10k-r1/failed-observation-replay-r1.json',
            lambda row:row.__setitem__('complete_performance_result_valid',True))
    rejected('original_failure_laundered_as_performance_pass',original_success)

    def cohort_full_claim(_description,changed):
        update_json(changed,'current/correctness-cohort-r1/verified-correctness-r1.json',
            lambda row:row.__setitem__('complete_10k_performance_claim',True))
    rejected('repair_cohort_laundered_as_full10k',cohort_full_claim)

    def omitted_failure(_description,changed):
        update_json(changed,'current/correctness-cohort-r1/verified-correctness-r1.json',
            lambda row:row.__setitem__('original_failed_cases',95))
    rejected('failed_request_omitted',omitted_failure)

    with tempfile.TemporaryDirectory(prefix='shardloom-dictionary-corruption-') as folder:
        target = Path(folder)
        (target/'acceptance.json').write_bytes((args.packet/'acceptance.json').read_bytes())
        first = report['archives'][0]['path']
        raw = bytearray((args.packet/first).read_bytes())
        raw[len(raw)//2] ^= 1
        (target/first).write_bytes(raw)
        try:
            verifier.read_archive(target)
        except AssertionError:
            outcomes.append(dict(name='archive_byte_changed',status='rejected'))
        else:
            raise AssertionError('corrupt archive accepted')

    # The successful relocated run denies every read from the original task,
    # source checkout and input directories, plus native/other subprocesses and
    # network connections. Only its copied packet and extracted Python sources
    # and saved SQLite results are available to the verifier.
    with tempfile.TemporaryDirectory(prefix='shardloom-dictionary-source-only-') as folder:
        target = Path(folder)
        for name in ('acceptance.json','verify.py',*(row['path'] for row in report['archives'])):
            shutil.copyfile(args.packet/name,target/name)
        wrapper = target/'source_only.py'
        wrapper.write_text('''import json, pathlib, runpy, sys, urllib.parse
root = pathlib.Path(__file__).resolve().parent
forbidden = (
    pathlib.Path('/Users/dylan/LocalData/shardloom'),
    pathlib.Path('/Users/dylan/.codex/worktrees'),
    pathlib.Path('/Users/dylan/Documents/shardloom-local-repo'),
    pathlib.Path('/Users/dylan/.cache/shardloom'),
)
def audit(event,args):
    if event in ('open','sqlite3.connect') and isinstance(args[0],(str,bytes)):
        value = args[0].decode() if isinstance(args[0],bytes) else args[0]
        if event == 'sqlite3.connect' and value.startswith('file:'):
            value = urllib.parse.unquote(urllib.parse.urlsplit(value).path)
        path = pathlib.Path(value).resolve()
        if any(path.is_relative_to(parent) for parent in forbidden):
            raise AssertionError('source-only replay opened original path: '+str(path))
    if event in ('subprocess.Popen','os.system','socket.connect','socket.bind','socket.sendto'):
        raise AssertionError('source-only replay attempted external execution/network: '+event)
sys.addaudithook(audit)
sys.argv = [str(root/'verify.py'),'--packet',str(root)]
runpy.run_path(str(root/'verify.py'),run_name='__main__')
''')
        run = subprocess.run([sys.executable,'-I','-B',str(wrapper)],cwd=target,
            capture_output=True,text=True,timeout=1200)
        assert run.returncode == 0,run.stderr
        result = json.loads(run.stdout)
        assert result['status'] == 'passed' and result['query_executions'] == 0
        assert result['original_attempts'] == 10000 and result['candidate_outcomes'] == {'passed':517}
        outcomes.append(dict(name='relocated_source_only',status='passed',replay=result))
    result = dict(schema='shardloom.dictionary_packet_controls.v1',status='passed',
        query_executions=0,packet_manifest=verifier.identity((args.packet/'acceptance.json').read_bytes()),
        semantic_controls='inner verification after archive validation; rebound log case proves test membership is checked independently of its digest',
        cases=outcomes,verifier=verifier.identity(Path(verifier.__file__).read_bytes()),
        control_source=verifier.identity(Path(__file__).read_bytes()))
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='passed',controls=len(outcomes),query_executions=0)))


if __name__ == '__main__':
    main()
