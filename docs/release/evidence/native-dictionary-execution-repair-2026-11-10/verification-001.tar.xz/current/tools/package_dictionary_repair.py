"""Seal the failed observation and its separate repair cohort for portable replay."""
import argparse
import io
import json
from pathlib import Path
import re
import shutil
import tarfile

from verify_dictionary_repair_packet import BASE,CHECKS,TEST_SOURCE,digest,identity,fingerprint,rust_counts,verify,verify_sources

D = Path(__file__).resolve().parents[1]
S = D.parent/'shared-operator-state-2026-11-10'
E = D.parent/'expanded-query-2026-11-03'
K = D.parent/'variant-expressions-2026-11-10'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def read(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--execution-name',required=True)
    parser.add_argument('--preflight-only',action='store_true')
    args = parser.parse_args()
    assert args.destination.resolve().is_relative_to(D) and not args.destination.exists()
    assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',args.execution_name)
    result = read(D/'correctness-cohort-r1/verified-correctness-r1.json')
    assert result['status'] == 'passed' and result['candidate_outcomes'] == {'passed':517}
    assert result['complete_10k_performance_claim'] is False
    old = read(S/'current-baseline-10k-r1/failed-observation-replay-r1.json')
    assert old['verification_passed'] and old['engine_execution_seconds'] is None
    assert old['complete_performance_result_valid'] is False
    data,locations = {},{}

    def add(path,name):
        assert path.is_file() and not path.is_symlink(),path
        raw = path.read_bytes()
        assert name not in data or data[name] == raw,name
        assert str(path) not in locations or locations[str(path)] == name,path
        data[name] = raw
        locations[str(path)] = name
        return raw

    def mapped(path):
        if path.is_relative_to(D):
            return 'current/'+path.relative_to(D).as_posix()
        if path.is_relative_to(S):
            return 'original/'+path.relative_to(S).as_posix()
        if path.is_relative_to(E/'investigation-original-harness-r1'):
            return 'harness/'+path.relative_to(E/'investigation-original-harness-r1').as_posix()
        if path.is_relative_to(E):
            return 'frozen/'+path.relative_to(E).as_posix()
        if path.is_relative_to(K):
            return 'prior/'+path.relative_to(K).as_posix()
        raise AssertionError('unclassified evidence path: '+str(path))

    for root,prefix in ((D,'current'),(S,'original')):
        chosen = [*root.glob('*.json'),*root.glob('*.log'),*root.glob('tools/*.py')]
        for pattern in ('*-retirement-*/*.json','*-retirement-*/*.xz','dictionary-panic-diagnostic-r1/*'):
            chosen.extend(root.glob(pattern))
        for path in sorted(set(chosen)):
            if path.name in {args.execution_name+'.json',args.execution_name+'.log'} or not path.is_file():
                continue
            add(path,prefix+'/'+path.relative_to(root).as_posix())
    for filename in ('contract.md','adversarial-review-r1.md'):
        add(D/filename,'current/'+filename)
    for root in (D/'correctness-cohort-r1',S/'current-baseline-10k-r1'):
        for name in ('complete.json','binding.json','attempts.sqlite'):
            add(root/name,mapped(root/name))
        for pattern in ('*.jsonl.gz','*-r1.json'):
            for path in sorted(root.glob(pattern)):
                add(path,mapped(path))
    frozen = read(E/'frozen.json')
    manifest = read(E/'investigation-original-harness-source-r1.json')
    for name in ('design.json','inputs.json','frozen.json','native-preparation/complete.json',
                 'investigation-original-harness-source-r1.json'):
        add(E/name,'frozen/'+name)
    for row in frozen['references']:
        path = Path(row['path'])
        raw = add(path,mapped(path))
        assert identity(raw) == dict(bytes=row['generation']['bytes'],sha256=row['sha256'])
    for relative,sha256 in sorted(manifest['harness_sha256'].items()):
        path = E/'investigation-original-harness-r1'/relative
        raw = add(path,'harness/'+relative)
        assert digest(raw) == sha256
        declared = [row for row in frozen['harness'] if row['path'].endswith('/'+relative)]
        assert len(declared) == 1 and declared[0]['sha256'] == sha256
        locations[declared[0]['path']] = 'harness/'+relative
    protocol = read(D/'correctness-cohort-protocol-r1.json')
    for row in protocol['runtime_binding']['proof_files']:
        path = Path(row['path'])
        raw = add(path,mapped(path))
        assert identity(raw) == dict(bytes=row['generation']['bytes'],sha256=row['sha256'])
    for name in ('variant-expression-main-r1.json','runtime-r2-identity.json'):
        add(K/name,'prior/'+name)
    # De-duplicate immutable source bytes across all checks and both observations.
    # No runtime, wheel, source input or compiled-cache payload is included.
    wanted = {}
    for name,raw in list(data.items()):
        if not name.endswith('.json'):
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError,UnicodeDecodeError):
            # A crashed process can leave an empty/non-JSON stdout artifact.
            # Preserve its exact bytes; it is not a source-inventory receipt.
            continue
        if not isinstance(record,dict):
            continue
        for key in ('build_sources','tool_source_inventory','changed_source_inventory'):
            for item in record.get(key,{}).values():
                if 'sha256' in item and 'symlink' not in item:
                    wanted[item['sha256']] = item
    for sha256,item in sorted(wanted.items()):
        matches = [root/'source-blobs'/sha256 for root in (D,S,K) if (root/'source-blobs'/sha256).is_file()]
        assert matches,sha256
        raw = add(matches[0],'source-blobs/'+sha256)
        assert identity(raw) == item
    build = read(D/'release-build-r1.json')
    sources = build['build_sources']
    checks = {}
    for name,command in CHECKS.items():
        receipt = read(D/(name+'.json'))
        assert receipt['status'] == 'passed' and receipt['command'] == command
        checks[name] = dict(command=command,status='passed',rust_tests=rust_counts(data['current/'+name+'.log']))
    failed = []
    dispositions = read(D/'failure-dispositions-r1.json')
    for name,raw in sorted(data.items()):
        if name.startswith('current/') and name.endswith('.json') and name.count('/') == 1:
            record = json.loads(raw)
            if isinstance(record,dict) and (str(record.get('status')).startswith('failed') or record.get('status') == 'interrupted'):
                key = name.removeprefix('current/')
                assert dispositions[key]
                failed.append(dict(receipt=name,identity=identity(raw),disposition=dispositions[key]))
    assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failed}
    report = dict(schema='shardloom.dictionary_repair_acceptance.v1',status='local_acceptance_passed',
        source_base=BASE,source_snapshot=sources,source_fingerprint_sha256=fingerprint(sources),
        checks=checks,required_native_tests=sorted(name.decode() for name in re.findall(
            rb'fn (native_dictionary_suspended_\w+)\(',data['source-blobs/'+sources[TEST_SOURCE]['sha256']])),
        source_policy='All production, vendor, configuration, harness and test bytes are bound to the fresh release build. Earlier default/focused checks differ only by the exact test documentation backtick correction; final native gates use the final bytes. Named status prose may advance after runtime capture.',
        original_observation=dict(attempts=10000,outcomes=old['original_outcomes'],complete_performance_result_valid=False,engine_execution_seconds=None),
        repair_cohort=dict(cases=517,original_failed_cases=96,passing_controls=421,outcomes=result['candidate_outcomes'],selection_uses_timing=False),
        original_failed_checks=failed,hosted_integration='pending',
        performance_claim=False,complete_10k_performance_claim=False,publication_attempted=False,
        whole_item_19_complete=False,whole_item_20_complete=False,
        limitations=[
            'The original exactly-once 10000-case observation has 96 failures and remains invalid as a complete performance result.',
            'The separate predefined 517-case correctness cohort repairs all 96 failures and preserves 421 controls; it is not a full10k rerun or an optimization acceptance.',
            'The original 20 CLI no-JSON failures passed after repair, but their original internal cause was not independently captured.',
            'Portable replay recomputes complete values and clocks for the original 10000 observations and the 517 candidate results; historical comparison receipts remain historical, with no new individual-change attribution.',
            'Runtime payloads, input datasets and compiled outputs are represented by their captured identities; the archived original comparator and expected results permit query-free replay.',
            'No package publication, broad performance superiority, item 19/20, RFC 0044 or CG-1 through CG-23 completion is claimed.',
        ],locations=dict(sorted(locations.items())),
        members=[dict(path=name,**identity(raw)) for name,raw in sorted(data.items())])
    assert sum(len(raw) for raw in data.values()) < 512 << 20
    verify_sources(report,data,W)
    if args.preflight_only:
        print(json.dumps(dict(status='passed',source_binding_verified=True,query_executions=0,
            logical_files=len(data),logical_bytes=sum(len(raw) for raw in data.values()),archives_written=0)))
        return
    # Bounded immutable archive parts keep each Git artifact below 64 MiB even
    # when a SQLite ledger already contains compressed, incompressible packets.
    # Logical file identities remain unchanged and are verified after assembly.
    stored,assemblies = {},[]
    chunk_size = 24 << 20
    for name,raw in sorted(data.items()):
        if len(raw) <= chunk_size:
            stored[name] = raw
            continue
        parts = []
        for ordinal,offset in enumerate(range(0,len(raw),chunk_size)):
            part = 'parts/'+digest(name.encode())+'/'+str(ordinal).zfill(4)
            assert part not in stored
            stored[part] = raw[offset:offset+chunk_size]
            parts.append(part)
        assemblies.append(dict(path=name,parts=parts,**identity(raw)))
    report['assemblies'] = assemblies
    report['stored_members'] = [dict(path=name,**identity(raw)) for name,raw in sorted(stored.items())]
    groups,group,bytes_in_group = [],[],0
    for row in report['stored_members']:
        if group and bytes_in_group+row['bytes'] > 48 << 20:
            groups.append(group)
            group,bytes_in_group = [],0
        group.append(row)
        bytes_in_group += row['bytes']
    if group:
        groups.append(group)
    args.destination.mkdir()
    report['archives'] = []
    for ordinal,group in enumerate(groups):
        path = args.destination/f'verification-{ordinal+1:03d}.tar.xz'
        with tarfile.open(path,'w:xz',preset=6) as archive:
            for row in group:
                entry = tarfile.TarInfo(row['path'])
                entry.size,entry.mode,entry.mtime = row['bytes'],0o644,0
                archive.addfile(entry,io.BytesIO(stored[row['path']]))
        raw = path.read_bytes()
        assert len(raw) < 64 << 20
        report['archives'].append(dict(path=path.name,members=[row['path'] for row in group],**identity(raw)))
    (args.destination/'acceptance.json').write_text(json.dumps(report,indent=2)+'\n')
    shutil.copyfile(D/'tools/verify_dictionary_repair_packet.py',args.destination/'verify.py')
    del data,stored
    print(json.dumps(verify(args.destination,W),sort_keys=True))


if __name__ == '__main__':
    main()
