"""Check the full saved-result import chain in an isolated, relocated process."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import verify_dictionary_repair_packet as verifier

D = Path(__file__).resolve().parents[1]
E = D.parent/'expanded-query-2026-11-03'
S = D.parent/'shared-operator-state-2026-11-10'
destination = D/'portable-imports-r1.json'
assert not destination.exists()
manifest = json.loads((E/'investigation-original-harness-source-r1.json').read_bytes())
data = {'harness/'+name:(E/'investigation-original-harness-r1'/name).read_bytes()
    for name in manifest['harness_sha256']}
for name,sha in manifest['harness_sha256'].items():
    assert verifier.digest(data['harness/'+name]) == sha
data['current/release-build-r1.json'] = (D/'release-build-r1.json').read_bytes()
data['original/current-baseline-10k-r1.json'] = (S/'current-baseline-10k-r1.json').read_bytes()
build = json.loads(data['current/release-build-r1.json'])
for name in verifier.REPLAY_SUPPORT:
    sha = build['build_sources'][name]['sha256']
    data['source-blobs/'+sha] = (D/'source-blobs'/sha).read_bytes()
sources = verifier.replay_sources(data)
assert len(sources) == 68
with tempfile.TemporaryDirectory(prefix='shardloom-dictionary-imports-') as folder:
    root = Path(folder).resolve()
    harness = root/'harness'
    for name,raw in sources.items():
        path = harness/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    (root/'expected.json').write_text(json.dumps({name:verifier.identity(raw) for name,raw in sources.items()}))
    wrapper = root/'check.py'
    wrapper.write_text('''import hashlib, json, pathlib, sys
root = pathlib.Path(__file__).resolve().parent
harness = root/'harness'
expected = json.loads((root/'expected.json').read_bytes())
forbidden = tuple(map(pathlib.Path,('/Users/dylan/LocalData/shardloom','/Users/dylan/.codex/worktrees','/Users/dylan/Documents/shardloom-local-repo','/Users/dylan/.cache/shardloom')))
def audit(event,args):
    if event == 'open' and isinstance(args[0],(str,bytes)):
        path = pathlib.Path(args[0].decode() if isinstance(args[0],bytes) else args[0]).resolve()
        assert not any(path.is_relative_to(parent) for parent in forbidden),path
    assert event not in ('subprocess.Popen','os.system','socket.connect','socket.bind','socket.sendto'),event
sys.addaudithook(audit)
sys.path[:0] = [str(harness/'scripts'),str(harness/'python/src'),str(harness/'benchmarks/traditional_analytics')]
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build,spaces
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files,replay
from query_timing_report import query_phase_timings
assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') for name in sys.modules)
loaded = {}
for name,module in list(sys.modules.items()):
    if not getattr(module,'__file__',None):
        continue
    path = pathlib.Path(module.__file__).resolve()
    if path.is_relative_to(harness):
        raw = path.read_bytes()
        assert expected[path.relative_to(harness).as_posix()] == dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        loaded[name] = path.relative_to(harness).as_posix()
assert {'native_workflow_protocol','clickbench_reference_packet','clickbench_native_sql'} <= set(loaded)
print(json.dumps(dict(status='passed',query_executions=0,native_extension_loaded=False,loaded_modules=loaded),sort_keys=True))
''')
    run = subprocess.run([sys.executable,'-I','-B',str(wrapper)],cwd=root,
        capture_output=True,text=True,timeout=120)
    assert run.returncode == 0,run.stderr
    result = json.loads(run.stdout)
result.update(source_files=len(sources),frozen_harness_files=65,
    supplemental_sources={name:verifier.identity(sources[name]) for name in verifier.REPLAY_SUPPORT},
    checker=verifier.identity(Path(__file__).read_bytes()))
with destination.open('x') as output:
    json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({key:result[key] for key in ('status','query_executions','native_extension_loaded','source_files')}))
