"""Retire closed reproducible debug files after the recorded free-space refusal."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
ROOTS = (CACHE / 'debug',)
DEST = OUT / 'debug-retirement-r1'
OBSERVATIONS = ('suspended-dictionary-regression-r1.json',)
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    assert path.is_file() and not path.is_symlink()
    return {'bytes': path.stat().st_size, 'sha256': base.sha(path)}

def inventory():
    rows, links, hashes = [], {}, {}
    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = {'path': str(path), 'generation': before}
        if stat.S_ISDIR(before[2]):
            item['kind'] = 'directory'
            rows.append(item)
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            rows.append(dict(item, kind='regular', sha256=hashes[key]))
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            rows.append(dict(item, kind='symlink', target=os.readlink(path)))
        else:
            raise AssertionError('unexpected file type: ' + str(path))
        assert base.generation(path) == before
    for root in ROOTS:
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
        visit(root)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths)
    return rows

def retained():
    expected = read(OUT / OBSERVATIONS[0])['protected_runtime_and_wheel']
    for name, item in expected.items():
        path = Path(name)
        assert not any(path.is_relative_to(root) for root in ROOTS)
        assert identity(path) == item, name
    return expected

def inputs():
    expected = read(OUT / OBSERVATIONS[0])['input_generations']
    assert len(expected) == 220
    assert {name: base.generation(Path(name)) for name in expected} == expected
    return expected

def release():
    return {str(path): base.generation(path) for path in sorted((CACHE / 'release').rglob('*'))}

def resolve():
    stopped = read(OUT / OBSERVATIONS[0])
    assert stopped['status'] == 'failed' and 'minimum free storage reached' in stopped['error']
    assert stopped['process_group_drained'] and stopped['direct_child_reaped']
    assert stopped['returncode'] != 0
    assert base.sha((OUT / OBSERVATIONS[0]).with_suffix('.log')) == stopped['log_sha256']
    assert stopped['fixed_source_validation'] and not stopped['allow_lockfile_update']
    assert stopped['build_source_verification']['pre_execution']['changed_paths'] == []
    assert stopped['original_failed_observation']['failed_attempts'] == 96
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert metadata['target_directory'] == str(CACHE)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == stopped['head'] == '8f426b3d2e774be2a9d30a731c33b8c830378d99'
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == stopped['working_tree']
    for name, info in stopped['build_sources'].items():
        path = ROOT / name
        if 'sha256' in info and 'symlink' not in info:
            assert identity(path) == info, name
        elif 'symlink' in info:
            assert path.is_symlink() and os.readlink(path) == info['symlink']
        else:
            assert info.get('absent') and not path.exists()
    return head

def plan():
    head = resolve()
    assert not DEST.exists()
    base.closed([str(root) for root in ROOTS])
    print('Inventorying closed reproducible debug output', flush=True)
    rows = inventory()
    manifest = {'roots': list(map(str, ROOTS)), 'entries': rows, 'retained': retained(),
        'input_generations': inputs(), 'release_generations': release(),
        'source_head': head, 'observations': {name: identity(OUT / name) for name in OBSERVATIONS}}
    blob = OUT / 'source-blobs' / base.sha(HELPER)
    if not blob.exists():
        blob.write_bytes(HELPER.read_bytes())
    assert blob.read_bytes() == HELPER.read_bytes()
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = {'status': 'planned_no_deletion', 'roots': list(map(str, ROOTS)), 'entries': len(rows),
        'regular_files': sum(row['kind'] == 'regular' for row in rows),
        'regular_bytes': sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        'symlinks': sum(row['kind'] == 'symlink' for row in rows),
        'manifest_sha256': base.sha(DEST / 'manifest.json.xz'), 'script_sha256': base.sha(Path(__file__)),
        'helper_sha256': base.sha(HELPER),
        'reason': 'The dictionary regression rebuild stopped before tests at the unchanged 12 GiB floor. Only reproducible debug compiler output is selected. All original outcomes, protected runtimes/wheels, full10k packets and source inventories remain. The failed original observation is not accepted.',
        'regeneration': 'Rebuild from the guarded complete source snapshot and locked dependencies with the same environment. Preserve accepted UUID and observed Variant runtimes/wheels, the copied measured library, current input generations, release cache and all original failed-cohort evidence. No payload backup or limit change.'}
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)

def apply():
    resolve()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['roots'] == list(map(str, ROOTS))
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    assert retained() == manifest['retained']
    assert inputs() == manifest['input_generations'] and release() == manifest['release_generations']
    assert all(identity(OUT / name) == value for name, value in manifest['observations'].items())
    base.closed(list(map(str, ROOTS)))
    print('Rechecking exact identities and closed handles', flush=True)
    assert inventory() == manifest['entries']
    base.closed(list(map(str, ROOTS)))
    receipt = {'status': 'running', 'removed': 0, 'manifest_sha256': summary['manifest_sha256']}
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(manifest['entries'], key=lambda item: len(Path(item['path']).parts), reverse=True):
            path = Path(row['path'])
            assert any(path == root or path.is_relative_to(root) for root in ROOTS)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                assert current[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert all(not root.exists() and not root.is_symlink() for root in ROOTS)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert release() == manifest['release_generations']
        receipt.update(status='passed', regular_files=summary['regular_files'],
            regular_bytes=summary['regular_bytes'], symlinks=summary['symlinks'],
            retained_runtimes_and_wheels_unchanged=True, input_generations_unchanged=True,
            release_cache_unchanged=True, storage_limits_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()

