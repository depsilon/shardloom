"""Freeze the failure-repair cohort from case shapes and outcomes, without using timings."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parents[1]
E = D.parent / 'expanded-query-2026-11-03'
S = D.parent / 'shared-operator-state-2026-11-10'
TARGET = S / 'current-baseline-10k-r1'
OUT = D / 'correctness-cohort-selection-r1.json'

def identity(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def main():
    assert __debug__ and not OUT.exists()
    report_path = TARGET / 'failed-observation-replay-r1.json'
    report = json.loads(report_path.read_bytes())
    assert report['verification_passed'] and not report['complete_performance_result_valid']
    assert report['original_outcomes'] == {'passed': 9904, 'crashed': 76, 'harness_error': 20}
    protocol_path = S / 'current-baseline-10k-protocol-r1.json'
    protocol = json.loads(protocol_path.read_bytes())
    assert identity(protocol_path)['sha256'] == report['protocol']['sha256']
    design_path = E / 'design.json'
    assert identity(design_path)['sha256'] == protocol['design']['sha256']
    cases_path = Path(report['case_rows']['path'])
    assert identity(cases_path)['sha256'] == report['case_rows']['sha256']
    design = json.loads(design_path.read_bytes())['cases']
    with gzip.open(cases_path, 'rt') as stream:
        observations = [json.loads(line) for line in stream]
    assert len(design) == len(observations) == 10000
    for seq, (row, observed) in enumerate(zip(design, observations, strict=True)):
        assert seq == observed['seq']
        assert row['id'] == observed['id'] and row['case_identity'] == observed['case_identity']
        assert observed['historical']['status'] == 'passed'
    failed = {seq for seq, row in enumerate(observations) if row['current']['status'] != 'passed'}
    assert len(failed) == 96 and failed == {row['seq'] for row in report['failures']}
    archetypes = {design[seq]['archetype'] for seq in failed}
    related, broad = {}, {}
    for seq, row in enumerate(design):
        if seq in failed:
            continue
        assert observations[seq]['current']['status'] == 'passed'
        if row.get('archetype') in archetypes:
            related.setdefault((row['archetype'], row['surface'], row['profile'], row['native_format']), seq)
        broad.setdefault((row['family'], row['surface'], row['native_format']), seq)
    reasons = defaultdict(list)
    for seq in failed:
        reasons[seq].append('original_failed_request')
    for seq in related.values():
        reasons[seq].append('first_passing_affected_archetype_surface_profile_format')
    for seq in broad.values():
        reasons[seq].append('first_passing_family_surface_format')
    selected = sorted(reasons)
    assert len(selected) == 517 and len(related) == 269 and len(broad) == 236
    paths = [report_path, protocol_path, design_path, cases_path, Path(__file__)]
    sources = [identity(path) for path in paths]
    rows = [dict(seq=seq, case=design[seq], reasons=reasons[seq],
        previous_status=observations[seq]['current']['status'],
        previous_job_sha256=observations[seq]['job_sha256']['current']) for seq in selected]
    result = dict(schema='shardloom.dictionary_correctness_cohort.v1',
        status='selected_before_candidate_execution', source_commit=report['source_commit'],
        selection_uses_timing=False, query_executions=0, attempts_per_case=1,
        original_failed_requests=96, passing_controls=421, selected_requests=517,
        affected_archetypes=sorted(archetypes), related_control_cells=len(related),
        family_surface_format_controls=len(broad),
        selection_policy='All original failures; first passing ordinal in every affected-archetype/surface/profile/native-format cell; first passing ordinal in every family/surface/native-format cell; deduplicate and retain original manifest order.',
        primary_objective='complete correct results with native certificates and unchanged resource/ownership contracts',
        complete_10k_performance_claim=False,
        failure_policy='Preserve every new outcome; no automatic repeat or replacement of failed requests.',
        sources=sources, cases=rows,
        selected_profiles=dict(sorted(Counter(row['case']['profile'] for row in rows).items())))
    assert [identity(path) for path in paths] == sources
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','selected_requests',
        'original_failed_requests','passing_controls','selection_uses_timing','query_executions')}))

if __name__ == '__main__':
    main()

