"""Provenance-only acceptance and rejection controls; executes no queries."""
import copy
from types import SimpleNamespace
import unittest

import frozen_generation_binding as binding


class BindingTests(unittest.TestCase):
    def setUp(self):
        self.old = dict(path='/exact/file', sha256='a' * 64,
            generation=dict(device=16777233, inode=10, bytes=20, mtime_ns=30, ctime_ns=40))
        self.new = copy.deepcopy(self.old)
        self.new['generation']['device'] = 16777234

    def test_equal_and_device_only_accepted(self):
        binding.device_only(self.old, self.old)
        binding.device_only(self.old, self.new)

    def test_every_other_identity_change_rejected(self):
        changes = [('path', '/another/file'), ('sha256', 'b' * 64),
                   ('device', 16777235), ('inode', 11), ('bytes', 21),
                   ('mtime_ns', 31), ('ctime_ns', 41), ('inode', True)]
        for key, value in changes:
            with self.subTest(key=key, value=value):
                observed = copy.deepcopy(self.new)
                (observed if key in ('path', 'sha256') else observed['generation'])[key] = value
                with self.assertRaises(AssertionError):
                    binding.device_only(self.old, observed)
        with self.assertRaises(AssertionError):
            binding.device_only(self.new, self.old)
        extra = copy.deepcopy(self.new)
        extra['generation']['unexpected'] = 0
        with self.assertRaises(AssertionError):
            binding.device_only(self.old, extra)

    def test_lookup_is_exact_and_does_not_rewrite_history(self):
        instance = binding.HistoricalBinding.__new__(binding.HistoricalBinding)
        instance.mapping = {self.old['path']: dict(historical=copy.deepcopy(self.old), current=self.new)}
        snapshot = copy.deepcopy(self.old)
        self.assertEqual(instance.current(self.old), self.new)
        self.assertEqual(self.old, snapshot)
        with self.assertRaises(AssertionError):
            instance.current(self.new)
        changed = copy.deepcopy(self.old)
        changed['path'] = '/unknown/file'
        with self.assertRaises(KeyError):
            instance.current(changed)

    def test_verifier_scope_restores_even_after_failure(self):
        instance = binding.HistoricalBinding.__new__(binding.HistoricalBinding)
        original = object()
        module = SimpleNamespace(verify=original)
        with self.assertRaises(RuntimeError):
            with instance.admission_verifier(module):
                self.assertEqual(module.verify, instance.verify)
                raise RuntimeError('intentional negative control')
        self.assertIs(module.verify, original)


if __name__ == '__main__':
    unittest.main(verbosity=2)
