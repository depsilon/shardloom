"""Validate every saved attempt without retrying or turning failures into a timing result."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import replay_current_10k as strict
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify

current = strict.current
EXPECTED_OUTCOMES = {'passed': 9904, 'crashed': 76, 'harness_error': 20}


def checked_failed_stage(target):
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 10000
    assert done['outcomes'] == EXPECTED_OUTCOMES
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    assert done['frozen']['path'] == str(current.E / 'frozen.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    guard_path = current.S / 'current-baseline-10k-r1.json'
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped']
    return done, guard_path


def main():
    target, previous = current.TARGET, current.E / 'shared-mechanisms-10k-r1'
    destination = target / 'failed-observation-replay-r1.json'
    cases_path = target / 'replayed-cases-r1.jsonl.gz'
    partial = target / 'replayed-cases-r1.partial.jsonl.gz'
    lock = target / '.failed-observation-replay-r1.lock'
    assert not any(path.exists() for path in (destination, cases_path, partial, lock))
    design, inputs, frozen, admitted = current.updated_admission(current.E)
    done, guard_path = checked_failed_stage(target)
    prior = strict.checked_stage(previous, historical=True)
    assert done['updated'] == admitted
    prepared = read(current.E / 'native-preparation/complete.json')
    # Historical jobs include their historical runtime generation objects.
    previous_inputs = dict(inputs, runtime=prior['updated']['runtime'])
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name: spec for spec in spaces()}
    outcomes, families, failure_signatures = Counter(), defaultdict(Counter), Counter()
    seen, failed, old_values = [], [], []
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        stores = {name: stack.enter_context(closing_db(Path(record['ledger']['path']), readonly=True))
                  for name, record in (('current', done), ('historical', prior))}
        attempts = {name: iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
                    for name, db in stores.items()}
        references = {profile: stack.enter_context(closing_db(current.E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
                      for profile in {row['profile'] for row in design['cases']}}
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, row in enumerate(design['cases']):
            item = build(row, definitions) if 'cell' in row else originals[row['id']]
            reference = references[row['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?', (item.id,)).fetchone()
            assert reference is not None and reference[0] == item.identity == row['case_identity']
            expected = unpack(reference[1])
            observed, jobs = {}, {}
            for name, config in (('current', inputs), ('historical', previous_inputs)):
                entry = next(attempts[name], None)
                assert entry is not None and entry[:2] == (ordinal, item.id)
                record = replay(entry, row, 'native', expected, item, config, prepared, design['execution'])
                assert record['status'] == entry[2]
                if name == 'historical':
                    assert record['status'] == 'passed'
                if record['status'] == 'passed':
                    strict.verify_clock(entry, record)
                else:
                    assert name == 'current' and record['status'] in {'crashed', 'harness_error'}
                    assert record['engine_seconds'] is None
                    packet = unpack(entry[3])
                    files = raw_files(packet)
                    stderr = files['one.stderr.txt'].decode('utf-8')
                    signature = ('DictSlots codes slot' if 'DictSlots codes slot' in stderr else
                        'CLI emitted no JSON; underlying cause not established' if record['status'] == 'harness_error'
                        and (record['failure_detail'] or '').startswith('ShardLoom command emitted no JSON output:')
                        else 'unclassified retained failure')
                    failure_signatures[signature] += 1
                    failed.append(dict(seq=ordinal, id=item.id, case_identity=item.identity,
                        status=record['status'], signature=signature, archetype=row.get('archetype'),
                        family=row['family'], profile=row['profile'], surface=row['surface'],
                        native_format=row['native_format'], detail=record['failure_detail'],
                        stderr=stderr, packet_blob_sha256=hashlib.sha256(entry[3]).hexdigest()))
                observed[name] = record
                raw_job = raw_files(unpack(entry[3]))['one.job.json']
                jobs[name] = hashlib.sha256(raw_job).hexdigest()
            seen.append(item.id)
            outcomes[observed['current']['status']] += 1
            families[row['family']][observed['current']['status']] += 1
            old_values.append(observed['historical']['engine_seconds'])
            output.write(json.dumps(dict(seq=ordinal, id=item.id, case_identity=item.identity,
                family=row['family'], profile=row['profile'], surface=row['surface'],
                native_format=row['native_format'], job_sha256=jobs, **observed),
                separators=(',', ':'), allow_nan=False) + '\n')
            if (ordinal + 1) % 1000 == 0:
                print(json.dumps(dict(saved_attempts_replayed=ordinal + 1, outcomes=dict(outcomes))), flush=True)
        assert all(next(entries, None) is None for entries in attempts.values())
    assert seen == [row['id'] for row in design['cases']] and len(set(seen)) == 10000
    assert dict(outcomes) == EXPECTED_OUTCOMES and len(failed) == 96
    verify(frozen)
    assert identity(target / 'attempts.sqlite') == done['ledger']
    assert identity(previous / 'attempts.sqlite') == current.historical_binding().current(prior['ledger'])
    partial.rename(cases_path)
    result = dict(status='verified_failed_observation', verification_passed=True,
        complete_performance_result_valid=False, engine_execution_seconds=None,
        reason='96 attempts lack a completed correct result; no complete current 10k engine total exists',
        query_executions_during_replay=0, source_commit=current.MERGE, source_tree=current.TREE,
        observed_attempts=10000, verified_correct_results=9904, original_outcomes=dict(outcomes),
        attempts_per_case=1, requested_repeats=0, failed_attempts_preserved=True,
        primary_clock='engine_execution_seconds', finite_engine_clocks_for_all_passed_results=True,
        passed_result_certificates_native_no_fallback=True,
        incomplete_attempt_certificate_claimed=False,
        historical_results_verified=10000, historical_engine_execution_seconds=math.fsum(old_values),
        case_reuse_policy='Only explicitly matched successful cases with identical request, source, runtime and clock contracts may form a later predefined cohort; failed cases are never replaced or combined into a full10k claim',
        families={name: dict(counts) for name, counts in sorted(families.items())},
        failure_signatures=dict(failure_signatures), failures=failed,
        case_rows=identity(cases_path), complete=identity(target / 'complete.json'), ledger=done['ledger'],
        historical_complete=identity(previous / 'complete.json'), historical_ledger=prior['ledger'],
        guard=identity(guard_path), protocol=identity(current.PROTOCOL), verifier=identity(Path(__file__)),
        original_strict_verifier=identity(Path(strict.__file__)), warm_reuse_measured=False)
    with destination.open('x') as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'verification_passed',
        'complete_performance_result_valid', 'engine_execution_seconds', 'observed_attempts',
        'verified_correct_results', 'original_outcomes', 'failure_signatures')}))


if __name__ == '__main__':
    main()
