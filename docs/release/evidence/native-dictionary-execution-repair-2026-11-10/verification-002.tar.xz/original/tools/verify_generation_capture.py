"""Preflight the versioned provenance adapter without executing native queries."""
import ast
import difflib
import json
from pathlib import Path
import sys
import unittest

import run_current_10k as current
import test_frozen_generation_binding as controls
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.expanded_run import verify_request_files


def main():
    destination = current.S / 'baseline-generation-preflight-r1.json'
    diff_path = current.S / 'baseline-capture-provenance-r1.diff'
    assert not destination.exists() and not diff_path.exists()
    current.verify_capture_source()
    historical = current.historical_binding()
    original_verify = current.capture.common.verify
    with historical.admission_verifier(current.capture.common):
        design, inputs, files, relocated, _, _ = current.capture.common.checked_admission(
            current.capture.common.ROOT_DEFAULT, current.E)
    assert current.capture.common.verify is original_verify
    assert len(relocated) == 65
    for stage, expected in (('native', {'passed': 9995}), ('polars', {'passed': 10000})):
        observed = historical.stage_complete(current.E, stage, 10000)
        assert observed['outcomes']['passed'] == expected['passed']
    products, _ = current.verified_runtime()
    runtime = {'binary': identity(Path(products['shardloom']['path'])), 'library': identity(current.LIBRARY)}
    prepared = read(current.E / 'native-preparation/complete.json')
    extras = [item for profile in prepared['profiles'].values()
              for item in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    generations = {row['path']: row for row in historical.files([*files, *extras]) + list(runtime.values())}
    for row in design['cases']:
        # Request construction performs no execution and only carries expected.
        job = current.capture.request(row, 'native', dict(inputs, runtime=runtime), prepared, None, design['execution'])
        verify_request_files(job, generations)
    loaded = {}
    manifest = read(current.E / 'investigation-original-harness-source-r1.json')['harness_sha256']
    for name, module in sys.modules.copy().items():
        if name == 'shardloom' or name.startswith('shardloom.'):
            path = Path(module.__file__).resolve()
            relative = path.relative_to(current.capture.common.HARNESS_DEFAULT).as_posix()
            assert relative.endswith('.py') and identity(path)['sha256'] == manifest[relative]
            loaded[name] = relative
    assert loaded and not any(name.endswith('._native') for name in sys.modules)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(controls.BindingTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful() and result.testsRun == 4
    functions = []
    for module in (current.original_capture, current.capture):
        source = Path(module.__file__).read_text()
        node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'observe')
        functions.append(ast.get_source_segment(source, node).splitlines(keepends=True))
    diff = ''.join(difflib.unified_diff(*functions, fromfile='original_capture.observe', tofile='current_capture.observe'))
    with diff_path.open('x') as output:
        output.write(diff)
    record = dict(status='passed_provenance_adapter_preflight', query_executions=0,
        complete_declaration_generations_checked=len(design['cases']),
        current_identity_files=historical.record['unique_files'], frozen_harness_files=len(relocated),
        loaded_client_modules=loaded, native_extension_loaded=False,
        controls=dict(test_methods=result.testsRun, failures=0, errors=0, skipped=0,
            rejected_changes=['path', 'hash', 'unrecognized device', 'inode', 'size', 'mtime', 'ctime',
                              'wrong field type', 'reverse device mapping', 'extra generation field',
                              'unbound historical generation', 'unknown path']),
        source_verified_capture_edits='only admission and explicit historical identity conversion; execution body unchanged',
        historical_request_runtime='old runtime identity objects retained exactly during old-answer replay',
        current_request_runtime='actual current runtime identity objects',
        strict_current_file_checks='original verify and verify_request_files unchanged',
        original_verifier_restored=True, original_failure_preserved='baseline-protocol-r1.json',
        binding=identity(current.BINDING), diff=identity(diff_path),
        reviewed_helpers=[identity(current.S / 'tools' / name) for name in (
            'run_current_10k.py', 'run_current_capture_r1.py', 'frozen_generation_binding.py',
            'replay_current_10k.py', 'test_frozen_generation_binding.py', 'verify_generation_capture.py')])
    with destination.open('x') as output:
        json.dump(record, output, indent=2)
        output.write('\n')
    print(json.dumps({key: record[key] for key in ('status', 'query_executions',
        'complete_declaration_generations_checked', 'current_identity_files')}))


if __name__ == '__main__':
    main()
