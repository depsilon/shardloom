"""One unscored failure reproduction with a Rust backtrace, preserving the scored pass."""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import sys

import run_current_10k as current
from query_surface.evidence import identity, worker_outcome
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import closing_db, verify, verify_request_files


def main():
    target = current.S / 'dictionary-panic-diagnostic-r1'
    assert not target.exists()
    _, _, frozen, _ = current.updated_admission(current.E)
    done = read(current.TARGET / 'complete.json')
    verify([done['ledger'], done['binding']])
    with closing_db(Path(done['ledger']['path']), readonly=True) as db:
        entry = db.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=433').fetchone()
    assert entry[1] == 'v2_integer_expression_order_38997a4131500439' and entry[2] == 'crashed'
    files = raw_files(unpack(entry[3]))
    job = json.loads(files['one.job.json'])
    verify_request_files(job, {row['path']: row for row in frozen})
    target.mkdir()
    job_path = target / 'one.job.json'
    with job_path.open('xb') as output:
        output.write(files['one.job.json'])
    with current.capture.BenchmarkGuard(target, binary=Path(job['runtime']['binary']['path']), memory_gb=2) as guard:
        command = ['env', 'RUST_BACKTRACE=1', sys.executable, '-B', str(current.capture.WORKER), '--job', str(job_path)]
        receipt = current.capture.run_profiled_command(command, target / 'one', job['timeout'] + 5, guard.check)
    stdout = (target / 'one.stdout.json').read_bytes()
    stderr = (target / 'one.stderr.txt').read_text()
    outcome = worker_outcome(receipt, stdout)
    assert outcome['status'] == 'crashed' and 'DictSlots codes slot' in stderr
    assert 'stack backtrace:' in stderr
    verify(frozen)
    result = dict(status='reproduced_failure_for_diagnosis', query_executions=1,
        benchmark_score=False, original_attempt_unchanged=True, original_seq=entry[0], id=entry[1],
        original_packet_sha256=hashlib.sha256(entry[3]).hexdigest(),
        original_ledger=done['ledger'], exact_original_job=identity(job_path),
        diagnostic_change='RUST_BACKTRACE=1 only', supervision=receipt,
        stderr=identity(target / 'one.stderr.txt'), stdout=identity(target / 'one.stdout.json'),
        script=identity(Path(__file__)))
    with (target / 'diagnosis.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'query_executions', 'benchmark_score', 'id')}))


if __name__ == '__main__':
    main()
