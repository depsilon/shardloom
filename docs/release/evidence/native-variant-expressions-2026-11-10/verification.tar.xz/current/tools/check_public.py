"""Run the selected public Variant tests against one explicit frozen runtime."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--runtime', required=True)
parser.add_argument('--tag', required=True)
parser.add_argument('modules', nargs='*', default=['test_native_variant_expression_binding'])
args = parser.parse_args()
out = Path(__file__).resolve().parents[1]
assert args.runtime.replace('-', '').isalnum() and args.tag.replace('-', '').isalnum()
runtime = out / args.runtime
assert all((runtime / name).is_file() for name in ('lib_native.dylib', 'shardloom'))
work = out / (args.tag + '-work')
assert not work.exists()
work.mkdir()
env = dict(os.environ, PYTHONPATH='python/src:python/tests',
    SHARDLOOM_REQUIRE_NATIVE_PYTHON='1', SHARDLOOM_NATIVE_TEST_LIBRARY=str(runtime / 'lib_native.dylib'),
    SHARDLOOM_BINARY=str(runtime / 'shardloom'), SHARDLOOM_SURFACE_TEST_BINARY=str(runtime / 'shardloom'),
    TMPDIR=str(work))
subprocess.run([sys.executable, '-B', '-m', 'unittest', '-v', *args.modules], env=env, check=True, timeout=900)
