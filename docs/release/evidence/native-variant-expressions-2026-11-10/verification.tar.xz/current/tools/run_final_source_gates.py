"""Verify final documentation and contracts after the accepted UUID closeout."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tag', required=True)
parser.add_argument('--runtime', required=True)
args = parser.parse_args()
assert args.tag.replace('-', '').isalnum() and args.runtime.replace('-', '').isalnum()
directory = Path(__file__).resolve().parent
checks = [
    ('doc-contracts', 600, ['cargo', 'test', '--offline', '--locked',
        '-p', 'shardloom-contract-tests', '--all-targets']),
    ('docs', 600, [sys.executable, '-B', str(directory / 'check_docs.py'),
        '--tag', args.tag, '--runtime', args.runtime]),
]
for family, timeout, command in checks:
    name = family + '-' + args.tag
    print('Starting ' + name, flush=True)
    subprocess.run([sys.executable, '-B', str(directory / 'guard_variant_expressions.py'),
        '--name', name, '--timeout', str(timeout), '--', *command], check=True)
