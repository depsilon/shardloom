"""Advance the Variant expression base to the accepted identical tree without touching source files."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'uuid-lifecycle-2026-11-10'
OLD = 'd21f680f0fab0592d9fa0b649d505b36ecbd7e8b'
BRANCH = 'refs/heads/codex/native-variant-expressions'
DEST = OUT / 'variant-expression-base-adoption-r1.json'


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=ROOT, timeout=90)


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def snapshot():
    changed = set()
    for args in (['diff', '--name-only', '-z', 'HEAD'],
                 ['ls-files', '--others', '--exclude-standard', '-z']):
        changed.update(filter(None, git(*args).decode().split('\0')))
    files = {}
    for name in sorted(changed):
        path = ROOT / name
        if path.is_symlink():
            files[name] = dict(symlink=str(path.readlink()))
        elif path.is_file():
            stat = path.stat()
            files[name] = dict(identity=identity(path.read_bytes()), generation=[
                stat.st_dev, stat.st_ino, stat.st_mode, stat.st_size, stat.st_mtime_ns,
                stat.st_ctime_ns, stat.st_nlink])
        else:
            assert not path.exists()
            files[name] = dict(absent=True)
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = ROOT / index
    return dict(files=files, index=identity(index.read_bytes()),
        diff=identity(git('diff', '--binary', 'HEAD')),
        status=git('status', '--porcelain').decode())


assert not DEST.exists()
prior_raw = (PRIOR / 'uuid-closeout-r1.json').read_bytes()
prior = json.loads(prior_raw)
NEW = prior['merge_commit']
assert len(NEW) == 40 and all(char in '0123456789abcdef' for char in NEW)
assert prior['status'] == 'complete' and prior['merge_commit'] == NEW and prior['pr_head'] == OLD
assert prior['pr_checks_passed'] == 58 and prior['main_checks_passed'] == 55
assert prior['portable_replay_after_retirement'] == 'passed'
assert git('symbolic-ref', 'HEAD').decode().strip() == BRANCH
assert git('rev-parse', 'HEAD').decode().strip() == OLD
tree = git('rev-parse', OLD + '^{tree}').decode().strip()
assert tree == git('rev-parse', NEW + '^{tree}').decode().strip() == prior['source_tree']
parents = git('show', '-s', '--format=%P', NEW).decode().split()
assert len(parents) == 2 and parents[1] == OLD
# The caller must finish guarded jobs first; verify no Variant expression preparation/build
# guard is live before changing the base observed by those processes.
processes = subprocess.check_output(['ps', '-axo', 'pid,command'], text=True)
assert not any('python' in line and any(name in line for name in (
    '/tools/guard_variant_expressions.py', '/tools/run_source_gates.py',
    '/tools/run_runtime_gates.py')) for line in processes.splitlines())
before = snapshot()
assert before['files'], 'expected the task-owned Variant expression implementation'
subprocess.run(['git', 'update-ref', '-m', 'Adopt verified UUID merge with identical source tree',
    BRANCH, NEW, OLD], cwd=ROOT, timeout=60, check=True)
result = dict(status='failed', old_head=OLD, new_head=NEW, tree=tree,
    prior_closeout=identity(prior_raw), before=before,
    observed_at=datetime.now(timezone.utc).isoformat(), script=identity(Path(__file__).read_bytes()))
try:
    assert git('rev-parse', 'HEAD').decode().strip() == NEW
    after = snapshot()
    assert before == after, 'base adoption changed the index, diff, or task-owned source identities'
    result.update(status='passed', after=after, accepted_base_tree_unchanged=True,
        index_unchanged=True, dirty_sources_unchanged=True, working_diff_unchanged=True,
        branch_compare_and_set=True)
finally:
    with DEST.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
print(json.dumps({name: result[name] for name in (
    'status', 'old_head', 'new_head', 'tree', 'dirty_sources_unchanged', 'index_unchanged')}))
