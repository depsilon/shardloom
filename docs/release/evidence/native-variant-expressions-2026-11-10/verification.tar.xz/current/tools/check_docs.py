"""Verify generated interfaces, public status and documentation contracts."""
import argparse
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tag', required=True)
parser.add_argument('--runtime', required=True)
args = parser.parse_args()
assert args.tag.replace('-', '').isalnum() and args.runtime.replace('-', '').isalnum()
runtime = OUT / args.runtime
checks = [
    ['scripts/write_native_function_reference.py', '--check', '--native-library', str(runtime / 'lib_native.dylib')],
    ['scripts/write_public_api_reference.py', '--check', '--binary', str(runtime / 'shardloom')],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_python_license_bundle.py'],
    ['scripts/check_public_status_docs.py', '--output', str(OUT / ('public-status-docs-' + args.tag + '.json'))],
    ['scripts/check_contribution_governance.py', '--output', str(OUT / ('contribution-governance-' + args.tag + '.json'))],
    ['-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_prove_native_python_wheel.py', '-v'],
]
for command in checks:
    print('Checking ' + ' '.join(command), flush=True)
    subprocess.run([sys.executable, '-B', *command], check=True, timeout=120)
