"""Retire closed reproducible debug files after the recorded free-space refusal."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
ROOTS = (CACHE / 'debug', OUT / 'runtime-preparation-r1')
DEST = OUT / 'preparation-retirement-r1'
CHECKS = ('variant-focused-preparation-r4.json', 'variant-path-preparation-r1.json',
          'variant-clippy-preparation-r2.json', 'public-build-preparation-r2.json')
OBSERVATIONS = (*CHECKS, 'public-preparation-r1.json', 'public-preparation-r2.json',
                'variant-focused-preparation-r5.json')
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    assert path.is_file() and not path.is_symlink()
    return {'bytes': path.stat().st_size, 'sha256': base.sha(path)}

def inventory():
    rows, links, hashes = [], {}, {}
    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = {'path': str(path), 'generation': before}
        if stat.S_ISDIR(before[2]):
            item['kind'] = 'directory'
            rows.append(item)
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            rows.append(dict(item, kind='regular', sha256=hashes[key]))
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            rows.append(dict(item, kind='symlink', target=os.readlink(path)))
        else:
            raise AssertionError('unexpected file type: ' + str(path))
        assert base.generation(path) == before
    for root in ROOTS:
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
        visit(root)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths)
    return rows

def retained():
    expected = dict(read(OUT / 'retained-baseline-r1.json')['retained_runtime_and_wheel'])
    variant = OUT.parent / 'variant-lifecycle-2026-11-09'
    expected.update(read(variant / 'variant-closeout-r1.json')['retained_runtime_and_wheel'])
    for row in read(OUT / 'runtime-preparation-r2-identity.json')['files']:
        expected[row['path']] = {key: row[key] for key in ('bytes', 'sha256')}
    for name, item in expected.items():
        path = Path(name)
        assert not any(path.is_relative_to(root) for root in ROOTS)
        assert identity(path) == item, name
    assert len(expected) == 8
    return expected

def inputs():
    directory = OUT.parent / 'variant-lifecycle-2026-11-09/variant-retirement-r1'
    assert base.sha(directory / 'manifest.json.xz') == read(directory / 'plan.json')['manifest_sha256']
    expected = json.loads(lzma.decompress((directory / 'manifest.json.xz').read_bytes()))['input_generations']
    assert {name: base.generation(Path(name)) for name in expected} == expected
    return expected

def release():
    return {str(path): base.generation(path) for path in sorted((CACHE / 'release').rglob('*'))}

def superseded():
    record = read(OUT / 'runtime-preparation-r1-identity.json')
    assert record['status'] == 'passed'
    assert identity(OUT / record['build_receipt']) == record['build_receipt_identity']
    assert set(path.name for path in ROOTS[1].iterdir()) == {'shardloom', 'lib_native.dylib'}
    for row in record['files']:
        path = Path(row['path'])
        assert path.parent == ROOTS[1]
        assert identity(path) == {key: row[key] for key in ('bytes', 'sha256')}
    return record

def resolve():
    for name in OBSERVATIONS:
        receipt = read(OUT / name)
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['source_validation_mode'] == 'preparation_no_source_changes'
        assert base.sha((OUT / name).with_suffix('.log')) == receipt['log_sha256']
        if name in CHECKS:
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
            assert not receipt['build_source_verification']['post_execution']['changed_paths']
    stopped = read(OUT / 'variant-focused-preparation-r5.json')
    assert stopped['status'] == 'failed' and 'insufficient free disk' in stopped['error']
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert metadata['target_directory'] == str(CACHE)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == stopped['head'] == read(OUT / 'retained-baseline-r1.json')['source_head']
    return head

def plan():
    head = resolve()
    assert not DEST.exists()
    base.closed([str(root) for root in ROOTS])
    print('Inventorying closed reproducible debug output', flush=True)
    rows = inventory()
    manifest = {'roots': list(map(str, ROOTS)), 'entries': rows, 'retained': retained(),
        'input_generations': inputs(), 'release_generations': release(), 'superseded': superseded(),
        'source_head': head, 'observations': {name: identity(OUT / name) for name in OBSERVATIONS}}
    blob = OUT / 'source-blobs' / base.sha(HELPER)
    if not blob.exists():
        blob.write_bytes(HELPER.read_bytes())
    assert blob.read_bytes() == HELPER.read_bytes()
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = {'status': 'planned_no_deletion', 'roots': list(map(str, ROOTS)), 'entries': len(rows),
        'regular_files': sum(row['kind'] == 'regular' for row in rows),
        'regular_bytes': sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        'symlinks': sum(row['kind'] == 'symlink' for row in rows),
        'manifest_sha256': base.sha(DEST / 'manifest.json.xz'), 'script_sha256': base.sha(Path(__file__)),
        'helper_sha256': base.sha(HELPER),
        'reason': 'The focused test rebuild stopped before tests at the unchanged free-space floor. All original receipts/logs/source inventories remain. Debug compiler output is reproducible; runtime-preparation-r1 is superseded by retained r2. Public r2 is partial, not accepted.',
        'regeneration': 'Use immutable build receipts, locked dependencies and complete source blobs. Preserve UUID and accepted Variant runtimes/wheels, current Variant-expression r2 comparison runtime, all input generations, release cache and original observations. No payload backup or limit change.'}
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)

def apply():
    resolve()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['roots'] == list(map(str, ROOTS))
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    assert superseded() == manifest['superseded'] and retained() == manifest['retained']
    assert inputs() == manifest['input_generations'] and release() == manifest['release_generations']
    assert all(identity(OUT / name) == value for name, value in manifest['observations'].items())
    base.closed(list(map(str, ROOTS)))
    print('Rechecking exact identities and closed handles', flush=True)
    assert inventory() == manifest['entries']
    base.closed(list(map(str, ROOTS)))
    receipt = {'status': 'running', 'removed': 0, 'manifest_sha256': summary['manifest_sha256']}
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(manifest['entries'], key=lambda item: len(Path(item['path']).parts), reverse=True):
            path = Path(row['path'])
            assert any(path == root or path.is_relative_to(root) for root in ROOTS)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                assert current[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert all(not root.exists() and not root.is_symlink() for root in ROOTS)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert release() == manifest['release_generations']
        receipt.update(status='passed', regular_files=summary['regular_files'],
            regular_bytes=summary['regular_bytes'], symlinks=summary['symlinks'],
            retained_runtimes_and_wheels_unchanged=True, input_generations_unchanged=True,
            release_cache_unchanged=True, storage_limits_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
