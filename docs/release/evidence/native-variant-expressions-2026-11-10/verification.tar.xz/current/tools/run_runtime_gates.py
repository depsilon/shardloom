"""Build, freeze and exercise a fresh Variant expression runtime and local wheel."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tag', required=True)
parser.add_argument('--runtime', required=True)
parser.add_argument('--installed', required=True)
parser.add_argument('--core', required=True)
parser.add_argument('--preparation', action='store_true')
args = parser.parse_args()
for value in (args.tag, args.runtime, args.installed, args.core):
    assert value.replace('-', '').isalnum()
directory = Path(__file__).resolve().parent
out = directory.parent
python = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
build_python = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
runtime = out / args.runtime
installed = out / args.installed
assert not runtime.exists() and not installed.exists() and not (out / args.core).exists()
public_work = out / ('public-release-' + args.tag + '-work')
assert not public_work.exists()
public_work.mkdir()
core_environment = ['env']
for name in ('SHARDLOOM_REQUIRE_NATIVE_PYTHON', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
             'SHARDLOOM_BIN', 'SHARDLOOM_BINARY', 'SHARDLOOM_SURFACE_TEST_BINARY',
             'SHARDLOOM_REPO_ROOT', 'SHARDLOOM_PROFILE_ORDER', 'PYTHONPATH', 'PYTHONHOME'):
    core_environment += ['-u', name]
checks = [
    ('release-build', 3600, ['env', 'PYO3_PYTHON=' + python, 'cargo', 'build',
        '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
        '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime', 300, [python, '-B', str(directory / 'freeze_runtime.py'),
        '--build', 'release-build-' + args.tag + '.json', '--name', args.runtime,
        '--profile', 'release']),
    ('public-release', 1200, ['env', 'PYTHONPATH=python/src:python/tests',
        'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
        'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(runtime / 'lib_native.dylib'),
        'SHARDLOOM_BINARY=' + str(runtime / 'shardloom'),
        'SHARDLOOM_SURFACE_TEST_BINARY=' + str(runtime / 'shardloom'),
        'TMPDIR=' + str(public_work), build_python, '-B', '-m', 'unittest', '-v',
        'test_native_variant_expression_binding', 'test_native_function_catalog',
        'test_native_result_schema']),
    ('installed', 2400, [build_python, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(installed), '--native-library', str(runtime / 'lib_native.dylib'),
        '--cli-binary', str(runtime / 'shardloom'), '--wheelhouse',
        '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse']),
    ('python-core', 900, [*core_environment, str(installed / 'venv/bin/python'),
        '-B', 'scripts/run_python_test_shard.py', '--shard', 'core',
        '--output-dir', str(out / args.core)]),
]
for family, timeout, command in checks:
    name = family + '-' + args.tag
    print('Starting ' + name, flush=True)
    mode = ['--preparation'] if args.preparation else []
    subprocess.run([sys.executable, '-B', str(directory / 'guard_variant_expressions.py'),
        '--name', name, '--timeout', str(timeout), *mode, '--', *command], check=True)
