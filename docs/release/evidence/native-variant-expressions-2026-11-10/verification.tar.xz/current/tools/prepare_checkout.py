"""Prepare the next task-owned branch without changing the UUID review checkout."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
UUID_ROOT = Path('/Users/dylan/.codex/worktrees/native-uuid-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'uuid-lifecycle-2026-11-10'
OLD = '0cae77b442c07d62911a50e2dc6b78067130beca'
HEAD = 'd21f680f0fab0592d9fa0b649d505b36ecbd7e8b'
BRANCH = 'codex/native-variant-expressions'
DEST = OUT / 'checkout-r1.json'
assert not DEST.exists()


def git(*args, root=ROOT):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=root, timeout=90).decode().strip()


def branches():
    return dict(line.split(' ', 1) for line in git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads/').splitlines())


def trees():
    return {block.splitlines()[0].removeprefix('worktree '): block.splitlines()[1:]
            for block in git('worktree', 'list', '--porcelain').split('\n\n')}


assert shutil.disk_usage(OUT).free >= (12 << 30) + (256 << 20)
assert git('rev-parse', 'HEAD') == OLD and not git('status', '--porcelain')
assert not git('branch', '--show-current')
assert git('rev-parse', 'HEAD', root=UUID_ROOT) == HEAD
assert not git('status', '--porcelain', root=UUID_ROOT)
before_branches, before_trees = branches(), trees()
assert 'refs/heads/' + BRANCH not in before_branches
source = json.loads((PRIOR / 'source-commit-r1.json').read_bytes())
assert source['status'] == 'passed' and source['head'] == HEAD and source['base'] == OLD
assert git('rev-parse', HEAD + '^{tree}') == source['tree']
record = dict(status='running', previous_head=OLD, source_head=HEAD, branch=BRANCH,
    tree=source['tree'], source_worktree=str(ROOT), uuid_worktree=str(UUID_ROOT),
    observed_at=datetime.now(timezone.utc).isoformat(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    previous_uuid_closeout='pending; this is preparation, not final acceptance',
    branches_before=before_branches, worktrees_before=before_trees)
try:
    subprocess.run(['git', 'switch', '-c', BRANCH, HEAD], cwd=ROOT, check=True, timeout=90)
    assert git('rev-parse', 'HEAD') == HEAD and git('branch', '--show-current') == BRANCH
    assert not git('status', '--porcelain')
    assert git('rev-parse', 'HEAD', root=UUID_ROOT) == HEAD and not git('status', '--porcelain', root=UUID_ROOT)
    after_branches, after_trees = branches(), trees()
    assert after_branches.pop('refs/heads/' + BRANCH) == HEAD and after_branches == before_branches
    assert {k:v for k,v in before_trees.items() if k != str(ROOT)} == {k:v for k,v in after_trees.items() if k != str(ROOT)}
    record.update(status='passed', uuid_source_unchanged=True, other_branches_unchanged=True,
        other_worktrees_unchanged=True, clean_candidate=True, worktrees_after=after_trees)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    with DEST.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(json.dumps({key:record[key] for key in ('status','source_head','branch','uuid_source_unchanged','other_worktrees_unchanged')}))
