"""Prepare reviewable Variant evidence scripts from the preceding UUID packet."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'uuid-lifecycle-2026-11-10/tools'
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)


def between(text, start, end, body):
    begin = text.index(start)
    finish = text.index(end, begin)
    return text[:begin] + body + text[finish:]


def common(text):
    for old, new in (
        ('verify_uuid_packet', 'verify_variant_expression_packet'),
        ('check_uuid_controls', 'check_variant_expression_controls'),
        ('seal_uuid_controls', 'seal_variant_expression_controls'),
        ('native-uuid-lifecycle/shardloom-local-repo', 'native-vector-representations/shardloom-local-repo'),
        ('shardloom.uuid_lifecycle_acceptance.v1', 'shardloom.variant_expression_acceptance.v1'),
        ('uuid-base-adoption-r1.json', 'variant-expression-base-adoption-r1.json'),
        ('adopt_variant_base.py', 'adopt_uuid_base.py'),
        ('variant-lifecycle-2026-11-09', 'uuid-lifecycle-2026-11-10'),
        ('variant-closeout-r1.json', 'uuid-closeout-r1.json'),
        ('pr1674', 'pr1675'),
        ('variant-main', 'uuid-main'),
        ('variant-retirement-r1', 'uuid-retirement-r1'),
        ('check_uuid_features.py', 'check_features.py'),
        ('check_uuid_msrv.py', 'check_msrv.py'),
        ('check_uuid_docs.py', 'check_docs.py'),
    ):
        text = text.replace(old, new)
    return text


verifier = common((PRIOR / 'verify_uuid_packet.py').read_text())
verifier = replace(verifier, 'Replay source-bound UUID acceptance', 'Replay source-bound Variant expression acceptance')
verifier = replace(verifier, "BASE = '0cae77b442c07d62911a50e2dc6b78067130beca'", "BASE = '8df722749e3993bb27a9cdd573de8a2a3860bb34'")
verifier = replace(verifier, "PREPARATION_BASE = '7ee43de766a85f3b5ca145e9330a80a69a9155aa'", "PREPARATION_BASE = 'd21f680f0fab0592d9fa0b649d505b36ecbd7e8b'")
verifier = replace(verifier, "BASE_TREE = '81020b350ff589a2cf6e9a094aa5a6f0c88074b1'", "BASE_TREE = '2686fcc6b7120ca04d53e7ac4f0d1cc1847eb322'")
verifier = replace(verifier, "'msrv': 'check_msrv.py', 'provider_arrow': 'check_arrow_array_provider.py',", "'msrv': 'check_msrv.py',")
verifier = replace(verifier, "'format', 'native_clippy', 'native_tests', 'provider_arrow',", "'format', 'native_clippy', 'native_tests',")
verifier = between(verifier, "MODULES = (", 'STATUS_PROSE = {', '''MODULES = ('test_native_variant_expression_binding', 'test_native_function_catalog', 'test_native_result_schema')
NATIVE_TEST_SOURCES = (
    'shardloom-vortex/src/local_primitive_relational_variant_expression_tests.rs',
    'shardloom-vortex/src/local_primitive_relational_variant_bind.rs',
    'shardloom-cli/src/sql_syntax.rs',
)
NATIVE_TEST_PATTERN = r'\\bfn\\s+((?:native_variant_expression_\\w+|variant_path_literals_preserve_names_and_refuse_unsupported_steps|parser_variant_field_functions_reach_native_binding))\\s*\\('
''')
verifier = replace(verifier, "'docs/architecture/native-uuid-lifecycle-2026-11-10.md',", "'docs/architecture/native-variant-expressions-2026-11-10.md',")
frozen_receipt = json.loads((OUT / 'public-release-preparation-r1.json').read_bytes())
assert frozen_receipt['status'] == 'passed'
frozen_paths = (
    'python/tests/test_native_variant_expression_binding.py',
    'python/tests/test_native_function_catalog.py',
    'python/tests/test_native_result_schema.py',
    'shardloom-vortex/src/local_primitive_relational_variant_expression_tests.rs',
    'shardloom-vortex/src/local_primitive_relational_variant_bind.rs',
    'shardloom-cli/src/sql_syntax.rs',
)
frozen = {}
for path in frozen_paths:
    sha = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    assert frozen_receipt['build_sources'][path]['sha256'] == sha
    frozen[path] = ('public-release-preparation-r1.json', sha)
verifier = between(verifier, '# These complete fixture/test files', 'EXCLUDED =',
    '# Complete independently specified fixtures captured before broad acceptance.\n'
    '# Their expected values do not come from candidate execution.\nFROZEN = ' + repr(frozen) + '\n')
required_failures = {row['receipt'] for row in json.loads((OUT / 'failure-dispositions.json').read_bytes())['observations']}
verifier = between(verifier, 'REQUIRED_HISTORICAL_FAILURES = {', 'PRIOR_CORE_RECEIPTS =',
    'REQUIRED_HISTORICAL_FAILURES = ' + repr(required_failures) + '\n')
verifier = replace(verifier, "'runtime-r2-identity.json', 'installed-proof-r1/report.json',", "'runtime-r1-identity.json', 'installed-proof-r1/report.json',")
verifier = between(verifier, 'LIMITATIONS = [', '\n\ndef digest(', '''LIMITATIONS = [
    'Finite native Variant field/path extraction, typed conversion, persistence and ownership acceptance; no benchmark or performance comparison.',
    'Literal paths and targets only. Paths have at most 24 steps and 16384 UTF-8 bytes. SQL NULL and embedded Variant null remain distinct; unsupported traversal and failed typed conversions return SQL NULL.',
    'Pinned Vortex 0.93 native format conversion uses an admitted Arrow format bridge and conservative workspace reservations. No zero-copy, zero-decode or total-process RSS bound is claimed; temporal conversion pairs remain explicitly bounded.',
    'Logical nesting depth remains 24 and storage wrappers remain bounded at 64. Useful spatial support and resource-admitted deep traversal remain required.',
    'Original failed and interrupted observations remain evidence. Default/native opt-in ignores and Python optional/environment skips remain explicit; selected public and installed tests require zero skips.',
    'No package publication, performance superiority, whole item 19, item 20, RFC 0044 or CG-1 through CG-23 completion claim.',
]
SOURCE_POLICY = (
    'All original source inventories and preparation labels remain immutable. Reused preparation '
    'requires unchanged pre/post source inventories, drained/reaped processes, final production-source '
    'equality and the completed preceding UUID closeout. The UUID PR head and accepted merge have the '
    'same tree; base adoption preserves index, dirty file identities and working diff. Only named '
    'status prose may differ at engine/runtime gates. All vendor, provider-lock, Cargo/config and '
    'production inputs remain included. Fresh docs and contract checks run after identical-tree '
    'base adoption and completed UUID closeout. Final guards capture and reverify that closeout '
    'identity; all guards preserve the retained runtime/wheel and input generations. No preparation '
    'receipt is relabeled as fixed-source final acceptance.'
)
''')
verifier = between(verifier, 'def provider_inputs(source):', '\n\ndef verify(', '')
verifier = between(verifier, "            if value.get('status') == 'running':", "            if 'log_sha256' in value:",
    "            assert value.get('status') != 'running', name\n")
verifier = replace(verifier,
    "    assert report['base_adoption'] == identity(data['current/variant-expression-base-adoption-r1.json'])\n    reused = {}",
    "    assert report['base_adoption'] == identity(data['current/variant-expression-base-adoption-r1.json'])\n"
    "    retained = read('current/retained-baseline-r1.json')\n"
    "    assert retained['status'] == 'local_dependency_proof_passed' and retained['source_head'] == PREPARATION_BASE\n"
    "    assert retained['retained_runtime_and_wheel'] == closeout['retained_runtime_and_wheel']\n"
    "    reused = {}")
verifier = replace(verifier, "            assert result['prior_closeout_sha256'] == digest(data['prior/acceptance.json'])\n            assert result['driver_sha256'] == digest(data['current/tools/guard_uuid_preparation.py'])",
    "            assert result['accepted_uuid_closeout'] is None")
verifier = verifier.replace("compared_scope='complete_vendor_provider_graph' if role == 'provider_arrow' else 'all_inputs_except_named_status_prose'", "compared_scope='all_inputs_except_named_status_prose'")
verifier = replace(verifier,
    "            assert result['head'] == result['base'] == BASE\n            assert result['prior_closeout_sha256'] == digest(data['prior/uuid-closeout-r1.json'])\n            assert result['driver_sha256'] == digest(data['current/tools/guard_uuid.py'])",
    "            assert result['head'] == BASE and result['base'] == PREPARATION_BASE\n"
    "            assert result['accepted_uuid_closeout'] == dict(\n"
    "                path='/Users/dylan/LocalData/shardloom/uuid-lifecycle-2026-11-10/uuid-closeout-r1.json',\n"
    "                **identity(data['prior/uuid-closeout-r1.json']))\n"
    "        assert result['prior_closeout_sha256'] == digest(data['current/retained-baseline-r1.json'])\n"
    "        assert result['driver_sha256'] == digest(data['current/tools/guard_variant_expressions.py'])")
verifier = replace(verifier,
    "        if role == 'provider_arrow':\n            assert provider_inputs(result['build_sources']) == provider_inputs(source)\n        else:\n            assert set(deltas) <= (set() if role in {'docs', 'doc_contracts'} else STATUS_PROSE), (role, deltas)",
    "        assert set(deltas) <= (set() if role in {'docs', 'doc_contracts'} else STATUS_PROSE), (role, deltas)")
verifier = replace(verifier, 'tests=420, failures=0, errors=0, skipped=0', 'tests=431, failures=0, errors=0, skipped=0')
verifier = replace(verifier, "main['pr'] == 1674", "main['pr'] == 1675")
verifier = replace(verifier, "read('prior/runtime-r2-identity.json')", "read('prior/runtime-r1-identity.json')")
verifier = replace(verifier, "r'\\bfn\\s+(native_uuid_\\w+)\\s*\\('", 'NATIVE_TEST_PATTERN')
verifier = replace(verifier, 'len(set(required_native)) == 7', 'len(set(required_native)) == 13')
verifier = replace(verifier, 'len(expected_public) == 19', 'len(expected_public) == 25')
verifier = between(verifier, "    tree = ast.parse(source_raw('scripts/ci_provider_tests.py'))", "    core = read('current/' + report['python_core_receipt'])", '')
verifier = replace(verifier, "return len(required_native), {'arrow-array': provider_counts}", 'return len(required_native), {}')
verifier = replace(verifier, "assert frozen['build_receipt_sha256'] == digest(data['current/' + roles['build']])",
    "assert frozen['build_receipt_identity'] == identity(data['current/' + roles['build']])\n"
    "    assert frozen['profile'] == 'release'\n"
    "    assert frozen['build_source_fingerprint_sha256'] == receipts['build']['build_source_fingerprint_sha256']")
verifier = between(verifier, 'def verify_retirements(data, read, closeout):', '\n\ndef verify_controls(', '''def verify_retirements(data, read, closeout):
    directory = 'current/preparation-retirement-r1'
    receipt, plan = read(directory + '/receipt.json'), read(directory + '/plan.json')
    raw = data[directory + '/manifest.json.xz']
    assert receipt['status'] == 'passed' and plan['status'] == 'planned_no_deletion'
    assert digest(raw) == receipt['manifest_sha256'] == plan['manifest_sha256']
    assert digest(data['current/tools/retire_preparation.py']) == plan['script_sha256']
    assert digest(data['current/source-blobs/' + plan['helper_sha256']]) == plan['helper_sha256']
    manifest = json.loads(lzma.decompress(raw))
    roots = manifest['roots']
    assert roots == plan['roots'] and len(roots) == 2
    assert roots == ['/Users/dylan/.cache/shardloom/cargo-target/debug',
        '/Users/dylan/LocalData/shardloom/variant-expressions-2026-11-10/runtime-preparation-r1']
    entries = manifest['entries']
    assert len(entries) == plan['entries'] == receipt['removed'] == len({row['path'] for row in entries})
    assert all(any(PurePosixPath(row['path']).is_relative_to(root) for root in roots) for row in entries)
    assert plan['regular_files'] == receipt['regular_files'] == sum(row['kind'] == 'regular' for row in entries)
    assert plan['symlinks'] == receipt['symlinks'] == sum(row['kind'] == 'symlink' for row in entries)
    assert plan['regular_bytes'] == receipt['regular_bytes'] == sum(
        row['generation'][3] for row in entries if row['kind'] == 'regular')
    assert manifest['source_head'] == PREPARATION_BASE
    successful = {'variant-focused-preparation-r4.json', 'variant-path-preparation-r1.json',
        'variant-clippy-preparation-r2.json', 'public-build-preparation-r2.json'}
    assert set(manifest['observations']) == successful | {
        'public-preparation-r1.json', 'public-preparation-r2.json', 'variant-focused-preparation-r5.json'}
    for name, info in manifest['observations'].items():
        original = read('current/' + name)
        assert identity(data['current/' + name]) == info
        assert original['source_validation_mode'] == 'preparation_no_source_changes'
        assert original['process_group_drained'] and original['direct_child_reaped']
        if name in successful:
            assert original['status'] == 'passed' and original['returncode'] == 0
            for phase in ('pre_execution', 'post_execution'):
                assert original['build_source_verification'][phase]['changed_paths'] == []
    stopped = read('current/variant-focused-preparation-r5.json')
    assert stopped['status'] == 'failed' and 'insufficient free disk' in stopped['error']
    assert all(manifest['retained'][path] == info for path, info in closeout['retained_runtime_and_wheel'].items())
    assert len(manifest['retained']) == 8 and len(manifest['input_generations']) == 220
    assert receipt['retained_runtimes_and_wheels_unchanged'] and receipt['input_generations_unchanged']
    assert receipt['release_cache_unchanged'] and not receipt['storage_limits_changed'] and not receipt['payload_backup_created']
    runtime = manifest['superseded']
    assert runtime == read('current/runtime-preparation-r1-identity.json') and runtime['status'] == 'passed'
    assert runtime['build_receipt_identity'] == identity(data['current/' + runtime['build_receipt']])
    for row in runtime['files']:
        matching = [entry for entry in entries if entry['path'] == row['path']]
        assert len(matching) == 1 and matching[0]['sha256'] == row['sha256']
        assert matching[0]['generation'][3] == row['bytes']
''')

packager = common((PRIOR / 'package_uuid_evidence.py').read_text())
packager = replace(packager, 'Seal UUID source, runtime', 'Seal Variant expression source, runtime')
packager = replace(packager, 'LIMITATIONS, MODULES, NATIVE_TEST_SOURCES,', 'LIMITATIONS, MODULES, NATIVE_TEST_PATTERN, NATIVE_TEST_SOURCES,')
packager = replace(packager, "compared_scope='complete_vendor_provider_graph' if role == 'provider_arrow' else 'all_inputs_except_named_status_prose'", "compared_scope='all_inputs_except_named_status_prose'")
packager = replace(packager, "r'\\bfn\\s+(native_uuid_\\w+)\\s*\\('", 'NATIVE_TEST_PATTERN')

controls = common((PRIOR / 'check_uuid_controls.py').read_text())
controls = replace(controls, 'Challenge saved UUID acceptance', 'Challenge saved Variant expression acceptance')
controls = controls.replace('provider_test_missing', 'path_test_missing')
controls = replace(controls, "('native_tests', 'shardloom-vortex/src/native_uuid_values.rs')", "('native_tests', 'shardloom-vortex/src/local_primitives/native_relational_variant.rs')")
controls = replace(controls, "('provider_arrow', 'vendor/arrow-array/src/ffi_stream/schema.rs')", "('native_tests', 'vendor/vortex-array/src/scalar_fn/fns/variant_get/mod.rs')")
controls = replace(controls, "('provider_arrow', '.github/provider-locks/arrow-array.lock')", "('build', 'Cargo.lock')")
controls = controls.replace('test_native_uuid_binding', 'test_native_variant_expression_binding').replace('test_uuid_', 'test_variant_')
controls = replace(controls,
    "change_log(report, data, 'provider_arrow', rb'^test ffi_stream::stream_schema::tests::[^\\n]+ \\.\\.\\. ok\\n')",
    "change_log(report, data, 'native_tests', rb'^test .*::variant_path_literals_preserve_names_and_refuse_unsupported_steps \\.\\.\\. ok\\n')")
controls = replace(controls, "del data['current/public-python-r1.json']", "del data['current/public-preparation-r1.json']")

sealer = common((PRIOR / 'seal_uuid_controls.py').read_text())
sealer = replace(sealer, 'their UUID packet', 'their Variant expression packet')

outputs = {
    'verify_variant_expression_packet.py': verifier,
    'package_variant_expression_evidence.py': packager,
    'check_variant_expression_controls.py': controls,
    'seal_variant_expression_controls.py': sealer,
}
print('*** Begin Patch')
for name, text in outputs.items():
    destination = OUT / 'tools' / name
    assert not destination.exists()
    compile(text, str(destination), 'exec')
    print('*** Add File: ' + str(destination))
    for line in text.splitlines():
        print('+' + line)
print('*** End Patch')
