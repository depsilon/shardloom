"""Run independent source gates sequentially with immutable individual receipts."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--group', choices=('default', 'native', 'portability'), required=True)
parser.add_argument('--tag', required=True)
parser.add_argument('--preparation', action='store_true')
args = parser.parse_args()
assert args.tag.replace('-', '').isalnum()
directory = Path(__file__).resolve().parent
features = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
groups = {
    'default': [
        ('format', 300, ['cargo', 'fmt', '--all', '--', '--check']),
        ('default-clippy', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('default-tests', 2400, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets'])],
    'native': [
        ('native-clippy', 2400, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', features, '--', '-D', 'warnings']),
        ('native-tests', 3600, ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets', '--features', features])],
    'portability': [
        ('features', 3600, [sys.executable, '-B', str(directory / 'check_features.py')]),
        ('msrv', 3600, [sys.executable, '-B', str(directory / 'check_msrv.py')])],
}
for family, timeout, command in groups[args.group]:
    name = family + '-' + args.tag
    print('Starting ' + name, flush=True)
    mode = ['--preparation'] if args.preparation else []
    subprocess.run([sys.executable, '-B', str(directory / 'guard_variant_expressions.py'),
        '--name', name, '--timeout', str(timeout), *mode, '--', *command], check=True)
