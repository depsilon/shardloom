"""Attach exact completed corruption-control observations to their Variant expression packet."""
import argparse
import json
from pathlib import Path

from verify_variant_expression_packet import digest, identity, verify

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', required=True, type=Path)
parser.add_argument('--controls', required=True, type=Path)
args = parser.parse_args()
out = Path(__file__).resolve().parents[1]
assert args.packet.resolve().is_relative_to(out) and args.controls.resolve().is_relative_to(out)
destination = args.packet / 'corruption-controls.json'
assert not destination.exists()
receipt = json.loads((args.controls / 'receipt.json').read_bytes())
assert receipt['status'] == 'passed'
assert receipt['driver_sha256'] == digest(Path(__file__).with_name('check_variant_expression_controls.py').read_bytes())
assert receipt['original_packet'] == {name: identity((args.packet / name).read_bytes())
    for name in ('acceptance.json', 'verification.tar.xz', 'verify.py')}
logs = {case['log']: (args.controls / case['log']).read_text() for case in receipt['cases']}
assert all(identity(logs[case['log']].encode()) == case['log_identity'] for case in receipt['cases'])
result = dict(status='passed', receipt=receipt, logs=logs,
    primary_sealer_sha256=digest(Path(__file__).read_bytes()))
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(verify(args.packet, require_controls=True), sort_keys=True))
