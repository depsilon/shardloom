"""Bind the existing golden fixture suite to the downloaded 1.1.0 CLI."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
SOURCE = '4d11d4e9c2349f0dc63dc27288b432a351c1a962'
PACKET = OUT / 'published-golden-110-attempt2'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    for key in os.environ:
        assert not key.startswith(('SHARDLOOM_', 'DYLD_', 'LD_')) and key not in {'PYTHONPATH', 'PYTHONHOME'}
    assert sha(SUPERVISOR) == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    proof_path = OUT / ('github-package-proof-v1.1.0-' + SOURCE[:12] + '.json')
    served = json.loads((OUT / 'v110-github-served-proof-r1.json').read_bytes())
    assert served['status'] == 'passed' and served['head'] == SOURCE
    proof = json.loads(proof_path.read_bytes())
    assert proof['channel_id'] == 'github_prerelease' and proof['target_commit'] == SOURCE
    assert proof['proof_status'] == 'passed' and proof['blockers'] == []
    assert proof['predownload_identity_bound_to_staged_assets'] is True
    assert proof['asset_count'] == 12
    final_path = OUT / 'release-110-final-source-1.json'
    final = json.loads(final_path.read_bytes())
    assert final['status'] == 'passed_technical_preview_source_and_package'
    assert final['source_commit'] == SOURCE
    binary = Path(proof['assets']['shardloom']['path'])
    assert sha(binary) == proof['assets']['shardloom']['sha256']
    source_path = OUT / 'archive-source-110-1.json'
    source = json.loads(source_path.read_bytes())
    assert source['status'] == 'passed' and source['source_commit'] == SOURCE
    final_identity, = [row for row in final['evidence_files'] if row['path'] == str(source_path)]
    assert sha(source_path) == final_identity['sha256']
    build_receipt_path = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31/io790-source110-release-build.json')
    build_receipt = json.loads(build_receipt_path.read_bytes())
    assert sha(build_receipt_path) == 'ff135917a703662f9f049a30d6d537eea32b92c0322e8b8824787376c8463bc5'
    assert build_receipt['status'] == 'passed' and Path(build_receipt['cwd']) == ROOT
    assert build_receipt['head'] == final['accepted_runtime_build_source']
    outside = OUT / 'published-golden-110-attempt1/golden-workflow-report.json'
    original = json.loads(outside.read_bytes())
    assert [flow['status'] for flow in original['workflows']] == ['passed', 'passed', 'failed']
    assert all('certificate' in item or 'external engine marker is missing' in item for item in original['blockers'])
    names = {name for name in source['exported_files'] if name.startswith('python/src/')}
    names.update({'shardloom-vortex/tests/fixtures/local_primitive_struct_five.vortex', 'scripts/check_golden_workflows.py', 'scripts/release_feature_contract.py',
                  'scripts/native_workflow_protocol.py', 'scripts/golden_workflow_contract.py',
                  'docs/status/runs-today-support-matrix.json'})
    pinned = {}
    for name in names:
        pinned[str(ROOT / name)] = source['exported_files'][name]['sha256']
    pinned.update({str(build_receipt_path): sha(build_receipt_path), str(outside): sha(outside), str(binary): sha(binary), str(SUPERVISOR): sha(SUPERVISOR),
                   str(Path(__file__)): sha(__file__), str(proof_path): sha(proof_path),
                   str(source_path): sha(source_path),
                   str(final_path): sha(final_path)})
    assert all(sha(path) == digest for path, digest in pinned.items())
    assert not PACKET.exists()
    PACKET.mkdir()
    # GitHub downloads preserve bytes but are not executable files by default.
    # Keep the original download untouched and execute an independently hashed copy.
    executable = PACKET / 'shardloom'
    with executable.open('xb') as stream, binary.open('rb') as source_stream:
        shutil.copyfileobj(source_stream, stream)
    executable.chmod(0o500)
    assert sha(executable) == sha(binary)
    pinned[str(executable)] = sha(executable)
    report_path = PACKET / 'golden-workflow-report.json'
    command = [sys.executable, '-B', str(ROOT / 'scripts/check_golden_workflows.py'),
               '--repo-root', str(ROOT), '--binary', str(executable), '--skip-build',
               '--work-dir', str(PACKET / 'work'), '--output', str(report_path)]
    spec = importlib.util.spec_from_file_location('golden_supervisor_110', SUPERVISOR)
    bounded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bounded)
    evidence = {'status': 'running', 'command': command, 'source_commit': proof['target_commit'],
                'fixture_scope': 'correctness certificate for the checked-in fixture at the compile-time workspace path',
                'independent_checkout_result': 'two workflows passed; separate checkout fixture produced native I/O evidence only',
                'binary': proof['assets']['shardloom'], 'source_pins': pinned,
                'executed_binary_path': str(executable), 'executed_binary_sha256': sha(executable),
                'python_wrapper_origin': 'unchanged source client matching the release',
                'github_transcript_sha256': sha(proof_path)}
    def guard():
        assert shutil.disk_usage(PACKET).free >= 12 << 30
        assert sum(path.stat().st_size for path in PACKET.rglob('*') if path.is_file()) < 128 << 20
    try:
        guard()
        with (PACKET / 'stdout.log').open('xb') as stdout, (PACKET / 'stderr.log').open('xb') as stderr:
            result = bounded.run(command, cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                output=stdout, error_output=stderr, timeout=180, evidence=evidence,
                guard=guard, max_output_bytes=4 << 20)
        assert result == 0
        report = json.loads(report_path.read_bytes())
        assert report['status'] == 'passed' and report['blockers'] == []
        assert report['workflow_count'] == 3 and report['stage_count'] == 9
        assert report['fallback_attempted'] is False and report['external_engine_invoked'] is False
        assert all(sha(path) == digest for path, digest in pinned.items())
        evidence['status'] = 'passed'
        evidence['report_sha256'] = sha(report_path)
        evidence['report_path'] = str(report_path)
    finally:
        if evidence['status'] == 'running':
            evidence['status'] = 'failed'
        evidence['logs'] = {name: sha(PACKET / name) for name in ('stdout.log', 'stderr.log')}
        with (PACKET / 'receipt.json').open('x') as stream:
            json.dump(evidence, stream, indent=2)
            stream.write('\n')
        print(json.dumps({'status': evidence['status'], 'receipt': str(PACKET / 'receipt.json')}), flush=True)


if __name__ == '__main__':
    main()
