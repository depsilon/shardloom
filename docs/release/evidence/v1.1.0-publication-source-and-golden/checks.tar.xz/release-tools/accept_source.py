"""Bind the release to the selected Git tree, package, archive and accepted native checks."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-release-110/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
SOURCE = '4d11d4e9c2349f0dc63dc27288b432a351c1a962'
TREE = '7a3a61bff7a581ffa93a70b4de8f493a440c136f'
PR_HEAD = '17328d9eb41bd9b9b8c730f5b3f1f0393e52511f'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--local-proof', type=Path, required=True)
parser.add_argument('--hosted-proof', type=Path, required=True)
parser.add_argument('--readiness-review', type=Path, required=True)
args = parser.parse_args()

def read(path):
    return json.loads(path.read_bytes())

def pin(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        return dict(path=str(path), size_bytes=path.stat().st_size,
                    sha256=hashlib.file_digest(stream, 'sha256').hexdigest())

def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=ROOT, text=True).strip()

def remote(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', 'repos/depsilon/shardloom/' + endpoint], cwd=ROOT))

assert not git('status','--porcelain') and git('rev-parse','HEAD') == SOURCE
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', PR_HEAD + '^{tree}') == TREE
commit = remote('commits/' + SOURCE)
assert commit['sha'] == SOURCE and commit['commit']['tree']['sha'] == TREE
assert commit['commit']['verification']['verified'] and commit['commit']['verification']['reason'] == 'valid'
pr_receipt = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31/pr1650-final-hosted-acceptance.json')
pr = read(pr_receipt)
assert pr['pr'] == 1650 and pr['status'] == 'passed' and pr['head'] == PR_HEAD
assert pr['merge']['sha'] == SOURCE and pr['merge']['merged'] and pr['threads'] == []
assert pr['review']['commit_sha'] == PR_HEAD and pr['review']['status'] == 'completed'
assert not pr['review']['has_any_findings'] and len(pr['checks']) == 58
assert all(c['head_sha'] == PR_HEAD and c['conclusion'] == 'success' for c in pr['checks'])
run = remote('actions/runs/41592354237')
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['event'] == 'push' and run['head_sha'] == SOURCE and run['head_branch'] == 'main'
assert args.hosted_proof.resolve().is_relative_to(OUT) and args.local_proof.resolve().is_relative_to(OUT)
hosted = read(args.hosted_proof)
assert hosted['status'] == 'passed' and hosted['source_commit'] == SOURCE
assert hosted['ci_run_id'] == run['id'] and hosted['requested_attempt'] == run['run_attempt']
assert args.readiness_review.resolve().is_relative_to(OUT)
readiness = read(args.readiness_review)
assert readiness['status'] == 'reviewed_for_technical_preview' and readiness['source_commit'] == SOURCE
assert readiness['ci_run_id'] == run['id'] and readiness['verified_readiness_reports'] == 11
assert not readiness['unclassified_additions'] and readiness['source_ci_evidence_sha256'] == pin(args.hosted_proof)['sha256']
correction = OUT / 'source-format-correction-r1/verification.json'
controls = OUT / 'v110-source-format-controls.json'
assert read(correction) == readiness['source_format_rollup_correction']
assert read(controls)['head'] == read(correction)['verifier_commit'] and read(controls)['status'] == 'passed'
assert readiness['release_source_rollup_retained'] and readiness['selected_published_version_at_source'] == '1.0.0'
milestone = ROOT / 'docs/release/evidence/v1.1.0-source-milestone-2026-11-03/acceptance.json'
original = read(milestone)
assert original['status'] == 'local_acceptance_passed' and original['source_version'] == '1.1.0'
assert original['installed'] == dict(tests=303, failures=0, errors=0, skipped=0, status='passed')
asset_receipt = OUT / 'attempt-02/staging-receipt.json'
stage = read(asset_receipt)
assert stage['status'] == 'passed_local_staging_no_publication'
assert stage['release_source_commit'] == SOURCE and stage['release_source_tree'] == TREE
assert stage['package_build_source_commit'] == original['runtime_source']
assets = OUT / 'attempt-02/assets/github-prerelease-assets'
archive_proof = OUT / 'archive-source-110-1.json'
sdist_proof = OUT / 'v110-source-distribution.json'
sdist = read(sdist_proof)
assert sdist['status'] == 'passed' and sdist['source_commit'] == SOURCE
assert len(sdist['verified_files']) == 289 and sdist['sdist_sha256'] == pin(assets / sdist['source_distribution'])['sha256']
archive = read(archive_proof)
assert archive['status'] == 'passed' and archive['source_commit'] == SOURCE and archive['source_tree'] == TREE
assert archive['archive']['sha256'] == stage['git_source_archive_verification']['sha256']
assert archive['version'] == 'shardloom 1.1.0'
local = read(args.local_proof)
assert local['channel_id'] == 'local_assets' and local['proof_status'] == 'passed'
assert not local['blockers'] and local['target_commit'] == SOURCE and local['release_tag'] == 'v1.1.0'
assert local['smoke_check_status'] == local['install_transcript_status'] == local['uninstall_transcript_status'] == 'passed'
assert not local['fallback_attempted'] and not local['external_engine_invoked']
assert len(local['assets']) == 12 and set(local['assets']) == {f.name for f in assets.iterdir()}
for name, expected in local['assets'].items():
    observed = pin(assets / name)
    assert all(observed[k] == expected[k] for k in ('sha256', 'size_bytes')), name
assert local['assets']['shardloom']['sha256'] == original['runtime_files']['shardloom']['sha256']
assert local['assets'][original['wheel']['filename']]['sha256'] == original['wheel']['sha256']
assert git('rev-parse','HEAD') == SOURCE and not git('status','--porcelain')
report = dict(schema_version='shardloom.release_source_package_acceptance.v1',
    status='passed_technical_preview_source_and_package', release_version='1.1.0',
    source_commit=SOURCE, source_tree=TREE, release_source_pr=1650,
    technical_preview_publication_ready=True, production_readiness_claimed=False,
    performance_superiority_claimed=False, uat_measurements_relabelled_as_package_build=False,
    selected_channel_sequence=['github_prerelease','testpypi','pypi','homebrew_tap'],
    local_package_proof_path=str(args.local_proof), accepted_runtime_build_source=original['runtime_source'],
    source_ci=dict(id=run['id'], attempt=run['run_attempt'], url=run['html_url'], conclusion=run['conclusion']),
    artifacts=len(local['assets']), source_archive_verified_files=len(archive['exported_files']),
    evidence_files=[pin(p) for p in (milestone, pr_receipt, asset_receipt, archive_proof, sdist_proof,
        args.hosted_proof, args.readiness_review, correction, controls, args.local_proof, Path(__file__))])
with (OUT / 'release-110-final-source-1.json').open('x') as f:
    json.dump(report,f,indent=2)
    f.write('\n')
print(report['status'], report['source_commit'], report['artifacts'])
