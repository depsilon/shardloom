"""Verify every exported Git blob, then build the release CLI from that archive."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-release-110/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True)
parser.add_argument('--archive', type=Path, required=True)
parser.add_argument('--attempt', type=int, required=True)
args = parser.parse_args()
assert args.attempt > 0


def git(*command):
    return subprocess.check_output(['git', *command], cwd=ROOT)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def fixed():
    assert git('rev-parse', 'HEAD').decode().strip() == args.source
    assert not git('status', '--porcelain')


fixed()
assert args.source == '4d11d4e9c2349f0dc63dc27288b432a351c1a962'
assert len(args.source) == 40 and all(c in '0123456789abcdef' for c in args.source)
archive = args.archive.resolve(strict=True)
assert archive.is_relative_to(OUT) and not args.archive.is_symlink()
assert archive.is_file() and archive.stat().st_size < 2 * GIB
destination = OUT / f'archive-source-110-{args.attempt}'
receipt = OUT / f'archive-source-110-{args.attempt}.json'
assert not destination.exists() and not receipt.exists()
require_local_path(destination, Path.home(), sys.platform)
check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=2 * GIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
expected, excluded = {}, {}
legacy_evidence = {
    'docs/benchmarks/compiler-profile-screen-2026-09-27.json.gz',
    'docs/benchmarks/json-typed-builder-screen-2026-09-27.json.gz',
    'docs/benchmarks/jsonl-typed-builder-screen-2026-09-27.json.gz',
    'docs/benchmarks/portable-release-acceptance-2026-09-27.json.gz',
}
for entry in git('ls-tree', '-rlz', args.source).split(b'\0'):
    if not entry:
        continue
    metadata, raw_name = entry.split(b'\t', 1)
    mode, kind, blob, size = metadata.split()
    name = raw_name.decode('utf-8')
    assert kind == b'blob' and mode in (b'100644', b'100755'), name
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts
    row = dict(bytes=int(size), git_blob=blob.decode(), mode=int(mode, 8))
    # This is the declared export contract, independent of Git attribute matching.
    omitted = name in legacy_evidence or (name.startswith('docs/benchmarks/evidence/') and (
        name.endswith(('.xz', '.gz')) or '.part-' in path.name))
    (excluded if omitted else expected)[name] = row
assert expected and excluded
assert sum(row['bytes'] for row in expected.values()) < GIB
record = dict(status='running', source_commit=args.source,
    source_tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    archive=dict(path=str(archive), bytes=archive.stat().st_size, sha256=sha(archive)),
    exported_files={}, excluded_git_blobs=excluded,
    driver_sha256=sha(Path(__file__)), publication_attempted=False,
    benchmark_rerun=False)
destination.mkdir()
seen = set()
try:
    with tarfile.open(archive, 'r:gz') as bundle:
        assert bundle.pax_headers.get('comment') == args.source
        for member in bundle:
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts, member.name
            if member.isdir():
                assert any(name.startswith(member.name.rstrip('/') + '/')
                           for name in (*expected, *excluded)), member.name
                continue
            assert member.isfile() and member.name in expected, member.name
            assert member.name not in seen, member.name
            seen.add(member.name)
            row = expected[member.name]
            assert member.size == row['bytes'], member.name
            # Git's default tar.umask=0002 adds group-write to tracked modes.
            # Preserve the executable distinction and reject all other modes.
            expected_mode = {0o100644: 0o664, 0o100755: 0o775}[row['mode']]
            assert member.mode == expected_mode, member.name
            target = destination / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            blob = hashlib.sha1(f'blob {member.size}\0'.encode())
            count = 0
            with bundle.extractfile(member) as source, target.open('xb') as output:
                while data := source.read(MIB):
                    output.write(data)
                    digest.update(data)
                    blob.update(data)
                    count += len(data)
            assert count == row['bytes'] and blob.hexdigest() == row['git_blob'], member.name
            target.chmod(member.mode)
            record['exported_files'][member.name] = dict(
                row, archive_mode=member.mode, sha256=digest.hexdigest())
    assert seen == set(expected), sorted(set(expected) - seen)
    assert sha(archive) == record['archive']['sha256']
    fixed()
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2',
               CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
    assert not any(value for key, value in env.items()
        if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
                   'RUSTC_WORKSPACE_WRAPPER'} or key.startswith('CARGO_PROFILE_RELEASE_'))
    cargo = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo']
    metadata = json.loads(subprocess.check_output([*cargo, 'metadata', '--locked',
        '--offline', '--no-deps', '--format-version', '1'], cwd=destination, env=env))
    assert Path(metadata['target_directory']) == CACHE
    command = [*cargo, 'build', '--locked', '--offline', '--release', '-p',
               'shardloom-cli', '--bin', 'shardloom', '--features', 'release-user-surfaces']
    record['build_command'] = command
    subprocess.run(command, cwd=destination, env=env, timeout=3600, check=True)
    binary = OUT / f'archive-source-110-{args.attempt}.shardloom'
    assert not binary.exists()
    shutil.copy2(CACHE / 'release/shardloom', binary)
    record['binary'] = dict(path=str(binary), bytes=binary.stat().st_size, sha256=sha(binary))
    record['version'] = subprocess.check_output([binary, '--version'], text=True).strip()
    assert record['version'] == 'shardloom 1.1.0'
    for name, row in record['exported_files'].items():
        assert sha(destination / name) == row['sha256'], name
    fixed()
    record['status'] = 'passed'
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    record['exported_count'] = len(record['exported_files'])
    record['excluded_count'] = len(excluded)
    with receipt.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=record['status'], receipt=str(receipt),
        exported_count=record['exported_count'], excluded_count=len(excluded))), flush=True)
