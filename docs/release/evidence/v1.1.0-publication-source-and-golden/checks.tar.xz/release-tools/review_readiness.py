"""Review the eleven bounded readiness reports for the pinned 1.1.0 source CI."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

OUT = Path('/Users/dylan/LocalData/shardloom/release-v1.1.0')
SOURCE = '4d11d4e9c2349f0dc63dc27288b432a351c1a962'
RUN_ID = 41592354237
RUN_ATTEMPT = 2
PREVIOUS = Path('/Users/dylan/LocalData/shardloom/release-v1.0.0/release-100-ci-99d62ae3d101')

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-proof', type=Path, default=OUT / 'hosted-source-2-r1/report.json')
parser.add_argument('--output-attempt', type=int, default=1)
parser.add_argument('--review-attempt', type=int, default=1)
args = parser.parse_args()
assert args.review_attempt > 0
source_proof_path = args.source_proof.resolve()
source_proof = read(source_proof_path)
assert source_proof['status'] == 'passed' and source_proof['source_commit'] == SOURCE
assert source_proof['ci_run_id'] == RUN_ID and source_proof['requested_attempt'] == RUN_ATTEMPT
assert args.output_attempt > 0
REPORTS = OUT / f'readiness-ci-{SOURCE[:12]}-run{RUN_ID}-attempt{RUN_ATTEMPT}-r{args.output_attempt}'
retrieval = read(REPORTS / 'retrieval.json')
assert retrieval['source_commit'] == SOURCE and retrieval['ci_run'] == RUN_ID
assert retrieval['run_attempt'] == RUN_ATTEMPT
assert len(retrieval['reports']) == 11
data = {}
for row in retrieval['reports']:
    path = REPORTS / row['name']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    data[row['name']] = read(path)
assert len(data) == 11

dependency = data['dependency-audit-report.json']
assert all(dependency[k] == 'passed' for k in ('advisory_status', 'cargo_audit_status', 'cargo_deny_status', 'license_policy_status', 'pip_audit_status'))
assert dependency['release_gate'] and dependency['fallback_dependency_absent']
assert dependency['runtime_dependency_scope']['forbidden_runtime_dependencies'] == []
assert dependency['runtime_dependency_scope']['cargo_manifest_count'] == 7
assert dependency['runtime_dependency_scope']['python_runtime_dependency_count'] == 0
assert all(row['status'] == 'passed' and row['returncode'] == 0 for row in dependency['tool_results'])

dry = data['release-dry-run-transcript.json']
assert dry['proof_status'] == 'passed' and len(dry['steps']) == 13
assert all(row['returncode'] == 0 and not row.get('timed_out', False) for row in dry['steps'])
assert dry['clean_conda_env_install_status'] == 'skipped_by_request' and dry['clean_conda_env_install_required'] is False
assert dry['benchmark_smoke_status'] == 'skipped_not_required_for_package_release'
assert dry['benchmark_smoke_required_for_package_release'] is False
assert 'shardloom-1.1.0-' in dry['local_wheel']

security = data['release-security-gate-report.json']
governance = data['contribution-governance-report.json']
assert len(security['checks']) == 7 and all(x['status'] == 'passed' and not x['blockers'] for x in security['checks'].values())
assert len(governance['checks']) == 6 and all(x['status'] == 'passed' and not x['blockers'] for x in governance['checks'])
golden = data['golden-workflow-report.json']
assert golden['workflow_count'] == len(golden['workflows']) == 3
stages = [s for w in golden['workflows'] for s in w['stages']]
assert golden['stage_count'] == len(stages) == 9
assert all(s['status'] == 'passed' and s['returncode'] == 0 and not s['blockers'] for s in stages)
semantics = data['admitted-semantics-matrix-report.json']
assert semantics['stage_count'] == semantics['matrix_row_count'] == len(semantics['stages'])
assert semantics['v1_required_runtime_row_count'] == semantics['v1_expected_validator_case_count']
assert semantics['v1_missing_validator_case_count'] == semantics['v1_unexpected_required_runtime_row_count'] == 0
assert all(s['status'] == 'passed' and not s['blockers'] for s in semantics['stages'])
semantic_kind_counts = dict(sorted(Counter(s['kind'] for s in semantics['stages']).items()))
semantic_counts = {
    'stage_count': semantics['stage_count'],
    'v1_required_runtime_row_count': semantics['v1_required_runtime_row_count'],
    'v1_expected_validator_case_count': semantics['v1_expected_validator_case_count'],
    'deterministic_unsupported_row_count': semantics['deterministic_unsupported_row_count'],
    'stage_kind_counts': semantic_kind_counts,
}
architecture = data['release-architecture-tracker-report.json']
assert architecture['status'] == 'blocked' and architecture['unchecked_phase_plan_count'] > 0
assert architecture['missing_required_input_count'] == 0 and architecture['runtime_gap_family_burn_down_blocker_count'] == 0
package = data['package-channel-readiness-report.json']
assert package['status'] == 'passed' and package['ready_channel_count'] == 4 and package['expected_channel_count'] == 9
assert package['pypi_proof_ref'].endswith('pypi-v1.0.0-transcript.json') and package['testpypi_proof_ref'].endswith('testpypi-v1.0.0-transcript.json')
finished = data['finished-product-readiness-report.json']
assert finished['status'] == 'passed' and finished['public_release_ready'] is False
assert finished['local_product_report_count'] == len(finished['local_product_reports'])
assert all(s['status'] == 'passed' and not s['blockers'] for s in finished['local_product_reports'])
assert finished['public_release_claim_allowed'] is False and finished['require_public_release_ready'] is False

comparison = []
for name, field in (
    ('hard-release-readiness-gate.json', 'blockers'),
    ('finished-product-readiness-report.json', 'public_release_blockers'),
    ('final-release-rehearsal-report.json', 'blockers'),
    ('release-architecture-tracker-report.json', 'blockers'),
):
    previous_path = PREVIOUS / name
    previous = read(previous_path)
    current = data[name]
    normalize = lambda rows: [re.sub(r'phase plan has unchecked items: \d+', 'phase plan has unchecked items: COUNT', item) for item in rows]
    current_count = len(current[field])
    previous_count = len(previous[field])
    current_normalized = normalize(current[field])
    previous_normalized = normalize(previous[field])
    comparison.append(dict(name=name, field=field, current_count=current_count,
        prior_v1_0_0_count=previous_count,
        prior_report=str(previous_path), prior_sha256=sha(previous_path),
        normalized_blocker_lists_equal=current_normalized == previous_normalized,
        changed_blockers=[item for item in current_normalized if item not in previous_normalized],
        removed_blockers=[item for item in previous_normalized if item not in current_normalized],
        normalization='Only the numeric count in phase plan has unchecked items is normalized; ordering and other wording remain significant.'))

# Differences in the raw production/product blockers need a specific review.
# The currently selected 1.0.0 channel proofs cover their own artifacts.
repair_path = OUT / 'source-format-correction-r1/verification.json'
repair = read(repair_path)
assert repair['status'] == 'passed' and repair['release_source'] == SOURCE
assert repair['verifier_only_diff'] == ['python/tests/test_release_scripts.py','scripts/check_release_readiness.py']
assert repair['corrected_check']['status'] == 'passed' and repair['other_replay_checks_identical'] == 31
assert repair['original_check'] == repair['replayed_old_check'] and repair['production_gate_status'] == 'blocked'
hard_name = 'hard-release-readiness-gate.json'
finished_name = 'finished-product-readiness-report.json'
extra = repair['removed_original_blocker']
reported = data[hard_name]['blockers']
preserved = [b for b in reported if b != extra]
assert reported.count(extra) == 1 and normalize(preserved) == normalize(read(PREVIOUS/hard_name)['blockers'])
# The finished-product consumer takes only the first twenty blockers. Removal
# of the stale entry restores the original twentieth entry in that summary.
summary = lambda blockers: 'hard_release_readiness: blockers present: ' + '; '.join(blockers[:20])
current = data[finished_name]['public_release_blockers']
assert current.count(summary(reported)) == 1
assert normalize([summary(preserved) if b == summary(reported) else b for b in current]) == normalize(read(PREVIOUS/finished_name)['public_release_blockers'])
reviewed_additions = {hard_name:{extra:sha(repair_path)},
    finished_name:{normalize([summary(reported)])[0]:sha(repair_path)}}
unclassified = [(row['name'], blocker) for row in comparison
                for blocker in row['changed_blockers']
                if blocker not in reviewed_additions.get(row['name'], {})]
observations = []
for row in retrieval['reports']:
    value = data[row['name']]
    for flag in ('fallback_attempted', 'external_engine_invoked', 'publication_attempted'):
        if flag in value:
            assert value[flag] is False, (row['name'], flag)
    observations.append(dict(name=row['name'], sha256=row['sha256'],
        status=value.get('status', value.get('rehearsal_status')),
        proof_status=value.get('proof_status'), blockers=value.get('blockers')))
record = dict(status='requires_scope_review' if unclassified else 'reviewed_for_technical_preview',
    observed_at_utc=datetime.now(timezone.utc).isoformat(), source_commit=SOURCE, ci_run_id=RUN_ID,
    verified_readiness_reports=len(observations), source_ci_evidence_sha256=sha(source_proof_path),
    selected_published_version_at_source='1.0.0', publication_attempted=False,
    semantic_counts=semantic_counts, golden_stages=len(stages),
    architecture_unchecked=architecture['unchecked_phase_plan_count'],
    local_product_reports=finished['local_product_report_count'],
    public_release_ready=finished['public_release_ready'],
    retrieval_receipt_sha256=sha(REPORTS/'retrieval.json'),
    report_observations=observations, prior_blocker_comparison=comparison,
    reviewed_additions=reviewed_additions, unclassified_additions=unclassified,
    source_format_rollup_correction=repair, release_source_rollup_retained=True,
    driver_sha256=sha(Path(__file__)))
destination = OUT / f'release-110-report-review-{args.review_attempt}.json'
with destination.open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps({k:record[k] for k in ('status','source_commit','verified_readiness_reports','unclassified_additions')}))
raise SystemExit(1 if unclassified else 0)
