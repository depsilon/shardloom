"""Replay the captured CI source-format gate before and after its verifier correction."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent.parent
SOURCE='4d11d4e9c2349f0dc63dc27288b432a351c1a962'
FIX='a68bdd946cf0572b0ed2a5f40948893378ee4240'
W=Path('/Users/dylan/.codex/worktrees/native-release-110/shardloom-local-repo')
C=Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
ARCHIVE=OUT/'archive-source-110-1'
BASE=OUT/f'readiness-ci-{SOURCE[:12]}-run41592354237-attempt2-r3'
INPUTS=OUT/f'readiness-ci-{SOURCE[:12]}-run41592354237-attempt2-r4'
OLD='v1 SourceState/prepared-state format coverage must contain 7 formats'
NAME='v1_source_prepared_state_scope_gate'

def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def run(command,root):
    return subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=120,check=True)

p=argparse.ArgumentParser()
p.add_argument('--attempt',type=int,required=True)
args=p.parse_args()
dest=OUT/f'source-format-correction-r{args.attempt}'
dest.mkdir(exist_ok=False)
assert git(W,'rev-parse','HEAD')==SOURCE and git(C,'rev-parse','HEAD')==FIX
assert not git(C,'status','--porcelain') and not git(W,'status','--porcelain')
expected_files={'scripts/check_release_readiness.py','python/tests/test_release_scripts.py'}
assert set(git(C,'diff','--name-only',SOURCE,FIX).splitlines())==expected_files
assert git(C,'rev-parse','HEAD^')==SOURCE
retrieval=read(INPUTS/'retrieval.json'); archive=read(OUT/'archive-source-110-1.json')
assert retrieval['source_commit']==archive['source_commit']==SOURCE
assert archive['status']=='passed' and archive['version']=='shardloom 1.1.0'
assert retrieval['artifact_id']==13230219233
for row in retrieval['reports']:
    path=Path(row['member_name'])
    assert path.parts[:1]==('target',) and '..' not in path.parts and path.suffix=='.json'
    data=(INPUTS/row['name']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    target=ARCHIVE/path
    assert not target.is_symlink() and target.resolve().is_relative_to(ARCHIVE.resolve())
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==data
    else:
        with target.open('xb') as stream:stream.write(data)
formats=ARCHIVE/'target/v1-source-prepared-state-scope-report.json'
submitted=read(formats)
assert submitted['status']=='passed' and submitted['all_no_fallback_no_external_engine']
assert submitted['supported_input_formats']==['csv','tsv','json','jsonl','parquet','arrow-ipc','avro','orc']
actual=read(BASE/'hard-release-readiness-gate.json')
actual_gates={r['name']:r for r in actual['checks']}
raw=[]
for label,checkout in [('release',W),('corrected',C)]:
    path=dest/(label+'.json')
    run([sys.executable,'-B',checkout/'scripts/check_release_readiness.py',
      '--repo-root',ARCHIVE,'--allow-blocked','--output',path],checkout)
    raw.append(read(path))
before,after=raw
g1,g2=({r['name']:r for r in x['checks']} for x in raw)
assert set(g1)==set(g2)==set(actual_gates)
assert g1[NAME]==actual_gates[NAME] and g1[NAME]['blockers']==[OLD] and g1[NAME]['status']=='blocked'
assert g2[NAME]['status']=='passed' and g2[NAME]['blockers']==[]
assert [name for name in g1 if g1[name]!=g2[name]]==[NAME]
blocker=NAME+': '+OLD
assert before['blockers'].count(blocker)==1 and after['blockers']==[x for x in before['blockers'] if x!=blocker]
assert before['status']==after['status']==actual['status']=='blocked'
patch=subprocess.check_output(['git','diff','--binary',SOURCE,FIX],cwd=C)
(dest/'verifier.patch').write_bytes(patch)
result=dict(status='passed',release_source=SOURCE,verifier_commit=FIX,
    verifier_only_diff=sorted(expected_files),patch_sha256=hashlib.sha256(patch).hexdigest(),
    source_ci_report_sha256=sha(formats),formats=submitted['supported_input_formats'],
    original_rollup_sha256=sha(BASE/'hard-release-readiness-gate.json'),
    before=sha(dest/'release.json'),after=sha(dest/'corrected.json'),
    original_check=actual_gates[NAME],replayed_old_check=g1[NAME],corrected_check=g2[NAME],
    other_replay_checks_identical=len(g1)-1,local_vs_hosted_unrelated_check_differences=[
        n for n in g1 if g1[n]!=actual_gates[n]],production_gate_status=after['status'],
    source_artifact_id=retrieval['artifact_id'],input_report_count=len(retrieval['reports']),
    removed_original_blocker=blocker,publication_attempted=False)
(dest/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
