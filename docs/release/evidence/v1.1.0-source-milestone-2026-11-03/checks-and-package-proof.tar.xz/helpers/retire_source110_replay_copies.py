"""Retire only the two verified temporary copies used by the relocation checks."""
import hashlib
import json
from pathlib import Path

from retire_adaptive_decisions_payloads import closed, identity, verify

OUT = Path(__file__).resolve().parents[1]
REPO = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
PACKET = REPO / 'docs/benchmarks/evidence/native-local-io-portable-2026-11-03'
ROOTS = [OUT.parent / ('local-io-portable-isolation-2026-11-03' + suffix) / 'packet'
         for suffix in ('', '-r2')]
PLAN = OUT / 'source110-isolation-retirement-plan.json'
RESULT = OUT / 'source110-isolation-retirement.json'
assert not PLAN.exists() and not RESULT.exists()
proof = json.loads((PACKET / 'acceptance.json').read_text())
assert proof['status'] == proof['replay']['status'] == 'passed'
assert proof['isolation']['replay_original_reads'] == proof['isolation']['replay_external_effect_attempts'] == 0
expected = proof['collection_files']
assert len(expected) == 33 and expected['manifest.json']['sha256'] == proof['replay']['collection_sha256']
retained = [verify(PACKET / relative, row) for relative, row in expected.items()]
copies, directories = [], []
for root in ROOTS:
    assert root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink()
    entries = list(root.rglob('*'))
    assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in entries)
    files = {path.relative_to(root).as_posix() for path in entries if path.is_file()}
    assert files == expected.keys()
    copies.extend(verify(root / name, expected[name]) for name in sorted(files))
    directories.extend([root, *(path for path in entries if path.is_dir())])
closed(ROOTS, [root / 'manifest.json' for root in ROOTS])
plan = dict(status='declared_before_retirement', copies=copies, retained=retained,
    scope='Two temporary isolation packet copies only. Complete original bytes retained in committed collection.',
    acceptance=identity(PACKET / 'acceptance.json'))
PLAN.write_text(json.dumps(plan, indent=2) + '\n')
for row in [*copies, *retained, plan['acceptance']]:
    assert identity(Path(row['path'])) == row
closed(ROOTS, [root / 'manifest.json' for root in ROOTS])
for row in copies:
    path = Path(row['path'])
    assert identity(path) == row
    path.unlink()
for path in sorted(directories, key=lambda p: len(p.parts), reverse=True):
    path.rmdir()
assert all(not root.exists() for root in ROOTS)
for row in retained:
    assert identity(Path(row['path'])) == row
result = dict(status='passed', retired_files=len(copies), retired_bytes=sum(row['stat']['st_size'] for row in copies),
    retained_collection_files=len(retained), plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(),
    repeated_identity_checks=True, closed_handles=True, no_payload_backup=True, engine_queries=0)
RESULT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
