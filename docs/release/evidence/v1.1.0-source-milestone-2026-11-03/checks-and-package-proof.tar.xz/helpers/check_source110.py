"""Check the source milestone's synchronized versions and generated public surface."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1] / 'source110-checks-r1'
OUT.mkdir(exist_ok=False)
PY = sys.executable
checks = [
    [PY, '-B', 'scripts/sync_workspace_package_versions.py', '--check'],
    [PY, '-B', 'scripts/check_workspace_version_sources.py', '--output', str(OUT / 'versions.json')],
    [PY, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_release_scripts.py', '-k', 'workspace_version_source', '-v'],
    [PY, '-B', 'scripts/write_public_api_reference.py', '--check'],
    [PY, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v'],
    [PY, '-B', 'scripts/write_v1_supported_unsupported_docs.py', '--check'],
    [PY, '-B', 'scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status.json')],
    [PY, '-B', 'scripts/check_website_readiness.py', '--output', str(OUT / 'website-readiness.json')],
    ['node', 'scripts/validate_static_assets.cjs'],
    [PY, '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py', '-v'],
    ['cargo', 'fmt', '--all', '--', '--check'],
]
results = []
for i, command in enumerate(checks):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=240)
    data = (result.stdout + result.stderr).encode()
    log = OUT / f'check-{i:02d}.log'
    log.write_bytes(data)
    row = dict(command=command, returncode=result.returncode, log=log.name,
               bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    results.append(row)
    print(json.dumps(row), flush=True)
    if result.returncode:
        print(data.decode()[-6000:], flush=True)
report = dict(status='passed' if all(row['returncode'] == 0 for row in results) else 'failed',
    checks=results, source_version='1.1.0', published_version='1.0.0', publication_attempted=False,
    preliminary_generator_failure=dict(command=['python3', '-B', 'scripts/write_public_api_reference.py'],
        returncode=1, reason='unqualified Python resolved to macOS Python 3.9; dataclass slots requires the supported Python version',
        correction='regenerated with the retained Python 3.13 environment before these checks',
        engine_queries=0))
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(report['status'] != 'passed')
