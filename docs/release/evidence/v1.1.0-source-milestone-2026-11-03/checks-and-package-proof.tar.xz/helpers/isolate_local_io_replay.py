"""Relocate the historical packet, then deny original evidence reads and effects."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import shutil
import sys

ARTIFACT = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31')
REPO = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
ORIGINAL_SOURCE = Path('/Users/dylan/.codex/worktrees/native-direct-source-count/shardloom-local-repo')
DESTINATION = Path('/Users/dylan/LocalData/shardloom/local-io-portable-isolation-2026-11-03-r2')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--verify-existing-copy', action='store_true')
args = parser.parse_args()
if args.verify_existing_copy:
    report_path = DESTINATION / 'per-observation-acceptance.json'
    if report_path.exists() or not (DESTINATION / 'acceptance.json').is_file():
        raise ValueError('require the accepted relocated packet and a new report path')
else:
    if DESTINATION.exists():
        raise ValueError('preserve the prior isolation attempt')
    DESTINATION.mkdir()
    shutil.copytree(ARTIFACT / 'portable-local-io-r1', DESTINATION / 'packet')
    report_path = DESTINATION / 'acceptance.json'
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'benchmarks/traditional_analytics'),
               str(ARTIFACT / 'oracle-python')]
import pyarrow
import pyarrow.compute
import pyarrow.parquet
import pyarrow.orc
import fastavro
import cramjam
from local_io_portable_replay import Collection, verify

denied = []
forbidden = (str(ARTIFACT), str(ORIGINAL_SOURCE))


def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn',
                 'socket.connect', 'socket.connect_ex', 'socket.bind'}:
        denied.append(event)
        raise PermissionError('effects denied during saved-evidence replay')
    if event in {'open', 'os.listdir', 'os.scandir'} and args and isinstance(args[0], (str, bytes, os.PathLike)):
        path = os.path.abspath(os.fsdecode(args[0]))
        if any(path == prefix or path.startswith(prefix + os.sep) for prefix in forbidden):
            denied.append(event + ':' + path)
            raise PermissionError('original evidence paths denied during replay')


sys.addaudithook(audit)
for path in (ARTIFACT / 'local-io-r17/manifest.json', ORIGINAL_SOURCE / 'Cargo.toml'):
    try:
        path.read_bytes()
    except PermissionError:
        pass
    else:
        raise AssertionError('original-path access control did not reject a read')
control_denials = list(denied)
progress = lambda message: print(message, file=sys.stderr, flush=True)
report = verify(Collection(DESTINATION / 'packet', progress), progress)
assert denied == control_denials, 'replay attempted original artifact access or an external effect'
result = dict(status='passed', replay=report, original_read_controls=control_denials,
    replay_original_reads=0, replay_external_effect_attempts=0,
    isolation='relocated packet; Python audit hook rejects original evidence/source reads and process/network effects after reader imports',
    dependencies=dict(pyarrow=pyarrow.__version__, fastavro=fastavro.__version__, cramjam=cramjam.__version__),
    source_files={})
for path in sorted(REPO.joinpath('scripts').glob('*local_io*.py')):
    data = path.read_bytes()
    result['source_files'][str(path)] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
with report_path.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key not in {'replay', 'source_files'}}, indent=2))
