"""Bind the local 1.1.0 package, source, verification and retirement records."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import tomllib

OUT = Path(__file__).resolve().parents[1]
REPO = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
RUNTIME = OUT / 'source110-runtime-r1'
PACKAGE = OUT / 'installed-wheel-source110-r1'
DEST = REPO / 'docs/release/evidence/v1.1.0-source-milestone-2026-11-03'
ISOLATION = OUT.parent / 'local-io-portable-isolation-2026-11-03-r2/per-observation-acceptance.json'
assert not DEST.exists()


def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


files, gates = {}, {}
names = ('io785-local-io-replay-acceptance', 'io786-source110-site-build', 'io787-source110-site-types',
         'io788-source110-static-checks', 'io789-source110-ci-contract', 'io790-source110-release-build',
         'io791-source110-runtime-freeze', 'io792-source110-installed-wheel',
         'io793-every-output-report-controls', 'io794-every-output-report-isolation',
         'io795-source110-isolation-copy-retirement', 'io796-source110-workspace-clippy',
         'io797-source110-workspace-tests')
for name in names:
    receipt = read(OUT / (name + '.json'))
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
    log = (OUT / (name + '.log')).read_bytes()
    assert identity(log)['sha256'] == receipt['log_sha256']
    files[name + '.json'] = (OUT / (name + '.json')).read_bytes()
    files[name + '.log'] = log
    gates[name] = dict(command=receipt['command'], status=receipt['status'],
                       returncode=receipt['returncode'], log=identity(log))

runtime = read(RUNTIME / 'manifest.json')
build = read(OUT / runtime['build_receipt'])
assert runtime['version'] == '1.1.0' and runtime['profile'] == 'release'
assert runtime['features'] == ['release-user-surfaces']
assert build['head'] == runtime['source_revision'] and not build['changed_source_inventory']
assert build['working_tree'] == '' and runtime['source_overlay']['bytes'] == 0
assert identity((OUT / runtime['build_receipt']).read_bytes())['sha256'] == runtime['build_receipt_sha256']
for name, observed in runtime['files'].items():
    assert identity((RUNTIME / name).read_bytes()) == observed
changed_proof_files = sorted(name for name, item in runtime['source_snapshot'].items()
                             if identity((REPO / name).read_bytes()) != item)
assert changed_proof_files == ['scripts/local_io_portable_replay.py', 'scripts/test_local_io_packet.py']
files['runtime/manifest.json'] = (RUNTIME / 'manifest.json').read_bytes()

package = read(PACKAGE / 'report.json')
assert package['status'] == package['uninstall_status'] == 'passed' and not package['publication_attempted']
assert package['installed_load']['version'] == '1.1.0' and package['installed_load']['isolated_install']
assert package['integration'] == dict(tests=303, failures=0, errors=0, skipped=0, status='passed')
for field, name in (('cli_sha256', 'shardloom'), ('native_library_sha256', '_native.abi3.so')):
    assert package['stage'][field] == package['integrity'][field] == runtime['files'][name]['sha256']
wheel = PACKAGE / 'dist' / package['integrity']['wheel']
wheel_identity = identity(wheel.read_bytes())
assert wheel_identity == dict(bytes=package['integrity']['wheel_bytes'], sha256=package['integrity']['wheel_sha256'])
files['package/report.json'] = (PACKAGE / 'report.json').read_bytes()
for step in package['steps']:
    data = (PACKAGE / step['log']).read_bytes()
    assert step['returncode'] == 0 and identity(data)['sha256'] == step['log_sha256']
    files['package/' + step['log']] = data

checks = OUT / 'source110-checks-r1'
static = read(checks / 'report.json')
assert static['status'] == 'passed' and len(static['checks']) == 11
for path in checks.iterdir():
    assert path.is_file() and not path.is_symlink()
    files['source-checks/' + path.name] = path.read_bytes()
for row in static['checks']:
    assert row['returncode'] == 0 and identity(files['source-checks/' + row['log']]) == {
        key: row[key] for key in ('bytes', 'sha256')}
assert read(checks / 'versions.json')['workspace_package_version'] == '1.1.0'
assert read(checks / 'ci-gate-matrix.json')['status'] == 'passed'
old_lock = tomllib.loads(git('show', 'dcbe2cc2:Cargo.lock').decode())
new_lock = tomllib.loads((REPO / 'Cargo.lock').read_text())
members = {row['name'] for row in json.loads(subprocess.check_output(['cargo', 'metadata', '--locked',
        '--offline', '--no-deps', '--format-version', '1'], cwd=REPO))['packages']}
assert len(members) == 7
for row in old_lock['package']:
    if row['name'] in members and 'source' not in row:
        assert row['version'] == '1.0.0'
        row['version'] = '1.1.0'
assert old_lock == new_lock, 'only workspace package versions may change in the lockfile'

isolation = read(ISOLATION)
previous = read(OUT / 'local-io-portable-replay-r3.json')
assert isolation['status'] == 'passed' and isolation['replay'] == previous and previous['observations'] == 9633
assert isolation['replay_original_reads'] == isolation['replay_external_effect_attempts'] == 0
files['io/per-observation-acceptance.json'] = ISOLATION.read_bytes()
for name in ('source110-isolation-retirement.json', 'source110-isolation-retirement-plan.json'):
    files['retirement/' + name] = (OUT / name).read_bytes()
for name in ('check_source110.py', 'freeze_source110_runtime.py', 'record_source110_acceptance.py',
             'isolate_local_io_replay.py', 'retire_source110_replay_copies.py'):
    files['helpers/' + name] = (OUT / 'tools' / name).read_bytes()
tests = files['io797-source110-workspace-tests.log'].decode()
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', tests)
assert counts and all(int(failed) == 0 for _, failed, _ in counts)
test_count = sum(int(passed) for passed, _, _ in counts)
assert test_count >= 3318

DEST.mkdir()
archive_path = DEST / 'checks-and-package-proof.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for name, data in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.mode, member.size, member.mtime = 0o644, len(data), 0
        archive.addfile(member, io.BytesIO(data))
with tarfile.open(archive_path, 'r:xz') as archive:
    members_read = archive.getmembers()
    assert len(members_read) == len(files) and {m.name for m in members_read} == set(files)
    assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in members_read)
result = dict(schema_version='shardloom.source_milestone_acceptance.v1', status='local_acceptance_passed',
    source_version='1.1.0', published_channel_version='1.0.0', publication_attempted=False,
    runtime_source=runtime['source_revision'], runtime_files=runtime['files'],
    frozen_source_files=len(runtime['source_snapshot']), verification_only_files_after_build=changed_proof_files,
    workspace_members=sorted(members), third_party_lock_entries_unchanged=True,
    wheel=dict(filename=wheel.name, **wheel_identity), installed=package['integration'],
    installed_version=package['installed_load']['version'], uninstall=package['uninstall_status'],
    workspace_tests=dict(passed=test_count, failed=0, ignored=sum(int(n) for _, _, n in counts)),
    static_checks=len(static['checks']), gates=gates,
    portable_replay=dict(pre_bump_source_commit=git('rev-parse', 'dcbe2cc2').decode().strip(),
        verifier_commit=git('rev-parse', '79a4cc84').decode().strip(), tests=17, failures=0, skipped=0,
        observations=previous['observations'], output_readbacks=previous['output_readbacks'],
        report_equal_to_original_replay=True, relocated=True, original_evidence_reads=0,
        collection_sha256=previous['collection_sha256']),
    duplicate_packet_retirement=read(OUT / 'source110-isolation-retirement.json'),
    archive=dict(path=archive_path.name, **identity(archive_path.read_bytes()), members=len(files),
                 complete_member_readback=True),
    new_benchmark_observations=0, hosted_acceptance='separate_gate',
    scope='Local macOS ARM64 build, installation and native integration tests for the source milestone.')
(DEST / 'acceptance.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('status','source_version','runtime_source','wheel',
    'installed','workspace_tests','portable_replay','archive')}, indent=2))
