"""Refresh the exact reviewed cold-file provider changes after verifying all other members."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
W = Path(__file__).resolve().parent.parent
OUTPUT = W / 'provenance-refresh-r3.json'
SELECTED = {
    'vortex-array': {'README.shardloom.md', 'src/dtype/struct_.rs', 'src/dtype/struct_memory_tests.rs',
                     'src/scalar_fn/fns/get_item.rs', 'src/scalar_fn/fns/select.rs'},
    'vortex-file': {'README.shardloom.md', 'src/footer/file_statistics.rs',
                    'src/footer/file_statistics_storage.rs'},
    'vortex-layout': {'README.shardloom.md', 'src/layouts/struct_/mod.rs',
                      'src/layouts/struct_/reader.rs'},
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

assert not OUTPUT.exists()
prepared = {}
for crate, selected in SELECTED.items():
    provider = ROOT / 'vendor' / crate
    path = provider / 'upstream-provenance.json'
    before = path.read_bytes()
    provenance = json.loads(before)
    expected = dict(provenance['original_files_sha256'])
    for omitted in provenance.get('omitted_files', {}):
        expected.pop(omitted, None)
    expected.update(provenance['modified_files_sha256'])
    expected.update(provenance['added_files_sha256'])
    for name, digest in expected.items():
        if name not in selected:
            assert sha((provider / name).read_bytes()) == digest, (crate, name)
    for name in sorted(selected):
        target = 'modified_files_sha256' if name in provenance['original_files_sha256'] else 'added_files_sha256'
        provenance[target][name] = sha((provider / name).read_bytes())
    for target in ('modified_files_sha256', 'added_files_sha256'):
        provenance[target] = dict(sorted(provenance[target].items()))
    provenance['local_changes_documentation']['sha256'] = sha((provider / 'README.shardloom.md').read_bytes())
    prepared[crate] = (path, before, provenance)

manifest_path = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
manifest_before = manifest_path.read_bytes()
manifest = json.loads(manifest_before)
for crate, (_, _, provenance) in prepared.items():
    components = [row for row in manifest['vendored_components'] if row['path'] == 'vendor/' + crate]
    assert len(components) == 1
    components[0]['provenance'] = provenance

report = {'status': 'passed', 'providers': {}, 'manifest_before': sha(manifest_before)}
for crate, (path, before, provenance) in prepared.items():
    assert path.read_bytes() == before
    path.write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + '\n')
    report['providers'][crate] = {'before': sha(before), 'after': sha(path.read_bytes()),
        'selected_files': {name: sha((path.parent / name).read_bytes()) for name in sorted(SELECTED[crate])}}
assert manifest_path.read_bytes() == manifest_before
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
report['manifest_after'] = sha(manifest_path.read_bytes())
OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
