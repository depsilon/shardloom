"""Freeze independent formula values before the public candidate lifecycle runs."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'python/tests')]
from wide_schema_fixture import KINDS, digest, joined_rows, row

def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

destination = OUT / 'preparation/frozen-public-fixture-r1.json'
assert not destination.exists()
cases = {}
for kind in KINDS:
    inputs = [row(kind, ordinal) for ordinal in range(1, 9)]
    expected = joined_rows(kind)
    cases[kind] = {'input_rows': 8, 'input_digest': digest(inputs),
                   'joined_rows': len(expected), 'joined_digest': digest(expected)}
spill = joined_rows('siblings', 257)
report = {
    'schema_version': 'shardloom.wide_schema_fixture.v1',
    'fixture_source': identity(ROOT / 'python/tests/wide_schema_fixture.py'),
    'contract_source': identity(ROOT / 'docs/architecture/native-wide-schema-2026-11-09.md'),
    'memory_bytes': 512 << 20,
    'cases': cases,
    'spill': {'kind': 'siblings', 'input_rows': 257, 'buffer_bytes': 1 << 20,
              'quota_bytes': 64 << 20, 'joined_rows': len(spill), 'joined_digest': digest(spill)},
    'baseline_or_candidate_execution': False,
}
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
