"""Record cold-file low-grant outcomes; panic is never an admitted denial."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from test_native_binding import _load_native
from wide_schema_fixture import digest, row, schema


def child(path, grant):
    _load_native()
    import shardloom as sl
    try:
        with sl.context(transport='native', memory_bytes=grant, max_parallelism=1) as context:
            result = context.read_vortex(path).collect(check=True)
            values = result.to_arrow().to_pylist()
            assert digest(values) == digest([row('siblings', 1), row('siblings', 2)])
            assert not result.envelope.field_bool('fallback_attempted')
            assert not result.envelope.field_bool('external_engine_invoked')
        return dict(grant=grant, status='values_passed')
    except BaseException as error:
        # Diagnostic only: preserve the actual exception and stderr. The parent
        # refuses all Rust/PyO3 panics; this does not turn exceptions into passes.
        return dict(grant=grant, status='exception', exception=type(error).__module__ + '.' + type(error).__name__,
                    error=str(error))


if sys.argv[1:2] == ['--child']:
    print(json.dumps(child(sys.argv[2], int(sys.argv[3])), sort_keys=True))
else:
    _load_native()
    import shardloom as sl
    output = Path(sys.argv[1])
    output.mkdir()
    with tempfile.TemporaryDirectory(prefix='cold-wide-', dir=output) as temporary:
        path = Path(temporary) / 'siblings.vortex'
        with sl.context(transport='native', memory_bytes=512 << 20, max_parallelism=1) as context:
            context.from_rows([row('siblings', 1), row('siblings', 2)], schema=schema('siblings')).write_vortex(path, check=True)
        observations = []
        for kib in (128, 256, 512, 1024, 2048, 4096, 8192):
            result = subprocess.run([sys.executable, '-B', str(Path(__file__).resolve()), '--child', str(path), str(kib << 10)],
                                    env=os.environ.copy(), capture_output=True, text=True, timeout=60, check=False)
            observation = dict(grant=kib << 10, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
            observations.append(observation)
            print(json.dumps(observation, sort_keys=True), flush=True)
        (output / 'observations.json').write_text(json.dumps(observations, indent=2) + '\n')
        assert all(item['returncode'] == 0 for item in observations), 'a diagnostic subprocess failed'
        assert all('PanicException' not in item['stdout'] and 'panicked at' not in item['stderr'] for item in observations), 'cold wide-file admission panicked'
