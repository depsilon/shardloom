"""Exercise the schema, ownership, cancellation and replay regression boundaries."""
import subprocess

filters = [
    'native_payload_schema::',
    'native_payload::storage_tests::',
    'ordered_aggregate_record_metadata_follows_required_ordinal_without_copying_payload',
    'native_nested_keys_schema_and_memory_are_admitted_before_provider_execution',
    'replay_capture_keeps_nullable_fragments_large_controls_and_pressure_declines',
    'native_nested_json_cancellation',
]
for selected in filters:
    command = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
               '--features', 'release-user-surfaces', '--lib', selected,
               '--', '--test-threads=2']
    print('Checking ' + selected, flush=True)
    subprocess.run(command, check=True, timeout=900)
