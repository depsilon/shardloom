"""Bound wide-schema task-owned build and test processes outside synced storage."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
PRIOR_CLOSEOUT = Path('/Users/dylan/LocalData/shardloom/vector-expressions-2026-11-08/vector-closeout-r1.json')
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, accounted_bytes, available_bytes, check_budgets, require_local_path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--timeout', type=float, default=2400)
parser.add_argument('--query-workload', action='store_true',
                    help='Keep full evidence/cache inventories before/after queries; active output and free-space guards remain.')
parser.add_argument('--allow-lockfile-update', action='store_true',
                    help='Preparation mode: permit only root Cargo.lock content to change; this is not fixed-source validation.')
parser.add_argument('--preparation', action='store_true',
                    help='Label dependency/fixture preparation without relaxing repository source checks.')
parser.add_argument('--active-output', type=Path,
                    help='Required with --query-workload: only this active output subtree is inventoried during queries.')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum() and args.timeout > 0
if args.query_workload != (args.active_output is not None):
    parser.error('--query-workload and --active-output must be supplied together')
if args.active_output is not None:
    args.active_output = args.active_output.resolve()
    if args.active_output == OUT or not args.active_output.is_relative_to(OUT):
        parser.error('--active-output must be a strict descendant of this task output directory')
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
for path in (OUT, CACHE):
    require_local_path(path, Path.home(), sys.platform)
helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
env = dict(os.environ,
    PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/dylan/.cargo/bin:/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    PYTHONPATH='python/src:scripts', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never')
prior_raw = PRIOR_CLOSEOUT.read_bytes()
prior = json.loads(prior_raw)
assert prior['status'] == 'complete'
assert prior['pr_checks_passed'] == 58 and prior['main_checks_passed'] == 55
retirement = PRIOR_CLOSEOUT.parent / 'vector-retirement-r2'
retirement_plan = json.loads((retirement / 'plan.json').read_bytes())
retirement_raw = (retirement / 'manifest.json.xz').read_bytes()
assert hashlib.sha256(retirement_raw).hexdigest() == retirement_plan['manifest_sha256']
input_generations = json.loads(lzma.decompress(retirement_raw))['input_generations']
assert input_generations

def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink]

retained_generations = {}
for name, expected in prior['retained_runtime_and_wheel'].items():
    path = Path(name)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        actual = {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    assert actual == expected, 'accepted runtime/wheel changed: ' + name
    retained_generations[name] = generation(path)
assert {name: generation(Path(name)) for name in input_generations} == input_generations
base = prior['merge_commit']
assert len(base) == 40 and all(char in '0123456789abcdef' for char in base)
subprocess.run(['git', 'merge-base', '--is-ancestor', base, 'HEAD'], cwd=ROOT,
               check=True, timeout=30)
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
    '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
assert metadata['target_directory'] == str(CACHE)
workload = WorkloadGuard()
workload.check()
changed = set()
# Include incorporated proposal commits as well as later working-tree changes.
for argv in (['git', 'diff', '--no-renames', '--name-only', '-z', base],
             ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    changed.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0') if path)
source_inventory = {}
for relative in sorted(changed):
    path = ROOT / relative
    if path.is_symlink():
        source_inventory[relative] = {'symlink': os.readlink(path)}
    elif path.is_file():
        source_inventory[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                      'bytes': path.stat().st_size}
        snapshot = OUT / 'source-blobs' / source_inventory[relative]['sha256']
        snapshot.parent.mkdir(exist_ok=True)
        if not snapshot.exists():
            shutil.copyfile(path, snapshot)
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == source_inventory[relative]['sha256']
    else:
        source_inventory[relative] = {'absent': True}
BUILD_INPUT_EXCLUSIONS = ('docs/benchmarks/evidence/', 'docs/release/evidence/',
                          'docs/dependencies/evidence/')

def included_build_input(relative):
    parts = Path(relative).parts
    if relative.startswith(('.git/', *BUILD_INPUT_EXCLUSIONS)) or '.git' in parts:
        return False
    return True

def capture_build_sources(snapshot=False):
    paths = set()
    for argv in (['git', 'ls-files', '--cached', '-z'],
                 ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0')
                     if path and included_build_input(path))
    inventory = {}
    for relative in sorted(paths):
        path = ROOT / relative
        if path.is_symlink():
            target = os.readlink(path)
            inventory[relative] = {'symlink': target,
                                   'sha256': hashlib.sha256(os.fsencode(target)).hexdigest()}
        elif path.is_file():
            raw = path.read_bytes()
            item = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
            inventory[relative] = item
            if snapshot:
                blob = OUT / 'source-blobs' / item['sha256']
                blob.parent.mkdir(parents=True, exist_ok=True)
                if not blob.exists():
                    blob.write_bytes(raw)
                assert blob.read_bytes() == raw
        elif not path.exists():
            inventory[relative] = {'absent': True}
        else:
            inventory[relative] = {'other_mode': path.lstat().st_mode}
    return inventory

def inventory_fingerprint(inventory):
    encoded = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(encoded).hexdigest()

build_sources = capture_build_sources(snapshot=True)
build_source_fingerprint = inventory_fingerprint(build_sources)
root_lock_before = build_sources.get('Cargo.lock')
assert root_lock_before and 'sha256' in root_lock_before and 'symlink' not in root_lock_before
tool_sources = {}
tool_paths = [helper, Path(sys.modules[WorkloadGuard.__module__].__file__),
              Path(sys.modules['local_uat_storage'].__file__)]
for argument in command:
    if argument.endswith('.py'):
        path = Path(argument)
        path = path if path.is_absolute() else ROOT / path
        if path.is_file():
            tool_paths.append(path)
for path in tool_paths:
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    item = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    tool_sources[str(path)] = item
    snapshot = OUT / 'source-blobs' / item['sha256']
    if not snapshot.exists():
        snapshot.write_bytes(raw)
    assert snapshot.read_bytes() == raw
record = {'status': 'running', 'command': command, 'cwd': str(ROOT),
    'prior_retained_runtime_and_wheel': prior['retained_runtime_and_wheel'],
    'retained_generations': retained_generations, 'input_generations': input_generations,
    'base': base, 'prior_closeout_sha256': hashlib.sha256(prior_raw).hexdigest(),
    'query_workload': args.query_workload,
    'build_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'evidence_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'active_output': str(args.active_output) if args.active_output else None,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'changed_source_inventory': source_inventory,
    'build_sources': build_sources,
    'build_source_fingerprint_sha256': build_source_fingerprint,
    'build_source_path_count': len(build_sources),
    'build_source_scope_exclusions': [*BUILD_INPUT_EXCLUSIONS, '.git/**',
        'generated output paths ignored by git'],
    'allow_lockfile_update': args.allow_lockfile_update,
    'source_validation_mode': ('preparation_allow_root_cargo_lock_update' if args.allow_lockfile_update
                               else 'preparation_no_source_changes' if args.preparation
                               else 'fixed_source_validation'),
    'fixed_source_validation': not (args.allow_lockfile_update or args.preparation),
    'root_cargo_lock_hashes': {'path': 'Cargo.lock', 'allowed_to_change': args.allow_lockfile_update,
        'before_sha256': root_lock_before['sha256'], 'before_bytes': root_lock_before['bytes'],
        'after_sha256': root_lock_before['sha256'], 'after_bytes': root_lock_before['bytes'],
        'changed': False},
    'build_source_verification': {},
    'tool_source_inventory': tool_sources,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'environment': {key: env.get(key) for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CLIPPY_CONF_DIR', 'SHARDLOOM_PIP_AUDIT_PYTHON')},
    'supervisor_sha256': hashlib.sha256(helper.read_bytes()).hexdigest()}

def verify_build_sources(phase):
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    current = capture_build_sources(snapshot=phase == 'post_execution')
    fingerprint = inventory_fingerprint(current)
    path_set_matches = set(current) == set(build_sources)
    changed = []
    for relative in sorted(set(current) | set(build_sources)):
        before = build_sources.get(relative)
        after = current.get(relative)
        if relative == 'Cargo.lock' and args.allow_lockfile_update and phase == 'post_execution':
            if not (before and after and 'sha256' in before and 'sha256' in after
                    and 'symlink' not in before and 'symlink' not in after):
                changed.append(relative)
        elif before != after:
            changed.append(relative)
    lock_after = current.get('Cargo.lock')
    if lock_after and 'sha256' in lock_after:
        record['root_cargo_lock_hashes'].update(after_sha256=lock_after['sha256'],
                                               after_bytes=lock_after['bytes'],
                                               changed=lock_after['sha256'] != root_lock_before['sha256'])
    result = {'head': current_head, 'head_matches': current_head == record['head'],
        'path_set_matches': path_set_matches, 'path_count': len(current),
        'fingerprint_sha256': fingerprint, 'changed_paths': changed}
    record['build_source_verification'][phase] = result
    assert result['head_matches'], 'HEAD changed during guarded execution'
    assert path_set_matches, 'build input path set changed during guarded execution'
    assert not changed, 'build input changed during guarded execution: ' + ', '.join(changed)

driver_snapshot = OUT / 'source-blobs' / record['driver_sha256']
if not driver_snapshot.exists():
    shutil.copyfile(Path(__file__), driver_snapshot)
receipt = OUT / f'{args.name}.json'
assert not receipt.exists()
log = OUT / f'{args.name}.log'
last_storage = None

def guard(force_build=False):
    global last_storage
    assert PRIOR_CLOSEOUT.read_bytes() == prior_raw
    assert {name: generation(Path(name)) for name in retained_generations} == retained_generations
    if force_build:
        assert {name: generation(Path(name)) for name in input_generations} == input_generations
        verify_build_sources('post_execution')
        for name, item in tool_sources.items():
            raw = Path(name).read_bytes()
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    workload.check(record.get('pid'))
    assert available_bytes(CACHE) >= 12 * GIB, 'minimum free storage reached'
    if not force_build and last_storage is not None and time.monotonic() - last_storage < 30:
        return
    observations = {}
    paths = (('output', OUT), ('cargo', CACHE))
    if args.query_workload and record.get('pid') and not force_build:
        paths = (('active_output', args.active_output),)
    for label, path in paths:
        budget = record['active_output_workspace_budget_bytes'] if label == 'active_output' else 100 * GIB
        observations[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=budget, max_log_bytes=192 * MIB)
    if args.query_workload and not record.get('pid'):
        # The inactive evidence tree is fixed while the isolated query job runs.
        # Subtract it once so narrowing the active scan never raises the total cap.
        inactive = observations['output']['workspace_bytes'] - accounted_bytes(args.active_output)
        assert inactive >= 0
        record['inactive_output_bytes'] = inactive
        record['active_output_workspace_budget_bytes'] = 100 * GIB - inactive
    record['storage_last_observation'] = observations
    record.setdefault('storage_inventory_scopes', []).append(dict(
        scopes=list(observations), child_started=bool(record.get('pid')), forced=force_build))
    last_storage = time.monotonic()

try:
    verify_build_sources('pre_execution')
    guard()
    with log.open('xb') as stream:
        code = supervisor.run(command, cwd=ROOT, env=env, output=stream,
            timeout=args.timeout, evidence=record, guard=guard, max_output_bytes=8 << 20)
    record['status'] = 'passed' if code == 0 else 'failed'
    guard(force_build=True)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    if log.exists():
        record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'returncode', 'seconds', 'process_group_drained', 'error')}), flush=True)
    print(str(receipt), flush=True)
raise SystemExit(code)
