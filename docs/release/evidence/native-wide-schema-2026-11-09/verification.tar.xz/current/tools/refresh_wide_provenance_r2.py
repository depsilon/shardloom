"""Refresh only the reviewed local schema-provider patch and packaged provenance."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
W = Path(__file__).resolve().parent.parent
OUTPUT = W / 'provenance-refresh-r2.json'
assert not OUTPUT.exists()
PROVIDER = ROOT / 'vendor/vortex-array'
SELECTED = {'src/dtype/struct_.rs', 'src/dtype/serde/flatbuffers.rs',
            'src/dtype/struct_memory_tests.rs', 'README.shardloom.md'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

path = PROVIDER / 'upstream-provenance.json'
before = path.read_bytes()
provenance = json.loads(before)
expected = dict(provenance['original_files_sha256'])
for omitted in provenance.get('omitted_files', {}):
    expected.pop(omitted, None)
expected.update(provenance['modified_files_sha256'])
expected.update(provenance['added_files_sha256'])
for name, digest in expected.items():
    if name not in SELECTED:
        assert sha((PROVIDER / name).read_bytes()) == digest, name
for name in sorted(SELECTED):
    raw = (PROVIDER / name).read_bytes()
    target = 'modified_files_sha256' if name in provenance['original_files_sha256'] else 'added_files_sha256'
    provenance[target][name] = sha(raw)
provenance['modified_files_sha256'] = dict(sorted(provenance['modified_files_sha256'].items()))
provenance['added_files_sha256'] = dict(sorted(provenance['added_files_sha256'].items()))
provenance['local_changes_documentation']['sha256'] = sha((PROVIDER / 'README.shardloom.md').read_bytes())
path.write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + '\n')
manifest_path = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
manifest_before = manifest_path.read_bytes()
manifest = json.loads(manifest_before)
components = [row for row in manifest['vendored_components'] if row['path'] == 'vendor/vortex-array']
assert len(components) == 1
components[0]['provenance'] = provenance
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
report = {'status': 'passed', 'selected_files': {name: sha((PROVIDER / name).read_bytes()) for name in sorted(SELECTED)},
          'provenance_before': sha(before), 'provenance_after': sha(path.read_bytes()),
          'manifest_before': sha(manifest_before), 'manifest_after': sha(manifest_path.read_bytes())}
output = OUTPUT
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
