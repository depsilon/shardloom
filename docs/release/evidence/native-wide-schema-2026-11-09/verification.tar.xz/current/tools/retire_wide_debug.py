"""Retire idle reproducible debug outputs after final native tests, without backups."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
DEBUG = CACHE / 'debug'
DEST = OUT / 'debug-retirement-r1'
PRIOR = OUT.parent / 'vector-expressions-2026-11-08'
CHECKS = ('native-clippy-r3.json', 'native-tests-r2.json')
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def read(path):
    return json.loads(path.read_bytes())


def inventory():
    assert DEBUG.resolve() == DEBUG and DEBUG.is_dir() and not DEBUG.is_symlink()
    rows, links, hashes = [], {}, {}
    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = dict(path=str(path), generation=before)
        if stat.S_ISDIR(before[2]):
            item['kind'] = 'directory'
            rows.append(item)
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            item.update(kind='regular', sha256=hashes[key])
            rows.append(item)
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            item.update(kind='symlink', target=os.readlink(path))
            rows.append(item)
        else:
            raise AssertionError('unexpected generated file type ' + str(path))
        assert base.generation(path) == before
    visit(DEBUG)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths)
    return rows


def retained():
    expected = read(PRIOR / 'vector-closeout-r1.json')['retained_runtime_and_wheel']
    for manifest in sorted(OUT.glob('runtime-*-identity.json')):
        for row in read(manifest)['files']:
            expected[row['path']] = {key: row[key] for key in ('bytes', 'sha256')}
    result = {}
    for name, info in expected.items():
        path = Path(name)
        assert path.is_file() and not path.is_symlink() and not path.is_relative_to(DEBUG)
        result[name] = dict(bytes=path.stat().st_size, sha256=base.sha(path))
        assert result[name] == info
    assert len(result) >= 7
    return result


def inputs():
    prior = PRIOR / 'vector-retirement-r2'
    assert base.sha(prior / 'manifest.json.xz') == read(prior / 'plan.json')['manifest_sha256']
    expected = json.loads(lzma.decompress((prior / 'manifest.json.xz').read_bytes()))['input_generations']
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def release():
    return {str(path): base.generation(path) for path in sorted((CACHE / 'release').rglob('*'))}


def resolve():
    for name in CHECKS:
        receipt = read(OUT / name)
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['fixed_source_validation']
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert base.sha((OUT / name).with_suffix('.log')) == receipt['log_sha256']
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    value = json.loads(subprocess.check_output(['cargo', 'metadata', '--locked', '--offline',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert value['target_directory'] == str(CACHE)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == receipt['head']
    closeout = read(PRIOR / 'vector-closeout-r1.json')
    assert closeout['status'] == 'complete' and closeout['merge_commit'] == receipt['base']
    assert not DEBUG.is_relative_to(ROOT) and os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize > 128 << 20


def plan():
    resolve()
    assert not DEST.exists()
    base.closed([str(DEBUG)])
    print('Inventorying idle debug compiler output', flush=True)
    rows = inventory()
    manifest = dict(root=str(DEBUG), entries=rows, retained=retained(), input_generations=inputs(),
        release_generations=release(), source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        native_checks={name: base.sha(OUT / name) for name in CHECKS})
    helper_blob = OUT / 'source-blobs' / base.sha(HELPER)
    if not helper_blob.exists():
        helper_blob.write_bytes(HELPER.read_bytes())
    assert helper_blob.read_bytes() == HELPER.read_bytes()
    DEST.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', root=str(DEBUG), entries=len(rows),
        regular_files=sum(row['kind'] == 'regular' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        manifest_sha256=base.sha(DEST / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), free_bytes_before=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
        reason='The native workspace suite and lint completed. Retire idle reproducible debug compiler output before the separate minimum-toolchain checks, preserving the unchanged storage floor.',
        regeneration='Complete recorded source inventories, lockfiles and exact original validation commands regenerate compiler outputs. Preserve the accepted vector-expression runtime/wheel, all candidate and failed-observation runtimes, current inputs, release cache and every source/observation receipt. No payload backup or storage-limit change.')
    (DEST / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


def apply():
    resolve()
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['root'] == str(DEBUG)
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    rows = manifest['entries']
    assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
    assert release() == manifest['release_generations']
    assert all(base.sha(OUT / name) == sha for name, sha in manifest['native_checks'].items())
    base.closed([str(DEBUG)])
    print('Rechecking exact debug identities and closed handles', flush=True)
    assert inventory() == rows
    base.closed([str(DEBUG)])
    receipt = dict(status='running', removed=0, manifest_sha256=summary['manifest_sha256'])
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(rows, key=lambda item: len(Path(item['path']).parts), reverse=True):
            path = Path(row['path'])
            assert path == DEBUG or path.is_relative_to(DEBUG)
            current = base.generation(path)
            if row['kind'] == 'directory':
                assert current[:3] == row['generation'][:3]
                path.rmdir()
            else:
                # All hardlink names are accounted for in the selected root.
                assert current[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert not DEBUG.exists() and not DEBUG.is_symlink()
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert release() == manifest['release_generations']
        receipt.update(status='passed', retained_runtimes_and_wheel_unchanged=True,
            input_generations_unchanged=True, release_cache_unchanged=True,
            regular_files=summary['regular_files'], regular_bytes=summary['regular_bytes'], symlinks=summary['symlinks'],
            free_bytes_before=summary['free_bytes_before'], free_bytes_after=os.statvfs(CACHE).f_bavail * os.statvfs(CACHE).f_frsize,
            storage_floor_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
