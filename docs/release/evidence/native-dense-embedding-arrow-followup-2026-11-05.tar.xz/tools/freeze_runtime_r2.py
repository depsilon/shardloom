"""Freeze and verify the just-built runtime for local package acceptance."""
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent.parent
build = json.loads((root / 'release-build-arrow-r2.json').read_text())
assert build['status'] == 'passed' and build['returncode'] == 0
target = Path(build['environment']['CARGO_TARGET_DIR']) / 'release'
destination = root / 'runtime-r2'
assert not destination.exists()
destination.mkdir()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()

report = {'build_receipt': 'release-build-arrow-r2.json', 'files': []}
for name in ('shardloom', 'lib_native.dylib'):
    source, copied = target / name, destination / name
    assert source.is_file() and not source.is_symlink()
    before = digest(source)
    shutil.copy2(source, copied)
    assert digest(copied) == before == digest(source)
    report['files'].append({'path': str(copied), 'bytes': copied.stat().st_size,
                            'sha256': before})
(root / 'runtime-identity-r2.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
