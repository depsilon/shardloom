"""Run the repository's existing static documentation gates."""
from pathlib import Path
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
output = Path(__file__).resolve().parent.parent
commands = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', str(output / 'public-status-docs-r2.json')],
    ['scripts/check_contribution_governance.py', '--output', str(output / 'contribution-governance-r2.json')],
    ['scripts/check_python_license_bundle.py'],
]
for command in commands:
    print('Checking ' + command[0], flush=True)
    subprocess.run([sys.executable, '-B', *command], cwd=root, check=True, timeout=120)
