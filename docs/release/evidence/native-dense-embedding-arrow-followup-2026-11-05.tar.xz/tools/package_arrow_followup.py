"""Preserve post-advisory validation as a separate immutable acceptance packet."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

Q = Path(__file__).resolve().parents[1]
T = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
P = T / 'docs/release/evidence'
NAME = 'native-dense-embedding-arrow-followup-2026-11-05'
REQUIRED = ('native-workspace-tests-arrow-r2', 'native-clippy-arrow-r2', 'format-check-arrow-r2',
            'dependency-gate-arrow-r2', 'release-build-arrow-r2', 'installed-wheel-arrow-r2')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


files, checks, receipts = set(), [], {}
for name in REQUIRED:
    path = Q / (name + '.json')
    receipt = read(path)
    receipts[name] = receipt
    log = Q / (name + '.log')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['process_group_drained']
    assert digest(log.read_bytes()) == receipt['log_sha256']
    files.update([path, log])
    checks.append(dict(receipt=path.name, status='passed', command=receipt['command']))
tests = (Q / 'native-workspace-tests-arrow-r2.log').read_text()
assert 'encoded_arrow_provider_rejects_run_ends_shorter_than_parent_extent ... ok' in tests
results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', tests)
counts = dict(zip(('passed', 'failed', 'ignored'), [sum(int(row[i]) for row in results) for i in range(3)]))
assert counts['failed'] == 0 and counts['passed'] > 6900
docs = read(Q / 'docs-arrow-r4.json')
assert docs['status'] == 'passed' and docs['returncode'] == 0
assert digest((Q / 'docs-arrow-r4.log').read_bytes()) == docs['log_sha256']
audit = read(Q / 'dependency-audit-arrow-r2.json')
assert audit['release_gate'] and audit['fallback_dependency_absent']
assert all(audit[key] == 'passed' for key in ('advisory_status', 'cargo_audit_status',
    'cargo_deny_status', 'license_policy_status', 'pip_audit_status'))
installed = read(Q / 'installed-proof-r2/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == dict(tests=312, failures=0, errors=0, skipped=0, status='passed')
assert not installed['publication_attempted']
for name, key in [('lib_native.dylib', 'native_library_sha256'), ('shardloom', 'cli_sha256')]:
    assert digest((Q / 'runtime-r2' / name).read_bytes()) == installed['integrity'][key]
build = receipts['release-build-arrow-r2']
source = {name: descriptor for name, descriptor in
          build['changed_source_inventory'].items()
          if Path(name).suffix in {'.rs', '.py', '.toml'} or name in
          {'Cargo.lock', 'python/THIRD_PARTY_LICENSES/manifest.json'}}
for name, descriptor in source.items():
    assert digest((T / name).read_bytes()) == descriptor['sha256'], name
for label, receipt in receipts.items():
    observed = {name: descriptor for name, descriptor in receipt['changed_source_inventory'].items()
        if Path(name).suffix in {'.rs', '.py', '.toml'} or name in
        {'Cargo.lock', 'python/THIRD_PARTY_LICENSES/manifest.json'}}
    assert receipt['head'] == build['head'] and observed == source, label
initial = {}
for suffix in ('.json', '.tar.xz'):
    path = P / ('native-dense-embedding-lifecycle-2026-11-05' + suffix)
    original = subprocess.check_output(['git', 'show',
        '0d097f05b01e656e83a936c59ce8d22a4fb0e50c:' + path.relative_to(T).as_posix()], cwd=T)
    assert path.read_bytes() == original
    initial[path.name] = digest(original)
for name in ('pr1658-core-original.log', 'pr1658-dependency-original.log', 'rich-pr1658-r1.json',
             'arrow-patch-provenance-r1.json', 'runtime-identity-r2.json',
             'docs-arrow-r2.json', 'docs-arrow-r2.log', 'docs-arrow-r3.json', 'docs-arrow-r3.log',
             'docs-arrow-r4.json', 'docs-arrow-r4.log',
             'dependency-audit-arrow-r2.json', 'public-status-docs-r2.json',
             'contribution-governance-r2.json', 'public-status-docs-r3.json',
             'contribution-governance-r3.json',
             'prepatch-codegen-retirement-r1.json', 'prepatch-codegen-retirement-r1.inventory.json.xz'):
    files.add(Q / name)
for name in ('runend-regression-old-provider-r1', 'runend-regression-old-provider-r2',
             'rich-package-import-r1', 'rich-discovery-import-r1', 'freeze-runtime-r2'):
    files.update(Q / (name + suffix) for suffix in ('.json', '.log'))
files.update((Q / 'installed-proof-r2').glob('*.json'))
files.update((Q / 'installed-proof-r2').glob('*.log'))
files.update(Q.glob('pr1658-c260-checks-*.json'))
files.update((Q / 'source-blobs').iterdir())
files.update(Q / 'tools' / name for name in ('guard_rich_data.py', 'freeze_runtime_r2.py',
    'check_rich_docs_r2.py', 'check_rich_docs_r3.py', 'retire_prepatch_codegen.py',
    'package_arrow_followup.py'))
manifest = []
archive = P / (NAME + '.tar.xz')
assert not archive.exists()
with tarfile.open(archive, 'w:xz') as bundle:
    for path in sorted(files):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        relative = path.relative_to(Q).as_posix()
        manifest.append(dict(path=relative, bytes=len(data), sha256=digest(data)))
        info = tarfile.TarInfo(relative)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        bundle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as bundle:
    assert bundle.getnames() == [row['path'] for row in manifest]
    for row in manifest:
        data = bundle.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
out = dict(schema_version='shardloom.dense_embedding_arrow_followup.v1', status='locally_accepted',
    source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=T, text=True).strip(),
    source_inventory=source, checked_build_parent=build['head'], checked_sources_identical=True,
    checks=checks, native_tests=counts, installed_package=installed['integration'],
    corrected_packages=read(Q / 'arrow-patch-provenance-r1.json'),
    original_failures=[
        dict(source='pr1658-core-original.log', disposition='Package and discovery imports corrected; both loaders pass nine tests.'),
        dict(source='pr1658-dependency-original.log', disposition='RUSTSEC-2026-0442 fixed by three pinned Arrow packages at 59.3.2; no exception.'),
        dict(source='runend-regression-old-provider-r1.json', disposition='Invocation corrected to the existing release-user-surfaces feature.'),
        dict(source='runend-regression-old-provider-r2.json', disposition='Regression reproduces invalid parent extent acceptance at 59.3.1 and passes at 59.3.2.'),
        dict(source='docs-arrow-r2.json', disposition='Generated references refreshed after the Cargo manifest changed; final check passes.')],
    native_library_sha256=installed['integrity']['native_library_sha256'], cli_sha256=installed['integrity']['cli_sha256'],
    wheel_sha256=installed['integrity']['wheel_sha256'], archive=archive.name,
    archive_sha256=digest(archive.read_bytes()), members=manifest,
    performance_claim=False, publication_attempted=False, whole_item_19_complete=False,
    initial_packet_identities=initial,
    initial_packet_unchanged='native-dense-embedding-lifecycle-2026-11-05.json')
with (P / (NAME + '.json')).open('x') as stream:
    json.dump(out, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': out['status'], 'members': len(manifest), 'native_tests': counts,
                  'installed_package': out['installed_package']}))
