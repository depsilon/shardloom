"""Run final static gates without replacing earlier documentation observations."""
from pathlib import Path
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
output = Path(__file__).resolve().parents[1]
commands = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', str(output / 'public-status-docs-r3.json')],
    ['scripts/check_contribution_governance.py', '--output', str(output / 'contribution-governance-r3.json')],
    ['scripts/check_python_license_bundle.py'],
]
assert not (output / 'public-status-docs-r3.json').exists()
assert not (output / 'contribution-governance-r3.json').exists()
for command in commands:
    print('Checking ' + command[0], flush=True)
    subprocess.run([sys.executable, '-B', *command], cwd=root, check=True, timeout=120)
