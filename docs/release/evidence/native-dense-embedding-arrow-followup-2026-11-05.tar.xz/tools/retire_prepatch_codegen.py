"""Retire closed, nonincremental Rust codegen scratch left by completed compilers."""
import hashlib
import json
import lzma
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parents[1]
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
REPORT = OUT / 'prepatch-codegen-retirement-r1.json'
INVENTORY = OUT / 'prepatch-codegen-retirement-r1.inventory.json.xz'
assert not REPORT.exists() and not INVENTORY.exists()


def idle():
    commands = subprocess.check_output(['ps', '-eo', 'comm='], text=True).splitlines()
    assert not any(Path(value.strip()).name in ('rustc', 'clippy-driver', 'cargo', 'ld', 'rust-lld')
                   for value in commands), 'compiler or linker remains active'


def identity(path):
    before = path.lstat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    assert path.name.endswith('.rcgu.o') and before.st_size > 0
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_blocks', 'st_nlink', 'st_mtime_ns', 'st_ctime_ns')
    assert all(getattr(before, field) == getattr(after, field) for field in fields)
    return dict(path=str(path), bytes=before.st_size, allocated_bytes=before.st_blocks * 512,
                sha256=digest, device=before.st_dev, inode=before.st_ino,
                mtime_ns=before.st_mtime_ns, ctime_ns=before.st_ctime_ns)


def closed(paths):
    for start in range(0, len(paths), 128):
        result = subprocess.run(['/usr/sbin/lsof', '-nP', '-F', 'n', '--', *map(str, paths[start:start + 128])],
                                capture_output=True, text=True, check=False, timeout=120)
        assert result.returncode == 1 and not result.stdout.strip() and not result.stderr.strip(), 'scratch object has an open handle'


idle()
paths = sorted(path for profile in ('debug', 'ci-native')
               for path in (CACHE / profile / 'deps').glob('*.rcgu.o'))
assert paths
closed(paths)
records = [identity(path) for path in paths]
raw = json.dumps(records, separators=(',', ':')).encode()
compressed = lzma.compress(raw)
with INVENTORY.open('xb') as stream:
    stream.write(compressed)
assert json.loads(lzma.decompress(INVENTORY.read_bytes())) == records
idle()
closed(paths)
assert [identity(path) for path in paths] == records
retired = []
try:
    for path, expected in zip(paths, records, strict=True):
        assert identity(path) == expected
        path.unlink()
        retired.append(str(path))
finally:
    result = dict(status='passed' if len(retired) == len(records) else 'partial',
                  scope='closed nonincremental .rcgu.o scratch from finished or interrupted compilers',
                  regeneration='Cargo rebuild from retained Git source and locked dependencies with CARGO_INCREMENTAL=0',
                  inventory_sha256=hashlib.sha256(compressed).hexdigest(), inventory=str(INVENTORY),
                  selected_files=len(records), retired_files=len(retired),
                  retired_logical_bytes=sum(row['bytes'] for row in records if row['path'] in retired),
                  retired_allocated_bytes=sum(row['allocated_bytes'] for row in records if row['path'] in retired),
                  preserved_kinds=['source', 'inputs', 'observations', 'runtimes', 'rlib', 'rmeta', 'test executables'],
                  completed_epoch=time.time())
    with REPORT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
assert all(not path.exists() for path in paths)
print(json.dumps(result))
