"""Package only the validation repair; retain the original Variant packet byte-for-byte."""
import argparse
import io
import json
from pathlib import Path
import tarfile
from verify_semantics_repair import CHANGED, FAILURES, HEAD, ORIGINAL, OUT, ROLES, ROOT, deltas, fingerprint, identity

K, V = Path(OUT), Path(ROOT)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--destination', type=Path, required=True)
args = parser.parse_args()
destination = args.destination.resolve()
assert destination.is_relative_to(K) and not destination.exists()
original = V / 'docs/release/evidence' / ORIGINAL
accepted = json.loads((original / 'acceptance.json').read_bytes())
original_files = {path.name: identity(path.read_bytes()) for path in original.iterdir()}
known = {(row['bytes'], row['sha256']) for row in accepted['members']}
known.update((row['bytes'], row['sha256']) for row in original_files.values())
data = {}


def add(path):
    assert path.is_file() and not path.is_symlink()
    name = path.relative_to(K).as_posix()
    raw = path.read_bytes()
    assert name not in data or data[name] == raw
    data[name] = raw


stems = sorted(set(ROLES.values()) | set(FAILURES) | {'release-script-repair-r1'})
for stem in stems:
    for suffix in ('.json', '.log'):
        add(K / (stem + suffix))
    receipt = json.loads(data[stem + '.json'])
    for inventory in ('build_sources', 'tool_source_inventory', 'changed_source_inventory'):
        for info in receipt[inventory].values():
            if 'bytes' in info and (info['bytes'], info['sha256']) not in known:
                blob = K / 'source-blobs' / info['sha256']
                assert identity(blob.read_bytes()) == info
                add(blob)
for path in sorted((K / 'semantics-repair-r1').rglob('*')):
    if path.is_file():
        add(path)
for name in ('semantics-repair-readiness-r1.json', 'semantics-repair-consumer-projection-r1.json',
             'hosted-failure-r1/admitted-semantics-matrix-report.json',
             'hosted-failure-r1/release-runtime-core-evidence.zip',
             'pr1676-observation-runtime-core-failure-r1.json',
             'pr1676-observation-runtime-core-job-log-r1.json'):
    add(K / name)
for name in ('verify_semantics_repair.py', 'package_semantics_repair.py',
             'check_semantics_repair_consumers.py', 'check_semantics_repair_controls.py'):
    add(K / 'tools' / name)
source = json.loads(data[ROLES['docs'] + '.json'])['build_sources']
assert set(deltas(accepted['source_snapshot'], source)) == CHANGED
for name in CHANGED:
    add(K / 'source-blobs' / source[name]['sha256'])
installed = json.loads((K / 'installed-proof-r1/report.json').read_bytes())
observed_runtime = {}
for name, path in (
    ('cli_sha256', K / 'runtime-r2/shardloom'),
    ('native_library_sha256', K / 'runtime-r2/lib_native.dylib'),
    ('wheel_sha256', K / 'installed-proof-r1/dist' / installed['integrity']['wheel']),
):
    assert path.is_file() and not path.is_symlink()
    before = path.stat()
    observed_runtime[name] = identity(path.read_bytes())
    assert before == path.stat()
    assert observed_runtime[name]['sha256'] == accepted['runtime_and_wheel'][name]
archive = io.BytesIO()
with tarfile.open(fileobj=archive, mode='w:xz', preset=6) as stream:
    for name, raw in sorted(data.items()):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode = len(raw), 0o644
        stream.addfile(entry, io.BytesIO(raw))
raw = archive.getvalue()
assert len(raw) < 16 << 20
report = dict(schema_version='shardloom.variant_semantics_repair.v1', status='local_acceptance_passed',
    original_head=HEAD, original_packet=original_files, roles=ROLES, changed_paths=sorted(CHANGED),
    final_source=source, source_deltas=deltas(accepted['source_snapshot'], source),
    source_fingerprint_sha256=fingerprint(source), runtime_and_wheel=accepted['runtime_and_wheel'],
    retained_runtime_observation=observed_runtime,
    production_inputs_changed=False, broad_native_validation_repeated=False, semantics_execution_performed=True,
    failure_dispositions={
        'hosted_original': 'Original CI failed one stale blanket-unsupported Variant fixture; the unchanged native runtime correctly rejects UTF8 operands with SL_INVALID_INPUT. Exact hosted ZIP and report are preserved.',
        'release-script-repair-r2': 'New direct readiness regression exposed three absent false claim/effect fields in its synthetic fixture. The fixture was completed and all 184 tests passed in r3.',
        'semantics-consumers-repair-r1': 'The conformance consumer requires CI-relative artifact references. The untouched actual report uses nonsynced absolute paths. R2 explicitly projects only those paths with every original artifact hash retained; all content fields remain identical.',
        'doc-contracts-repair-r1': 'Documentation contract still required older 151/124/25/23/1 totals. It now requires the actual 153/128/23/20/2 totals; the complete contract suite passed in r2.',
    }, performance_claim=False, publication_attempted=False,
    archive=identity(raw), members=[dict(path=name, **identity(body)) for name, body in sorted(data.items())])
destination.mkdir(parents=True)
(destination / 'verification.tar.xz').write_bytes(raw)
(destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
(destination / 'verify.py').write_bytes(data['tools/verify_semantics_repair.py'])
print(json.dumps(dict(status='packaged', members=len(data), archive_bytes=len(raw), changed_paths=len(CHANGED))))
