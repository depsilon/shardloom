"""Check both release consumers against the actual repaired semantics report."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import check_v1_correctness_conformance as conformance

source = OUT / 'semantics-repair-r1/report.json'
report = json.loads(source.read_bytes())
# The release consumer fixes artifact references to CI's target/ layout. Keep
# the observed report immutable and record an explicit path-only projection.
projected = copy.deepcopy(report)
relocations = []
for stage in projected['stages']:
    if not stage.get('artifact_ref'):
        continue
    artifact = Path(stage['artifact_ref'])
    assert artifact == OUT / 'semantics-repair-r1/work/artifacts' / (stage['case_id'] + '.json')
    raw = artifact.read_bytes()
    target = conformance._expected_stage_artifact_ref(stage['case_id'])
    relocations.append(dict(source=str(artifact), target=target,
        bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    stage['artifact_ref'] = target
summary, blockers = conformance._validate_admitted(projected)
assert not blockers, blockers
destination = OUT / 'semantics-repair-readiness-r1.json'
assert not destination.exists()
run = subprocess.run([sys.executable, '-B', 'scripts/check_release_readiness.py',
    '--admitted-semantics-report', str(source), '--output', str(destination)],
    cwd=ROOT, check=False, timeout=120)
assert run.returncode == 1, 'unrelated release inputs are intentionally absent'
readiness = json.loads(destination.read_bytes())
gate = [row for row in readiness['checks'] if row['name'] == 'admitted_semantics_matrix_validator']
assert len(gate) == 1 and not gate[0]['blockers'], gate
assert readiness['public_release_claim_allowed'] is False
projection = OUT / 'semantics-repair-consumer-projection-r1.json'
assert not projection.exists()
projection.write_text(json.dumps(dict(original_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    relocations=relocations, projected_report=projected), indent=2) + '\n')
print(json.dumps(dict(status='passed', conformance_blockers=blockers,
    readiness_semantics_gate=gate[0], complete_release_readiness_claim=False), sort_keys=True))
