"""Exercise complete portable replay and focused corruption rejection for the repair."""
import argparse
import copy
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from verify_semantics_repair import CONTROLS, ORIGINAL, ROOT, fingerprint, identity, read_archive

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
packet, output = args.packet.resolve(), args.output.resolve()
assert not output.exists()
output.mkdir()
original = packet.parent / ORIGINAL
before = {name: identity((packet / name).read_bytes()) for name in ('acceptance.json', 'verification.tar.xz', 'verify.py')}
rows = []
for case in CONTROLS:
    directory = output / case
    directory.mkdir()
    current = directory / packet.name
    shutil.copytree(packet, current)
    dependency = directory / ORIGINAL
    dependency.mkdir()
    for path in original.iterdir():
        target = dependency / path.name
        if case == 'original_packet_changed' and path.name == 'acceptance.json':
            target.write_bytes(path.read_bytes() + b'\n')
        else:
            os.link(path, target)
    report = json.loads((current / 'acceptance.json').read_bytes())
    data = read_archive(current, report)
    if case == 'archive_byte':
        raw = bytearray((current / 'verification.tar.xz').read_bytes())
        raw[len(raw) // 2] ^= 1
        (current / 'verification.tar.xz').write_bytes(raw)
    elif case == 'production_delta':
        name = 'Cargo.toml'
        report['final_source'][name] = dict(bytes=1, sha256='0' * 64)
        report['source_fingerprint_sha256'] = fingerprint(report['final_source'])
    elif case == 'runtime_identity':
        report['runtime_and_wheel']['cli_sha256'] = '0' * 64
    elif case in ('hosted_failure_missing', 'local_failure_missing', 'semantic_fallback', 'failed_test_receipt'):
        if case == 'hosted_failure_missing':
            del data['hosted-failure-r1/release-runtime-core-evidence.zip']
        elif case == 'local_failure_missing':
            del data['release-script-repair-r2.json']
        else:
            name = 'semantics-repair-r1/report.json' if case == 'semantic_fallback' else 'release-script-repair-r3.json'
            value = json.loads(data[name])
            value['fallback_attempted' if case == 'semantic_fallback' else 'status'] = True if case == 'semantic_fallback' else 'failed'
            data[name] = (json.dumps(value, indent=2) + '\n').encode()
        archive = io.BytesIO()
        with tarfile.open(fileobj=archive, mode='w:xz', preset=6) as stream:
            for name, raw in sorted(data.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                stream.addfile(entry, io.BytesIO(raw))
        raw = archive.getvalue()
        (current / 'verification.tar.xz').write_bytes(raw)
        report['archive'] = identity(raw)
        report['members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(data.items())]
    (current / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    command = [sys.executable, '-I', '-B', str(current / 'verify.py')]
    if case == 'original':
        command += ['--repo-root', ROOT]
    elif case == 'source_scope_missing':
        empty = directory / 'empty-repo'
        subprocess.run(['git', 'init', '-q', str(empty)], check=True)
        command += ['--repo-root', str(empty)]
    run = subprocess.run(command, capture_output=True, timeout=180)
    log = run.stdout + run.stderr
    assert run.returncode == (0 if case in ('original', 'relocated') else 1), (case, log.decode()[-3000:])
    assert {name: identity((packet / name).read_bytes()) for name in before} == before
    rows.append(dict(case=case, returncode=run.returncode, log=log.decode(), log_identity=identity(log)))
    print(case + ': ' + ('accepted' if run.returncode == 0 else 'rejected'), flush=True)
report = dict(status='passed', original_packet=before, verifier=before['verify.py'],
    driver=identity(Path(__file__).read_bytes()), cases=rows, positive_controls=2,
    rejected_controls=len(CONTROLS) - 2)
(output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
assert not (packet / 'corruption-controls.json').exists()
(packet / 'corruption-controls.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', positive_controls=2, rejected_controls=len(CONTROLS) - 2)))
