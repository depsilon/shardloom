"""Package verified release cleanup identities and checks, without retaining deleted payloads."""
import argparse, hashlib, io, json, lzma, tarfile
from pathlib import Path

V=Path(__file__).resolve().parents[1]
C=Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--receipt',type=Path,required=True);p.add_argument('--validation',type=Path,required=True)
p.add_argument('--guard',type=Path,required=True)
a=p.parse_args()
def read(path):return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(raw):return hashlib.sha256(raw).hexdigest()
receipt=a.receipt.resolve();validation=a.validation.resolve();guard=a.guard.resolve()
assert __debug__ and all(path.is_relative_to(V) for path in (receipt,validation,guard))
rec,pre,supervised=map(read,(receipt,validation,guard))
assert rec['status']==pre['status']==supervised['status']=='passed'
assert supervised['returncode']==0 and supervised['process_group_drained'] and supervised['direct_child_reaped']
assert supervised['active_output']==str(receipt.parent) and pre['phase']=='pre-cleanup'
assert rec['retained_and_proof_files_unchanged'] and not rec['inputs_touched'] and not rec['payload_backup_created']
man=Path(rec['manifest']);assert man.parent==receipt.parent and sha(man)==rec['manifest_sha256']
inventory=json.loads(lzma.decompress(man.read_bytes()))
assert len(inventory['paths'])==len({r['path'] for r in inventory['paths']})==rec['removed']
assert set(inventory['roots'])==set(rec['roots'])==set(rec['closed_handles'])
assert all(not Path(root).exists() and not Path(root).is_symlink() for root in rec['roots'])
regular=[r for r in inventory['paths'] if r['kind']=='regular']
assert len(regular)==rec['regular_files'] and sum(r['generation'][3] for r in regular)==rec['retired_regular_bytes']
assert all(sha(Path(path))==wanted for path,wanted in inventory['retained_sha256'].items())
prior=V/'compiler-retirement-110-r1/receipt.json';previous=read(prior)
before=Path(previous['manifest']);assert previous['status']=='passed' and sha(before)==previous['manifest_sha256']
assert rec['prior_ci_native_retirement']['status']=='previously_retired'
assert not Path(previous['profile']).exists() and previous['profile'] not in rec['roots']
dest=C/'docs/release/evidence/v1.1.0-generated-cleanup';assert not dest.exists()
files={};values={}
def add(path,name=None):
    assert path.is_file() and not path.is_symlink()
    name=name or path.relative_to(V).as_posix()
    assert name not in files and path.stat().st_size<=32<<20
    raw=path.read_bytes();files[name]={'bytes':len(raw),'sha256':digest(raw)};values[name]=raw
for path in (receipt,man,validation,guard,guard.with_suffix('.log'),prior,before,
             V/'v110-retire-ci-compiler-r1.json',V/'v110-retire-ci-compiler-r1.log',
             V/'release-tools/retire_release_110.py',V/'release-tools/retire_ci_profile_110.py',
             V/'release-tools/retirement-inventory-110.json',V/'release-tools/registry-retention-map-110.json',
             V/'release-tools/validate_release_finish_110.py',Path(__file__)):
    add(path)
if 'resume' in rec:
    interrupted=Path(rec['resume']['original_failed_receipt'])
    assert interrupted.parent==V/'release-110-generated-retirement-r1'
    assert sha(interrupted)==rec['resume']['original_failed_receipt_sha256']
    stopped=read(interrupted)
    assert stopped['status']=='failed' and stopped['removed']==rec['resume']['original_failed_removed']
    assert stopped['manifest_sha256']==rec['manifest_sha256']
    for path in (interrupted,Path(stopped['manifest']),V/'v110-final-retirement-r1.json',
                 V/'v110-final-retirement-r1.log',V/'release-tools/resume_retirement_110.py',
                 V/'release-110-retirement-resume-self-test-r1.json'):
        add(path)
for entry in pre['checks']:
    path=Path(entry['log'])
    assert path.parent.parent==V and sha(path)==entry['log_sha256'] and entry['returncode']==0
    add(path)
    if path.with_suffix('.json').is_file():add(path.with_suffix('.json'))
old=V.parent/'release-v1.0.0/release-100-payload-cleanup-1.json'
assert inventory['retained_sha256'][str(old)]==sha(old)
add(old,'previous-release/release-100-payload-cleanup-1.json')
assert sum(map(len,values.values()))<64<<20
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:xz',preset=3) as tar:
    for name,raw in sorted(values.items()):
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644
        tar.addfile(entry,io.BytesIO(raw))
packed=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:xz') as tar:
    assert [m.name for m in tar]==sorted(files)
    for m in tar.getmembers():assert m.isfile() and tar.extractfile(m).read()==values[m.name]
out=dict(status='passed',schema_version='shardloom.release_generated_retirement.v1',
         release='v1.1.0',release_source='4d11d4e9c2349f0dc63dc27288b432a351c1a962',
         cleanup_receipt=receipt.relative_to(V).as_posix(),cleanup_receipt_sha256=sha(receipt),
         retained_files=len(inventory['retained_sha256']),release_roots=len(rec['roots']),
         retired_regular_files=rec['regular_files'],retired_regular_bytes=rec['retired_regular_bytes'],
         previously_retired_ci_profile={'regular_files':previous['regular_files'],'regular_bytes':previous['retired_regular_bytes'],
                                        'receipt_sha256':sha(prior)},inputs_touched=False,
         precleanup_local_checks=len(pre['checks']),precleanup_receipt_sha256=sha(validation),
         archive={'path':'observations.tar.xz','sha256':digest(packed),'bytes':len(packed),'members':files},
         recovery='Rebuild disposable intermediates from the release sources and captured commands. The tested release runtime, published artifacts, current comparison runtime and source data are retained.')
if 'resume' in rec:
    out['interrupted_attempt_and_recovery']=rec['resume']
dest.mkdir()
with (dest/'observations.tar.xz').open('xb') as f:f.write(packed)
with (dest/'index.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
assert sha(dest/'observations.tar.xz')==out['archive']['sha256']
print(json.dumps({k:out[k] for k in ('status','retired_regular_files','retired_regular_bytes','retained_files')}))
