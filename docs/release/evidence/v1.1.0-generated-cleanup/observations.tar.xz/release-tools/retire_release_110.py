"""Retire only reviewed, closed ShardLoom release intermediates; preserve all observations."""
import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

R = Path(__file__).resolve().parent.parent
C = Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
CI_PRIOR = R / 'compiler-retirement-110-r1'
WORKERS_AUDIT = R / 'workers-local-audit-r1'
PREVIOUS = R.parent / 'release-v1.0.0'
SOURCE = '4d11d4e9c2349f0dc63dc27288b432a351c1a962'
AUDIT_SOURCE = '2cd1167724b4866010ad16baeefdc6293891308b'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def entry(path):
    g = generation(path)
    row = dict(path=str(path), generation=g)
    if stat.S_ISDIR(g[2]):
        row['kind'] = 'directory'
    elif stat.S_ISREG(g[2]):
        row.update(kind='regular', sha256=sha(path))
    elif stat.S_ISLNK(g[2]):
        row.update(kind='symlink', target=os.readlink(path))
    else:
        raise ValueError('Unexpected file type ' + str(path))
    assert g == generation(path)
    return row


def inventory(root):
    assert root.resolve() == root
    rows = []
    def visit(path):
        row = entry(path)
        rows.append(row)
        if row['kind'] == 'directory':
            for child in sorted(path.iterdir()):
                visit(child)
    visit(root)
    return rows


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--local', required=True, type=Path, help='Passed postdeployment local closeout validation')
parser.add_argument('--include-build', nargs='+', choices=('debug', 'ci-native', 'release'),
                    metavar='PROFILE', help='Selectively retire named Cargo profiles after active-use checks')
args = parser.parse_args()
assert not __debug__ is False and args.name.replace('-', '').isalnum()
target = R / args.name
dest, manifest_path = target / 'receipt.json', target / 'manifest.json.xz'
assert not target.exists()
assert R == Path('/Users/dylan/LocalData/shardloom/release-v1.1.0') and R.resolve() == R
assert read(args.local)['status'] == 'passed'
assert subprocess.check_output(['git','rev-parse','v1.1.0^{commit}'],cwd=C,text=True).strip() == SOURCE
keep, bases = {}, {}
def retain(path, digest=None):
    assert path.is_file() and not path.is_symlink()
    actual = sha(path)
    assert digest is None or digest == actual, path
    keep[str(path)] = actual
    return actual


def retire(path, why, digest=None):
    assert path.exists() and path.resolve() == path and path not in bases
    if digest is not None:
        assert path.is_file() and sha(path) == digest, path
    bases[path] = why


def validate_prior_ci_retirement():
    receipt_path = CI_PRIOR / 'receipt.json'
    manifest_path = CI_PRIOR / 'generations.json.xz'
    receipt = read(receipt_path)
    assert receipt.get('status') == 'passed'
    assert Path(receipt.get('profile', '')) == CACHE / 'ci-native'
    assert Path(receipt.get('manifest', '')) == manifest_path
    assert sha(manifest_path) == receipt.get('manifest_sha256')
    rows = json.loads(lzma.decompress(manifest_path.read_bytes()))
    assert isinstance(rows, list) and rows and rows[0]['path'] == '.'
    assert len({row['path'] for row in rows}) == len(rows)
    assert all(row.get('kind') in ('directory', 'file', 'symlink') for row in rows)
    return receipt_path, manifest_path, rows, receipt


def assert_no_active_build(path):
    # The process scan catches builders that have not opened an output file yet;
    # lsof below independently checks handles and working directories under the root.
    lines = subprocess.check_output(['ps', '-axo', 'pid=,comm=,args='], text=True).splitlines()
    build_names = {'cargo', 'rustc', 'nextest', 'cargo-nextest'}
    for line in lines:
        fields = line.strip().split(None, 2)
        if len(fields) < 2 or Path(fields[1]).name not in build_names:
            continue
        raise AssertionError('active build process blocks optional profile retirement: ' + line)
    if not path.exists():
        return
    result = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpn', '+D', str(path)],
                            capture_output=True, timeout=180)
    assert result.returncode == 1 and not result.stdout and not result.stderr, path


def validate_workers_audit():
    audit_path = WORKERS_AUDIT / 'audit.json'
    browser_path = R / 'publication-browser-workers-local-r1/browser.json'
    website_checks_path = R / 'v110-publication-website-evidence-checks-r1.json'
    audit = read(audit_path)
    browser = read(browser_path)
    website_checks = read(website_checks_path)
    assert audit.get('status') == 'passed' and audit.get('source_commit') == AUDIT_SOURCE
    assert audit.get('site_tree') == subprocess.check_output(
        ['git', 'rev-parse', AUDIT_SOURCE + ':website'], cwd=C, text=True).strip()
    assert not audit.get('failures') and audit.get('local_group_drained') is True
    assert audit.get('browser', {}).get('exitcode') == 0
    assert Path(audit['browser']['receipt']) == browser_path
    assert browser.get('status') == 'passed' and browser.get('source_revision') == AUDIT_SOURCE
    assert browser.get('console_errors') == [] and browser.get('checks')
    assert browser.get('stage') == 'complete' and browser.get('screenshots')
    assert website_checks.get('status') == 'passed' and website_checks.get('returncode') == 0
    review = read(R / 'release-110-publication-pr-review-2.json')
    deployed = read(C / 'docs/release/evidence/v1.1.0-deployed-site/index.json')
    assert review['status'] == 'passed_premerge' and review['pr'] == 1652
    assert website_checks['head'] == review['head'] == deployed['premerge']['head']
    checked_tree = subprocess.check_output(
        ['git', 'rev-parse', review['head'] + '^{tree}'], cwd=C, text=True).strip()
    assert checked_tree == review['source_tree'] == subprocess.check_output(
        ['git', 'rev-parse', deployed['merge_commit'] + '^{tree}'], cwd=C, text=True).strip()
    assert audit['site_tree'] == deployed['website_tree'] == subprocess.check_output(
        ['git', 'rev-parse', 'HEAD:website'], cwd=C, text=True).strip()
    files = audit.get('files')
    assert isinstance(files, dict) and len(files) >= 50
    for relative, evidence in files.items():
        path = C / relative
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == evidence['bytes'] and sha(path) == evidence['sha256']
    return audit_path, browser_path, website_checks_path


def validate_cache_profile(profile):
    path = CACHE / profile
    assert path.is_dir() and path.resolve() == path and not path.is_symlink()
    rows = inventory(path)
    assert rows and rows[0]['path'] == str(path)
    assert all(row['kind'] != 'regular' or path.stat().st_dev == row['generation'][0]
               for row in rows)
    assert all(row['kind'] != 'regular' or Path(row['path']).stat().st_nlink == 1
               for row in rows), 'unexpected hard link in selected Cargo profile'
    return path


retain(args.local)
for name in ('release-110-final-source-1.json','release-110-reviewed-channels-1.json',
             'registry-observation-primary-review-110.json','v110-homebrew-install-r1.json',
             'v110-homebrew-install-r2.json','v110-homebrew-install-r3.json',
             'release-110-publication-local-acceptance-1.json',
             'release-tools/retirement-inventory-110.json','release-tools/registry-retention-map-110.json'):
    retain(R/name)
source = read(R/'release-110-final-source-1.json')
assert source['source_commit']==SOURCE and source['status']=='passed_technical_preview_source_and_package'
review=read(R/'release-110-reviewed-channels-1.json')
assert review['status']=='passed_four_published_technical_preview_channels' and len(review['proofs'])==4
for row in review['proofs'].values():
    path=C/row['path']
    retain(path,row['sha256'])
    value=read(path)
    assert value['proof_status']==value['uninstall_transcript_status']=='passed' and not value['blockers']

# The prior ci-native output has already been retired once. Preserve its actual
# receipt and generation proof, and distinguish that completed action from a new
# profile eligible for optional retirement.
ci_profile = CACHE / 'ci-native'
if not ci_profile.exists():
    ci_receipt, ci_manifest, ci_rows, prior_receipt = validate_prior_ci_retirement()
    assert len(ci_rows) == prior_receipt['removed']
    retain(ci_receipt)
    retain(ci_manifest, prior_receipt['manifest_sha256'])
    prior_ci_retirement = dict(status='previously_retired', profile=str(ci_profile),
                               receipt=str(ci_receipt), manifest=str(ci_manifest),
                               manifest_sha256=prior_receipt['manifest_sha256'], entries=len(ci_rows))
else:
    prior_ci_retirement = dict(status='profile_present', profile=str(ci_profile))

workers_audit_paths = validate_workers_audit()
for path in workers_audit_paths:
    retain(path)
retain(R/'release-tools/audit_local_workers_110.py')
retain(R/'release-tools/browser_110.cjs')
workers_browser = read(workers_audit_paths[1])
for screenshot in workers_browser['screenshots'].values():
    retain(Path(screenshot['path']), screenshot['sha256'])
workers_toolchain = WORKERS_AUDIT / 'toolchain'
workers_node_modules = workers_toolchain / 'node_modules'
workers_npm_cache = WORKERS_AUDIT / 'npm-cache'
assert (workers_toolchain / 'package.json').is_file()
assert (workers_toolchain / 'package-lock.json').is_file()
retain(workers_toolchain / 'package.json')
retain(workers_toolchain / 'package-lock.json')
retire(workers_node_modules, 'Disposable Workers audit install; audit and browser proofs retained.')
retire(workers_npm_cache, 'Disposable Workers audit npm cache; audit and browser proofs retained.')
stage=read(R/'attempt-02/staging-receipt.json')
assert stage['release_source_commit']==SOURCE and stage['status']=='passed_local_staging_no_publication'
for key in ('cli','native_library','wheel'):
    item=stage['frozen_input_identities'][key]
    retain(Path(item['path']),item['sha256'])
expanded=Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03')
matched=read(expanded/'membership-source-match-r1.json')
assert matched['status']=='passed' and read(expanded/'membership-candidate-once/comparison.json')['status']=='passed'
retain(expanded/'membership-source-match-r1.json')
retain(expanded/'membership-candidate-once/complete.json')
for name,digest in matched['candidate_products'].items():
    retain(expanded/'membership-runtime-r1'/name,digest)
canonical=R/'attempt-02/assets/github-prerelease-assets'
assert len(list(canonical.iterdir()))==12
for path in sorted(canonical.iterdir()):
    retain(path)
assert keep[str(canonical/'shardloom')]==stage['frozen_input_identities']['cli']['sha256']
wheel=read(R/'release-110-pypi-package-proof-1.json')
assert wheel['status']=='passed'
retain(Path(wheel['downloaded_wheel']),wheel['downloaded_wheel_sha256'])
archive=read(R/'archive-source-110-1.json')
assert archive['status']=='passed' and archive['source_commit']==SOURCE
raw=R/'readiness-ci-4d11d4e9c234-run41592354237-attempt2-r4'
prior=read(R/'release-tools/retirement-inventory-110.json')
require_roots={
    'archive-source-110-1-extraction':R/'archive-source-110-1',
    'attempt-01-staged-assets':R/'attempt-01/assets',
    'local-package-proof-venv':R/'local-package-proof-v1.1.0-4d11d4e9c234/venv',
    'github-package-proof-venv':R/'github-package-proof-v1.1.0-4d11d4e9c234/venv',
    'github-package-proof-downloads':R/'github-package-proof-v1.1.0-4d11d4e9c234/downloads',
    **{'published-golden-attempt-'+str(i): R/f'published-golden-110-attempt{i}/shardloom' for i in (1,2)}}
assert {v['id'] for v in prior['candidates']} == set(require_roots)|{'attempt-02-assets-top-level-duplicates'}
assert prior['release_identity']['source_commit']==SOURCE
for candidate in prior['candidates']:
    obs=candidate['observed']
    for item in candidate['owning_receipts']:
        path=R/item if isinstance(item,str) else Path(item['path'])
        retain(path,None if isinstance(item,str) else item['sha256'])
    if candidate['id']=='attempt-02-assets-top-level-duplicates':
        for item in obs['files']:
            counterpart=canonical/item['name']
            assert item['canonical_nested_copy']['matches'] and item['sha256']==keep[str(counterpart)]
            path=R/'attempt-02/assets'/item['name']
            g=item['generation']; actual=generation(path)
            assert actual[:2]==[g['device'],g['inode']] and actual[3:]==[g['size_bytes'],g['mtime_ns'],g['ctime_ns']]
            retire(path,'Byte-identical to retained '+str(counterpart),item['sha256'])
        continue
    root=Path(obs['path']);assert root==require_roots[candidate['id']]
    found={row['path']:row for row in inventory(root) if row['kind']!='directory'}
    assert len(found)==len(obs['files'])
    for item in obs['files']:
        path=(root/item['path']) if root.is_dir() else root
        row=found[str(path)];g=item['generation']
        assert row['generation'][:2]==[g['device'],g['inode']]
        assert stat.S_IMODE(row['generation'][2])==g['mode']
        assert row['generation'][3:]==[g['size_bytes'],g['mtime_ns'],g['ctime_ns']],path
        if item['type']=='symlink':
            assert row['target']==item['target']
        else:
            assert row['sha256']==item['sha256']
        if candidate['id']=='archive-source-110-1-extraction' and item['path'].startswith('target/'):
            retain(raw/item['path'].replace('/','--'),item['sha256'])
        if candidate['id']=='github-package-proof-downloads' or candidate['id'].startswith('published-golden-attempt'):
            assert keep[str(canonical/path.name)]==row['sha256']
    retire(root,candidate['classification'])
assert len([path for path in keep if path.startswith(str(raw)+'/target--')])==27
retire(Path(archive['binary']['path']),'Exported-source build; accepted build, source and proof retained.',archive['binary']['sha256'])

for name in ('bundled-registry-110-pypi-rvaqc98c','bundled-registry-110-testpypi-_l2taxp9',
             'python-registry-110-pypi-1','python-registry-110-testpypi-1',
             'homebrew-110-sspgudyr','homebrew-110-r2-9kokp4i6','homebrew-110-r3-q1t5ix86'):
    parent=R/name
    assert (parent/'venv/pyvenv.cfg').is_file()
    receipts=[p for p in parent.iterdir() if p.is_file()]
    assert receipts
    for path in receipts:
        retain(path)
    retire(parent/'venv','Completed single-use install/test environment; commands, output and proof receipts retained.')
test=read(R/'release-110-testpypi-package-proof-1.json')
assert test['status']=='passed' and Path(test['downloaded_wheel']).parent==R/'python-registry-110-testpypi-1/downloads'
retire(Path(test['downloaded_wheel']),'Verified public TestPyPI distribution',test['downloaded_wheel_sha256'])
mapping=read(R/'release-tools/registry-retention-map-110.json')
assert Path(mapping['cache_root'])==CACHE/'registry-evidence-1.1.0-9pu0flk6'
served=[r for r in mapping['records'] if r['class_name']=='served_distribution']
assert len(served)==8
for row in served:
    path=Path(row['path'])
    assert path.parent.parent==Path(mapping['cache_root'])
    provenance=C/f'docs/release/channel-proofs/{path.parent.name}-v1.1.0-provenance.json'
    assert Path(row['proof_locator'])==provenance
    retain(provenance)
    doc=read(provenance)
    actual,=[r for r in doc['artifact_refs'] if r['filename']==path.name]
    assert doc['proof_status']=='passed' and actual['sha256']==row['sha256'] and actual['size_bytes']==row['bytes']
    assert path.stat().st_size==row['bytes'] and actual['url']==row['original_locator']['url']
    retire(path,'Verified public registry download. Installed-tested macOS wheel retained separately at '+wheel['downloaded_wheel']+'; registry locator '+actual['url'],row['sha256'])
old_receipt=PREVIOUS/'release-100-payload-cleanup-1.json'
old=read(old_receipt);assert old['status']=='passed'
retain(old_receipt)
old_paths=[PREVIOUS/'release-100-assets-1/shardloom',PREVIOUS/'release-100-build-1/extension/_native.abi3.so',
    PREVIOUS/'python-registry-100-pypi-1/downloads/shardloom-1.0.0-cp310-abi3-macosx_26_0_arm64.whl']
assert set(map(str,old_paths))==set(old['retained_sha256'])
for path in old_paths:
    if path.exists():
        retire(path,'Superseded 1.0.0 runtime or installed-test wheel. Immutable prior build/publication receipts and current 1.1.0 runtime and wheel remain.',old['retained_sha256'][str(path)])
selected_profiles = list(dict.fromkeys(args.include_build or []))
for name in selected_profiles:
    if name == 'ci-native' and not (CACHE/name).exists():
        assert prior_ci_retirement['status'] == 'previously_retired', \
            'ci-native is absent without validated prior retirement evidence'
        assert_no_active_build(CACHE/name)
        continue
    path = validate_cache_profile(name)
    assert_no_active_build(path)
    retire(path, 'Selected Cargo profile; rebuild from tracked source/lock and preserved guard commands.')
assert not any(a in b.parents for a in bases for b in bases if a!=b)
assert all(base!=expanded and base not in expanded.parents and expanded not in base.parents for base in bases)
assert not any(p==base or base in p.parents for base in bases for p in map(Path,keep))
rows=[row for root in bases for row in inventory(root)]
assert len(rows)==len({row['path'] for row in rows})
manifest=dict(roots={str(p):why for p,why in bases.items()},retained_sha256=keep,paths=rows)
target.mkdir()
with manifest_path.open('xb') as f:
    f.write(lzma.compress(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode(),preset=3))
assert json.loads(lzma.decompress(manifest_path.read_bytes()))==manifest
receipt=dict(status='running',manifest=str(manifest_path),manifest_sha256=sha(manifest_path),roots=list(map(str,bases)),closed_handles=[],removed=0)
try:
    for root in bases:
        if root.parent == CACHE:
            assert_no_active_build(root)
        else:
            result=subprocess.run(['/usr/sbin/lsof','-nP','-Fpn',*(['+D'] if root.is_dir() else []),str(root)],capture_output=True,timeout=180)
            assert result.returncode==1 and not result.stdout and not result.stderr,root
        receipt['closed_handles'].append(str(root))
    assert [row for root in bases for row in inventory(root)]==rows
    assert all(sha(Path(name))==wanted for name,wanted in keep.items())
    for row in sorted(rows,key=lambda row:len(Path(row['path']).parts),reverse=True):
        path=Path(row['path'])
        if row['kind']=='directory':
            assert generation(path)[:3]==row['generation'][:3]
            path.rmdir()
        else:
            assert entry(path)==row
            path.unlink()
        receipt['removed']+=1
    assert all(not p.exists() and not p.is_symlink() for p in bases)
    assert all(sha(Path(name))==wanted for name,wanted in keep.items())
    receipt.update(status='passed',regular_files=sum(r['kind']=='regular' for r in rows),
        symlinks=sum(r['kind']=='symlink' for r in rows),retired_regular_bytes=sum(r['generation'][3] for r in rows if r['kind']=='regular'),
        retained_and_proof_files_unchanged=True,inputs_touched=False,payload_backup_created=False)
    receipt['prior_ci_native_retirement'] = prior_ci_retirement
    receipt['workers_local_audit'] = dict(status='validated', audit=str(workers_audit_paths[0]),
        browser=str(workers_audit_paths[1]), website_checks=str(workers_audit_paths[2]),
        toolchain_source_and_lock_retained=True, scratch_runtime_retained=True)
except BaseException as exc:
    receipt.update(status='failed',error=type(exc).__name__+': '+str(exc))
    raise
finally:
    with dest.open('x') as f:
        json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:receipt[k] for k in ('status','regular_files','symlinks','retired_regular_bytes')}))
