"""Validate release-only follow-through, including external proof before cleanup."""
import argparse, hashlib, json, os, re, subprocess, tarfile
from pathlib import Path

V=Path(__file__).resolve().parents[1]
C=Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
CI=V/'readiness-ci-4d11d4e9c234-run41592354237-attempt2-r3'
BIND=V/'release-110-local-evidence-bindings-1'
PUB=C/'docs/release/evidence/v1.1.0-deployed-site'
RET=C/'docs/release/evidence/v1.1.0-generated-cleanup'
PY='/opt/homebrew/opt/python@3.13/libexec/bin/python3'
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--phase',choices=('pre-cleanup','final'),required=True)
p.add_argument('--name',required=True)
a=p.parse_args();assert __debug__ and re.fullmatch('[a-z0-9-]+',a.name)
dest=V/a.name;report=V/(a.name+'.json');assert not dest.exists() and not report.exists()
def read(path):return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=C,text=True).strip()
pub=read(PUB/'index.json')
assert pub['status']=='passed' and pub['publication_pr']==1652 and pub['premerge']['check_count']==58
assert pub['merge_commit']=='ad2ed5cb1da279413e93e402ee56d7bb24478d90' and pub['website_tree']==git('rev-parse','HEAD:website')
assert pub['production_site_attempts'][-1]['status']==pub['production_browser_attempts'][-1]['status']=='passed'
assert pub['repository_links']['distinct']==40 and pub['repository_links']['occurrences']==54
ar=pub['archive'];tarpath=PUB/ar['path'];assert tarpath==PUB/'observations.tar.xz' and sha(tarpath)==ar['sha256']
with tarfile.open(tarpath,'r:xz') as tar:
    rows=tar.getmembers();assert len(rows)==len(ar['members'])==len({m.name for m in rows})==ar['member_count']<=400
    for m in rows:
        assert m.isfile() and not m.issym() and not m.islnk() and 0<=m.size<=16<<20 and not {'..','.'}.intersection(Path(m.name).parts)
        source=(V/m.name).resolve();assert source.is_relative_to(V) and source.is_file()
        blob=tar.extractfile(m).read();assert len(blob)==ar['members'][m.name]['bytes'] and blob==source.read_bytes()
        assert hashlib.sha256(blob).hexdigest()==ar['members'][m.name]['sha256']
approval=read(C/'docs/release/final-release-approval-post-release-verification.json')
assert approval['approved_release_tag']=='v1.1.0' and approval['approved_release_commit']=='4d11d4e9c2349f0dc63dc27288b432a351c1a962'
assert approval['public_release_ready'] and approval['post_release_verification_ready']
assert len(approval['verification_rows'])==6 and all(r['verification_status']=='passed' for r in approval['verification_rows'])
assert all(r['evidence_ref']==(PUB/'index.json').relative_to(C).as_posix() for r in approval['verification_rows'] if r['row_id'] in ('website_support_matrix_public_smoke','docs_links_public_smoke'))
assert not git('diff','--name-only','HEAD','--','Cargo.toml','Cargo.lock','python','shardloom-*','scripts','.github','website','website-src')
for s in ('pypi','testpypi','github-prerelease','homebrew'):
    proof=read(C/f'docs/release/channel-proofs/{s}-v1.1.0-transcript.json')
    assert proof['proof_status']==proof['uninstall_transcript_status']=='passed' and not proof['blockers']
if a.phase=='final':
    retired=read(RET/'index.json')
    assert retired['status']=='passed' and sha(V/retired['cleanup_receipt'])==retired['cleanup_receipt_sha256']
    assert sha(RET/retired['archive']['path'])==retired['archive']['sha256']
dest.mkdir()
def check(label,script,*extra):
    return (label,[PY,'-B','scripts/'+script,*extra,'--output',str(dest/(label+'.json'))])
local=['--require-local-evidence'] if a.phase=='pre-cleanup' else []
checks=[
    check('package-channels','check_package_channel_readiness.py',*local,'--dependency-audit-report',str(CI/'dependency-audit-report.json'),
        '--release-dry-run-transcript',str(CI/'release-dry-run-transcript.json'),'--provenance-report',str(BIND/'supply-chain-release-evidence.json')),
    check('release-boundary','check_v1_release_boundary.py','--release-dry-run-transcript',str(CI/'release-dry-run-transcript.json'),
        '--package-channel-report',str(dest/'package-channels.json')),
    check('source-package','check_v1_local_source_package_release.py'),
    check('final-approval','check_final_release_approval.py','--require-public-release-ready'),
    check('public-status','check_public_status_docs.py'),
    check('workspace-version','check_workspace_version_sources.py'),
    check('docs-productization','check_v1_docs_productization.py'),
    check('website-readiness','check_website_readiness.py'),
    ('website-links',[PY,'-B','-m','unittest','-v','scripts.test_website_links']),
    ('whitespace',['git','diff','--check','HEAD']),
]
if a.phase=='pre-cleanup':
    checks.append(('release-doc-contracts',['cargo','test','--offline','--locked','-p','shardloom-contract-tests','--test','release_readiness_metadata']))
record=dict(status='running',phase=a.phase,head=git('rev-parse','HEAD'),checked_deployment_sha256=sha(PUB/'index.json'),
            checked_approval_sha256=sha(C/'docs/release/final-release-approval-post-release-verification.json'),
            source=approval['approved_release_commit'],checks=[],reviewed_archive_members=len(rows),
            command_scope='Release acceptance and read-only site, package and documentation checks.')
try:
    for name,cmd in checks:
        path=dest/(name+'.log')
        with path.open('xb') as f:
            run=subprocess.run(cmd,cwd=C,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='python/src:python/tests:scripts'),
                               stdout=f,stderr=subprocess.STDOUT,timeout=1800)
        record['checks'].append(dict(name=name,command=cmd,returncode=run.returncode,log=str(path),log_sha256=sha(path)))
        print(name,run.returncode,flush=True)
    record['status']='passed' if all(c['returncode']==0 for c in record['checks']) else 'failed'
except BaseException as e:
    record.update(status='failed',error=repr(e));raise
finally:
    with report.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
raise SystemExit(0 if record['status']=='passed' else 1)
