"""Retire the closed CI-native compiler profile after preserving release and candidate runtimes."""
import hashlib
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

V=Path(__file__).resolve().parent.parent
C=Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
root=Path('/Users/dylan/.cache/shardloom/cargo-target/ci-native')
out=V/'compiler-retirement-110-r1';out.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_bytes())
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snap(path):
    s=path.lstat();data=dict(path=path.relative_to(root).as_posix(),device=s.st_dev,inode=s.st_ino,
        mode=s.st_mode,bytes=s.st_size,mtime=s.st_mtime_ns,ctime=s.st_ctime_ns)
    if stat.S_ISREG(s.st_mode):
        assert s.st_nlink==1,'review unexpected hard link before retirement'
        data.update(kind='file',sha256=sha(path))
    elif stat.S_ISDIR(s.st_mode):data['kind']='directory'
    elif stat.S_ISLNK(s.st_mode):data.update(kind='symlink',target=os.readlink(path))
    else:raise ValueError(str(path))
    return data
def inventory():
    assert root.is_dir() and root.resolve()==root and not root.is_symlink()
    return [snap(p) for p in [root,*sorted(root.rglob('*'))]]
def no_build():
    commands=subprocess.check_output(['ps','-axo','comm='],text=True)
    assert not any(Path(c.strip()).name in ('cargo','rustc','nextest','cargo-nextest') for c in commands.splitlines())
assert V==Path('/Users/dylan/LocalData/shardloom/release-v1.1.0')
meta=json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--offline','--format-version','1'],cwd=C))
assert Path(meta['target_directory'])==root.parent and root.name=='ci-native'
no_build()
keep={}
for name in ('release-110-final-source-1.json','release-110-reviewed-channels-1.json',
    'v110-publication-workspace-tests-r1.json','v110-publication-clippy-r1.json',
    'attempt-02/staging-receipt.json','release-110-pypi-package-proof-1.json',
    'release-110-publication-local-acceptance-2.json','v110-expanded-reference-primary-r2.json',
    'v110-expanded-disjoint-probe-r2.json'):
    path=V/name; value=read(path); assert value.get('status','').startswith('passed'),name
    keep[str(path)]=sha(path)
for item in read(V/'release-110-reviewed-channels-1.json')['proofs'].values():
    path=C/item['path'];assert sha(path)==item['sha256'];keep[str(path)]=item['sha256']
stage=read(V/'attempt-02/staging-receipt.json')
for name in ('cli','native_library','wheel'):
    item=stage['frozen_input_identities'][name];path=Path(item['path'])
    assert not path.is_relative_to(root) and sha(path)==item['sha256'];keep[str(path)]=item['sha256']
pypi=read(V/'release-110-pypi-package-proof-1.json');keep[pypi['downloaded_wheel']]=pypi['downloaded_wheel_sha256']
assert all(sha(Path(p))==v for p,v in keep.items())
rows=inventory()
manifest=out/'generations.json.xz'
with manifest.open('xb') as f:f.write(lzma.compress(json.dumps(rows,separators=(',',':')).encode(),preset=3))
assert json.loads(lzma.decompress(manifest.read_bytes()))==rows
result=dict(status='running',profile=str(root),manifest=str(manifest),manifest_sha256=sha(manifest),kept_sha256=keep,
    removed=0,reason='Closed Cargo CI-native compiler output. Retained accepted 1.1.0 CLI, native library, wheels, source, build and integration receipts; preserve default debug profile for pending workspace checks.',
    payload_archive_created=False,allocated_free_before=os.statvfs(V).f_bavail*os.statvfs(V).f_frsize)
try:
    p=subprocess.run(['/usr/sbin/lsof','-nP','-Fpn','+D',str(root)],capture_output=True,timeout=180)
    assert p.returncode==1 and not p.stdout and not p.stderr
    result['lsof_returncode']=p.returncode;no_build()
    assert rows==inventory()
    assert all(sha(Path(p))==v for p,v in keep.items())
    for r in sorted(rows,key=lambda r:len(Path(r['path']).parts),reverse=True):
        path=root/r['path']
        if r['kind']=='directory':
            s=path.lstat()
            assert (s.st_dev,s.st_ino,s.st_mode)==(r['device'],r['inode'],r['mode'])
            path.rmdir()
        else:
            assert snap(path)==r
            path.unlink()
        result['removed']+=1
    assert not root.exists() and not root.is_symlink()
    assert all(sha(Path(p))==v for p,v in keep.items())
    result.update(status='passed',regular_files=sum(r['kind']=='file' for r in rows),
        symlinks=sum(r['kind']=='symlink' for r in rows),retired_regular_bytes=sum(r['bytes'] for r in rows if r['kind']=='file'),
        allocated_free_after=os.statvfs(V).f_bavail*os.statvfs(V).f_frsize,retained_files_unchanged=True)
except BaseException as error:
    result.update(status='failed',error=type(error).__name__+': '+str(error));raise
finally:
    with (out/'receipt.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(result['status'],result['regular_files'],result['retired_regular_bytes'])

