#!/usr/bin/env python3
"""Audit or resume only the unremoved suffix of the immutable v1.1.0 cleanup plan.

Default operation is read-only.  --apply is intentionally explicit and consumes
the original r1 manifest without changing it.  This helper is never run with
--apply by its authoring/verification workflow.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess
import tempfile
from collections import defaultdict


V = Path('/Users/dylan/LocalData/shardloom/release-v1.1.0')
R1 = V / 'release-110-generated-retirement-r1'
R2 = V / 'release-110-generated-retirement-r2'
KNOWN_FAILURE_REMOVED = 12314
KNOWN_TOTAL = 18739
KNOWN_MANIFEST_SHA256 = '5c6297089080f44de8b0f5f70a2fc1d68118eb6a053b76a2712ad49df7ffd06e'


def sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_json(path: Path):
    return json.loads(path.read_bytes())


def compressed_manifest():
    raw = (R1 / 'manifest.json.xz').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == KNOWN_MANIFEST_SHA256
    manifest = json.loads(lzma.decompress(raw))
    return raw, manifest


def generation(path: Path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def grouped_regular_rows(rows):
    groups = defaultdict(list)
    for index, row in enumerate(rows):
        if row['kind'] == 'regular':
            g = row['generation']
            groups[(g[0], g[1])].append((index, row))
    return groups


def _assert_regular_row(row, remaining_aliases, removed_aliases):
    """Compare every regular-file identity field, with ctime linked to plan unlinks."""
    path = Path(row['path'])
    g = generation(path)
    wanted = row['generation']
    assert g[:5] == wanted[:5], f'regular identity changed: {path}'
    assert sha256(path) == row['sha256'], f'regular content changed: {path}'
    assert path.stat().st_nlink == remaining_aliases, \
        f'unaccounted hardlink(s): {path} has {path.stat().st_nlink}, plan has {remaining_aliases}'
    if g[5] != wanted[5]:
        assert removed_aliases and remaining_aliases >= 1, \
            f'unexplained ctime change: {path}'


def _assert_row(row, remaining_aliases=None, removed_aliases=False):
    path = Path(row['path'])
    kind = row['kind']
    if kind == 'regular':
        _assert_regular_row(row, remaining_aliases, removed_aliases)
        return
    g = generation(path)
    wanted = row['generation']
    if kind == 'directory':
        # Child removal changes directory size/timestamps; directory identity stays fixed.
        assert g[:3] == wanted[:3], f'directory identity changed: {path}'
    elif kind == 'symlink':
        assert g == wanted, f'symlink identity changed: {path}'
        assert os.readlink(path) == row['target'], f'symlink target changed: {path}'
    else:
        raise AssertionError(f'unknown manifest kind {kind!r}: {path}')


def verify_row_set(rows, removed_count):
    """Prove the original prefix is absent and every original suffix row is intact."""
    assert len(rows) == KNOWN_TOTAL and len({r['path'] for r in rows}) == KNOWN_TOTAL
    # Retirement traversed the manifest with Python's stable depth sort. Keep
    # this ordering separate from the manifest's immutable inventory ordering.
    ordered = sorted(rows, key=lambda r: len(Path(r['path']).parts), reverse=True)
    prefix, suffix = ordered[:removed_count], ordered[removed_count:]
    for row in prefix:
        path = Path(row['path'])
        try:
            path.lstat()
        except FileNotFoundError:
            continue
        raise AssertionError(f'original removed prefix entry is present: {path}')

    groups = grouped_regular_rows(ordered)
    remaining_by_group = defaultdict(int)
    removed_by_group = defaultdict(int)
    for i, row in enumerate(ordered):
        if row['kind'] == 'regular':
            key = tuple(row['generation'][:2])
            if i < removed_count:
                removed_by_group[key] += 1
            else:
                remaining_by_group[key] += 1
    for key, aliases in groups.items():
        reference = aliases[0][1]
        for _, row in aliases[1:]:
            assert row['generation'][:5] == reference['generation'][:5]
            assert row['generation'][5] == reference['generation'][5]
            assert row['sha256'] == reference['sha256'], f'inconsistent hardlink plan group {key}'

    for index, row in enumerate(suffix, start=removed_count):
        if row['kind'] == 'regular':
            key = tuple(row['generation'][:2])
            _assert_row(row, remaining_by_group[key], removed_by_group[key] > 0)
        else:
            _assert_row(row)
    return prefix, suffix, groups, remaining_by_group, removed_by_group, ordered


def check_closed_handles(roots):
    checked = []
    for root_text in roots:
        root = Path(root_text)
        if not root.exists() and not root.is_symlink():
            # A fully removed exact-file root is already closed by absence.
            checked.append(root_text)
            continue
        args = ['/usr/sbin/lsof', '-nP', '-Fpn']
        if root.is_dir():
            args.append('+D')
        args.append(str(root))
        result = subprocess.run(args, capture_output=True, timeout=180)
        assert result.returncode == 1 and not result.stdout and not result.stderr, \
            f'open handle under retirement root: {root}'
        checked.append(root_text)
    return checked


def verify_retained(retained):
    for filename, digest in retained.items():
        path = Path(filename)
        assert path.is_file() and not path.is_symlink(), f'retained proof missing: {path}'
        assert sha256(path) == digest, f'retained proof changed: {path}'


def prior_ci_retirement():
    path = V / 'compiler-retirement-110-r1/receipt.json'
    previous = read_json(path)
    manifest = Path(previous['manifest'])
    assert previous['status'] == 'passed'
    assert sha256(manifest) == previous['manifest_sha256']
    return dict(status='previously_retired', profile=previous['profile'], receipt=str(path),
                manifest=str(manifest), manifest_sha256=previous['manifest_sha256'],
                entries=previous['removed'])


def make_receipt(manifest, roots, checked, retained):
    rows = manifest['paths']
    return dict(
        status='running', manifest=str(R2 / 'manifest.json.xz'),
        manifest_sha256=KNOWN_MANIFEST_SHA256, roots=roots, closed_handles=checked,
        removed=KNOWN_FAILURE_REMOVED, regular_files=sum(r['kind'] == 'regular' for r in rows),
        symlinks=sum(r['kind'] == 'symlink' for r in rows),
        retired_regular_bytes=sum(r['generation'][3] for r in rows if r['kind'] == 'regular'),
        retained_and_proof_files_unchanged=False, inputs_touched=False,
        payload_backup_created=False, prior_ci_native_retirement=prior_ci_retirement(),
        workers_local_audit=dict(status='validated',
            audit=str(V / 'workers-local-audit-r1/audit.json'),
            browser=str(V / 'publication-browser-workers-local-r1/browser.json'),
            website_checks=str(V / 'v110-publication-website-evidence-checks-r1.json'),
            toolchain_source_and_lock_retained=True, scratch_runtime_retained=True),
        resume=dict(schema='shardloom.release_retirement_resume.v1',
            original_failed_receipt=str(R1 / 'receipt.json'),
            original_failed_receipt_sha256=sha256(R1 / 'receipt.json'),
            original_failed_removed=KNOWN_FAILURE_REMOVED,
            original_failed_error=read_json(R1 / 'receipt.json')['error'],
            original_manifest_sha256=KNOWN_MANIFEST_SHA256,
            hardlink_ctime_audit='ctime variance accepted only for regular-file inode groups with an earlier removed manifest alias; each remaining link count must equal the remaining plan aliases',
            hardlink_groups=[]),
    )


def atomic_receipt(path, value):
    temp = path.with_name(path.name + f'.tmp-{os.getpid()}')
    raw = (json.dumps(value, indent=2) + '\n').encode()
    with temp.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def audit(apply=False):
    assert V.is_dir() and V.resolve() == V
    assert not R2.exists() and not R2.is_symlink(), f'resume output already exists: {R2}'
    original_receipt = read_json(R1 / 'receipt.json')
    raw_manifest, manifest = compressed_manifest()
    assert original_receipt['status'] == 'failed'
    assert original_receipt['manifest'] == str(R1 / 'manifest.json.xz')
    assert original_receipt['manifest_sha256'] == KNOWN_MANIFEST_SHA256
    assert original_receipt['removed'] == KNOWN_FAILURE_REMOVED
    rows = manifest['paths']
    roots = list(manifest['roots'])
    assert set(roots) == set(original_receipt['roots']) == set(original_receipt['closed_handles'])
    assert len(roots) == 40 and len(manifest['retained_sha256']) == 277
    assert all(Path(root).is_absolute() for root in roots)
    prefix, suffix, groups, remaining, removed, ordered_rows = verify_row_set(
        rows, KNOWN_FAILURE_REMOVED)
    check_closed_handles(roots)
    verify_retained(manifest['retained_sha256'])
    receipt = make_receipt(manifest, roots, roots, manifest['retained_sha256'])
    for key, removed_aliases in removed.items():
        if len(groups[key]) > 1 and removed_aliases and remaining[key]:
            aliases = groups[key]
            receipt['resume']['hardlink_groups'].append(dict(
                device=key[0], inode=key[1], removed_plan_aliases=removed_aliases,
                remaining_plan_aliases=remaining[key],
                paths=[row['path'] for _, row in aliases],
                current_link_count=Path(next(row['path'] for _, row in aliases
                    if Path(row['path']).exists())).stat().st_nlink if remaining[key] else 0))
    if not apply:
        return dict(status='dry_run_passed', original_total=len(rows),
            original_prefix_absent=len(prefix), original_suffix_verified=len(suffix),
            cumulative_removed=len(rows), regular_files=receipt['regular_files'],
            symlinks=receipt['symlinks'], retired_regular_bytes=receipt['retired_regular_bytes'],
            retained_files_verified=len(manifest['retained_sha256']), roots_closed=len(roots),
            hardlink_groups=receipt['resume']['hardlink_groups'], apply_performed=False)

    R2.mkdir()
    try:
        with (R2 / 'manifest.json.xz').open('xb') as stream:
            stream.write(raw_manifest)
            stream.flush()
            os.fsync(stream.fileno())
        assert sha256(R2 / 'manifest.json.xz') == KNOWN_MANIFEST_SHA256
        atomic_receipt(R2 / 'receipt.json', receipt)
        suffix_groups_remaining = dict(remaining)
        removed_by_group = dict(removed)
        for row in ordered_rows[KNOWN_FAILURE_REMOVED:]:
            path = Path(row['path'])
            if row['kind'] == 'regular':
                key = tuple(row['generation'][:2])
                _assert_row(row, suffix_groups_remaining[key], removed_by_group.get(key, 0) > 0)
                path.unlink()
                suffix_groups_remaining[key] -= 1
                removed_by_group[key] = removed_by_group.get(key, 0) + 1
            else:
                _assert_row(row)
                if row['kind'] == 'directory':
                    path.rmdir()
                else:
                    path.unlink()
            receipt['removed'] += 1
            atomic_receipt(R2 / 'receipt.json', receipt)
        assert all(not Path(root).exists() and not Path(root).is_symlink() for root in roots)
        verify_retained(manifest['retained_sha256'])
        receipt.update(status='passed', removed=len(rows),
            retained_and_proof_files_unchanged=True, inputs_touched=False,
            payload_backup_created=False)
        atomic_receipt(R2 / 'receipt.json', receipt)
        return dict(status='passed', cumulative_removed=len(rows),
            regular_files=receipt['regular_files'], symlinks=receipt['symlinks'],
            retired_regular_bytes=receipt['retired_regular_bytes'], apply_performed=True)
    except BaseException as exc:
        receipt.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        atomic_receipt(R2 / 'receipt.json', receipt)
        raise


def self_test():
    """Exercise identity logic on disposable temp hardlinks; never touches V."""
    with tempfile.TemporaryDirectory(prefix='retirement-110-resume-test-') as tmp:
        root = Path(tmp)
        first, second = root / 'first', root / 'second'
        first.write_bytes(b'fixture hardlink payload')
        os.link(first, second)
        s = first.lstat()
        digest = sha256(first)
        row_a = dict(path=str(first), kind='regular',
            generation=[s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns],
            sha256=digest)
        row_b = dict(row_a, path=str(second))
        first.unlink()
        # The alias unlink changes ctime; suffix link count is exactly one.
        _assert_regular_row(row_b, remaining_aliases=1, removed_aliases=True)
        try:
            os.link(second, root / 'external')
            _assert_regular_row(row_b, remaining_aliases=1, removed_aliases=True)
        except AssertionError as exc:
            assert 'unaccounted hardlink' in str(exc)
        else:
            raise AssertionError('unaccounted external hardlink was not rejected')
    return dict(status='synthetic_hardlink_self_test_passed', fixture='temporary directory only')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true', help='perform the audited suffix unlink; destructive')
    parser.add_argument('--self-test', action='store_true', help='exercise hardlink rules in a temp directory')
    args = parser.parse_args()
    result = self_test() if args.self_test else audit(apply=args.apply)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
