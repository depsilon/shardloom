"""Execute refreshed source-document examples against the retained installed wheel."""
import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory

REPO = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
sys.path.insert(0, str(REPO / 'python/tests'))
import pyarrow as pa
from test_native_table_binding import make_table, OLD


def blocks(path):
    return re.findall(r'^```python\n(.*?)^```', path.read_text(), flags=re.M | re.S)


def run(code, name):
    scope = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(ast.fix_missing_locations(code) if isinstance(code, ast.AST) else code,
                     name, 'exec'), scope)
    return scope


def main():
    tables = REPO / 'website-src/src/content/docs/field-guide/local-tables.mdx'
    sql = REPO / 'website-src/src/content/docs/field-guide/sql.mdx'
    connected = REPO / 'docs/reference/connected-programming.md'
    snippets = blocks(tables)
    assert len(snippets) == 2
    base = ast.parse(snippets[0])
    alternatives = ast.parse(snippets[1]).body
    assert len(alternatives) == 2
    results = []
    with TemporaryDirectory(prefix='shardloom-doc-tables-') as directory:
        for kind, template in [('delta', None), ('iceberg', alternatives[0]), ('hudi', alternatives[1])]:
            path, _, _, _, _ = make_table(Path(directory) / kind, kind, pa)
            tree = ast.parse(snippets[0])
            block = next(node for node in tree.body if isinstance(node, ast.With))
            if template is not None:
                block.body[0] = ast.parse(ast.unparse(template)).body[0]
            declaration = block.body[0]
            assert isinstance(declaration, ast.Assign) and isinstance(declaration.value, ast.Call)
            declaration.value.args[0] = ast.Constant(str(path))
            scope = run(tree, f'{tables}:{kind}')
            result = scope['result']
            expected = tuple(row for row in OLD if row['id'] >= 2)
            assert result.to_rows() == expected, kind
            assert result.details.field_map['fallback_attempted'] == 'false'
            assert result.details.field_map['external_engine_invoked'] == 'false'
            results.append(dict(example='table_snapshot', format=kind, rows=len(expected)))
    candidates = [code for code in blocks(sql) if 'parameters=' in code]
    assert len(candidates) == 1
    run(candidates[0], str(sql))
    results.append(dict(example='named_parameters_and_query_local_relation', rows=3))
    first = blocks(connected)[0]
    run(first, str(connected))
    results.append(dict(example='connected_programming_complete_computation', rows=3))
    print(json.dumps(dict(status='passed', examples=results,
        source_sha256={str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in (tables, sql, connected)},
        fixture_scope='Documentation table paths replaced with independent small wire-format fixtures; query code, selectors and expected visibility unchanged.')))


if __name__ == '__main__':
    main()
