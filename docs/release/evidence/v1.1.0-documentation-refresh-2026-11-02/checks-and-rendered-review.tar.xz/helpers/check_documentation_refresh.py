"""Run the existing documentation and generated-site acceptance checks."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31/docs-refresh-r1')
PY = sys.executable
checks = [
    [PY, '-B', 'scripts/write_public_api_reference.py', '--check'],
    [PY, '-B', 'scripts/write_v1_supported_unsupported_docs.py', '--check'],
    [PY, '-B', 'scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status.json')],
    [PY, '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py', '-v'],
    [PY, '-B', 'scripts/check_website_readiness.py', '--output', str(OUT / 'website-readiness.json')],
    ['node', 'scripts/validate_static_assets.cjs'],
    [PY, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v'],
    ['npm', '--prefix', 'website-src', 'audit', '--audit-level=low'],
]
results = []
for index, command in enumerate(checks):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=180)
    log = OUT / f'check-{index:02d}.log'
    with log.open('x') as stream:
        stream.write(result.stdout + result.stderr)
    record = dict(command=command, returncode=result.returncode, log=str(log))
    results.append(record)
    print(json.dumps(record), flush=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-6000:], flush=True)
report = dict(status='passed' if all(row['returncode'] == 0 for row in results) else 'failed', checks=results)
with (OUT / 'documentation-checks.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
raise SystemExit(report['status'] != 'passed')
