# Next representation unit — primary design draft

Grounded against main `c47eeefa05012cce32b053f53af18583041c9f19` while its 55
required integration checks run. This scratch design is not implementation or
acceptance. Finish variable-tensor main verification and sealed closeout first.

## Coherent scope

Carry Float16 primitive values, nested numeric values, dense embeddings and both
fixed/variable tensors through existing native source, result, selection,
relational, spill and persistence owners. Include ragged collections of fixed
vectors in the same lifecycle proof using existing List<FixedSizeList> and
List<Embedding> types, with no new collection wrapper. Sparse and quantized
logical representations need separate persistent semantic contracts and remain
subsequent step-4 work. Exact vector expressions remain step 5.

Comparator: a columnar-runtime maintainer would require exact selected bits,
nullability and logical metadata across every boundary, no eager observation of
hidden values, correct ownership accounting, and explicit unsupported outputs.

## Type and semantics decisions

- Use Vortex 0.90 `PType::F16`/`half::f16` and primitive storage, with the current
  tensor and embedding extensions over it. No new runtime dependency, layout,
  extension identifier, engine, or parallel scalar substrate is needed.
- Admit scalar Float16 to the existing numeric owners and shared float semantic
  policy, using Float64 registers just as Float32 does. Existing expression
  result typing, strict/extended policy, key equivalence, null handling and
  aggregate rules remain the contract; this adds a physical width, not vector
  arithmetic. Do not enable optional specialized paths until their dtype and
  result contracts have explicit tests.
- Preserve all 65,536 binary16 bit patterns in storage and opaque carriage.
  Positive/negative zero, subnormals, infinities, NaN sign/payload and signaling
  bits are representation data. Semantic keys may use existing canonical NaN
  and zero identities without changing carried values.
- Add core bit-oriented binary16-to-Float64 and exact reverse conversion to
  avoid introducing half into the core dependency graph. Use these helpers at
  scalar/Python boundaries; the provider continues to own its native f16 type.
  Exact finite conversion must reject overflow, underflow and rounding. Exact
  NaN reverse conversion rejects payload bits that do not fit binary16.
- Rust helper verification must exhaust every 16-bit input and independently
  check numeric values against the pinned provider conversion for finite values.
  Include negative controls for every exponent boundary and discarded bit region.
- Explicit Python `float16` schema/type construction accepts only exactly
  representable values under the caller's existing float policy. Inferred Python
  floats remain Float64. Typed JSON remains finite and exact. No new implicit or
  explicit lossy cast is introduced by this unit.
- Existing observation rules remain: selected scalar observation checks float
  policy; untouched rich payload components may carry nonfinite bits; masked or
  discarded values do not become an observed error merely due to this admission.

## Boundaries to implement and inspect

1. Core float bit helpers; typed-native schema/value parser and result builder.
2. Native payload schema and metadata accounting; float leaf copying/validation;
   numeric owner/accessor, key preparation, gather and result reconstruction.
   Review every explicit F16 exclusion; retain intentional optimization skips
   with deterministic general native behavior rather than blanket replacement.
3. Vortex/Arrow recursive conversion and ingest; tensor and embedding component
   validators and Arrow mappings; row-result/schema extraction and Python builders.
4. Vortex, Arrow IPC and Parquet write/reopen using actual capable provider paths.
   Source hint and scalar compatibility routes must not silently widen declared
   Float16. Unsupported format/type combinations fail before publication; text,
   Avro and ORC cannot claim exact Float16 schema without an explicit mapping.
5. Native/Python types, user guide, example, generated API surfaces, acceptance
   validators and phase/retention docs consistent with actual proved behavior.

## Acceptance contract

One mixed dataset exercises primitive f16, variable lists, fixed vectors,
embeddings, vector collections, fixed tensors and variable tensors beside
ordinary join/filter keys and existing binary/nested payloads. Test complete
selected bytes and metadata for import -> retained source -> selection/reorder
and ordinary filtering -> duplicate-match join -> streaming and forced spill ->
all five writes -> separate-process reopen -> export. Include nonzero slices,
empty and null parents, null children, zero-width tensors, changed source,
source/context drop, retained Arrow views, memory denial/shrink, cancellation,
failed publication and last-owner cleanup. Use independent Arrow/Parquet reads
where the pinned reader supports the exact layout and retain precise gaps.

Targeted numeric tests cover Float16 key/filter/order/aggregate and projected
expressions against explicit Float64-register reference semantics, exact result
type and float policy. No new vector arithmetic, performance claim or benchmark.
Then required fmt/default clippy/workspace tests, applicable native feature
matrix, complete native tests, Python core, clean installed-wheel suite and
example, portable original/relocated evidence replay and meaningful corruption
controls. Preserve original failures and source versions. Hosted PR/review and
exact main checks precede task-owned artifact retirement and next implementation.

## Source anchors already inspected

- `native_payload_schema.rs`: `admitted_scalar`, recursive metadata admission.
- `native_arrow_conversion.rs`: `data_type` excludes F16.
- `local_primitive_result_batch.rs`: selected scalar, byte sizing, builders.
- `local_primitives/native_numeric_owner.rs`: typed dispatch, policy, `Numeric`.
- `local_primitives/native_relational_numeric_gather.rs`: physical leaf/copy gate.
- `local_primitives/native_relational_sort_numeric.rs`: original-width sort keys.
- `local_primitives/native_relational_batch.rs`: take and preservation policies.
- `local_primitives/native_payload.rs`: parent-selected recursive copies.
- `local_primitives/native_input_values.rs`: finite exact JSON numeric boundary.
- `local_primitives.rs`: primitive statistic/logical conversion exclusions.
- `shardloom-core/src/float_policy.rs`: existing F32 exact widening/narrowing.
- `python/src/shardloom/{types,_input_schema,_result_schema,_tensor,_variable_tensor}.py`
  and `shardloom-python/src/{object_input,rows,schema}.rs`: current F32/F64 routes.

The source inventories in this scratch directory remain static evidence only.
Provider specification, boundary inventories and the separate literal-provider
call graph have been reviewed against the local sources. Public typed predicate
lowering already excludes all float fields from optional scan pushdown. Keep
that rule and route Float16 requests through the shared relational executor
using the existing `prepared_dispatch::requires_relational` type check. Legacy
Float16 predicate conversion and optional specialized reductions remain
unadmitted; no lossy predicate narrowing or new provider cast is needed. Add a
nonrepresentable-threshold regression through public file and memory sources.

## Exact conversion design, awaiting implementation

Use `widen_f16_bits(u16) -> f64` and
`narrow_f16_bits_exact(f64) -> Option<u16>` in the existing core float policy
module. The bit argument avoids adding the provider's scalar dependency to core.
Normal binary16 exponents map to the Float64 exponent by adding 1008; its ten
fraction bits occupy Float64 fraction bits 42 through 51. Special exponent 31
maps to 2047 with the same fraction placement, preserving NaN sign, quiet/signaling
state and payload. For a nonzero subnormal fraction `m`, let `k` be its highest
set-bit position: the Float64 exponent is `999 + k`, and the remaining fraction
is shifted left by `52 - k`. Signed zero is constructed directly from its sign.

Exact narrowing accepts zero; normal Float64 exponents 1009 through 1038 with
zero low 42 fraction bits; subnormal-target exponents 999 through 1008 whose
53-bit significand is divisible by `2 ** (1051 - exponent)`; and special values
whose low 42 payload bits are zero. All other finite values are rejected. No
floating arithmetic or lossy cast is needed for either representation conversion.
Validate every binary16 pattern, finite values against the pinned half provider,
adjacent Float64 values around every finite binary16 value, every excluded
exponent region and every discarded NaN payload-bit position.

The finite-only Python JSON adapter can use `struct` half packing with an exact
round-trip check. In-process PyO3 construction and row extraction must use the
core bit helpers, since numeric half packing alone does not preserve carried
NaN bits. Inferred Python floats remain Float64, and `types.scalar` retains its
existing literal-domain contract. Do not broaden unrelated expression literals,
table-format schemas or optional encoded-provider eligibility automatically.

## Reviewed test and integration boundaries

- Exhaustive storage input is a raw-buffer Arrow Float16 column with every
  16-bit pattern under extended policy. Compare complete valid value bits after
  native, IPC and Parquet persistence, independently reading supported formats.
  Rich collections use representative boundary patterns and full selected-value
  comparison; this does not require preserving unobservable bytes under nulls.
- The five existing front doors are DataFrame, Python SQL, typed native plan,
  embedded workflow and CLI SQL. All feed the shared native execution boundary.
  Reopen saved native outputs in a separate process after source removal; compare
  complete result schemas, logical metadata and selected bits.
- Existing `test_native_tensor_binding._value` handles only Float32/64. Extend
  its raw-bit case before reusing `_rows` for Float16 tensor/collection checks.
  `test_native_float_policy_binding.describe` already uses floating bit widths.
- Preserve `numeric_expression_left_preparation_precedes_right_evaluation_failure`:
  its deliberately invalid F16 source becomes valid. Replace it with an actually
  unsupported numeric-key source (for example a Null array, verified through
  the same direct key preparation) and retain the exact error-order assertion.
- `prepared_dispatch::requires_relational` is the common type-based route for
  rich/decimal/extension native requests. Add Float16 there and retain existing
  float predicate pushdown exclusion, including its direct typed-plan checks.
- Ingest has independent scalar-family, finite-value and dictionary-value
  checks. Extend all three for Float16 while retaining integer-only dictionary
  codes and existing policy about referenced/unreferenced values. Inspect exact
  source-schema hints; unsupported scalar row reconstruction must refuse an
  exact declared Float16 schema instead of silently widening it.
- Existing wheel proof discovers `test_native*binding.py` automatically. Use the
  existing test environment and wheelhouse, the shared two-job compiler cache,
  unchanged 12-GiB free-space floor and standard guard. Feature checks retain the
  seven configurations in `tools/check_variable_features.py`; no dependency or
  feature expansion is planned.
