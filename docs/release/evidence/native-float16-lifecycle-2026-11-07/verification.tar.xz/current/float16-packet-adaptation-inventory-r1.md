# Prior variable-tensor evidence packet: adaptation inventory

Read-only workflow inventory for the Float16 lifecycle. This records what the variable-tensor packet asserts and binds; it makes no design choices about the new packet. Paths and values below belong to the prior packet and must be replaced with current Float16 receipts and identities.

## Prior packet and command model

- Prior scratch root: `/Users/dylan/LocalData/shardloom/variable-tensor-lifecycle-2026-11-07`.
- Prior verifier source: `tools/verify_variable_packet.py`.
- Prior packet builder: `tools/package_variable_evidence.py`.
- Prior corruption driver/sealer: `tools/check_variable_packet_controls.py`, `tools/seal_variable_controls.py`.
- Prior delivery binder: `tools/prepare_variable_delivery.py`.
- Prior doc checks: `tools/check_variable_docs.py`.
- Prior accepted evidence destination: `F/docs/release/evidence/native-variable-shape-tensor-2026-11-07/`.
- Float16 scratch target is `/Users/dylan/LocalData/shardloom/float16-lifecycle-2026-11-07`; current worktree is `F=/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo`.

The prior builder consumes scratch-root JSON receipts and paired logs, source blobs, tool source, provider provenance and package proof; it writes `verification.tar.xz`, `acceptance.json`, and an embedded verifier into a repository evidence directory. Its absolute `ROOT`, `DEST`, branch, historical merge commit, names, hard-coded type descriptions, assertion counts, and outputs are variable-tensor-specific. Copying and string-replacing those values is insufficient.

## Exact required top-level evidence receipts

The prior verifier's `REQUIRED` list is asserted in `tools/verify_variable_packet.py`. For each required `name`, the builder expects both `S/name.json` and `S/name.log`; JSON status must be `passed`, return code 0, process group drained, and log SHA-256 must match the receipt. It stores command/status and Rust test counts (when present).

- `variable-format-r4`
- `variable-default-clippy-r3`
- `variable-default-tests-r3`
- `variable-native-clippy-r4`
- `variable-native-tests-r2`
- `variable-feature-matrix-r1`
- `variable-native-build-r3`
- `variable-freeze-runtime-r3`
- `variable-python-core-r1`
- `variable-example-r2`
- `variable-static-docs-r1`
- `variable-installed-wheel-r1`
- `variable-provider-acceptance-r1`

The verifier also consumes non-required observations: all top-level `S/*.json`, `S/*.log`, `S/source-blobs/*`, `S/tools/*.py`, selected directory contents, and installed-proof JSON/logs. Failed observations are deliberately included and must have explicit dispositions; stopped/failed attempts are not converted into successful evidence.

## Other bound source, result, and log inputs

The builder selects:

- Every `S/*.json`, `S/*.log`, `S/source-blobs/*`, `S/tools/*.py`.
- All `S/*.md` except `continuation.md`.
- All immediate files in `provider-formats-r1/`, `provider-new-arrow-r2/`, `debug-retirement-r1/`, `parquet-schema-probe-r1/`, `parquet-schema-probe-r2/`, `python-core-r1/`.
- `installed-proof-r1/*.json` and `installed-proof-r1/*.log`.
- Excludes files whose basename starts `variable-package-` from the archive.
- Contracts taken from F at the build receipt's source commit: `Cargo.lock`, `python/tests/test_public_context.py`, `scripts/prove_native_python_wheel.py`, and five `.github/provider-locks/{orc-rust,arrow-avro,arrow-ipc,arrow-data,arrow-array}.lock` files.
- Provider original registry archives from the local Cargo registry cache, provider provenance JSON, and every modified/added vendor source file for `arrow-data`, `arrow-array`, and `parquet`.
- Prior fixed tensor provider review (`receipt.json`, `registry.json`, `vortex-tensor-0.90.0.crate`) and all receipts named by the fixed-tensor closeout file.

For Float16, each selected category must be audited against current changed dependencies, provider evidence, source inventory, relevant prior lifecycle receipts and real Float16 inputs. The variable packet's prior tensor closeout and three provider packages are not automatically Float16 dependencies or required inputs.

## Assertions embedded in prior report/verifier (must be recomputed, not copied)

- Python core: `status=passed`; discovery count from core receipt; reported run count parsed from log; skip/failure/error counts match; log is present and count agrees.
- Installed wheel: isolated native install and uninstall status passed; all steps return code 0 and step logs hash correctly; wheel, CLI and native library identities agree across report, runtime freeze and wheel contents. Wheel package source matches the source snapshot.
- Installed integration report in this prior report: **361 tests, 0 failures, 0 errors, 0 skipped**, status passed. The report's `installed-proof-r1/report.json` integration contract is the authoritative source; do not reuse 361 as a Float16 target.
- The prior installed suite asserts every selected discovery pattern has at least one test. Patterns: `test_native*binding.py`, `test_connected_programming.py`, `test_native_function_catalog.py`, `test_native_observations.py`, `test_native_standard_adapters.py`, `test_query_surface_native.py`, `test_recursion_policy.py`, `test_public_context.py`.
- It separately binds exact test method names for variable tensor (11 tests) and public context (19 tests), checks the count/output of the runnable example (`complete_reopened_rows: 2`), and forbids skipped installed tests.
- Provider acceptance: five named crates x test/clippy = 10 commands, all logs and lockfiles hash-bound; prior totals **1,606 passed, 0 failed, 1 ignored**. These provider names/counts and ignored-test facts are specific to that packet and must be replaced by Float16 provider evidence; do not carry a known upstream Map ignored test into a new summary unless it is relevant and actually observed.
- Failure inventory: all top-level failed JSON receipts are matched to the report's original-failure entries and nonempty dispositions. `failure-index-r2` requires 21 failed receipts as a subset; `failure-index-r3` requires 23 and exact set equality. These numbers and historical failure dispositions are variable-tensor-specific.
- Prior native suite stopped once for a minimum-free-storage guard; verifier binds that stopped state, drained/reaped process, and a later cleanup receipt (22,392 regular files). Those claims must not be replayed as Float16 observations.
- Dependency-resolution comparison allows exactly two same-version path substitutions (`arrow-data`, `arrow-array`) against a recorded base lock. Reuse only if the new source tree has the same exact dependency delta and provenance.
- Historical preceding integration binds PR #1661, merged main commit, 58 PR checks and 55 main checks. Float16 has different implementation/PR history; omit this historical integration chain unless it is truly a required dependency for the new proof.
- Contract limitations in the prior verifier include PyArrow 25.0.1 variable-tensor footer behavior, fixed-list null-parent limitation, tensor arithmetic/key roles, writers and sparse/quantized scope. Do not port those as Float16 limitations; use Float16 contract-specific independent reader and unsupported-format limits.

## Prior workflow command and receipts

- Build receipt command: `cargo build --locked --offline --release --features release-user-surfaces -p shardloom-cli -p shardloom-python` (with configured Python/profile environment). Receipt: `variable-native-build-r3.json`.
- Required default checks in this packet: `cargo fmt --all -- --check`; workspace Clippy with `--locked --offline -- -D warnings`; workspace tests with `--locked --offline`.
- Native checks additionally enable `shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment` for Clippy/tests.
- Feature matrix: delegated to `tools/check_variable_features.py` and its receipt/log; inspect for exact feature tuples, not just status.
- Python core: delegated to `scripts/run_python_test_shard.py --shard core` (receipt records actual command/test count).
- Example: prior custom `tools/run_variable_example.py` and receipt/log; Float16 example command and expected exact assertions must be new.
- Static docs: prior `tools/check_variable_docs.py`; performs `scripts/write_public_api_reference.py --check`, `scripts/write_python_api_exports.py --check`, `scripts/check_user_surface_reference.py`, `scripts/check_public_status_docs.py --output <scratch/public-status-docs-TAG.json>`, and `scripts/check_contribution_governance.py --output <scratch/contribution-governance-TAG.json>`. The two generated checks create scratch receipts.
- Installed wheel: `scripts/prove_native_python_wheel.py --output-dir <scratch>/installed-proof-r1 --native-library <runtime>/lib_native.dylib --cli-binary <runtime>/shardloom --wheelhouse <wheelhouse>`, invoked with offline/no-index packaging as encoded by that tool. In prior report it created `package/`, `dist/shardloom-1.1.0-cp310-abi3-macosx_27_0_arm64.whl`, `venv/`, per-stage logs, `integration.json`, and `report.json`. It built, installed optional consumer dependencies from a hashed wheelhouse, installed and loaded the wheel, ran integration tests, uninstalled, and confirmed module/library/CLI removal. Rebuild and rebind all current wheel/runtime identities for Float16.
- Evidence package: `python3 -B <S>/tools/package_variable_evidence.py` produced prior repository evidence files. It is a writing script and was only inspected here, not run.
- Portable verification: embedded `verify.py` supports `--packet` and optional `--repo-root`; intended to verify offline without runtime test/build reruns.
- Delivery binder checks clean branch/head/parent, exact changed-file set, packet hashes, docs receipt/source inventory, wheel/runtime identities and workflow files. It writes `S/delivery-acceptance-r1.json`. It includes prior branch `codex/native-variable-tensor-lifecycle`, hard-coded F path, variable-tensor evidence directory, fixed-tensor closeout, doc receipt names, and exact changed-file set; all require a new Float16-specific binding.

## Output paths in the prior workflow

- Repository evidence folder: `F/docs/release/evidence/native-variable-shape-tensor-2026-11-07/`
  - `verification.tar.xz`
  - `acceptance.json`
  - `verify.py`
  - later-added `README.md`
  - later-added `corruption-controls.json`
- Scratch control suite: `S/packet-controls-r1/` with a receipt, one log per control, and cloned packet directories.
- Scratch build/package/delivery receipts: `S/variable-package-r1.json`, `S/variable-packet-controls-r1.json`, `S/delivery-acceptance-r1.json`; excluded `variable-package-*` receipt from archive to avoid self-reference.
- README generation source: `S/tools/write_variable_packet_readme.py`.

## Relocation and corruption controls

The prior verifier/control harness runs two positive controls: original packet with repository source checking, and a byte-identical relocated packet with no repo root. It rejects nine controls:

1. one flipped byte in archive;
2. changed report test count without changing archive;
3. resealed packet marking required native tests failed;
4. resealed installed test report with one skipped test;
5. omitted original failed observation with summary adjusted;
6. provider test count altered to 99,999 with summary adjusted;
7. missing original provider crate source;
8. preceding-main required check changed to failure with nested hashes/links resealed;
9. broadened example correction with source blobs and inventories resealed.

`check_variable_packet_controls.py` saves each subprocess log, hashes it, checks expected accept/reject and error type, verifies relocation copies exact three packet files, and verifies original packet hashes are unchanged. `seal_variable_controls.py` independently rechecks all 11 result names, logs, fixture mutations and original immutability before writing `corruption-controls.json`. Prior control receipt status: passed, 2 positive / 9 rejected. This suite contains tensor-specific mutation paths and must be adapted to Float16 evidence structure; no run was performed for this inventory.

## Stale facts / non-mechanical adaptation warnings

- Hard-coded variable worktree, branch, evidence destination, prior scratch locations, feature labels and source/test filenames.
- `REQUIRED`, `FORMAT_PROVIDERS`, exact cargo command map, feature matrix, provider archive set, patched dependency assumptions and provenance verification.
- Example correction chain and its exact one-line source diff, expected reopened row count, test module names/counts.
- Exact installed wheel release tag, runtime binaries, Python version, package source count, 361 integration tests, license inventory counts and all hashes.
- Provider totals 1,606/0/1; failed receipt count 23; cleanup count 22,392; PR #1661 and 58/55 check receipts.
- Historical fixed/variable tensor closeout chains and PyArrow limitations.
- Text describing Float32/Float64 only, unsupported Float16/sparse/quantized representations, or tensor-only limitations in packet README/verifier/report.
- Prior verifier has semantic checks on *specific* schema roundtrips, data shapes, unsupported outputs and result values beyond checksum/receipt consistency; these must be replaced with binary16 representation and lifecycle-specific evidence. A successful packet hash does not prove Float16 correctness unless the verifier binds required 65,536-pattern, user lifecycle, persistence, policy, exact-threshold and ownership evidence called for by the new contract.
