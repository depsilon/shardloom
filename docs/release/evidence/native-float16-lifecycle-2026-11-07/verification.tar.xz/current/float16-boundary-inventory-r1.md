# Float16 boundary inventory (r1)

Read-only source inventory at `c47eeefa05012cce32b053f53af18583041c9f19` (main, after PR #1662). This records source behavior only; it does not certify runtime behavior or a complete Float16 lifecycle. Full paths below are repository-relative unless stated otherwise.

## Findings

### Provider capability versus ShardLoom admission

- Vendored Vortex 0.90 has primitive `PType::F16`, native `f16` values and scalar conversion support (`vendor/vortex-array/src/dtype/ptype.rs:55,351,400-401`; `vendor/vortex-array/src/scalar/convert/primitive.rs:141`; `vendor/vortex-array/src/scalar/proto.rs:156-157,354-364`). This is generic provider capability, not proof of ShardLoom path admission.
- Vortex scalars preserve F16 bits in protobuf, including NaN and infinities (`vendor/vortex-array/src/scalar/proto.rs:947-987`). That does not imply ShardLoom's result scalar supports those values.
- ShardLoom's public core `ScalarValue` has only `Float64(f64)`, not Float32/Float16 variants (`shardloom-core/src/expression.rs:44-63`). Vortex-owned retained scalar conversion maps a `Value::Float` to `ScalarValue::Float64` (`shardloom-vortex/src/local_primitive_unary_values.rs:717-770`); `OwnedScalar` reserves and owns/copies those scalar values (`shardloom-vortex/src/local_primitive_unary_values.rs:545-582`).

### Schema and payload admission

- Typed native JSON schema parsing recognizes primitive names `f32` and `f64`; all other primitive names, including `f16`, return `unsupported native input primitive` (`shardloom-vortex/src/local_primitives/native_input_schema.rs:210-225`).
- Shared native payload scalar admission rejects F16 (`shardloom-vortex/src/native_payload_schema.rs:15-23`), and recursive metadata sizing only accepts primitive types other than F16 (`shardloom-vortex/src/native_payload_schema.rs:194-201`). The Arrow leaf allowlist names Float32 and Float64 and omits Float16 (`shardloom-vortex/src/native_payload_schema.rs:324-343`); nested list/struct recursion uses that leaf admission (`shardloom-vortex/src/native_payload_schema.rs:375-387`). Its unsupported diagnostic explicitly says F32/F64 (`shardloom-vortex/src/native_payload_schema.rs:440-449`).
- Native Vortex-to-Arrow dtype conversion returns `None` for F16 (`shardloom-vortex/src/native_arrow_conversion.rs:73-85`). This mapper also supplies the Arrow builder schema for declared in-process input; generic Arrow import has its separate shared schema-admission gate.
- Result buffer sizing rejects F16 (`shardloom-vortex/src/local_primitive_result_batch.rs:377-389`); native primitive result construction explicitly errors `float16 results are not admitted` (`shardloom-vortex/src/local_primitive_result_batch.rs:915-933`).

### Fixed tensor, variable tensor, and embedding validators

- Fixed tensor element admission allows Bool or any primitive except F16 (`shardloom-vortex/src/native_tensor.rs:211-230`). Its Arrow component mapper recognizes Float32/Float64 and returns `None` for other kinds (`shardloom-vortex/src/native_tensor_arrow.rs:37-53,77-93`).
- Variable tensor storage requires a List whose child passes the fixed tensor element validator; its failure diagnostic lists Boolean/integer/Float32/Float64 (`shardloom-vortex/src/native_variable_tensor.rs:285-312`). Arrow extension preflight likewise delegates to that element validator (`shardloom-vortex/src/native_variable_tensor_arrow.rs:48-75`). The existing tests explicitly include F16 as rejected storage (`shardloom-vortex/src/native_variable_tensor_tests.rs:154-166`).
- Embedding Arrow preflight accepts fixed-size Float32 or Float64 children only (`shardloom-vortex/src/native_embedding_arrow.rs:35-49`); the Vortex-to-Arrow component mapper also accepts only F32/F64 (`shardloom-vortex/src/native_embedding_arrow.rs:51-79`).
- Tensor and embedding Arrow tests exercise F32/F64 payloads and bit-preserving cases, not a Float16 round trip (`shardloom-vortex/src/native_tensor_arrow.rs:206-280`; `shardloom-vortex/src/native_embedding_arrow.rs:183-262`).

### Python, file/source schema, and scalar/result boundaries

- Python inferred numeric floats become Arrow Float64 (`shardloom-python/src/object_input.rs:145-151`). Explicit builder construction and append handling enumerate Float32/Float64, with no Float16 arm (`shardloom-python/src/object_input.rs:284-324,388-415`). Python row conversion handles Float32 by exact-bit-aware widen and Float64 directly (`shardloom-python/src/rows.rs:78-93`). Schema descriptions name Float32/Float64 and recurse into lists/fixed-size lists; tensor/embedding metadata is handled on that fixed-list branch (`shardloom-python/src/schema.rs:22-82`).
- The ShardLoom object input schema path parses declared typed JSON and maps the result through the native Arrow converter; conversion absence produces an explicit error (`shardloom-vortex/src/resident_memory_batches.rs:91-128`).
- Universal-format source schema hint maps Arrow Float16/32/64 to Arrow Float64 (`shardloom-vortex/src/universal_format_io.rs:4485-4498`). The Arrow scalar reader only has Float32->Float64 and Float64->Float64 branches (`shardloom-vortex/src/universal_format_io.rs:6510-6515`). This is a widening compatibility hint, not Float16-preserving lifecycle evidence. No source evidence here proves a read/write/reopen path preserves Float16 bits.
- Native nested Arrow values are subject to payload schema admission; `List<Float16>` is therefore excluded at the generic schema boundary (`shardloom-vortex/src/native_payload_schema.rs:317-387`). Variable tensor/embedding custom extension field admission also excludes Float16, above.

### Existing exact F32/F64 representation helpers and callers

- `shardloom-core/src/float_policy.rs:5-45` defines Strict/Extended nonfinite admission. `widen_f32` and `narrow_f32_exact` preserve carried F32 NaN payload/sign bits and require bit-exact finite round trips (`shardloom-core/src/float_policy.rs:52-87`). `float_key_bits` canonicalizes NaNs and signed zero for semantic key identity without mutating carried values (`shardloom-core/src/float_policy.rs:89-100`). Arithmetic-result NaN canonicalizers are separate (`shardloom-core/src/float_policy.rs:102-120`).
- `widen_f32` is called by Python result-row conversion (`shardloom-python/src/rows.rs:88-91`) and `narrow_f32_exact` by Python Float32 input conversion (`shardloom-python/src/object_input.rs:756-760`). `narrow_f32_exact` also enforces declared F32 output storage; result writing checks the session float policy before storing F32/F64 and rejects F16 (`shardloom-vortex/src/local_primitive_result_batch.rs:872-933`).
- `float_key_bits` is used in retained scalar key normalization (`shardloom-vortex/src/local_primitive_unary_values.rs:290-307`) and pivot key/value identity (`shardloom-vortex/src/local_primitive_unary_pivot_values.rs:140-203`). The helper family has F32/F64-specific policy and payload rules; the inspected files contain no corresponding F16 helper.
- Native numeric owners reject F16 before execution (`shardloom-vortex/src/local_primitives/native_numeric_owner.rs:61-73`); numeric gather access and copy paths likewise exclude F16 (`shardloom-vortex/src/local_primitives/native_relational_numeric_gather.rs:35-69,130-142`). Additional explicit F16 exclusions occur in scalar admission and numeric result/access paths listed above.

### Feature gates and evidence limits

- Arrow conversion module is compiled only with `vortex-local-primitives`, `vortex-write`, `universal-format-io`, and Unix (`shardloom-vortex/src/lib.rs:102-108`). Native payload schema is enabled by local primitives or by write+universal-format-io (`shardloom-vortex/src/lib.rs:115-121`). Tensor/variable-tensor modules require local primitives or write (`shardloom-vortex/src/lib.rs:132-143`); variable-tensor Arrow value validation is further gated by `vortex-write` (`shardloom-vortex/src/native_variable_tensor_arrow.rs:30-34`).
- These are source-level gates and mappings, not runtime verification. The inventory does not establish every optional feature combination, or prove any full Float16 input → compute → output → reopen behavior.

## Search coverage

Read repository `AGENTS.md`, `docs/skills/vortex-internals.md`, `docs/skills/vortex/vortex-concepts.md`, and `docs/skills/vortex/vortex-first-provider-check.md`. Targeted searches covered Float16/F16 occurrences in ShardLoom core, Vortex and Python source; typed schema parsing; payload schema and Arrow conversion; result batches; fixed/variable tensor and embedding validators/tests; Python object input, schema and row conversion; universal-format source schema/scalar conversion; scalar ownership/key helpers; numeric owner/gather exclusions; and vendored Vortex scalar/type support. Reviewed the existing provider inventory at `/Users/dylan/LocalData/shardloom/variable-tensor-lifecycle-2026-11-07/remaining-representations-provider-inventory-r1.md` as context, then independently checked the source anchors above. No builds, tests, benchmarks, network writes, or Git changes were performed; conclusions are static source observations.
