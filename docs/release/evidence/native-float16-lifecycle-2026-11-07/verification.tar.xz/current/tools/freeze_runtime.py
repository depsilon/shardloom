"""Freeze a verified native build outside the shared compiler output."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--build', required=True)
parser.add_argument('--name', required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parents[1]
assert args.name.replace('-', '').isalnum()
build_path = out / args.build
build = json.loads(build_path.read_text())
assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
source = Path(build['environment']['CARGO_TARGET_DIR']) / 'release'
destination = out / args.name
assert not destination.exists()
destination.mkdir()

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            result.update(block)
    return result.hexdigest()

record = {'status': 'passed', 'build_receipt': args.build, 'build_receipt_sha256': sha(build_path), 'files': []}
for name in ('shardloom', 'lib_native.dylib'):
    original, copied = source / name, destination / name
    assert original.is_file() and not original.is_symlink()
    identity = sha(original)
    shutil.copy2(original, copied)
    assert sha(copied) == identity == sha(original)
    record['files'].append({'path': str(copied), 'bytes': copied.stat().st_size, 'sha256': identity})
(out / (args.name + '-identity.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

