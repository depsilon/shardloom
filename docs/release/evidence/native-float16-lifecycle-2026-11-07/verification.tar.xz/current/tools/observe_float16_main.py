"""Record hosted checks for the exact merged Float16 delivery."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess

R = Path(__file__).resolve().parent.parent
W = Path('/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo')
REPO = 'depsilon/shardloom'
CODEQL_PR_ONLY = {'CodeQL', 'CodeQL rust', 'CodeQL python'}
WORKERS = 'Workers Builds: shardloom'
DYNAMIC_PATH_CHECKS = {
    'dynamic/dependabot/update-graph': 'update-pip-graph',
    'dynamic/dependabot/dependabot-updates': 'Dependabot',
}
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--merge', required=True, help='40-character merged commit SHA')
parser.add_argument('--pre', required=True, help='preserved passed_premerge receipt JSON')
parser.add_argument('--name', required=True, help='unique simple receipt name (without suffix)')
args = parser.parse_args()
if not re.fullmatch(r'[0-9a-f]{40}', args.merge):
    parser.error('--merge must be a lowercase 40-character commit SHA')
if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.name):
    parser.error('--name must contain only lowercase letters, digits, and single hyphens')
prepath = Path(args.pre).resolve()
if not prepath.is_file():
    parser.error('--pre must name the preserved PR receipt file')
dest = R / (args.name + '.json')
rawdir = R / (args.name + '-raw')
if dest.exists() or rawdir.exists():
    parser.error('receipt name already exists; choose a new --name')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=W, timeout=60).decode().strip()


def api(endpoint):
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', 'repos/' + REPO + '/' + endpoint],
                                  cwd=W, timeout=50, stderr=subprocess.PIPE)
    if len(raw) > 8 << 20:
        raise ValueError('GitHub response exceeds 8 MiB bound: ' + endpoint)
    return raw, json.loads(raw)


pre_raw = prepath.read_bytes()
pre = json.loads(pre_raw)
assert pre.get('status') == 'passed_premerge', 'PR receipt is not passed_premerge'
head = pre.get('head')
base = pre.get('base')
source_tree = pre.get('source_tree') or pre.get('tree')
assert re.fullmatch(r'[0-9a-f]{40}', head or '') and re.fullmatch(r'[0-9a-f]{40}', base or '')
assert re.fullmatch(r'[0-9a-f]{40}', source_tree or '')
assert git('rev-parse', args.merge) == args.merge
tree = git('rev-parse', args.merge + '^{tree}')
parents = git('show', '-s', '--format=%P', args.merge).split()
assert parents == [base, head], 'merged commit parents differ from preserved PR base/head'
assert tree == source_tree, 'merged commit tree differs from accepted PR source tree'
assert git('rev-parse', head + '^{tree}') == source_tree, 'PR source SHA tree differs from accepted tree'

# The PR receipt's completed-successful names are the contract. The three CodeQL
# names are PR-only per codeql-analysis.yml; the Workers check is added for hosted
# counts. Other workflow triggers are manual or scheduled, not main-push triggers.
pr_checks = pre.get('checks')
if not isinstance(pr_checks, list):
    raise ValueError('PR receipt lacks its preserved checks array; inspect its schema')
successful = {row['name'] for row in pr_checks
              if row.get('status') == 'completed' and row.get('conclusion') == 'success'}
if not successful or not all(isinstance(name, str) and name for name in successful):
    raise ValueError('PR receipt has no completed successful check names')
required_repository = successful - CODEQL_PR_ONLY - {WORKERS}
expected = required_repository | {WORKERS}

rawdir.mkdir()
sources = {}
for label, endpoint in (
    ('checks', f'commits/{args.merge}/check-runs?per_page=100&filter=latest'),
    ('workflows', f'actions/runs?head_sha={args.merge}&per_page=100'),
    ('commit', f'commits/{args.merge}'),
):
    raw, parsed = api(endpoint)
    (rawdir / (label + '.json')).write_bytes(raw)
    sources[label] = parsed
checks, workflows, commit = (sources[k] for k in ('checks', 'workflows', 'commit'))
assert checks.get('total_count') == len(checks.get('check_runs', [])) <= 100
assert workflows.get('total_count') == len(workflows.get('workflow_runs', [])) <= 100
assert commit.get('sha') == args.merge and commit['commit']['tree']['sha'] == tree
assert [row['sha'] for row in commit.get('parents', [])] == [base, head]
assert commit['commit'].get('verification', {}).get('verified') is True
check_rows = checks['check_runs']
run_rows = workflows['workflow_runs']
assert all(row.get('head_sha') == args.merge for row in check_rows + run_rows)
assert len({row['id'] for row in check_rows}) == len(check_rows)

# CI is the only ordinary workflow configured for push to main. Dependabot may
# create dynamic dependency graph workflow runs; accept only the two known paths,
# Dependabot's actor, and check runs proven to belong to that exact successful
# workflow suite and exact merged commit.
push_runs = [row for row in run_rows if row.get('event') == 'push']
non_push_runs = [row for row in run_rows if row.get('event') != 'push']
selected = [row for row in check_rows if row.get('name') in expected]
unexpected_checks = [row for row in check_rows if row.get('name') not in expected]
duplicates = sorted(name for name in expected
                    if sum(row.get('name') == name for row in selected) > 1)
dynamic_run_details = []
dynamic_suite_checks = []
for row in non_push_runs:
    path = row.get('path')
    check_name = DYNAMIC_PATH_CHECKS.get(path)
    actor = (row.get('actor') or {}).get('login')
    suite_id = row.get('check_suite_id')
    admissible = (check_name is not None and actor == 'dependabot[bot]'
                  and row.get('event') == 'dynamic' and row.get('head_sha') == args.merge
                  and row.get('status') == 'completed' and row.get('conclusion') == 'success'
                  and isinstance(suite_id, int))
    matching = [check for check in unexpected_checks
                if check.get('check_suite', {}).get('id') == suite_id]
    exact_checks = [check for check in matching
                    if check.get('name') == check_name and check.get('head_sha') == args.merge
                    and check.get('app', {}).get('slug') == 'github-actions'
                    and check.get('status') == 'completed' and check.get('conclusion') == 'success']
    if not admissible or len(matching) != 1 or len(exact_checks) != 1:
        dynamic_run_details.append({
            'id': row.get('id'), 'name': row.get('name'), 'path': path,
            'event': row.get('event'), 'head_sha': row.get('head_sha'),
            'actor': actor, 'check_suite_id': suite_id,
            'status': row.get('status'), 'conclusion': row.get('conclusion'),
            'classification': 'unexpected-workflow-requires-review'})
        continue
    check = exact_checks[0]
    dynamic_suite_checks.append(check)
    dynamic_run_details.append({
        'id': row['id'], 'name': row.get('name'), 'path': path,
        'event': row['event'], 'head_sha': row['head_sha'], 'actor': actor,
        'check_suite_id': suite_id, 'status': row['status'],
        'conclusion': row['conclusion'], 'accepted_check_id': check['id'],
        'accepted_check_name': check_name, 'accepted_check_app': 'github-actions',
        'classification': 'validated-dependabot-dynamic-workflow'})
accepted_dynamic_check_ids = {row['id'] for row in dynamic_suite_checks}
unmatched_extra_checks = [row for row in unexpected_checks
                          if row['id'] not in accepted_dynamic_check_ids]
workflow_classification = [
    {'id': row.get('id'), 'name': row.get('name'), 'event': row.get('event'),
     'path': row.get('path'), 'head_sha': row.get('head_sha'),
     'classification': ('expected-main-ci' if row.get('event') == 'push' and row.get('name') == 'CI'
                        else next((detail['classification'] for detail in dynamic_run_details
                                   if detail['id'] == row.get('id')),
                                  'unexpected-workflow-requires-review'))}
    for row in run_rows
]
check_classification = [
    {'id': row.get('id'), 'name': row.get('name'), 'status': row.get('status'),
     'conclusion': row.get('conclusion'), 'app': row.get('app', {}).get('slug'),
     'classification': ('required-main-check' if row.get('name') in expected
                        else 'validated-dependabot-dynamic-check' if row.get('id') in accepted_dynamic_check_ids
                        else 'unexpected-check-requires-review')}
    for row in check_rows
]
failures = [{'name': row['name'], 'status': row['status'], 'conclusion': row.get('conclusion')}
            for row in check_rows + run_rows
            if row.get('status') == 'completed' and row.get('conclusion') != 'success']
pending = [{'name': row.get('name'), 'status': row.get('status')}
           for row in check_rows + run_rows if row.get('status') != 'completed']
missing = sorted(expected - {row['name'] for row in selected})
passed_repo = sum(row.get('status') == 'completed' and row.get('conclusion') == 'success'
                  and row.get('name') in required_repository for row in selected)
passed_hosted = sum(row.get('status') == 'completed' and row.get('conclusion') == 'success'
                    for row in selected)
unexpected = bool(unmatched_extra_checks or any(
                    detail['classification'] != 'validated-dependabot-dynamic-workflow'
                    for detail in dynamic_run_details) or duplicates
                  or any(row not in push_runs or row.get('name') != 'CI' for row in push_runs)
                  or len(push_runs) != 1
                  or len(dynamic_suite_checks) != len(non_push_runs))
is_pass = not failures and not pending and not missing and not unexpected \
    and passed_repo == len(required_repository) and passed_hosted == len(expected)
status = 'passed' if is_pass else 'failed' if failures else 'pending' if pending or missing else 'review_required'
result = dict(
    status=status, observed_at=dt.datetime.now(dt.timezone.utc).isoformat(),
    source_commit=args.merge, source_tree=tree, website_tree=git('rev-parse',args.merge+':website'), source_sha=head, pr=pre.get('pr'),
    pr_head=head, pr_base=base, expected_repository_check_names=sorted(required_repository),
    required_hosted_check_names=sorted(expected),
    successful_repository_checks=passed_repo, successful_hosted_checks=passed_hosted,
    observed_check_names=sorted(row.get('name', '') for row in check_rows),
    failed=failures, pending=pending, missing=missing,
    unexpected_checks=check_classification, workflows=workflow_classification,
    unexpected_workflows=[row for row in non_push_runs
                          if not any(detail['id'] == row.get('id') and
                                     detail['classification'] == 'validated-dependabot-dynamic-workflow'
                                     for detail in dynamic_run_details)],
    additional_dynamic_workflows=dynamic_run_details,
    additional_dynamic_checks=[{'id': row.get('id'), 'name': row.get('name'),
                                'head_sha': row.get('head_sha'),
                                'check_suite_id': row.get('check_suite', {}).get('id'),
                                'app': row.get('app', {}).get('slug'),
                                'status': row.get('status'), 'conclusion': row.get('conclusion')}
                               for row in dynamic_suite_checks],
    duplicate_expected_checks=duplicates,
    ci_run_id=push_runs[0].get('id') if len(push_runs) == 1 else None,
    ci_run_url=push_runs[0].get('html_url') if len(push_runs) == 1 else None,
    workers_check=next((row for row in selected if row.get('name') == WORKERS), None),
    commit_verification=commit['commit']['verification'],
    workflow_trigger_assessment={
        'ci': 'push to main and pull_request; main run expected',
        'codeql': 'pull_request, workflow_dispatch, schedule; excluded from main push set',
        'scorecard': 'workflow_dispatch and schedule; no push run expected',
        'pypi': 'workflow_dispatch; no push run expected',
        'dependabot_dynamic': 'only dynamic/dependabot/update-graph or dynamic/dependabot/dependabot-updates, actor dependabot[bot], exact merged SHA, successful exact check suite'},
    premerge_sha256=sha(pre_raw), observer_sha256=sha(Path(__file__).read_bytes()),
    raw_sources={p.relative_to(R).as_posix(): sha(p.read_bytes()) for p in sorted(rawdir.iterdir())},
    production_readiness_claimed=False, production_website_bytes_verified=False)
with dest.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key: result[key] for key in
                  ('status', 'source_commit', 'successful_hosted_checks', 'ci_run_id',
                   'failed', 'pending', 'missing', 'duplicate_expected_checks',
                   'additional_dynamic_workflows')}))
raise SystemExit(0 if is_pass else 1 if failures else 3)

