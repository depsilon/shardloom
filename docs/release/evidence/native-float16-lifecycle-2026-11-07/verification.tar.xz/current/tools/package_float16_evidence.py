"""Bind final Float16 sources, observations, installed proof and prior closeout."""
import argparse
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import zipfile

from verify_float16_packet import LIMITATIONS, MODULES, ROLES, code_path, digest, identity, rust_counts, test_methods, verify

ROOT = Path('/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PRIOR = OUT.parent / 'variable-tensor-lifecycle-2026-11-07'
DEST = ROOT / 'docs/release/evidence/native-float16-lifecycle-2026-11-07'


def read(path):
    return json.loads(path.read_bytes())


assert not DEST.exists()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', default='r1')
args = parser.parse_args()
assert args.attempt.replace('-', '').isalnum()
STAGED = OUT / ('packet-build-' + args.attempt)
assert not STAGED.exists()
plan = read(OUT / 'packet-plan.json')
roles = plan['roles']
assert set(roles) == ROLES
checks = {}
for role, filename in roles.items():
    receipt = read(OUT / filename)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['process_group_drained'], role
    raw = (OUT / filename.removesuffix('.json')).with_suffix('.log').read_bytes()
    assert digest(raw) == receipt['log_sha256']
    checks[role] = dict(receipt=filename, status='passed', command=receipt['command'], rust_tests=rust_counts(raw))
build = read(OUT / roles['build'])
source = {name: info for name, info in build['changed_source_inventory'].items() if code_path(name)}
for name, info in source.items():
    assert identity((ROOT / name).read_bytes()) == info, name
installed = read(OUT / 'installed-proof-r2/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
wheel = OUT / 'installed-proof-r2/dist' / installed['integrity']['wheel']
assert digest(wheel.read_bytes()) == installed['integrity']['wheel_sha256']
package_source = {name: info for name, info in source.items() if name.startswith('python/src/shardloom/')}
with zipfile.ZipFile(wheel) as archive:
    for name, info in package_source.items():
        assert identity(archive.read(name.removeprefix('python/src/'))) == info
    for suffix, key in [('/_native.abi3.so', 'native_library_sha256'), ('/bin/macos-aarch64/shardloom', 'cli_sha256')]:
        names = [name for name in archive.namelist() if name.endswith(suffix)]
        assert len(names) == 1 and digest(archive.read(names[0])) == installed['integrity'][key]
wheel_sources = dict(status='passed', wheel_sha256=installed['integrity']['wheel_sha256'], changed_python_sources=package_source)
wheel_source_path = OUT / 'wheel-source-identity.json'
if wheel_source_path.exists():
    assert read(wheel_source_path) == wheel_sources
else:
    wheel_source_path.write_text(json.dumps(wheel_sources, indent=2) + '\n')

dispositions = read(OUT / 'failure-dispositions.json')
failures = []
for path in sorted(OUT.glob('*.json')):
    value = read(path)
    if value.get('status') == 'failed':
        assert path.name in dispositions and dispositions[path.name]
        failures.append(dict(receipt='current/' + path.name, identity=identity(path.read_bytes()), disposition=dispositions[path.name]))
assert set(dispositions) == {Path(row['receipt']).name for row in failures}
index_name = 'failure-index-' + args.attempt + '.json'
with (OUT / index_name).open('x') as stream:
    json.dump(dict(status='recorded', failures=failures), stream, indent=2)
    stream.write('\n')

files = {}


def add(prefix, path, relative):
    assert path.is_file() and not path.is_symlink(), path
    name = prefix + '/' + relative
    raw = path.read_bytes()
    assert name not in files or files[name] == raw
    files[name] = raw


selected = [*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('source-blobs/*'), *OUT.glob('tools/*.py')]
selected += [path for path in OUT.glob('*.md') if path.name != 'continuation.md']
for directory in ('debug-retirement-r1', 'python-core-r1', 'python-core-r2'):
    selected += [path for path in (OUT / directory).iterdir() if path.is_file()]
selected += [*OUT.glob('installed-proof-*/*.json'), *OUT.glob('installed-proof-*/*.log')]
for path in sorted(set(selected)):
    add('current', path, path.relative_to(OUT).as_posix())
for relative in ('python/tests/test_public_context.py', 'scripts/prove_native_python_wheel.py'):
    add('contracts', ROOT / relative, relative)
dependency_paths = subprocess.check_output(['git', 'ls-files', '-z', 'Cargo.lock', '**/Cargo.toml', 'Cargo.toml',
    'vendor/**/upstream-provenance.json', '.github/provider-locks'], cwd=ROOT).decode().split('\0')
dependencies = {}
for relative in sorted(set(filter(None, dependency_paths))):
    raw = (ROOT / relative).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', build['head'] + ':' + relative], cwd=ROOT)
    add('contracts', ROOT / relative, relative)
    dependencies[relative] = identity(raw)
changed = subprocess.check_output(['git', 'diff', '--name-only', build['head'], '--', 'vendor', 'Cargo.lock', '**/Cargo.toml', 'Cargo.toml', '.github/provider-locks'], cwd=ROOT)
assert not changed
closeout = read(PRIOR / 'variable-closeout-r1.json')
assert closeout['status'] == 'complete' and closeout['merge_commit'] == build['head']
add('prior', PRIOR / 'variable-closeout-r1.json', 'variable-closeout-r1.json')
for relative, info in closeout['receipts'].items():
    assert identity((PRIOR / relative).read_bytes()) == info
    add('prior', PRIOR / relative, relative)
core = read(OUT / 'python-core-r2/core.json')
corelog = (OUT / roles['python_core'].removesuffix('.json')).with_suffix('.log').read_bytes()
count = re.search(rb'Ran (\d+) tests? in [0-9.]+s', corelog)
assert count
expected = sorted(name for module in MODULES for name in test_methods((ROOT / 'python/tests' / (module + '.py')).read_bytes(), module))
report = dict(schema_version='shardloom.float16_lifecycle_acceptance.v1', status='local_acceptance_passed',
    source_base=build['head'], code_snapshot=source, roles=roles, checks=checks,
    archive='verification.tar.xz', members=[dict(path=name, **identity(raw)) for name, raw in sorted(files.items())],
    installed_package=installed['integration'], float16_tests=expected,
    python_core=dict(discovered_test_cases=core['test_count'], reported_test_runs=int(count.group(1)),
        skip_records=core['skipped_count'], failures=core['failure_count'], errors=core['error_count']),
    runtime_identity=plan['runtime_identity'], runtime_and_wheel={key: installed['integrity'][key]
        for key in ('cli_sha256', 'native_library_sha256', 'wheel_sha256')},
    unchanged_dependency_sources=dependencies, dependency_change='none', original_failures=failures, failure_index=index_name,
    limitations=LIMITATIONS, hosted_integration='pending', performance_claim=False,
    publication_attempted=False, whole_item_19_complete=False)
STAGED.mkdir()
with tarfile.open(STAGED / report['archive'], 'w:xz', preset=6) as archive:
    for row in report['members']:
        entry = tarfile.TarInfo(row['path'])
        entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
        archive.addfile(entry, io.BytesIO(files[row['path']]))
report['archive_sha256'] = digest((STAGED / report['archive']).read_bytes())
(STAGED / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
(STAGED / 'verify.py').write_bytes((OUT / 'tools/verify_float16_packet.py').read_bytes())
result = verify(STAGED, ROOT)
shutil.copytree(STAGED, DEST)
for path in STAGED.iterdir():
    assert path.read_bytes() == (DEST / path.name).read_bytes()
print(json.dumps(result))
