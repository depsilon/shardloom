"""Execute the public Float16 example and check all displayed reopened values."""
import ast
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import runpy
import struct
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_binding import _load_native

_load_native()
captured = io.StringIO()
with redirect_stdout(captured):
    runpy.run_path(str(ROOT / 'python/examples/float16_vectors.py'), run_name='__main__')
lines = captured.getvalue().splitlines()
assert lines[0] == 'Exact Float16 values and vector collections reopened from Vortex.', lines
expected = [
    {'id': 2, 'score': None, 'passages': [], 'image': None, 'samples': {'data': [], 'shape': [0, 2]}},
    {'id': 1, 'score': 1.5, 'passages': [[0.5, -0.0, None], [1.0, 2.0, 3.0]],
     'image': [0.5, 1.0, None, 2.0], 'samples': {'data': [1.0, 2.0], 'shape': [1, 2]}},
]
actual = [ast.literal_eval(line) for line in lines[1:]]
assert actual == expected, lines
assert struct.pack('<d', actual[1]['passages'][0][1]) == struct.pack('<d', -0.0)
print(captured.getvalue(), end='')
print(json.dumps({'status': 'passed', 'complete_reopened_rows': len(expected), 'signed_zero_preserved': True}))
