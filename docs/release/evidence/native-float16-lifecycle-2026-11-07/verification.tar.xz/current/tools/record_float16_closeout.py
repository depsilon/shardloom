"""Bind Float16 local proof, exact hosted integration and safe retirement."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo')
PRIOR = OUT.parent / 'variable-tensor-lifecycle-2026-11-07'
PACKET = ROOT / 'docs/release/evidence/native-float16-lifecycle-2026-11-07'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', type=Path, required=True)
parser.add_argument('--main', type=Path, required=True)
parser.add_argument('--reconciliation', type=Path, required=True)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


prep_path = OUT / 'delivery-acceptance-r1.json'
prep, pre, main = read(prep_path), read(args.pre), read(args.main)
assert prep['status'] == 'passed' and prep['runtime_sources_match_build']
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
assert isinstance(pre['pr'], int) and pre['pr'] > 0 and main['pr'] == pre['pr']
number = pre['pr']
assert main['pr_head'] == pre['head'] == prep['head']
assert main['source_tree'] == pre['source_tree'] == prep['tree']
assert pre['base_branch'] == 'main' and pre['tree_matches_synthetic']
assert main['premerge_sha256'] == identity(args.pre)['sha256']
assert pre['acceptance_sha256'] == identity(prep_path)['sha256']
assert pre['review']['commit_sha'] == prep['head'] and pre['review']['status'] == 'completed'
assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
assert main['commit_verification']['verified'] is True
assert not main['failed'] and not main['pending'] and not main['missing']
assert git('rev-parse', 'HEAD') == main['source_commit'] and git('rev-parse', 'HEAD^{tree}') == prep['tree']
assert git('branch', '--show-current') == 'main' and not git('status', '--porcelain')
assert git('show', '-s', '--format=%P', 'HEAD').split() == [pre['base'], prep['head']]
prior = read(PRIOR / 'variable-closeout-r1.json')
assert prior['status'] == 'complete' and prior['merge_commit'] == pre['base'] == prep['base']

prefix = f'pr{number}-final-'
final_checks = read(OUT / (prefix + 'checks-r1.json'))
final_review = read(OUT / (prefix + 'review-r1.json'))
assert final_checks['status'] == final_review['status'] == 'passed'
assert final_checks['head'] == final_review['head'] == prep['head']
assert final_checks['base'] == final_review['base'] == pre['base']
assert final_checks['successful_hosted_checks'] == 58 and final_review['unresolved_threads'] == 0
assert final_checks['premerge_sha256'] == final_review['premerge_sha256'] == identity(args.pre)['sha256']
assert final_review['automated_review'] == pre['review']
for observation in (main, final_checks, final_review):
    for name, checksum in observation['raw_sources'].items():
        path = OUT / name
        assert path.resolve().is_relative_to(OUT) and identity(path)['sha256'] == checksum

acceptance = read(PACKET / 'acceptance.json')
assert acceptance['status'] == 'local_acceptance_passed'
for filename, key in [('acceptance.json', 'acceptance'), ('verification.tar.xz', 'archive'),
                      ('verify.py', 'verifier'), ('corruption-controls.json', 'corruption_controls')]:
    assert identity(PACKET / filename) == prep[key]
for relative, expected in acceptance['code_snapshot'].items():
    assert identity(ROOT / relative) == expected
docs = read(OUT / 'float16-final-docs-r1.json')
assert docs['status'] == 'passed' and docs['process_group_drained'] and docs['direct_child_reaped']
assert identity(OUT / 'float16-final-docs-r1.json') == prep['final_documentation_checks']
assert set(docs['changed_source_inventory']) == set(prep['changed_files'])
for relative, expected in docs['changed_source_inventory'].items():
    assert identity(ROOT / relative) == expected

installed = read(OUT / 'installed-proof-r2/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == acceptance['installed_package']
integration = installed['integration']
assert isinstance(integration['tests'], int) and integration['tests'] > 0
assert all(integration[key] == 0 for key in ('failures', 'errors', 'skipped'))
assert integration['status'] == 'passed'
kept = {}
runtime_and_wheel = acceptance['runtime_and_wheel']
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    path = OUT / 'runtime-r4' / name
    assert identity(path)['sha256'] == installed['integrity'][key] == runtime_and_wheel[key]
    kept[str(path)] = identity(path)
wheel = OUT / 'installed-proof-r2/dist' / installed['integrity']['wheel']
assert identity(wheel)['sha256'] == installed['integrity']['wheel_sha256'] == runtime_and_wheel['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for relative, expected in acceptance['code_snapshot'].items():
        if relative.startswith('python/src/shardloom/'):
            raw = archive.read(relative.removeprefix('python/src/'))
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected
kept[str(wheel)] = identity(wheel)

retirement_path = OUT / 'float16-retirement-r1/receipt.json'
retirement = read(retirement_path)
assert retirement['status'] == 'passed' and retirement['accepted_head'] == prep['head']
assert retirement['accepted_tree'] == prep['tree']
assert retirement['main'] == identity(args.main) and retirement['premerge'] == identity(args.pre)
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
assert not retirement['storage_limits_changed'] and not retirement['payload_backup_created']
applied = read(OUT / 'float16-retirement-apply-r1.json')
assert applied['status'] == 'passed' and applied['process_group_drained'] and applied['direct_child_reaped']
assert identity(OUT / 'float16-retirement-apply-r1.log')['sha256'] == applied['log_sha256']
checkout = read(OUT / 'float16-main-checkout-r1.json')
assert checkout['status'] == 'passed' and checkout['merge_commit'] == main['source_commit']
assert checkout['both_worktrees_clean'] and checkout['accepted_file_trees_unchanged']
reconciliation = read(args.reconciliation)
assert reconciliation['status'] == 'passed' and reconciliation['open_prs'] == [] and reconciliation['pages_complete']

receipts = [prep_path, args.pre, args.main, args.reconciliation, retirement_path,
    OUT / f'pr{number}-create-r1.json', OUT / f'pr{number}-merge-r1.json',
    OUT / (prefix + 'checks-r1.json'), OUT / (prefix + 'review-r1.json'),
    OUT / 'float16-main-checkout-r1.json', OUT / 'precommit-whitespace-r1.json',
    OUT / 'float16-final-docs-r1.json', OUT / 'float16-final-docs-r1.log',
    OUT / 'float16-package-r1.json', OUT / 'float16-package-r1.log',
    OUT / 'float16-packet-controls-r1.json', OUT / 'float16-packet-controls-r1.log',
    OUT / 'float16-retirement-r1/plan.json', OUT / 'float16-retirement-r1/manifest.json.xz',
    OUT / 'float16-retirement-plan-r1.json', OUT / 'float16-retirement-plan-r1.log',
    OUT / 'float16-retirement-apply-r1.json', OUT / 'float16-retirement-apply-r1.log',
    OUT / 'installed-proof-r2/report.json',
    *[OUT / 'tools' / (name + '.py') for name in (
        'prepare_float16_delivery', 'final_float16_review', 'watch_float16_pr',
        'advance_float16_main', 'observe_float16_main', 'watch_float16_main',
        'retire_float16_intermediates', 'record_float16_closeout')]]
receipts += [OUT / name for observation in (main, final_checks, final_review)
             for name in observation['raw_sources']]
receipts = sorted(set(receipts))
assert all(path.resolve().is_relative_to(OUT) for path in receipts)
external_helper = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
plan = read(OUT / 'float16-retirement-r1/plan.json')
assert identity(external_helper)['sha256'] == plan['helper_sha256']

report = dict(status='complete', observed_at=datetime.now(timezone.utc).isoformat(),
    pr_url=f'https://github.com/depsilon/shardloom/pull/{number}', pr_head=prep['head'],
    merge_commit=main['source_commit'], source_tree=prep['tree'],
    pr_checks_passed=58, main_checks_passed=55, review_findings=False,
    review_url=pre['review_url'], main_ci_url=main['ci_run_url'], no_open_prs_at_observation=True,
    validation=acceptance['checks'], installed_package=integration,
    runtime_sources_match_build=True, runtime_source_proof=prep['runtime_source_proof'],
    retired_regular_files=retirement['regular_files'], retired_symlinks=retirement['symlinks'],
    current_inputs_unchanged=True, portable_replay_after_retirement='passed',
    retained_runtime_and_wheel=kept,
    committed_evidence={path.relative_to(ROOT).as_posix(): identity(path) for path in sorted(PACKET.iterdir())},
    receipts={path.relative_to(OUT).as_posix(): identity(path) for path in receipts},
    retirement_primitives=dict(path=str(external_helper), **identity(external_helper), source=external_helper.read_text()),
    prior_variable_tensor_closeout=identity(PRIOR / 'variable-closeout-r1.json'),
    closeout_script=identity(Path(__file__)), working_tree_clean=True,
    performance_claim=False, publication_attempted=False, whole_item_19_complete=False,
    limitations=acceptance['limitations'])
with (OUT / 'float16-closeout-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'merge_commit', 'pr_checks_passed',
    'main_checks_passed', 'installed_package', 'retired_regular_files')}))
