"""Preserve fresh current-head check and review state before the authorized merge."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-float16-lifecycle/shardloom-local-repo')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', required=True, type=Path)
args = parser.parse_args()
pre = json.loads(args.pre.read_bytes())
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert isinstance(pre['pr'], int) and pre['pr'] > 0 and pre['tree_matches_synthetic']
number = pre['pr']
head, base = pre['head'], pre['base']
required = {row['name'] for row in pre['checks']}
assert len(required) == 58
prefix = 'pr' + str(number) + '-final-'
rawdir = OUT / (prefix + 'raw-r1')
assert not rawdir.exists()
checks_path, review_path = [OUT / (prefix + label + '-r1.json') for label in ('checks', 'review')]
assert not checks_path.exists() and not review_path.exists()
rawdir.mkdir()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def request(name, arguments):
    raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', *arguments],
        cwd=ROOT, stderr=subprocess.PIPE, timeout=50)
    assert len(raw) < 8 << 20
    (rawdir / (name + '.json')).write_bytes(raw)
    return json.loads(raw)


def api(name, path):
    return request(name, ['repos/depsilon/shardloom/' + path])


common = dict(status='needs_attention', pr=number, head=head, base=base,
    observed_at=datetime.now(timezone.utc).isoformat(), premerge_sha256=digest(args.pre.read_bytes()),
    observer_sha256=digest(Path(__file__).read_bytes()))
checks_report, review_report = dict(common), dict(common)
try:
    pr = api('pull', f'pulls/{number}')
    assert pr['head']['sha'] == head and pr['base']['sha'] == base and pr['base']['ref'] == 'main'
    assert pr['state'] == 'open' and not pr['draft'] and pr['mergeable'] is True
    checks = api('checks', f'commits/{head}/check-runs?per_page=100&filter=latest')
    rows = checks['check_runs']
    assert len(rows) == checks['total_count'] == len(required)
    assert {row['name'] for row in rows} == required
    assert all(row['head_sha'] == head and row['status'] == 'completed'
               and row['conclusion'] == 'success' for row in rows)
    checks_report.update(status='passed', successful_hosted_checks=len(rows),
        required_check_names=sorted(required), mergeable=True)
    comments = api('comments', f'issues/{number}/comments?per_page=100')
    assert len(comments) < 100
    states = [(json.loads(match.group(1))['code_review'], row['html_url']) for row in comments
        if row['user']['login'] == 'chatgpt-codex-connector[bot]'
        and (match := re.search(r'<!-- codex-review-state:v1 (.*?) -->', row['body']))]
    current = [(state, url) for state, url in states if state.get('commit_sha') == head]
    assert len(current) == 1
    review, review_url = current[0]
    assert review['status'] == 'completed'
    assert review['has_any_findings'] is review['has_unresolved_findings'] is False
    query = 'query($n:Int!){repository(owner:"depsilon",name:"shardloom"){pullRequest(number:$n){reviewDecision mergeable headRefOid baseRefOid reviewThreads(first:100){nodes{id isResolved isOutdated} pageInfo{hasNextPage}} reviews(first:100){nodes{state author{login}} pageInfo{hasNextPage}}}}}'
    audit = request('review', ['graphql', '-F', 'n=' + str(number), '-f', 'query=' + query])['data']['repository']['pullRequest']
    assert audit['headRefOid'] == head and audit['baseRefOid'] == base and audit['mergeable'] == 'MERGEABLE'
    assert all(not audit[key]['pageInfo']['hasNextPage'] for key in ('reviewThreads', 'reviews'))
    assert all(row['isResolved'] for row in audit['reviewThreads']['nodes'])
    assert audit['reviewDecision'] != 'CHANGES_REQUESTED'
    review_report.update(status='passed', automated_review=review, review_url=review_url,
        unresolved_threads=0, audit=audit)
except BaseException as error:
    message = type(error).__name__ + ': ' + str(error)
    checks_report['observation_error'] = review_report['observation_error'] = message
    raise
finally:
    raw_sources = {path.relative_to(OUT).as_posix(): digest(path.read_bytes()) for path in sorted(rawdir.iterdir())}
    for path, report in ((checks_path, checks_report), (review_path, review_report)):
        report['raw_sources'] = raw_sources
        with path.open('x') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
print(json.dumps(dict(checks=checks_report['status'], review=review_report['status'], head=head, base=base)))

