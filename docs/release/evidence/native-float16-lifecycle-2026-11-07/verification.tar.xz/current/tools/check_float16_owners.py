"""Run focused ownership and admission regressions against the first native build."""
import hashlib
from pathlib import Path
import subprocess

binary = Path('/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-fc8874ac18e9a047')
print('Native test binary SHA256:', hashlib.sha256(binary.read_bytes()).hexdigest(), flush=True)
for name in ('numeric_output_copy', 'numeric_gather', 'numeric_expression_left_preparation',
             'tensor_', 'malformed_typed_schemas', 'nested_intake_checks',
             'native_nested_schema_admission', 'unary_nested_pivot_rejects'):
    listing = subprocess.check_output([str(binary), '--list', name], text=True)
    assert ': test' in listing, name
    print(listing, flush=True)
    subprocess.run([str(binary), '--test-threads=2', name], check=True, timeout=240)
