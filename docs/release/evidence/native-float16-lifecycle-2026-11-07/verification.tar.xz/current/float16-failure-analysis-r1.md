# Float16 initial lifecycle observations

The original `python-native-float16-r1` used frozen `runtime-r1` and ran all 14
new binding tests. It recorded four failed assertions and eight errors. The
complete all-65,536-pattern Vortex, IPC and Parquet test passed, as did exact
Python construction/row extraction, mixed join/spill/stream/reopen, streaming
failure cleanup, and zero-width/empty recursive types.

Harness corrections were checked against the existing float-policy tests and
the actual admission owners:

- A context-created frame inherits resource settings, while a new `sl.sql`
  frame over its client needs an explicit action allocation. The new helper
  now supplies that allocation.
- An embedded workflow inherits its immutable native Session float policy;
  the workflow argument grammar does not accept the CLI's `--float-policy`.
- File dictionary admission is separate from the feature-gated caller-owned
  encoded Arrow transport, which does not admit float dictionaries. The test
  now uses a real independent IPC dictionary file and preserves strict checking
  of the complete valid dictionary value domain.
- Opaque native-file selection may carry nonfinite bits under strict policy;
  scalar arithmetic, comparison and ordering are the observation boundaries.
  The test now checks both retained carriage and all three refusals.
- Direct third-party Arrow stream reads promote registered tensor metadata to
  extension types. The control now compares both schemas through PyArrow's
  independent IPC interpretation, with complete storage/nullability/metadata
  equality and unchanged full row-bit checks.

`python-native-float16-r2`, still using `runtime-r1`, passed 12 of 14 tests and
isolated two implementation gaps. Mixed Float16/Float64 UNION ALL passed the
selected half through an ordinary provider cast, which quieted its signaling
NaN before the result owner received it. Avro's default provider writer widens
Float16 to Float32, causing the reopened-schema check to reject only after
writer execution. Output cleanup passed, but the intended preflight diagnostic
and producer boundary were missing.

The follow-up writes promoted Float64 results through the existing exact-bit
numeric owner and rejects recursive Float16 Avro/ORC schemas before a producer
is opened. Additional tests cover common-type conditional/coalesce results,
strict selected-value validation, discarded branches, exhaustive reversed
promotion and null selection, and failed streaming fanout before consumption.
These new changes require their own build and validation; this note does not
turn either original failed run into an accepted one.

`python-native-float16-r3` used the rebuilt and frozen `runtime-r2`. Both original
implementation gaps passed, including the recursive Avro/ORC stream preflight.
The new strict UNION test then exposed missing finite validation in the direct
promotion writer: numeric owners expose original values, while their consumers
must apply the floating policy. The promotion now invokes the existing numeric
output validator for each selected valid value and checks cancellation after
construction. A native regression covers selected finite values, negative zero,
hidden null payloads and an observed signaling NaN. The other r3 failure was
the expected COALESCE schema: a nonnullable literal default correctly makes its
result nonnullable. The reference now asserts that exact schema, while keeping
unchanged bitwise value checks. Complete r3 receipt and log remain preserved.

The first two default Clippy attempts rejected a manual leading-bit expression
and a verbose zero-magnitude mask in the new core tests. They now use `ilog2`
and an exact trailing-zero check respectively. Native Clippy r1 identified
duplicate dtype match arms and now-infallible primitive conversion helpers:
admitting Float16 covers every primitive variant, so the obsolete `Result` and
`Option` wrappers were removed. Native Clippy r2 then caught callers still using
the former wrappers. All call sites were updated; the JSON writer keeps its
separate finite-value condition and unsupported-domain error. These attempts
remain failed observations; later native Clippy r3 and r4 pass.

The first full native workspace test run stopped at a CLI regression assertion
that expected the old `F32/F64` diagnostic text. The diagnostic correctly lists
`F16/F32/F64` after admission. The assertion was updated without changing the
Variant rejection or its no-fallback boundary. Both default workspace test runs
pass all 3,321 cases. Native workspace r2 and the remaining acceptance checks
must finish before overall acceptance can be claimed. Sequence wrapper failures
remain separate from the failed stage receipts and retain their original logs.

Native workspace r2 completed its full Vortex test binary with exactly one
failed assertion: the existing empty-input test requires the diagnostic phrase
`retaining field nullability`. The Float16 admission change had inserted
`exact type and` within that phrase. All remaining spill and recovery tests
passed. The original nested diagnostic is now preserved, with a separate
Float16-specific refusal. The same regression test now checks Float16-only and
nested empty schemas, both nullable settings and buffered, streamed and budgeted
ingest. Clearing the typed RecordBatch must still reject before publication.
The original stage and sequence receipts remain failed observations; their
replacement checks are separate evidence.

The extended focused check `float16-empty-ingest-r1` then exposed a second
empty-input issue: buffered readers synthesized a typed empty RecordBatch only
for nested schemas. A schema-only Float16 IPC file therefore reached the
intentional schemaless refusal. The reader now retains a typed empty batch for
Float16 as well, preserving the original Field nullability and metadata. The
regression additionally checks the retained source batch and schema directly;
the writer still refuses if a caller removes that batch. The failed focused
receipt and its full log remain preserved.

A follow-up source review found the same risk for a top-level Float16-valued
dictionary with no batches. Native workspace r3 was deliberately interrupted
through the unchanged supervisor before completing; its process group drained
and its stopped receipt is retained, not presented as a complete test result.
The expanded focused r3 reproduced the missing typed batch. The correction
preserves the dictionary's Arrow dtype hint and retains its typed empty batch,
while still refusing if a caller removes that batch. Focused r4 passes plain,
dictionary and nested cases with both nullabilities through all three ingest
modes. The previous release-r3/installed-r1 run remains an observation of the
earlier source; fresh final runtime/package checks are required.
