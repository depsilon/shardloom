# Float16 remaining allowlist inventory (R2)

Read-only inventory for the November 7 Float16 lifecycle contract. Scanned production `.rs` and `.py` files under `shardloom-vortex/src`, `shardloom-python/src`, and `python/src/shardloom`; excluded tests, vendor and dependency trees. This records observed dispatch behavior, not a judgment that any gate is unintended. Line numbers refer to the scanned checkout at inventory time.

## Residual explicit gates and limited dispatch

| Location | Enclosing function / site | Exact observed effect |
|---|---|---|
| `shardloom-vortex/src/local_primitives/native_relational_expression_scalar_operand.rs:72-98` | `admit` | The optional scalar-operand specialization only admits output and array types both `F64` with an `F64` literal. For Float16 operands it returns `None`, so this specialization does not run. |
| `shardloom-vortex/src/local_primitives/native_relational_aggregate_typed_state.rs:112-145` | `admit_measure` | The typed aggregate-state specialization returns `None` when `input == F16`; callers cannot use this specialization for Float16 input. This is the explicitly identified optional specialization exclusion. |
| `shardloom-vortex/src/local_primitives/native_relational_window_records.rs:42-74` | `Kind::new` | Stored framed SUM/AVG/SUM DISTINCT/AVG DISTINCT/MEDIAN/QUANTILE output accepts decimal or nullable F64 only. A different bound output dtype returns `stored window reduction has an unsupported bound output type`. |
| `shardloom-vortex/src/local_primitives/native_relational_window_frame_state.rs:284-305` | window quantile evaluation | Non-decimal interpolated quantile output is explicitly built as nullable F64; interpolation is performed in that output dtype. |
| `shardloom-vortex/src/local_primitives/native_relational_expression.rs:728-740` | binary expression evaluator | Floating arithmetic is selected only when the bound output dtype is F64. Other outputs take the integer conversion/evaluation branch. This is an output-type dispatch; source input dtype alone does not establish whether Float16 arithmetic reaches it. |
| `shardloom-python/src/expression.rs:221-240` | Python `Expression.cast` | The explicit scalar cast-name arms cover bool, int64, uint64, float64, utf8, binary and temporal types. Float16/float32 names fall through to temporal parsing or `LogicalDType::Extension(name)`; this method does not construct a Float16 scalar logical dtype. |
| `python/src/shardloom/query.py:10605-10630` | `_normalize_cast_dtype` | SQL/Python cast normalization allowlists float64 but not float16 or float32; unsupported names raise `ValueError` listing admitted cast types. |
| `python/src/shardloom/query.py:10928-10953` | typed scalar cast payload validation | `supported_dtype` admits float64 aliases but not float16/float32; with null input, an unrecognized float16/float32 target is not represented as a typed null payload. |
| `python/src/shardloom/query.py:13257-13280` | `_normalize_schema_dtype_token` | The alias mapping includes float/f64/float64 and omits f16/float16 (and f32/float32); those tokens are returned unchanged after normalization rather than canonicalized to the corresponding float token. |
| `python/src/shardloom/adbc.py:79-90` | ADBC parameter batch conversion | Scalar parameter `supported` mapping contains `pa.float64()` only; a Float16 or Float32 parameter dtype has no exact native scalar contract and raises the explicit cast-before-binding error. |

## Nearby paths observed to admit Float16

These were checked to avoid reporting a missed gate where Float16 is already explicit:

- `shardloom-vortex/src/local_primitives/native_numeric_owner.rs:35-47` dispatches `PType::F16` to the existing `f16` numeric implementation.
- `shardloom-vortex/src/local_primitives/native_payload_storage.rs:32-67` copies F16 data at two-byte stride and reconstructs `PrimitiveArray<f16>`.
- `shardloom-vortex/src/local_primitives/native_relational_records.rs:82-150` preserves F16 records through U16 bit storage, exact narrowing, and reconstruction.
- `shardloom-vortex/src/local_primitives/native_relational_sort_numeric.rs:20-90` admits F16 sort keys and compares widened raw-bit values through the existing float ordering.
- `shardloom-vortex/src/local_primitive_result_numeric.rs:128-143` validates F16 values under float policy; `local_primitive_result_batch.rs:891-939` exactly narrows and builds F16 columns.
- `shardloom-vortex/src/native_arrow_conversion.rs:72-85`, `native_tensor_arrow.rs:35-55,85-96`, and `native_embedding_arrow.rs:40-50,60-101` include F16 Arrow mapping.
- `shardloom-python/src/rows.rs:85-97` widens Float16 by raw bits before Python scalar extraction; `object_input.rs:291-301,392-418` builds Float16 input columns; `schema.rs:24-37` names Float16 schema fields.
- Python result schema decodes `f16` at `python/src/shardloom/_result_schema.py:20-26`; Python input schema and tensor/embedding element allowlists include float16 at `_input_schema.py:23-28,200-205,364-370`, `_tensor.py:10`, and `_result_schema.py:95-98`.

## Scope exclusions and uncertainty

- Excluded by assignment as intentional: `encoded_numeric_reduction.rs` optional reduction specialization; `native_relational_aggregate_typed_state.rs` optional specialization noted above; `local_primitives.rs::stat_value_to_vortex_literal` F16 rejection because public typed predicates exclude floating fields; dictionary integer indices; compatibility text/Avro/ORC and table logical-format mapping restrictions.
- Core scalar IR remains Float64; inferred Python floats remain Float64; the existing scalar-literal route remains in its declared result domain. The Python scalar literal implementation at `shardloom-python/src/expression.rs:90-110` constructs `ScalarValue::Float64` for Python floats.
- Some listed gates are optimizations, SQL cast capabilities, or result-domain choices. This scan does not establish whether they should change or whether a higher-level route intentionally handles the request elsewhere. In particular, the expression arithmetic output gate is not proof that source Float16 arithmetic is rejected.
- The inventory is limited to name/match/allowlist sites matching F32/F64/Float32/Float64 in the three assigned production source roots; it does not claim a proof of complete runtime reachability or enumerate ordinary Float64-register operations.
