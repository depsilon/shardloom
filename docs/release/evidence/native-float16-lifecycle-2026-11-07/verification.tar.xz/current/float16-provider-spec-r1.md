# Float16 provider and format source packet (r1)

Read-only source inventory, captured 2026-11-07 at repository head `c47eeefa0`.
This records provider/format capability separately from ShardLoom admission; it
does not establish a ShardLoom Float16 lifecycle or bit-preserving round trip.

## Pinned versions

| Component | Resolved/documented version | Evidence |
| --- | --- | --- |
| `half` Rust scalar provider | 2.7.1 | `Cargo.lock:1470-1475`; [versioned `f16` API](https://docs.rs/half/2.7.1/half/struct.f16.html) |
| Arrow Rust array | 59.3.1 | `Cargo.lock:153-169`; workspace vendored source `vendor/arrow-array/src/array/primitive_array.rs:214,1463` |
| Arrow Rust IPC | 59.3.1 | `Cargo.lock:278-291`; vendored `vendor/arrow-ipc/src/convert.rs:351,629-634` |
| Arrow Rust schema | 59.3.2 | `Cargo.lock:356-364`; Float16 is a schema `DataType` in the lock-resolved registry source `arrow-schema-59.3.2/src/datatype.rs:118,730`; this crate is not vendored |
| Rust Parquet | 59.3.1 | `Cargo.lock:2415-2435`; vendored provider mappings cited below |
| PyArrow API reference | 25.0.1 | [versioned `pyarrow.float16`](https://arrow.apache.org/docs/25.0/python/generated/pyarrow.float16.html) and [versioned `pyarrow.ipc.new_file`](https://arrow.apache.org/docs/25.0/python/generated/pyarrow.ipc.new_file.html). This is documentation evidence, not a claim that PyArrow is installed in this worktree. |

## Representation and interchange contract

- Binary16 has 16 total bits, one sign bit, five exponent bits and ten fraction
  bits (11 bits of precision for normal values). The pinned `half` source
  `half-2.7.1/src/binary16.rs:395-401,477,725-737` exposes the exponent mask
  `0x7c00`, fraction mask `0x03ff`, sign test and normal exponent limits. This
  provides inspectable provider evidence for the layout and bias 15. The
  [IEEE 754-2019 listing](https://standards.ieee.org/ieee/754/6210/) identifies
  the standard; this packet did not inspect its complete normative tables.
  The provider distinguishes signed zero, subnormals, infinities, and quiet
  and signaling NaNs. Layout support does not establish exact NaN conversion.
- Arrow’s [format definition](https://arrow.apache.org/docs/25.0/format/Columnar.html#byte-order-endianness)
  defines `HALF` floating precision and a fixed-size primitive value layout;
  Arrow IPC record/dictionary batch bodies are little-endian by default, with
  schema metadata carrying the body endianness. `Schema.fbs` names the type
  `Precision::HALF` ([Arrow 25.0.0 source, line 155](https://github.com/apache/arrow/blob/apache-arrow-25.0.0/format/Schema.fbs#L155)).
- The Parquet format’s [`FLOAT16` logical type](https://github.com/apache/parquet-format/blob/master/LogicalTypes.md#float16)
  is a two-byte IEEE little-endian value stored as `FIXED_LEN_BYTE_ARRAY(2)`.
  Its sort order handles NaNs and signed zeros specially; writers should use
  `IEEE754TotalOrder`. That ordering rule is not evidence of payload-bit
  preservation through value conversions.
- In the pinned Rust `half` provider, `f16::from_bits`/`to_bits` expose the raw
  16-bit encoding; `from_le_bytes`/`to_le_bytes` provide explicit portable byte
  order. Widening f16 to f32/f64 is documented lossless for values; narrowing
  from f32/f64 is lossy, rounds to representable values, can overflow to
  infinity/underflow to zero, and documents NaN values as preserved. These APIs
  do not promise preservation of every NaN payload through numeric conversion.
  The source's own NaN conversion tests explicitly note nondeterministic
  f32/f64 NaN conversion signs (`binary16.rs:1588,1615`). Raw-bit constructors
  and byte copies are the appropriate fidelity boundary for supplied NaNs.

## Provider capability evidence

### Rust Arrow and IPC

- `arrow-array` 59.3.1 defines `Float16Array = PrimitiveArray<Float16Type>`
  (`vendor/arrow-array/src/array/primitive_array.rs:214`); `Float16Type` is
  backed by `half::f16` (`vendor/arrow-array/src/types.rs:40,145-147` and
  `primitive_array.rs:1463`). Primitive builders and generic array construction
  also include `DataType::Float16` (`vendor/arrow-array/src/builder/primitive_builder.rs:44`,
  `builder/mod.rs:461`, `array/mod.rs:901`). This is typed-array support, not a
  ShardLoom importer/exporter admission finding.
- `arrow-ipc` 59.3.1 decodes IPC `Precision::HALF` to `DataType::Float16`
  (`vendor/arrow-ipc/src/convert.rs:351`) and encodes `DataType::Float16` as
  `Precision::HALF` (`convert.rs:629-634`). Its reader accepts Float16 in the
  supported primitive path (`vendor/arrow-ipc/src/reader.rs:903`) and has a
  Float16 schema test (`reader.rs:4029`). Generic PyArrow IPC file writing
  accepts a schema and record batches; together with PyArrow’s `float16()` and
  array construction example, this is API/provider evidence, not an observed
  cross-language round trip (`pyarrow.float16` and `pyarrow.ipc.new_file` links
  above).

### Rust Parquet

- Arrow-to-Parquet writer maps Arrow Float16 values through `Float16Array`
  (`vendor/parquet/src/arrow/arrow_writer/mod.rs:1768-1771`; write helper at
  `:1900`).
- Parquet schema mapping emits `FIXED_LEN_BYTE_ARRAY(2)` with `LogicalType::FLOAT16`
  (`vendor/parquet/src/arrow/schema/mod.rs:621-626`).
- Parquet-to-Arrow schema mapping returns `DataType::Float16` only for the
  Float16 annotation over the two-byte fixed-length physical type; other width
  is rejected (`vendor/parquet/src/arrow/schema/primitive.rs:349-357`).
- Reader source includes Float16 and nullable Float16 data in its round-trip
  fixture (`vendor/parquet/src/arrow/arrow_reader/mod.rs:2131-2185`). This is
  crate-level support evidence; it does not prove a ShardLoom Parquet lifecycle.

### PyArrow 25.0.1

- The versioned API exposes `pyarrow.float16()` as the half-precision Arrow
  type (`halffloat`) and shows construction from a NumPy `float16` array,
  including `NaN` (`https://arrow.apache.org/docs/25.0/python/generated/pyarrow.float16.html`).
- `pyarrow.ipc.new_file(sink, schema, ...)` creates an Arrow IPC file writer
  whose schema determines column types (`https://arrow.apache.org/docs/25.0/python/generated/pyarrow.ipc.new_file.html`).
  Combined with the Arrow IPC format support above, the documented API surface
  can express a Float16 column. The API example is not a proof of raw NaN payload
  preservation, nor a PyArrow↔Rust test result.

## ShardLoom admission status and limits

- ShardLoom’s current `native_payload_schema.rs:19` excludes `PType::F16` from
  admitted scalar types. Ordinary nested Arrow leaf admission also excludes it
  (`native_payload_schema.rs:200` and the Arrow leaf match at `:326-387`).
- The ordinary Vortex-to-Arrow mapper explicitly returns `None` for `PType::F16`
  (`native_arrow_conversion.rs:73-85`). Fixed-tensor and variable-tensor Arrow
  element whitelists also exclude it (`native_tensor_arrow.rs:18-40,77-93` and
  `native_variable_tensor.rs:299-311`).
- The universal-format source schema hint maps Float16, Float32, and Float64 to
  Float64 (`universal_format_io.rs:4495-4498`), which is a widening hint, not
  Float16 fidelity. The prior inventory also records typed JSON/Python
  Float16 refusals and their source locations in
  [`remaining-representations-provider-inventory-r1.md`](remaining-representations-provider-inventory-r1.md).
- Therefore upstream Arrow/Parquet/PyArrow capability must not be reported as
  ShardLoom read, write, compute, tensor, Python, or full lifecycle support.
  No cross-boundary Float16 NaN-payload, signed-zero, subnormal, IPC, or Parquet
  ShardLoom round-trip proof was found in this source-only collection.

## Primary references

- [IEEE SA: IEEE 754-2019](https://standards.ieee.org/ieee/754/6210/)
- [Arrow Columnar Format v25.0.1: endianness](https://arrow.apache.org/docs/25.0/format/Columnar.html#byte-order-endianness)
- [Arrow 25.0.0 `Schema.fbs`: `Precision::HALF`](https://github.com/apache/arrow/blob/apache-arrow-25.0.0/format/Schema.fbs#L155)
- [Parquet format: `FLOAT16`](https://github.com/apache/parquet-format/blob/master/LogicalTypes.md#float16)
- [Rust `half` 2.7.1 `f16` API](https://docs.rs/half/2.7.1/half/struct.f16.html)
- [PyArrow 25.0.1 `float16`](https://arrow.apache.org/docs/25.0/python/generated/pyarrow.float16.html)
- [PyArrow 25.0.1 IPC file writer](https://arrow.apache.org/docs/25.0/python/generated/pyarrow.ipc.new_file.html)

Primary review verified the material Arrow/Parquet maps, pinned half layout and
conversion caveats, and current official PyArrow/half/format pages. It corrected
the nonexistent vendored arrow-schema path and invalid Schema.fbs line anchor,
and bounded the IEEE listing claim. This remains source evidence only.
