# Float literal conversion call graph (r1)

Read-only source findings at `c47eeefa0` in `shardloom-vortex/src`. No Float16 semantics are proposed here.

## Direct call graph and error flow

1. `local_primitives.rs::predicate_to_vortex_expr` handles `PredicateExpr::Compare` at `local_primitives.rs:48664-48679`. It resolves `(lhs, field_dtype)` with `predicate_field_expr`, then calls `stat_value_to_vortex_literal(...)?` at `:48665-48671`; any conversion error immediately returns from `predicate_to_vortex_expr` before it constructs a Vortex comparison expression.
2. `local_primitives.rs::in_list_to_vortex_expr` loops non-NULL members at `:48735-48746`. Each calls `stat_value_to_vortex_literal(...)?` at `:48739-48744`; an error aborts list construction and propagates. NULL members bypass conversion and are tracked separately (`:48735-48738`).
3. `local_primitives.rs::stat_value_to_vortex_literal` is defined at `:48913-48976`. For a primitive dtype, F32 uses `lit(stat_value_to_f64(value)? as f32)` (`:48963-48965`); F64 uses `lit(stat_value_to_f64(value)?)` (`:48964-48965`); F16 explicitly returns `InvalidOperation` (`:48966-48969`). `stat_value_to_f64` at `:49053-49064` returns Float64 directly and casts Int64/UInt64 with `as f64`; other literal families error.
4. The caller is `attach_predicate_to_scan_plan` (`local_primitives.rs:47789-47842`): after rewrite and pushdown/residual splitting, it calls `predicate_to_vortex_expr(...)?` for the pushdown part at `:47834-47840`. The error propagates from `attach_predicate_to_scan_plan` to its enclosing planner. Direct attachment call sites use `?` at `local_primitives.rs:7520,7539,7552,14625,14678,14810,14853,20024,20238,20428,20623,20821,47893,47971`; these therefore fail plan construction on a pushed-literal conversion error rather than dropping or rewriting the predicate.
5. Other `predicate_to_vortex_expr` invocations found are recursive conjunction mapping at `local_primitives.rs:48645-48648`, plus callers at `:21633,22086,22129,22187,22239,22317,22370,22430,23049,23714,24573,25482,47835`, and test-only direct calls at `:49483,49490`. Their immediately enclosing expressions use `?`/`Result` propagation (for the `.map` call at :21633, collection/use follows the `Result` path). No caller catches this literal-conversion error and substitutes another evaluator in the inspected paths.

## Eligibility before narrowing

- `predicate_field_expr` (`local_primitives.rs:48884-48911`) accepts any primitive dtype for the implicit `value` field or a found struct child; it does not validate the predicate literal’s representability. It returns the declared field dtype unchanged.
- Legacy unary schema `predicate_types` (`local_primitive_unary_schema.rs:29-49`) admits Bool, UTF8, or any primitive for predicates. `retained_source_admitted` invokes this before scanning (`:51-68`) but does not compare literals against Float32/Float64 limits. Other typed binding includes `validate_predicate_fields` (`local_primitive_relational_bind.rs:952-965`), which validates the field via `validate_scalar`; it likewise does not validate literal value representability. These checks are field-family gates, not exact float narrowing checks.
- `split_predicate_for_vortex_pushdown` at `local_primitives.rs:48816-48846` sends all non-`And` predicate variants through pushdown; it does not inspect numeric dtype/value. `attach_predicate_to_scan_plan` then attempts literal conversion (`:47804-47840`).
- At the actual conversion, Float32 narrowing is a Rust `as f32` cast (`local_primitives.rs:48964`), with no finite check, exact round-trip check, overflow check, or nonrepresentability refusal in this helper. Float64 accepts the `f64` from `stat_value_to_f64`; integer-to-f64 casts there are also not checked for exactness (`:49055-49063`).
- Consequently source does not show a pre-narrowing exactness gate for a Float64 literal converted to Float32 in this Vortex pushdown helper. This is a source fact, not a conclusion about upstream Vortex’s later evaluation semantics.

Primary review adds the public typed-provider boundary omitted by that helper
inventory: `local_primitive_relational_provider_plan.rs:701-751` deliberately
admits only Bool, UTF8 and integer fields to predicate pushdown, so **all floating
predicates already retain shared relational evaluation**, including nonrepresentable
Float32 thresholds. `local_primitive_relational_provider.rs:82-87` also declines
the whole optional provider for extended float policy. The legacy helper's
narrowing behavior therefore does not establish a bug in the public typed path.
`local_primitive_prepared_dispatch.rs:141-176` routes rich/decimal/extension
source types to that shared relational path. Float16 can use the same existing
type-based admission boundary while its optional legacy specializations remain
unadmitted; no lossy Float16 predicate literal conversion is necessary.

## General native float filter path

- A separate general native row-filter path is `NativeNumericOwner::compare_rows` → `compare_typed` (`local_primitives/native_numeric_owner.rs:751-760,761-788`). It obtains a typed RHS through `T::Wide::compare_rhs` and compares each valid source value after `value.widen()` (`:768-779`). For F32, `Numeric for f32` chooses `Wide=f64` and calls ShardLoom’s bit-aware `float_policy::widen_f32` (`:840-844`). Thus source F32 values compare in an F64 register against the coerced F64 threshold; this path does not narrow that threshold to F32.
- For this path, `Wide for f64::compare_rhs` calls `coerce_compare_rhs_f64` (`native_numeric_owner.rs:911-940`); the latter preserves Float64, casts integer thresholds to f64, and returns a Float64 RHS (`local_primitives.rs:11468-11485,13990-14045`). `fast_compare_row_indices_from_accessor` dispatches NativeNumeric to `owner.compare_rows` (`local_primitives.rs:11209-11218`); its legacy Float64 accessor branches also route to F64/F64 comparison (`:11255-11266`).
- This establishes a F32-to-F64 value widen and F64 threshold comparison in the general native accessor path; it does not establish the correctness of the separate Vortex predicate pushdown narrowing path above.

## Relevant test evidence

- `native_relational_float_comparisons_preserve_exact_integer_literals_and_columns` uses an F32 column with an integer literal `1` and tests nullable results, alongside F64/integer comparisons (`local_primitive_relational_expression_tests.rs:70-178`). It does not use a nonrepresentable F64 literal against F32.
- `native_numeric_accessor_keeps_float_bits_nulls_empty_and_existing_fast_paths` verifies F32 min/max widen exactly into Float64 StatValues (`local_primitives/native_numeric_accessor_tests.rs:126-178`); it does not directly test F32 comparison with a nonrepresentable Float64 threshold.
- `native_numeric_owner_all_widths_keep_payload_identity_and_sliced_validity` exercises `compare_rows` under a macro for F32/F64 but supplies same-family integer-valued thresholds (`local_primitives/native_numeric_accessor_tests.rs:270-372`). No nonrepresentable Float64 threshold case is present there.
- `pushdown_predicate_accepts_iso_date_literals_for_date_named_unsigned_fields` directly tests `predicate_to_vortex_expr` success/error for date-string versus non-date unsigned fields (`local_primitives.rs:49457-49503`). It is not a Float32/Float64 narrowing test.
- Targeted searches for `stat_value_to_vortex_literal`, `predicate_to_vortex_expr`, `narrow_f32_exact`, Float32 predicate literals, and nonrepresentable literal wording found no direct test that rejects a nonrepresentable Float64 literal before F32 narrowing. The checked-in helper itself contains no such guard. This is a bounded source search, not runtime verification.
