# Float16 source and verification review

Scope: the Float16 and existing vector-collection lifecycle diff against
`c47eeefa05012cce32b053f53af18583041c9f19`. This is the primary source review;
final test, installed-package and hosted acceptance remain separate gates.

## Representation preservation

The highest-risk mistake is to admit the type but route selected values through
ordinary floating conversions that quiet signaling NaNs. The core helpers use
integer representation rules, including normalization of subnormals and exact
narrowing. The numeric owner widens only scalar registers. Preserving copies,
native replay and private retained records keep two-byte values or raw U16
carriers. Common Float16/Float64 result promotion bypasses the ordinary provider
cast, writes the final result owner directly and does not cache a widened input
column. Prefix construction retains the selected half dtype until copying the
retained scalar. The exhaustive Rust checks and all-pattern Vortex/IPC/Parquet
Python test are required in the final packet.

## Observation and ownership

Adding a physical width must not broaden strict-policy observation. The final
promotion validates each selected valid value, polls cancellation and verifies
cancellation at completion. Opaque carriage retains the existing explicit
preserve-unobserved policy. Dictionary input checks the complete valid value
domain, while ordinary selected rows and absent parent/component payloads keep
their existing visibility rules. Tests cover nonrepresentable thresholds,
strict selected and unused CASE branches, UNION, COALESCE, signed zero and NaN
identity, last-owner release, denied/shrunk memory, cancellation and changed
source generations. Buffer widths, reservations, output owners and cleanup use
the existing native boundaries.

## Persistence and public routes

The source hint preserves Float16 instead of relabeling it Float64. The legacy
empty scalar reconstruction route refuses when it lacks a typed RecordBatch.
Avro's widening writer and ORC's absent exact mapping are blocked recursively
during schema preparation, before opening a producer or staging output.
Embedding/tensor diagnostics retain precedence. The five-interface tests bind
complete schema, valid-value representations and no-fallback certificates;
mixed lifecycle tests also require separate-process reopen after source removal.
Independent Parquet checks retain the pinned reader's absent-parent fixed-list
limitation explicitly and check its capable subset, in addition to complete
native reopen and all scalar bit patterns.

## Scope and remaining gates

No dependency versions, provider patches, feature definitions, CI workflows or
external query-engine boundaries change. Optional legacy Float16 specializations
and scalar casts remain unadmitted; sparse/quantized interpretation and exact
vector expressions are separate work. No benchmark or performance claim is
part of this unit.

No additional source defect was found in this pass. Earlier promotion,
preflight, validation and test-fixture failures are preserved in the failure
analysis and original receipts. This review does not substitute for completing
the full workspace, feature, clean installed-wheel, portable replay and hosted
integration gates.

## Empty-source follow-up

The broadened empty-input regression exposed a buffered-reader boundary that
the original mixed rich-schema fixtures did not isolate: a Float16-only file
with no record batches lost its typed source batch, while nested schemas already
retained one. The reader now applies the existing typed-empty preservation path
to Float16 as well. The writer keeps its refusal if a caller removes that batch,
and the original nested diagnostic wording is unchanged. Focused r2 verifies
the exact source schema and nullable/nonnullable reopen through buffered,
streamed and budgeted ingestion. Full final workspace and package validation
remain required after this correction.

The same review was extended to Float16-valued dictionaries. The initial source
hint discarded the dictionary dtype, and an empty reader produced no typed
batch. A dedicated matrix entry reproduced the gap. The source now retains both
the dictionary hint and the typed empty batch; the writer still refuses a
deliberately removed batch. Focused r4 passes the complete nullable/nonnullable
matrix through buffered, streamed and budgeted ingestion. Final acceptance
uses a fresh release build and installed wheel for this corrected source.
