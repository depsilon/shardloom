"""Retire exact closed variable-tensor intermediates after hosted acceptance."""
import argparse
import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import subprocess
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
PRIOR = OUT.parent / 'tensor-lifecycle-2026-11-07'
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
TARGET = OUT / 'variable-retirement-r1'
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
spec = importlib.util.spec_from_file_location('retirement_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.E = OUT.parent


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=base.sha(path))


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


def preparation():
    value = read(OUT / 'delivery-acceptance-r1.json')
    assert value['status'] == 'passed' and value['runtime_sources_match_build']
    prior = read(PRIOR / 'tensor-closeout-r1.json')
    assert prior['status'] == 'complete' and prior['merge_commit'] == value['base']
    return value


def roots():
    result = {
        str(PRIOR / 'runtime-r2/shardloom'): 'Superseded accepted fixed-tensor CLI; installed-tested variable-tensor CLI retained.',
        str(PRIOR / 'runtime-r2/lib_native.dylib'): 'Superseded accepted fixed-tensor library; installed-tested variable-tensor library retained.',
        str(PRIOR / 'installed-proof-r1/dist'): 'Superseded fixed-tensor wheel; installed-tested variable-tensor wheel retained.',
        str(OUT / 'runtime-r1'): 'Earlier variable-tensor runtime; exact source snapshots and final tested build retained.',
        str(OUT / 'runtime-r2'): 'Earlier variable-tensor runtime; exact source snapshots and final tested build retained.',
        str(OUT / 'installed-proof-r1/package'): 'Completed package staging; committed source and installed-tested wheel retained.',
        str(OUT / 'installed-proof-r1/venv'): 'Completed uninstalled proof environment; locked wheelhouse retained.',
        str(OUT / 'packet-controls-r1'): 'Exact mutation recipes, observations and logs preserved in the committed controls record.',
        str(OUT / 'parquet-schema-probe-r1'): 'Tiny diagnostic Parquet files preserved byte-exact in the committed verification archive.',
        str(OUT / 'parquet-schema-probe-r2'): 'Tiny diagnostic Parquet files preserved byte-exact in the committed verification archive.',
    }
    paths = [Path(name) for name in result]
    assert all(path.exists() and not path.is_symlink() and path.resolve() == path for path in paths)
    assert all(path.is_relative_to(OUT) or path.is_relative_to(PRIOR) for path in paths)
    assert not any(a != b and a.is_relative_to(b) for a in paths for b in paths)
    return result


def retained():
    acceptance = read(PACKET / 'acceptance.json')
    installed = read(OUT / 'installed-proof-r1/report.json')
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['integration'] == acceptance['installed_package'] == dict(
        tests=361, failures=0, errors=0, skipped=0, status='passed')
    prep = preparation()
    for filename, key in [('acceptance.json', 'acceptance'), ('verification.tar.xz', 'archive'),
                          ('verify.py', 'verifier'), ('corruption-controls.json', 'corruption_controls')]:
        assert identity(PACKET / filename) == prep[key]
    files = list(sorted(PACKET.iterdir()))
    assert all(path.is_file() and not path.is_symlink() for path in files)
    for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
        path = OUT / 'runtime-r3' / name
        assert base.sha(path) == installed['integrity'][key] == acceptance[key]
        files.append(path)
    wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
    assert base.sha(wheel) == installed['integrity']['wheel_sha256'] == acceptance['wheel_sha256']
    files += [wheel, OUT / 'installed-proof-r1/report.json', OUT / 'delivery-acceptance-r1.json',
              PRIOR / 'tensor-closeout-r1.json', OUT / 'precommit-whitespace-r1.json']
    return {str(path): identity(path) for path in files}


def inputs():
    previous = read(PRIOR / 'tensor-retirement-r2/plan.json')
    path = PRIOR / 'tensor-retirement-r2/manifest.json.xz'
    assert base.sha(path) == previous['manifest_sha256']
    expected = json.loads(lzma.decompress(path.read_bytes()))['input_generations']
    assert expected
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def preserved_observations():
    acceptance = read(PACKET / 'acceptance.json')
    assert base.sha(PACKET / 'verification.tar.xz') == acceptance['archive_sha256']
    with tarfile.open(PACKET / 'verification.tar.xz', 'r:xz') as archive:
        for directory in ('parquet-schema-probe-r1', 'parquet-schema-probe-r2'):
            paths = sorted((OUT / directory).iterdir())
            assert {path.name for path in paths} == {'full.parquet', 'present.parquet'}
            for path in paths:
                assert path.is_file() and not path.is_symlink()
                assert archive.extractfile('current/' + directory + '/' + path.name).read() == path.read_bytes()
        for version in ('r1', 'r2'):
            name = 'runtime-' + version + '-identity.json'
            frozen = read(OUT / name)
            assert archive.extractfile('current/' + name).read() == (OUT / name).read_bytes()
            assert frozen['status'] == 'passed'
            assert {Path(row['path']).name for row in frozen['files']} == {'shardloom', 'lib_native.dylib'}
            assert {p.name for p in (OUT / ('runtime-' + version)).iterdir()} == {'shardloom', 'lib_native.dylib'}
            for row in frozen['files']:
                path = Path(row['path'])
                assert path.parent == OUT / ('runtime-' + version)
                assert identity(path) == {key: row[key] for key in ('bytes', 'sha256')}
    controls = read(PACKET / 'corruption-controls.json')
    assert controls['status'] == 'passed' and controls['exact_fixture_mutations_verified']
    assert controls['positive_controls'] == 2 and controls['rejected_controls'] == 9
    assert controls['observation'] == read(OUT / 'packet-controls-r1/receipt.json')
    assert controls['driver_source'] == (OUT / 'tools/check_variable_packet_controls.py').read_text()
    for name, content in controls['logs'].items():
        assert (OUT / 'packet-controls-r1' / (name + '.log')).read_text() == content
    old = read(PRIOR / 'tensor-closeout-r1.json')
    for path, expected in old['retained_runtime_and_wheel'].items():
        assert identity(Path(path)) == expected


def replay():
    subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-I',
        str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=180)


def plan():
    assert not TARGET.exists()
    prep = preparation()
    assert git('rev-parse', 'HEAD') == prep['head'] and not git('status', '--porcelain')
    selected = roots()
    preserved_observations()
    replay()
    kept, generations = retained(), inputs()
    rows = [row for name in sorted(selected) for row in base.inventory(Path(name))]
    assert len(rows) == len({row['path'] for row in rows})
    assert not (set(kept) | set(generations)).intersection(row['path'] for row in rows)
    base.closed(selected)
    for row in rows:
        base.unchanged(row)
    manifest = dict(roots=selected, entries=rows, retained=kept, input_generations=generations,
        accepted_head=prep['head'], accepted_tree=prep['tree'])
    TARGET.mkdir()
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode())
    (TARGET / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    summary = dict(status='planned_no_deletion', head=prep['head'], tree=prep['tree'],
        roots=len(selected), entries=len(rows), regular_files=sum(row['kind'] == 'regular' for row in rows),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        manifest_sha256=base.sha(TARGET / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), deleted=False, payload_backup_created=False,
        retained_test_environment='The existing fixed-tensor test environment remains in use for immediately following queue work.')
    (TARGET / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


def apply(main_path, pre_path):
    prep, main, pre = preparation(), read(main_path), read(pre_path)
    assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
    assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
    assert main['pr'] == pre['pr'] == 1662 and main['pr_head'] == pre['head'] == prep['head']
    assert main['source_tree'] == pre['source_tree'] == prep['tree']
    assert main['premerge_sha256'] == base.sha(pre_path) and pre['tree_matches_synthetic']
    assert main['commit_verification']['verified'] is True
    assert git('rev-parse', 'HEAD') == main['source_commit'] and not git('status', '--porcelain')
    assert git('branch', '--show-current') == 'main'
    summary = read(TARGET / 'plan.json')
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(TARGET / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET / 'manifest.json.xz').read_bytes()))
    selected, rows = manifest['roots'], manifest['entries']
    assert manifest['accepted_head'] == prep['head'] and manifest['accepted_tree'] == prep['tree']
    assert roots() == selected and retained() == manifest['retained'] and inputs() == manifest['input_generations']
    preserved_observations()
    for _ in range(2):
        assert [row for name in sorted(selected) for row in base.inventory(Path(name))] == rows
        base.closed(selected)
    receipt = dict(status='running', removed=0, main=identity(main_path), premerge=identity(pre_path),
        prior_fixed_tensor_closeout=identity(PRIOR / 'tensor-closeout-r1.json'),
        accepted_head=prep['head'], accepted_tree=prep['tree'], manifest_sha256=summary['manifest_sha256'])
    assert not (TARGET / 'receipt.json').exists()
    try:
        for row in sorted(rows, key=lambda value: len(Path(value['path']).parts), reverse=True):
            path = Path(row['path'])
            base.unchanged(row, removing_children=row['kind'] == 'directory')
            path.rmdir() if row['kind'] == 'directory' else path.unlink()
            receipt['removed'] += 1
        assert all(not Path(name).exists() and not Path(name).is_symlink() for name in selected)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        replay()
        receipt.update(status='passed', retained_files_unchanged=True, input_generations_unchanged=True,
            portable_replay_after_retirement='passed', regular_files=summary['regular_files'],
            symlinks=summary['symlinks'], regular_bytes=summary['regular_bytes'],
            control_observations_preserved=True, storage_limits_changed=False, payload_backup_created=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (TARGET / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    parser.add_argument('--main', type=Path)
    parser.add_argument('--pre', type=Path)
    args = parser.parse_args()
    if args.mode == 'plan':
        plan()
    else:
        assert args.main and args.pre
        apply(args.main, args.pre)
