"""Bind variable-tensor local proof, exact hosted integration and safe retirement."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-variable-tensor-lifecycle/shardloom-local-repo')
PRIOR = OUT.parent / 'tensor-lifecycle-2026-11-07'
PACKET = ROOT / 'docs/release/evidence/native-variable-shape-tensor-2026-11-07'
SECURITY = Path('/Users/dylan/.codex/state/plugins/codex-security/scans/shardloom-local-repo/artifacts-b2b2e466578304b9e6f9b439ce16c13bdaf41f503f2a3839f1f7706c36e27f07')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pre', type=Path, required=True)
parser.add_argument('--main', type=Path, required=True)
parser.add_argument('--reconciliation', type=Path, required=True)
args = parser.parse_args()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True, timeout=90).strip()


prep_path = OUT / 'delivery-acceptance-r1.json'
prep, pre, main = read(prep_path), read(args.pre), read(args.main)
assert prep['status'] == 'passed' and prep['runtime_sources_match_build']
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert main['status'] == 'passed' and main['successful_hosted_checks'] == 55
assert main['pr'] == pre['pr'] == 1662
assert main['pr_head'] == pre['head'] == prep['head']
assert main['source_tree'] == pre['source_tree'] == prep['tree']
assert pre['base_branch'] == 'main' and pre['tree_matches_synthetic']
assert main['premerge_sha256'] == identity(args.pre)['sha256']
assert pre['acceptance_sha256'] == identity(prep_path)['sha256']
assert pre['review']['commit_sha'] == prep['head'] and pre['review']['status'] == 'completed'
assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
assert main['commit_verification']['verified'] is True
assert not main['failed'] and not main['pending'] and not main['missing']
assert git('rev-parse', 'HEAD') == main['source_commit'] and git('rev-parse', 'HEAD^{tree}') == prep['tree']
assert git('branch', '--show-current') == 'main' and not git('status', '--porcelain')
assert git('show', '-s', '--format=%P', 'HEAD').split() == [pre['base'], prep['head']]
prior = read(PRIOR / 'tensor-closeout-r1.json')
assert prior['status'] == 'complete' and prior['merge_commit'] == pre['base'] == prep['base']

final_checks = read(OUT / 'pr1662-final-checks-r1.json')
final_review = read(OUT / 'pr1662-final-review-r1.json')
assert final_checks['status'] == final_review['status'] == 'passed'
assert final_checks['head'] == final_review['head'] == prep['head']
assert final_checks['base'] == final_review['base'] == pre['base']
assert final_checks['successful_hosted_checks'] == 58 and final_review['unresolved_threads'] == 0
assert final_checks['premerge_sha256'] == final_review['premerge_sha256'] == identity(args.pre)['sha256']
assert final_review['automated_review'] == pre['review']
for observation in (main, final_checks, final_review):
    for name, checksum in observation['raw_sources'].items():
        path = OUT / name
        assert path.resolve().is_relative_to(OUT) and identity(path)['sha256'] == checksum

# The first hosted observation failed only the CodeQL result check. Preserve
# that observation and the reviewed false-positive disposition independently.
original_pr = read(OUT / 'variable-pr1662-r1.json')
assert original_pr['status'] == 'needs_attention' and original_pr['head'] == prep['head']
assert len(original_pr['failures']) == 1 and original_pr['failures'][0]['name'] == 'CodeQL'
security_raw = SECURITY / 'artifacts/pr1662-codeql'
triage_path = SECURITY / 'findings/pr1662-codeql-triage-r1.json'
triage = read(triage_path)
assert triage['schema_version'] == 'triage-finding/v0'
assert triage['repository']['revision'] == prep['head']
assert [row['input_id'] for row in triage['findings']] == ['365', '364', '363', '362']
assert all(row['verdict'] == 'not_actionable' and row['confidence'] == 'high'
           and row['boundary_assessment']['boundary_crossed'] is False
           for row in triage['findings'])
request = read(security_raw / 'dismiss-request-r1.json')
assert request['state'] == 'dismissed' and request['dismissed_reason'] == 'false positive'
for number in (365, 364, 363, 362):
    instances = read(security_raw / f'instances-{number}-r1.json')
    assert len(instances) == 1 and instances[0]['ref'] == 'refs/pull/1662/merge'
    assert instances[0]['commit_sha'] == pre['synthetic']
    response = read(security_raw / f'dismiss-response-{number}-r1.json')
    assert response['number'] == number and response['state'] == 'dismissed'
    assert response['dismissed_reason'] == request['dismissed_reason']
    assert response['dismissed_comment'] == request['dismissed_comment']
    assert response['most_recent_instance']['commit_sha'] == pre['synthetic']
before, after = [read(security_raw / filename) for filename in
                 ('codeql-failed-check-r1.json', 'post-dismiss-check-r1.json')]
assert before['id'] == after['id'] == original_pr['failures'][0]['id']
assert before['head_sha'] == after['head_sha'] == prep['head']
assert before['conclusion'] == 'failure' and after['conclusion'] == 'success'
security_paths = [triage_path, SECURITY / 'findings/pr1662-codeql-triage-r1.md',
                  *sorted(security_raw.iterdir())]
assert len(security_paths) == 25
security_receipts = {str(path): identity(path) for path in security_paths}

acceptance = read(PACKET / 'acceptance.json')
assert acceptance['status'] == 'local_acceptance_passed'
for filename, key in [('acceptance.json', 'acceptance'), ('verification.tar.xz', 'archive'),
                      ('verify.py', 'verifier'), ('corruption-controls.json', 'corruption_controls')]:
    assert identity(PACKET / filename) == prep[key]
for relative, expected in acceptance['code_snapshot'].items():
    assert identity(ROOT / relative) == expected
docs = read(OUT / 'variable-final-docs-r2.json')
assert docs['status'] == 'passed' and docs['process_group_drained'] and docs['direct_child_reaped']
assert identity(OUT / 'variable-final-docs-r2.json') == prep['final_documentation_checks']
assert set(docs['changed_source_inventory']) == set(prep['changed_files'])
for relative, expected in docs['changed_source_inventory'].items():
    assert identity(ROOT / relative) == expected

installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == acceptance['installed_package'] == dict(
    tests=361, failures=0, errors=0, skipped=0, status='passed')
kept = {}
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    path = OUT / 'runtime-r3' / name
    assert identity(path)['sha256'] == installed['integrity'][key] == acceptance[key]
    kept[str(path)] = identity(path)
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert identity(wheel)['sha256'] == installed['integrity']['wheel_sha256'] == acceptance['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for relative, expected in acceptance['code_snapshot'].items():
        if relative.startswith('python/src/shardloom/'):
            raw = archive.read(relative.removeprefix('python/src/'))
            assert dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == expected
kept[str(wheel)] = identity(wheel)

retirement_path = OUT / 'variable-retirement-r1/receipt.json'
retirement = read(retirement_path)
assert retirement['status'] == 'passed' and retirement['accepted_head'] == prep['head']
assert retirement['accepted_tree'] == prep['tree']
assert retirement['main'] == identity(args.main) and retirement['premerge'] == identity(args.pre)
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
assert not retirement['storage_limits_changed'] and not retirement['payload_backup_created']
applied = read(OUT / 'variable-retirement-apply-r1.json')
assert applied['status'] == 'passed' and applied['process_group_drained'] and applied['direct_child_reaped']
assert identity(OUT / 'variable-retirement-apply-r1.log')['sha256'] == applied['log_sha256']
checkout = read(OUT / 'variable-main-checkout-r1.json')
assert checkout['status'] == 'passed' and checkout['merge_commit'] == main['source_commit']
assert checkout['both_worktrees_clean'] and checkout['accepted_file_trees_unchanged']
reconciliation = read(args.reconciliation)
assert reconciliation['status'] == 'passed' and reconciliation['open_prs'] == [] and reconciliation['pages_complete']

receipts = [prep_path, args.pre, args.main, args.reconciliation, retirement_path,
    OUT / 'variable-pr1662-r1.json',
    OUT / 'pr1662-create-r1.json', OUT / 'pr1662-merge-r1.json',
    OUT / 'pr1662-final-checks-r1.json', OUT / 'pr1662-final-review-r1.json',
    OUT / 'variable-main-checkout-r1.json', OUT / 'main-helper-adaptation-r1.json',
    OUT / 'main-helper-primary-review-r1.json', OUT / 'precommit-whitespace-r1.json',
    OUT / 'variable-final-docs-r1.json', OUT / 'variable-final-docs-r1.log',
    OUT / 'variable-final-docs-r2.json', OUT / 'variable-final-docs-r2.log',
    OUT / 'variable-package-r1.json', OUT / 'variable-package-r1.log',
    OUT / 'variable-packet-controls-r1.json', OUT / 'variable-packet-controls-r1.log',
    OUT / 'variable-retirement-r1/plan.json', OUT / 'variable-retirement-r1/manifest.json.xz',
    OUT / 'variable-retirement-plan-r1.json', OUT / 'variable-retirement-plan-r1.log',
    OUT / 'variable-retirement-apply-r1.json', OUT / 'variable-retirement-apply-r1.log',
    OUT / 'installed-proof-r1/report.json',
    *[OUT / 'tools' / (name + '.py') for name in (
        'prepare_variable_delivery', 'final_variable_review', 'watch_variable_pr',
        'advance_variable_main', 'observe_variable_main', 'watch_variable_main',
        'retire_variable_intermediates', 'record_variable_closeout')]]
receipts += [OUT / name for observation in (main, final_checks, final_review)
             for name in observation['raw_sources']]
receipts = sorted(set(receipts))
assert all(path.resolve().is_relative_to(OUT) for path in receipts)
external_helper = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
plan = read(OUT / 'variable-retirement-r1/plan.json')
assert identity(external_helper)['sha256'] == plan['helper_sha256']
report = dict(status='complete', observed_at=datetime.now(timezone.utc).isoformat(),
    pr_url='https://github.com/depsilon/shardloom/pull/1662', pr_head=prep['head'],
    merge_commit=main['source_commit'], source_tree=prep['tree'],
    pr_checks_passed=58, main_checks_passed=55, review_findings=False,
    review_url=pre['review_url'], main_ci_url=main['ci_run_url'], no_open_prs_at_observation=True,
    validation=acceptance['checks'], installed_package=installed['integration'],
    provider_tests=acceptance['provider_tests'], runtime_sources_match_build=True,
    runtime_source_proof=prep['runtime_source_proof'],
    retired_regular_files=retirement['regular_files'], retired_symlinks=retirement['symlinks'],
    current_inputs_unchanged=True, portable_replay_after_retirement='passed',
    retained_runtime_and_wheel=kept,
    committed_evidence={path.relative_to(ROOT).as_posix(): identity(path) for path in sorted(PACKET.iterdir())},
    receipts={path.relative_to(OUT).as_posix(): identity(path) for path in receipts},
    retirement_primitives=dict(path=str(external_helper), **identity(external_helper), source=external_helper.read_text()),
    prior_fixed_tensor_closeout=identity(PRIOR / 'tensor-closeout-r1.json'),
    codeql_resolution=dict(original_status='failure', final_status='success',
        false_positive_alerts=[365, 364, 363, 362], source_changed=False,
        scanning_configuration_changed=False, artifacts=security_receipts),
    closeout_script=identity(Path(__file__)), working_tree_clean=True,
    performance_claim=False, publication_attempted=False, whole_item_19_complete=False,
    reader_limitations=acceptance['reader_limitations'])
with (OUT / 'variable-closeout-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('status', 'merge_commit', 'pr_checks_passed',
    'main_checks_passed', 'installed_package', 'retired_regular_files')}))
