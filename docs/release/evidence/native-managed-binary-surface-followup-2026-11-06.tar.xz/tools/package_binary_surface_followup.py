"""Preserve hosted failures and bind the corrected Python metadata to its wheel."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'docs/release/evidence'
NAME = 'native-managed-binary-surface-followup-2026-11-06'
ORIGINAL = DEST / 'native-managed-binary-objects-2026-11-06.json'
CONTEXT = 'python/src/shardloom/context.py'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

original = read(ORIGINAL)
assert original['status'] == 'locally_accepted'
assert sha(DEST / original['archive']) == original['archive_sha256']
assert read(OUT / 'python-followup-sequence-r2.json')['status'] == 'passed'
checks = []
for name in ['binary-graduation-tests-r1', 'binary-python-core-r2', 'installed-wheel-r2']:
    receipt, log = OUT / (name + '.json'), OUT / (name + '.log')
    record = read(receipt)
    assert record['status'] == 'passed' and record['returncode'] == 0 and record['process_group_drained']
    assert sha(log) == record['log_sha256']
    assert record['changed_source_inventory'][CONTEXT]['sha256'] == sha(ROOT / CONTEXT)
    checks.append({'receipt': receipt.name, 'receipt_sha256': sha(receipt), 'log_sha256': sha(log),
                   'status': 'passed', 'command': record['command']})
core = read(OUT / 'python-core-r2/core.json')
assert core['status'] == 'passed' and core['failure_count'] == core['error_count'] == 0
match = re.search(r'Ran (\d+) tests in ', (OUT / 'binary-python-core-r2.log').read_text())
assert match
executed = int(match.group(1))
assert executed >= 831

installed = read(OUT / 'installed-proof-r2/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == {'tests': 319, 'failures': 0, 'errors': 0, 'skipped': 0, 'status': 'passed'}
assert not installed['publication_attempted']
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert sha(OUT / 'runtime-r2' / name) == installed['integrity'][key] == original[key]
wheels = list((OUT / 'installed-proof-r2/dist').glob('*.whl'))
assert len(wheels) == 1 and sha(wheels[0]) == installed['integrity']['wheel_sha256']
with zipfile.ZipFile(wheels[0]) as wheel:
    assert hashlib.sha256(wheel.read('shardloom/context.py')).hexdigest() == sha(ROOT / CONTEXT)
changed = subprocess.check_output(['git', 'diff', '--name-only', '307c0543e317d0ed07ad42cd43bdfeaa74601c9f'], cwd=ROOT, text=True).splitlines()
assert [name for name in changed if not name.startswith('docs/')] == [CONTEXT]
for name, descriptor in original['verified_changed_build_sources'].items():
    if name != CONTEXT:
        assert sha(ROOT / name) == descriptor['sha256'], name

names = ['pr1659-msrv-original.log', 'pr1659-msrv-retry-request-r1.json',
    'pr1659-core-original.log', 'pr1659-initial-review-r1.json',
    'binary-pr1659-r1.json', 'binary-pr1659-r2.json',
    'python-followup-sequence-r1.json', 'python-followup-sequence-r2.json',
    'python-core-r1/core.json', 'python-core-r2/core.json']
for name in ['binary-graduation-tests-r1', 'binary-python-core-r1', 'binary-python-core-r2', 'installed-wheel-r2']:
    names.extend([name + '.json', name + '.log'])
files = [OUT / name for name in names]
files += list((OUT / 'installed-proof-r2').glob('*.json')) + list((OUT / 'installed-proof-r2').glob('*.log'))
files += list((OUT / 'tools').glob('*python_followup*.py')) + [Path(__file__)]
for row in read(OUT / 'installed-wheel-r2.json')['changed_source_inventory'].values():
    files.append(OUT / 'source-blobs' / row['sha256'])
files = sorted(set(files))
assert sum(path.stat().st_size for path in files) < 32 << 20
archive, report_path = DEST / (NAME + '.tar.xz'), DEST / (NAME + '.json')
assert not archive.exists() and not report_path.exists()
members = []
with tarfile.open(archive, 'w:xz', preset=6) as bundle:
    for path in files:
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        name = path.relative_to(OUT).as_posix()
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        bundle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as bundle:
    assert bundle.getnames() == [row['path'] for row in members]
    for row in members:
        raw = bundle.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']

report = {'schema_version': 'shardloom.managed_binary_surface_followup.v1', 'status': 'locally_accepted',
    'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_inventory': {CONTEXT: {'bytes': (ROOT / CONTEXT).stat().st_size, 'sha256': sha(ROOT / CONTEXT)}},
    'original_acceptance_sha256': sha(ORIGINAL), 'original_archive_sha256': original['archive_sha256'],
    'correction': 'Classify five new native Context methods in the inert graduation matrix; regenerate the API source fingerprint.',
    'checks': checks, 'core_python': {'reported_tests': executed, 'skip_records': core['skipped_count'],
        'declared_test_count': core['test_count'], 'failures': 0, 'errors': 0, 'status': 'passed'},
    'installed_package': installed['integration'], 'wheel_sha256': sha(wheels[0]),
    'cli_sha256': original['cli_sha256'], 'native_library_sha256': original['native_library_sha256'],
    'native_runtime_rebuilt': False, 'native_runtime_unchanged': True,
    'wheel_context_matches_validated_source': True,
    'original_failures': [
        {'receipt': 'pr1659-core-original.log', 'disposition': 'Missing graduation classification corrected; no gate removed.'},
        {'receipt': 'pr1659-msrv-original.log', 'disposition': 'Registry connection reset before compilation. Initial retry rejected while run active; new revision receives fresh hosted checks.'},
        {'receipt': 'binary-python-core-r1.json', 'disposition': 'Two generated reference fingerprints were stale after metadata correction; regenerated and full core shard passed.'},
        {'receipt': 'python-followup-sequence-r1.json', 'disposition': 'Stopped on failed core reference check before building or installing a package.'}],
    'hosted_integration': 'pending', 'whole_item_19_complete': False,
    'publication_attempted': False, 'performance_claim': False,
    'archive': archive.name, 'archive_sha256': sha(archive), 'members': members}
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'core_python': report['core_python'],
    'installed_package': report['installed_package'], 'members': len(members), 'archive_bytes': archive.stat().st_size}))
