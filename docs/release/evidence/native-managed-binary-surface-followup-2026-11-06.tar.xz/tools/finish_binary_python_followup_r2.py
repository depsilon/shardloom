"""Finish the Python-only classification correction with an installed package proof."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
state = {'status': 'running', 'active_stage': 'binary-python-core-r2', 'runtime_rebuilt': False}
receipt = OUT / 'python-followup-sequence-r2.json'
assert not receipt.exists()
original = json.loads((ROOT / 'docs/release/evidence/native-managed-binary-objects-2026-11-06.json').read_text())

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    save()
    deadline = time.monotonic() + 1300
    core_receipt = OUT / 'binary-python-core-r2.json'
    while not core_receipt.exists():
        assert time.monotonic() < deadline, 'core check did not finish before its deadline'
        time.sleep(5)
    core = json.loads(core_receipt.read_text())
    assert core['status'] == 'passed' and core['returncode'] == 0 and core['process_group_drained']
    state['core_passed'] = True
    for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
        assert hashlib.sha256((OUT / 'runtime-r2' / name).read_bytes()).hexdigest() == original[key]
    changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=ROOT, text=True).splitlines()
    assert set(changed) == {'python/src/shardloom/context.py',
        'docs/reference/shardloom-user-surface-index.json', 'docs/reference/shardloom-user-surface-index.md'}
    state['active_stage'] = 'installed-wheel-r2'
    save()
    command = [PYTHON, str(OUT / 'tools/guard_managed_binary.py'), '--name', 'installed-wheel-r2',
        '--timeout', '2400', '--', BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(OUT / 'installed-proof-r2'),
        '--native-library', str(OUT / 'runtime-r2/lib_native.dylib'),
        '--cli-binary', str(OUT / 'runtime-r2/shardloom'), '--wheelhouse', WHEELHOUSE]
    subprocess.run(command, cwd=ROOT, check=True)
    installed = json.loads((OUT / 'installed-wheel-r2.json').read_text())
    assert installed['status'] == 'passed' and installed['process_group_drained']
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
    print(json.dumps(state), flush=True)
