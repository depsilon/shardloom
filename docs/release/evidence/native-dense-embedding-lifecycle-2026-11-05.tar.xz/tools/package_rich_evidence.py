"""Preserve the finite rich-column validation observations without runtime payloads."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'docs/release/evidence'
NAME = 'native-dense-embedding-lifecycle-2026-11-05'

def sha(data):
    return hashlib.sha256(data).hexdigest()

required = ['default-clippy-r1', 'default-workspace-tests-r1', 'native-workspace-tests-r1',
            'native-clippy-r5', 'native-dense-final-r1', 'format-check-r2', 'write-feature-check-r1',
            'release-build-r1', 'rich-final-r1', 'schema-controls-r1',
            'docs-checks-r1', 'installed-wheel-r1']
checks = []
for name in required:
    record = json.loads((OUT / (name + '.json')).read_text())
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained']
    log = (OUT / (name + '.log')).read_bytes()
    assert sha(log) == record['log_sha256']
    entry = {'receipt': name + '.json', 'command': record['command'],
             'status': 'passed', 'log_sha256': sha(log)}
    results = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    if results:
        entry['rust_tests'] = dict(zip(('passed', 'failed', 'ignored'),
            (sum(int(r[i]) for r in results) for i in range(3))))
        assert entry['rust_tests']['failed'] == 0
    checks.append(entry)

installed = json.loads((OUT / 'installed-proof-r1/report.json').read_text())
assert installed['status'] == 'passed' and installed['integration']['status'] == 'passed'
assert installed['integration']['skipped'] == 0 and not installed['publication_attempted']
build = json.loads((OUT / 'release-build-r1.json').read_text())
source = {}
for path, identity in build['changed_source_inventory'].items():
    if Path(path).suffix in {'.rs', '.py', '.toml'} or path == 'Cargo.lock':
        assert sha((ROOT / path).read_bytes()) == identity['sha256'], path
        source[path] = identity
dispositions = {
    'rich-binding-tests-r1': 'Fixture JOIN source aliases corrected to the documented AS syntax.',
    'rich-lifecycle-tests-r2': 'Native spill exposed missing first-party wire-edition admission; the registered edition fixes it.',
    'rich-lifecycle-tests-r3': 'Interrupted unittest difflib rendering of a large failed comparison; per-row complete comparisons retain coverage and expose the field alias mismatch.',
    'rich-lifecycle-tests-r3-duplicate-launch': 'Duplicate receipt/log name rejected; both the interruption and duplicate launch remain recorded.',
    'rich-lifecycle-tests-r4': 'Fixture projection aliases corrected so complete expected field names match the declared output.',
    'rich-controls-tests-r1': 'Arrow permits unreachable null components under null parents; the validated provider mask bridge preserves values and logical nullability.',
    'rich-controls-tests-r2': 'PyArrow 25.0.1 nullable FixedSizeList Parquet read limitation remains explicit; native all-row and independent nonnull-parent controls pass.',
}
failures = []
for path in sorted(OUT.glob('*.json')):
    record = json.loads(path.read_text())
    if record.get('status') != 'failed':
        continue
    disposition = dispositions.get(path.stem)
    if path.stem.startswith(('format', 'native-clippy')):
        disposition = 'Formatting/lint corrected; final format and strict native lint checks pass.'
    assert disposition, path
    failures.append({'receipt': path.name, 'status': 'failed', 'returncode': record.get('returncode'),
                     'error': record.get('error'), 'disposition': disposition})
files = sorted(set([*OUT.glob('*.json'), *OUT.glob('*.log'),
                   *OUT.glob('*-sample.txt'), *OUT.glob('source-blobs/*'),
                   *OUT.glob('tools/*.py'), *OUT.glob('installed-proof-r1/*.json'),
                   *OUT.glob('installed-proof-r1/*.log')]))
manifest = []
DEST.mkdir(exist_ok=True)
archive = DEST / (NAME + '.tar.xz')
assert not archive.exists()
with tarfile.open(archive, 'w:xz', preset=6) as bundle:
    for file in files:
        assert file.is_file() and not file.is_symlink()
        data = file.read_bytes()
        name = file.relative_to(OUT).as_posix()
        manifest.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        bundle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as bundle:
    assert bundle.getnames() == [entry['path'] for entry in manifest]
    for entry in manifest:
        data = bundle.extractfile(entry['path']).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
report = {
    'schema_version': 'shardloom.dense_embedding_lifecycle_acceptance.v1',
    'status': 'locally_accepted',
    'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'verified_changed_build_sources': source,
    'checks': checks,
    'original_failures': failures,
    'installed_package': installed['integration'],
    'installed_wheel_sha256': installed['integrity']['wheel_sha256'],
    'native_library_sha256': installed['integrity']['native_library_sha256'],
    'cli_sha256': installed['integrity']['cli_sha256'],
    'publication_attempted': False,
    'performance_claim': False,
    'whole_item_19_complete': False,
    'verification_scope': 'Native workspace r1 precedes the final Arrow validity-scratch credit. Final native focused tests, lint and installed-package integration cover that addition; hosted checks remain an integration gate.',
    'known_limit': 'PyArrow 25.0.1 rejects null FixedSizeList parents in Parquet, including its own files. Complete native roundtrip and independently written input pass; independent readback uses present parents. Nullable Arrow IPC readback is complete.',
    'archive': archive.name,
    'archive_sha256': sha(archive.read_bytes()),
    'members': manifest,
}
target = DEST / (NAME + '.json')
assert not target.exists()
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(target), 'members': len(manifest),
                  'archive_bytes': archive.stat().st_size, 'installed_package': report['installed_package']}))
