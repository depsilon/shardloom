"""Compare the selected 1.1.0 release's public HTML, styles, scripts and search assets."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('stage', choices=['preview', 'production'])
parser.add_argument('name')
parser.add_argument('--head', required=True)
parser.add_argument('--preview-origin')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
OUT = Path(__file__).resolve().parents[1]
REPO = Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
SITE = REPO / 'website'
if args.stage == 'production':
    assert args.preview_origin is None
    origin = 'https://shardloom.io'
else:
    assert re.fullmatch(r'https://[a-z0-9-]+-shardloom\.djheinrich\.workers\.dev', args.preview_origin or '')
    origin = args.preview_origin
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert args.head == head and not subprocess.check_output(
    ['git','status','--porcelain','--','website','website-src/src/data/public-guide.json'],cwd=REPO)
assert json.loads((REPO/'website-src/src/data/public-guide.json').read_bytes())['release']['version']=='1.1.0'
assert b'shardloom==1.1.0' in (SITE/'field-guide/start-local-proof/index.html').read_bytes()
report = OUT / (args.name + '.json')
assert not report.exists()
files = {p.relative_to(SITE).as_posix(): p for p in SITE.rglob('*') if p.is_file() and not p.is_symlink()}
selected = {name: path for name, path in files.items() if name == 'index.html' or name.endswith('/index.html')
            or name.endswith(('.css', '.js', '.pf_index', '.pf_meta', '.pf_fragment'))
            or name == 'pagefind/pagefind-entry.json' or name.startswith('pagefind/') and '.wasm' in name}
assert 'field-guide/development/index.html' in selected and 'field-guide/local-tables/index.html' in selected
redirects = {}
for line in (SITE / '_redirects').read_text().splitlines():
    parts = line.split()
    if len(parts) >= 2 and '*' not in parts[0] and parts[1].startswith('/'):
        redirects[parts[0]] = parts[1].split('#', 1)[0]


class ScriptTag(HTMLParser):
    def handle_starttag(self, tag, attrs):
        assert tag == 'script' and len(dict(attrs)) == len(attrs)
        self.attrs = dict(attrs)


def edge_additions(local, remote):
    # Require an exact authored prefix and suffix. The only allowed intervening
    # bytes are the independently sampled production beacon and JSD templates.
    before, close, tail = local.rpartition(b'</body>')
    if not close or not remote.startswith(before) or not remote.endswith(close + tail):
        return None
    insertion = remote[len(before):-(len(close) + len(tail))]
    if not 0 < len(insertion) <= 8192:
        return None
    seen, pos = [], 0
    for match in re.finditer(rb'<script([^>]*)>(.*?)</script>', insertion, re.S):
        if insertion[pos:match.start()].strip():
            return None
        attrs, script = match.groups()
        if not attrs:
            params = re.search(rb"__CF\$cv\$params=\{r:'([0-9a-f]{16})',t:'([A-Za-z0-9+/=]{12,36})'\}", script)
            if not params or script.count(params[1]) != 2 or script.count(params[2]) != 1:
                return None
            template = script.replace(params[1], b'RAY').replace(params[2], b'TIME')
            if hashlib.sha256(template).hexdigest() != 'c0ad6ffc4df68dede6f2cbd63c1dceb4ea8934fede3eaca7ddb69f2abe9334ec':
                return None
            seen.append('cloudflare_jsd_template')
        else:
            tag = ScriptTag()
            tag.feed(('<script' + attrs.decode('ascii') + '></script>'))
            config = tag.attrs.pop('data-cf-beacon', None)
            if script or not config or tag.attrs != {
                'type':'module', 'crossorigin':'anonymous',
                'src':'https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092',
                'integrity':'sha512-UKNk8GbxkABxKcXYuLkO16EleLGUkcvJWtpSNmExE0Too3ZaFAxTscNWEc1OdAv5/BikHawapSCaiD2XCmp+Bw=='}:
                return None
            if hashlib.sha256(json.dumps(json.loads(config), sort_keys=True, separators=(',',':')).encode()).hexdigest() != '63d7412c35e947e3ccbae5988606704b90461e8cf4837df4a91fc878b765aff2':
                return None
            seen.append('cloudflare_insights_beacon')
        pos = match.end()
    if insertion[pos:].strip() or not seen or len(seen) != len(set(seen)):
        return None
    return seen


assert edge_additions(b'<p>source</p></body>', b'<p>other</p></body>') is None
assert edge_additions(b'<p>source</p></body>', b'<p>source</p><script>alert(1)</script></body>') is None


def check(item):
    name, path = item
    route = '/' + (name[:-len('index.html')] if name.endswith('index.html') else name)
    expected_route = redirects.get(route, route)
    target = path if route == expected_route else SITE / expected_route.strip('/') / 'index.html'
    data = target.read_bytes()
    observed = dict(file=name, route=route, expected_route=expected_route,
                    served_file=target.relative_to(SITE).as_posix(),
                    expected_bytes=len(data), expected_sha256=hashlib.sha256(data).hexdigest())
    request = urllib.request.Request(origin + route, headers={'User-Agent': 'ShardLoom public documentation verification',
                                     'Accept-Encoding': 'identity'})
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            final = urllib.parse.urlparse(response.geturl())
            assert final.scheme == 'https' and final.netloc == urllib.parse.urlparse(origin).netloc
            html = args.stage == 'production' and target.name == 'index.html'
            remote = response.read(len(data) + (8193 if html else 1))
            observed.update(status=response.status, final_url=response.geturl(), bytes_read=len(remote),
                            sha256=hashlib.sha256(remote).hexdigest())
            observed['byte_identical'] = remote == data
            additions = edge_additions(data, remote) if html and remote != data else None
            observed['edge_additions'] = additions
            observed['matches'] = (response.status == 200 and (remote == data or additions is not None)
                                   and final.path.rstrip('/') == expected_route.rstrip('/'))
    except (OSError, AssertionError) as error:
        observed.update(error=str(error)[:400], matches=False)
    return observed


with ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(check, sorted(selected.items())))
result = dict(status='passed' if all(r['matches'] for r in rows) else 'failed', stage=args.stage,
    origin=origin, source_commit=head,
    website_tree=subprocess.check_output(['git','rev-parse',head+':website'],cwd=REPO,text=True).strip(),
    html=sum(r['file'].endswith('.html') for r in rows), resources=sum(not r['file'].endswith('.html') for r in rows),
    matches=sum(r['matches'] for r in rows), byte_identical=sum(r.get('byte_identical',False) for r in rows),
    matched_with_pinned_edge_scripts=sum(bool(r.get('edge_additions')) for r in rows), comparisons=rows)
with report.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({k:v for k,v in result.items() if k != 'comparisons'}))
for row in rows:
    if not row['matches']:
        print(json.dumps(row))
raise SystemExit(result['status'] != 'passed')
