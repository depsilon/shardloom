#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ORIGIN = 'https://shardloom.io';
const INSTALL = 'python -m pip install shardloom==1.1.0';

function fail(message) { throw new Error(message); }
function parseArgs(argv) {
  if (argv.length !== 2) fail('Usage: node browser_110.cjs <new-output-directory-name> <merge-revision>');
  const [name, revision] = argv;
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(name) || name === '.' || name === '..')
    fail('Output name must be a simple directory name (letters, digits, dot, underscore, hyphen).');
  if (!/^[0-9a-f]{40}$/.test(revision)) fail('Supply the full merged commit revision.');
  const root = '/Users/dylan/LocalData/shardloom/release-v1.1.0';
  const output = path.join(root, name);
  if (!output.startsWith(root + path.sep)) fail('Output must be beneath the release evidence directory.');
  if (fs.existsSync(output)) fail(`Output directory already exists: ${output}`);
  fs.mkdirSync(output, { recursive: false });
  return { output, revision };
}

function playwrightModule() {
  try { return require('playwright'); } catch (e) {
    fail(`Cannot load Playwright. Set NODE_PATH to its node_modules directory. Original error: ${e.message}`);
  }
}
function assert(condition, message) { if (!condition) fail(message); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }

async function main() {
  const { output, revision } = parseArgs(process.argv.slice(2));
  const { chromium } = playwrightModule();
  const report = { stage: 'prepared', status: 'running', origin: ORIGIN, merge_revision: revision, screenshots: {}, checks: {}, console_errors: [] };
  let browser;
  try {
    browser = await chromium.launch({ headless: true, channel: 'chrome' });
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
    page.on('console', msg => { if (msg.type() === 'error') report.console_errors.push(msg.text()); });
    page.on('pageerror', error => report.console_errors.push(error.message));

    const capture = async (name) => {
      const file = path.join(output, `${name}.png`);
      await page.screenshot({ path: file, fullPage: false });
      const dims = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
      report.screenshots[`${name}.png`] = { path: file, dimensions: [dims.width, dims.height], sha256: sha256(file) };
    };
    const widthCheck = async (label, expected) => {
      const result = await page.evaluate(() => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth }));
      assert(result.width === expected && result.documentWidth === expected, `${label} page width mismatch: ${JSON.stringify(result)}`);
      report.checks[label] = result;
    };

    assert(new URL(ORIGIN).origin === ORIGIN, 'Production origin constant is invalid.');
    await page.goto(`${ORIGIN}/`, { waitUntil: 'networkidle', timeout: 60000 });
    assert(new URL(page.url()).origin === ORIGIN, `Unexpected origin after home navigation: ${page.url()}`);
    await widthCheck('home_desktop', 1440);
    await capture('home-desktop');
    await page.goto(`${ORIGIN}/field-guide/start-local-proof/`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.getByRole('button', { name: 'Search' }).click();
    await page.getByRole('textbox', { name: 'Search' }).fill('1.1.0');
    await page.getByText('7 results for 1.1.0', { exact: false }).waitFor({ state: 'visible' });
    report.checks.search_message = await page.getByText('7 results for 1.1.0', {exact: true}).innerText();
    await capture('search-desktop');
    await page.getByRole('link', { name: 'Local table bindings in' }).click();
    await page.waitForLoadState('networkidle');
    const searchResult = await page.evaluate(() => ({ pathname: location.pathname, hash: location.hash, heading: document.getElementById(location.hash.slice(1))?.textContent.trim(), version: document.body.innerText.includes('Published 1.1.0') }));
    assert(searchResult.pathname === '/field-guide/cli/' && searchResult.hash === '#local-table-bindings-in-110' && searchResult.heading === 'Local table bindings in 1.1.0' && searchResult.version, `Search navigation mismatch: ${JSON.stringify(searchResult)}`);
    report.checks.search_navigation = searchResult;

    await page.goto(`${ORIGIN}/field-guide/start-local-proof/`, { waitUntil: 'networkidle', timeout: 60000 });
    const install = await page.evaluate(expected => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth, version: document.body.innerText.includes('Published 1.1.0'), install: document.body.innerText.includes(expected) }), INSTALL);
    assert(install.install && install.version, `Install page does not show required version/install text: ${JSON.stringify(install)}`);
    await capture('install-desktop');
    await widthCheck('install_desktop', 1440);

    await page.setViewportSize({ width: 390, height: 844 });
    const mobile = await page.evaluate(expected => ({ width: innerWidth, documentWidth: document.documentElement.scrollWidth, version: document.body.innerText.includes('Published 1.1.0'), install: document.body.innerText.includes(expected) }), INSTALL);
    assert(mobile.width === 390 && mobile.documentWidth === 390 && mobile.version && mobile.install, `Mobile install check failed: ${JSON.stringify(mobile)}`);
    report.checks.install_mobile = mobile;
    await capture('install-mobile');
    await page.getByRole('button', { name: 'Menu' }).click();
    const menu = await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded');
    assert(menu === 'true', `Mobile menu did not open (aria-expanded=${menu}).`);
    await page.getByRole('link', { name: 'Local table snapshots' }).click();
    await page.waitForLoadState('networkidle');
    const tablePage = await page.evaluate(() => ({ pathname: location.pathname, title: document.title, width: innerWidth, documentWidth: document.documentElement.scrollWidth, version: document.body.innerText.includes('Published 1.1.0'), menuExpanded: document.querySelector('starlight-menu-button button')?.getAttribute('aria-expanded') }));
    assert(tablePage.pathname === '/field-guide/local-tables/' && tablePage.title === 'Query local table snapshots | ShardLoom' && tablePage.width === 390 && tablePage.documentWidth === 390 && tablePage.version && tablePage.menuExpanded === 'false', `Mobile local-table navigation failed: ${JSON.stringify(tablePage)}`);
    report.checks.mobile_table_navigation = tablePage;
    await capture('mobile-tables');
    await page.goto(`${ORIGIN}/`, { waitUntil: 'networkidle', timeout: 60000 });
    await widthCheck('home_mobile', 390);
    await capture('home-mobile');
    assert(report.console_errors.length === 0, `Browser console errors: ${report.console_errors.join(' | ')}`);
    report.stage = 'complete';
    report.status = 'passed';
  } catch (error) {
    report.stage = 'failed';
    report.status = 'failed';
    report.error = error.stack || String(error);
    throw error;
  } finally {
    if (browser) await browser.close();
    report.finished_at = new Date().toISOString();
    fs.writeFileSync(path.join(output, 'browser.json'), JSON.stringify(report, null, 2) + '\n');
  }
}

main().catch(error => { console.error(`Production browser probe failed: ${error.message}`); process.exitCode = 1; });
