"""Read exact Git objects targeted by current public-guide repository links."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

W = Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo')
R = Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--commit', required=True)
parser.add_argument('--name', required=True)
args=parser.parse_args()
assert re.fullmatch(r'[0-9a-f]{40}',args.commit) and re.fullmatch(r'[a-z0-9-]+',args.name)
HEAD=args.commit
OUT=R/(args.name+'.json')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert not OUT.exists()
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
paths = sorted((W / 'website-src/src/content').rglob('*.mdx')) + [W / name for name in (
    'README.md', 'python/README.md', 'docs/getting-started/package-user-install.md',
    'docs/getting-started/source-checkout-install.md', 'docs/release/v1.1.0-publication-verification.md')]
scope = {}
links = {}
for path in paths:
    relative = path.relative_to(W).as_posix()
    raw = git('show', HEAD + ':' + relative)
    assert raw == path.read_bytes()
    scope[relative] = sha(raw)
    for line, text in enumerate(raw.decode().splitlines(), 1):
        for url in re.findall(r'https://github\.com/depsilon/shardloom/blob/[^\s)\]>"\x27`]+', text):
            links.setdefault(url, []).append(dict(file=relative, line=line))

rows = []
for url, occurrences in sorted(links.items()):
    parts = urlsplit(url)
    prefix, revision, path = parts.path.removeprefix('/depsilon/shardloom/').split('/', 2)
    assert prefix == 'blob' and not parts.query
    resolved = HEAD if revision == 'main' else git('rev-parse', revision + '^{commit}').decode().strip()
    raw = git('show', resolved + ':' + unquote(path))
    blob = git('rev-parse', resolved + ':' + unquote(path)).decode().strip()
    fragment = unquote(parts.fragment)
    if fragment:
        headings = {re.sub(r'[^\w\s-]', '', s.lstrip('# ').strip().lower()).replace(' ', '-')
                    for s in raw.decode().splitlines() if s.startswith('#')}
        explicit = set(re.findall(r'<a\s+(?:id|name)=["\x27]([^"\x27]+)', raw.decode()))
        assert fragment in headings | explicit, (url, fragment)
    rows.append(dict(url=url, revision=revision, resolved_commit=resolved, path=unquote(path),
                     fragment=fragment, blob_identity=blob, sha256=sha(raw), bytes=len(raw),
                     exists=True, occurrences=occurrences))
result = dict(status='passed_git_object_readback', source_commit=HEAD,
              source_tree=git('rev-parse', HEAD + '^{tree}').decode().strip(),
              scope_files=scope, links=rows, distinct_links=len(rows),
              occurrences=sum(len(row['occurrences']) for row in rows),
              main_links_bound_to_reviewed_publication_tree=True,
              live_http_or_deployment_check_claimed=False, observer_sha256=sha(Path(__file__).read_bytes()))
with OUT.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({k: result[k] for k in ('status', 'distinct_links', 'occurrences')}))
