"""Reconcile the first-party browser smoke with the exact optional beacon CSP block."""
import argparse, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXPECTED=("Loading the script 'https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092' "
          'violates the following Content Security Policy directive: "script-src \'self\' \'unsafe-inline\' \'wasm-unsafe-eval\'". '
          "Note that 'script-src-elem' was not explicitly set, so 'script-src' is used as a fallback. The action has been blocked.")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_bytes())
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--browser',type=Path,required=True);p.add_argument('--site',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
assert __debug__ and all(path.resolve().is_relative_to(ROOT) for path in [args.browser,args.site,args.output])
raw,site=read(args.browser),read(args.site)
assert read(ROOT/'publication-preview-browser-r1/browser.json')['console_errors'][0]==EXPECTED
assert site['status']=='passed' and site['stage']=='production' and site['matches']==len(site['comparisons'])
assert raw['merge_revision']==site['source_commit'] and raw['origin']==site['origin']=='https://shardloom.io'
previous=read(ROOT/'publication-preview-browser-r2/browser.json')
assert raw['checks']==previous['checks'] and raw['screenshots'].keys()==previous['screenshots'].keys()
for name,r in raw['screenshots'].items():
    path=Path(r['path'])
    assert path.resolve().parent==args.browser.resolve().parent and path.name==name
    assert sha(path)==r['sha256'] and r['dimensions']==previous['screenshots'][name]['dimensions']
errors=raw['console_errors']
assert len(errors)<=20 and all(v==EXPECTED for v in errors)
if errors:
    assert raw['status']=='failed' and raw['stage']=='failed'
    assert raw['error'].splitlines()[0]=='Error: Browser console errors: '+' | '.join(errors)
else:
    assert raw['status']=='passed' and raw['stage']=='complete' and 'error' not in raw
result={**raw,'status':'passed','stage':'first_party_interactions_verified',
        'strict_browser_status':raw['status'],'strict_browser_receipt':str(args.browser.resolve()),
        'strict_browser_receipt_sha256':sha(args.browser),'site_receipt_sha256':sha(args.site),
        'first_party_runtime_errors_observed':0,'optional_external_analytics_csp_blocks':len(errors),
        'zero_console_error_claimed':not bool(errors),'classifier_sha256':sha(Path(__file__))}
with args.output.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({k:result[k] for k in ('status','strict_browser_status','optional_external_analytics_csp_blocks','first_party_runtime_errors_observed')}))
