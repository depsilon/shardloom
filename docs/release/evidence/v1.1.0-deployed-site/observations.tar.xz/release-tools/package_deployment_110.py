"""Build a bounded, lossless post-deployment evidence packet for v1.1.0.

This preparer is intentionally inert until passed exact accepted merge, hosted,
site and browser receipts. It writes only the index and observations archive in
the publication worktree. Inputs and outputs are kept in their explicit roots.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import struct
import tarfile
import tempfile
from urllib.parse import urlsplit

R = Path('/Users/dylan/LocalData/shardloom/release-v1.1.0').resolve()
C = Path('/Users/dylan/.codex/worktrees/native-release-110-publication/shardloom-local-repo').resolve()
DEST = C / 'docs/release/evidence/v1.1.0-deployed-site'
LIMIT_MEMBER = 16 << 20
LIMIT_TOTAL = 64 << 20
LIMIT_MEMBERS = 400
BEACON = 'https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092'
PREVIEW_ORIGIN = re.compile(r'https://[a-z0-9-]+-shardloom\.djheinrich\.workers\.dev\Z')
PR_ONLY_CHECKS = {'CodeQL', 'CodeQL rust', 'CodeQL python'}
WORKERS_CHECK = 'Workers Builds: shardloom'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--merge-sha', required=True, help='clean checked-out merge SHA in C')
pre = parser.add_mutually_exclusive_group(required=True)
pre.add_argument('--premerge-review', help='passed exact-head publication PR review receipt')
pre.add_argument('--premerge-acceptance', help='passed exact-head alternate acceptance receipt')
parser.add_argument('--main-receipt', required=True, help='passed post-merge main receipt with raw_sources')
parser.add_argument('--preview-receipt', required=True, help='passed preview asset observer JSON')
parser.add_argument('--preview-browser', required=True, help='passed preview browser JSON')
parser.add_argument('--production-site', action='append', required=True,
                    help='production site observer JSON; repeat to preserve attempts in order')
parser.add_argument('--production-browser', action='append', required=True,
                    help='production browser JSON; repeat to preserve attempts in order')
parser.add_argument('--observation', action='append', default=[],
                    help='additional earlier or failed observation to retain; repeat as needed')
args = parser.parse_args()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=C, text=True, timeout=60).strip()


def owned_path(value, *, must_exist=True):
    path = Path(value)
    if not path.is_absolute():
        path = R / path
    path = path.resolve(strict=must_exist)
    require(path.is_relative_to(R), f'input escapes V evidence root: {value}')
    if must_exist:
        require(path.is_file(), f'missing required evidence file: {path}')
    return path


def read(path):
    raw = path.read_bytes()
    require(len(raw) <= LIMIT_MEMBER, f'JSON input exceeds {LIMIT_MEMBER} bytes: {path}')
    value = json.loads(raw)
    require(isinstance(value, dict), f'expected JSON object: {path}')
    return value


def rel(path):
    return path.relative_to(R).as_posix()


def git_source(path, commit):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=C, timeout=60)


def passed_review(review, merge, *, acceptance_mode=False):
    accepted_statuses = {'passed', 'accepted', 'passed_exact_head_acceptance'}
    if acceptance_mode:
        require(review.get('status') in accepted_statuses,
                'alternate exact-head acceptance receipt does not report a passed state')
    else:
        require(review.get('status') == 'passed_premerge', 'PR review is not passed_premerge')
    require(review.get('pr') == 1652, 'premerge receipt is not for publication PR #1652')
    head, base = review.get('head'), review.get('base')
    require(re.fullmatch(r'[0-9a-f]{40}', head or '') is not None, 'premerge receipt lacks exact head SHA')
    require(re.fullmatch(r'[0-9a-f]{40}', base or '') is not None, 'premerge receipt lacks exact base SHA')
    tree = review.get('source_tree') or review.get('tree')
    require(re.fullmatch(r'[0-9a-f]{40}', tree or '') is not None, 'premerge receipt lacks source tree')
    require(git('rev-parse', f'{merge}^{{tree}}') == tree, 'merge tree differs from accepted PR tree')
    require(git('rev-parse', f'{head}^{{tree}}') == tree, 'PR head tree differs from accepted tree')
    require(git('show', '-s', '--format=%P', merge).split() == [base, head],
            'merge parents are not exactly the accepted base and PR head')
    require(git('rev-parse', merge) == merge, 'merge SHA is not a commit in C')
    checks = review.get('checks')
    require(isinstance(checks, list) and checks, 'premerge receipt lacks its check rows')
    require(all(row.get('head_sha') == head and row.get('status') == 'completed'
                and row.get('conclusion') == 'success' for row in checks),
            'premerge checks include a non-success or wrong-head row')
    names = [row.get('name') for row in checks]
    require(all(isinstance(name, str) and name for name in names) and len(names) == len(set(names)),
            'premerge check names are missing or duplicated')
    require(all(urlsplit(row.get('html_url', '')).scheme == 'https'
                and urlsplit(row.get('html_url', '')).netloc == 'github.com'
                for row in checks), 'premerge check row has a non-GitHub or invalid URL')
    review_url = review.get('review_url', '')
    require(review_url.startswith('https://github.com/depsilon/shardloom/pull/1652'),
            'premerge review URL does not identify publication PR #1652')
    reported = review.get('successful_hosted_checks')
    if reported is not None:
        require(reported == len(checks), 'premerge successful check count differs from check rows')
    repo_count = review.get('successful_repository_checks')
    if repo_count is not None:
        require(0 < repo_count <= len(checks), 'premerge repository check count is invalid')
    require(not review.get('failures') and not review.get('missing') and not review.get('pending'),
            'premerge receipt reports failed, missing or pending checks')
    if acceptance_mode:
        require(review.get('exact_head_acceptance') is True
                or review.get('accepted_head') == head
                or review.get('head') == head,
                'alternate receipt does not explicitly accept this exact PR head')
        if review.get('synthetic'):
            require(git('rev-parse', f'{review["synthetic"]}^{{tree}}') == tree,
                    'alternate acceptance synthetic merge does not have the accepted tree')
    else:
        detail = review.get('review', {})
        require(detail.get('status') == 'completed' and detail.get('has_any_findings') is False
                and detail.get('has_unresolved_findings') is False,
                'premerge review is incomplete or reports findings')
        audit = review.get('audit', {})
        require(audit.get('reviewDecision') != 'CHANGES_REQUESTED'
                and audit.get('headRefOid') == head and audit.get('baseRefOid') == base
                and audit.get('mergeable') == 'MERGEABLE'
                and not audit.get('reviewThreads', {}).get('pageInfo', {}).get('hasNextPage')
                and not audit.get('reviews', {}).get('pageInfo', {}).get('hasNextPage')
                and all(row.get('isResolved') or row.get('isOutdated')
                        for row in audit.get('reviewThreads', {}).get('nodes', [])),
                'premerge review audit has unresolved threads or is not mergeable')
        require(review.get('tree_matches_synthetic') is True
                and review.get('synthetic')
                and git('rev-parse', f'{review["synthetic"]}^{{tree}}') == tree,
                'premerge synthetic merge does not have the accepted tree')
    return head, base, tree, len(checks), names


def verify_main(main, merge, pre_path, pre_check_names):
    require(main.get('status') == 'passed', 'main receipt is not passed')
    require(main.get('source_commit') == merge, 'main receipt source commit differs from merge')
    tree = git('rev-parse', f'{merge}^{{tree}}')
    require(main.get('source_tree') == tree, 'main receipt source tree differs from merge')
    require(main.get('pr') == 1652, 'main receipt is not for publication PR #1652')
    require(main.get('pr_head') and main.get('pr_base'), 'main receipt lacks exact PR head/base')
    parents = git('show', '-s', '--format=%P', merge).split()
    require(parents == [main['pr_base'], main['pr_head']], 'main receipt PR commits differ from merge parents')
    require(sha(pre_path.read_bytes()) == main.get('premerge_sha256'),
            'main receipt does not bind the supplied premerge receipt bytes')
    require(not main.get('failed') and not main.get('pending') and not main.get('missing'),
            'main receipt reports failed, pending or missing checks')
    names = main.get('required_hosted_check_names')
    require(isinstance(names, list) and names and len(names) == len(set(names)),
            'main receipt lacks a unique required hosted check set')
    hosted = main.get('successful_hosted_checks')
    repo = main.get('successful_repository_checks')
    expected_repository = set(pre_check_names) - PR_ONLY_CHECKS - {WORKERS_CHECK}
    expected_hosted = expected_repository | {WORKERS_CHECK}
    require(set(names) == expected_hosted,
            'main hosted check names do not reconcile with successful PR checks and main-only workflow policy')
    require(hosted == len(expected_hosted) == len(names) and repo == len(expected_repository),
            'main receipt success counts do not agree with required checks')
    require(main.get('website_tree') == git('rev-parse', f'{merge}:website'),
            'main receipt website tree differs from merged website tree')
    ci_url = urlsplit(main.get('ci_run_url', ''))
    require(ci_url.scheme == 'https' and ci_url.netloc == 'github.com'
            and ci_url.path.startswith('/depsilon/shardloom/actions/runs/'),
            'main receipt CI URL is missing or does not identify this repository')
    raw_sources = main.get('raw_sources')
    require(isinstance(raw_sources, dict) and raw_sources,
            'main receipt does not identify its raw provider source files')
    return tree


def verify_site(site, merge, *, production, source_revision=None):
    require(site.get('status') == 'passed', 'site observation did not pass')
    require(site.get('stage') == ('production' if production else 'preview'), 'site stage mismatch')
    expected_revision = source_revision or merge
    require(site.get('source_commit') == expected_revision, 'site observer source commit differs from accepted source')
    require(site.get('website_tree') == git('rev-parse', f'{merge}:website'),
            'site observer website tree differs from accepted merge')
    origin = site.get('origin')
    if production:
        require(origin == 'https://shardloom.io', 'production site origin is not canonical HTTPS origin')
    else:
        require(PREVIEW_ORIGIN.fullmatch(origin or '') is not None, 'preview origin is not an approved Workers URL')
    rows = site.get('comparisons')
    require(isinstance(rows, list) and rows, 'site receipt lacks authored asset comparisons')
    require(site.get('matches') == len(rows), 'site match count differs from comparison rows')
    for row in rows:
        require(row.get('matches') is True and row.get('status') == 200,
                f'authored site resource failed: {row.get("file", row.get("route"))}')
        additions = row.get('edge_additions') or []
        require(isinstance(additions, list) and len(additions) == len(set(additions))
                and set(additions) <= {'cloudflare_jsd_template', 'cloudflare_insights_beacon'},
                'site response contains unrecognized or duplicate edge additions')
        if additions:
            require(row.get('file', '').endswith('.html') and row.get('bytes_read', 0) > row.get('expected_bytes', 0)
                    and row['bytes_read'] <= row['expected_bytes'] + 8192,
                    'pinned edge additions have an invalid response size')
        else:
            require(row.get('expected_sha256') == row.get('sha256'),
                    f'authored site digest mismatch: {row.get("file", row.get("route"))}')
            require(row.get('expected_bytes') == row.get('bytes_read'),
                    f'authored site byte count mismatch: {row.get("file", row.get("route"))}')
        final = urlsplit(row.get('final_url', ''))
        expect = urlsplit(origin)
        require(final.scheme == 'https' and final.netloc == expect.netloc,
                f'site resource left expected origin: {row.get("final_url")}')
        expected_route = row.get('expected_route') or row.get('route')
        require(final.path.rstrip('/') == expected_route.rstrip('/'),
                f'site URL resolved to an unexpected route: {row.get("final_url")}')
    return len(rows)


def browser_errors(browser):
    errors = browser.get('console_errors')
    if errors is None and isinstance(browser.get('console'), dict):
        console = browser['console']
        count = console.get('optional_cloudflare_analytics_policy_blocks_observed', 0)
        require(console.get('first_party_runtime_errors_observed') == 0,
                'browser receipt reports first-party runtime errors')
        require(console.get('zero_console_error_claimed') is False,
                'analytics CSP receipt must not claim a clean console')
        require(0 <= count <= 20, 'analytics CSP block count is outside bound')
        return count
    require(isinstance(errors, list), 'browser receipt lacks console error observations')
    require(len(errors) <= 20, 'browser console error list exceeds bound')
    for error in errors:
        require(isinstance(error, str) and BEACON in error
                and 'Content Security Policy directive: "script-src \'self\' \'unsafe-inline\' \'wasm-unsafe-eval\'"' in error
                and 'The action has been blocked.' in error,
                'browser has an error other than the precisely pinned optional analytics CSP block')
    return len(errors)


def verify_browser(browser, merge, origin, *, preview):
    require(browser.get('status') == 'passed', 'browser observation did not pass')
    require(browser.get('origin') == origin, 'browser and site origins differ')
    revision = browser.get('merge_revision') or browser.get('source_revision') or browser.get('source_commit')
    require(revision == merge, 'browser observation is not tied to the accepted source revision')
    if browser.get('stage') == 'first_party_interactions_verified':
        strict = owned_path(browser['strict_browser_receipt'])
        original = read(strict)
        require(not preview and original['status'] == browser['strict_browser_status'] == 'failed'
                and sha(strict.read_bytes()) == browser['strict_browser_receipt_sha256']
                and sha(owned_path('publication-production-r1.json').read_bytes()) == browser['site_receipt_sha256']
                and sha(owned_path('release-tools/classify_production_browser_110.py').read_bytes()) == browser['classifier_sha256']
                and all(original[k] == browser[k] for k in ('checks', 'screenshots', 'console_errors', 'merge_revision', 'origin'))
                and browser['first_party_runtime_errors_observed'] == 0 and browser['zero_console_error_claimed'] is False
                and browser['optional_external_analytics_csp_blocks'] == browser_errors(browser) == 6,
                'production browser classification does not bind the original observations')
    else:
        require(browser.get('stage') in ('complete', 'passed', 'production', 'preview'), 'browser stage is incomplete')
    if 'primary_visual_review' in browser:
        require(browser['primary_visual_review'] == 'passed_no_blocking_defects_observed',
                'browser visual review did not pass')
    checks = browser.get('checks')
    require(isinstance(checks, dict) and checks, 'browser receipt lacks interaction checks')
    if 'search_message' in checks:
        require('7 results for 1.1.0' in checks['search_message'], 'browser search result is not release-specific')
        nav = checks.get('search_navigation', {})
        require(nav.get('version') is True and '/field-guide/' in nav.get('pathname', '')
                and nav.get('heading'), 'search result navigation was not verified')
        mobile = checks.get('mobile_table_navigation', {})
        require(mobile.get('pathname') == '/field-guide/local-tables/'
                and mobile.get('version') is True and mobile.get('menuExpanded') == 'false'
                and mobile.get('width') == mobile.get('documentWidth') == 390,
                'mobile page navigation or viewport width check failed')
        require(checks.get('install_mobile', {}).get('version') is True
                and checks['install_mobile'].get('install') is True,
                'mobile installation content was not verified')
        require(checks.get('install_desktop', {}).get('width')
                == checks['install_desktop'].get('documentWidth') == 1440,
                'desktop installation viewport check failed')
        require(checks.get('home_desktop', {}).get('width')
                == checks['home_desktop'].get('documentWidth') == 1440
                and checks.get('home_mobile', {}).get('width')
                == checks['home_mobile'].get('documentWidth') == 390,
                'desktop or mobile home viewport check failed')
    elif 'search' in browser:
        search = browser['search']
        mobile = browser.get('mobile', {})
        require(search.get('status') == 'passed' and search.get('query') == '1.1.0'
                and search.get('result_count', 0) > 0, 'production search observation did not pass')
        require(mobile.get('status') == 'passed' and mobile.get('document_horizontal_overflow_observed') is False,
                'production mobile observation did not pass')
    else:
        raise ValueError('browser receipt schema has no recognized search/navigation contract')
    count = browser_errors(browser)
    screenshots = browser.get('screenshots')
    if screenshots is None:
        screenshots = {k: v for k, v in browser.get('files', {}).items()
                       if k.lower().endswith('.png')}
    require(isinstance(screenshots, dict) and screenshots, 'browser receipt lacks screenshots')
    needed = ('home-desktop.png', 'search-desktop.png', 'install-desktop.png',
              'install-mobile.png', 'mobile-tables.png', 'home-mobile.png')
    require(all(name in screenshots for name in needed),
            'browser receipt must include desktop home/search/install and mobile install/tables/home screenshots')
    files = []
    for name, info in screenshots.items():
        path_value = info.get('path') if isinstance(info, dict) else None
        path = owned_path(path_value or name)
        raw = path.read_bytes()
        digest = info.get('sha256') if isinstance(info, dict) else None
        require(digest == sha(raw), f'screenshot digest differs from browser receipt: {path}')
        require(raw.startswith(b'\x89PNG\r\n\x1a\n'), f'screenshot is not PNG: {path}')
        dimensions = info.get('dimensions') if isinstance(info, dict) else None
        if dimensions:
            actual = list(struct.unpack('>II', raw[16:24]))
            require(actual == dimensions, f'screenshot dimensions differ from receipt: {path}')
        files.append(path)
    for relative, info in browser.get('files', {}).items():
        path = owned_path(relative)
        raw = path.read_bytes()
        require(len(raw) == info.get('bytes') and sha(raw) == info.get('sha256'),
                f'browser evidence file digest/size differs from receipt: {path}')
        if path not in files:
            files.append(path)
    return count, files


merge = args.merge_sha
require(re.fullmatch(r'[0-9a-f]{40}', merge) is not None, '--merge-sha must be lowercase 40-character SHA')
require(git('rev-parse', 'HEAD') == merge, 'C is not checked out at --merge-sha')
require(not git('status', '--porcelain'), 'C must be a clean checkout before packaging')
require(not DEST.exists(), f'destination already exists: {DEST}')

pre_path = owned_path(args.premerge_review or args.premerge_acceptance)
main_path, preview_path = owned_path(args.main_receipt), owned_path(args.preview_receipt)
preview_browser_path = owned_path(args.preview_browser)
production_paths = [owned_path(p) for p in args.production_site]
production_browser_paths = [owned_path(p) for p in args.production_browser]
require(production_paths and production_browser_paths, 'production site and browser receipts are required')
review, main = read(pre_path), read(main_path)
preview_site, preview_browser = read(preview_path), read(preview_browser_path)
production_sites = [read(p) for p in production_paths]
production_browsers = [read(p) for p in production_browser_paths]
pre_head, pre_base, pre_tree, pre_check_count, pre_check_names = passed_review(
    review, merge, acceptance_mode=args.premerge_acceptance is not None)
tree = verify_main(main, merge, pre_path, pre_check_names)
require(main.get('pr_head') == pre_head and main.get('pr_base') == pre_base,
        'main receipt PR head/base do not match premerge receipt')
require(pre_tree == tree, 'premerge and merged source trees differ')
require(preview_site.get('source_commit') == pre_head,
        'preview site must verify the accepted PR head commit')
preview_count = verify_site(preview_site, merge, production=False, source_revision=pre_head)
preview_browser_count, preview_shots = verify_browser(
    preview_browser, pre_head, preview_site['origin'], preview=True)
require(preview_browser_count == 0, 'preview browser console contains errors')

production_summaries, production_shots = [], []
for path, site in zip(production_paths, production_sites):
    count = verify_site(site, merge, production=True)
    production_summaries.append({'receipt': rel(path), 'status': site['status'],
                                 'authored_assets': count, 'matches': site.get('matches')})
require(production_sites[-1].get('status') == 'passed', 'latest production site receipt did not pass')
for path, browser in zip(production_browser_paths, production_browsers):
    analytics_blocks, shots = verify_browser(browser, merge, 'https://shardloom.io', preview=False)
    production_shots.extend(shots)
    require(browser is production_browsers[-1] or browser.get('status') in ('passed', 'failed'),
            'unexpected production browser attempt status')
    if browser is production_browsers[-1]:
        accepted_analytics_blocks = analytics_blocks
require(production_browsers[-1].get('status') == 'passed', 'latest production browser receipt did not pass')

# Retain the known original comparison and failed preview browser observation by
# default. Additional failures/attempts are explicit CLI inputs, never inferred.
observation_values = ['pr1652-original-and-new-preview-r1.json',
                      'publication-preview-browser-r1/browser.json', *args.observation]
observation_paths = list(dict.fromkeys(owned_path(v) for v in observation_values))
observations = [read(p) for p in observation_paths]
require(any(p.name == 'pr1652-original-and-new-preview-r1.json' for p in observation_paths),
        'original-versus-updated PR observation is required')

# Exact owned inputs: named receipts, main observer raw sources, actual browser
# screenshots, known driver/observer programs, this packager, and explicit attempts.
members = {}

def add(path):
    path = path.resolve()
    require(path.is_file() and path.is_relative_to(R), f'packet input is missing or outside V: {path}')
    key, raw = rel(path), path.read_bytes()
    require(len(raw) <= LIMIT_MEMBER, f'packet member exceeds individual size bound: {key}')
    require(key not in members, f'duplicate archive member: {key}')
    require(len(members) < LIMIT_MEMBERS, 'packet member count exceeds bound')
    require(sum(len(data) for data in members.values()) + len(raw) <= LIMIT_TOTAL,
            'packet total uncompressed bytes exceed bound')
    members[key] = raw


for path in [pre_path, main_path, preview_path, preview_browser_path,
             *production_paths, *production_browser_paths, *observation_paths,
             *preview_shots, *production_shots]:
    add(path)
for source in [main, *(row for row in observations if row.get('raw_sources'))]:
    require(source.get('source_commit') == merge and source.get('pr') == 1652,
            'main check observations belong to a different merge')
    for relative, expected in source['raw_sources'].items():
        path = owned_path(relative)
        require(sha(path.read_bytes()) == expected, f'main raw-source digest mismatch: {relative}')
        if rel(path) not in members:
            add(path)
for name in ('release-tools/observe_docs_main_110.py',
             'release-tools/observe_published_site_110.py',
             'release-tools/observe_preview_original_110.py',
             'release-tools/browser_110.cjs', 'browser_110_preview_r2.cjs',
             'release-tools/audit_publication_links_110.py', 'release-tools/check_mobile_install_paint_110.cjs',
             'release-tools/classify_production_browser_110.py',
             'release-tools/package_deployment_110.py'):
    add(owned_path(name))

links_path=owned_path('release-110-merged-repository-links-1.json')
links=read(links_path)
require(links['status']=='passed_git_object_readback' and links['source_commit']==merge and
        links['source_tree']==tree and links['distinct_links']==len(links['links']) and
        links['occurrences']==sum(len(row['occurrences']) for row in links['links']), 'repository links differ')
for row in links['links']:
    require(sha(git_source(row['path'],row['resolved_commit']))==row['sha256'], 'linked Git content differs')
require(links['observer_sha256']==sha(owned_path('release-tools/audit_publication_links_110.py').read_bytes()),'link observer differs')
add(links_path)
cloud_path=owned_path('release-110-cloudflare-main-1.json')
cloud=read(cloud_path)
require(cloud['head_sha']==merge and cloud['conclusion']=='success' and cloud['id']==main['workers_check']['id'],
        'Workers deployment is not bound to the verified main check')
add(cloud_path)
visual_path=owned_path('production-visual-review-r1.json')
visual=read(visual_path)
require(visual['source_commit']==merge and visual['status']=='passed_with_recorded_resize_capture_discrepancy'
        and visual['site_receipt_sha256']==sha(production_paths[-1].read_bytes())
        and visual['browser_receipt_sha256']==sha(production_browser_paths[-1].read_bytes()),
        'visual inspection is outside the accepted observation')
add(visual_path)
mobile_path=owned_path('publication-mobile-install-paint-r1/observations.json')
mobile=read(mobile_path)
require(sha(mobile_path.read_bytes())==visual['mobile_followup']['observations_sha256'] and mobile['source']==merge,
        'mobile supplementary observation differs')
add(mobile_path)
for row in mobile['captures']:
    shot=owned_path(row['file'])
    require(sha(shot.read_bytes())==row['sha256'] and row['headerRects'][0][1]==[0,0,390,64],
            'supplementary screenshot or geometry differs')
    add(shot)
strict=owned_path(production_browsers[-1]['strict_browser_receipt'])
require(sha(strict.read_bytes())==production_browsers[-1]['strict_browser_receipt_sha256'],'original production browser receipt differs')
if rel(strict) not in members:
    add(strict)
add(owned_path('publication-production-browser-r1-driver.log'))

main_observer = owned_path('release-tools/observe_docs_main_110.py')
require(main.get('observer_sha256') == sha(main_observer.read_bytes()),
        'main receipt observer digest differs from retained observer script')
site_observer = owned_path('release-tools/observe_published_site_110.py')
# The original Python HTTP preview observer retained response digests directly.
# It did not emit browser-program sidecars or a self-hash.
captured_preview = read(owned_path('pr1652-original-and-new-preview-r1.json'))
require(captured_preview['preview_assets']==preview_site and captured_preview['preview_browser']==preview_browser,
        'preview differs from the original hosted observation')
for path, site in zip(production_paths, production_sites):
    require(site.get('observer_sha256') == sha(site_observer.read_bytes()),
            f'site receipt observer digest differs from retained script: {path}')

for site in [preview_site, *production_sites]:
    for row in site['comparisons']:
        source = row.get('source_path') or row.get('served_file') or row.get('file')
        require(isinstance(source, str), 'site comparison lacks exact authored source path')
        source_path = source if source.startswith('website/') else 'website/' + source
        raw = git_source(source_path, merge)
        expected = row.get('expected_sha256') or row.get('source_sha256')
        require(sha(raw) == expected, f'authored asset source differs from accepted merge: {source}')

total = sum(map(len, members.values()))
manifest = {key: {'bytes': len(raw), 'sha256': sha(raw)} for key, raw in sorted(members.items())}
archive_payload = DEST / 'observations.tar.xz'
index_path = DEST / 'index.json'
summary = {
    'schema_version': 'shardloom.release_deployed_site_evidence.v1',
    'status': 'passed', 'release_version': '1.1.0', 'merge_commit': merge,
    'source_tree': tree, 'website_tree': git('rev-parse', f'{merge}:website'),
    'publication_pr': 1652,
    'premerge': {'receipt': rel(pre_path), 'head': pre_head, 'base': pre_base,
                 'check_count': pre_check_count, 'check_names': sorted(pre_check_names)},
    'main': {'receipt': rel(main_path), 'successful_repository_checks': main['successful_repository_checks'],
             'successful_hosted_checks': main['successful_hosted_checks'],
             'required_hosted_check_names': main['required_hosted_check_names'],
             'raw_sources': main['raw_sources']},
    'preview': {'receipt': rel(preview_path), 'status': preview_site['status'],
                'origin': preview_site['origin'], 'authored_assets': preview_count,
                'browser_receipt': rel(preview_browser_path), 'browser_status': preview_browser['status'],
                'screenshots': len(preview_shots)},
    'production_site_attempts': production_summaries,
    'production_browser_attempts': [
        {'receipt': rel(path), 'status': browser['status'], 'origin': browser['origin'],
         'screenshots': len(browser.get('screenshots', {})),
         'pinned_optional_analytics_csp_blocks': browser_errors(browser)}
        for path, browser in zip(production_browser_paths, production_browsers)],
    'accepted_production_optional_analytics_csp_blocks': accepted_analytics_blocks,
    'repository_links': {'receipt':rel(links_path),'distinct':links['distinct_links'],'occurrences':links['occurrences']},
    'production_visual_review': {'receipt':rel(visual_path),'resize_capture':visual['mobile_followup']['inspection']},
    'known_prior_observations': [{'receipt': rel(path), 'status': row.get('status'),
                                  'original': row.get('original'), 'updated': row.get('updated')}
                                 for path, row in zip(observation_paths, observations)],
    'archive': {'path': 'observations.tar.xz', 'member_count': len(members),
                'uncompressed_bytes': total, 'members': manifest},
    'claim_boundaries': [
        'The browser recorded each policy block of the optional Cloudflare analytics beacon.',
        'The HTTP comparisons cover the selected authored assets. The separate repository-link audit verifies Git objects and named fragments.',
        'Release scope is technical-preview installation and documentation deployment.'
    ]
}

# All prerequisites and byte checks complete before creating the output directory.
DEST.mkdir(parents=True)
try:
    with tempfile.TemporaryDirectory(prefix='.deployment-packet-', dir=DEST) as temporary:
        temp = Path(temporary)
        archive_tmp = temp / 'observations.tar.xz'
        with tarfile.open(archive_tmp, 'w:xz', preset=6) as tar:
            for key, raw in sorted(members.items()):
                import io
                info = tarfile.TarInfo(key)
                info.size = len(raw)
                info.mode = 0o600
                tar.addfile(info, io.BytesIO(raw))
        with tarfile.open(archive_tmp, 'r:xz') as tar:
            rows = tar.getmembers()
            require(len(rows) == len(members) and sum(row.size for row in rows) == total,
                    'archive member count or byte bound changed on reopen')
            require({row.name for row in rows} == set(members), 'archive member inventory changed')
            for row in rows:
                raw = tar.extractfile(row).read()
                require(raw == members[row.name] and sha(raw) == manifest[row.name]['sha256'],
                        f'archive member failed exact byte verification: {row.name}')
        packed = archive_tmp.read_bytes()
        summary['archive']['bytes'] = len(packed)
        summary['archive']['sha256'] = sha(packed)
        index_tmp = temp / 'index.json'
        index_tmp.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        archive_tmp.replace(archive_payload)
        index_tmp.replace(index_path)
except Exception:
    for path in (archive_payload, index_path):
        path.unlink(missing_ok=True)
    try:
        DEST.rmdir()
    except OSError:
        pass
    raise

print(json.dumps({'status': 'passed', 'merge_commit': merge, 'members': len(members),
                  'uncompressed_bytes': total, 'archive_sha256': summary['archive']['sha256']}))
