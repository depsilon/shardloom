'use strict';
const {chromium} = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '../publication-mobile-install-paint-r1');
const pageUrl = 'https://shardloom.io/field-guide/start-local-proof/';
const mobile = {width:390,height:844};
const desktop = {width:1440,height:1000};
fs.mkdirSync(root);
const report = {origin: pageUrl, source:'ad2ed5cb1da279413e93e402ee56d7bb24478d90', captures:[]};
async function settled(page) {
  await page.evaluate(async () => {
    await document.fonts.ready;
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  });
}
async function capture(page, name) {
  const state = await page.evaluate(() => {
    const box = el => { const r=el.getBoundingClientRect(); return [r.x,r.y,r.width,r.height]; };
    return {viewport: [innerWidth,innerHeight],scroll:[scrollX,scrollY],documentWidth:document.documentElement.scrollWidth,
      headerRects:[...document.querySelectorAll('header')].map(el=>[el.className,box(el)]),
      topHit:document.elementsFromPoint(82,30).slice(0,4).map(el=>[el.tagName,el.className,box(el)]),
      bottomHit:document.elementsFromPoint(82,790).slice(0,4).map(el=>[el.tagName,el.className,box(el)]),
      mainHeading:document.querySelector('h1')?.textContent, installer:document.body.innerText.includes('python -m pip install shardloom==1.1.0')};
  });
  const file=path.join(root,name+'.png'), raw=await page.screenshot({path:file,fullPage:false});
  if (state.documentWidth!==390 || state.viewport[1]!==844 || !state.installer) throw Error('mobile content or geometry differs');
  report.captures.push({name,file,sha256:crypto.createHash('sha256').update(raw).digest('hex'),...state});
}
(async()=>{
  const browser=await chromium.launch({channel:'chrome',headless:true});
  try {
    const fresh=await browser.newPage({viewport:mobile,deviceScaleFactor:1});
    await fresh.goto(pageUrl,{waitUntil:'networkidle'});await settled(fresh);await capture(fresh,'fresh-mobile');
    const resized=await browser.newPage({viewport:desktop,deviceScaleFactor:1});
    await resized.goto(pageUrl,{waitUntil:'networkidle'});await resized.setViewportSize(mobile);
    await capture(resized,'immediate-resize');await settled(resized);await capture(resized,'settled-resize');
    report.status='complete';
  } finally {
    await browser.close();
    fs.writeFileSync(path.join(root,'observations.json'),JSON.stringify(report,null,2)+'\n');
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
