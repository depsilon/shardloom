"""Freeze the successful final native build before clean-wheel verification."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
build = json.loads((ROOT / 'release-build-r2.json').read_text())
assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
source = Path(build['environment']['CARGO_TARGET_DIR']) / 'release'
destination = ROOT / 'runtime-r2'
assert not destination.exists()
destination.mkdir()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()

report = {'build_receipt': 'release-build-r2.json', 'files': []}
for name in ('shardloom', 'lib_native.dylib'):
    original, copied = source / name, destination / name
    assert original.is_file() and not original.is_symlink()
    before = digest(original)
    shutil.copy2(original, copied)
    assert digest(copied) == before == digest(original)
    report['files'].append({'path': str(copied), 'bytes': copied.stat().st_size, 'sha256': before})
(ROOT / 'runtime-identity-r2.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
