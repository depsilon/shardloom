"""Verify the minimal-feature gate correction, then prove the final package."""
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
GUARD = OUT / 'tools/guard_managed_binary.py'
ENV = ['env', 'CARGO_PROFILE_DEV_DEBUG=0', 'CARGO_PROFILE_TEST_DEBUG=0', 'PYO3_PYTHON=' + PYTHON]
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
stages = [
    ('format-check-r2', 120, ['cargo', 'fmt', '--all', '--', '--check']),
    ('write-feature-check-r2', 1200, ENV + ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'vortex-write', '--locked', '--offline']),
    ('native-workspace-clippy-r5', 3600, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'shardloom-python/python-native', '--locked', '--offline', '--', '-D', 'warnings']),
    ('binary-final-tests-r1', 1800, ENV + ['cargo', 'test', '-p', 'shardloom-vortex', '--features', 'native-binary-objects', '--lib', 'binary_object', '--locked', '--offline']),
    ('release-build-r2', 5400, ENV + ['cargo', 'build', '--locked', '--offline', '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime-r2', 600, [PYTHON, str(OUT / 'tools/freeze_binary_runtime_r2.py')]),
    ('installed-wheel-r1', 2400, [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(OUT / 'installed-proof-r1'),
        '--native-library', str(OUT / 'runtime-r2/lib_native.dylib'),
        '--cli-binary', str(OUT / 'runtime-r2/shardloom'), '--wheelhouse', WHEELHOUSE]),
]
receipt = OUT / 'check-sequence-r2.json'
assert not receipt.exists()
previous = json.loads((OUT / 'release-build-r1.json').read_text())
assert previous['status'] == 'failed' and previous['process_group_drained']
state = {'status': 'running', 'completed': [], 'active_stage': None}

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for name, timeout, command in stages:
        state.update(active_stage=name)
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_text())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        if name == 'write-feature-check-r2':
            assert 'native_extensions.rs' not in (OUT / (name + '.log')).read_text()
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
