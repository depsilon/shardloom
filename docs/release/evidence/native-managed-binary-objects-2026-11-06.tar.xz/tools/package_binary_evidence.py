"""Package completed finite correctness evidence, preserving failed attempts."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'docs/release/evidence'
NAME = 'native-managed-binary-objects-2026-11-06'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

required = ['native-workspace-tests-r1', 'default-workspace-tests-r1', 'default-clippy-r1',
    'feature-matrix-r1', 'format-check-r2', 'write-feature-check-r2',
    'native-workspace-clippy-r5', 'binary-final-tests-r1', 'release-build-r2',
    'freeze-runtime-r2', 'installed-wheel-r1']
checks = []
for name in required:
    record = read(OUT / (name + '.json'))
    assert record['status'] == 'passed' and record['returncode'] == 0 and record['process_group_drained'], name
    log = (OUT / (name + '.log')).read_bytes()
    assert sha(log) == record['log_sha256'], name
    entry = {'receipt': name + '.json', 'command': record['command'], 'status': 'passed'}
    results = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    if results:
        entry['rust_tests'] = dict(zip(('passed', 'failed', 'ignored'),
            (sum(int(row[i]) for row in results) for i in range(3))))
        assert entry['rust_tests']['failed'] == 0
    checks.append(entry)
for name in ['docs-r1', 'docs-r2', 'python-schema-regression-r1']:
    record = read(OUT / (name + '.json'))
    assert record['status'] == 'passed'
    assert sha((OUT / (name + '.log')).read_bytes()) == record['log_sha256']
    checks.append({'receipt': name + '.json', 'status': 'passed', 'scope': record['scope']})

installed = read(OUT / 'installed-proof-r1/report.json')
assert read(OUT / 'check-sequence-r2.json')['status'] == 'passed'
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration']['status'] == 'passed'
assert installed['integration']['tests'] >= 319 and installed['integration']['skipped'] == 0
assert not installed['publication_attempted']
integration = (OUT / 'installed-proof-r1/integration.log').read_text()
for suffix in [
    'public_reads_are_exact_lazy_bounded_and_retained',
    'nested_rows_join_sort_spill_and_stream_keep_handles',
    'explicit_cross_session_transfer_and_bare_arrow_refusal',
    'portable_export_reopens_in_a_fresh_process_after_relocation',
    'incompatible_sinks_and_failed_producers_do_not_publish',
    'keys_comparison_and_arithmetic_fail_without_payload_reads',
    'native_writes_are_portable_across_all_five_interfaces',
]:
    name = 'test_binary_object_' + suffix
    assert any(line.startswith(name + ' ') and line.endswith(' ... ok')
               for line in integration.splitlines()), name
for name, key in [('lib_native.dylib', 'native_library_sha256'), ('shardloom', 'cli_sha256')]:
    assert sha((OUT / 'runtime-r2' / name).read_bytes()) == installed['integrity'][key]

build = read(OUT / 'release-build-r2.json')
source = {name: descriptor for name, descriptor in build['changed_source_inventory'].items()
          if Path(name).suffix in {'.rs', '.py', '.toml'} or name == 'Cargo.lock'}
for name, descriptor in source.items():
    assert sha((ROOT / name).read_bytes()) == descriptor['sha256'], name
for proof in ['native-workspace-clippy-r5', 'binary-final-tests-r1', 'installed-wheel-r1']:
    record = read(OUT / (proof + '.json'))
    for name, descriptor in source.items():
        assert record['changed_source_inventory'][name] == descriptor, (proof, name)

dispositions = {
    'binary-adversarial-tests-r1': 'The empty Arrow last-owner fixture still retained its completed result; corrected final-owner release passes.',
    'binary-persistence-tests-r1': 'Test imports and the owned Arrow stream receiver were corrected before runtime execution.',
    'binary-persistence-tests-r2': 'Empty object arrays exposed a missing extension-storage branch in native empty/gather builders; corrected and verified.',
    'binary-python-lifecycle-tests-r1': 'Native object dtype copy support was added; the failing producer fixture now preexports its Arrow batch rather than recursively entering the active session.',
    'python-binding-check-r1': 'Native binary-object feature closure was wired through the CLI release surface shared by the Python binding.',
    'release-build-r1': 'Deliberately stopped through bounded guard cleanup before correcting the write-only feature gate; final release r2 replaces it.',
    'check-sequence-r1': 'The sequence stopped on the deliberately interrupted build. It did not install or freeze an unaccepted runtime.',
}
failures = []
for path in sorted(OUT.glob('*.json')):
    record = read(path)
    if record.get('status') != 'failed':
        continue
    disposition = dispositions.get(path.stem)
    if path.stem.startswith('native-workspace-clippy-r'):
        disposition = 'Checked conversions and source organization corrected; final strict native lint passes.'
    assert disposition, path
    failures.append({'receipt': path.name, 'status': 'failed', 'returncode': record.get('returncode'),
                     'error': record.get('error'), 'disposition': disposition})

files = sorted(set([*OUT.glob('*.json'), *OUT.glob('*.log'), *OUT.glob('source-blobs/*'),
    *OUT.glob('tools/*.py'), *OUT.glob('installed-proof-r1/*.json'), *OUT.glob('installed-proof-r1/*.log')]))
files = [path for path in files if not path.name.startswith('package-evidence-')]
assert sum(path.stat().st_size for path in files) <= 64 << 20
manifest = []
archive = DEST / (NAME + '.tar.xz')
assert not archive.exists() and not (DEST / (NAME + '.json')).exists()
with tarfile.open(archive, 'w:xz', preset=6) as bundle:
    for path in files:
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        relative = path.relative_to(OUT).as_posix()
        manifest.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
        info = tarfile.TarInfo(relative)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        bundle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as bundle:
    assert bundle.getnames() == [entry['path'] for entry in manifest]
    for entry in manifest:
        data = bundle.extractfile(entry['path']).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']

report = {
    'schema_version': 'shardloom.managed_binary_objects_acceptance.v1', 'status': 'locally_accepted',
    'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'verified_changed_build_sources': source, 'checks': checks, 'original_failures': failures,
    'installed_package': installed['integration'], 'installed_wheel_sha256': installed['integrity']['wheel_sha256'],
    'native_library_sha256': installed['integrity']['native_library_sha256'], 'cli_sha256': installed['integrity']['cli_sha256'],
    'verification_scope': 'Full native/default suites precede only the local-primitives helper cfg gate. Source verification binds that sole Rust difference; final focused tests, strict lint and installed integration cover the final build.',
    'runtime_contract': 'Explicit local managed/external byte objects, bounded integrity-checked reads, one self-contained managed native file, shared relational/spill owners and deterministic incompatible-sink refusal.',
    'interface_proof': ['dataframe', 'native_sql', 'typed_plan', 'embedded_workflow', 'cli_sql'],
    'limitations': ['Local files only; external references remain externally owned and nonportable.',
        'Conservative session arena retention can keep unused objects until final owner release.',
        'Shared private-file transfers retain original storage quota until final backing owner release.',
        'Compatibility files reject object descriptors; explicit byte conversion is required.',
        'Python reads explicitly copy caller-owned bytes; native memory accounting is not a process-RSS guarantee.',
        'New formats require the matching native reader; no package publication is performed.',
        'Normal opt-in native observation tests remain excluded; no benchmark or performance claim is made.',
        'Legacy warnings in unchanged minimal-feature sources are retained in the original log.'],
    'publication_attempted': False, 'performance_claim': False, 'whole_item_19_complete': False,
    'hosted_integration': 'pending', 'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()), 'members': manifest,
}
(DEST / (NAME + '.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'members': len(manifest),
                  'archive_bytes': archive.stat().st_size, 'installed_package': report['installed_package']}))
