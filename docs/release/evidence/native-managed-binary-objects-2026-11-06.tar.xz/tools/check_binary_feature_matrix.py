"""Exercise feature isolation and public feature closure sequentially."""
import subprocess

commands = [
    ['cargo', 'check', '--workspace', '--no-default-features'],
    ['cargo', 'check', '--workspace', '--all-features'],
    ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'upstream-vortex'],
    ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'vortex-file-io'],
    ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'vortex-local-primitives'],
    ['cargo', 'check', '-p', 'shardloom-vortex', '--no-default-features', '--features', 'native-binary-objects'],
    ['cargo', 'test', '-p', 'shardloom-cli', '--all-targets', '--no-default-features', '--features', 'vortex-write'],
]
for command in commands:
    command += ['--locked', '--offline']
    print('Checking ' + ' '.join(command), flush=True)
    subprocess.run(command, check=True, timeout=1800)
