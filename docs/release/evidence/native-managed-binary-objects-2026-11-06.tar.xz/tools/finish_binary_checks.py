"""Continue the already-authorized local checks after the native suite drains."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
GUARD = OUT / 'tools/guard_managed_binary.py'
ENV = ['env', 'CARGO_PROFILE_DEV_DEBUG=0', 'CARGO_PROFILE_TEST_DEBUG=0', 'PYO3_PYTHON=' + PYTHON]
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
stages = [
    ('format-check-r1', 120, ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-clippy-r1', 3600, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings']),
    ('default-workspace-tests-r1', 5400, ENV + ['cargo', 'test', '--workspace', '--all-targets', '--locked', '--offline']),
    ('feature-matrix-r1', 7200, ENV + [PYTHON, str(OUT / 'tools/check_binary_feature_matrix.py')]),
    ('release-build-r1', 5400, ENV + ['cargo', 'build', '--locked', '--offline', '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime-r1', 600, [PYTHON, str(OUT / 'tools/freeze_binary_runtime.py')]),
    ('installed-wheel-r1', 2400, [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py',
        '--output-dir', str(OUT / 'installed-proof-r1'),
        '--native-library', str(OUT / 'runtime-r1/lib_native.dylib'),
        '--cli-binary', str(OUT / 'runtime-r1/shardloom'), '--wheelhouse', WHEELHOUSE]),
]
receipt = OUT / 'check-sequence-r1.json'
assert not receipt.exists()
state = {'status': 'waiting_for_native_suite', 'completed': [], 'active_stage': None}

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

save()
try:
    native = OUT / 'native-workspace-tests-r1.json'
    while not native.exists():
        time.sleep(2)
    prior = json.loads(native.read_text())
    assert prior['status'] == 'passed' and prior['returncode'] == 0 and prior['process_group_drained'], prior['status']
    for name, timeout, command in stages:
        state.update(status='running', active_stage=name)
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_text())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
