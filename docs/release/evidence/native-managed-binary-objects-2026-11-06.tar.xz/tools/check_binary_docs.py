"""Run source, reference and installed-schema prerequisites for this work unit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
commands = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status-docs-r1.json')],
    ['scripts/check_contribution_governance.py', '--output', str(OUT / 'contribution-governance-r1.json')],
    ['scripts/check_python_license_bundle.py'],
    ['-m', 'unittest', '-v', 'python.tests.test_public_api_reference', 'python.tests.test_binary_object_schema'],
]
report = {'status': 'running', 'checks': [], 'scope': 'bounded_static_checks_no_native_execution'}
receipt, log = OUT / 'docs-r1.json', OUT / 'docs-r1.log'
assert not receipt.exists() and not log.exists()
try:
    with log.open('x') as stream:
        for command in commands:
            invocation = [sys.executable, '-B', *command]
            print('Checking ' + ' '.join(invocation), file=stream, flush=True)
            result = subprocess.run(invocation, cwd=ROOT, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=120, check=False)
            report['checks'].append({'command': invocation, 'returncode': result.returncode})
            if result.returncode:
                raise RuntimeError('static check failed: ' + command[0])
    report['status'] = 'passed'
finally:
    if report['status'] == 'running':
        report['status'] = 'failed'
    report['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    receipt.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))
